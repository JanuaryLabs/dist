import { Database } from '../database';
export declare function sqlite(options?: {
    uri?: string;
}): Database;
