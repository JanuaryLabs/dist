import type { TableDefinition } from './table';
import type { TriggerDefinition, WorkflowDefinition } from './workflow';
export interface PolicyDefinition {
    name: string;
    rule: string;
}
export interface FeatureDefinition<W> {
    name: string;
    workflows: W;
    tables: Record<string, TableDefinition>;
    policies?: Record<string, string>;
}
interface FeatureConfig {
    experimental?: unknown[];
    tables: Record<string, TableDefinition>;
    policies?: Record<string, Policy>;
    workflows: WorkflowDefinition<TriggerDefinition<unknown, unknown>>[];
}
export type Policy = (name: string) => string;
export declare function feature(config: FeatureConfig): FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown, unknown>>[]>;
export declare function feature(name: string, config: FeatureConfig): FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown, unknown>>[]>;
export declare namespace feature {
    var _a: <W>(name: string, config: {
        experimental?: unknown[];
        workflows: Record<string, any>;
        tables: Record<string, TableDefinition>;
        policies?: Record<string, Policy>;
    }) => FeatureDefinition<W>;
    export { _a as new };
}
export {};
