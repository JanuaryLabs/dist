import type { Context } from 'hono';
import { Policy } from '@january/declarative';
import type { Extension } from '../extension';
interface HonoOptions {
    useFeatureNameAsBasePath: boolean;
    generateSwagger: (featureName: string) => boolean;
}
export declare const honoDefaultOptions: HonoOptions;
export declare function hono(options?: HonoOptions): Extension;
declare module '@january/declarative' {
    namespace policy {
        function http(policyFn: (context: Context) => void): Policy;
    }
}
export {};
