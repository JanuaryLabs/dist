import type { Extension } from '../../extension';
export declare const webhooks: Extension;
