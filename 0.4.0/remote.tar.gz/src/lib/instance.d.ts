import type { GetEventsOptions } from 'dockerode';
import { Observable } from 'rxjs';
export declare const INTERNAL_PORT = 3000;
export declare function listenToDockerEvents(options: Omit<GetEventsOptions, 'abortSignal'>): Observable<any[]>;
export interface LogEntry {
    timestamp: string;
    log: string;
}
export declare function containerLogs(containerName: string): Observable<LogEntry>;
