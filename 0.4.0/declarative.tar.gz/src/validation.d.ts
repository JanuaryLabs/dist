import type { JSONSchemaType } from 'ajv';
export declare function createSchema<T>(properties: Record<keyof T, JSONSchemaType<any> & {
    required?: boolean;
}>): JSONSchemaType<T>;
/**
 * Validate input against schema
 *
 * @param schema ajv augmented json-schema
 * @param input input to validate
 * @returns
 */
export declare function validateInput<T>(schema: JSONSchemaType<T>, input: Record<keyof T, unknown>): asserts input is T;
