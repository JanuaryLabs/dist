import type { Contracts } from '@faslh/compiler/contracts';
interface HonoOptions {
    useFeatureNameAsBasePath: boolean;
    generateSwagger: (featureName: string) => boolean;
}
export declare const honoDefaultOptions: HonoOptions;
export declare const hono: (options?: HonoOptions) => {
    packages: {
        boxen: {
            version: string;
            dev: false;
        };
        'fast-glob': {
            version: string;
            dev: false;
        };
        ip: {
            version: string;
            dev: false;
        };
        '@types/ip': {
            version: string;
            dev: false;
        };
        hono: {
            version: string;
            dev: false;
        };
        '@hono/node-server': {
            version: string;
            dev: false;
        };
        '@scalar/hono-api-reference': {
            version: string;
            dev: false;
        };
        '@tus/file-store': {
            version: string;
            dev: false;
        };
        '@tus/server': {
            version: string;
            dev: false;
        };
    };
    files: {
        'src/core/validation.ts': string;
        'src/app.ts': string;
        'src/extensions/hono/tus.ts': string;
        'src/extensions/hono/helpers.ts': string;
        'src/extensions/hono/index.ts': string;
    };
    onFeature(contract: Contracts.FeatureContract, { fs }: {
        fs: import("@faslh/compiler/sdk/devkit").ProjectFS;
    }): {
        [x: string]: any[];
    };
};
export {};
