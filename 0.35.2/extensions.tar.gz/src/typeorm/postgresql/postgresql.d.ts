import { Database } from '../database';
export declare function postgresql(options?: {}): Database;
