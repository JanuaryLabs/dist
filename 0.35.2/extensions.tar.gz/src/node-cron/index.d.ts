import type { Extension } from '../extension';
export declare const nodeCron: Extension;
