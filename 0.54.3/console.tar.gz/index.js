// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
var colors = {
  green: (message) => `\x1B[32m${message}\x1B[0m`,
  blue: (message) => `\x1B[34m${message}\x1B[0m`,
  magenta: (message) => `\x1B[35m${message}\x1B[0m`
};
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 0.85,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
box.print = function(title, ...lines) {
  console.log(box(title, ...lines.map((it) => it.trimEnd())));
};
function network(port = process.env["PORT"]) {
  console.log(
    box(
      "Server",
      `\u2139 Localhost: http://localhost:${port}`,
      `\u2714 Network IP: http://${ip.address()}:${port}`
    )
  );
}
var pretty = {
  network,
  box,
  swagger: async (pattern, cwd = import.meta.dirname) => {
    const swaggerFiles = await glob(pattern, {
      cwd
    });
    const swaggerEndpoints = swaggerFiles.map((x) => x.split(".swagger.json").shift()).map((it) => `/${it}/swagger`);
    console.log(box("Swagger Docs", ...swaggerEndpoints));
  }
};
export {
  box,
  colors,
  pretty
};
