export declare function inventory(): string;
