// libs/inventory/src/lib/inventory.ts
function inventory() {
  return "inventory";
}
export {
  inventory
};
//# sourceMappingURL=index.js.map
