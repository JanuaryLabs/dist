#!/usr/bin/env node

// libs/remote/src/cli.ts
import { watch } from "chokidar";
import { Command, program } from "commander";
import { DockerfileParser } from "dockerfile-ast";
import glob from "fast-glob";
import { readFile } from "fs/promises";
import { join } from "path";
import { Subject, debounceTime, exhaustMap } from "rxjs";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag) {
  const header = (value, error) => typeof tag === "string" ? tag : tag(value, error);
  return tap({
    next(value) {
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}

// libs/remote/src/lib/proxy/docker.runner.ts
import tar from "tar";
import tarStream2 from "tar-stream";

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/lib/proxy/docker.runner.ts
function createTar(baseTag, files) {
  const dockerfile = getRunnerDockerfile(baseTag);
  const pack = tarStream2.pack();
  for (const { path, content } of files) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
function getRunnerDockerfile(imageName) {
  return `
FROM ${imageName} as deps

WORKDIR /app

# FROM node:lts as base
# WORKDIR /app
COPY ./package.json /app/package.json
COPY . /app/build/
# COPY --from=deps /app/node_modules /app/node_modules

# it'll make install dynamic dependencies faster
# COPY --from=deps /app/package-lock.json /app/package-lock.json

# RUN npm ci --omit=dev --no-audit --no-fund --prefer-offline

# CMD tail -f /dev/null

CMD [ "npm", "run", "start:prod" ]
`;
}

// libs/remote/src/cli.ts
var watcher = new Subject();
var setCommand = new Command("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in the format NAME=VALUE").action(async (secretsList, s) => {
  const options = program.opts();
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: options["apiKey"]
      }
    });
  }
});
var defaultCommand = new Command("connect").argument("[dockerfilePath]", "Path to the Dockerfile", "Dockerfile").action(async (dockerfileName) => {
  const options = program.opts();
  const files = await getFiles(dockerfileName);
  watch(
    files.map((it) => it.path),
    { cwd: process.cwd(), persistent: true }
  ).on("all", async (event, path) => {
    watcher.next(path);
  });
  watcher.pipe(
    debug("files"),
    debounceTime(500),
    exhaustMap(() => {
      const tar2 = createTar("node:lts", files);
      return fetch(`${serverizeUrl}/upload`, {
        method: "POST",
        duplex: "half",
        body: tar2,
        headers: {
          "Content-Type": "application/x-tar",
          Apikey: options["apiKey"]
        }
      });
    })
  ).subscribe();
});
var secretCommand = new Command("secrets").addCommand(setCommand);
var cli = program.name("Serverize").version("1.0.0").description("Serverize").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command").requiredOption("-k, --api-key <key>", "API key for authentication");
cli.usage("npx @january/remote Dockerfile").addCommand(defaultCommand, { isDefault: true }).addCommand(secretCommand).parse(process.argv);
async function getFiles(dockerfileName) {
  const dockerfile = await readFile(
    join(process.cwd(), dockerfileName),
    "utf-8"
  );
  const ast = DockerfileParser.parse(dockerfile);
  const copies = ast.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    const path = srcArg.getValue();
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const files = await glob(Array.from(paths), {
    cwd: process.cwd()
  });
  return [
    {
      path: dockerfileName,
      content: dockerfile
    },
    ...await Promise.all(
      files.map(async (file) => ({
        path: file,
        content: await readFile(join(process.cwd(), file), "utf-8")
      }))
    )
  ];
}
//# sourceMappingURL=cli.js.map
