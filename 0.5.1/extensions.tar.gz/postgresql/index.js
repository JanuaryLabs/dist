// libs/extensions/postgresql/src/index.ts
var PostgreSQLExtension = class {
  composeService() {
    return {
      database: {
        image: "postgres:16",
        ports: ["5432:5432"],
        volumes: ["postgres_data:/var/lib/postgresql/data"],
        networks: ["development"],
        environment: {
          POSTGRES_PASSWORD: "yourpassword",
          POSTGRES_USER: "youruser",
          POSTGRES_DB: "yourdatabase"
        }
      },
      pgadmin: {
        image: "dpage/pgadmin4",
        ports: ["8080:8080"],
        networks: ["development"],
        environment: {
          PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
          PGADMIN_DEFAULT_PASSWORD: "password"
        }
      }
    };
  }
  env() {
    return {
      CONNECTION_STRING: "postgresql://youruser:yourpassword@database:5432/yourdatabase"
    };
  }
};
export {
  PostgreSQLExtension
};
