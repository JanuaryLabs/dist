export * from './functions';
export * from './auth';
declare module '@january/declarative' {
    namespace trigger {
        function firestore(): void;
    }
}
