import type { Server } from '@tus/server';
import type { IncomingMessage } from 'http';
import type { TriggerDefinition, trigger } from '@january/declarative';
export declare const honotriggers: {
    http<M>(config: trigger.HttpTriggerConfig<M>): TriggerDefinition<[trigger.HttpTrigger<M>, IncomingMessage]>;
    sse(config: {
        path: string;
        policies?: string[];
    }): TriggerDefinition<[{
        trigger: trigger.HttpTriggerPayload;
    }, IncomingMessage]>;
    websocket(config: {
        topic: string;
        policies?: string[];
    }): TriggerDefinition<[trigger.SSETrigger, IncomingMessage]>;
    stream<M>(config: trigger.HttpTriggerConfig<M>): TriggerDefinition<[{
        trigger: trigger.HttpTriggerPayload;
        input: trigger.Input<M>;
    }, IncomingMessage]>;
    tus(config: Omit<ConstructorParameters<typeof Server>[0], "allowedCredentials" | "allowedHeaders" | "allowedMethods" | "allowedOrigins" | "respectForwardedHeaders" | "relativeLocation"> & {
        policies?: string[];
    }): TriggerDefinition<[{
        id: string;
        mimeType: string;
        size: string;
    }, IncomingMessage]>;
    file(config: {
        path: string;
        root?: string;
        rewrite?: (path: string) => string;
        policies?: string[];
    }): TriggerDefinition<[string]>;
};
