import type { OpenAPIObject, ReferenceObject, SchemaObject } from 'openapi3-ts/oas31';
export declare function followRef(spec: OpenAPIObject, ref: string): SchemaObject | ReferenceObject;
type OnRefCallback = (ref: string, zod: string) => void;
/**
 * Convert an OpenAPI (JSON Schema style) object into a Zod schema string,
 * adapted for OpenAPI 3.1 (fully aligned with JSON Schema 2020-12).
 */
export declare function jsonSchemaToZod(spec: OpenAPIObject, schema: SchemaObject | ReferenceObject, required: boolean | undefined, onRef: OnRefCallback): string;
export {};
