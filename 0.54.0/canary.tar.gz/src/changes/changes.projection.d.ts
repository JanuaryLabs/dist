import type { ParameterDeclarationStructure } from 'ts-morph';
import type { Checker } from '@january/parser';
export interface WorkflowVM {
    displayName: string;
    featureName: string;
    description?: string;
    trigger: IWorkflowTriggerVM;
    tag: string;
    code: string;
    structures: any;
    params: ParameterDeclarationStructure[];
    imports: Checker.Import[];
}
export interface IWorkflowTriggerVM {
    metadata: Record<string, any>;
    sourceId: string;
    details: Record<string, any>;
}
export interface PolicyVM {
    displayName: string;
    rule: string;
    imports: Checker.Import[];
}
export interface ExtensionVM {
    id: string;
    name: string;
    main?: string;
    details: Record<string, any>;
}
export interface FeatureVM {
    displayName: string;
}
export interface Changes {
    features: FeatureVM[];
    workflows: WorkflowVM[];
}
