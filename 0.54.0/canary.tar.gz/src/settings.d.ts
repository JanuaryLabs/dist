import type { Workflow } from '@faslh/compiler/contracts';
export declare function createWorkflowSchema(workflow: Workflow): Record<string, any>;
