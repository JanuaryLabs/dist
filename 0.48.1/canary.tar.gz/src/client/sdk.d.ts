import type { Checker } from '@january/parser';
export interface SecurityScheme {
    bearerAuth: {
        type: 'http';
        scheme: 'bearer';
        bearerFormat: 'JWT';
    };
}
export interface SdkConfig {
    /**
     * The name of the sdk client
     * @default 'Client'
     */
    name?: string;
    output?: string;
    options?: Record<string, any>;
    securityScheme?: SecurityScheme;
}
export interface Spec {
    features: FeatureSpec[];
    name?: string;
    options?: Record<string, {
        in: 'header';
        schema: string;
    }>;
    securityScheme?: SecurityScheme;
}
export interface FeatureSpec {
    featureName: string;
    workflows: {
        name: string;
        type: string;
        tag: string;
        schemaName: string;
        imports: Checker.ProjectImport[];
        trigger: Record<string, any>;
        inputs: Record<string, {
            source: string;
            schema: string;
        }>;
    }[];
}
export declare function generateClientSdk(spec: Spec): {
    'index.ts': string;
    'sdk.ts': string;
    'validator.ts': string;
    'client.ts': string;
    'request.ts': string;
    'schemas.ts': string;
    'endpoints.ts': string;
};
