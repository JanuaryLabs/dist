import type { Contracts } from '@faslh/compiler/contracts';
export interface WorkspaceSettings {
    runtime: string;
    /**
     * If true, the generated code will be formatted using prettier
     */
    formatGeneratedCode?: boolean;
    fs: {
        features: string;
        cwd: string;
        output: string;
        /**
         * The directory where the output files will be generated relative to the cwd
         */
        extensions: string;
        startup: string;
        public: string;
    };
}
export declare function createWorkflowSchema(workflow: Contracts.Workflow): Record<string, any>;
