import { createRequire } from 'module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/parser/src/index.ts
import { readFileSync } from "fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
var checker, Checker;
var init_src = __esm({
  "libs/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
    })(Checker || (Checker = {}));
  }
});

// libs/canary/src/index.ts
import { existsSync as existsSync3 } from "fs";
import { cp, lstat, readFile as readFile3, readdir as readdir3, writeFile as writeFile2 } from "fs/promises";
import { merge } from "lodash-es";
import { basename as basename2, extname as extname2, join as join6, relative as relative3 } from "path";
import { Piscina } from "piscina";
import * as morph from "ts-morph";

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}

// libs/compiler/contracts/src/contract.ts
var Contracts;
((Contracts2) => {
  function fffffff(input) {
    const [namespace, value] = input.split(":");
    return {
      namespace,
      value
    };
  }
})(Contracts || (Contracts = {}));
function nonStatic(inputs) {
  return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
function standaloneInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique2 = uniquify(
    Object.entries(inputs).filter(
      ([name, prop]) => prop.data?.["standalone"] && predicate([name, prop])
    ),
    ([name, prop]) => paramName([name, prop])
  );
  return unique2.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
function nonStaticInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique2 = uniquify(
    nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])),
    ([name, prop]) => paramName([name, prop])
  );
  return unique2.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
function paramName([name, prop]) {
  return prop.data?.["parameterName"] || name;
}

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "23bfb249-0149-4033-a2a9-2dbec614d461",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "bytes",
    primitiveType: "Uint8Array",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      }
    },
    initialValidation: []
  },
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
function getValidationByName(name) {
  const validation2 = validations_default.find((a) => a.name === name);
  if (!validation2) {
    throw new Error(`Validation with name ${name} not found`);
  }
  return validation2;
}
function getSourceFieldByName(name) {
  const field2 = fields_default.find((it) => it.name === name);
  if (!field2) {
    throw new Error(`Field with name ${name} not found`);
  }
  return field2;
}
function assignDefaults(metadata, details) {
  Object.entries(metadata ?? {}).forEach(([name, config2]) => {
    if (details[name] === void 0 && config2.defaultValue !== void 0) {
      details[name] = config2.defaultValue;
    }
  });
  return details;
}

// libs/compiler/sdk/devkit/src/lib/project-config.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var _config;
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
ProjectConfig = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var config = {
  basePath: "./src",
  extensions: "./src/extensions",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join2("#{relative}", config.basePath, importPath);
  };
  makeEntityImportSpecifier = (tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  };
  makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join2(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join2(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join2(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeEntityPath = (featureName, tableName, suffix) => join2(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  );
  makeQueryPath = (tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectFS);
var commandsGlob = () => {
  return `${config.features}/**/*.command.ts`;
};
var routersGlob = () => {
  return "/**/*.router.ts";
};
var listenersGlob = () => {
  return "/**/*.github.ts";
};
var cronsGlob = () => {
  return "/**/*.cron.ts";
};
var entitiesGlob = () => {
  return "/**/*.entity.ts";
};
var makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
var makeIdentityPath = (fileName) => join2(config.extensions, "identity", fileName);
var makeCommandPath = (featureName, tagName, commandName) => makeFeatureFile(
  featureName,
  join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
);
var makeFeaturePath = (fileName) => join2(config.features, fileName);

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/bundler/src/virtual.ts
import esbuild from "esbuild";

// libs/bundler/src/bundler.ts
import esbuild2 from "esbuild";
import { nodeExternalsPlugin } from "esbuild-node-externals";
import { existsSync } from "fs";
import { readFile } from "fs/promises";
import { join as join3, relative } from "path";
async function bundle(options) {
  const tsconfig = JSON.parse(await readFile(options.tsconfigPath, "utf-8"));
  const paths = tsconfig.compilerOptions.paths;
  const packages = [];
  const jumps = ["/", ...relative(options.cwd, options.projectRoot).split("/")];
  while (jumps.length) {
    const path = join3(options.cwd, jumps.join("/"), "package.json");
    if (existsSync(path)) {
      packages.push(path);
    }
    jumps.pop();
  }
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    },
    plugins: [
      nodeExternalsPlugin({
        packagePath: packages,
        allowList: Object.keys(paths)
      })
    ],
    assetNames: "[name]",
    loader: {
      ".swagger.json": "file"
    }
  });
}

// libs/sdk/evaluator/src/lib/evaluate.ts
import { randomBytes } from "crypto";
import { get } from "lodash-es";

// libs/sdk/declarative/src/lib/feature.ts
function feature(nameOrConfig) {
  return {
    name: "",
    tables: nameOrConfig.tables,
    workflows: nameOrConfig.workflows,
    imports: [],
    policies: Object.entries(nameOrConfig.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config2 = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config2.message
    }
  };
}
var required = mandatory;
function unique(config2 = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config2.message
      }
    }
  ];
}
function defineValidation(config2) {
  return {
    name: config2.name,
    config: config2
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config2) {
  const additionalFields = {};
  const idField = Object.values(config2.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config2.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config2.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config2.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config2.fields,
      ...additionalFields
    },
    constraints: config2.constraints || []
  };
}
table.use = useTable;
function useTable(name) {
  return {
    command: "QueryTable",
    payload: {
      name
    }
  };
}
function field(config2) {
  const { type, validations = [], metadata = {}, ...rest } = config2;
  return {
    type: config2.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config2) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config2.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config2.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config2 = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config2;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config2) {
    return field2({
      type: "relation",
      metadata: config2,
      validations: config2.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
field.enum = (config2) => {
  return field({
    type: "single-select",
    metadata: {
      style: "enum",
      values: config2.values,
      defaultValue: config2.defaultValue
    }
  });
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(name, config2) {
  const execute = config2.trigger.refineExecute(config2.execute);
  return {
    name,
    trigger: config2.trigger,
    raw: !Object.keys(config2.trigger.inputs ?? {}).length,
    execute,
    tag: config2.tag
  };
}

// libs/sdk/evaluator/src/lib/evaluate.ts
init_src();
var defaultPrimitiveCallers = {
  table,
  feature,
  workflow,
  field: field.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  useTable,
  index
  // z: {
  //   object(...args: any[]) {
  //     logMe({ 'z.objectile': args });
  //     return args;
  //   },
  //   uuid() {
  //     return 'uuid';
  //   },
  //   int(...args: any[]) {
  //     logMe({ 'z.int': args });
  //     return 'int';
  //   },
  //   number(...args: any[]) {
  //     logMe({ 'z.number': args });
  //     return 'number';
  //   },
  //   string() {
  //     return 'string';
  //   },
  //   array(...args: any[]) {
  //     logMe({ 'z.array': args });
  //     return {
  //       type: 'array',
  //     };
  //   },
  // } as any,
  // z(...args: any[]) {
  //   logMe({ z: args });
  //   return args;
  // },
  // object(...args: any[]) {
  //   logMe({ 'z.object': args });
  //   return 'object';
  // },
  // uuid() {
  //   return 'uuid';
  // },
  // int() {
  //   return 'int';
  // },
  // number() {
  //   return 'string';
  // },
  // string() {
  //   return 'string';
  // },
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers, node, hooks = {}) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    let callerImpl = callers[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node.arguments.map((it) => staticEval(callers, it, hooks));
    if (typeof callerImpl === "function") {
      if (type.length) {
        args.unshift(type.join("."));
      }
      return callerImpl(...args);
    }
    callerImpl = get(callerImpl, type);
    if (!callerImpl) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => staticEval(callers, it, hooks));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      obj[key] = staticEval(callers, value, hooks);
    }
    return obj;
  }
  return node;
}
async function evaluate(code, callers) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    feature: staticEval(callers, ast.project),
    imports: ast.imports
  };
}

// libs/compiler/generator/src/index.ts
import {
  Project as Project4,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project as Project2, SyntaxKind, VariableDeclarationKind as VariableDeclarationKind2 } from "ts-morph";

// libs/compiler/generator/src/lib/sourcecode.ts
import { basename, dirname, extname, join as join4, relative as relative2, sep } from "path";
import { Injectable as Injectable3, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project3,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project3(options);
}
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join4(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative2(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
        case moduleSpecifier.startsWith("#{entity}"): {
          const entityName = moduleSpecifier.replace("#{entity}/", "");
          const files = __privateGet(this, _morphProject).getSourceFiles(
            join4(__privateGet(this, _outputDir), "/**/src/features/**/*.entity.ts")
          );
          const filePath = __privateMethod(this, _VirtualProject_instances, findClassSourceFile_fn).call(this, files, entityName);
          if (!filePath) {
            throw new Error(`Entity ${entityName} file not found.`);
          }
          moduleSpecifier = relative2(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(`${moduleSpecifier}.ts`);
          break;
        }
      }
    }
  }
};
findClassSourceFile_fn = function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
};
exportsDir_fn = function(dir) {
  const fullPath = join4(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  console.log(
    imports,
    __privateGet(this, _morphProject).getSourceFile(join4(fullPath, "index.ts"))
  );
  __privateGet(this, _morphProject).createSourceFile(
    join4(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportsCommands_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join4(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join4(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
};
exportRoutes_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join4(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join4(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { HonoEnv } from '@workspace/utils';import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono<HonoEnv>][]`,
    { overwrite: true }
  );
};
exportListeners_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join4(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join4(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportJobs_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join4(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join4(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportEntities_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join4(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join4(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities= [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
};
tuneImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      assertElements: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
    importDeclaration.getAssertClause()?.getElements().forEach((item) => {
      uniqueImports[moduleSpecifierValue].assertElements.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    const assertElements = Array.from(it.assertElements.values());
    file.addImportDeclaration({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements,
      defaultImport: it.defaultImport,
      isTypeOnly: false,
      namespaceImport: it.namespaceImport
    });
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    file.addImportDeclaration({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements: [],
      defaultImport: it.defaultImport,
      isTypeOnly: true
    });
  });
};
removeUnusedImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).some(
        (it) => it.getText() === importedName && it.getParent() !== namedImport
      );
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
};
moveImportsToTop_fn = function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index2) => {
    file.insertImportDeclaration(index2, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText(),
        isTypeOnly: namedImport.isTypeOnly()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
};
VirtualProject = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}
function emitFiles(concreteStructure, generateDir) {
  const vProject = new VirtualProject(generateDir);
  vProject.generate(concreteStructure);
  return {
    files: vProject.getOutput(),
    save: vProject.emit.bind(vProject),
    cleanup: () => vProject.cleanup()
  };
}

// libs/modern/src/index.ts
import { existsSync as existsSync2 } from "fs";
import { mkdir, readFile as readFile2, readdir as readdir2, writeFile } from "fs/promises";
import { dirname as dirname2, isAbsolute, join as join5 } from "path";
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
async function writeFiles(dir, contents, format = true) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join5(dir, file);
    await mkdir(dirname2(filePath), { recursive: true });
    const stringContent = typeof content === "string" ? content : JSON.stringify(content);
    await writeFile(
      filePath,
      format ? await formatCode(stringContent, getExt(file)) : stringContent,
      "utf-8"
    );
  }
}
function readFolder(path) {
  return existsSync2(path) ? readdir2(path) : [];
}
async function readJson(path) {
  const content = JSON.parse(await readFile2(path, "utf-8"));
  return {
    content,
    write: (value = content) => writeFile(path, JSON.stringify(value, null, 2), "utf-8")
  };
}
function getFile(filePath) {
  return existsSync2(filePath) ? readFile2(filePath, "utf-8") : Promise.resolve(null);
}

// libs/canary/src/changes/execute.ts
import pluralize from "pluralize";
import { StructureKind as StructureKind3 } from "ts-morph";
import { v4 as v42 } from "uuid";
async function toChanges(projectDefinition) {
  const tablesIds = {};
  const workflowIds = {};
  const fieldsIds = {};
  const pathsIds = {};
  const policiesIds = {};
  projectDefinition.features.forEach((feature2) => {
    Object.keys(feature2.tables).forEach((tableName) => {
      tablesIds[tableName] = v42();
      const table2 = feature2.tables[tableName];
      Object.keys(table2.fields).forEach((fieldName) => {
        fieldsIds[fieldName] = v42();
      });
    });
    Object.keys(feature2.policies ?? {}).forEach((policyName) => {
      policiesIds[policyName] = v42();
    });
    feature2.workflows.forEach((workflow2) => {
      workflowIds[workflow2.name] = v42();
    });
  });
  function getTableDef(tableName) {
    let tableDef;
    for (const { tables: tables2 } of projectDefinition.features) {
      const table2 = Object.entries(tables2).find(([it]) => it === tableName) ?? [];
      tableDef = table2[1];
      if (tableDef) {
        break;
      }
    }
    return tableDef;
  }
  function mapQueries(details) {
    if (typeof details === "string" || typeof details === "number" || typeof details === "boolean") {
      return details;
    }
    if (isRequest(details)) {
      return mapQuery(details);
    }
    if (isNullOrUndefined(details)) {
      return details;
    }
    if (Array.isArray(details)) {
      return details.map(mapQueries);
    }
    return Object.entries(details).reduce((acc, [key, value]) => {
      return {
        ...acc,
        [key]: mapQueries(value)
      };
    }, {});
  }
  function mapQuery(value) {
    if (isRequest(value)) {
      let result = void 0;
      switch (value.command) {
        case "QueryTable":
          result = tablesIds[value.payload.name];
          break;
        case "QueryWorkflow":
          result = workflowIds[value.payload.name];
          break;
        case "QueryFieldName":
          for (const feature2 of projectDefinition.features) {
            for (const table2 of Object.values(feature2.tables)) {
              if (table2.fields[value.payload.name]) {
                const field2 = table2.fields[value.payload.name];
                if (field2.type === "relation") {
                  result = camelcase(value.payload.name + " id");
                }
              }
            }
          }
          result ??= value.payload.name;
          break;
        case "QueryField":
          for (const feature2 of projectDefinition.features) {
            for (const table2 of Object.values(feature2.tables)) {
              if (table2.fields[value.payload.name]) {
                const field2 = table2.fields[value.payload.name];
                if (field2.type === "relation") {
                  result = fieldsIds[camelcase(value.payload.name + " id")];
                }
              }
            }
          }
          result ??= fieldsIds[value.payload.name];
          break;
        case "QueryPath":
          result = pathsIds[value.payload.name];
          break;
        default:
          throw new Error(`Unknown command ${value.command}`);
      }
      if (isNullOrUndefined(result)) {
        throw new Error(
          `Could not find ${value.command} ${value.payload.name}`
        );
      }
      return result;
    }
    return value;
  }
  const policies = [];
  const features = [];
  const tables = [];
  const workflows = [];
  for (const feature2 of projectDefinition.features) {
    features.push({
      displayName: feature2.name
    });
    for (const [policyName, policy] of Object.entries(feature2.policies ?? {})) {
      policies.push({
        id: policiesIds[policyName],
        rule: policy,
        displayName: policyName
      });
    }
    for (const [tableName, table2] of Object.entries(feature2.tables)) {
      tables.push({
        id: tablesIds[tableName],
        featureName: feature2.name,
        displayName: tableName,
        fields: [],
        indexes: table2.constraints.map(
          (constraint) => mapQueries(constraint.details)
        )
      });
    }
    for (const workflow2 of feature2.workflows) {
      const { structures, params, ...triggerConfig } = workflow2.trigger.config;
      workflows.push({
        id: workflowIds[workflow2.name],
        featureName: feature2.name,
        displayName: workflow2.name,
        output: {},
        tag: workflow2.tag,
        code: workflow2.execute.code,
        params: [
          ...workflow2.execute.params ?? [],
          ...params ?? []
        ],
        structures: [
          ...workflow2.execute.structures,
          ...structures ?? []
        ],
        imports: projectDefinition.imports.map(
          (imp) => ({
            kind: StructureKind3.ImportDeclaration,
            isTypeOnly: imp.isTypeOnly,
            moduleSpecifier: imp.moduleSpecifier,
            namedImports: imp.namedImports,
            defaultImport: imp.defaultImport,
            namespaceImport: imp.namespaceImport
          })
        ),
        trigger: {
          sourceId: workflow2.trigger.type,
          details: mapQueries({
            ...triggerConfig,
            raw: workflow2.raw,
            inputs: Object.assign(
              {},
              workflow2.trigger.inputs ?? {},
              workflow2.execute.inputs
            ),
            policies: workflow2.trigger.policies
          })
        }
      });
    }
  }
  for (const feature2 of projectDefinition.features) {
    for (const [tableName, table2] of Object.entries(feature2.tables)) {
      for (const [fieldName, field2] of Object.entries(table2.fields)) {
        const source = getSourceFieldByName(field2.type);
        const fieldValidation = [];
        for (const item of source.initialValidation) {
          const sourceValidation = getValidationByName(item.name);
          const details = Object.keys(item.details).reduce(
            (acc, key) => {
              const value = item.details[key];
              if (typeof value === "string" && value.startsWith("context.")) {
                const fieldMetadataProperty = value.replace("context.", "");
                return {
                  ...acc,
                  [key]: field2.details[fieldMetadataProperty]
                };
              }
              return {
                ...acc,
                [key]: value
              };
            },
            {}
          );
          fieldValidation.push({
            details,
            sourceId: sourceValidation.id,
            name: sourceValidation.name
          });
        }
        for (const validation2 of field2.validations.flat()) {
          const source2 = getValidationByName(validation2.name);
          fieldValidation.push({
            details: validation2.details,
            name: source2.name,
            sourceId: source2.id
          });
        }
        if (field2.type === "relation") {
          const references = field2.details["references"];
          const relatedEntity = references.payload.name;
          const relatedEntityDef = getTableDef(relatedEntity);
          if (!relatedEntityDef) {
            throw new Error(
              `Referenced entity '${relatedEntity}' in relation field '${fieldName}' not found`
            );
          }
          const table3 = tables.find((it) => it.displayName === tableName);
          const relatedTable = tables.find(
            (it) => it.displayName === relatedEntity
          );
          if (!table3) {
            throw new Error(`Table ${tableName} not found`);
          }
          if (!relatedTable) {
            throw new Error(
              `Referenced entity '${relatedEntity}' in relation field '${fieldName}' in table ${table3.displayName} not found`
            );
          }
          const [, referencedPrimaryField] = Object.entries(
            relatedEntityDef.fields
          ).find(
            ([fieldName2, field3]) => [
              "primary-key-uuid",
              "primary-key-number",
              "primary-key-custom"
            ].includes(field3.type)
          );
          const referencedPrimaryFieldSource = await getSourceFieldByName(
            referencedPrimaryField.type
          );
          const relationIdField = await getSourceFieldByName(
            referencedPrimaryFieldSource.references
          );
          const relationIdSourceField = await getSourceFieldByName("relation-id");
          const relationSourceField = await getSourceFieldByName("relation");
          switch (field2.details["relationship"]) {
            case "many-to-one":
              {
                {
                  table3.fields.push({
                    id: fieldsIds[fieldName],
                    displayName: fieldName,
                    tableId: tablesIds[tableName],
                    sourceId: source.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(source.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        nameOfColumnOnRelatedEntity: camelcase(
                          pluralize.plural(tableName)
                        ),
                        relatedEntityName: relatedEntity
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = camelcase(
                    `${pluralize.singular(fieldName)} Id`
                  );
                  fieldsIds[relationIdFieldName] ??= v42();
                  table3.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[tableName],
                    sourceId: relationIdField.id,
                    details: assignDefaults(relationIdField.metadata, {
                      length: null
                    }),
                    validations: uniquify(fieldValidation, (item) => item.name)
                  });
                }
                {
                  const relatedEntity2 = references.payload.name;
                  const fieldNameOnTheOtherTable = camelcase(
                    pluralize.plural(tableName)
                  );
                  fieldsIds[fieldNameOnTheOtherTable] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[fieldNameOnTheOtherTable],
                    displayName: fieldNameOnTheOtherTable,
                    tableId: tablesIds[relatedEntity2],
                    sourceId: relationSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationSourceField.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        ignoreIfExist: true,
                        joinSide: false,
                        nameOfColumnOnRelatedEntity: camelcase(fieldName),
                        relationship: "one-to-many",
                        references: tablesIds[tableName],
                        // FIXME: relation field have TableName stored in them
                        relatedEntityName: tableName
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = `${camelcase(
                    pluralize.plural(tableName)
                  )}Ids`;
                  fieldsIds[relationIdFieldName] ??= v42();
                  relatedTable.fields.push({
                    validations: uniquify(fieldValidation, (item) => item.name),
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[relatedEntity],
                    sourceId: relationIdSourceField.id,
                    details: assignDefaults(relationIdSourceField.metadata, {
                      ignoreIfExist: true,
                      virtualRelationField: true,
                      tableName: relatedEntity,
                      columnNameOnSelfTable: pluralize.plural(
                        camelcase(tableName)
                      ),
                      relationship: "one-to-many",
                      references: tablesIds[relatedEntity]
                    })
                  });
                }
              }
              break;
            case "one-to-one":
              {
                {
                  table3.fields.push({
                    id: fieldsIds[fieldName],
                    displayName: fieldName,
                    tableId: tablesIds[tableName],
                    validations: uniquify(fieldValidation, (item) => item.name),
                    sourceId: source.id,
                    details: assignDefaults(source.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        nameOfColumnOnRelatedEntity: camelcase(
                          pluralize.singular(tableName)
                        ),
                        relatedEntityName: relatedEntity
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = camelcase(
                    `${pluralize.singular(fieldName)} Id`
                  );
                  fieldsIds[relationIdFieldName] ??= v42();
                  table3.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[tableName],
                    sourceId: relationIdField.id,
                    details: assignDefaults(relationIdField.metadata, {
                      length: null
                    }),
                    validations: uniquify(fieldValidation, (item) => item.name)
                  });
                }
                {
                  const relatedEntity2 = references.payload.name;
                  const fieldNameOnTheOtherTable = camelcase(
                    pluralize.singular(tableName)
                  );
                  fieldsIds[fieldNameOnTheOtherTable] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[fieldNameOnTheOtherTable],
                    displayName: fieldNameOnTheOtherTable,
                    tableId: tablesIds[relatedEntity2],
                    sourceId: relationSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationSourceField.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        joinSide: false,
                        nameOfColumnOnRelatedEntity: camelcase(fieldName),
                        relationship: field2.details["relationship"],
                        relatedEntityName: tableName,
                        references: tablesIds[tableName]
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = `${camelcase(
                    pluralize.singular(tableName)
                  )}Id`;
                  fieldsIds[relationIdFieldName] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[relatedEntity],
                    sourceId: relationIdSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationIdSourceField.metadata, {
                      virtualRelationField: true,
                      tableName: relatedEntity,
                      columnNameOnSelfTable: pluralize.singular(
                        camelcase(tableName)
                      ),
                      relationship: "one-to-one",
                      references: tablesIds[relatedEntity]
                    })
                  });
                }
              }
              break;
            default:
              throw new Error(
                `Unimplemented relationship ${field2.details["relationship"]}`
              );
          }
        } else {
          const table3 = tables.find((it) => it.displayName === tableName);
          if (!table3) {
            throw new Error(`Table ${tableName} not found`);
          }
          table3.fields.push({
            id: fieldsIds[fieldName],
            displayName: fieldName,
            validations: uniquify(fieldValidation, (item) => item.name),
            tableId: tablesIds[tableName],
            sourceId: source.id,
            details: mapQueries(field2.details)
          });
        }
      }
    }
  }
  return {
    policies,
    features,
    imports: projectDefinition.imports.map((imp) => imp.moduleSpecifier),
    tables,
    workflows
  };
}
function isRequest(request) {
  if (isNullOrUndefined(request)) {
    return false;
  }
  if (Array.isArray(request)) {
    return false;
  }
  if (typeof request !== "object") {
    return false;
  }
  return "command" in request;
}

// libs/canary/src/settings.ts
function createWorkflowSchema(workflow2) {
  return Object.entries(workflow2.inputs).filter(([key, prop]) => !prop.data?.["standalone"]).reduce(
    (acc, [key, prop]) => ({
      ...acc,
      [key]: {
        schema: prop.data?.["zod"] || "z.any()",
        source: prop.data?.["source"]
      }
    }),
    {}
  );
}

// libs/canary/src/index.ts
var piscina;
var coreExt = {
  files: {},
  packages: {
    "rfc-7807-problem-details": {
      version: "^1.1.0",
      dev: false
    },
    ajv: {
      version: "8.12.0",
      dev: false
    },
    "ajv-formats": {
      version: "2.1.1",
      dev: false
    },
    "ajv-errors": {
      version: "3.0.0",
      dev: false
    },
    "ajv-keywords": {
      version: "5.1.0",
      dev: false
    },
    validator: {
      version: "13.9.0",
      dev: false
    },
    "lodash-es": {
      version: "^4.17.21",
      dev: false
    },
    "@types/lodash-es": {
      version: "^4.17.12",
      dev: true
    },
    "http-status-codes": {
      version: "2.2.0",
      dev: false
    },
    "@types/node": {
      version: "^20.11.26",
      dev: true
    },
    typescript: {
      version: "^5.7.0",
      dev: true
    },
    "@types/validator": {
      version: "13.7.17",
      dev: true
    },
    prettier: {
      version: "^3.3.3",
      dev: true
    },
    zod: {
      version: "^3.23.8",
      dev: false
    },
    "@january/console": {
      version: "https://github.com/JanuaryLabs/dist/raw/main/console.tar.gz"
    }
  }
};
async function getUserFiles(settings) {
  const thirdPartyExtsDir = join6(settings.fs.output, "src", "extensions");
  const packageJson = await getFile(join6(settings.fs.cwd, "package.json")) || '{"dependencies":{}}';
  return {
    userExts: await Promise.all(
      (await readFolder(settings.fs.extensions)).map(async (dir) => {
        const indexFile = (await readFolder(join6(settings.fs.extensions, dir))).find((it) => it.startsWith("index."));
        return {
          dir,
          index: indexFile
        };
      })
    ),
    thirdPartyExts: await readFolder(thirdPartyExtsDir),
    "package.json": JSON.parse(packageJson)
  };
}
async function defineConfig(config2) {
  const devDependencies = {};
  const dependencies = {};
  const scripts = {
    dev: "node --watch ./",
    start: "node ./"
    // 'migration:generate':
    //   './node_modules/.bin/typeorm migration:generate ./src/migrations/migrations --dataSource ./src/datasource -o --pretty --outputJs',
  };
  for (const { packages, scripts: packageScripts } of [
    coreExt,
    ...config2.extensions
  ]) {
    Object.assign(scripts, packageScripts ?? {});
    Object.entries(packages).forEach(([name, config3]) => {
      if (config3.dev) {
        devDependencies[name] = config3.version;
      } else {
        dependencies[name] = config3.version;
      }
    });
  }
  const cwd = config2.fs?.cwd ?? process.cwd();
  const settings = {
    fs: {
      features: join6(cwd, "src", "features"),
      output: config2.fs?.output ?? join6(cwd, "output"),
      extensions: join6(cwd, "src", "extensions"),
      cwd,
      startup: join6(cwd, "src", "startup.ts"),
      public: join6(cwd, "public")
    },
    runtime: "node",
    formatGeneratedCode: config2.formatGeneratedCode
  };
  const concreteStructure = await generate(settings, config2.extensions);
  await writeFiles(
    settings.fs.output,
    Object.assign({}, ...config2.extensions.map((it) => it.files)),
    false
  );
  const dir = join6(settings.fs.output, "src", "extensions", "identity");
  const files = await readdir3(dir);
  await writeFile2(
    join6(dir, "index.ts"),
    files.map((it) => `export * from './${it}';
`),
    "utf-8"
  );
  const userFiles = await getUserFiles(settings);
  const copyList = [
    [settings.fs.public, join6(settings.fs.output, "build", "public")],
    [settings.fs.startup, join6(settings.fs.output, "src")]
  ];
  for (const [src, dest] of copyList) {
    const stat = await lstat(src).catch(() => null);
    if (!stat) {
      continue;
    }
    if (stat.isFile()) {
      const fileName = basename2(src);
      const filePath = dest.endsWith(fileName) ? dest : join6(dest, fileName);
      await cp(src, filePath, { force: true });
    } else {
      await cp(src, dest, { force: true });
    }
  }
  for (const { dir: dir2, index: index2 } of userFiles.userExts) {
    if (!index2) {
      console.warn(`Missing index.ts file for extension ${dir2}`);
    }
  }
  const relativeCwd = relative3(process.cwd(), settings.fs.cwd);
  const relativeOutputDir = relative3(process.cwd(), settings.fs.output);
  const isRunningInOriginalCwd = relativeCwd === "";
  await writeFiles(
    settings.fs.output,
    {
      // TODO: run on eject only
      // await fetch(
      //   'https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore',
      // ).then((res) => res.text()),
      // '.gitignore': '',
      "package.json": toJson({
        version: "0.0.0",
        main: "./build/server.js",
        type: "module",
        private: true,
        scripts,
        dependencies: {
          ...dependencies,
          ...Object.fromEntries(
            Object.entries(userFiles["package.json"].dependencies).filter(
              ([name, version]) => !name.startsWith("@january/")
            )
          )
        },
        devDependencies
      }),
      "tsconfig.json": toJson({
        ...config2.baseTsConfig ? { extends: config2.baseTsConfig } : {},
        compilerOptions: {
          ...config2.baseTsConfig ? {} : { baseUrl: ".", rootDir: "." },
          jsx: "preserve",
          sourceMap: true,
          target: "ESNext",
          module: "esnext",
          moduleResolution: "node",
          declaration: false,
          outDir: "dist",
          types: ["node"],
          removeComments: true,
          strict: true,
          inlineSources: true,
          sourceRoot: "/",
          allowSyntheticDefaultImports: true,
          esModuleInterop: true,
          experimentalDecorators: true,
          emitDecoratorMetadata: true,
          importHelpers: true,
          noEmitHelpers: true,
          resolveJsonModule: true,
          skipLibCheck: true,
          skipDefaultLibCheck: true,
          lib: ["ESNext"],
          noEmit: true,
          allowImportingTsExtensions: true
        },
        include: ["src/**/*.ts"]
      })
    },
    false
  );
  const paths = {
    ...userFiles.thirdPartyExts.reduce(
      (acc, it) => ({
        ...acc,
        [`@extensions/${it}`]: [
          `${join6(relativeOutputDir, "src", "extensions", it)}/index.ts`
        ]
      }),
      {}
    ),
    ...userFiles.userExts.filter((it) => it.index).reduce(
      (acc, it) => ({
        ...acc,
        [`@extensions/${it.dir}`]: [
          `${join6(relativeCwd, isRunningInOriginalCwd ? "../" : "", "src", "extensions", it.dir, it.index)}`
        ]
      }),
      {}
    ),
    "@workspace/entities": [
      join6(relativeOutputDir, "src/features/entities.ts")
    ],
    "@workspace/identity": [
      join6(relativeOutputDir, "src/extensions/identity/index.ts")
    ],
    "@workspace/validation": [
      join6(relativeOutputDir, "src/core/validation.ts")
    ],
    "@workspace/utils": [join6(relativeOutputDir, "src/core/utils.ts")]
  };
  const tsconfig = await readJson(
    config2.tsconfigFilePaths || join6(settings.fs.output, "tsconfig.json")
  );
  Object.assign(tsconfig.content.compilerOptions.paths, paths);
  if (!config2.skipBundling) {
    await bundle({
      cwd: process.cwd(),
      tsconfigPath: config2.tsconfigFilePaths ?? join6(settings.fs.output, "tsconfig.json"),
      projectRoot: settings.fs.output,
      entry: join6(settings.fs.output, "src", "server.ts"),
      out: join6(settings.fs.output, "build", "server.js")
    });
  }
  if (config2.client) {
    piscina ??= new Piscina({
      filename: new URL("./client.js", import.meta.url).href,
      recordTiming: false
    });
    await piscina.run({
      settings,
      client: config2.client,
      features: concreteStructure.features
    });
  }
  return concreteStructure;
}
async function getChanges(settings, primitives) {
  const featurePaths = await readFolder(
    join6(settings.fs.cwd, "src", "features")
  );
  const features = await Promise.all(
    featurePaths.map(async (feature2) => {
      const featureText = await readFile3(
        join6(settings.fs.features, feature2),
        "utf-8"
      );
      const def = await evaluate(
        featureText,
        merge(...[...primitives, defaultPrimitiveCallers])
      );
      def.feature.name = basename2(feature2).replace(extname2(feature2), "");
      return def;
    })
  );
  const pd = {
    features: features.map((it) => it.feature),
    imports: features.map((it) => it.imports).flat(1)
  };
  const changes = await toChanges(pd);
  return {
    imports: changes.imports,
    policies: changes.policies.map((it) => ({
      filePath: makeIdentityPath(`${spinalcase2(it.displayName)}.policy.ts`),
      structure: [
        ...pd.imports.map((pi) => ({
          ...pi,
          kind: morph.StructureKind.ImportDeclaration
        })),
        it.rule
      ]
    })),
    features: await Promise.all(
      changes.features.reduce(
        (acc, curr) => [
          ...acc,
          {
            displayName: curr.displayName,
            workflows: changes.workflows.filter(
              (workflow2) => workflow2.featureName === curr.displayName
            ),
            tables: changes.tables.filter(
              (table2) => table2.featureName === curr.displayName
            )
          }
        ],
        []
      ).map(async (feature2) => {
        const tags = /* @__PURE__ */ new Set();
        const featureContract = {
          displayName: feature2.displayName,
          tags: [],
          tables: feature2.tables,
          workflows: await Promise.all(
            feature2.workflows.map(async (workflow2) => {
              const schemaName = camelcase(`${workflow2.displayName} schema`);
              const inputName = pascalcase(`${workflow2.displayName} input`);
              const inputs = workflow2.trigger.details["inputs"];
              const workflowContract = {
                inputName,
                inputs,
                displayName: workflow2.displayName,
                schemaName,
                featureName: feature2.displayName,
                tag: workflow2.tag,
                raw: workflow2.trigger.details["raw"],
                triggerInput: workflow2.trigger.details["triggerInput"],
                output: {
                  properties: [],
                  returnCode: ""
                },
                code: workflow2.code,
                structures: workflow2.structures,
                imports: workflow2.imports,
                params: workflow2.params,
                trigger: {
                  sourceId: workflow2.trigger.sourceId,
                  policies: workflow2.trigger["details"]["policies"],
                  tag: workflow2.tag,
                  // NOTE: it only has effect for http triggers. we might need it for github action to support multiple webhooks
                  details: workflow2.trigger.details,
                  inputName,
                  inputs,
                  displayName: workflow2.displayName,
                  featureName: feature2.displayName,
                  schemaName,
                  operationName: snakecase2(workflow2.displayName)
                }
              };
              tags.add(workflow2.tag);
              return workflowContract;
            })
          )
        };
        featureContract.tags = Array.from(tags);
        return featureContract;
      })
    )
  };
}
async function generate(settings, extensions = []) {
  if (existsSync3(settings.fs.extensions)) {
    await cp(
      settings.fs.extensions,
      join6(settings.fs.output, "src", "extensions"),
      { recursive: true }
    );
  }
  const concreteStructure = await getChanges(
    settings,
    extensions.map((it) => it.primitives ?? {})
  );
  const collector = {};
  concreteStructure.policies.forEach((it) => {
    collector[it.filePath] = it.structure;
  });
  const relativeCwd = relative3(process.cwd(), settings.fs.cwd);
  const extTypesPaths = [];
  const levelsToRoot = [...relativeCwd.split("/").map((_) => `..`), ".."].join(
    "/"
  );
  for (const ext of extensions) {
    if (ext.id) {
      extTypesPaths.push(
        `${levelsToRoot}/node_modules/@january/extensions/src/${ext.id}/index.d.ts`
      );
    }
    for (const feature2 of concreteStructure.features) {
      Object.assign(
        collector,
        ...feature2.workflows.map((it) => processWorkflow(it))
      );
      if (ext.onFeature) {
        Object.assign(
          collector,
          ext.onFeature(feature2, {
            fs: new ProjectFS()
          })
        );
      }
    }
  }
  await writeFiles(
    settings.fs.output,
    {
      "references.d.ts": extTypesPaths.map((it) => `/// <reference path="${it}" />`).join("\n")
    },
    settings.formatGeneratedCode
  );
  const { save, cleanup } = emitFiles(collector, settings.fs.output);
  if (settings.formatGeneratedCode) {
    await save(async (file) => {
      file.replaceWithText(
        await formatCode(file.getFullText(), getExt(file.getFilePath())).catch(
          () => {
            console.error(`Failed to format ${file.getFilePath()}`);
            return file.getFullText();
          }
        )
      );
    });
  } else {
    await save();
  }
  await cleanup();
  return concreteStructure;
}
function processWorkflow(contract) {
  const commandName = camelcase(contract.displayName);
  const workflowInputs = contract.inputs;
  const destructuredInputs = nonStaticInputs(contract.inputs).map(
    ([name]) => name
  );
  const workflowParams = standaloneInputs(workflowInputs).map(
    ([name, prop]) => ({
      name,
      type: prop.type
    })
  );
  const workflowInputsStructures = Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean);
  if (destructuredInputs.length) {
    workflowParams.unshift({
      name: `input`,
      type: `z.infer<typeof ${contract.schemaName}>,`
    });
  }
  workflowParams.push(
    ...(contract.params ?? []).map((it) => ({
      name: it.name,
      type: it.type
    }))
  );
  const zod = createWorkflowSchema(contract);
  const dto = Object.keys(zod).length ? [
    {
      kind: morph.StructureKind.ImportDeclaration,
      moduleSpecifier: "zod",
      defaultImport: "z"
    },
    `
export const ${contract.schemaName} = z.object(${toLitObject(zod, (x) => x.schema)})`
  ] : [];
  const workflowStructure = [
    ...contract.imports ?? [],
    ...workflowInputsStructures.flat(),
    ...dto,
    ...contract.structures,
    {
      kind: morph.StructureKind.Function,
      name: commandName,
      isAsync: true,
      isDefaultExport: false,
      isExported: true,
      parameters: workflowParams,
      statements: [contract.code]
    }
  ];
  return {
    // FIXME: file trigger doesn't need a command so we need not to add one
    [makeCommandPath(contract.featureName, contract.tag, contract.displayName)]: workflowStructure
  };
}
export {
  defineConfig,
  generate
};
//# sourceMappingURL=index.js.map
