var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/sdk/parser/src/index.ts
import { readFileSync } from "fs";
var checker;
((checker2) => {
  function isCallExpression(node, name) {
    if (!node) {
      return false;
    }
    const isCallExpr = node.type === "CallExpression";
    if (!isCallExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    if (node.callee.type === "MemberExpression") {
      return node.callee.property.type === "Identifier" && node.callee.property.value === name;
    }
    return node.callee.type === "Identifier" && node.callee.value === name;
  }
  checker2.isCallExpression = isCallExpression;
  __name(isCallExpression, "isCallExpression");
  function isObjectExpression(node) {
    return node.type === "ObjectExpression";
  }
  checker2.isObjectExpression = isObjectExpression;
  __name(isObjectExpression, "isObjectExpression");
  function isKeyValueProperty(node, valueType, keyName) {
    if (node.type !== "KeyValueProperty") {
      return false;
    }
    if (!valueType) {
      return true;
    }
    const sameType = node.value.type === valueType;
    if (!sameType) {
      return false;
    }
    if (!keyName) {
      return true;
    }
    return isIdentifier(node.key, keyName);
  }
  checker2.isKeyValueProperty = isKeyValueProperty;
  __name(isKeyValueProperty, "isKeyValueProperty");
  function isNullLiteral(node) {
    return node.type === "NullLiteral";
  }
  checker2.isNullLiteral = isNullLiteral;
  __name(isNullLiteral, "isNullLiteral");
  function isPrimitive(node) {
    if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
      return true;
    }
    return false;
  }
  checker2.isPrimitive = isPrimitive;
  __name(isPrimitive, "isPrimitive");
  function isIdentifier(node, name) {
    if (!node) {
      return false;
    }
    const isIdentifier2 = node.type === "Identifier";
    if (!isIdentifier2) {
      return false;
    }
    if (!name) {
      return true;
    }
    return node.value === name;
  }
  checker2.isIdentifier = isIdentifier;
  __name(isIdentifier, "isIdentifier");
  function isMemberExpression(node, name) {
    if (!node) {
      return false;
    }
    const isMemberExpr = node.type === "MemberExpression";
    if (!isMemberExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    return isIdentifier(node.property, name);
  }
  checker2.isMemberExpression = isMemberExpression;
  __name(isMemberExpression, "isMemberExpression");
  function isArrayExpression(node) {
    return node.type === "ArrayExpression";
  }
  checker2.isArrayExpression = isArrayExpression;
  __name(isArrayExpression, "isArrayExpression");
})(checker || (checker = {}));
var Checker;
((Checker2) => {
  function isPrimitive(value) {
    return value !== Object(value);
  }
  Checker2.isPrimitive = isPrimitive;
  __name(isPrimitive, "isPrimitive");
  function isCallExpression(value) {
    return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
  }
  Checker2.isCallExpression = isCallExpression;
  __name(isCallExpression, "isCallExpression");
  function isObjectExpression(value) {
    return !isCallExpression(value) && value !== null && typeof value === "object";
  }
  Checker2.isObjectExpression = isObjectExpression;
  __name(isObjectExpression, "isObjectExpression");
  function isArrayExpression(value) {
    return Array.isArray(value);
  }
  Checker2.isArrayExpression = isArrayExpression;
  __name(isArrayExpression, "isArrayExpression");
})(Checker || (Checker = {}));
var isWorker = /* @__PURE__ */ __name(() => {
  return typeof global.importScripts === "function";
}, "isWorker");
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
__name(isRecord, "isRecord");
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
__name(isSpan, "isSpan");
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
__name(adjustOffsetOfAst, "adjustOffsetOfAst");
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
__name(parseCode, "parseCode");
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
__name(legacy_parse, "legacy_parse");
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
__name(parse, "parse");
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
__name(getImports, "getImports");
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
__name(resolveAsExpression, "resolveAsExpression");
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
__name(resolveCallExpression, "resolveCallExpression");
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
__name(resolveUnaryExpression, "resolveUnaryExpression");
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
__name(resolveArrayExpression, "resolveArrayExpression");
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
__name(resolveObjectExpression, "resolveObjectExpression");
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
__name(resolveMemberExpression, "resolveMemberExpression");
var exportTypes = [
  "ExportAllDeclaration",
  "ExportDeclaration",
  "ExportDefaultDeclaration",
  "ExportDefaultExpression",
  "ExportNamedDeclaration",
  "ImportDeclaration"
];
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
__name(isExportItem, "isExportItem");
async function getExports(code) {
  const ast = await parseCode(code);
  if (!ast) {
    return [];
  }
  return ast.body.filter(isExportItem);
}
__name(getExports, "getExports");
export {
  Checker,
  checker,
  getExports,
  legacy_parse,
  parse,
  parseCode,
  resolveCallExpression
};
