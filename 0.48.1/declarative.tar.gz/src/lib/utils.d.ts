export declare function getErrors(fn: () => void): unknown[];
export declare function coerceString(value?: string | boolean | number | null | string[]): string | number | boolean | null | undefined;
