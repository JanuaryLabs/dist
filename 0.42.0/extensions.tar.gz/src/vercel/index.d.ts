import type { Extension } from '../extension';
export declare const vercel: Extension;
