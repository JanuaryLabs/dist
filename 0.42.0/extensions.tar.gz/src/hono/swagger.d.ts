import * as openapi from 'openapi3-ts/oas31';
import type { Contracts } from '@faslh/compiler/contracts';
export declare function makeSwaggerSpec(contract: Contracts.FeatureContract): openapi.OpenAPIObject;
