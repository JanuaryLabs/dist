import type { CodeRunnerConfig } from '@faslh/isomorphic';
export declare function createRemoteContainer(containerName: string, imageTag: string, instructions?: {
    internalPort?: number;
    hostPort?: number;
    Healthcheck?: Record<string, any>;
}, env?: Record<string, string>): Promise<import("dockerode").Container>;
export declare function imagesExists(...tags: string[]): Promise<boolean>;
export declare function containerExists(containerId: string | {
    name: string;
}): Promise<boolean>;
export declare const needsNewRunnerImage: (config: CodeRunnerConfig) => Promise<boolean>;
