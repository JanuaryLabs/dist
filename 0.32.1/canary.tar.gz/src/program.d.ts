export declare const cli: import("commander").Command;
