import './setup';
import { type BundableFile } from '@january/generator/bundler';
export declare function generate(code: string, extensions: Record<string, any>, repoPath: string): Promise<BundableFile[]>;
