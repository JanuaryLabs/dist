var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/utils/src/lib/utils.ts
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        const canRetry = operation.retry(error);
        if (!canRetry) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config.accessor(item)]: config.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && !Array.isArray(obj) && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
function msToNs(ms) {
  return ms * 1e6;
}
__name(msToNs, "msToNs");
function nsToMs(nano) {
  return parseInt(typeof nano === "number" ? String(nano) : nano, 10) / 1e6;
}
__name(nsToMs, "nsToMs");
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input, sub) {
  const index = input.indexOf(sub);
  if (index === -1) {
    return input;
  }
  return input.slice(sub.length);
}
__name(substring, "substring");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/extensions/src/firebase/functions/index.ts
import yaml from "js-yaml";
var deployContent = /* @__PURE__ */ __name(() => {
  return yaml.dump(
    {
      name: "Deploy To Firebase Functions",
      on: {
        // push: {
        //   branches: ['main'],
        // },
        workflow_dispatch: {
          inputs: {
            correlationId: {
              description: '"Correlation Id"',
              required: true
            }
          }
        }
      },
      env: {
        FASLH_API_URL: "https://us-central1-january-9f554.cloudfunctions.net/ghevents"
        // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
      },
      jobs: {
        deploy_to_firebase_functions: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            {
              id: "cache",
              name: "Cache Or Restore Node Modules",
              uses: "actions/cache@v3",
              with: {
                path: "node_modules",
                key: "node-modules-${{ hashFiles('package-lock.json') }}"
              }
            },
            {
              id: "install_deps",
              name: "Install Deps",
              run: "npm install --no-audit --no-fund"
            },
            {
              id: "build",
              name: "Build",
              run: "npm run build:prod -- --entry ./src/firebase-functions.ts"
            },
            {
              id: "deploy",
              name: "Deploy to Firebase",
              uses: "w9jds/firebase-action@master",
              with: {
                args: "deploy --only functions --debug"
              },
              env: {
                GCP_SA_KEY: `\${{ secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY }}`,
                PROJECT_ID: `\${{ secrets.FIREBASE_FUNCTION_PROJECT_ID }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
}, "deployContent");
var functions = {
  id: "firebase/functions",
  packages: {
    "firebase-functions": {
      version: "^5.0.1",
      dev: false
    },
    "firebase-admin": {
      version: "^12.4.0",
      dev: false
    }
  },
  files: {
    "../.github/workflows/deploy.yml": deployContent(),
    "server.ts": `
		import * as functions from 'firebase-functions';
		import application from './app';
		exports.api = functions.https.onRequest(application.callback());
		exports.hello = functions.https.onRequest((req, res) => {
			res.json({ result: 'Hello from Firebase!' });
		});
		`,
    "../firebase.json": toJson({
      functions: [
        {
          ignore: ["**/node_modules/**", "**/src/**", "**/public/**"],
          codebase: "faslh",
          source: "dist",
          runtime: "nodejs16"
        }
      ]
    })
  }
};

// libs/extensions/src/firebase/auth/firebase-app-setup.txt
var firebase_app_setup_default = "import { cert, initializeApp } from 'firebase-admin/app';\nimport type { GoogleServiceAccount } from '../../core/service-account';\n\nconst serviceAccount: GoogleServiceAccount = JSON.parse(\n	Buffer.from(process.env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY, 'base64').toString(\n		'ascii'\n	)\n);\n\nexport const firebaseApp = initializeApp({\n	credential: cert({\n		clientEmail: serviceAccount.client_email,\n		privateKey: serviceAccount.private_key,\n		projectId: serviceAccount.project_id,\n	}),\n	projectId: serviceAccount.project_id,\n	serviceAccountId: serviceAccount.client_email,\n});\n";

// libs/extensions/src/firebase/auth/service-account-interface.txt
var service_account_interface_default = "export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n";

// libs/extensions/src/firebase/auth/subject.txt
var subject_default = "import { firebaseApp } from '@extensions/firebase-auth';\nimport { UnauthorizedException } from '@workspace/identity';\nimport {\n	AuthClientErrorCode,\n	DecodedIdToken,\n	FirebaseAuthError,\n	getAuth,\n} from 'firebase-admin/auth';\nimport { IResult } from 'ua-parser-js';\n\nexport interface ClientInfo {\n	ip?: string | null;\n	userAgent?: string | null;\n	userAgentData: IResult;\n}\n\nexport type IdentitySubject = {\n	claims: DecodedIdToken;\n};\n\nexport const auth = getAuth(firebaseApp);\n\nfunction isBearerToken(\n	token: string | null | undefined\n): token is `Bearer ${string}` {\n	if (!token || typeof token !== 'string') {\n		return false;\n	}\n\n	if (!token.startsWith('Bearer ')) {\n		return false;\n	}\n\n	return true;\n}\n\nexport async function verifyToken(\n	token: string | null | undefined\n): Promise<boolean> {\n	if (!isBearerToken(token)) {\n		throw new UnauthorizedException();\n	}\n\n	try {\n		await auth.verifyIdToken(token.replace('Bearer ', ''));\n		return true;\n	} catch (error) {\n		if (error instanceof FirebaseAuthError) {\n			if (error.hasCode(AuthClientErrorCode.ID_TOKEN_EXPIRED.code)) {\n				const exception = new UnauthorizedException();\n				exception.cause = error;\n				throw exception;\n			}\n		}\n\n		// TODO: log the error\n		const exception = new UnauthorizedException();\n		exception.cause = error;\n		throw exception;\n	}\n}\n\nexport async function loadSubject(\n	token: string | null | undefined\n): Promise<IdentitySubject | null> {\n	if (!isBearerToken(token)) {\n		return null;\n	}\n\n	try {\n		const claims = await auth.verifyIdToken(token.replace('Bearer ', ''));\n		return { claims };\n	} catch (error) {\n		return null;\n	}\n}\n";

// libs/extensions/src/firebase/auth/index.ts
function auth() {
  return {
    id: "firebase/auth",
    packages: {
      "firebase-admin": {
        version: "^12.4.0",
        dev: false
      },
      "ua-parser-js": {
        version: "^1.0.37",
        dev: false
      },
      "@types/ua-parser-js": {
        version: "^0.7.39",
        dev: true
      },
      "@types/request-ip": {
        version: "^0.0.41",
        dev: true
      },
      "request-ip": {
        version: "^3.3.0",
        dev: false
      }
    },
    files: {
      "src/core/service-account.ts": service_account_interface_default,
      "src/extensions/firebase-auth/firebase.ts": firebase_app_setup_default,
      "src/extensions/identity/subject.ts": subject_default,
      "src/extensions/firebase-auth/index.ts": `
    export * from './firebase';
import z from 'zod';
export const env = {
  FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: z.string()
}
`
    },
    primitives: {
      policy: {
        authenticated() {
          return (name) => `
    import { Context } from 'hono';
    import { verifyToken } from '@workspace/identity';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
        }
      }
    }
  };
}
__name(auth, "auth");
export {
  auth,
  functions
};
//# sourceMappingURL=index.js.map
