export declare namespace hono {
    namespace policy { }
}
