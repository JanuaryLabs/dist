// libs/opensdk/src/index.ts
import { get as get2, merge } from "lodash";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}

// libs/opensdk/src/json-zod.ts
import { get } from "lodash";
function cleanRef(ref) {
  return ref.replace(/^#\//, "");
}
function followRef(spec, ref) {
  const pathParts = cleanRef(ref).split("/");
  const entry = get(spec, pathParts);
  if (entry && "$ref" in entry) {
    return followRef(spec, entry.$ref);
  }
  return entry;
}
function jsonSchemaToZod(spec, schema, required = false, onRef) {
  if ("$ref" in schema) {
    const schemaName = cleanRef(schema.$ref).split("/").pop();
    onRef(
      schemaName,
      jsonSchemaToZod(spec, followRef(spec, schema.$ref), required, onRef)
    );
    return schemaName;
  }
  if (schema.allOf && Array.isArray(schema.allOf)) {
    const allOfSchemas = schema.allOf.map(
      (sub) => jsonSchemaToZod(spec, sub, true, onRef)
    );
    return `z.intersection(${allOfSchemas.join(", ")})`;
  }
  if (schema.anyOf && Array.isArray(schema.anyOf)) {
    const anyOfSchemas = schema.anyOf.map(
      (sub) => jsonSchemaToZod(spec, sub, false, onRef)
    );
    return `z.union([${anyOfSchemas.join(", ")}])${appendOptional(required)}`;
  }
  if (schema.oneOf && Array.isArray(schema.oneOf)) {
    const oneOfSchemas = schema.oneOf.map(
      (sub) => jsonSchemaToZod(spec, sub, false, onRef)
    );
    return `z.union([${oneOfSchemas.join(", ")}])${appendOptional(required)}`;
  }
  if (schema.enum && Array.isArray(schema.enum)) {
    const enumVals = schema.enum.map((val) => JSON.stringify(val)).join(", ");
    return `z.enum([${enumVals}])${appendOptional(required)}`;
  }
  const types = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (!types.length) {
    return `z.unknown()${appendOptional(required)}`;
  }
  if (types.length > 1) {
    const realTypes = types.filter((t) => t !== "null");
    if (realTypes.length === 1 && types.includes("null")) {
      const typeZod = basicTypeToZod(realTypes[0], schema, spec, false, onRef);
      return `${typeZod}.nullable()${appendOptional(required)}`;
    }
    const subSchemas = types.map(
      (t) => basicTypeToZod(t, schema, spec, false, onRef)
    );
    return `z.union([${subSchemas.join(", ")}])${appendOptional(required)}`;
  }
  return basicTypeToZod(types[0], schema, spec, required, onRef);
}
function basicTypeToZod(type, schema, spec, required = false, onRef) {
  switch (type) {
    case "string":
      return handleString(schema, required);
    case "number":
    case "integer":
      return handleNumber(schema, required);
    case "boolean":
      return `z.boolean()${appendDefault(schema.default)}${appendOptional(required)}`;
    case "object":
      return handleObject(schema, spec, required, onRef);
    case "array":
      return handleArray(schema, spec, required, onRef);
    case "null":
      return `z.null()${appendOptional(required)}`;
    default:
      return `z.unknown()${appendOptional(required)}`;
  }
}
function handleString(schema, required) {
  let base = "z.string()";
  switch (schema.format) {
    case "date-time":
    case "datetime":
      base = "z.coerce.date()";
      break;
    case "date":
      base = "z.coerce.date() /* or z.string() if you want raw date strings */";
      break;
    case "time":
      base = "z.string() /* optionally add .regex(...) for HH:MM:SS format */";
      break;
    case "email":
      base = "z.string().email()";
      break;
    case "uuid":
      base = "z.string().uuid()";
      break;
    case "url":
    case "uri":
      base = "z.string().url()";
      break;
    case "ipv4":
      base = 'z.string().ip({version: "v4"})';
      break;
    case "ipv6":
      base = 'z.string().ip({version: "v6"})';
      break;
    case "phone":
      base = "z.string() /* or add .regex(...) for phone formats */";
      break;
    case "byte":
    case "binary":
      base = "z.instanceof(Blob) /* consider base64 check if needed */";
      break;
    case "int64":
      base = "z.string() /* or z.bigint() if your app can handle it */";
      break;
    default:
      break;
  }
  return `${base}${appendDefault(schema.default)}${appendOptional(required)}`;
}
function handleNumber(schema, required) {
  let defaultValue = schema.default !== void 0 ? `.default(${schema.default})` : ``;
  let base = "z.number()";
  if (schema.format === "int64") {
    base = "z.bigint()";
    if (schema.default !== void 0) {
      defaultValue = `.default(BigInt(${schema.default}))`;
    }
  }
  if (schema.format === "int32") {
    base += ".int()";
  }
  if (typeof schema.exclusiveMinimum === "number") {
    base += `.gt(${schema.exclusiveMinimum})`;
  }
  if (typeof schema.exclusiveMaximum === "number") {
    base += `.lt(${schema.exclusiveMaximum})`;
  }
  if (typeof schema.minimum === "number") {
    base += schema.format === "int64" ? `.min(BigInt(${schema.minimum}))` : `.min(${schema.minimum})`;
  }
  if (typeof schema.maximum === "number") {
    base += schema.format === "int64" ? `.max(BigInt(${schema.maximum}))` : `.max(${schema.maximum})`;
  }
  if (typeof schema.multipleOf === "number") {
    base += `.refine((val) => Number.isInteger(val / ${schema.multipleOf}), "Must be a multiple of ${schema.multipleOf}")`;
  }
  return `${base}${defaultValue}${appendOptional(required)}`;
}
function handleObject(schema, spec, required = false, onRef) {
  const properties = schema.properties || {};
  const propEntries = Object.entries(properties).map(([key, propSchema]) => {
    const isRequired = (schema.required ?? []).includes(key);
    const zodPart = jsonSchemaToZod(spec, propSchema, isRequired, onRef);
    return `'${key}': ${zodPart}`;
  });
  let additionalProps = "";
  if (schema.additionalProperties) {
    if (typeof schema.additionalProperties === "object") {
      const addPropZod = jsonSchemaToZod(
        spec,
        schema.additionalProperties,
        true,
        onRef
      );
      additionalProps = `.catchall(${addPropZod})`;
    } else if (schema.additionalProperties === true) {
      additionalProps = `.catchall(z.unknown())`;
    }
  }
  const objectSchema = `z.object({${propEntries.join(", ")}})${additionalProps}`;
  return `${objectSchema}${appendOptional(required)}`;
}
function handleArray(schema, spec, required = false, onRef) {
  const { items } = schema;
  if (!items) {
    return `z.array(z.unknown())${appendOptional(required)}`;
  }
  if (Array.isArray(items)) {
    const tupleItems = items.map(
      (sub) => jsonSchemaToZod(spec, sub, true, onRef)
    );
    const base = `z.tuple([${tupleItems.join(", ")}])`;
    return `${base}${appendOptional(required)}`;
  }
  const itemsSchema = jsonSchemaToZod(spec, items, true, onRef);
  return `z.array(${itemsSchema})${appendOptional(required)}`;
}
function appendOptional(isRequired) {
  return isRequired ? "" : ".optional()";
}
function appendDefault(defaultValue) {
  return defaultValue !== void 0 ? `.default(${JSON.stringify(defaultValue)})` : "";
}

// libs/opensdk/src/client.txt
var client_default = "import { parse } from 'fast-content-type-parse';\n\nimport type { Endpoints } from './endpoints';\n\nexport interface RequestInterface<D extends object = object> {\n  /**\n   * Sends a request based on endpoint options\n   *\n   * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'\n   * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.\n   */\n  <R extends keyof Endpoints>(\n    route: R,\n    options?: Endpoints[R]['input'],\n  ): Promise<Endpoints[R]['output']>;\n}\n\nexport async function handleError(response: Response) {\n  try {\n    if (response.status >= 400 && response.status < 500) {\n      const body = (await response.json()) as Record<string, any>;\n      return {\n        status: response.status,\n        body: body,\n      };\n    }\n    return new Error(\n      `An error occurred while fetching the data. Status: ${response.status}`,\n    );\n  } catch (error) {\n    return error as any;\n  }\n}\n\nasync function handleChunkedResponse(response: Response, contentType: string) {\n  const { type } = parse(contentType);\n\n  switch (type) {\n    case 'application/json': {\n      let buffer = '';\n      const reader = response.body!.getReader();\n      const decoder = new TextDecoder();\n      while (true) {\n        const { value, done } = await reader.read();\n        if (done) break;\n        buffer += decoder.decode(value);\n      }\n      return JSON.parse(buffer);\n    }\n    case 'text/html':\n    case 'text/plain': {\n      let buffer = '';\n      const reader = response.body!.getReader();\n      const decoder = new TextDecoder();\n      while (true) {\n        const { value, done } = await reader.read();\n        if (done) break;\n        buffer += decoder.decode(value);\n      }\n      return buffer;\n    }\n    default:\n      return response.body;\n  }\n}\n\nexport async function parseResponse(response: Response) {\n  const contentType = response.headers.get('Content-Type');\n  if (!contentType) {\n    throw new Error('Content-Type header is missing');\n  }\n\n  if (response.status === 204) {\n    return null;\n  }\n  const isChunked = response.headers.get('Transfer-Encoding') === 'chunked';\n  if (isChunked) {\n    return response.body!;\n    // return handleChunkedResponse(response, contentType);\n  }\n\n  const { type } = parse(contentType);\n  switch (type) {\n    case 'application/json':\n      return response.json();\n    case 'text/plain':\n      return response.text();\n    case 'text/html':\n      return response.text();\n    case 'text/xml':\n    case 'application/xml':\n      return response.text();\n    case 'application/x-www-form-urlencoded':\n      const text = await response.text();\n      return Object.fromEntries(new URLSearchParams(text));\n    case 'multipart/form-data':\n      return response.formData();\n    default:\n      throw new Error(`Unsupported content type: ${contentType}`);\n  }\n}\n";

// libs/opensdk/src/parser.txt
var parser_default = "import { z } from 'zod';\n\nexport type ParseError<T extends z.ZodType<any, any, any>> = {\n  kind: 'parse';\n} & z.inferFlattenedErrors<T>;\n\nexport function parse<T extends z.ZodType>(\n  schema: T,\n  input: unknown,\n) {\n  const result = schema.safeParse(input);\n  if (!result.success) {\n    const errors = result.error.flatten((issue) => issue);\n    return [null, errors];\n  }\n  return [result.data as z.infer<T>, null];\n}\n";

// libs/opensdk/src/request.txt
var request_default = "type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';\ntype ContentType = 'xml' | 'json' | 'urlencoded' | 'multipart';\ntype Endpoint = `${ContentType} ${Method} ${string}` | `${Method} ${string}`;\n\nexport function createUrl(base: string, path: string, query: URLSearchParams) {\n  const url = new URL(path, base);\n  url.search = query.toString();\n  return url;\n}\nfunction template(\n  templateString: string,\n  templateVariables: Record<string, any>,\n): string {\n  const nargs = /{([0-9a-zA-Z_]+)}/g;\n  return templateString.replace(nargs, (match, key: string, index: number) => {\n    // Handle escaped double braces\n    if (\n      templateString[index - 1] === '{' &&\n      templateString[index + match.length] === '}'\n    ) {\n      return key;\n    }\n\n    const result = key in templateVariables ? templateVariables[key] : null;\n    return result === null || result === undefined ? '' : String(result);\n  });\n}\n\ninterface ToRequest {\n  <T extends Endpoint>(\n    endpoint: T,\n    input: Record<string, any>,\n    props: {\n      inputHeaders: string[];\n      inputQuery: string[];\n      inputBody: string[];\n      inputParams: string[];\n    },\n    defaults: {\n      baseUrl: string;\n      headers?: Record<string, string>;\n    },\n  ): Request;\n  urlencoded: <T extends Endpoint>(\n    endpoint: T,\n    input: Record<string, any>,\n    props: {\n      inputHeaders: string[];\n      inputQuery: string[];\n      inputBody: string[];\n      inputParams: string[];\n    },\n    defaults: {\n      baseUrl: string;\n      headers?: Record<string, string>;\n    },\n  ) => Request;\n}\n\nfunction _json(\n  input: Record<string, any>,\n  props: {\n    inputHeaders: string[];\n    inputQuery: string[];\n    inputBody: string[];\n    inputParams: string[];\n  },\n) {\n  const headers = new Headers({});\n  for (const header of props.inputHeaders) {\n    headers.set(header, input[header]);\n  }\n\n  const body: Record<string, any> = {};\n  for (const prop of props.inputBody) {\n    body[prop] = input[prop];\n  }\n\n  const query = new URLSearchParams();\n  for (const key of props.inputQuery) {\n    const value = input[key];\n    if (value !== undefined) {\n      query.set(key, String(value));\n    }\n  }\n\n  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {\n    acc[key] = input[key];\n    return acc;\n  }, {});\n\n  return {\n    body: JSON.stringify(body),\n    query,\n    params,\n    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },\n  };\n}\n\ntype Input = Record<string, any>;\ntype Props = {\n  inputHeaders: string[];\n  inputQuery: string[];\n  inputBody: string[];\n  inputParams: string[];\n};\n\nabstract class Serializer {\n  constructor(\n    protected input: Input,\n    protected props: Props,\n  ) {}\n  abstract getBody(): BodyInit | null;\n  abstract getHeaders(): Record<string, string>;\n  serialize(): Serialized {\n    const headers = new Headers({});\n    for (const header of this.props.inputHeaders) {\n      headers.set(header, this.input[header]);\n    }\n\n    const query = new URLSearchParams();\n    for (const key of this.props.inputQuery) {\n      const value = this.input[key];\n      if (value !== undefined) {\n        query.set(key, String(value));\n      }\n    }\n\n    const params = this.props.inputParams.reduce<Record<string, any>>(\n      (acc, key) => {\n        acc[key] = this.input[key];\n        return acc;\n      },\n      {},\n    );\n\n    return {\n      body: this.getBody(),\n      query,\n      params,\n      headers: this.getHeaders(),\n    };\n  }\n}\n\ninterface Serialized {\n  body: BodyInit | null;\n  query: URLSearchParams;\n  params: Record<string, any>;\n  headers: Record<string, string>;\n}\n\nclass JsonSerializer extends Serializer {\n  getBody(): BodyInit | null {\n    const body: Record<string, any> = {};\n    for (const prop of this.props.inputBody) {\n      body[prop] = this.input[prop];\n    }\n    return JSON.stringify(body);\n  }\n  getHeaders(): Record<string, string> {\n    return {\n      'Content-Type': 'application/json',\n      Accept: 'application/json',\n    };\n  }\n}\n\nclass UrlencodedSerializer extends Serializer {\n  getBody(): BodyInit | null {\n    const body = new URLSearchParams();\n    for (const prop of this.props.inputBody) {\n      body.set(prop, this.input[prop]);\n    }\n    return body;\n  }\n  getHeaders(): Record<string, string> {\n    return {};\n  }\n}\n\nclass FormDataSerializer extends Serializer {\n  getBody(): BodyInit | null {\n    const body = new FormData();\n    for (const prop of this.props.inputBody) {\n      body.append(prop, this.input[prop]);\n    }\n    return body;\n  }\n  getHeaders(): Record<string, string> {\n    return {};\n  }\n}\n\nexport function json(input: Input, props: Props) {\n  return new JsonSerializer(input, props).serialize();\n}\nexport function urlencoded(input: Input, props: Props) {\n  return new UrlencodedSerializer(input, props).serialize();\n}\nexport function formdata(input: Input, props: Props) {\n  return new FormDataSerializer(input, props).serialize();\n}\n\nexport function _urlencoded(\n  input: Record<string, any>,\n  props: {\n    inputHeaders: string[];\n    inputQuery: string[];\n    inputBody: string[];\n    inputParams: string[];\n  },\n) {\n  const headers = new Headers({});\n  for (const header of props.inputHeaders) {\n    headers.set(header, input[header]);\n  }\n\n  const body = new URLSearchParams();\n  for (const prop of props.inputBody) {\n    body.set(prop, input[prop]);\n  }\n\n  const query = new URLSearchParams();\n  for (const key of props.inputQuery) {\n    const value = input[key];\n    if (value !== undefined) {\n      query.set(key, String(value));\n    }\n  }\n\n  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {\n    acc[key] = input[key];\n    return acc;\n  }, {});\n\n  return {\n    body,\n    query,\n    params,\n    headers: {},\n  };\n}\n\nexport function toRequest<T extends Endpoint>(\n  endpoint: T,\n  input: Serialized,\n  defaults: {\n    baseUrl: string;\n    headers?: Record<string, string>;\n  },\n): Request {\n  const [method, path] = endpoint.split(' ');\n\n  const headers = new Headers({\n    ...defaults?.headers,\n    ...input.headers,\n  });\n  const pathVariable = template(path, input.params);\n\n  const url = createUrl(defaults.baseUrl, pathVariable, input.query);\n  return new Request(url, {\n    method: method,\n    headers: headers,\n    body: method === 'GET' ? undefined : input.body,\n  });\n}\n";

// libs/opensdk/src/response.txt
var response_default = "export interface ApiResponse<Status extends number, Body extends unknown> {\n  kind: 'response';\n  status: Status;\n  body: Body;\n}\n\n// 4xx Client Errors\nexport type BadRequest = ApiResponse<400, { message: string }>;\nexport type Unauthorized = ApiResponse<401, { message: string }>;\nexport type PaymentRequired = ApiResponse<402, { message: string }>;\nexport type Forbidden = ApiResponse<403, { message: string }>;\nexport type NotFound = ApiResponse<404, { message: string }>;\nexport type MethodNotAllowed = ApiResponse<405, { message: string }>;\nexport type NotAcceptable = ApiResponse<406, { message: string }>;\nexport type Conflict = ApiResponse<409, { message: string }>;\nexport type Gone = ApiResponse<410, { message: string }>;\nexport type UnprocessableEntity = ApiResponse<422, { message: string; errors?: Record<string, string[]> }>;\nexport type TooManyRequests = ApiResponse<429, { message: string; retryAfter?: string }>;\nexport type PayloadTooLarge = ApiResponse<413, { message: string; }>;\nexport type UnsupportedMediaType = ApiResponse<415, { message: string; }>;\n\n// 5xx Server Errors\nexport type InternalServerError = ApiResponse<500, { message: string }>;\nexport type NotImplemented = ApiResponse<501, { message: string }>;\nexport type BadGateway = ApiResponse<502, { message: string }>;\nexport type ServiceUnavailable = ApiResponse<503, { message: string; retryAfter?: string }>;\nexport type GatewayTimeout = ApiResponse<504, { message: string }>;\n\nexport type ClientError =\n  | BadRequest\n  | Unauthorized\n  | PaymentRequired\n  | Forbidden\n  | NotFound\n  | MethodNotAllowed\n  | NotAcceptable\n  | Conflict\n  | Gone\n  | UnprocessableEntity\n  | TooManyRequests;\n\nexport type ServerError =\n  | InternalServerError\n  | NotImplemented\n  | BadGateway\n  | ServiceUnavailable\n  | GatewayTimeout;\n\nexport type ProblematicResponse = ClientError | ServerError;\n";

// libs/opensdk/src/sdk.ts
import { camelcase as camelcase2 } from "stringcase";

// libs/opensdk/src/backend.ts
var backend_default = (spec) => {
  const specOptions = {
    ...spec.options ?? {},
    fetch: {
      schema: "z.function().args(z.instanceof(Request)).returns(z.promise(z.instanceof(Response))).optional()"
    },
    baseUrl: { schema: "z.string().url()" }
  };
  if (spec.securityScheme) {
    specOptions["token"] = { schema: "z.string().optional()" };
  }
  const defaultHeaders = spec.securityScheme ? `{Authorization: \`${titlecase(spec.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}` : `{}`;
  return `

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { parse } from './parser';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${toLitObject(specOptions, (x) => x.schema)});
      type ${spec.name}Options = z.infer<typeof optionsSchema>;
    export class ${spec.name} {

      constructor(public options: ${spec.name}Options) {}

  async request<E extends keyof Endpoints>(
    endpoint: E,
    input: Endpoints[E]['input'],
  ): Promise<readonly [Endpoints[E]['output'], Endpoints[E]['error'] | null]> {
      const route = schemas[endpoint];
      const [parsedInput, parseError] = parse(route.schema, input);
      if (parseError) {
        return [
          null as never,
          { ...parseError, kind: 'parse' } as never,
        ] as const;
      }
      const request = route.toRequest(parsedInput as never, {
        headers: this.defaultHeaders,
        baseUrl: this.options.baseUrl,
      });
      const response = await (this.options.fetch ?? fetch)(request);
      if (response.ok) {
        const data = await parseResponse(response);
        return [data as Endpoints[E]['output'], null] as const;
      }
      const error = await handleError(response);
      return [null as never, { ...error, kind: 'response' }] as const;
  }

      get defaultHeaders() {
        return ${defaultHeaders}
      }

  setOptions(options: Partial<${spec.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${spec.name}Options)[]) {
      if (validated[key] !== undefined) {
        (this.options[key] as typeof validated[typeof key]) = validated[key]!;
      }
    }
  }
}`;
};

// libs/opensdk/src/sdk.ts
var SchemaEndpoint = class {
  #imports = [
    `import z from 'zod';`,
    'import type { Endpoints } from "./endpoints";',
    'import type { StreamEndpoints } from "./stream-endpoints";',
    `import { toRequest, json, urlencoded, formdata, createUrl } from './request';`,
    `import type { ParseError } from './parser';`
  ];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation},`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export default {
${this.#endpoints.join("\n")}
}`;
  }
};
var Emitter = class {
  imports = [
    `import z from 'zod';`,
    `import type { ParseError } from './parser';`
  ];
  endpoints = [];
  addEndpoint(endpoint, operation) {
    this.endpoints.push(`  "${endpoint}": ${operation};`);
  }
  addImport(value) {
    this.imports.push(value);
  }
  complete() {
    return `${this.imports.join("\n")}
export interface Endpoints {
${this.endpoints.join("\n")}
}`;
  }
};
var StreamEmitter = class extends Emitter {
  complete() {
    return `${this.imports.join("\n")}
export interface StreamEndpoints {
${this.endpoints.join("\n")}
}`;
  }
};
function generateClientSdk(spec) {
  const emitter = new Emitter();
  const streamEmitter = new StreamEmitter();
  const schemas = {};
  const schemasImports = [];
  const schemaEndpoint = new SchemaEndpoint();
  const errors = [];
  for (const [name, operations] of Object.entries(spec.groups)) {
    const featureSchemaFileName = camelcase2(name);
    schemas[featureSchemaFileName] = [`import z from 'zod';`];
    emitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    streamEmitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    schemaEndpoint.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    for (const operation of operations) {
      const schemaName = camelcase2(`${operation.name} schema`);
      const schema = `export const ${schemaName} = ${Object.keys(operation.schemas).length === 1 ? Object.values(operation.schemas)[0] : toLitObject(operation.schemas)};`;
      schemas[featureSchemaFileName].push(schema);
      schemasImports.push(
        ...operation.imports.map((it) => (it.namedImports ?? []).map((it2) => it2.name)).flat()
      );
      const schemaRef = `${featureSchemaFileName}.${schemaName}`;
      const output = operation.formatOutput();
      const inputHeaders = [];
      const inputQuery = [];
      const inputBody = [];
      const inputParams = [];
      for (const [name2, prop] of Object.entries(operation.inputs)) {
        if (prop.source === "headers" || prop.source === "header") {
          inputHeaders.push(`"${name2}"`);
        } else if (prop.source === "query") {
          inputQuery.push(`"${name2}"`);
        } else if (prop.source === "body") {
          inputBody.push(`"${name2}"`);
        } else if (prop.source === "path") {
          inputParams.push(`"${name2}"`);
        } else if (prop.source === "internal") {
          continue;
        } else {
          throw new Error(
            `Unknown source ${prop.source} in ${name2} ${JSON.stringify(
              prop
            )} in ${operation.name}`
          );
        }
      }
      if (operation.type === "sse") {
        const input = `z.infer<typeof ${schemaRef}>`;
        const endpoint = `${operation.trigger.method.toUpperCase()} ${operation.trigger.path}`;
        streamEmitter.addImport(
          `import type {${pascalcase(operation.name)}} from './outputs/${spinalcase2(operation.name)}';`
        );
        streamEmitter.addEndpoint(
          endpoint,
          `{input: ${input}, output: ${output.use}}`
        );
        schemaEndpoint.addEndpoint(
          endpoint,
          `{
        schema: ${schemaRef},
        toRequest(input: StreamEndpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${endpoint}';
            return toRequest(endpoint, json(input, {
            inputHeaders: [${inputHeaders}],
            inputQuery: [${inputQuery}],
            inputBody: [${inputBody}],
            inputParams: [${inputParams}],
          }), init);
          },
        }`
        );
      } else {
        emitter.addImport(
          `import type {${output.import}} from './outputs/${spinalcase2(operation.name)}';`
        );
        errors.push(...operation.errors ?? []);
        const addTypeParser = Object.keys(operation.schemas).length > 1;
        for (const type in operation.schemas ?? {}) {
          let typePrefix = "";
          if (addTypeParser && type !== "json") {
            typePrefix = `${type} `;
          }
          const input = `typeof ${schemaRef}${addTypeParser ? `.${type}` : ""}`;
          const endpoint = `${typePrefix}${operation.trigger.method.toUpperCase()} ${operation.trigger.path}`;
          emitter.addEndpoint(
            endpoint,
            `{input: z.infer<${input}>; output: ${output.use}; error: ${(operation.errors ?? ["ServerError"]).concat(`ParseError<${input}>`).join("|")}}`
          );
          schemaEndpoint.addEndpoint(
            endpoint,
            `{
          schema: ${schemaRef}${addTypeParser ? `.${type}` : ""},
          toRequest(input: Endpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
            const endpoint = '${endpoint}';
              return toRequest(endpoint, ${operation.contentType || "json"}(input, {
              inputHeaders: [${inputHeaders}],
              inputQuery: [${inputQuery}],
              inputBody: [${inputBody}],
              inputParams: [${inputParams}],
            }), init);
            },
          }`
          );
        }
      }
    }
  }
  emitter.addImport(
    `import type { ${removeDuplicates(errors, (it) => it).join(", ")} } from './response';`
  );
  return {
    ...Object.fromEntries(
      Object.entries(schemas).map(([key, value]) => [
        `inputs/${key}.ts`,
        [
          schemasImports.length ? `import {${removeDuplicates(schemasImports, (it) => it)}} from '../zod';` : "",
          ...value
        ].join("\n")
      ])
    ),
    "backend.ts": backend_default(spec),
    "parser.ts": parser_default,
    "client.ts": client_default,
    "request.ts": request_default,
    "schemas.ts": schemaEndpoint.complete(),
    "endpoints.ts": emitter.complete(),
    "stream-endpoints.ts": streamEmitter.complete(),
    "response.ts": response_default
  };
}

// libs/opensdk/src/index.ts
function isRef(obj) {
  return "$ref" in obj;
}
var responses = {
  "400": "BadRequest",
  "401": "Unauthorized",
  "402": "PaymentRequired",
  "403": "Forbidden",
  "404": "NotFound",
  "405": "MethodNotAllowed",
  "406": "NotAcceptable",
  "409": "Conflict",
  "413": "PayloadTooLarge",
  "410": "Gone",
  "422": "UnprocessableEntity",
  "429": "TooManyRequests",
  "500": "InternalServerError",
  "501": "NotImplemented",
  "502": "BadGateway",
  "503": "ServiceUnavailable",
  "504": "GatewayTimeout"
};
var defaults = {
  target: "javascript",
  style: "github",
  operationId: (operation, path, method) => {
    if (operation.operationId) {
      return operation.operationId;
    }
    return operation.operationId || camelcase(`${method} ${path.replace(/\//g, " ")}`);
  }
};
function generate(config) {
  const groups = {};
  const commonSchemas = {};
  const outputs = {};
  for (const [path, methods] of Object.entries(config.spec.paths ?? {})) {
    for (const [method, operation] of Object.entries(methods)) {
      const formatOperationId = config.operationId ?? defaults.operationId;
      const operationName = formatOperationId(operation, path, method);
      console.log(`Processing ${method} ${path}`);
      const groupName = (operation.tags ?? ["default"])[0];
      groups[groupName] ??= [];
      const inputs = {};
      const imports = [];
      const additionalProperties = [];
      for (const param of operation.parameters ?? []) {
        if (isRef(param)) {
          throw new Error(`Found reference in parameter ${param.$ref}`);
        }
        if (!param.schema) {
          throw new Error(`Schema not found for parameter ${param.name}`);
        }
        inputs[param.name] = {
          source: param.in,
          schema: ""
        };
        additionalProperties.push(param);
      }
      const types = {};
      const shortContenTypeMap = {
        "application/json": "json",
        "application/x-www-form-urlencoded": "urlencoded",
        "multipart/form-data": "formdata",
        "application/xml": "xml",
        "text/plain": "text"
      };
      let contentType;
      if (operation.requestBody && Object.keys(operation.requestBody).length) {
        const content = isRef(operation.requestBody) ? get2(followRef(config.spec, operation.requestBody.$ref), ["content"]) : operation.requestBody.content;
        for (const type in content) {
          const schema = isRef(content[type].schema) ? followRef(config.spec, content[type].schema.$ref) : content[type].schema;
          types[shortContenTypeMap[type]] = jsonSchemaToZod(
            config.spec,
            merge(schema, {
              required: additionalProperties.filter((p) => p.required).map((p) => p.name),
              properties: additionalProperties.reduce(
                (acc, p) => ({
                  ...acc,
                  [p.name]: p.schema
                }),
                {}
              )
            }),
            true,
            (schemaName, zod) => {
              commonSchemas[schemaName] = zod;
              imports.push({
                defaultImport: void 0,
                isTypeOnly: false,
                moduleSpecifier: "../zod",
                namedImports: [{ isTypeOnly: false, name: schemaName }],
                namespaceImport: void 0
              });
            }
          );
        }
        if (content["application/json"]) {
          contentType = "json";
        } else if (content["application/x-www-form-urlencoded"]) {
          contentType = "urlencoded";
        } else if (content["multipart/form-data"]) {
          contentType = "formdata";
        } else {
          contentType = "json";
        }
      } else {
        types[shortContenTypeMap["application/json"]] = jsonSchemaToZod(
          config.spec,
          {
            type: "object",
            required: additionalProperties.filter((p) => p.required).map((p) => p.name),
            properties: additionalProperties.reduce(
              (acc, p) => ({
                ...acc,
                [p.name]: p.schema
              }),
              {}
            )
          },
          true,
          (schemaName, zod) => {
            commonSchemas[schemaName] = zod;
            imports.push({
              defaultImport: void 0,
              isTypeOnly: false,
              moduleSpecifier: "./zod",
              namedImports: [{ isTypeOnly: false, name: schemaName }],
              namespaceImport: void 0
            });
          }
        );
      }
      const errors = [];
      operation.responses ??= {};
      let foundResponse = false;
      const output = [`import z from 'zod';`];
      for (const status in operation.responses) {
        const response = operation.responses[status];
        const statusCode = +status;
        if (statusCode >= 400) {
          errors.push(responses[status] ?? "ProblematicResponse");
        }
        if (statusCode >= 200 && statusCode < 300) {
          foundResponse = true;
          const responseContent = get2(response, ["content"]);
          const isJson = responseContent && responseContent["application/json"];
          const responseSchema = isJson ? jsonSchemaToZod(
            config.spec,
            responseContent["application/json"].schema,
            true,
            (schemaName, zod) => {
              commonSchemas[schemaName] = zod;
              imports.push({
                defaultImport: void 0,
                isTypeOnly: false,
                moduleSpecifier: "../zod",
                namedImports: [{ isTypeOnly: false, name: schemaName }],
                namespaceImport: void 0
              });
            }
          ) : "z.instanceof(ReadableStream)";
          output.push(
            importsToString(mergeImports(Object.values(imports).flat())).join(
              "\n"
            )
          );
          output.push(
            `export const ${pascalcase(operationName + " output")} = ${responseSchema}`
          );
        }
      }
      if (!foundResponse) {
        output.push(
          `export const ${pascalcase(operationName + " output")} = z.void()`
        );
      }
      outputs[`${operationName}.ts`] = output.join("\n");
      groups[groupName].push({
        name: operationName,
        type: "http",
        imports: mergeImports(Object.values(imports).flat()),
        inputs,
        errors: errors.length ? errors : ["ServerError"],
        contentType,
        schemas: types,
        formatOutput: () => ({
          import: pascalcase(operationName + " output"),
          use: `z.infer<typeof ${pascalcase(operationName + " output")}>`
        }),
        trigger: {
          path,
          method
        }
      });
    }
  }
  return { groups, commonSchemas, outputs };
}
function mergeImports(imports) {
  const merged = {};
  for (const i of imports) {
    merged[i.moduleSpecifier] = merged[i.moduleSpecifier] ?? {
      moduleSpecifier: i.moduleSpecifier,
      defaultImport: i.defaultImport,
      namespaceImport: i.namespaceImport,
      namedImports: []
    };
    if (i.namedImports) {
      merged[i.moduleSpecifier].namedImports.push(...i.namedImports);
    }
  }
  return Object.values(merged);
}
function importsToString(imports) {
  return imports.map((i) => {
    if (i.defaultImport) {
      return `import ${i.defaultImport} from '${i.moduleSpecifier}'`;
    }
    if (i.namespaceImport) {
      return `import * as ${i.namespaceImport} from '${i.moduleSpecifier}'`;
    }
    if (i.namedImports) {
      return `import {${removeDuplicates(i.namedImports, (it) => it.name).map((n) => n.name).join(", ")}} from '${i.moduleSpecifier}'`;
    }
    throw new Error(`Invalid import ${JSON.stringify(i)}`);
  });
}
export {
  defaults,
  generate,
  generateClientSdk
};
