import{get as M,merge as re}from"lodash";import{camelcase as Me,cramcase as Ve,dotcase as _e,pascalcase as $,sentencecase as He,snakecase as We,spinalcase as Ze,titlecase as N}from"stringcase";import{v4 as Ne}from"uuid";import oe from"retry";import{snakecase as pe,spinalcase as ce}from"stringcase";function O(e,t=r=>r){return`{${Object.keys(e).map(r=>`${r}: ${t(e[r])}`).join(", ")}}`}function P(e,t){return[...new Map(e.map(r=>[t(r),r])).values()]}var L={openapi:"3.0.0",info:{description:"This is a sample server Petstore server.  You can find out more about Swagger at [http://swagger.io](http://swagger.io) or on [irc.freenode.net, #swagger](http://swagger.io/irc/).  For this sample, you can use the api key `special-key` to test the authorization filters.",version:"1.0.0",title:"Swagger Petstore",termsOfService:"http://swagger.io/terms/",contact:{email:"apiteam@swagger.io"},license:{name:"Apache 2.0",url:"http://www.apache.org/licenses/LICENSE-2.0.html"}},externalDocs:{description:"Find out more about Swagger",url:"http://swagger.io"},servers:[{url:"http://petstore.swagger.io/v2"}],tags:[{name:"pet",description:"Everything about your Pets",externalDocs:{description:"Find out more",url:"http://swagger.io"}},{name:"store",description:"Access to Petstore orders"},{name:"user",description:"Operations about user",externalDocs:{description:"Find out more about our store",url:"http://swagger.io"}}],paths:{"/pet":{post:{tags:["pet"],summary:"Add a new pet to the store",description:"",operationId:"addPet",requestBody:{$ref:"#/components/requestBodies/Pet"},responses:{"405":{description:"Invalid input"}},security:[{petstore_auth:["write:pets","read:pets"]}]},put:{tags:["pet"],summary:"Update an existing pet",description:"",operationId:"updatePet",requestBody:{$ref:"#/components/requestBodies/Pet"},responses:{"400":{description:"Invalid ID supplied"},"404":{description:"Pet not found"},"405":{description:"Validation exception"}},security:[{petstore_auth:["write:pets","read:pets"]}]}},"/pet/findByStatus":{get:{tags:["pet"],summary:"Finds Pets by status",description:"Multiple status values can be provided with comma separated strings",operationId:"findPetsByStatus",parameters:[{name:"status",in:"query",description:"Status values that need to be considered for filter",required:!0,explode:!0,schema:{type:"array",items:{type:"string",enum:["available","pending","sold"],default:"available"}}}],responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{type:"array",items:{$ref:"#/components/schemas/Pet"}}},"application/json":{schema:{type:"array",items:{$ref:"#/components/schemas/Pet"}}}}},"400":{description:"Invalid status value"}},security:[{petstore_auth:["write:pets","read:pets"]}]}},"/pet/findByTags":{get:{tags:["pet"],summary:"Finds Pets by tags",description:"Muliple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.",operationId:"findPetsByTags",parameters:[{name:"tags",in:"query",description:"Tags to filter by",required:!0,explode:!0,schema:{type:"array",items:{type:"string"}}}],responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{type:"array",items:{$ref:"#/components/schemas/Pet"}}},"application/json":{schema:{type:"array",items:{$ref:"#/components/schemas/Pet"}}}}},"400":{description:"Invalid tag value"}},security:[{petstore_auth:["write:pets","read:pets"]}],deprecated:!0}},"/pet/{petId}":{get:{tags:["pet"],summary:"Find pet by ID",description:"Returns a single pet",operationId:"getPetById",parameters:[{name:"petId",in:"path",description:"ID of pet to return",required:!0,schema:{type:"integer",format:"int64"}}],responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{$ref:"#/components/schemas/Pet"}},"application/json":{schema:{$ref:"#/components/schemas/Pet"}}}},"400":{description:"Invalid ID supplied"},"404":{description:"Pet not found"},default:{description:"successful response"}},security:[{api_key:[]}]},post:{tags:["pet"],summary:"Updates a pet in the store with form data",description:"",operationId:"updatePetWithForm",parameters:[{name:"petId",in:"path",description:"ID of pet that needs to be updated",required:!0,schema:{type:"integer",format:"int64"}}],requestBody:{content:{"application/x-www-form-urlencoded":{schema:{type:"object",properties:{name:{description:"Updated name of the pet",type:"string"},status:{description:"Updated status of the pet",type:"string"}}}}}},responses:{"405":{description:"Invalid input"}},security:[{petstore_auth:["write:pets","read:pets"]}]},delete:{tags:["pet"],summary:"Deletes a pet",description:"",operationId:"deletePet",parameters:[{name:"api_key",in:"header",required:!1,schema:{type:"string"}},{name:"petId",in:"path",description:"Pet id to delete",required:!0,schema:{type:"integer",format:"int64"}}],responses:{"400":{description:"Invalid ID supplied"},"404":{description:"Pet not found"}},security:[{petstore_auth:["write:pets","read:pets"]}]}},"/pet/{petId}/uploadImage":{post:{tags:["pet"],summary:"Uploads an image",description:"",operationId:"uploadFile",parameters:[{name:"petId",in:"path",description:"ID of pet to update",required:!0,schema:{type:"integer",format:"int64"}}],requestBody:{content:{"multipart/form-data":{schema:{type:"object",properties:{additionalMetadata:{description:"Additional data to pass to server",type:"string"},file:{description:"file to upload",type:"string",format:"binary"}}}}}},responses:{"200":{description:"successful operation",content:{"application/json":{schema:{$ref:"#/components/schemas/ApiResponse"}}}}},security:[{petstore_auth:["write:pets","read:pets"]}]}},"/store/inventory":{get:{tags:["store"],summary:"Returns pet inventories by status",description:"Returns a map of status codes to quantities",operationId:"getInventory",responses:{"200":{description:"successful operation",content:{"application/json":{schema:{type:"object",additionalProperties:{type:"integer",format:"int32"}}}}}},security:[{api_key:[]}]}},"/store/order":{post:{tags:["store"],summary:"Place an order for a pet",description:"",operationId:"placeOrder",requestBody:{content:{"application/json":{schema:{$ref:"#/components/schemas/Order"}}},description:"order placed for purchasing the pet",required:!0},responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{$ref:"#/components/schemas/Order"}},"application/json":{schema:{$ref:"#/components/schemas/Order"}}}},"400":{description:"Invalid Order"}}}},"/store/order/{orderId}":{get:{tags:["store"],summary:"Find purchase order by ID",description:"For valid response try integer IDs with value >= 1 and <= 10. Other values will generated exceptions",operationId:"getOrderById",parameters:[{name:"orderId",in:"path",description:"ID of pet that needs to be fetched",required:!0,schema:{type:"integer",format:"int64",minimum:1,maximum:10}}],responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{$ref:"#/components/schemas/Order"}},"application/json":{schema:{$ref:"#/components/schemas/Order"}}}},"400":{description:"Invalid ID supplied"},"404":{description:"Order not found"}}},delete:{tags:["store"],summary:"Delete purchase order by ID",description:"For valid response try integer IDs with positive integer value. Negative or non-integer values will generate API errors",operationId:"deleteOrder",parameters:[{name:"orderId",in:"path",description:"ID of the order that needs to be deleted",required:!0,schema:{type:"integer",format:"int64",minimum:1}}],responses:{"400":{description:"Invalid ID supplied"},"404":{description:"Order not found"}}}},"/user":{post:{tags:["user"],summary:"Create user",description:"This can only be done by the logged in user.",operationId:"createUser",requestBody:{content:{"application/json":{schema:{$ref:"#/components/schemas/User"}}},description:"Created user object",required:!0},responses:{default:{description:"successful operation"}}}},"/user/createWithArray":{post:{tags:["user"],summary:"Creates list of users with given input array",description:"",operationId:"createUsersWithArrayInput",requestBody:{$ref:"#/components/requestBodies/UserArray"},responses:{default:{description:"successful operation"}}}},"/user/createWithList":{post:{tags:["user"],summary:"Creates list of users with given input array",description:"",operationId:"createUsersWithListInput",requestBody:{$ref:"#/components/requestBodies/UserArray"},responses:{default:{description:"successful operation"}}}},"/user/login":{get:{tags:["user"],summary:"Logs user into the system",description:"",operationId:"loginUser",parameters:[{name:"username",in:"query",description:"The user name for login",required:!0,schema:{type:"string"}},{name:"password",in:"query",description:"The password for login in clear text",required:!0,schema:{type:"string"}}],responses:{"200":{description:"successful operation",headers:{"X-Rate-Limit":{description:"calls per hour allowed by the user",schema:{type:"integer",format:"int32"}},"X-Expires-After":{description:"date in UTC when token expires",schema:{type:"string",format:"date-time"}}},content:{"application/xml":{schema:{type:"string"}},"application/json":{schema:{type:"string"}}}},"400":{description:"Invalid username/password supplied"}}}},"/user/logout":{get:{tags:["user"],summary:"Logs out current logged in user session",description:"",operationId:"logoutUser",responses:{default:{description:"successful operation"}}}},"/user/{username}":{get:{tags:["user"],summary:"Get user by user name",description:"",operationId:"getUserByName",parameters:[{name:"username",in:"path",description:"The name that needs to be fetched. Use user1 for testing. ",required:!0,schema:{type:"object"}}],responses:{"200":{description:"successful operation",content:{"application/xml":{schema:{$ref:"#/components/schemas/User"}},"application/json":{schema:{$ref:"#/components/schemas/User"}}}},"400":{description:"Invalid username supplied"},"404":{description:"User not found"}}},put:{tags:["user"],summary:"Updated user",description:"This can only be done by the logged in user.",operationId:"updateUser",parameters:[{name:"username",in:"path",description:"name that need to be updated",required:!0,schema:{type:"string"}}],requestBody:{content:{"application/json":{schema:{$ref:"#/components/schemas/User"}}},description:"Updated user object",required:!0},responses:{"400":{description:"Invalid user supplied"},"404":{description:"User not found"}}},delete:{tags:["user"],summary:"Delete user",description:"This can only be done by the logged in user.",operationId:"deleteUser",parameters:[{name:"username",in:"path",description:"The name that needs to be deleted",required:!0,schema:{type:"string"}}],responses:{"400":{description:"Invalid username supplied"},"404":{description:"User not found"}}}}},components:{requestBodies:{Pet:{content:{"application/json":{schema:{$ref:"#/components/schemas/Pet"}},"application/xml":{schema:{$ref:"#/components/schemas/Pet"}}},description:"Pet object that needs to be added to the store",required:!0},UserArray:{content:{"application/json":{schema:{type:"array",items:{$ref:"#/components/schemas/User"}}}},description:"List of user object",required:!0}},securitySchemes:{petstore_auth:{type:"oauth2",flows:{implicit:{authorizationUrl:"http://petstore.swagger.io/oauth/dialog",scopes:{"write:pets":"modify pets in your account","read:pets":"read your pets"}}}},api_key:{type:"apiKey",name:"api_key",in:"header"}},schemas:{Order:{type:"object",properties:{id:{type:"integer",format:"int64"},petId:{type:"integer",format:"int64"},quantity:{type:"integer",format:"int32"},shipDate:{type:"string",format:"date-time"},status:{type:"string",description:"Order Status",enum:["placed","approved","delivered"]},complete:{type:"boolean",default:!1}},xml:{name:"Order"}},Category:{type:"object",properties:{id:{type:"integer",format:"int64"},name:{type:"string"}},xml:{name:"Category"}},User:{type:"object",properties:{id:{type:"integer",format:"int64"},username:{type:"string"},firstName:{type:"string"},lastName:{type:"string"},email:{type:"string"},password:{type:"string"},phone:{type:"string"},userStatus:{type:"integer",format:"int32",description:"User Status"}},xml:{name:"User"}},Tag:{type:"object",properties:{id:{type:"integer",format:"int64"},name:{type:"string"}},xml:{name:"Tag"}},Pet:{type:"object",required:["name","photoUrls"],properties:{id:{type:"integer",format:"int64",readOnly:!0,default:40,example:25},category:{$ref:"#/components/schemas/Category"},name:{type:"string",example:"doggie"},photoUrls:{type:"array",xml:{name:"photoUrl",wrapped:!0},items:{type:"string",example:"https://example.com/photo.png"}},tags:{type:"array",xml:{name:"tag",wrapped:!0},items:{$ref:"#/components/schemas/Tag"}},status:{type:"string",description:"pet status in the store",enum:["available","pending","sold"]}},xml:{name:"Pet"}},ApiResponse:{type:"object",properties:{code:{type:"integer",format:"int32"},type:{type:"string"},message:{type:"string"}}}}}};import{get as J}from"lodash";function U(e){return e.replace(/^#\//,"")}function E(e,t){let r=U(t).split("/"),s=J(e,r);return s&&"$ref"in s?E(e,s.$ref):s}function f(e,t,r=!1,s){if("$ref"in t){let p=U(t.$ref).split("/").pop();return s(p,f(e,E(e,t.$ref),r,s)),p}if(t.allOf&&Array.isArray(t.allOf))return`z.intersection(${t.allOf.map(c=>f(e,c,!0,s)).join(", ")})`;if(t.anyOf&&Array.isArray(t.anyOf))return`z.union([${t.anyOf.map(c=>f(e,c,!1,s)).join(", ")}])${m(r)}`;if(t.oneOf&&Array.isArray(t.oneOf))return`z.union([${t.oneOf.map(c=>f(e,c,!1,s)).join(", ")}])${m(r)}`;if(t.enum&&Array.isArray(t.enum))return`z.enum([${t.enum.map(c=>JSON.stringify(c)).join(", ")}])${m(r)}`;let i=Array.isArray(t.type)?t.type:t.type?[t.type]:[];if(!i.length)return`z.unknown()${m(r)}`;if(i.length>1){let p=i.filter(a=>a!=="null");return p.length===1&&i.includes("null")?`${S(p[0],t,e,!1,s)}.nullable()${m(r)}`:`z.union([${i.map(a=>S(a,t,e,!1,s)).join(", ")}])${m(r)}`}return S(i[0],t,e,r,s)}function S(e,t,r,s=!1,i){switch(e){case"string":return G(t,s);case"number":case"integer":return Q(t,s);case"boolean":return`z.boolean()${C(t.default)}${m(s)}`;case"object":return K(t,r,s,i);case"array":return X(t,r,s,i);case"null":return`z.null()${m(s)}`;default:return`z.unknown()${m(s)}`}}function G(e,t){let r="z.string()";switch(e.format){case"date-time":case"datetime":r="z.coerce.date()";break;case"date":r="z.coerce.date() /* or z.string() if you want raw date strings */";break;case"time":r="z.string() /* optionally add .regex(...) for HH:MM:SS format */";break;case"email":r="z.string().email()";break;case"uuid":r="z.string().uuid()";break;case"url":case"uri":r="z.string().url()";break;case"ipv4":r='z.string().ip({version: "v4"})';break;case"ipv6":r='z.string().ip({version: "v6"})';break;case"phone":r="z.string() /* or add .regex(...) for phone formats */";break;case"byte":case"binary":r="z.string() /* consider base64 check if needed */";break;case"int64":r="z.string() /* or z.bigint() if your app can handle it */";break;default:break}return`${r}${C(e.default)}${m(t)}`}function Q(e,t){let r=e.default!==void 0?`.default(${e.default})`:"",s="z.number()";return e.format==="int64"&&(s="z.bigint()",e.default&&(r=`.default(BigInt(${e.default}))`)),e.format==="int32"&&(s+=".int()"),typeof e.exclusiveMinimum=="number"&&(s+=`.gt(${e.exclusiveMinimum})`),typeof e.exclusiveMaximum=="number"&&(s+=`.lt(${e.exclusiveMaximum})`),typeof e.minimum=="number"&&(s+=`.min(${e.minimum})`),typeof e.maximum=="number"&&(s+=`.max(${e.maximum})`),typeof e.multipleOf=="number"&&(s+=`.refine((val) => Number.isInteger(val / ${e.multipleOf}), "Must be a multiple of ${e.multipleOf}")`),`${s}${r}${m(t)}`}function K(e,t,r=!1,s){let i=e.properties||{},p=Object.entries(i).map(([o,u])=>{let b=e.required?.includes(o)??!1,y=f(t,u,b,s);return`${o}: ${y}`}),c="";return e.additionalProperties&&(typeof e.additionalProperties=="object"?c=`.catchall(${f(t,e.additionalProperties,!0,s)})`:e.additionalProperties===!0&&(c=".catchall(z.unknown())")),`${`z.object({${p.join(", ")}})${c}`}${m(r)}`}function X(e,t,r=!1,s){let{items:i}=e;return i?Array.isArray(i)?`${`z.tuple([${i.map(o=>f(t,o,!0,s)).join(", ")}])`}${m(r)}`:`z.array(${f(t,i,!0,s)})${m(r)}`:`z.array(z.unknown())${m(r)}`}function m(e){return e?"":".optional()"}function C(e){return e?`.default(${JSON.stringify(e)})`:""}var z=`import { parse } from 'fast-content-type-parse';
import type { Endpoints } from './endpoints';
import schemas from './schemas';
import { validateOrThrow, ServerError } from './validator';

export interface RequestInterface<D extends object = object> {
	/**
	 * Sends a request based on endpoint options
	 *
	 * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'
	 * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.
	 */
	<R extends keyof Endpoints>(
		route: R,
		options?: Endpoints[R]['input']
	): Promise<Endpoints[R]['output']>;
}

export async function handleError(response: Response) {
	try {
		if (response.status >= 400 && response.status < 500) {
			const body = (await response.json()) as Record<string, any>;
			return new ServerError(body.title || body.detail, response.status, body.errors ?? {});
		}
		return new Error(
			\`An error occurred while fetching the data. Status: \${response.status}\`
		);
	} catch (error) {
		// in case the response is not a json
		// this is a workaround but we should change
		// it from the server to always return json

		return error as Error;
	}
}

export async function parseResponse(response: Response) {
	const contentType = response.headers.get('Content-Type');
	if (!contentType) {
		throw new Error('Content-Type header is missing');
	}

	if (response.status === 204) {
		return null;
	}

	const { type } = parse(contentType);
	switch (type) {
		case 'application/json':
			return response.json();
		case 'text/plain':
			return response.text();
		default:
			throw new Error(\`Unsupported content type: \${contentType}\`);
	}
}`;var q=`type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type Endpoint = \`\${Method} \${string}\`;

export function createUrl(base: string, path: string, query: URLSearchParams) {
	const url = new URL(path, base);
	url.search = query.toString();
	return url;
}
function template(
	templateString: string,
	templateVariables: Record<string, any>
): string {
	const nargs = /{([0-9a-zA-Z_]+)}/g;
	return templateString.replace(nargs, (match, key: string, index: number) => {
		// Handle escaped double braces
		if (
			templateString[index - 1] === '{' &&
			templateString[index + match.length] === '}'
		) {
			return key;
		}

		const result = key in templateVariables ? templateVariables[key] : null;
		return result === null || result === undefined ? '' : String(result);
	});
}
export function toRequest<T extends Endpoint>(
	endpoint: T,
	input: Record<string, any>,
	props: {
		inputHeaders: string[];
		inputQuery: string[];
		inputBody: string[];
		inputParams: string[];
	},
	defaults: {
		baseUrl: string;
		headers?: Record<string, string>;
	}
): Request {
	const [method, path] = endpoint.split(' ');

	const headers = new Headers({
		...defaults?.headers,
		'Content-Type': 'application/json',
		Accept: 'application/json',
	});

	for (const header of props.inputHeaders) {
		headers.set(header, input[header]);
	}

	const query = new URLSearchParams();
	for (const key of props.inputQuery) {
		const value = input[key];
		if (value !== undefined) {
			query.set(key, String(value));
		}
	}

	const body = props.inputBody.reduce<Record<string, any>>((acc, key) => {
		acc[key] = input[key];
		return acc;
	}, {});

	const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
		acc[key] = input[key];
		return acc;
	}, {});

	const init = {
		path: template(path, params),
		method,
		headers,
		query,
		body: JSON.stringify(body),
	};

	const url = createUrl(defaults.baseUrl, init.path, init.query);
	return new Request(url, {
		method: init.method,
		headers: init.headers,
		body: method === 'GET' ? undefined : JSON.stringify(body),
	});
}
`;var B=`import { z } from 'zod';

export function validate<T extends z.ZodRawShape>(
	schema: z.ZodObject<T>,
	input: unknown
) {
	const result = schema.safeParse(input);
	if (!result.success) {
		return result.error.flatten((issue) => ({
			message: issue.message,
			code: issue.code,
			fatel: issue.fatal,
			path: issue.path.join('.'),
		})).fieldErrors;
	}
	return null;
}

export class ValidationError extends Error {
	flattened: { path: string; message: string }[];
	constructor(
		public override message: string,
		public errors: ReturnType<typeof validate>
	) {
		super(message);
		this.name = 'ValidationError';
		Error.captureStackTrace(this, ValidationError);
		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({
			path: key,
			message: (it as any[])[0].message,
		}));
	}
}

export class ServerError extends Error {
	flattened: { path: string; message: string }[];
	constructor(
		public override message: string,
		public status: number,
		public errors: ReturnType<typeof validate>
	) {
		super(message);
		this.name = 'ServerError';
		Error.captureStackTrace(this, ServerError);
		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({
			path: key,
			message: (it as any[])[0].message,
		}));
	}
}

export function validateOrThrow<T extends z.ZodRawShape>(
	schema: z.ZodObject<T>,
	input: unknown
): asserts input is z.infer<z.ZodObject<T>> {
	const errors = validate(schema, input);
	if (errors) {
		throw new ValidationError('Validation failed', errors);
	}
}
`;import{camelcase as D}from"stringcase";var F=e=>{let t={...e.options??{},baseUrl:{schema:"z.string().url()"}};e.securityScheme&&(t.token={schema:"z.string().optional()"});let r=e.securityScheme?`{Authorization: \`${N(e.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}`:"{}";return`

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { validateOrThrow } from './validator';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${O(t,s=>s.schema)});
      type ${e.name}Options = z.infer<typeof optionsSchema>;
    export class ${e.name} {

      constructor(public options: ${e.name}Options) {}

async stream<E extends keyof StreamEndpoints>(
    endpoint: E,
    input: StreamEndpoints[E]['input'],
  ): Promise<readonly [ReadableStream, Error | null]> {
    try {
      const route = schemas[endpoint];
      validateOrThrow(route.schema, input);
      const response = await fetch(
        route.toRequest(input as never, {
          headers: this.defaultHeaders,
          baseUrl: this.options.baseUrl,
        }),
      );

      if (response.ok) {
        return [response.body!, null] as const;
      }
      const error = await handleError(response);
      return [null as never, error] as const;
    } catch (error) {
      return [null as never, error as Error] as const;
    }
  }

async request<E extends keyof Endpoints>(
		endpoint: E,
		input: Endpoints[E]['input']
	): Promise<readonly [Endpoints[E]['output'], Error | null]> {
		try {
			const route = schemas[endpoint];
			validateOrThrow(route.schema, input);
			const response = await fetch(
				route.toRequest(input as never, {
					headers: this.defaultHeaders,
					baseUrl: this.options.baseUrl,
				})
			);

			if (response.ok) {
				const data = await parseResponse(response);
				return [data as Endpoints[E]['output'], null] as const;
			}
			const error = await handleError(response);
			return [null, error] as const;
		} catch (error) {
			return [null, error as Error] as const;
		}
	}

      get defaultHeaders() {
        return ${r}
      }

  setOptions(options: Partial<${e.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${e.name}Options)[]) {
      if (validated[key] !== undefined) {
        this.options[key] = validated[key]!;
      }
    }
  }
}`};var j=class{#e=["import z from 'zod';",'import type { Endpoints } from "./endpoints";','import type { StreamEndpoints } from "./stream-endpoints";',"import { toRequest, createUrl } from './request';"];#t=[];addEndpoint(t,r){this.#t.push(`  "${t}": ${r},`)}addImport(t){this.#e.push(t)}complete(){return`${this.#e.join(`
`)}
export default {
${this.#t.join(`
`)}
}`}},w=class{imports=["import z from 'zod';"];endpoints=[];addEndpoint(t,r){this.endpoints.push(`  "${t}": ${r};`)}addImport(t){this.imports.push(t)}complete(){return`${this.imports.join(`
`)}
export interface Endpoints {
${this.endpoints.join(`
`)}
}`}},R=class extends w{complete(){return`${this.imports.join(`
`)}
export interface StreamEndpoints {
${this.endpoints.join(`
`)}
}`}};function lt(e){let t=new w,r=new R,s={},i=[],p=new j;for(let[c,a]of Object.entries(e.groups)){let o=D(c);s[o]=["import z from 'zod';"],t.addImport(`import * as ${o} from './inputs/${o}';`),r.addImport(`import * as ${o} from './inputs/${o}';`),p.addImport(`import * as ${o} from './inputs/${o}';`);for(let u of a){let b=D(`${u.name} schema`),y=`export const ${b} = ${u.schema};`;s[o].push(y),i.push(...u.imports.map(x=>(x.namedImports??[]).map(v=>v.name)).flat());let l=`${u.trigger.method.toUpperCase()} ${u.trigger.path}`,g=`${o}.${b}`,n=`z.infer<typeof ${g}>`,d=u.formatOutput(),h=[],T=[],I=[],k=[];for(let[x,v]of Object.entries(u.inputs))if(v.source==="headers")h.push(`"${x}"`);else if(v.source==="query")T.push(`"${x}"`);else if(v.source==="body")I.push(`"${x}"`);else if(v.source==="path")k.push(`"${x}"`);else{if(v.source==="internal")continue;throw new Error(`Unknown source ${v.source} in ${x} ${JSON.stringify(v)} in ${u.name}`)}u.type==="stream"?(r.addImport(`import {${$(u.name)}} from './outputs/${u.name}';`),r.addEndpoint(l,`{input: ${n}, output: ${d}}`),p.addEndpoint(l,`{
        schema: ${g},
        toRequest(input: StreamEndpoints['${l}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${l}';
            return toRequest(endpoint, input, {
            inputHeaders: [${h}],
            inputQuery: [${T}],
            inputBody: [${I}],
            inputParams: [${k}],
          }, init);
          },
        }`)):(t.addImport(`import {${$(u.name)}} from './outputs/${u.name}';`),t.addEndpoint(l,`{input: ${n}, output: ${d}}`),p.addEndpoint(l,`{
        schema: ${g},
        toRequest(input: Endpoints['${l}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${l}';
            return toRequest(endpoint, input, {
            inputHeaders: [${h}],
            inputQuery: [${T}],
            inputBody: [${I}],
            inputParams: [${k}],
          }, init);
          },
        }`))}}return{...Object.fromEntries(Object.entries(s).map(([c,a])=>[`inputs/${c}.ts`,[i.length?`import {${P(i,o=>o)}} from '../zod';`:"",...a].join(`
`)])),"backend.ts":F(e),"validator.ts":B,"client.ts":z,"request.ts":q,"schemas.ts":p.complete(),"endpoints.ts":t.complete(),"stream-endpoints.ts":r.complete()}}function A(e){return"$ref"in e}function bt(){let e=L,t={},r={},s={};for(let[i,p]of Object.entries(e.paths??{}))for(let[c,a]of Object.entries(p)){if(i!=="/pet/findByStatus")continue;let o=a.operationId,u=(a.tags??["default"])[0];t[u]??=[];let b={},y=[],l="",g=[];for(let n of a.parameters??[]){if(A(n))throw new Error(`Found reference in parameter ${n.$ref}`);if(!n.schema)throw new Error(`Schema not found for parameter ${n.name}`);b[n.name]={source:n.in,schema:""},g.push(n)}if(a.requestBody&&Object.keys(a.requestBody).length){let n=A(a.requestBody)?M(E(e,a.requestBody.$ref),["content","application/json","schema"]):a.requestBody.content["application/json"].schema;A(n)&&(n=E(e,n.$ref)),l=f(e,re(n,{required:g.filter(d=>d.required).map(d=>d.name),properties:g.reduce((d,h)=>({...d,[h.name]:h.schema}),{})}),!0,(d,h)=>{r[d]=h,y.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"./zod",namedImports:[{isTypeOnly:!1,name:d}],namespaceImport:void 0})})}else l=f(e,{type:"object",required:g.filter(n=>n.required).map(n=>n.name),properties:g.reduce((n,d)=>({...n,[d.name]:d.schema}),{})},!0,(n,d)=>{r[n]=d,y.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"./zod",namedImports:[{isTypeOnly:!1,name:n}],namespaceImport:void 0})});if(a.responses){let n=a.responses[200];if(n){let d=M(n,["content","application/json","schema"]),h=f(e,d,!0,(T,I)=>{r[T]=I,y.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"../zod",namedImports:[{isTypeOnly:!1,name:T}],namespaceImport:void 0})});s[`${o}.ts`]=`
          import z from 'zod';
          ${se(V(Object.values(y).flat())).join(`
`)}
            export const ${$(o)} = ${h}
            `,console.log({responseSchema:h})}}t[u].push({name:o,type:"http",imports:V(Object.values(y).flat()),inputs:b,schema:l,formatOutput:()=>`z.infer<typeof ${$(o)}>`,trigger:{path:i,method:c}})}return{groups:t,commonSchemas:r,outputs:s}}function V(e){let t={};for(let r of e)t[r.moduleSpecifier]=t[r.moduleSpecifier]??{moduleSpecifier:r.moduleSpecifier,defaultImport:r.defaultImport,namespaceImport:r.namespaceImport,namedImports:[]},r.namedImports&&t[r.moduleSpecifier].namedImports.push(...r.namedImports);return Object.values(t)}function se(e){return e.map(t=>{if(t.defaultImport)return`import ${t.defaultImport} from '${t.moduleSpecifier}'`;if(t.namespaceImport)return`import * as ${t.namespaceImport} from '${t.moduleSpecifier}'`;if(t.namedImports)return`import {${t.namedImports.map(r=>r.name).join(", ")}} from '${t.moduleSpecifier}'`;throw new Error(`Invalid import ${JSON.stringify(t)}`)})}export{bt as generate,lt as generateClientSdk};
