import { type Operation } from './sdk';
export declare function generate(): {
    groups: Record<string, Operation[]>;
    commonSchemas: Record<string, string>;
    outputs: Record<string, string>;
};
export * from './sdk';
