import type { Checker } from '@january/parser';
export interface SecurityScheme {
    bearerAuth: {
        type: 'http';
        scheme: 'bearer';
        bearerFormat: 'JWT';
    };
}
export interface SdkConfig {
    /**
     * The name of the sdk client
     */
    name: string;
    packageName?: string;
    options?: Record<string, any>;
    emptyBodyAsNull?: boolean;
    stripBodyFromGetAndHead?: boolean;
    securityScheme?: SecurityScheme;
    output: string;
    formatGeneratedCode?: boolean;
}
export interface Spec {
    groups: Record<string, Operation[]>;
    commonZod?: string;
    name?: string;
    options?: Record<string, {
        in: 'header';
        schema: string;
    }>;
    securityScheme?: SecurityScheme;
}
export interface OperationInput {
    source: string;
    schema: string;
}
export interface Operation {
    name: string;
    errors: string[];
    type: string;
    imports: Checker.Import[];
    trigger: Record<string, any>;
    contentType?: string;
    schemas: Record<string, string>;
    schema?: string;
    inputs: Record<string, OperationInput>;
    formatOutput: () => {
        import: string;
        use: string;
    };
}
export declare function generateClientSdk(spec: Spec): {
    'backend.ts': string;
    'parser.ts': string;
    'client.ts': string;
    'request.ts': string;
    'schemas.ts': string;
    'endpoints.ts': string;
    'stream-endpoints.ts': string;
    'response.ts': string;
};
