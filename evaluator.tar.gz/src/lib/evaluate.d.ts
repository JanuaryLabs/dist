import type { UnknownFeature } from '@january/declarative';
import type { diagnostic } from '@january/parser';
import { Checker } from '@january/parser';
export type Callers = Record<string, (...args: any[]) => void>;
export declare const defaultPrimitiveCallers: Callers;
export declare const EVAL_ERRORS: {
    UNKNOWN_CALLER: string;
};
export declare function staticEval(callers: Callers, node: unknown, hooks?: {
    unknownCaller?: (node: unknown, caller: string) => null | ((...args: any[]) => void);
}): unknown;
export declare function defensiveEvaluate(code: string): Promise<{
    reports: diagnostic.Diagnostic[];
    definition: {
        features: UnknownFeature[];
        imports: Checker.Import[];
    };
}>;
export declare function evaluate<T>(code: string, callers: Callers): Promise<{
    block: T;
    imports: Checker.Import[];
}>;
export declare function compare(a: string, b: string): Promise<boolean>;
