export declare function inferType(code: string): Promise<any>;
