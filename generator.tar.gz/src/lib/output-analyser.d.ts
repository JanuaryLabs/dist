import type * as morph from 'ts-morph';
export declare function getReturnTypeOfDefaultExport(workflowOutput: string, project?: morph.Project): {
    returnTypeStr: string;
    returnCode: string;
    properties: {
        name: string;
        primitiveType: string | undefined;
        parameter: string | undefined;
    }[];
};
export declare function assignDefaultExportToVar(code: string, varName: string, project?: morph.Project): string;
