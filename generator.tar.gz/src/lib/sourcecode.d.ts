import * as morph from 'ts-morph';
import type { ConcreteContracts } from '@faslh/compiler/contracts';
export declare function createMorph(): morph.Project;
export declare function emitFiles(concreteStructure: OnFeatureR, generateDir?: string): {
    files: {
        path: import("@ts-morph/common").StandardizedFilePath;
        content: string;
    }[];
    save: (before?: (file: morph.SourceFile) => void) => Promise<void>;
    cleanup: () => void;
};
export type OnFeatureR = Record<string, ConcreteContracts.MorphStatementWriter>;
