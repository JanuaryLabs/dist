import type { ComposeService } from '@january/docker';
export declare class FlyExtension {
    composeService(): {
        api: {
            image: string;
            build: {
                context: string;
                dockerfile: string;
            };
            networks: string[];
            restart: string;
            command: string;
            develop: {
                watch: ({
                    action: string;
                    path: string;
                    target: string;
                    ignore: string[];
                } | {
                    action: string;
                    path: string;
                    target?: undefined;
                    ignore?: undefined;
                })[];
            };
            env_file: string[];
            ports: string[];
            depends_on: string[];
        };
    };
    env(): {
        PORT: string;
    };
}
export declare const localServer: (options?: {
    port?: string;
    env?: Record<string, string>;
    env_file?: string[];
}) => ComposeService;
