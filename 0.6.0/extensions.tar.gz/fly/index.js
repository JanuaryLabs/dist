// libs/extensions/fly/src/index.ts
var FlyExtension = class {
  composeService() {
    return {
      api: {
        image: "node:lts",
        build: {
          context: ".",
          dockerfile: "Dockerfile"
        },
        networks: ["development"],
        restart: "unless-stopped",
        command: "node --watch /app/build/server.js",
        develop: {
          watch: [
            {
              action: "sync",
              path: "./output/build/server.js",
              target: "/app/build/server.js",
              ignore: ["node_modules/"]
            },
            {
              action: "rebuild",
              path: "./output/package.json"
            }
          ]
        },
        env_file: [".env"],
        ports: ["3000:3000", "9229:9229"],
        depends_on: ["database"]
      }
    };
  }
  env() {
    return {
      PORT: "3000"
    };
  }
};
var localServer = (options = {
  port: "3000"
}) => {
  options.port ??= "3000";
  return {
    image: "node:lts",
    build: {
      context: ".",
      dockerfile: "Dockerfile"
    },
    networks: ["development"],
    restart: "unless-stopped",
    command: "node --watch /app/build/server.js",
    develop: {
      watch: [
        {
          action: "sync",
          path: "./output/build/server.js",
          target: "/app/build/server.js",
          ignore: ["node_modules/"]
        },
        {
          action: "rebuild",
          path: "./output/package.json"
        }
      ]
    },
    ports: [`${options.port}:${options.port}`, "9229:9229"],
    environment: {
      NODE_ENV: "development",
      PORT: options.port
    },
    env_file: [".env.compose", ".env", ...options.env_file ?? []]
  };
};
export {
  FlyExtension,
  localServer
};
