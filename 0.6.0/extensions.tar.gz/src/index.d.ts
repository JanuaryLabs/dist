import { compose } from '@january/docker';
export { FlyExtension } from '@january/extensions/fly';
export { PostgreSQLExtension } from '@january/extensions/postgresql';
interface Ext {
    composeService(): Record<string, {
        [key: string]: any;
        volumes?: string[];
        networks?: string[];
    }>;
    env(): Record<string, string>;
}
export declare function run(ext: Ext[]): void;
export declare function writeFiles(dir: string, contents: Record<string, unknown>): Promise<void>;
export declare function writeCompose({ dockerCompose, environment, }: ReturnType<typeof compose>): Promise<void>;
