var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/extensions/src/fly/index.ts
import dedent from "dedent";
import yaml from "js-yaml";
var deployContent = /* @__PURE__ */ __name(() => {
  return yaml.dump(
    {
      name: "Deploy To fly.io",
      on: {
        push: {
          branches: ["main"]
        },
        workflow_dispatch: {}
      },
      jobs: {
        deploy_to_fly: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            {
              id: "setup_node",
              uses: "actions/setup-node@v3",
              name: "Setup Node.js",
              with: {
                "node-version": "20",
                cache: "npm"
              }
            },
            // {
            //   id: 'cache_deps',
            //   name: 'Cache Or Restore Node Modules.',
            //   uses: 'actions/cache@v3',
            //   with: {
            //     path: 'node_modules',
            //     key: "${{ runner.os }}-node-${{ hashFiles('package-lock.json') }}",
            //   },
            // },
            // {
            //   id: 'install_deps',
            //   name: 'Install project dependencies.',
            //   run: 'npm install --no-audit --no-fund',
            //   if: `steps.cache_deps.outputs.cache-hit != 'true'`,
            // },
            // {
            //   FIXME: set this up properly using esbuild
            //   id: 'build',
            //   name: 'Build',
            //   if: false,
            //   run: 'npm run build:prod',
            // },
            {
              name: "Build",
              run: "npm run build"
            },
            {
              name: "Setup Fly.io cli.",
              uses: "superfly/flyctl-actions/setup-flyctl@master"
            },
            {
              id: "deploy",
              name: "Deploying ...",
              run: `flyctl deploy --app \${{ secrets.FLY_APP_NAME }} --remote-only`,
              env: {
                FLY_API_TOKEN: `\${{ secrets.FLY_API_TOKEN }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
}, "deployContent");
var fly = {
  packages: {},
  files: {
    "../.github/workflows/deploy.yml": deployContent(),
    "../.dockerignore": ["node_modules", ".git"].join("\n"),
    "../Dockerfile": dedent`
  ARG NODE_VERSION=20

FROM node:\${NODE_VERSION}-alpine AS builder
LABEL fly_launch_runtime="NodeJS"
WORKDIR /app
ENV NODE_ENV=production
COPY ./output/package*.json ./
RUN npm install --omit=dev --no-audit --no-fund --legacy-peer-deps

FROM node:\${NODE_VERSION}-alpine AS runner
WORKDIR /app
COPY --from=builder /app/node_modules /app/node_modules
COPY ./output/build/ /app/build/
COPY ./output/package*.json ./
CMD [ "npm", "start"]
EXPOSE 3000`,
    "../fly.toml": dedent`
    #
# See https://fly.io/docs/reference/configuration/ for information about how to use this file.
#

primary_region = "ams"

[env]
  PORT = "3000"

[http_service]
  internal_port = 3000
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 0

`,
    "src/server.ts": `import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import application from './app';
import { relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { showRoutes } from 'hono/dev'
import ip from 'ip';
import boxen from 'boxen';
import glob from 'fast-glob';
import { pretty } from '@january/console';

const dirRelativeToCwd = relative(process.cwd(), import.meta.dirname);

  application.use(
    '/:filename{.+\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

  application.use('/:filename{.+\\.swagger\\.json$}', serveStatic({
    root: dirRelativeToCwd,
    rewriteRequestPath: (path) => path.split('/').pop() as string,
  }));

const port = parseInt(process.env.PORT ?? '3000', 10)
serve({
  fetch: application.fetch,
  port: port,
});

if(process.env.NODE_ENV === 'development'){
  showRoutes(application, { verbose: true });
}

pretty.network(port);
pretty.swagger('*.swagger.json')
`
  }
};
export {
  fly
};
//# sourceMappingURL=index.js.map
