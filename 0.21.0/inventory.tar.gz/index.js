var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/inventory/src/lib/inventory.ts
function inventory() {
  return "inventory";
}
__name(inventory, "inventory");
export {
  inventory
};
//# sourceMappingURL=index.js.map
