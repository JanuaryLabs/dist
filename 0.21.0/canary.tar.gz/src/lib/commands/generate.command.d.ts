export declare function doGenerate(projectDir: string): Promise<{}>;
