var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/extensions/src/typeorm/execute.txt
var execute_default = "import sqlTag, { RawValue } from 'sql-template-tag';\nimport { camelCase } from 'lodash-es';\nimport {\n  Brackets,\n  DeepPartial,\n  EntityManager,\n  EntityTarget,\n  ObjectLiteral,\n  QueryRunner,\n  SelectQueryBuilder,\n  WhereExpressionBuilder,\n} from 'typeorm';\nimport dataSource from '../../core/data-source';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\nimport { Transform } from 'node:stream';\nexport type ExecutePipeline<I extends ObjectLiteral> = <\n  O extends Record<string, any>,\n>(\n  domainEntity: I,\n  rawEntity: Record<string, any>,\n) => I;\n\nexport async function execute<U extends ObjectLiteral>(\n  qb: SelectQueryBuilder<U>,\n  ...mappers: ExecutePipeline<U>[]\n) {\n  const { entities, raw } = await qb.getRawAndEntities();\n  return entities.map((entity, index) => {\n    return mappers.reduce((acc, mapper) => {\n      return mapper(acc, raw[index]);\n    }, entity);\n  });\n}\n\n/**\n * Begin a transaction and execute a computation. If the computation succeeds, the transaction is committed. If the computation fails, the transaction is rolled back.\n *\n * @param computation async function that takes a `EntityManager` and returns a `Promise`\n * @returns the result of the computation\n * @throws the error thrown by the computation or the error thrown by the transaction\n * @example\n *\n * // If the computation succeeds, the transaction is committed\n *\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  return user;\n * });\n *\n * // result is the updated user\n *\n * // If the computation fails, the transaction is rolled back\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  throw new Error('Something went wrong');\n * });\n *\n * // result is undefined\n * // If the transaction fails, the error is thrown\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  await manager.query('DROP TABLE users');\n * });\n *\n */\nexport async function useTransaction<TResult>(\n  computation: (manager: EntityManager) => Promise<TResult>,\n) {\n  let queryRunner: QueryRunner = dataSource.createQueryRunner();\n  await queryRunner.connect();\n  await queryRunner.startTransaction();\n  try {\n    const result = await computation(queryRunner.manager);\n    await queryRunner.commitTransaction();\n    return result;\n  } catch (error) {\n    await queryRunner.rollbackTransaction();\n    await queryRunner.release();\n    (queryRunner as any) = null;\n    throw error;\n  }\n}\n\nexport function limitOffsetPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    pageNo?: number;\n    pageSize?: number;\n    count: number;\n  },\n) {\n  const pageSize = Number(options.pageSize||50);\n  const pageNo = Number(options.pageNo||1);\n  const offset = (pageNo - 1) * pageSize;\n  qb.take(pageSize);\n  qb.skip(offset);\n\n  return (result: Entity[]) => ({\n    hasNextPage: result.length === pageSize,\n    hasPreviousPage: offset > 0,\n    pageSize: options.pageSize,\n    currentPage: options.pageNo,\n    totalCount: options.count,\n    totalPages: Math.ceil(options.count / pageSize),\n  });\n}\n\nexport function deferredJoinPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    pageNo?: number | string | undefined;\n    pageSize?: number | string | undefined;\n    count: number;\n  },\n) {\n  const pageSize = Number(options.pageSize||50);\n  const pageNo = Number(options.pageNo||1);\n  const offset = (pageNo - 1) * pageSize;\n\n  const { tablePath: tableName } = qb.expressionMap.findAliasByName(qb.alias);\n  if (!tableName) {\n    throw new Error(`Could not find table path for alias ${qb.alias}`);\n  }\n\n  const subQueryAlias = `deferred_join_${tableName}`;\n  qb.innerJoin(\n    (subQuery) => {\n      const subQueryTableAlias = `deferred_${tableName}`;\n\n      return subQuery\n        .from(tableName, subQueryTableAlias)\n        .select(`${subQueryTableAlias}.id`, 'id')\n        .orderBy(`${subQueryTableAlias}.createdAt`)\n        .limit(pageSize)\n        .offset(offset);\n    },\n    subQueryAlias,\n    `${qb.alias}.id = ${subQueryAlias}.id`,\n  );\n  return (result: Entity[]) => ({\n    hasNextPage: result.length === pageSize,\n    hasPreviousPage: offset > 0,\n    pageSize: options.pageSize,\n    currentPage: options.pageNo,\n    totalCount: options.count,\n    totalPages: Math.ceil(options.count / pageSize),\n  });\n}\n\nexport function cursorPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    count: number;\n    pageSize: number;\n    /**\n     * Base64 encoded string of the last record's cursor\n     */\n    cursor?: string; // we shouldn't need to specify before or after cursor, the cursor should be enough\n  },\n) {\n  const cursorPayload = options.cursor\n    ? JSON.parse(Buffer.from(options.cursor, 'base64').toString('utf-8'))\n    : null;\n  const alias = qb.alias;\n\n  let orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n  if (!orderByColumns.includes(`${alias}.createdAt`)) {\n    // always order by createdAt to ensure a consistent order\n    // createdAt will be either first order by in case no order by is specified by the caller function or last order by in case the caller function specified an order by\n    qb.addOrderBy(`${alias}.createdAt`);\n  }\n  if (!orderByColumns.includes(`${alias}.id`)) {\n    // fallback to order by id if more than one record is duplicated (have the same attributes used in order by clause)\n    qb.addOrderBy(`${alias}.id`);\n  }\n\n  orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n  if (cursorPayload) {\n    qb.andWhere(\n      new Brackets((qb) => {\n        function withCurrentColumn(qb: WhereExpressionBuilder, index: number) {\n          const column = orderByColumns[index];\n          const paramName = camelCase(\n            `last ${getColumnNameWithoutAlias(column, alias)}`,\n          );\n          qb.andWhere(`${column} > :${paramName}`, {\n            [paramName]: cursorPayload[paramName],\n          });\n        }\n\n        for (let index = 0; index < orderByColumns.length; index++) {\n          if (index === 0) {\n            withCurrentColumn(qb, index);\n            continue;\n          }\n          qb.orWhere(\n            new Brackets((qb) => {\n              for (let j = 0; j < index; j++) {\n                const previousColumn = orderByColumns[j];\n                const paramName = camelCase(\n                  `last ${getColumnNameWithoutAlias(previousColumn, alias)}`,\n                );\n                qb.andWhere(`${previousColumn} = :${paramName}`, {\n                  [paramName]: cursorPayload[paramName],\n                });\n              }\n              withCurrentColumn(qb, index);\n            }),\n          );\n        }\n      }),\n    );\n  }\n\n  qb.take(options.pageSize + 1);\n  return (result: Entity[]) => ({\n    nextCursor: Buffer.from(\n      JSON.stringify(\n        orderByColumns.reduce<Record<string, any>>((acc, column) => {\n          const paramName = camelCase(\n            `last ${getColumnNameWithoutAlias(column, alias)}`,\n          );\n          return {\n            ...acc,\n            [paramName]: qb.expressionMap.parameters[paramName],\n          };\n        }, {}),\n      ),\n    ).toString('base64'),\n    previousCursor: null,\n    startCursor: null, // always null\n    endCursor: '', // think of it as startCursor but the order is reversed\n    hasNextPage: false, // if there is nextCursor, then there is a next page\n    hasPreviousPage: false, // if there is previousCursor, then there is a previous page\n    pageSize: options.pageSize,\n    totalCount: options.count,\n  });\n}\n\nexport function getEntityById<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  id: string,\n) {\n  const qb = createQueryBuilder(entity, 'entity')\n  .where('entity.id = :id', {\n    id,\n  })\n  .limit(1);\n  return qb.getOne();\n}\n\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n  return column.replace(`${alias}.`, '');\n}\n\nexport function createQueryBuilder<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  alias: string,\n) {\n  const repo = dataSource.getRepository(entity);\n  return repo.createQueryBuilder(alias);\n}\n\nexport async function removeEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(entityType: EntityTarget<Entity>, qb: SelectQueryBuilder<T>) {\n  const repo = dataSource.getRepository(entityType);\n  const entity = await qb.getOneOrFail();\n  await repo.softRemove(entity);\n  return entity;\n}\n\nexport async function patchEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>,\n) {\n  const result = await qb\n    .update()\n    .set(entity as unknown as Entity)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function setEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  // TODO: should throw an error if the entity does not exist or one of the required filed is missing\n  // put replaces the whole record one met validation\n  return patchEntity(qb, entity);\n}\n\nexport async function increment<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :incrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('incrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function decrement<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :decrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('decrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport function saveEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  const repo = dataSource.getRepository(entityType);\n  return repo.save(entity as T);\n}\n\nexport async function upsertEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n  conflictColumns: Extract<keyof (Entity & { id: string }), string>[] = ['id'],\n) {\n  const repo = dataSource.getRepository(entityType);\n  await repo\n    .createQueryBuilder()\n    .insert()\n    .into(entityType)\n    .values(entity as T)\n    .orUpdate(Object.keys(entity), conflictColumns)\n    .execute();\n}\n\nexport function sql(\n  strings: readonly string[],\n  ...values: readonly RawValue[]\n) {\n  const serializedSQL = sqlTag(strings, ...values);\n  return dataSource.query(serializedSQL.sql, serializedSQL.values);\n}\n\nexport function exists<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n) {\n  return qb.getOne().then(Boolean);\n}\n\nexport async function stream<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(qb: SelectQueryBuilder<T>) {\n  const stream = await qb.stream();\n  return stream.pipe(\n    new Transform({\n      objectMode: true,\n      transform(record, encoding, callback) {\n        callback(\n          null,\n          JSON.stringify(\n            Object.fromEntries(\n              Object.entries(record).map(([key, value]) => [\n                key.replace(/projects_/g, ''),\n                value,\n              ]),\n            ),\n          ),\n        );\n      },\n    }),\n  );\n}\n";

// libs/extensions/src/typeorm/postgresql.ts
function postgresql(options = {}) {
  return {
    options: {
      type: `'postgres'`,
      useUTC: true,
      url: `process.env.CONNECTION_STRING`,
      ssl: `process.env.NODE_ENV === 'production'`
    },
    files: {
      "src/extensions/postgresql/execute.ts": execute_default,
      "src/extensions/postgresql/index.ts": `export * from './execute';`
    },
    packages: {
      pg: {
        version: "8.11.5",
        dev: false
      },
      "pg-query-stream": {
        version: "^4.7.0",
        dev: false
      }
    }
  };
}
__name(postgresql, "postgresql");

// libs/extensions/src/typeorm/sqlite.ts
function sqlite(options = {}) {
  return {
    options: {
      database: options.uri ?? `':memory:'`,
      type: `'sqlite'`,
      driver: 'require("better-sqlite3")'
    },
    files: {
      "src/extensions/sqlite/execute.ts": execute_default,
      "src/extensions/sqlite/index.ts": `export * from './execute';`
    },
    packages: {}
  };
}
__name(sqlite, "sqlite");

// libs/extensions/src/typeorm/turso.ts
function turso(options = {}) {
  return {
    options: {
      type: `'sqlite'`,
      database: JSON.stringify(options.uri ?? `process.env.CONNECTION_STRING`),
      driver: `require("@libsql/sqlite3")`,
      flags: "0x00000040"
    },
    files: {
      "src/extensions/turso/execute.ts": execute_default,
      "src/extensions/turso/index.ts": `export * from './execute';`
    },
    packages: {
      "@libsql/client": {
        version: "^0.14.0"
      },
      "@libsql/sqlite3": {
        version: "^0.3.1"
      }
    }
  };
}
__name(turso, "turso");

// libs/extensions/src/typeorm/index.ts
function typeorm(config) {
  const props = Object.entries(config.database.options).reduce(
    (acc, [key, value]) => {
      return acc + `${key}: ${value},
`;
    },
    ``
  );
  return {
    packages: {
      typeorm: {
        version: "0.3.20",
        dev: false
      },
      "sql-template-tag": {
        version: "5.2.1",
        dev: false
      },
      ...config.database.packages
    },
    files: {
      ...config.database.files,
      "src/core/data-source.ts": `
import entities from '@workspace/entities';
import { DataSource, DefaultNamingStrategy } from 'typeorm';

class NamingStrategy extends DefaultNamingStrategy {
  override tableName(
    targetName: string,
    userSpecifiedName: string | undefined,
  ): string {
    return super.tableName(userSpecifiedName ?? targetName, undefined);
  }
}

export default new DataSource({
  ${props}
  migrationsRun: true,
  entities: [...entities],
  logging: false, // process.env.NODE_ENV !== 'production'
  synchronize: true, // process.env.NODE_ENV !== 'production'
  namingStrategy: new NamingStrategy(),
});
    `
    }
  };
}
__name(typeorm, "typeorm");
export {
  postgresql,
  sqlite,
  turso,
  typeorm
};
//# sourceMappingURL=index.js.map
