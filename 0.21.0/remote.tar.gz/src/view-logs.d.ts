import { Observable } from 'rxjs';
export declare const logs$: Observable<string>;
export declare function followLogs(next?: boolean): void;
export declare function sse(): Observable<string>;
