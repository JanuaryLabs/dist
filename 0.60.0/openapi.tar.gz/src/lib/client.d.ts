import { type SdkConfig } from '@january/opensdk';
export interface GenerateClient {
    fs: {
        features: string;
        extensions: string;
        tsconfig: string;
    };
    client: SdkConfig;
    primitives: any[];
    zod?: string;
}
export declare function generate({ client, fs, primitives, zod, }: GenerateClient): Promise<void>;
