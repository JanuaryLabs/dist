// libs/extensions/src/identity/authorize.txt
var authorize_default = "import {\n  ProblemDetails,\n  ProblemDetailsException,\n} from 'rfc-7807-problem-details';\n\nexport function authorize<T>(\n  ...routePolicies: ((context: T) => Promise<boolean> | boolean)[]\n) {\n  return async (context: T, next: any) => {\n    for (const policy of routePolicies) {\n      if (!await policy(context)) {\n        throw new ForbiddenException();\n      }\n    }\n    await next();\n  };\n}\n\nexport class UnauthorizedException extends ProblemDetailsException {\n  constructor(detail?: string) {\n    super(\n      new ProblemDetails(\n        'Unauthorized',\n        detail ?? 'Authentication is required to access this resource.',\n        401\n      )\n    );\n    Error.captureStackTrace(this, UnauthorizedException);\n  }\n}\n\nexport class ForbiddenException extends ProblemDetailsException {\n  constructor(detail?: string) {\n    super(\n      new ProblemDetails('Forbidden', detail ?? 'You do not have permission to access this resource.', 403)\n    );\n    Error.captureStackTrace(this, ForbiddenException);\n  }\n}";

// libs/extensions/src/identity/subject.txt
var subject_default = "import { IncomingMessage } from 'http';\nimport { getClientIp } from 'request-ip';\nimport UAParser, { type IResult } from 'ua-parser-js';\n\nexport interface ClientInfo {\n  ip?: string | null;\n  userAgent?: string | null;\n  userAgentData: IResult;\n}\nexport type IdentitySubject = {\n  info: ClientInfo;\n};\n\nexport async function verifyToken(token: string): Promise<boolean> {\n  return true;\n}\n\nexport async function loadSubject(\n  token: string | null | undefined,\n): Promise<IdentitySubject | null> {\n  return null;\n}\n";

// libs/extensions/src/identity/index.ts
var identity = {
  id: "identity",
  packages: {
    "ua-parser-js": {
      version: "^1.0.37",
      dev: false
    },
    "@types/ua-parser-js": {
      version: "^0.7.39",
      dev: true
    },
    "@types/request-ip": {
      version: "^0.0.41",
      dev: true
    },
    "request-ip": {
      version: "^3.3.0",
      dev: false
    }
  },
  files: {
    "src/extensions/identity/authorize.ts": authorize_default,
    "src/extensions/identity/subject.ts": subject_default,
    "src/extensions/identity/index.ts": [
      "export * from './authorize'",
      "export * from './subject'",
      "export * from './policies'"
    ].join("\n")
  }
};
export {
  identity
};
//# sourceMappingURL=index.js.map
