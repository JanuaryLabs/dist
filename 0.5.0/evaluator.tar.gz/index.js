var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/sdk/declarative/src/lib/database.ts
import { cstVisitor, parse, show } from "sql-parser-cst";
import { Project, StructureKind, SyntaxKind } from "ts-morph";

// libs/compiler/sdk/devkit/src/lib/devkit.ts
import { Injectable, ServiceLifetime } from "tiny-injector";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { get } from "lodash";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
function toLiteralObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function removeTrialingSlash(path) {
  return path.replace(/\/$/, "");
}
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlash(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}

// libs/compiler/sdk/devkit/src/lib/data/actions.json
var actions_default = [
  {
    id: "077b1325-0ade-4f63-8f66-ced39cef38ba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Atomic",
    name: "atomic",
    visible: true,
    multi: true,
    allowedActions: [],
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "9c858969-f48b-4b72-8282-bfe82654ae9a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Delete Record",
    name: "delete-record",
    visible: true,
    output: {
      displayName: "deletedRecord",
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    },
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      cascade: {
        displayName: "Cascade",
        type: "boolean",
        defaultValue: true,
        required: true,
        visible: false
      }
    }
  },
  {
    id: "b036bc50-9292-486a-9714-1f551fee5dc4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Record Exist",
    name: "check-record-existance",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "recordExists",
      source: [
        {
          id: "recordExists",
          primitiveType: "boolean",
          displayName: "recordExists"
        }
      ]
    }
  },
  {
    id: "83ce1e80-0117-4ebc-86ac-3bdad3b32796",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Insert Record",
    name: "insert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      columns: {
        displayName: "Payload",
        type: "columns-list",
        required: false,
        source: {
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ],
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "2bb630dd-7ba3-4cda-95a7-f65ee22116ee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Raw SQL Query",
    name: "raw-sql-query",
    metadata: {
      query: {
        displayName: "Query",
        type: "string",
        required: true
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "62e55ba2-9a81-4f88-995e-2093ca3fc067",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Upsert Record",
    name: "upsert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select"
      },
      columns: {
        displayName: "Payload",
        type: "columns-list"
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "a8ded515-b99e-4fca-9654-7d2c12624a7a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "increment-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "b5a5e901-9ef8-4d2c-86f2-39263ca8ebee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "decrement-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    output: {
      type: "context.tableId",
      displayName: "updatedRecord",
      source: []
    },
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Set Fields",
    name: "set-fields",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      columns: {
        displayName: "Field",
        type: "columns-list",
        required: true,
        source: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          },
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ]
        }
      }
    }
  },
  {
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    displayName: "With i18n",
    name: "i18n"
  },
  {
    id: "3c40908c-1c69-4222-a936-7a569a1198b5",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "Upload file to google storage",
    name: "upload-file",
    output: {
      displayName: "uploadedFile",
      source: []
    },
    metadata: {
      multiple: {
        displayName: "Can upload multiple files",
        type: "boolean",
        required: false,
        defaultValue: "@fixed:false"
      },
      maxFileCount: {
        displayName: "Maximum file count",
        type: "number",
        required: false,
        defaultValue: "@fixed:1",
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxTotalSize: {
        displayName: "Maximum total size",
        type: "number",
        required: false,
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxFileSize: {
        displayName: "Maximum file size",
        type: "number",
        required: false
      }
    }
  },
  {
    id: "c4ec127b-e167-4a30-8544-732c55d1bd24",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "List Records",
    name: "list-records",
    metadata: {
      localizable: {
        displayName: "Localizable",
        type: "boolean",
        required: false,
        fieldset: "first",
        visible: false,
        defaultValue: "false"
      },
      pagination: {
        displayName: "Pagination",
        type: "single-select",
        required: true,
        fieldset: "pagination",
        defaultValue: "deferred_joins",
        source: [
          {
            id: "none",
            displayName: "None"
          },
          {
            id: "limit_offset",
            displayName: "Limit & Offset"
          },
          {
            id: "deferred_joins",
            displayName: "Deferred Joins"
          },
          {
            id: "cursor",
            displayName: "Cursor"
          }
        ]
      },
      tableId: {
        displayName: "Table",
        type: "single-select",
        fieldset: "first",
        required: true,
        source: {
          url: "/tables"
        }
      },
      limit: {
        displayName: "Limit",
        type: "number",
        required: false,
        fieldset: "pagination",
        defaultValue: 50
      },
      query: {
        displayName: "Query",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      source: {
        input: "context.pagination",
        operator: "equal",
        value: "none",
        then: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        },
        else: [
          {
            id: "records",
            displayName: "records",
            primitiveType: {
              input: "context.limit",
              operator: "equal",
              value: 1,
              then: "object",
              else: "array"
            },
            typeName: {
              url: "/tables/:id",
              binding: {
                id: "context.tableId"
              },
              use: "displayName"
            },
            interface: {
              url: "/tables/:id/fields",
              binding: {
                id: "context.tableId"
              }
            },
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          },
          {
            id: "meta",
            displayName: "meta",
            typeName: "Meta",
            primitiveType: "object",
            interface: [
              {
                id: "hasNextPage",
                displayName: "hasNextPage",
                primitiveType: "boolean"
              },
              {
                id: "hasPreviousPage",
                displayName: "hasPreviousPage",
                primitiveType: "boolean"
              },
              {
                id: "pageSize",
                displayName: "pageSize",
                primitiveType: "number"
              },
              {
                id: "currentPage",
                displayName: "currentPage",
                primitiveType: "number"
              },
              {
                id: "totalCount",
                displayName: "totalCount",
                primitiveType: "number"
              },
              {
                id: "totalPages",
                displayName: "totalPages",
                primitiveType: "number"
              }
            ],
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          }
        ]
      }
    }
  },
  {
    id: "89ad4cdb-2ed1-4c42-84bd-4986648bbfe2",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "List Files",
    name: "list-files",
    output: {
      displayName: "files",
      source: []
    },
    metadata: {
      prefix: {
        displayName: "Prefix",
        type: "string",
        required: false,
        fieldset: "first"
      },
      flat: {
        displayName: "Flat",
        type: "boolean",
        required: false,
        fieldset: "first"
      }
    }
  },
  {
    id: "43ea3f72-f3b0-419f-abef-f1bd4b5e9b22",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Custom Code",
    name: "custom-code",
    output: {
      source: []
    },
    metadata: {
      code: {
        displayName: "Code",
        type: "code-editor",
        required: true,
        extras: {
          language: "typescript"
        }
      }
    }
  },
  {
    id: "e0c60892-6b26-417e-8140-8e8d31f64ab2",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Branch",
    name: "branch",
    type: "branch",
    multi: true,
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "89e16a38-25f1-444e-bcf7-96e6455c3707",
    extensionId: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    displayName: "Send Email",
    name: "send-email",
    output: {
      outputName: "sentEmail",
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        required: true,
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        required: true,
        fieldset: "email"
      },
      replayTo: {
        displayName: "Replay To",
        type: "string",
        required: false
      },
      subject: {
        displayName: "Subject",
        type: "string",
        required: true,
        fieldset: "content"
      },
      templateId: {
        displayName: "Template",
        type: "string",
        fieldset: "content",
        required: true
      }
    }
  },
  {
    id: "69a01ada-a83a-451f-a3fe-fb486e08ffa9",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Send Email",
    name: "resend-send-email",
    output: {
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      subject: {
        displayName: "Subject",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "content"
      },
      text: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      html: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "c292a9d7-1f66-47b9-b366-e25f3faff840",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Create Contact",
    name: "resend-create-contact",
    output: {
      source: []
    },
    metadata: {
      firstName: {
        displayName: "First name",
        type: "string",
        fieldset: "general"
      },
      lastName: {
        displayName: "Last name",
        type: "string",
        required: false,
        fieldset: "general"
      },
      email: {
        displayName: "Email",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      unsubscribed: {
        displayName: "Unsubscribed",
        type: "string",
        required: false,
        fieldset: "email"
      },
      audienceId: {
        displayName: "Audience id",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b",
    extensionId: "389d81cd-5b58-4ade-b815-add468c48e37",
    displayName: "Ajax",
    name: "ajax",
    output: {
      source: []
    },
    metadata: {
      url: {
        displayName: "URL",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      method: {
        displayName: "Method",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      body: {
        displayName: "Body",
        type: "json",
        required: false
      }
    }
  },
  {
    id: "7a9d9a29-7079-4aa8-bdc0-d93a713a2440",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger",
    metadata: {
      path: {
        fieldset: "config",
        type: "string",
        displayName: "Path",
        required: true,
        pattern: "^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"
      },
      method: {
        fieldset: "config",
        displayName: "Method",
        type: "single-select",
        source: [
          {
            id: "get",
            displayName: "GET"
          },
          {
            id: "post",
            displayName: "POST"
          },
          {
            id: "put",
            displayName: "PUT"
          },
          {
            id: "patch",
            displayName: "PATCH"
          },
          {
            id: "delete",
            displayName: "DELETE"
          },
          {
            id: "head",
            displayName: "HEAD"
          }
        ],
        required: true
      },
      contentType: {
        visible: false,
        fieldset: "optional",
        type: "single-select",
        displayName: "Content Type",
        required: false,
        source: [
          {
            id: "application/json",
            displayName: "application/json"
          },
          {
            id: "application/x-www-form-urlencoded",
            displayName: "application/x-www-form-urlencoded"
          },
          {
            id: "multipart/form-data",
            displayName: "multipart/form-data"
          }
        ]
      },
      summary: {
        fieldset: "optional",
        type: "string",
        displayName: "Summary",
        required: false,
        visible: false
      }
    }
  },
  {
    id: "0aec7685-5c19-43eb-bc2c-93597b5cecfc",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    id: "7b1696e9-9c89-4ba7-abc0-e1448b287772",
    extensionId: "9c034274-069e-4567-ab33-bab8f31f874c",
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    id: "cd76caa3-e9f0-49b8-bf7a-0ebed83bd486",
    extensionId: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/extensions.json
var extensions_default = [
  {
    id: "e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b",
    visible: false,
    name: "soft-delete",
    categories: ["soft-delete"],
    title: "",
    subtitle: "Support Soft Delete functionality in any table.",
    description: "Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.",
    tableMetadata: {
      tableId: {
        displayName: "Support Soft Delete",
        required: false,
        visible: false,
        type: "single-select",
        source: [
          {
            id: "none",
            displayName: "No soft delete"
          },
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag"
          },
          {
            id: "trash",
            displayName: "Using trash table"
          }
        ]
      }
    },
    metadata: {},
    packages: []
  },
  {
    id: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    visible: true,
    name: "core",
    categories: ["misc"],
    title: "Core",
    subtitle: "Core functionality",
    metadata: {},
    description: "Essential functionality that is required for all projects.",
    packages: [
      {
        name: "rfc-7807-problem-details",
        version: "^1.1.0"
      },
      {
        name: "ajv",
        version: "8.12.0"
      },
      {
        name: "ajv-formats",
        version: "2.1.1"
      },
      {
        name: "ajv-errors",
        version: "3.0.0"
      },
      {
        name: "ajv-keywords",
        version: "5.1.0"
      },
      {
        name: "validator",
        version: "13.9.0"
      },
      {
        name: "lodash-es",
        version: "^4.17.21"
      },
      {
        name: "@types/lodash-es",
        version: "^4.17.12",
        dev: true
      },
      {
        name: "http-status-codes",
        version: "2.2.0"
      },
      {
        name: "@types/node",
        version: "^20.11.26",
        dev: true
      },
      {
        name: "typescript",
        version: "^4.9.4",
        dev: true
      },
      {
        name: "@types/validator",
        version: "13.7.17",
        dev: true
      }
    ]
  },
  {
    id: "977a059f-ddda-4677-b785-4d1b04a7c201",
    visible: true,
    name: "prettier",
    categories: ["misc"],
    title: "Prettier",
    subtitle: "An opinionated code formatter",
    description: "Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.",
    logo: "assets/prettier.png",
    metadata: {},
    packages: [
      {
        name: "prettier",
        version: "3.3.2",
        dev: true
      }
    ]
  },
  {
    id: "e81b26bb-051b-4b30-a94d-e34ad615504c",
    visible: true,
    name: "identity",
    categories: ["misc"],
    title: "identity",
    subtitle: "identity",
    description: "",
    metadata: {},
    packages: [
      {
        name: "ua-parser-js",
        version: "^1.0.37"
      },
      {
        name: "@types/ua-parser-js",
        version: "^0.7.39",
        dev: true
      },
      {
        name: "@types/request-ip",
        version: "^0.0.41",
        dev: true
      },
      {
        name: "request-ip",
        version: "^3.3.0"
      }
    ]
  },
  {
    id: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "postgresql",
    categories: ["database"],
    main: "execute.ts",
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "PostgreSQL",
    subtitle: "A free and open-source relational database management system emphasizing extensibility and SQL compliance.",
    description: "PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.",
    logo: "assets/postgresql.svg",
    packages: [
      { name: "typeorm", version: "0.3.20" },
      { name: "pg", version: "8.11.5" },
      { name: "sql-template-tag", version: "5.2.1" }
    ]
  },
  {
    id: "71c97a1c-3efe-4712-b35b-56714dafa02f",
    name: "mysql",
    categories: ["database"],
    disabled: true,
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "MySQL",
    description: "MySQL is an open-source relational database management system.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    name: "firebase-functions",
    categories: ["hosting"],
    disabled: true,
    logo: "assets/firebase-functions.png",
    svg: "SiFirebase",
    title: "Firebase Functions",
    subtitle: "Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code",
    description: "Firebase Functions is a serverless framework that lets you automatically run backend code.",
    metadata: {
      FIREBASE_FUNCTION_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"
      }
    },
    packages: [
      {
        name: "firebase-functions",
        version: "^5.0.1"
      },
      {
        name: "firebase-admin",
        version: "^12.4.0"
      }
    ]
  },
  {
    id: "d9e83836-e41d-4ae2-aa93-229a0ef27069",
    name: "firebase-auth",
    categories: ["identity"],
    disabled: false,
    main: "firebase.ts",
    metadata: {
      FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"
      }
    },
    title: "Firebase Authentication",
    description: "Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.",
    subtitle: "Authenticate users with Firebase",
    packages: [
      {
        name: "firebase-admin",
        version: "^12.4.0"
      },
      {
        name: "ua-parser-js",
        version: "^1.0.37"
      },
      {
        name: "@types/ua-parser-js",
        version: "^0.7.39",
        dev: true
      },
      {
        name: "@types/request-ip",
        version: "^0.0.41",
        dev: true
      },
      {
        name: "request-ip",
        version: "^3.3.0"
      }
    ]
  },
  {
    id: "34d9ec05-de0d-4d79-ae2a-9a06200d20dd",
    name: "fly",
    categories: ["hosting"],
    logo: "assets/fly.png",
    title: "Fly",
    description: "Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.",
    metadata: {
      FLY_API_TOKEN: {
        displayName: "Deploy Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_API_TOKEN",
        description: "The token to deploy the app"
      },
      FLY_APP_NAME: {
        displayName: "App Name",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_APP_NAME",
        description: "The name of the app"
      }
    }
  },
  {
    name: "vercel",
    id: "4c82c872-1a2f-4849-98a6-bd7017498191",
    categories: ["hosting"],
    title: "Vercel",
    description: "Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.",
    metadata: {
      VERCEL_ORG_ID: {
        displayName: "Org ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_ORG_ID"
      },
      VERCEL_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_PROJECT_ID"
      },
      VERCEL_API_TOKEN: {
        displayName: "API Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_API_TOKEN"
      }
    }
  },
  {
    id: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    name: "hono",
    categories: ["routing"],
    title: "Hono.dev",
    description: "Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.",
    metadata: {},
    packages: [
      {
        name: "hono",
        version: "^4.4.0"
      },
      {
        name: "@hono/node-server",
        version: "^1.11.1"
      },
      {
        name: "@scalar/hono-api-reference",
        version: "^0.5.145"
      }
    ]
  },
  {
    id: "109aa1af-f9d0-4d31-bbc6-c4603be5b7b0",
    name: "koajs",
    disabled: true,
    categories: ["routing"],
    title: "Koa.js",
    description: "Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.",
    logo: "assets/http.svg",
    metadata: {},
    svg: "SiKoa",
    packages: [
      {
        name: "koa",
        version: "latest"
      },
      {
        name: "koa-static",
        version: "latest"
      },
      {
        name: "@types/koa-static",
        version: "latest"
      },
      {
        name: "@koa/router",
        version: "latest"
      },
      {
        name: "koa-body",
        version: "latest"
      },
      {
        name: "koa-bodyparser",
        version: "latest"
      },
      {
        name: "koa-logger",
        version: "latest"
      },
      {
        name: "koa-qs",
        version: "latest"
      },
      {
        name: "@koa/cors",
        version: "latest"
      },
      {
        name: "@types/koa-logger",
        version: "latest"
      },
      {
        name: "@types/koa__cors",
        version: "^3.3.0"
      },
      {
        name: "@types/koa__router",
        version: "^12.0.0"
      },
      {
        name: "@types/koa-bodyparser",
        version: "^4.3.10"
      },
      {
        name: "@types/koa-qs",
        version: "^2.0.0"
      },
      {
        name: "swagger-ui-dist",
        version: "latest"
      },
      {
        name: "@types/swagger-ui-dist",
        version: "latest"
      }
    ]
  },
  {
    id: "3633c476-c120-4f9f-893b-b6b03f67b9e9",
    name: "expressjs",
    svg: "SiExpress",
    disabled: true,
    categories: ["routing"],
    title: "Express.js",
    description: "Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
    logo: "assets/http.svg",
    metadata: {},
    packages: [
      {
        name: "express",
        version: "latest"
      },
      {
        name: "body-parser",
        version: "latest"
      },
      {
        name: "morgan",
        version: "latest"
      },
      {
        name: "cors",
        version: "latest"
      },
      {
        name: "@types/express",
        version: "latest",
        dev: true
      },
      {
        name: "@types/body-parser",
        version: "latest",
        dev: true
      },
      {
        name: "@types/cors",
        version: "latest",
        dev: true
      },
      {
        name: "@types/morgan",
        version: "latest",
        dev: true
      }
    ]
  },
  {
    id: "3e184f8b-d2dc-4592-9507-979d649277f5",
    visible: true,
    name: "google-cloud-storage",
    categories: ["file-storage"],
    logo: "assets/cloud-storage.svg",
    title: "Google Cloud Storage",
    description: "Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google's cloud with advanced security and sharing capabilities.",
    metadata: {
      BUCKET_NAME: {
        _comment: "// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won't work",
        displayName: "Bucket Name",
        type: "string",
        required: true,
        description: "The name of the bucket"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        type: "json",
        description: "The service account key to access the bucket",
        required: true
      }
    },
    packages: [
      {
        name: "@google-cloud/storage",
        version: "7.11.2"
      },
      {
        name: "formidable",
        version: "3.5.1"
      },
      {
        name: "@types/formidable",
        version: "3.4.5",
        dev: true
      },
      {
        name: "mime",
        version: "4.0.3"
      }
    ]
  },
  {
    id: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    visible: true,
    disabled: true,
    name: "mailer-send",
    categories: ["mail"],
    logo: "assets/mailer-send.svg",
    title: "Mailer Send",
    description: "MailerSend is a transactional email API built by the team behind MailerLite. It's a scalable, reliable, and easy-to-use way to send emails via SMTP or API.",
    metadata: {
      MAILER_SEND_API_KEY: {
        displayName: "API Key",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    visible: true,
    name: "resend",
    main: "resend.ts",
    categories: ["mail"],
    logo: "assets/resend.jpeg",
    title: "Resend",
    description: "The best API to reach humans instead of spam folders. Build, test, and deliver transactional emails at scale.",
    metadata: {
      RESEND_API_KEY: {
        displayName: "API Key",
        defaultValue: "@process:env.RESEND_API_KEY",
        type: "string",
        required: true,
        description: "The API key to access the service"
      }
    },
    packages: [
      {
        name: "resend",
        version: "1.0.0"
      }
    ]
  },
  {
    id: "9c034274-069e-4567-ab33-bab8f31f874c",
    visible: true,
    name: "github",
    categories: [],
    title: "GitHub Webhooks",
    description: "GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com",
    metadata: {
      WEBHOOK_SECRET: {
        displayName: "Webhook Secret",
        defaultValue: "@process:env.WEBHOOK_SECRET",
        type: "string",
        required: true
      }
    },
    packages: [
      {
        name: "@octokit/webhooks",
        version: "^13.2.7"
      }
    ]
  },
  {
    id: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    visible: true,
    name: "node-cron",
    categories: ["schedulers"],
    title: "Node Cron",
    description: "A simple cron-like job scheduler for Node.js",
    metadata: {},
    packages: [
      {
        name: "@types/node-cron",
        version: "^3.0.11",
        dev: true
      },
      {
        name: "node-cron",
        version: "^3.0.3"
      }
    ]
  },
  {
    id: "389d81cd-5b58-4ade-b815-add468c48e37",
    visible: true,
    disabled: true,
    name: "ajax",
    categories: ["misc"],
    logo: "assets/ajax.png",
    title: "Ajax",
    description: "Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.",
    metadata: {},
    svg: "SiAjax"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/operators.json
var operators_default = [
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Equal To",
    name: "equals",
    metadata: {}
  },
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Not Equal To",
    name: "not_equals",
    metadata: {}
  },
  {
    id: "f3d3c1af-0066-4884-8533-917ec2c71fd1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "One Of",
    name: "one_of",
    metadata: {}
  },
  {
    id: "f56f9948-7745-4203-928f-e75c481d13d8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Between",
    name: "between",
    metadata: {}
  },
  {
    id: "c2e22f65-ce15-42cc-a99f-7e5bca84b69f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "63ec8fb7-357f-403a-b753-6df8a3f25737",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "More Than",
    name: "more_than",
    metadata: {}
  },
  {
    id: "162eedc3-3ace-48c2-8a38-0c1db9058d8a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    name: "contains",
    metadata: {}
  },
  {
    id: "60e18406-a4a7-44a4-8b91-2481710fb4e8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    name: "starts_with",
    metadata: {}
  },
  {
    id: "d3b7f462-d154-4bfa-8645-3f74a958bed6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    name: "ends_with",
    metadata: {}
  },
  {
    id: "d1a02de2-8928-4517-884d-502bdb8d8409",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "fa2b1831-9ceb-4808-984e-1f834a723c56",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Greater Than",
    name: "greater-than",
    metadata: {}
  },
  {
    id: "a2c10af5-c9dd-401c-b28c-59bb48c85345",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Not Empty",
    name: "is_not_empty",
    metadata: {}
  },
  {
    id: "8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Empty",
    name: "is_empty",
    metadata: {}
  },
  {
    id: "73963f47-092a-4bf2-a38a-50dca50ca5e6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before",
    name: "before",
    metadata: {}
  },
  {
    id: "a830cb78-e9f2-4259-9753-d6259bea1bed",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before On",
    name: "before_on",
    metadata: {}
  },
  {
    id: "d23be707-a71d-44bd-8b61-9489e84f1a2d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After On",
    name: "after_on",
    metadata: {}
  },
  {
    id: "8648374e-f78a-4322-ac67-67467d4fbff5",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After",
    name: "after",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
var DevKit = class {
  typesResolverMap = {
    date: "Date"
  };
  assignDefaults(metadata, details) {
    Object.entries(metadata ?? {}).forEach(([name, config]) => {
      if (details[name] === void 0 && config.defaultValue !== void 0) {
        details[name] = config.defaultValue;
      }
    });
    return details;
  }
  getDeps() {
    const exts = this.extensions();
    const dependencies = exts.map((it) => it.packages ?? []).flat();
    const possibleDeps = [
      {
        name: "discord.js",
        version: "^14.15.3",
        dev: false
      }
    ];
    return [...dependencies, ...possibleDeps].reduce((acc, it) => {
      return {
        ...acc,
        [it.name]: it.version
      };
    }, {});
  }
  async getSourceActionByName(name) {
    if (isNullOrUndefined(name)) {
      throw new Error(
        "getSourceActionByName:name is required. received: " + name
      );
    }
    const action2 = (await this.actions()).find((it) => it.name === name);
    if (!action2) {
      throw new Error(`Action with name ${name} not found`);
    }
    return action2;
  }
  getSourceActionById(id) {
    const action2 = this.actions().find((it) => it.id === id);
    if (!action2) {
      throw new Error(`Action with id ${id} not found`);
    }
    return action2;
  }
  getExtensionActions(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return actions_default.filter((it) => it.extensionId === id);
  }
  actions() {
    return actions_default;
  }
  async getExtensionTriggers(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return (await this.triggers()).filter((it) => it.extensionId === id);
  }
  getExtensionById(id) {
    const item = this.extensions().find((it) => it.id === id);
    if (!item) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return item;
  }
  async triggers() {
    return (await this.actions()).filter((it) => it.type === "trigger");
  }
  extensions() {
    return extensions_default;
  }
  getExtensionByName(name) {
    const item = this.extensions().find((it) => it.name === name);
    if (!item) {
      throw new Error(`Extension with name ${name} not found`);
    }
    return item;
  }
  toJson(obj) {
    return JSON.stringify(obj, null, 2);
  }
  async getTriggerById(id) {
    const trigger2 = (await this.triggers()).find((it) => it.id === id);
    if (!trigger2) {
      throw new Error(`Trigger with id ${id} not found`);
    }
    return trigger2;
  }
  async getTriggerByName(name) {
    const trigger2 = (await this.actions()).find(
      (it) => it.type === "trigger" && it.name === name
    );
    if (!trigger2) {
      throw new Error(`Trigger with name ${name} not found`);
    }
    return trigger2;
  }
  async getValidationById(id) {
    const validation2 = (await this.validations()).find((it) => it.id === id);
    if (!validation2) {
      throw new Error(`Validation with id ${id} not found`);
    }
    return validation2;
  }
  async getValidationsByIds(ids) {
    const validations2 = await this.validations();
    const list = [];
    for (const id of ids) {
      const validation2 = validations2.find((it) => it.id === id);
      if (!validation2) {
        throw new Error(`Validation with id ${id} not found`);
      }
      list.push(validation2);
    }
    return list;
  }
  async getValidationsByNames(names) {
    const validations2 = await this.validations();
    const list = [];
    for (const name of names) {
      const validation2 = validations2.find((it) => it.name === name);
      if (!validation2) {
        throw new Error(`Validation with name ${name} not found`);
      }
      list.push(validation2);
    }
    return list;
  }
  async getValidationByName(name) {
    const validation2 = await this.validations().find((a) => a.name === name);
    if (!validation2) {
      throw new Error(`Validation with name ${name} not found`);
    }
    return validation2;
  }
  async getSourceFieldById(id) {
    const field2 = (await this.getFieldsByExtension()).find(
      (it) => it.id === id
    );
    if (!field2) {
      throw new Error(`Field with id ${id} not found`);
    }
    return field2;
  }
  async getSourceFieldByName(name) {
    const field2 = (await this.getFieldsByExtension()).find(
      (it) => it.name === name
    );
    if (!field2) {
      throw new Error(`Field with name ${name} not found`);
    }
    return field2;
  }
  async getFieldsByExtension() {
    return await this.fields();
  }
  fields() {
    return fields_default;
  }
  validations() {
    return validations_default;
  }
  operators() {
    return operators_default;
  }
  substring(input2, sub) {
    const index2 = input2.indexOf(sub);
    if (index2 === -1) {
      return input2;
    }
    return input2.slice(sub.length);
  }
  toLiteralObject(obj) {
    if (Array.isArray(obj)) {
      return toLiteralObject(Object.fromEntries(obj), (value) => {
        try {
          if ("value" in value) {
            return value.value;
          }
        } catch (e) {
          return value;
        }
      });
    }
    return toLiteralObject(obj, (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
};
DevKit = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], DevKit);

// libs/compiler/sdk/devkit/src/lib/project-config.ts
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var _config;
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config
    });
  }
};
_config = new WeakMap();
ProjectConfig = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable3, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
var ProjectFS = class {
  constructor(_projectConfig) {
    this._projectConfig = _projectConfig;
  }
  routersGlob() {
    return this._projectConfig.getConfig().features + "/**/*.router.ts";
  }
  listenersGlob() {
    return this._projectConfig.getConfig().features + "/**/*.github.ts";
  }
  cronsGlob() {
    return this._projectConfig.getConfig().features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return this._projectConfig.getConfig().features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join2(
      "#{relative}",
      this._projectConfig.getConfig().basePath,
      importPath
    );
  };
  makeEntityImportSpecifier = (tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  };
  makeFeaturePath = (fileName) => join2(this._projectConfig.getConfig().features, fileName);
  makeFeatureFile = (featureName, fileName) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(featureName),
    fileName
  );
  makeCorePath = (fileName) => join2(this._projectConfig.getConfig().basePath, "core", fileName);
  makeIdentityPath = (fileName) => join2(this._projectConfig.getConfig().basePath, "identity", fileName);
  makeSrcPath = (fileName) => join2(this._projectConfig.getConfig().basePath, fileName);
  makeWorkspacePath = (fileName) => join2(
    this._projectConfig.getConfig().basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join2(this._projectConfig.getConfig().basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix) => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeEntityPath = (featureName, tableName, suffix) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  );
  makeQueryPath = (tableName, queryName) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], ProjectFS);
var makeEntityImportSpecifier = (tableName) => {
  return join2("#{entity}", pascalcase(tableName));
};

// libs/sdk/declarative/src/lib/functional.ts
function input(value) {
  if (typeof value === "number" || typeof value === "boolean" || value === null) {
    return input.primitive(value);
  }
  if (value.startsWith("context") || value.startsWith("workflow")) {
    return input.workflow(value.replace("context.", ""));
  }
  if (value.startsWith("trigger")) {
    return input.trigger(value.replace("trigger.", ""));
  }
  if (!value.startsWith("@")) {
    return input.primitive(value);
  }
  return {
    input: value
  };
}
((input2) => {
  function primitive(value) {
    return {
      input: `@fixed:${typeof value === "boolean" || typeof value === "number" || value === null ? value : `'${value}'`}`
    };
  }
  input2.primitive = primitive;
  function workflow2(path) {
    return {
      input: `@workflow:${path}`
    };
  }
  input2.workflow = workflow2;
  function trigger2(path) {
    return {
      input: `@trigger:${path}`
    };
  }
  input2.trigger = trigger2;
  function field2(name) {
    return {
      input: `@tables:fields.${name}`
    };
  }
  input2.field = field2;
})(input || (input = {}));

// libs/compiler/transpilers/src/lib/ast.ts
import { camelcase as camelcase2 } from "stringcase";

// libs/compiler/transpilers/src/lib/expression.ts
var QueryBuilder;
((QueryBuilder2) => {
  class Expression {
  }
  QueryBuilder2.Expression = Expression;
  function createBooleanLiteral(value) {
    return {
      value,
      type: "boolean",
      accept(visitor, context) {
        return visitor.visitBooleanLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createBooleanLiteral = createBooleanLiteral;
  function createDateLiteral(value) {
    return {
      value,
      type: "date",
      accept(visitor, context) {
        return visitor.visitDateLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createDateLiteral = createDateLiteral;
  function createStringLiteral(value, defaultContext) {
    return {
      value,
      type: "string",
      accept(visitor, context = defaultContext) {
        return visitor.visitStringLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createStringLiteral = createStringLiteral;
  function createNumericLiteral(value) {
    return {
      value,
      type: "numeric",
      accept(visitor, context) {
        return visitor.visitNumericLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNumericLiteral = createNumericLiteral;
  function createNullLiteral(defaultContext) {
    return {
      type: "null",
      accept(visitor, context = defaultContext) {
        return visitor.visitNullLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNullLiteral = createNullLiteral;
  function createIdentifier(value, defaultContext) {
    return {
      value,
      type: "identifier",
      accept(visitor, context) {
        return visitor.visitIdentifier(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createIdentifier = createIdentifier;
  function createCombinator(operator) {
    return {
      operator,
      type: "combinator",
      accept(visitor, context) {
        return visitor.visitCombinator(this, context);
      }
    };
  }
  QueryBuilder2.createCombinator = createCombinator;
  function createBinaryExpression(left, operator, right, defaultContext) {
    return {
      type: "binary",
      left,
      operator,
      right,
      accept(visitor, context = defaultContext) {
        return visitor.visitBinaryExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createBinaryExpression = createBinaryExpression;
  function createGroupExpression(list, combinator, defaultContext) {
    return {
      type: "group",
      combinator,
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitGroupExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createGroupExpression = createGroupExpression;
  function createQuerySelectExpression(groups, defaultContext) {
    return {
      type: "querySelect",
      value: groups,
      accept(visitor, context = defaultContext) {
        return visitor.visitQuerySelectExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createQuerySelectExpression = createQuerySelectExpression;
  function createListExpression(list, defaultContext) {
    return {
      type: "list",
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitListExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createListExpression = createListExpression;
})(QueryBuilder || (QueryBuilder = {}));

// libs/compiler/transpilers/src/lib/factory.ts
var QueryFactory;
((QueryFactory2) => {
  function createEmptyGroupRule() {
    return {
      data: [],
      operator: "group",
      input: ["and"]
    };
  }
  QueryFactory2.createEmptyGroupRule = createEmptyGroupRule;
  function createGroupRule(combinator, data) {
    return {
      input: [combinator],
      operator: "group",
      data
    };
  }
  QueryFactory2.createGroupRule = createGroupRule;
  function createSelectRule(groups, columns) {
    return {
      operator: "querySelect",
      input: columns ?? [],
      data: groups
    };
  }
  QueryFactory2.createSelectRule = createSelectRule;
  function createIsEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsEmptyRule = createIsEmptyRule;
  function createIsNotEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotEmptyRule = createIsNotEmptyRule;
  function createEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createEqualRule = createEqualRule;
  function createGreaterThanRule(input2, data) {
    return {
      operator: "more_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanRule = createGreaterThanRule;
  function createGreaterThanEqualRule(input2, data) {
    return {
      operator: "more_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanEqualRule = createGreaterThanEqualRule;
  function createLessThanRule(input2, data) {
    return {
      operator: "less_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanRule = createLessThanRule;
  function createLessThanEqualRule(input2, data) {
    return {
      operator: "less_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanEqualRule = createLessThanEqualRule;
  function createIsRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsRule = createIsRule;
  function createIsNotRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotRule = createIsNotRule;
  function createNotEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotEqualRule = createNotEqualRule;
  function createOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createOneOfRule = createOneOfRule;
  function createNotOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotOneOfRule = createNotOneOfRule;
  function createBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createBetweenRule = createBetweenRule;
  function createNotBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotBetweenRule = createNotBetweenRule;
  function createContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createContainRule = createContainRule;
  function createMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createMatchRule = createMatchRule;
  function createNotMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotMatchRule = createNotMatchRule;
  function createNotContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotContainRule = createNotContainRule;
  function createStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createStartsWithRule = createStartsWithRule;
  function createNotStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotStartsWithRule = createNotStartsWithRule;
  function createEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createEndsWithRule = createEndsWithRule;
  function createNotEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotEndsWithRule = createNotEndsWithRule;
  function createPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: false
      }
    };
  }
  QueryFactory2.createPeriodRule = createPeriodRule;
  function createNotPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: true
      }
    };
  }
  QueryFactory2.createNotPeriodRule = createNotPeriodRule;
})(QueryFactory || (QueryFactory = {}));

// libs/sdk/declarative/src/lib/utils.ts
function getErrors(fn) {
  try {
    fn();
    return [];
  } catch (e) {
    return [e].flat();
  }
}
function coerceString(value) {
  if (value === void 0 || value === null) {
    return value;
  }
  if (typeof value === "number") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.join(".");
  }
  return value.valueOf();
}

// libs/sdk/declarative/src/lib/query.ts
function where(column, operator, value) {
  const columnName = coerceColumnName(column);
  let condition;
  value = coerceString(value);
  switch (operator) {
    case "after":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "after",
        value
      );
      break;
    case "before":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "before",
        value
      );
      break;
  }
  if (condition) {
    return {
      kind: "condition",
      implementation: condition
    };
  }
  if (typeof value !== "string") {
    throw new Error(`Value ${value} is not supported`);
  }
  const data = {
    type: "string",
    input: value
  };
  switch (operator) {
    case "equals":
      condition = QueryFactory.createEqualRule([columnName], data);
      break;
    case "not_equals":
      condition = QueryFactory.createNotEqualRule([columnName], data);
      break;
    case "more_than":
      condition = QueryFactory.createGreaterThanRule([columnName], data);
      break;
    case "less_than":
      condition = QueryFactory.createLessThanRule([columnName], data);
      break;
    case "more_than_or_equal":
      condition = QueryFactory.createGreaterThanEqualRule([columnName], data);
      break;
    case "less_than_or_equal":
      condition = QueryFactory.createLessThanEqualRule([columnName], data);
      break;
    case "is":
      condition = QueryFactory.createIsRule([columnName], data);
      break;
    case "is_not_empty":
      condition = QueryFactory.createIsNotEmptyRule([columnName], data);
      break;
    case "is_empty":
      condition = QueryFactory.createIsEmptyRule([columnName], data);
      break;
    case "contains":
      condition = QueryFactory.createContainRule([columnName], data);
      break;
    case "starts_with":
      condition = QueryFactory.createStartsWithRule([columnName], data);
      break;
    case "ends_with":
      condition = QueryFactory.createEndsWithRule([columnName], data);
      break;
    default:
      throw new Error(`Operator ${operator} is not supported`);
  }
  return {
    kind: "condition",
    implementation: condition
  };
}
function sort(name, input2) {
  return {
    kind: "sort",
    implementation: {
      id: coerceColumnName(name),
      input: input2.startsWith("@fixed") ? input2 : `@fixed:${input2}`
    }
  };
}
function isKind(featureOrKind, kind) {
  if (!featureOrKind) {
    return false;
  }
  if (typeof featureOrKind === "string") {
    return (feature2) => feature2 && feature2.kind === featureOrKind;
  }
  return featureOrKind.kind === kind;
}
function query(...features) {
  const sorts = features.filter(isKind("sort"));
  const columns = features.filter((f) => f.kind === "select").map((f) => f.implementation);
  const conditions = features.filter(isKind("condition"));
  const groups = [
    ...features.filter((f) => f.kind === "group"),
    and(...conditions)
    // wrap this in an "and" group to simulate implicit "and" condition
  ].map((f) => f.implementation);
  const limit2 = features.find(isKind("limit"))?.implementation;
  return {
    whereBy: QueryFactory.createSelectRule(groups, columns),
    sortBy: sorts.map((it) => it.implementation),
    limit: limit2
  };
}
query.sql = (sql) => {
};
function select(name) {
  return {
    kind: "select",
    implementation: {
      name
    }
  };
}
function and(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("and", rules)
  };
}
function or(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("or", rules)
  };
}
var coerceColumnName = (column) => {
  if (!column.startsWith("@tables")) {
    return `@tables:fields.${column}`;
  }
  return column;
};
var date;
((date2) => {
  let after;
  ((after2) => {
    function startOfThisWeek() {
      return weeksAgo(0);
    }
    after2.startOfThisWeek = startOfThisWeek;
    function weekAgo() {
      return weeksAgo(1);
    }
    after2.weekAgo = weekAgo;
    function weeksAgo(amount, relativeTo = "now") {
      return {
        period: "week",
        amount: -Math.abs(amount),
        relativeTo
      };
    }
    after2.weeksAgo = weeksAgo;
    function weekInYear(n, relativeTo = "now") {
    }
    function monthInYear(n) {
    }
    function startOfThisMonth() {
      return monthsAgo(0);
    }
    after2.startOfThisMonth = startOfThisMonth;
    function monthAgo() {
      return monthsAgo(1);
    }
    after2.monthAgo = monthAgo;
    function monthsAgo(amount) {
      return {
        period: "month",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.monthsAgo = monthsAgo;
    function startOfThisYear() {
      return yearsAgo(0);
    }
    after2.startOfThisYear = startOfThisYear;
    function yearAgo() {
      return yearsAgo(1);
    }
    after2.yearAgo = yearAgo;
    function yearsAgo(amount) {
      return {
        period: "year",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.yearsAgo = yearsAgo;
  })(after = date2.after || (date2.after = {}));
})(date || (date = {}));
function limit(upTo) {
  return {
    kind: "limit",
    implementation: upTo
  };
}

// libs/sdk/declarative/src/lib/database.ts
function defineAction(config) {
  return {
    type: config.type,
    config: config.config
  };
}
function action(transferable, config) {
  let body = "return true";
  const guard = transferable.toString();
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "guard.ts",
    `const guard = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  let guardFunction = sourceFile.getVariableDeclarationOrThrow("guard").getInitializerIfKind(SyntaxKind.ArrowFunction);
  if (!guardFunction) {
    guardFunction = sourceFile.set({
      statements: [`const guard = ()=>${guard}`]
    }).getVariableDeclarationOrThrow("guard").getInitializerIfKindOrThrow(SyntaxKind.ArrowFunction);
  }
  const inputs = [];
  const stepsUses = guardFunction.getDescendantsOfKind(SyntaxKind.Identifier).filter((identifier) => identifier.getText() === "steps");
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind.Identifier).filter((identifier) => identifier.getText() === triggerIdentifierText);
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const stepUse of stepsUses) {
    const parent = stepUse.getParentWhileKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!parent) {
      continue;
    }
    const usageText = parent.getText();
    const [namespace, stepName, ...rest] = usageText.split(".");
    inputs.push(
      `@workflow:${camelcase(`${stepName}Output`)}.${rest.join(".")}`
    );
    const key = rest.at(-1);
    parent.replaceWithText(key);
  }
  for (const triggerUse of triggerUses) {
    const parent = triggerUse.getParentWhileKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!parent) {
      continue;
    }
    const usageText = parent.getText();
    const [namespace, ...rest] = usageText.split(".");
    inputs.push(`@${namespace}:${rest.join(".")}`);
    const key = rest.at(-1);
    parent.replaceWithText(`input.${key}`);
  }
  body = guardFunction.getBodyText();
  return defineAction({
    type: "custom-code",
    config: {
      structures: tables,
      ...config ?? {},
      inline: config?.inline ?? false,
      code: body,
      inputs: inputs.reduce(
        (acc, it) => ({
          ...acc,
          [it.split(".").at(-1)]: input(it)
        }),
        {}
      )
    }
  });
}
((action2) => {
  let core;
  ((core2) => {
    function raw(config) {
      return action2(config.code, {
        inline: config.inline
      });
    }
    core2.raw = raw;
    function branch(config) {
      const fallback = {
        id: "fallback",
        name: "fallback",
        rule: ""
      };
      const paths = Object.entries(config.paths).map(([name, rule]) => {
        return {
          id: crypto.randomUUID(),
          name,
          rule
        };
      });
      return defineAction({
        type: "branch",
        config: {
          ...config,
          paths: [fallback, ...paths]
        }
      });
    }
    core2.branch = branch;
  })(core = action2.core || (action2.core = {}));
  let unstable_discord;
  ((unstable_discord2) => {
    function send(config) {
      return action2(
        `
           const webhook = new WebhookClient('${config.webhook}');
           await webhook.send(${JSON.stringify(config.message)});
      `,
        {
          structures: [
            {
              kind: StructureKind.ImportDeclaration,
              moduleSpecifier: "discord.js",
              namedImports: ["WebhookClient"]
            }
          ]
        }
      );
    }
    unstable_discord2.send = send;
  })(unstable_discord = action2.unstable_discord || (action2.unstable_discord = {}));
  let database;
  ((database2) => {
    database2.list = listRecord;
    database2.single = singleRecord;
    database2.search = searchRecords;
    database2.set = setFields;
    database2.remove = deleteRecord;
    database2.exists = recordExists;
    database2.upsert = upsertRecord;
    database2.increment = incrementField;
    database2.decrement = decrementField;
    function insert(config) {
      return defineAction({
        type: "insert-record",
        config: {
          tableId: config.table,
          columns: config.columns
        }
      });
    }
    database2.insert = insert;
    function sql(config) {
      const cst = parse(config.query, {
        dialect: "sqlite",
        includeSpaces: true,
        includeNewlines: true,
        includeComments: false,
        includeRange: true,
        paramTypes: []
      });
      const parameters = [];
      const toUpper = cstVisitor({
        string_literal: (str) => {
          if (str.text.includes("@trigger:")) {
            parameters.push(input(str.text.replace("'", "").replace("'", "")));
            str.text = `\${${str.text.replace("'", "").replace("'", "").split(".").at(-1)}}`;
          }
        },
        keyword: (kw) => {
          kw.text = kw.text.toUpperCase();
        }
      });
      toUpper(cst);
      return defineAction({
        type: "raw-sql-query",
        config: {
          query: show(cst),
          parameters
        }
      });
    }
    database2.sql = sql;
    insert.rule = ({ node }, service) => {
      const reports = [];
      return reports;
    };
  })(database = action2.database || (action2.database = {}));
  function incrementField(config) {
    return defineAction({
      type: "increment-field",
      config: {
        tableId: config.table,
        field: config.field,
        query: config.query
      }
    });
  }
  function decrementField(config) {
    return defineAction({
      type: "decrement-field",
      config: {
        tableId: config.table,
        field: config.field,
        query: config.query
      }
    });
  }
  function listRecord(config) {
    return defineAction({
      type: "list-records",
      config: {
        ...config,
        limit: config.limit ?? config.query?.limit,
        tableId: config.table,
        query: config.query ?? query()
      }
    });
  }
  function searchRecords(config) {
    return action2.database.list({
      ...config,
      limit: config.limit ?? 50,
      pagination: config.pagination ?? "deferred_joins",
      query: query(
        ...config.fields.map(
          (it) => where("name", "contains", config.queryTerm || "@trigger:query.query")
        )
      )
    });
  }
  searchRecords.rule = () => {
    const reports = [];
    return reports;
  };
  function singleRecord(config) {
    return defineAction({
      type: "list-records",
      config: {
        limit: 1,
        pagination: "none",
        tableId: config.table,
        query: config.query
      }
    });
  }
  singleRecord.rule = () => {
    const reports = [];
    return reports;
  };
  function upsertRecord(config) {
    return defineAction({
      type: "upsert-record",
      config: {
        tableId: config.table,
        columns: config.columns,
        conflictFields: config.conflictFields ?? []
      }
    });
  }
  function setFields(config) {
    return defineAction({
      type: "set-fields",
      config: {
        tableId: config.table,
        columns: config.columns,
        query: config.query
      }
    });
  }
  setFields.rule = () => {
    const reports = [];
    return reports;
  };
  function deleteRecord(config) {
    return defineAction({
      type: "delete-record",
      config: {
        tableId: config.table,
        query: config.query
      }
    });
  }
  deleteRecord.rule = () => {
    const reports = [];
    return reports;
  };
  function recordExists(config) {
    return defineAction({
      type: "check-record-existance",
      config: {
        tableId: config.table,
        query: config.query
      }
    });
  }
  recordExists.rule = () => {
    const reports = [];
    return reports;
  };
})(action || (action = {}));
((action2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? action2 : defineAction;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown action type: ${type}`);
  }
  action2.fromConfig = fromConfig;
  let googleCloudStorage;
  ((googleCloudStorage2) => {
    function uploadSingle(config) {
      return defineAction({
        type: "upload-file",
        config: {
          ...config
          // maxFileSize: config.maxFileSize ?? 50 * 1024 * 1024,
        }
      });
    }
    googleCloudStorage2.uploadSingle = uploadSingle;
    uploadSingle.rule = () => {
      const reports = [];
      return reports;
    };
  })(googleCloudStorage = action2.googleCloudStorage || (action2.googleCloudStorage = {}));
})(action || (action = {}));
((action2) => {
  let resend;
  ((resend2) => {
    function sendEmail(config) {
      return defineAction({
        type: "resend-send-email",
        config: {
          to: input(config.to),
          subject: input(config.subject),
          from: input(config.from),
          html: input(config.html)
        }
      });
    }
    resend2.sendEmail = sendEmail;
    function createContact(config) {
      return defineAction({
        type: "resend-create-contact",
        config: {
          email: input(config.email),
          firstName: input(config.firstName),
          audienceId: input(config.audienceId)
        }
      });
    }
    resend2.createContact = createContact;
    sendEmail.rule = () => {
      const reports = [];
      return reports;
    };
    createContact.rule = () => {
      const reports = [];
      return reports;
    };
  })(resend = action2.resend || (action2.resend = {}));
  function openai() {
  }
  action2.openai = openai;
})(action || (action = {}));

// libs/sdk/parser/src/index.ts
var checker;
((checker2) => {
  function isCallExpression(node, name) {
    if (!node) {
      return false;
    }
    const isCallExpr = node.type === "CallExpression";
    if (!isCallExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    if (node.callee.type === "MemberExpression") {
      return node.callee.property.type === "Identifier" && node.callee.property.value === name;
    }
    return node.callee.type === "Identifier" && node.callee.value === name;
  }
  checker2.isCallExpression = isCallExpression;
  function isObjectExpression(node) {
    return node.type === "ObjectExpression";
  }
  checker2.isObjectExpression = isObjectExpression;
  function isKeyValueProperty(node, valueType, keyName) {
    if (node.type !== "KeyValueProperty") {
      return false;
    }
    if (!valueType) {
      return true;
    }
    const sameType = node.value.type === valueType;
    if (!sameType) {
      return false;
    }
    if (!keyName) {
      return true;
    }
    return isIdentifier(node.key, keyName);
  }
  checker2.isKeyValueProperty = isKeyValueProperty;
  function isStringLiteral(node) {
    return node.type === "StringLiteral";
  }
  checker2.isStringLiteral = isStringLiteral;
  function isNullLiteral(node) {
    return node.type === "NullLiteral";
  }
  checker2.isNullLiteral = isNullLiteral;
  function isPrimitive(node) {
    if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
      return true;
    }
    return false;
  }
  checker2.isPrimitive = isPrimitive;
  function isIdentifier(node, name) {
    if (!node) {
      return false;
    }
    const isIdentifier2 = node.type === "Identifier";
    if (!isIdentifier2) {
      return false;
    }
    if (!name) {
      return true;
    }
    return node.value === name;
  }
  checker2.isIdentifier = isIdentifier;
  function isMemberExpression(node, name) {
    if (!node) {
      return false;
    }
    const isMemberExpr = node.type === "MemberExpression";
    if (!isMemberExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    return isIdentifier(node.property, name);
  }
  checker2.isMemberExpression = isMemberExpression;
  function isArrayExpression(node) {
    return node.type === "ArrayExpression";
  }
  checker2.isArrayExpression = isArrayExpression;
})(checker || (checker = {}));
var Checker;
((Checker2) => {
  function isPrimitive(value) {
    return value !== Object(value);
  }
  Checker2.isPrimitive = isPrimitive;
  function isCallExpression(value) {
    return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
  }
  Checker2.isCallExpression = isCallExpression;
  function isObjectExpression(value) {
    return !isCallExpression(value) && value !== null && typeof value === "object";
  }
  Checker2.isObjectExpression = isObjectExpression;
  function isArrayExpression(value) {
    return Array.isArray(value);
  }
  Checker2.isArrayExpression = isArrayExpression;
})(Checker || (Checker = {}));
var sourceCode;
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  await initSync(
    "https://cdn.jsdelivr.net/npm/@swc/wasm-web@1.7.3/wasm_bg.wasm"
  );
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function parseDeclarative(code) {
  sourceCode = code;
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const importStmt = val.body.filter((it) => it.type === "ImportDeclaration");
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: importStmt.filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
      (it) => ({
        isTypeOnly: it.typeOnly,
        moduleSpecifier: it.source.value,
        defaultImport: it.specifiers.find(
          (sp) => sp.type === "ImportDefaultSpecifier"
        )?.local.value,
        namespaceImport: it.specifiers.find(
          (sp) => sp.type === "ImportNamespaceSpecifier"
        )?.local.value,
        namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
          (sp) => ({
            name: sp.imported ? sp.imported.value : sp.local.value,
            alias: sp.imported ? sp.local.value : void 0,
            isTypeOnly: sp.isTypeOnly
          })
        )
      })
    ),
    project: resolveCallExpression(projectExpr.expression)
  };
}
function resolveAsExpression(node) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression));
  }
  return args;
}
function resolveCallExpression(node) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression));
    }
  }
  return list;
}
function resolveObjectExpression(node, key) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
      continue;
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}

// libs/sdk/declarative/src/lib/feature.ts
function feature(name, config) {
  return {
    name,
    tables: config.tables,
    workflows: config.workflows,
    policies: Object.entries(config.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}
feature.new = (name, config) => {
  throw new Error("Not implemented");
};
feature.rule = ({ node }, service) => {
  const reports = [];
  if (!Checker.isCallExpression(node)) {
    return reports;
  }
  const [featureName, config] = node.arguments;
  const errors = service.validateName(featureName, "Feature");
  for (const error of errors) {
    reports.push({
      message: error,
      span: node.span,
      node,
      severity: "error"
    });
  }
  if (errors.length) {
    return reports;
  }
  if (!service.inUniqueFeature(featureName)) {
    reports.push({
      message: `Feature "${featureName}" is already defined`,
      span: node.span,
      node,
      severity: "error"
    });
  }
  if (Checker.isObjectExpression(config)) {
    if (!("tables" in config)) {
      reports.push({
        message: "Feature must have tables",
        span: node.span,
        node,
        severity: "error"
      });
    }
  }
  return reports;
};

// libs/sdk/declarative/src/lib/project.ts
function project(...features) {
  return features;
}
project.rule = ({ node }, service) => {
  const reports = [];
  return reports;
};

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config.message
    }
  };
}
var required = mandatory;
function unique(config = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config.message
      }
    }
  ];
}
function defineValidation(config) {
  return {
    name: config.name,
    config
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config) {
  const additionalFields = {};
  const idField = Object.values(config.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config.fields,
      ...additionalFields
    },
    constraints: config.constraints || []
  };
}
table.unique = (...fields) => {
  return {
    type: "unique",
    details: {
      columns: fields
    }
  };
};
table.index = (...fields) => {
  return {
    type: "index",
    details: {
      columns: fields
    }
  };
};
table.use = useTable;
function useTable(name) {
  return {
    command: "QueryTable",
    payload: {
      name
    }
  };
}
useTable.rule = ({ node }, service) => {
  const reports = [];
  if (!Checker.isCallExpression(node)) {
    return reports;
  }
  const [table2] = node.arguments;
  if (typeof table2 !== "string") {
    reports.push({
      message: "Table name must be a string literal",
      span: node.span,
      node,
      severity: "error"
    });
  } else {
    const exist = service.hasTable(table2);
    if (!exist) {
      reports.push({
        message: `Table "${table2}" not found`,
        span: node.span,
        node,
        severity: "error"
      });
    }
  }
  return reports;
};
function field(config) {
  const { type, validations: validations2 = [], metadata = {}, ...rest } = config;
  return {
    type: config.type,
    details: {
      ...metadata,
      ...rest
    },
    validations: validations2
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      if (type.endsWith(".rule")) {
        const reports = [];
        return reports;
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.decimal = decimal;
  function relation(config) {
    return field2({
      type: "relation",
      metadata: config,
      validations: config.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
field.enum = (config) => {
  return field({
    type: "single-select",
    metadata: {
      style: "enum",
      values: config.values,
      defaultValue: config.defaultValue
    }
  });
};
function useField(name, value) {
  value = coerceString(value);
  if (value === void 0) {
    return {
      input: {
        command: "QueryFieldName",
        payload: {
          name
        }
      }
    };
  }
  return {
    ...input(value),
    name: {
      command: "QueryField",
      payload: {
        name
      }
    }
  };
}
useField.rule = ({ node }, service) => {
  const reports = [];
  if (!Checker.isCallExpression(node)) {
    return reports;
  }
  const [fieldName] = node.arguments;
  if (typeof fieldName !== "string") {
    reports.push({
      message: "Field name must be a string literal",
      span: node.span,
      node,
      severity: "error"
    });
  } else {
    const exist = service.hasField(fieldName);
    if (!exist) {
      reports.push({
        message: `Field "${fieldName}" not found`,
        span: node.span,
        node,
        severity: "error"
      });
    }
  }
  return reports;
};
useField.increment = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      increment: true
    }
  };
};
useField.decrement = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      decrement: true
    }
  };
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
import { Project as Project2, SyntaxKind as SyntaxKind2 } from "ts-morph";

// libs/sdk/declarative/src/validation.ts
import { Ajv } from "ajv";
import addErrors from "ajv-errors";
import addFormats from "ajv-formats";
import validator from "validator";
var ajv = new Ajv({
  allErrors: true,
  useDefaults: "empty",
  removeAdditional: "failing",
  coerceTypes: true
});
addErrors(ajv);
addFormats(ajv);
function isBetween(date2, startDate, endDate) {
  if (!date2) {
    return false;
  }
  if (!startDate) {
    return false;
  }
  if (!endDate) {
    return false;
  }
  return validator.isAfter(date2, startDate) && validator.isBefore(date2, endDate);
}
var validations = [
  ["isBefore", validator.isBefore],
  ["isAfter", validator.isAfter],
  ["isBoolean", validator.isBoolean],
  ["isDate", validator.isDate],
  ["isNumeric", validator.isNumeric],
  ["isLatLong", validator.isLatLong],
  ["isMobilePhone", validator.isMobilePhone],
  ["isEmpty", validator.isEmpty],
  ["isDecimal", validator.isDecimal],
  ["isURL", validator.isURL],
  ["isEmail", validator.isEmail],
  ["isBetween", isBetween]
];
validations.forEach(([key, value]) => {
  const keyword = key;
  ajv.addKeyword({
    keyword,
    validate: (schema, data) => {
      if (schema === void 0 || schema === null) {
        return false;
      }
      const func = value;
      return func.apply(validator, [
        data,
        ...Array.isArray(schema) ? schema : [schema]
      ]);
    }
  });
});
function createSchema(properties) {
  const required2 = [];
  const requiredErrorMessages = {};
  for (const [key, value] of Object.entries(properties)) {
    if (value.required) {
      required2.push(key);
    }
    if ("errorMessage" in value && "required" in value.errorMessage) {
      requiredErrorMessages[key] = value.errorMessage.required;
      delete value.errorMessage.required;
    }
  }
  const extendSchema = {};
  if (Object.keys(requiredErrorMessages).length) {
    extendSchema["errorMessage"] = {
      required: requiredErrorMessages
    };
  }
  const clearProperties = Object.fromEntries(
    Object.entries(properties).map(([key, value]) => {
      const { required: required3, ...rest } = value;
      return [key, rest];
    })
  );
  return {
    type: "object",
    properties: clearProperties,
    required: required2,
    additionalProperties: false,
    ...extendSchema
  };
}
function validateInput(schema, input2) {
  const validate = ajv.compile(schema);
  const valid = validate(input2);
  if (!valid && validate.errors) {
    throw formatErrors(validate.errors);
  }
}
function formatErrors(errors, parent) {
  return errors.reduce(
    (acc, it) => {
      if (it.keyword === "errorMessage") {
        return {
          ...acc,
          ...formatErrors(it.params["errors"], it)
        };
      }
      const property = (it.instancePath || it.params["missingProperty"]).replace(".", "").replace("/", "");
      return { ...acc, [property]: parent?.message || it.message || "" };
    },
    {}
  );
}

// libs/sdk/declarative/src/lib/workflow.ts
if (typeof process === "undefined") {
  Object.defineProperty(self, "process", {
    value: {
      env: {}
    }
  });
}
function workflow(name, config) {
  return {
    name,
    trigger: config.trigger,
    actions: {
      execute: action(config.execute, {
        inline: true
      })
    },
    tag: config.tag
  };
}
workflow.rule = ({ node }, service) => {
  const reports = [];
  if (!Checker.isCallExpression(node)) {
    return reports;
  }
  const [name, config] = node.arguments;
  if (typeof name === "string") {
    if (!name.trim().length) {
      reports.push({
        message: "Workflow name must not be empty",
        span: node.span,
        node: name,
        severity: "error"
      });
    }
    if (!service.isUniqueWorkflow(name)) {
      reports.push({
        message: `Workflow name "${name}" is already defined`,
        span: node.span,
        node,
        severity: "error"
      });
    }
  } else {
    reports.push({
      message: "Workflow name must be a string",
      span: node.span,
      node: name,
      severity: "error"
    });
  }
  if (!Checker.isObjectExpression(config)) {
    reports.push({
      message: "Workflow config must be an object",
      span: node.span,
      node: config,
      severity: "error"
    });
  }
  return reports;
};
function defineTrigger(type, config) {
  return {
    type,
    config
  };
}
var trigger;
((trigger2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? trigger2 : defineTrigger;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown trigger type: ${type}`);
  }
  trigger2.fromConfig = fromConfig;
})(trigger || (trigger = {}));
((trigger2) => {
  function schedule(config) {
    return {
      type: "node-cron-trigger",
      config,
      policies: []
    };
  }
  trigger2.schedule = schedule;
  schedule.rule = () => {
    const reports = [];
    return reports;
  };
})(trigger || (trigger = {}));
((trigger2) => {
  function http(config) {
    const inputs = {};
    if (config.mapper) {
      const guard = config.mapper.toString();
      const project2 = new Project2({
        useInMemoryFileSystem: true
      });
      const sourceFile = project2.createSourceFile(
        "index.ts",
        `const mapFn = ${guard}`
      );
      const triggerIdentifierText = "trigger";
      const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind2.ArrowFunction);
      const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind2.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(
        SyntaxKind2.ReturnStatement
      );
      const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
        SyntaxKind2.ObjectLiteralExpression
      );
      returnObjExpr.getProperties().forEach((prop) => {
        const propAssignment = prop.asKindOrThrow(
          SyntaxKind2.PropertyAssignment
        );
        const propName = propAssignment.getName();
        const propValue = propAssignment.getInitializerOrThrow();
        inputs[propName] = {
          value: propValue.getFullText().replaceAll(`${triggerIdentifierText}.`, "")
        };
      });
    }
    return {
      type: "http",
      config,
      policies: config.policies ?? [],
      inputs
    };
  }
  trigger2.http = http;
  trigger2.httpConfigSchema = createSchema({
    policies: {
      type: "array",
      items: {
        type: "string"
      }
    },
    method: {
      type: "string",
      enum: ["get", "post", "put", "delete", "patch"],
      required: true,
      errorMessage: {
        enum: 'Method must be one of the following: "get", "post", "put", "delete", "patch"',
        type: 'Method must be one of the following: "get", "post", "put", "delete", "patch"',
        required: "Missing method"
      }
    },
    path: {
      type: "string",
      required: true,
      pattern: "^/.*",
      errorMessage: {
        pattern: 'Path must start with "/"',
        required: "Missing path"
      }
    }
  });
  http.rule = (ast, service) => {
    const reports = [];
    if (!Checker.isCallExpression(ast.node)) {
      return reports;
    }
    const [config] = ast.node.arguments;
    if (Checker.isObjectExpression(config)) {
      const errors = getErrors(() => validateInput(trigger2.httpConfigSchema, config)) ?? [];
      Object.values(errors).forEach((message) => {
        reports.push({
          message,
          span: ast.node.span,
          node: ast.node,
          severity: "error"
        });
      });
      if (!errors.length) {
        const relatedFeature = service.getFeature(ast);
        const relatedWorkflow = service.getWorkflow(ast);
        if (!relatedWorkflow || !relatedFeature) {
          return [];
        }
        const isDuplicate = service.duplicateWorkflowTriggerConfig(
          relatedWorkflow,
          (otherWorkflow, feature2) => {
            if (otherWorkflow.trigger.type !== "http") {
              return false;
            }
            const dub = normalizeWorkflowPath({
              featureName: feature2.name,
              workflowTag: otherWorkflow.tag,
              workflowPath: otherWorkflow.trigger.config["path"],
              workflowMethod: otherWorkflow.trigger.config["method"]
            }) === normalizeWorkflowPath({
              featureName: relatedFeature.name,
              workflowTag: relatedWorkflow.tag,
              workflowPath: config["path"],
              workflowMethod: config["method"]
            });
            return dub;
          }
        );
        if (isDuplicate) {
          reports.push({
            message: "Duplicate trigger config",
            span: ast.node.span,
            node: ast.node,
            severity: "error"
          });
        }
      }
    } else {
      reports.push({
        message: "Missing trigger config",
        span: ast.node.span,
        node: ast.node,
        severity: "error"
      });
    }
    return reports;
  };
})(trigger || (trigger = {}));
((trigger2) => {
  function sse(config) {
    return {
      type: "sse",
      inputs: {},
      config,
      policies: []
    };
  }
  trigger2.sse = sse;
  sse.rule = () => {
    const reports = [];
    return reports;
  };
  function websocket(config) {
    return {
      type: "sse",
      inputs: {},
      config,
      policies: []
    };
  }
  trigger2.websocket = websocket;
  websocket.rule = () => {
    const reports = [];
    return reports;
  };
  function stream(config) {
    return {
      type: "sse",
      inputs: {},
      config,
      policies: []
    };
  }
  trigger2.stream = stream;
  stream.stream = () => {
    const reports = [];
    return reports;
  };
})(trigger || (trigger = {}));
((trigger2) => {
  function github(config) {
    const inputs = {};
    if (config.mapper) {
      const guard = config.mapper.toString();
      const project2 = new Project2({
        useInMemoryFileSystem: true
      });
      const sourceFile = project2.createSourceFile(
        "index.ts",
        `const mapFn = ${guard}`
      );
      const triggerIdentifierText = "trigger";
      const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind2.ArrowFunction);
      const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind2.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(
        SyntaxKind2.ReturnStatement
      );
      const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
        SyntaxKind2.ObjectLiteralExpression
      );
      returnObjExpr.getProperties().forEach((prop) => {
        const propAssignment = prop.asKindOrThrow(
          SyntaxKind2.PropertyAssignment
        );
        const propName = propAssignment.getName();
        const propValue = propAssignment.getInitializerOrThrow();
        inputs[propName] = {
          value: propValue.getFullText().replaceAll(`${triggerIdentifierText}.`, "")
        };
      });
    }
    return {
      type: "github-trigger",
      config,
      policies: config.policies ?? [],
      inputs
    };
  }
  trigger2.github = github;
  github.rule = () => {
    const reports = [];
    return reports;
  };
})(trigger || (trigger = {}));
function policy(rule) {
  return rule;
}
function definePolicy(rule) {
  return (name) => rule;
}
((policy2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? policy2 : definePolicy;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown policy type: ${type}`);
  }
  policy2.fromConfig = fromConfig;
  function authenticated() {
    return (name) => `
    import { Context } from 'hono';
    import { verifyToken } from './subject';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
  }
  policy2.authenticated = authenticated;
  function http() {
    return () => "";
  }
  function github(config) {
    if (!config.events || !config.events.length || !config.guard) {
      return () => "";
    }
    const project2 = new Project2({
      useInMemoryFileSystem: true
    });
    let body = "return true";
    if (config.guard) {
      const guard = config.guard.toString();
      const sourceFile = project2.createSourceFile(
        "guard.ts",
        `const guard = ${guard}`
      );
      const guardFunction = sourceFile.getVariableDeclarationOrThrow("guard").getInitializerOrThrow();
      const isBlock = guardFunction.getBody().isKind(SyntaxKind2.Block);
      body = isBlock ? guardFunction.getBodyText() : `return ${guardFunction.getBodyText()}`;
    }
    return (name) => `
    import { EmitterWebhookEvent } from '@octokit/webhooks';
    import { isEventOfType } from '../core/github-webhooks';

    export async function ${name}(event: EmitterWebhookEvent) {
      if(isEventOfType(event, ${(config.events ?? []).map((it) => `'${it}'`).join(", ")})) {
        ${body}
      }
      return false;

  }`;
  }
  policy2.github = github;
  github.rule = () => {
    const reports = [];
    return reports;
  };
})(policy || (policy = {}));
policy.unstable_country = (country) => {
  return `@trigger:context.country === '${country}'`;
};

// libs/sdk/evaluator/src/lib/evaluate.ts
var callers = {
  project,
  table,
  feature,
  workflow,
  trigger: trigger.fromConfig,
  action: action.fromConfig,
  field: field.fromConfig,
  policy: policy.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  useTable,
  useField,
  query,
  select,
  sort,
  where,
  limit,
  and,
  or,
  input,
  index,
  withTrigger: (...args) => {
  }
};
function call(node, parent = null, metadata) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node.caller}`);
    }
    const args = node.arguments.map((it) => call(it, node));
    if (type.length) {
      args.unshift(type.join("."));
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => call(it, node));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      if (metadata === "actions") {
        obj[key] = call(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          node,
          key
        );
      } else {
        obj[key] = call(value, node, key);
      }
    }
    return obj;
  }
  return node;
}
function diagnose(service, ast) {
  const reports = [];
  if (Checker.isCallExpression(ast.node)) {
    const [implFn, ...type] = ast.node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${ast.node.caller}`);
    }
    const args = [ast, service];
    reports.push(
      ...ast.node.arguments.map(
        (it) => diagnose(service, {
          parent: ast,
          node: it
        })
      )
    );
    if (type.length) {
      args.unshift([...type, "rule"].join("."));
      reports.push(...callerImpl(...args));
    } else {
      if ("rule" in callerImpl) {
        reports.push(...callerImpl.rule(...args));
      }
    }
    return reports;
  }
  if (Checker.isArrayExpression(ast.node)) {
    return ast.node.map(
      (it) => diagnose(service, {
        parent: ast,
        node: it
      })
    );
  }
  if (Checker.isObjectExpression(ast.node)) {
    for (const [key, value] of Object.entries(ast.node)) {
      reports.push(
        ...diagnose(service, {
          parent: ast,
          node: value
        })
      );
    }
    return reports;
  }
  return reports;
}
async function evaluate(code) {
  const ast = await parseDeclarative(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  const features = call(ast.project);
  const service = {
    getFeature(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "feature") {
          return features.find(
            (feature2) => feature2.name === parent.node.arguments[0]
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    getWorkflow(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "workflow") {
          const feature2 = this.getFeature(parent);
          const [workflowName] = parent.node.arguments;
          return feature2?.workflows.find(
            (workflow2) => workflow2.name === workflowName
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    duplicateWorkflowTriggerConfig: (relatedWorkflow, check) => {
      for (const feature2 of features) {
        for (const workflow2 of feature2.workflows) {
          if (workflow2 === relatedWorkflow) {
            continue;
          }
          if (check(workflow2, feature2)) {
            return true;
          }
        }
      }
      return false;
    },
    hasField: (name) => features.some(
      (feature2) => Object.keys(feature2.tables ?? {}).some(
        (table2) => Object.keys(feature2.tables[table2].fields).includes(name)
      )
    ),
    hasTable: (name) => features.some((feature2) => {
      return (feature2.tables ?? {})[name];
    }),
    inUniqueFeature: (name) => {
      let count = 0;
      for (const feature2 of features) {
        if (feature2.name === name) {
          count++;
        }
      }
      return count === 1;
    },
    isUniqueWorkflow: (name) => {
      for (const feature2 of features) {
        let count = 0;
        for (const workflow2 of feature2.workflows) {
          if (workflow2.name === name) {
            count++;
          }
        }
        if (count > 1) {
          return false;
        }
      }
      return true;
    },
    validateName(name, context) {
      const errors = [];
      if (typeof name !== "string") {
        errors.push(`${context} must be a string`);
      } else if (name.trim().length === 0) {
        errors.push(`${context} must not be empty`);
      }
      return errors;
    }
  };
  const reports = diagnose(service, {
    parent: null,
    node: ast
  }).flat(Infinity);
  return {
    reports,
    definition: {
      features,
      imports: ast.imports,
      extensions: {},
      name: ""
    }
  };
}
async function compare(a, b) {
  const removeSpans = (node) => {
    if (!node) return "";
    return JSON.stringify(node, (key, value) => {
      if (key === "span") {
        return void 0;
      }
      return value;
    });
  };
  return removeSpans((await parseDeclarative(a))?.project ?? null) === removeSpans((await parseDeclarative(a))?.project ?? null);
}

// libs/sdk/evaluator/src/lib/infertype.ts
var noop = () => {
};
var callers2 = {
  project: (...args) => {
    const [name, config] = args;
    return args[0];
  },
  feature: (...args) => {
    const [name, config] = args;
    return {
      workflows: config.workflows,
      tables: config.tables,
      featureName: name
    };
  },
  table,
  field,
  workflow,
  trigger: trigger.fromConfig,
  action: action.fromConfig,
  useTable: noop,
  mandatory: noop,
  required: noop,
  unique: noop,
  useField: noop,
  query: noop,
  select: noop,
  sort: noop,
  where: noop,
  limit: noop,
  and: noop,
  or: noop,
  input: noop,
  index: noop
};
function call2(node, metadata, parent) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    const callerImpl = callers2[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node.caller}`);
    }
    const args = node.arguments.map((it) => call2(it));
    if (type.length) {
      args.unshift([...type, "dts"].join("."));
    } else {
      if ("dts" in callerImpl) {
        return callerImpl.dts(...args, metadata);
      }
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => call2(it));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      if (metadata === "actions") {
        obj[key] = call2(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          key
        );
      } else {
        obj[key] = call2(value, key, node);
      }
    }
    return obj;
  }
  return node;
}
async function inferType(code) {
  const ast = await parseDeclarative(code);
  if (!ast) {
    return [];
  }
  const result = call2(ast.project);
  return result;
}
export {
  compare,
  evaluate,
  inferType
};
