// libs/remote/src/index.ts
import { parse } from "dotenv";
import { readFile, readdir } from "fs/promises";
import { join as join2 } from "path";

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
var colors = {
  green: (message) => `\x1B[32m${message}\x1B[0m`,
  blue: (message) => `\x1B[34m${message}\x1B[0m`,
  magenta: (message) => `\x1B[35m${message}\x1B[0m`
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: (label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    },
    recordEnd: (label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    },
    end: () => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }
  };
}
function retryPromise(promise) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
async function extractError(fn) {
  try {
    return {
      value: await fn(),
      error: void 0
    };
  } catch (error) {
    return { error };
  }
}

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
async function removeContainer(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    await container.stop({ t: 0 }).catch(console.error);
  }
  await container.remove({ f: true }).catch(console.error);
}
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
function makeRunningContainerName(projectId) {
  return `${projectId}-container`;
}
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}

// libs/docker/src/index.ts
function createPack(content) {
  const pack = tarStream.pack();
  const entry = pack.entry({ name: "package.json" }, content, () => {
    pack.finalize();
  });
  entry.end();
  return new Promise((resolve, reject) => {
    entry.on("finish", () => {
      resolve(pack);
    });
    entry.on("error", reject);
  });
}
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}
async function installPackageJson(content, projectId) {
  const containerName = `${projectId}-install-deps`;
  const volumeName = "node_modules";
  const depsImage = "node:lts";
  const pack = await createPack(content);
  const { value: container, error } = await extractError(
    () => docker.createContainer({
      Image: depsImage,
      WorkingDir: "/app",
      name: containerName,
      Cmd: ["sh", "-c", "npm install", "--no-audit", "--no-fund"],
      HostConfig: {
        Binds: [`${volumeName}:/app/node_modules`],
        AutoRemove: true,
        // ReadonlyRootfs: true,
        CapDrop: ["ALL"]
      }
    })
  );
  if (error) {
    const { statusCode, message } = error;
    switch (statusCode) {
      case 409:
        await removeContainer(containerName).catch(() => {
        });
        await installPackageJson(content, projectId);
        break;
      case 404:
        console.log(`Image not found: ${depsImage}`);
        console.error(error);
        break;
      default:
        console.error(error);
        break;
    }
    return;
  }
  try {
    await container.putArchive(pack, {
      path: "/app"
    });
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      logs: true
    });
    stream.pipe(process.stdout);
    await container.start();
    await container.wait({
      condition: "removed"
    });
    console.log("Dependencies installed");
  } finally {
    await removeContainer(containerName).catch(() => {
    });
  }
}
function followProgress(stream) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      console.log
    );
  });
}

// libs/remote/src/lib/instance.ts
import {
  Observable,
  Subject,
  defer,
  from,
  map,
  mergeMap,
  switchMap,
  tap
} from "rxjs";
import { PassThrough as PassThrough2 } from "stream";
if (!process.env["DOCKER_HOST"]) {
  console.warn("DOCKER_HOST environment variable is not set.");
} else {
  console.log("ensure ssh-add private-key");
}
var INTERNAL_PORT = 3e3;
function listenToDockerEvents(options) {
  const abortController = new AbortController();
  return new Observable((subscriber) => {
    const events = docker.getEvents({
      abortSignal: abortController.signal,
      ...options
    });
    from(events).pipe(
      switchMap((x) => x),
      map((buffer) => {
        return buffer.toString("utf-8").split("\n").map((it) => it.trim()).filter(Boolean).map((event) => {
          try {
            return JSON.parse(event);
          } catch (error) {
            console.error(
              "Failed to parse event:",
              event,
              "$$$chunk$$",
              buffer.toString("utf-8")
            );
            if (process.env["NODE_ENV"] === "development") {
              throw error;
            }
            return {};
          }
        });
      })
    ).subscribe(subscriber);
    return () => {
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
function timestampParser(text) {
  if (!text.includes("Z")) {
    return { timestamp: "", rest: text };
  }
  let timestamp = "";
  do {
    timestamp += text.slice(0, 1);
    text = text.slice(1);
  } while (text.slice(0, 1) !== "Z");
  timestamp += text.slice(0, 1);
  text = text.slice(1);
  return {
    timestamp,
    rest: text
  };
}
function containerLogs(containerName) {
  return new Observable((subscriber) => {
    const abortController = new AbortController();
    const container$ = defer(async () => {
      const container = await getContainer({ name: containerName });
      if (!container) {
        throw new Error(`Container ${containerName} not found`);
      }
      return container;
    });
    const stream$ = container$.pipe(
      tap((container) => {
        console.log(
          "Listening to logs for container:",
          containerName,
          ` (${container.id})`
        );
      }),
      switchMap(
        (container) => from(
          container.logs({
            // TODO: emit only from the start of the day
            follow: true,
            stdout: true,
            stderr: true,
            timestamps: true,
            details: true,
            abortSignal: abortController.signal
          })
        ).pipe(
          mergeMap((stream) => {
            const subject = new Subject();
            const write$ = new PassThrough2({
              write(chunk, encoding, callback) {
                const output = chunk.toString();
                const lines = output.split("\n").map(timestampParser);
                lines.forEach(
                  (entry) => subject.next({ timestamp: entry.timestamp, log: entry.rest })
                );
                callback();
              }
            });
            container.modem.demuxStream(stream, write$, write$);
            return subject;
          })
        )
      )
    );
    stream$.subscribe(subscriber);
    return () => {
      console.log("ABORTING");
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}

// libs/remote/src/lib/proxy/docker.ts
import { Writable } from "stream";

// libs/remote/src/lib/proxy/docker.runner.ts
import { writeFileSync } from "fs";
import { join } from "path";
import tar from "tar";
import tarStream2 from "tar-stream";
async function buildRunnerImage(distDir, baseTag, runTag) {
  const dockerfile = getRunnerDockerfile(baseTag);
  writeFileSync(join(distDir, "Dockerfile"), dockerfile);
  const tarStream3 = tar.create(
    {
      gzip: false,
      cwd: distDir
    },
    ["."]
  );
  const buildStream = await docker.buildImage(tarStream3, {
    t: runTag
  });
  return followProgress(buildStream);
}
function createTar(baseTag, files) {
  const dockerfile = getRunnerDockerfile(baseTag);
  const pack = tarStream2.pack();
  for (const { path, content } of files) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
async function buildRunnerImageStream(tar2, runTag) {
  tar2.pipe(process.stdout);
  const buildStream = await docker.buildImage(tar2, {
    t: runTag
  });
  return followProgress(buildStream);
}
function getRunnerDockerfile(imageName) {
  return `
FROM ${imageName} as deps

WORKDIR /app

# FROM node:lts as base
# WORKDIR /app
COPY ./package.json /app/package.json
COPY . /app/build/
# COPY --from=deps /app/node_modules /app/node_modules

# it'll make install dynamic dependencies faster
# COPY --from=deps /app/package-lock.json /app/package-lock.json

# RUN npm ci --omit=dev --no-audit --no-fund --prefer-offline

# CMD tail -f /dev/null

CMD [ "npm", "run", "start:prod" ]
`;
}

// libs/remote/src/lib/proxy/docker.ts
async function getContainerPort(containerId) {
  const container = await getContainer(containerId);
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${INTERNAL_PORT}/tcp`][0].HostPort;
}
async function createRemoteContainer(name, imageTag, ports = { internalPort: INTERNAL_PORT }, env = {}) {
  const mapPort = ports.hostPort ? [{ HostPort: ports.hostPort }] : [];
  const container = await docker.createContainer({
    name,
    Image: imageTag,
    Env: [
      // FIXME: keeping this for now till we generate debug database for each project
      // 'CONNECTION_STRING=postgresql://january-test_owner:U17cOgTaYXIm@ep-holy-flower-a5lkn70o.us-east-2.aws.neon.tech/january-test?sslmode=require',
      ...Object.entries(env).map(([key, value]) => `${key}=${value}`),
      "NODE_ENV=development",
      `PORT=${ports.internalPort}`
    ],
    Labels: {
      "traefik.enable": "true",
      [`traefik.http.routers.${name}.rule`]: "Host(`" + name + ".january.sh`)",
      [`traefik.http.routers.${name}.tls.certresolver`]: "myresolver",
      [`traefik.http.services.${name}.loadbalancer.server.port`]: String(
        ports.internalPort
      )
    },
    ExposedPorts: {
      [`${ports.internalPort}/tcp`]: {}
      // '9229/tcp': {},
    },
    platform: process.env["NODE_ENV"] === "production" ? "linux/amd64" : void 0,
    HostConfig: {
      // named volume to that has node_modules
      Binds: [`node_modules:/app/node_modules`],
      NetworkMode: "traefik-network",
      // Instruct Docker to dynamically bind an available host port to container's port
      PortBindings: {
        [`${ports.internalPort}/tcp`]: mapPort
      },
      // FIXME: we need to allow only 64MB of memory
      Memory: 96 * 1024 * 1024,
      RestartPolicy: {
        Name: "on-failure",
        MaximumRetryCount: 5
      },
      // allow only 0.10 of the CPU
      CpuPercent: 10
    },
    Healthcheck: {
      Test: ["CMD", "curl", "-f", `http://localhost:${INTERNAL_PORT}/health`],
      Interval: 60 * 1e9,
      // 60 seconds
      Timeout: 10 * 1e9,
      // 10 seconds
      Retries: 3,
      StartPeriod: 60 * 1e9
      // 60 seconds
    }
  });
  return container;
}
async function imagesExists(...tags) {
  const images = await docker.listImages({
    all: true
  });
  const imageTags = images.flatMap((image) => image.RepoTags);
  return tags.every((tag) => {
    return imageTags.includes(tag.includes(":") ? tag : `${tag}:latest`);
  });
}
async function containerExists(containerId) {
  if (typeof containerId === "string") {
    const container2 = docker.getContainer(containerId);
    return container2.inspect().then(
      () => true,
      () => false
    );
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  return !!container;
}
var needsNewRunnerImage = async (config) => {
  const runnerImageTag = `${config.projectId}-run`;
  console.log({
    [`${config.projectId}-run`]: await imagesExists(runnerImageTag)
  });
  return config.depsChanges || config.codeChanges || !await imagesExists(runnerImageTag);
};
var canProcced = async (config) => {
  const needNewRunnerImage = await needsNewRunnerImage(config);
  if (needNewRunnerImage) {
    return false;
  }
  const needNewContainer = !await containerExists(config.containerId);
  if (needNewContainer) {
    return false;
  }
  return true;
};
async function createClientServer(options) {
  const recorder = createRecorder({
    label: "docker:createClientServer"
  });
  const config = await options.getConfig();
  const baseImageTag = "ezzabuzaid/january-client-build";
  const runnerImageTag = `${config.projectId}-image`;
  const runnerContainerName = makeRunningContainerName(config.projectId);
  const needsContainerReload = async () => {
    const container = docker.getContainer(config.containerId);
    const info = await container.inspect();
    return !info.State.Running;
  };
  if (await needsNewRunnerImage(config)) {
    recorder.record("needsNewBaseImage");
    const canCreate = await canCreateMore(128);
    if (!canCreate) {
      throw new Error("No more memory");
    }
    const { value: dist, error } = await extractError(() => options.getDist());
    if (error) {
      console.error(error);
      return;
    }
    recorder.record("buildRunnerImage");
    await buildRunnerImage(dist, baseImageTag, runnerImageTag);
    recorder.recordEnd("buildRunnerImage");
    if (config.containerId) {
      const container = docker.getContainer(config.containerId);
      container.stop({ signal: "SIGKILL" }).then(() => container.remove()).catch(() => {
      });
    }
    Object.assign(config, {
      codeChanges: false,
      depsChanges: false
    });
    recorder.recordEnd("needsNewBaseImage");
  }
  if (!await containerExists(config.containerId)) {
    recorder.record("needsNewContainer");
    const canCreate = await canCreateMore(128);
    if (!canCreate) {
      throw new Error("No more memory");
    }
    recorder.record("createContainer");
    const container = await createRemoteContainer(
      runnerContainerName,
      runnerImageTag
    );
    recorder.recordEnd("createContainer");
    recorder.record("startContainer");
    await container.start();
    await followLogs(container);
    recorder.recordEnd("startContainer");
    recorder.record("getContainerPort");
    const port = await retryPromise(() => getContainerPort(container.id));
    recorder.recordEnd("getContainerPort");
    recorder.record("healthCheck");
    await retryPromise(async () => {
      const res = await fetch(`http://localhost:${port}/health`);
      if (!res.ok) {
        throw new Error("Failed to fetch");
      }
    });
    recorder.recordEnd("healthCheck");
    Object.assign(config, {
      containerId: container.id,
      port,
      codeChanges: false,
      depsChanges: false
    });
    recorder.recordEnd("needsNewContainer");
  }
  if (await needsContainerReload()) {
    recorder.record("needsContainerReload");
    const canCreate = await canCreateMore(128);
    if (!canCreate) {
      throw new Error("No more memory");
    }
    const container = docker.getContainer(config.containerId);
    await container.start();
    await followLogs(container);
    const port = await retryPromise(() => getContainerPort(container.id));
    await retryPromise(async () => {
      const res = await fetch(`http://localhost:${port}/health`);
      if (!res.ok) {
        throw new Error("Failed to fetch");
      }
    });
    Object.assign(config, {
      port,
      codeChanges: false,
      depsChanges: false
    });
  }
  await options.setConfig(config);
  return config.port;
}
async function canCreateMore(memoryAllocation) {
  let memory = [];
  const stream = new Writable({
    write(chunk, encoding, callback) {
      const output = chunk.toString().trim().split(/\s+/);
      memory = output;
      callback();
    }
  });
  await docker.run("node:lts", ["sh", "-c", "free -m | grep Mem"], stream, {
    Tty: false,
    HostConfig: {
      AutoRemove: true
    }
  });
  const freeMemoryMb = parseInt(memory[3], 10);
  console.log(`freeMemoryMb: ${freeMemoryMb}`);
  return {
    canCreate: freeMemoryMb > memoryAllocation,
    freeMemoryMb
  };
}

// libs/remote/src/lib/manager.ts
Error.stackTraceLimit = Infinity;
(async () => {
  await upsertNetwork("traefik-network");
  await upsertVolume("node_modules");
})();
async function createRemoteServer(projectId, tar2, env = {}, restartContainer = true) {
  const recorder = createRecorder({
    label: "createClientServer",
    verbose: true
  });
  const runnerImageTag = `${projectId}-image`;
  const runnerContainerName = makeRunningContainerName(projectId);
  const forceRestart = await isContainerRunning(runnerContainerName).then((container) => !container).catch(() => true);
  console.log(`Restart container: ${restartContainer}`);
  if (forceRestart) {
    console.warn(
      `Container doesn't exists. ignore restart flag ${restartContainer}`
    );
    restartContainer ||= forceRestart;
  }
  if (restartContainer) {
    {
      await buildRunnerImageStream(tar2, runnerImageTag);
    }
    {
      recorder.record("removeContainer");
      await removeContainer(runnerContainerName).catch(() => {
      });
      recorder.recordEnd("removeContainer");
    }
    {
      recorder.record("startContainer");
      try {
        const container = await createRemoteContainer(
          runnerContainerName,
          runnerImageTag,
          { internalPort: INTERNAL_PORT },
          env
        );
        await container.start();
        await followLogs(container);
      } catch {
        {
          recorder.record("removingErroredContainer");
          await removeContainer(runnerContainerName).catch(() => {
          });
          recorder.recordEnd("removingErroredContainer");
        }
      }
      recorder.recordEnd("startContainer");
    }
  }
  recorder.end();
  return runnerContainerName;
}
async function liveness(projectUrl) {
  const recorder = createRecorder({
    label: "isContainerAlive",
    verbose: true
  });
  recorder.record("healthCheck");
  await retryPromise(async () => {
    const res = await fetch(projectUrl);
    if (!res.ok) {
      throw new Error("Failed to fetch");
    }
  });
  recorder.recordEnd("healthCheck");
  recorder.end();
}

// libs/remote/src/index.ts
async function getEnv() {
  const env = {};
  const envs = [".env", "remote.env"];
  for (const file of envs) {
    const filePath = join2(process.cwd(), file);
    const envFile = await readFile(filePath, "utf-8");
    const envFileContent = parse(envFile);
    Object.assign(env, envFileContent);
  }
  return env;
}
async function remote(config) {
  const projectId = crypto.randomUUID();
  const packageJson = await readFile(
    join2(config.distDir, "package.json"),
    "utf-8"
  );
  await installPackageJson(packageJson, projectId);
  await createRemoteServer(
    projectId,
    createTar("node:lts", [
      ...await Promise.all(
        (await readdir(config.distDir)).map(async (file) => ({
          path: file,
          content: await readFile(join2(config.distDir, file), "utf-8")
        }))
      )
    ]),
    await getEnv(),
    true
  );
}
async function remotePack(tar2) {
  const projectId = crypto.randomUUID();
  await createRemoteServer(projectId, tar2, {}, true);
}
export {
  INTERNAL_PORT,
  buildRunnerImage,
  buildRunnerImageStream,
  canProcced,
  containerExists,
  containerLogs,
  createClientServer,
  createRemoteContainer,
  createRemoteServer,
  createTar,
  getContainerPort,
  getRunnerDockerfile,
  imagesExists,
  listenToDockerEvents,
  liveness,
  needsNewRunnerImage,
  remote,
  remotePack
};
//# sourceMappingURL=index.js.map
