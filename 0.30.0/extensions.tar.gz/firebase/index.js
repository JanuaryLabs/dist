var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config2) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config2.accessor(item)]: config2.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config2) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config2.featureName),
        snakecase(config2.workflowTag),
        toCurlyBraces(config2.workflowPath)
      )
    )
  );
  return config2.workflowMethod ? `${config2.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/compiler/sdk/devkit/src/lib/data/actions.json
var actions_default = [
  {
    id: "077b1325-0ade-4f63-8f66-ced39cef38ba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Atomic",
    name: "atomic",
    visible: true,
    multi: true,
    allowedActions: [],
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "9c858969-f48b-4b72-8282-bfe82654ae9a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Delete Record",
    name: "delete-record",
    visible: true,
    output: {
      displayName: "deletedRecord",
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    },
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      cascade: {
        displayName: "Cascade",
        type: "boolean",
        defaultValue: true,
        required: true,
        visible: false
      }
    }
  },
  {
    id: "b036bc50-9292-486a-9714-1f551fee5dc4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Record Exist",
    name: "check-record-existance",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "recordExists",
      source: [
        {
          id: "recordExists",
          primitiveType: "boolean",
          displayName: "recordExists"
        }
      ]
    }
  },
  {
    id: "83ce1e80-0117-4ebc-86ac-3bdad3b32796",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Insert Record",
    name: "insert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      columns: {
        displayName: "Payload",
        type: "columns-list",
        required: false,
        source: {
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ],
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "2bb630dd-7ba3-4cda-95a7-f65ee22116ee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Raw SQL Query",
    name: "raw-sql-query",
    metadata: {
      query: {
        displayName: "Query",
        type: "string",
        required: true
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "62e55ba2-9a81-4f88-995e-2093ca3fc067",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Upsert Record",
    name: "upsert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select"
      },
      columns: {
        displayName: "Payload",
        type: "columns-list"
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "a8ded515-b99e-4fca-9654-7d2c12624a7a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "increment-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "b5a5e901-9ef8-4d2c-86f2-39263ca8ebee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "decrement-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    output: {
      type: "context.tableId",
      displayName: "updatedRecord",
      source: []
    },
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Set Fields",
    name: "set-fields",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      columns: {
        displayName: "Field",
        type: "columns-list",
        required: true,
        source: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          },
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ]
        }
      }
    }
  },
  {
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    displayName: "With i18n",
    name: "i18n"
  },
  {
    id: "3c40908c-1c69-4222-a936-7a569a1198b5",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "Upload file to google storage",
    name: "upload-file",
    output: {
      displayName: "uploadedFile",
      source: []
    },
    metadata: {
      multiple: {
        displayName: "Can upload multiple files",
        type: "boolean",
        required: false,
        defaultValue: "@fixed:false"
      },
      maxFileCount: {
        displayName: "Maximum file count",
        type: "number",
        required: false,
        defaultValue: "@fixed:1",
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxTotalSize: {
        displayName: "Maximum total size",
        type: "number",
        required: false,
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxFileSize: {
        displayName: "Maximum file size",
        type: "number",
        required: false
      }
    }
  },
  {
    id: "c4ec127b-e167-4a30-8544-732c55d1bd24",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "List Records",
    name: "list-records",
    metadata: {
      localizable: {
        displayName: "Localizable",
        type: "boolean",
        required: false,
        fieldset: "first",
        visible: false,
        defaultValue: "false"
      },
      pagination: {
        displayName: "Pagination",
        type: "single-select",
        required: true,
        fieldset: "pagination",
        defaultValue: "deferred_joins",
        source: [
          {
            id: "none",
            displayName: "None"
          },
          {
            id: "limit_offset",
            displayName: "Limit & Offset"
          },
          {
            id: "deferred_joins",
            displayName: "Deferred Joins"
          },
          {
            id: "cursor",
            displayName: "Cursor"
          }
        ]
      },
      tableId: {
        displayName: "Table",
        type: "single-select",
        fieldset: "first",
        required: true,
        source: {
          url: "/tables"
        }
      },
      limit: {
        displayName: "Limit",
        type: "number",
        required: false,
        fieldset: "pagination",
        defaultValue: 50
      },
      query: {
        displayName: "Query",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      source: {
        input: "context.pagination",
        operator: "equal",
        value: "none",
        then: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        },
        else: [
          {
            id: "records",
            displayName: "records",
            primitiveType: {
              input: "context.limit",
              operator: "equal",
              value: 1,
              then: "object",
              else: "array"
            },
            typeName: {
              url: "/tables/:id",
              binding: {
                id: "context.tableId"
              },
              use: "displayName"
            },
            interface: {
              url: "/tables/:id/fields",
              binding: {
                id: "context.tableId"
              }
            },
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          },
          {
            id: "meta",
            displayName: "meta",
            typeName: "Meta",
            primitiveType: "object",
            interface: [
              {
                id: "hasNextPage",
                displayName: "hasNextPage",
                primitiveType: "boolean"
              },
              {
                id: "hasPreviousPage",
                displayName: "hasPreviousPage",
                primitiveType: "boolean"
              },
              {
                id: "pageSize",
                displayName: "pageSize",
                primitiveType: "number"
              },
              {
                id: "currentPage",
                displayName: "currentPage",
                primitiveType: "number"
              },
              {
                id: "totalCount",
                displayName: "totalCount",
                primitiveType: "number"
              },
              {
                id: "totalPages",
                displayName: "totalPages",
                primitiveType: "number"
              }
            ],
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          }
        ]
      }
    }
  },
  {
    id: "89ad4cdb-2ed1-4c42-84bd-4986648bbfe2",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "List Files",
    name: "list-files",
    output: {
      displayName: "files",
      source: []
    },
    metadata: {
      prefix: {
        displayName: "Prefix",
        type: "string",
        required: false,
        fieldset: "first"
      },
      flat: {
        displayName: "Flat",
        type: "boolean",
        required: false,
        fieldset: "first"
      }
    }
  },
  {
    id: "43ea3f72-f3b0-419f-abef-f1bd4b5e9b22",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Custom Code",
    name: "custom-code",
    output: {
      source: []
    },
    metadata: {
      code: {
        displayName: "Code",
        type: "code-editor",
        required: true,
        extras: {
          language: "typescript"
        }
      }
    }
  },
  {
    id: "e0c60892-6b26-417e-8140-8e8d31f64ab2",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Branch",
    name: "branch",
    type: "branch",
    multi: true,
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "89e16a38-25f1-444e-bcf7-96e6455c3707",
    extensionId: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    displayName: "Send Email",
    name: "send-email",
    output: {
      outputName: "sentEmail",
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        required: true,
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        required: true,
        fieldset: "email"
      },
      replayTo: {
        displayName: "Replay To",
        type: "string",
        required: false
      },
      subject: {
        displayName: "Subject",
        type: "string",
        required: true,
        fieldset: "content"
      },
      templateId: {
        displayName: "Template",
        type: "string",
        fieldset: "content",
        required: true
      }
    }
  },
  {
    id: "69a01ada-a83a-451f-a3fe-fb486e08ffa9",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Send Email",
    name: "resend-send-email",
    output: {
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      subject: {
        displayName: "Subject",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "content"
      },
      text: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      html: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "c292a9d7-1f66-47b9-b366-e25f3faff840",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Create Contact",
    name: "resend-create-contact",
    output: {
      source: []
    },
    metadata: {
      firstName: {
        displayName: "First name",
        type: "string",
        fieldset: "general"
      },
      lastName: {
        displayName: "Last name",
        type: "string",
        required: false,
        fieldset: "general"
      },
      email: {
        displayName: "Email",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      unsubscribed: {
        displayName: "Unsubscribed",
        type: "string",
        required: false,
        fieldset: "email"
      },
      audienceId: {
        displayName: "Audience id",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b",
    extensionId: "389d81cd-5b58-4ade-b815-add468c48e37",
    displayName: "Ajax",
    name: "ajax",
    output: {
      source: []
    },
    metadata: {
      url: {
        displayName: "URL",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      method: {
        displayName: "Method",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      body: {
        displayName: "Body",
        type: "json",
        required: false
      }
    }
  },
  {
    id: "7a9d9a29-7079-4aa8-bdc0-d93a713a2440",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger",
    metadata: {
      path: {
        fieldset: "config",
        type: "string",
        displayName: "Path",
        required: true,
        pattern: "^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"
      },
      method: {
        fieldset: "config",
        displayName: "Method",
        type: "single-select",
        source: [
          {
            id: "get",
            displayName: "GET"
          },
          {
            id: "post",
            displayName: "POST"
          },
          {
            id: "put",
            displayName: "PUT"
          },
          {
            id: "patch",
            displayName: "PATCH"
          },
          {
            id: "delete",
            displayName: "DELETE"
          },
          {
            id: "head",
            displayName: "HEAD"
          }
        ],
        required: true
      },
      contentType: {
        visible: false,
        fieldset: "optional",
        type: "single-select",
        displayName: "Content Type",
        required: false,
        source: [
          {
            id: "application/json",
            displayName: "application/json"
          },
          {
            id: "application/x-www-form-urlencoded",
            displayName: "application/x-www-form-urlencoded"
          },
          {
            id: "multipart/form-data",
            displayName: "multipart/form-data"
          }
        ]
      },
      summary: {
        fieldset: "optional",
        type: "string",
        displayName: "Summary",
        required: false,
        visible: false
      }
    }
  },
  {
    id: "0aec7685-5c19-43eb-bc2c-93597b5cecfc",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    id: "6432f258-6511-4d8a-86a6-628db3f333e7",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    id: "7b1696e9-9c89-4ba7-abc0-e1448b287772",
    extensionId: "9c034274-069e-4567-ab33-bab8f31f874c",
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    id: "11e4e048-cf30-4fa1-b0ff-25baa7a5f416",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "File Trigger",
    name: "file",
    type: "trigger"
  },
  {
    id: "0bd0b432-5f7a-447a-afab-6db83d8976b1",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    id: "cd76caa3-e9f0-49b8-bf7a-0ebed83bd486",
    extensionId: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/extensions.json
var extensions_default = [
  {
    id: "e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b",
    visible: false,
    name: "soft-delete",
    categories: ["soft-delete"],
    title: "",
    subtitle: "Support Soft Delete functionality in any table.",
    description: "Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.",
    tableMetadata: {
      tableId: {
        displayName: "Support Soft Delete",
        required: false,
        visible: false,
        type: "single-select",
        source: [
          {
            id: "none",
            displayName: "No soft delete"
          },
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag"
          },
          {
            id: "trash",
            displayName: "Using trash table"
          }
        ]
      }
    },
    metadata: {}
  },
  {
    id: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    visible: true,
    name: "core",
    categories: ["misc"],
    title: "Core",
    main: "src/core/validation.ts",
    subtitle: "Core functionality",
    metadata: {},
    description: "Essential functionality that is required for all projects."
  },
  {
    id: "977a059f-ddda-4677-b785-4d1b04a7c201",
    visible: true,
    name: "prettier",
    categories: ["misc"],
    title: "Prettier",
    subtitle: "An opinionated code formatter",
    description: "Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.",
    logo: "assets/prettier.png",
    metadata: {}
  },
  {
    id: "e81b26bb-051b-4b30-a94d-e34ad615504c",
    visible: true,
    name: "identity",
    categories: ["misc"],
    title: "identity",
    subtitle: "identity",
    description: "",
    metadata: {}
  },
  {
    id: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "postgresql",
    categories: ["database"],
    main: "src/extensions/postgresql/index.ts",
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "PostgreSQL",
    subtitle: "A free and open-source relational database management system emphasizing extensibility and SQL compliance.",
    description: "PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "71c97a1c-3efe-4712-b35b-56714dafa02f",
    name: "mysql",
    categories: ["database"],
    disabled: true,
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "MySQL",
    description: "MySQL is an open-source relational database management system.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    name: "firebase-functions",
    categories: ["hosting"],
    disabled: true,
    logo: "assets/firebase-functions.png",
    svg: "SiFirebase",
    title: "Firebase Functions",
    subtitle: "Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code",
    description: "Firebase Functions is a serverless framework that lets you automatically run backend code.",
    metadata: {
      FIREBASE_FUNCTION_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"
      }
    }
  },
  {
    id: "d9e83836-e41d-4ae2-aa93-229a0ef27069",
    name: "firebase-auth",
    categories: ["identity"],
    disabled: false,
    main: "firebase.ts",
    metadata: {
      FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"
      }
    },
    title: "Firebase Authentication",
    description: "Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.",
    subtitle: "Authenticate users with Firebase"
  },
  {
    id: "34d9ec05-de0d-4d79-ae2a-9a06200d20dd",
    name: "fly",
    categories: ["hosting"],
    logo: "assets/fly.png",
    title: "Fly",
    description: "Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.",
    metadata: {
      FLY_API_TOKEN: {
        displayName: "Deploy Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_API_TOKEN",
        description: "The token to deploy the app"
      },
      FLY_APP_NAME: {
        displayName: "App Name",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_APP_NAME",
        description: "The name of the app"
      }
    }
  },
  {
    name: "vercel",
    id: "4c82c872-1a2f-4849-98a6-bd7017498191",
    categories: ["hosting"],
    title: "Vercel",
    description: "Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.",
    metadata: {
      VERCEL_ORG_ID: {
        displayName: "Org ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_ORG_ID"
      },
      VERCEL_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_PROJECT_ID"
      },
      VERCEL_API_TOKEN: {
        displayName: "API Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_API_TOKEN"
      }
    }
  },
  {
    id: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    name: "hono",
    categories: ["routing"],
    title: "Hono.dev",
    main: "src/extensions/tus/index.ts",
    description: "Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.",
    metadata: {}
  },
  {
    id: "109aa1af-f9d0-4d31-bbc6-c4603be5b7b0",
    name: "koajs",
    disabled: true,
    categories: ["routing"],
    title: "Koa.js",
    description: "Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.",
    logo: "assets/http.svg",
    metadata: {},
    svg: "SiKoa",
    packages: [
      {
        name: "koa",
        version: "latest"
      },
      {
        name: "koa-static",
        version: "latest"
      },
      {
        name: "@types/koa-static",
        version: "latest"
      },
      {
        name: "@koa/router",
        version: "latest"
      },
      {
        name: "koa-body",
        version: "latest"
      },
      {
        name: "koa-bodyparser",
        version: "latest"
      },
      {
        name: "koa-logger",
        version: "latest"
      },
      {
        name: "koa-qs",
        version: "latest"
      },
      {
        name: "@koa/cors",
        version: "latest"
      },
      {
        name: "@types/koa-logger",
        version: "latest"
      },
      {
        name: "@types/koa__cors",
        version: "^3.3.0"
      },
      {
        name: "@types/koa__router",
        version: "^12.0.0"
      },
      {
        name: "@types/koa-bodyparser",
        version: "^4.3.10"
      },
      {
        name: "@types/koa-qs",
        version: "^2.0.0"
      },
      {
        name: "swagger-ui-dist",
        version: "latest"
      },
      {
        name: "@types/swagger-ui-dist",
        version: "latest"
      }
    ]
  },
  {
    id: "3633c476-c120-4f9f-893b-b6b03f67b9e9",
    name: "expressjs",
    svg: "SiExpress",
    disabled: true,
    categories: ["routing"],
    title: "Express.js",
    description: "Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
    logo: "assets/http.svg",
    metadata: {},
    packages: [
      {
        name: "express",
        version: "latest"
      },
      {
        name: "body-parser",
        version: "latest"
      },
      {
        name: "morgan",
        version: "latest"
      },
      {
        name: "cors",
        version: "latest"
      },
      {
        name: "@types/express",
        version: "latest",
        dev: true
      },
      {
        name: "@types/body-parser",
        version: "latest",
        dev: true
      },
      {
        name: "@types/cors",
        version: "latest",
        dev: true
      },
      {
        name: "@types/morgan",
        version: "latest",
        dev: true
      }
    ]
  },
  {
    id: "3e184f8b-d2dc-4592-9507-979d649277f5",
    visible: true,
    name: "gcs",
    categories: ["file-storage"],
    logo: "assets/cloud-storage.svg",
    title: "Google Cloud Storage",
    description: "Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google's cloud with advanced security and sharing capabilities.",
    main: "src/extensions/gcs/index.ts",
    metadata: {
      BUCKET_NAME: {
        _comment: "// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won't work",
        displayName: "Bucket Name",
        type: "string",
        required: true,
        description: "The name of the bucket"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        type: "json",
        description: "The service account key to access the bucket",
        required: true
      }
    }
  },
  {
    id: "9c034274-069e-4567-ab33-bab8f31f874c",
    visible: true,
    name: "github",
    categories: [],
    title: "GitHub Webhooks",
    description: "GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com",
    metadata: {
      WEBHOOK_SECRET: {
        displayName: "Webhook Secret",
        defaultValue: "@process:env.WEBHOOK_SECRET",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    visible: true,
    name: "node-cron",
    categories: ["schedulers"],
    title: "Node Cron",
    description: "A simple cron-like job scheduler for Node.js",
    metadata: {},
    packages: [
      {
        name: "@types/node-cron",
        version: "^3.0.11",
        dev: true
      },
      {
        name: "node-cron",
        version: "^3.0.3"
      }
    ]
  },
  {
    id: "389d81cd-5b58-4ade-b815-add468c48e37",
    visible: true,
    disabled: true,
    name: "ajax",
    categories: ["misc"],
    logo: "assets/ajax.png",
    title: "Ajax",
    description: "Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.",
    metadata: {},
    svg: "SiAjax"
  },
  {
    id: "8c438fcd-b8c0-444e-9100-24abd93a6bcb",
    visible: true,
    disabled: true,
    name: "sqlite",
    categories: ["database"],
    main: "src/extensions/sqlite/index.ts",
    title: "Sqlite",
    description: "Sqlite is a relational database management system.",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "23bfb249-0149-4033-a2a9-2dbec614d461",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "bytes",
    primitiveType: "Uint8Array",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      }
    },
    initialValidation: []
  },
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/operators.json
var operators_default = [
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Equal To",
    name: "equals",
    metadata: {}
  },
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Not Equal To",
    name: "not_equals",
    metadata: {}
  },
  {
    id: "f3d3c1af-0066-4884-8533-917ec2c71fd1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "One Of",
    name: "one_of",
    metadata: {}
  },
  {
    id: "f56f9948-7745-4203-928f-e75c481d13d8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Between",
    name: "between",
    metadata: {}
  },
  {
    id: "c2e22f65-ce15-42cc-a99f-7e5bca84b69f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "63ec8fb7-357f-403a-b753-6df8a3f25737",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "More Than",
    name: "more_than",
    metadata: {}
  },
  {
    id: "162eedc3-3ace-48c2-8a38-0c1db9058d8a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    name: "contains",
    metadata: {}
  },
  {
    id: "60e18406-a4a7-44a4-8b91-2481710fb4e8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    name: "starts_with",
    metadata: {}
  },
  {
    id: "d3b7f462-d154-4bfa-8645-3f74a958bed6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    name: "ends_with",
    metadata: {}
  },
  {
    id: "d1a02de2-8928-4517-884d-502bdb8d8409",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "fa2b1831-9ceb-4808-984e-1f834a723c56",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Greater Than",
    name: "greater-than",
    metadata: {}
  },
  {
    id: "a2c10af5-c9dd-401c-b28c-59bb48c85345",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Not Empty",
    name: "is_not_empty",
    metadata: {}
  },
  {
    id: "8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Empty",
    name: "is_empty",
    metadata: {}
  },
  {
    id: "73963f47-092a-4bf2-a38a-50dca50ca5e6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before",
    name: "before",
    metadata: {}
  },
  {
    id: "a830cb78-e9f2-4259-9753-d6259bea1bed",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before On",
    name: "before_on",
    metadata: {}
  },
  {
    id: "d23be707-a71d-44bd-8b61-9489e84f1a2d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After On",
    name: "after_on",
    metadata: {}
  },
  {
    id: "8648374e-f78a-4322-ac67-67467d4fbff5",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After",
    name: "after",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var DevKit = class {
  getDeps() {
    const exts = this.extensions();
    const dependencies = exts.map((it) => it.packages ?? []).flat();
    const possibleDeps = [
      {
        name: "discord.js",
        version: "^14.15.3",
        dev: false
      }
    ];
    return [...dependencies, ...possibleDeps].reduce((acc, it) => {
      return {
        ...acc,
        [it.name]: it.version
      };
    }, {});
  }
  getExtensionActions(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return actions_default.filter((it) => it.extensionId === id);
  }
  actions() {
    return actions_default;
  }
  async getExtensionTriggers(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return (await this.triggers()).filter((it) => it.extensionId === id);
  }
  async triggers() {
    return (await this.actions()).filter((it) => it.type === "trigger");
  }
  extensions() {
    return extensions_default;
  }
  toJson(obj) {
    return JSON.stringify(obj, null, 2);
  }
  async getValidationsByIds(ids) {
    const validations = await this.validations();
    const list = [];
    for (const id of ids) {
      const validation = validations.find((it) => it.id === id);
      if (!validation) {
        throw new Error(`Validation with id ${id} not found`);
      }
      list.push(validation);
    }
    return list;
  }
  async getValidationsByNames(names) {
    const validations = await this.validations();
    const list = [];
    for (const name of names) {
      const validation = validations.find((it) => it.name === name);
      if (!validation) {
        throw new Error(`Validation with name ${name} not found`);
      }
      list.push(validation);
    }
    return list;
  }
  async getFieldsByExtension() {
    return await this.fields();
  }
  fields() {
    return fields_default;
  }
  validations() {
    return validations_default;
  }
  operators() {
    return operators_default;
  }
};
__name(DevKit, "DevKit");
DevKit = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], DevKit);
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input, sub) {
  const index = input.indexOf(sub);
  if (index === -1) {
    return input;
  }
  return input.slice(sub.length);
}
__name(substring, "substring");
function getSourceActionById(id) {
  const action = actions_default.find((it) => it.id === id);
  if (!action) {
    throw new Error(`Action with id ${id} not found`);
  }
  return action;
}
__name(getSourceActionById, "getSourceActionById");
function getExtensionById(id) {
  const item = extensions_default.find((it) => it.id === id);
  if (!item) {
    throw new Error(`Extension with id ${id} not found`);
  }
  return item;
}
__name(getExtensionById, "getExtensionById");
function getValidationByName(name) {
  const validation = validations_default.find((a) => a.name === name);
  if (!validation) {
    throw new Error(`Validation with name ${name} not found`);
  }
  return validation;
}
__name(getValidationByName, "getValidationByName");
function getSourceFieldById(id) {
  const field = fields_default.find((it) => it.id === id);
  if (!field) {
    throw new Error(`Field with id ${id} not found`);
  }
  return field;
}
__name(getSourceFieldById, "getSourceFieldById");
function getSourceFieldByName(name) {
  const field = fields_default.find((it) => it.name === name);
  if (!field) {
    throw new Error(`Field with name ${name} not found`);
  }
  return field;
}
__name(getSourceFieldByName, "getSourceFieldByName");
function assignDefaults(metadata, details) {
  Object.entries(metadata ?? {}).forEach(([name, config2]) => {
    if (details[name] === void 0 && config2.defaultValue !== void 0) {
      details[name] = config2.defaultValue;
    }
  });
  return details;
}
__name(assignDefaults, "assignDefaults");
function getTriggerByName(name) {
  const trigger = actions_default.find(
    (it) => it.type === "trigger" && it.name === name
  );
  if (!trigger) {
    throw new Error(`Trigger with name ${name} not found`);
  }
  return trigger;
}
__name(getTriggerByName, "getTriggerByName");
function getValidationById(id) {
  const validation = validations_default.find((it) => it.id === id);
  if (!validation) {
    throw new Error(`Validation with id ${id} not found`);
  }
  return validation;
}
__name(getValidationById, "getValidationById");
function getSourceActionByName(name) {
  if (isNullOrUndefined(name)) {
    throw new Error(
      "getSourceActionByName:name is required. received: " + name
    );
  }
  const action = actions_default.find((it) => it.name === name);
  if (!action) {
    throw new Error(`Action with name ${name} not found`);
  }
  return action;
}
__name(getSourceActionByName, "getSourceActionByName");
function getExtensionByName(name) {
  const item = extensions_default.find((it) => it.name === name);
  if (!item) {
    throw new Error(`Extension with name ${name} not found`);
  }
  return item;
}
__name(getExtensionByName, "getExtensionByName");

// libs/compiler/sdk/devkit/src/lib/project-config.ts
var _config;
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
__name(ProjectConfig, "ProjectConfig");
ProjectConfig = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable3, Injector, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
var config = {
  basePath: "./src",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  _projectConfig = Injector.GetRequiredService(ProjectConfig);
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = /* @__PURE__ */ __name((importPath) => {
    return join2("#{relative}", config.basePath, importPath);
  }, "makeCoreImportSpecifier");
  makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  }, "makeEntityImportSpecifier");
  makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
  makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
  makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "identity", fileName), "makeIdentityPath");
  makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
  makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  ), "makeWorkspacePath");
  makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
  makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  ), "makeCommandPath");
  makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
  makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  ), "makeControllerPath");
  makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  ), "makeControllerRoutePath");
  makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  ), "makeListenerRoutePath");
  makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  ), "makeJobRoutePath");
  makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  ), "makeEntityPath");
  makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  ), "makeQueryPath");
  makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
};
__name(ProjectFS, "ProjectFS");
ProjectFS = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], ProjectFS);
var commandsGlob = /* @__PURE__ */ __name(() => {
  return `${config.features}/**/*.command.ts`;
}, "commandsGlob");
var routersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.router.ts";
}, "routersGlob");
var listenersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.github.ts";
}, "listenersGlob");
var cronsGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.cron.ts";
}, "cronsGlob");
var entitiesGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.entity.ts";
}, "entitiesGlob");
var makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
var makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
var makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "identity", fileName), "makeIdentityPath");
var makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
var makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
  config.basePath,
  "../",
  /** We need this to work with new january cli */
  "../",
  fileName
), "makeWorkspacePath");
var makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
var makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => makeFeatureFile(
  featureName,
  join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
), "makeCommandPath");
var makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
var makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
), "makeControllerRoutePath");
var makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
), "makeListenerRoutePath");
var makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
), "makeJobRoutePath");
var makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
  config.features,
  spinalcase2(featureName),
  `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
), "makeEntityPath");
var makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
  config.features,
  spinalcase2(tableName),
  "queries",
  `${spinalcase2(queryName)}.query.ts`
), "makeQueryPath");
var makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
var makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
  return join2("#{entity}", pascalcase(tableName));
}, "makeEntityImportSpecifier");
var makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
), "makeControllerPath");
var makeFeaturePath = /* @__PURE__ */ __name((fileName) => join2(config.features, fileName), "makeFeaturePath");

// libs/extensions/src/firebase/functions.ts
import yaml from "js-yaml";
var deployContent = /* @__PURE__ */ __name(() => {
  return yaml.dump(
    {
      name: "Deploy To Firebase Functions",
      on: {
        // push: {
        //   branches: ['main'],
        // },
        workflow_dispatch: {
          inputs: {
            correlationId: {
              description: '"Correlation Id"',
              required: true
            }
          }
        }
      },
      env: {
        FASLH_API_URL: "https://us-central1-january-9f554.cloudfunctions.net/ghevents"
        // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
      },
      jobs: {
        deploy_to_firebase_functions: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            {
              id: "cache",
              name: "Cache Or Restore Node Modules",
              uses: "actions/cache@v3",
              with: {
                path: "node_modules",
                key: "node-modules-${{ hashFiles('package-lock.json') }}"
              }
            },
            {
              id: "install_deps",
              name: "Install Deps",
              run: "npm install --no-audit --no-fund"
            },
            {
              id: "build",
              name: "Build",
              run: "npm run build:prod -- --entry ./src/firebase-functions.ts"
            },
            {
              id: "deploy",
              name: "Deploy to Firebase",
              uses: "w9jds/firebase-action@master",
              with: {
                args: "deploy --only functions --debug"
              },
              env: {
                GCP_SA_KEY: `\${{ secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY }}`,
                PROJECT_ID: `\${{ secrets.FIREBASE_FUNCTION_PROJECT_ID }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
}, "deployContent");
var functions = {
  packages: {
    "firebase-functions": {
      version: "^5.0.1",
      dev: false
    },
    "firebase-admin": {
      version: "^12.4.0",
      dev: false
    }
  },
  files: {
    "../.github/workflows/deploy.yml": deployContent(),
    "server.ts": `
		import * as functions from 'firebase-functions';
		import application from './app';
		exports.api = functions.https.onRequest(application.callback());
		exports.hello = functions.https.onRequest((req, res) => {
			res.json({ result: 'Hello from Firebase!' });
		});
		`,
    "../firebase.json": toJson({
      functions: [
        {
          ignore: ["**/node_modules/**", "**/src/**", "**/public/**"],
          codebase: "faslh",
          source: "dist",
          runtime: "nodejs16"
        }
      ]
    })
  }
};

// libs/extensions/src/firebase/auth/firebase-app-setup.txt
var firebase_app_setup_default = "import { cert, initializeApp } from 'firebase-admin/app';\nimport type { GoogleServiceAccount } from '../../core/service-account';\n\nconst serviceAccount: GoogleServiceAccount = JSON.parse(\n	Buffer.from(process.env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY, 'base64').toString(\n		'ascii'\n	)\n);\n\nexport const firebaseApp = initializeApp({\n	credential: cert({\n		clientEmail: serviceAccount.client_email,\n		privateKey: serviceAccount.private_key,\n		projectId: serviceAccount.project_id,\n	}),\n	projectId: serviceAccount.project_id,\n	serviceAccountId: serviceAccount.client_email,\n});\n";

// libs/extensions/src/firebase/auth/service-account-interface.txt
var service_account_interface_default = "export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n";

// libs/extensions/src/firebase/auth/subject.txt
var subject_default = "import { DecodedIdToken, getAuth } from 'firebase-admin/auth';\nimport { IncomingMessage } from 'http';\nimport { getClientIp } from 'request-ip';\nimport UAParser, { IResult } from 'ua-parser-js';\nimport { firebaseApp } from './firebase';\nimport {\n  ProblemDetails,\n  ProblemDetailsException,\n} from 'rfc-7807-problem-details';\n\nexport interface ClientInfo {\n  ip?: string | null;\n  userAgent?: string | null;\n  userAgentData: IResult;\n}\n\nexport type IdentitySubject = {\n  claims: DecodedIdToken;\n};\n\nexport const auth = getAuth(firebaseApp);\n\nfunction isBearerToken(\n  token: string | null | undefined,\n): token is `Bearer ${string}` {\n  if (!token || typeof token !== 'string') {\n    return false;\n  }\n\n  if (!token.startsWith('Bearer ')) {\n    return false;\n  }\n\n  return true;\n}\n\nexport async function verifyToken(\n  token: string | null | undefined,\n): Promise<boolean> {\n  if (!isBearerToken(token)) {\n    throw new ProblemDetailsException(\n      new ProblemDetails(\n        'unauthorized',\n        'Unauthorized',\n        401,\n        'Authorization header is missing or invalid',\n      ),\n    );\n  }\n\n  try {\n    await auth.verifyIdToken(token.replace('Bearer ', ''));\n    return true;\n  } catch (error) {\n    return false;\n  }\n}\n\nexport async function loadSubject(\n  token: string | null | undefined,\n): Promise<IdentitySubject | null> {\n  if (!isBearerToken(token)) {\n    return null;\n  }\n\n  try {\n    const claims = await auth.verifyIdToken(token.replace('Bearer ', ''));\n    return { claims };\n  } catch (error) {\n    return null;\n  }\n}";

// libs/extensions/src/firebase/auth/index.ts
var auth = {
  packages: {
    "firebase-admin": {
      version: "^12.4.0",
      dev: false
    },
    "ua-parser-js": {
      version: "^1.0.37",
      dev: false
    },
    "@types/ua-parser-js": {
      version: "^0.7.39",
      dev: true
    },
    "@types/request-ip": {
      version: "^0.0.41",
      dev: true
    },
    "request-ip": {
      version: "^3.3.0",
      dev: false
    }
  },
  files: {
    "src/core/service-account.ts": service_account_interface_default,
    "src/extensions/firebase-auth/firebase.ts": firebase_app_setup_default,
    "src/extensions/firebase-auth/subject.ts": subject_default,
    "src/extensions/firebase-auth/index.ts": `
    export * from './subject';
    export * from './firebase';
import z from 'zod';
export const env = {
  FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: z.string()
}
`
  }
};
export {
  auth,
  functions
};
//# sourceMappingURL=index.js.map
