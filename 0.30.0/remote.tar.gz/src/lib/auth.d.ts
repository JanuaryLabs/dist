import { type User } from 'firebase/auth';
export declare function anonymouslySignIn(): Promise<{
    user: User;
    token: string;
}>;
export declare function signInWithGithub(): Promise<{
    user: User;
    token: string;
    accessToken?: undefined;
} | {
    user: null;
    token?: undefined;
    accessToken?: undefined;
} | {
    user: User;
    token: string;
    accessToken: string | undefined;
}>;
export declare function linkAccountWithGithub(): Promise<{
    user: User;
    token: string;
    accessToken?: undefined;
} | {
    user: null;
    token?: undefined;
    accessToken?: undefined;
} | {
    user: User;
    token: string;
    accessToken: string | undefined;
} | undefined>;
export declare function signInWithGoogle(): Promise<{
    user: User;
    token: string;
    accessToken?: undefined;
} | {
    user: User;
    token: string;
    accessToken: string | undefined;
} | {
    user: null;
    token?: undefined;
    accessToken?: undefined;
}>;
export declare function signUpWithEmail(email: string, password: string): Promise<{
    user: User;
    token: string;
}>;
export declare function signInWithEmail(email: string, password: string): Promise<{
    user: User;
    token: string;
} | {
    user: null;
    token?: undefined;
}>;
export declare function initialise(): Promise<User | null>;
