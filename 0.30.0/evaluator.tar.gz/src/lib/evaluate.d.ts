import type { EmptyProject, TriggerDefinition, WorkflowDefinition } from '@january/declarative';
import type { diagnostic } from '@january/sdk/parser';
import { Checker } from '@january/sdk/parser';
export interface RuleService {
    isUniqueWorkflow: (name: string) => boolean;
    hasTable: (name: string) => boolean;
    hasField: (name: string) => boolean;
    validateName: (name: unknown, context: string) => string[];
    inUniqueFeature: (name: string) => boolean;
    getFeature: (descendantNode: any) => EmptyProject['features'][0] | undefined;
    getWorkflow: (descendantNode: any) => WorkflowDefinition<TriggerDefinition<unknown, unknown>> | undefined;
    duplicateWorkflowTriggerConfig: (relatedWorkflow: unknown, compare: (workflowConfig: WorkflowDefinition<TriggerDefinition<unknown, unknown>>, feature: EmptyProject['features'][0]) => boolean) => boolean;
}
export declare function defensiveEvaluate(code: string): Promise<{
    reports: diagnostic.Diagnostic[];
    definition: EmptyProject;
}>;
export declare function evaluate(code: string): Promise<{
    feature: EmptyProject["features"][0];
    imports: Checker.ProjectImport[];
}>;
export declare function compare(a: string, b: string): Promise<boolean>;
