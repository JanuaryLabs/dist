export declare const bun: {
    (config: {
        buildCommand: string;
        entrypoint: string;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
