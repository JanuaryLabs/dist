import type { Stage, StartStage } from './declarative';
type RuntimeConfig = Omit<Stage, 'cmd' | 'port' | 'user'> & {
    allowWrite?: string[];
};
interface NodeRuntimeConfig extends RuntimeConfig {
    entry: string | {
        type: 'script';
        value: string;
    } | {
        type: 'file';
        value: string;
    };
}
interface BunRuntimeConfig extends RuntimeConfig {
    entry: string;
}
export declare function nodeServer(entrypoint: string): StartStage;
export declare function nodeServer(config: NodeRuntimeConfig): StartStage;
export declare namespace nodeServer {
    var image: string;
    var pm: string;
    var dockerignore: string[];
}
interface DenoRuntimeConfig extends RuntimeConfig {
    entry: {
        type: 'script';
        value: string;
    } | {
        type: 'file';
        value: string;
        flags: ('--allow-net' | '--allow-env' | '--allow-read' | '--allow-write')[];
    } | {
        type: 'executable';
        value: string;
    };
}
export declare function denoServer(entrypoint: string): StartStage;
export declare function denoServer(config: DenoRuntimeConfig): StartStage;
export declare namespace denoServer {
    var image: string;
    var pm: string;
    var dockerignore: string[];
}
export declare function bunServer(entrypoint: string): StartStage;
export declare function bunServer(config: BunRuntimeConfig): StartStage;
export declare namespace bunServer {
    var image: string;
}
export declare function nginx(config?: Omit<RuntimeConfig, 'entrypoint' | 'from'> & {
    from?: RuntimeConfig['from'];
}): StartStage;
export declare function httpd(): StartStage;
export {};
