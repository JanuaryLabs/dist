export declare const dotnet: {
    (config: {
        projectName: string;
        healthCheck?: string;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
