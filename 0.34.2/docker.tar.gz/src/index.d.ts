export * from './lib/compose/compose';
export * from './lib/file';
export * from './lib/instance';
export * from './lib/npm';
export * from './lib/utils';
export declare function mergeEnvs(...files: string[]): Promise<Record<string, string>>;
