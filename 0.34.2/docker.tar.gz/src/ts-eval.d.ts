import type { EmptyProject } from '@january/declarative';
/**
 * Run node.js or typescript untrusted (user) code in a container
 */
export declare function runUntrustedCode(userCode: string): Promise<EmptyProject[]>;
