export declare function createRemoteServer(config: {
    domainPrefix: string;
}, processImage: () => Promise<string>, env: Record<string, string> | undefined, signal: AbortSignal, instructions: {
    internalPort: number;
    Healthcheck?: Record<string, any>;
    hostPort?: string;
}): Promise<string>;
export declare function liveness(projectUrl: string): Promise<void>;
export declare function createRemoteContainer(containerName: string, imageTag: string, signal: AbortSignal, instructions: {
    internalPort: number;
    hostPort?: string;
    Healthcheck?: Record<string, any>;
}, env?: Record<string, string>): Promise<import("dockerode").Container>;
export declare function makeProjectPath(projectId: string): string;
export declare function makeRunningImageName(projectId: string): string;
export declare function makeRunningContainerName(projectId: string): string;
