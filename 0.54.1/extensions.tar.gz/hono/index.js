var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/extensions/src/hono/consume.txt
var consume_default = "import type { trigger } from '@january/declarative';\nimport type { Context } from 'hono';\nimport { createMiddleware } from 'hono/factory';\nimport { type RedirectStatusCode } from 'hono/utils/http-status';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nexport const consume = (contentType: string) => {\n  return createMiddleware(async (context, next) => {\n    const clientContentType = context.req.header('Content-Type');\n    if (clientContentType !== contentType) {\n      throw new ProblemDetailsException({\n        title: 'Unsupported Media Type',\n        status: 415,\n        detail: `Expected content type: ${contentType}, but got: ${clientContentType}`,\n      });\n    }\n    await next();\n  });\n};\n";

// libs/extensions/src/hono/output.txt
var output_default = "import type { Context } from 'hono';\nimport { getContext } from 'hono/context-storage';\nimport type {\n  ContentfulStatusCode,\n  RedirectStatusCode,\n} from 'hono/utils/http-status';\n\ntype Data = any;\nfunction send(\n  context: Context,\n  value: Data | null | undefined,\n  status: ContentfulStatusCode,\n  headers?: Readonly<Record<string, string>>,\n) {\n  if (value === undefined || value === null) {\n    return context.body(null, status, headers);\n  }\n  const responseHeaders = { ...headers };\n  responseHeaders['Content-Type'] ??= 'application/json';\n  if (responseHeaders['Content-Type'].includes('application/json')) {\n    return context.body(JSON.stringify(value), status, responseHeaders);\n  }\n  return context.body(value, status, responseHeaders);\n}\n\nexport function createOutput(contextFn: () => Context) {\n  return {\n    nocontent() {\n      const context = contextFn();\n      return context.body(null, 204, {});\n    },\n    ok(value?: Data | null, headers?: Record<string, string>) {\n      return send(contextFn(), value, 200, headers);\n    },\n    created(\n      valueOrUri: string | Data,\n      value?: Data | null,\n      headers?: Record<string, string>,\n    ) {\n      if (typeof valueOrUri === 'string') {\n        // If no content is provided, we send null\n        return send(contextFn(), value, 201, {\n          Location: valueOrUri,\n          ...(headers || {}),\n        });\n      } else {\n        // valueOrUri is the data\n        return send(contextFn(), valueOrUri, 201, headers);\n      }\n    },\n    redirect(uri: string | URL, statusCode?: unknown) {\n      const context = contextFn();\n      return context.redirect(\n        uri.toString(),\n        (statusCode as RedirectStatusCode) ?? undefined,\n      );\n    },\n    attachment(buffer: Buffer, filename: string, mimeType: string) {\n      const context = contextFn();\n      // https://github.com/honojs/hono/issues/3720\n      return context.body(buffer as never, 200, {\n        'Content-Type': mimeType,\n        'Content-Disposition': `attachment; filename=\"${filename}\"`,\n        'Content-Length': buffer.length.toString(),\n      });\n    },\n    badRequest(\n      value?: Data | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 400, headers);\n    },\n    unauthorized(\n      value?: Data | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 401, headers);\n    },\n    forbidden(\n      value?: Data  | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 403, headers);\n    },\n    notFound(value?: Data  | null, headers?: Record<string, string>) {\n      return send(contextFn(), value, 404, headers);\n    },\n    notImplemented(\n      value?: Data  | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 501, headers);\n    },\n    accepted(value?: Data  | null, headers?: Record<string, string>) {\n      return send(contextFn(), value, 202, headers);\n    },\n    conflict(value?: Data  | null, headers?: Record<string, string>) {\n      return send(contextFn(), value, 409, headers);\n    },\n    unprocessableEntity(\n      value?: Data  | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 422, headers);\n    },\n    internalServerError(\n      value?: Data  | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 500, headers);\n    },\n    serviceUnavailable(\n      value?: Data  | null,\n      headers?: Record<string, string>,\n    ) {\n      return send(contextFn(), value, 503, headers);\n    },\n  };\n}\n\nexport default createOutput(() => getContext());\n";

// libs/extensions/src/hono/setup.txt
var setup_default = "import './features/crons';\nimport './features/listeners';\nimport { Hono } from 'hono';\nimport { cors } from 'hono/cors';\nimport { logger } from 'hono/logger';\nimport { timing } from 'hono/timing';\nimport { type StatusCode } from 'hono/utils/http-status';\nimport { contextStorage } from 'hono/context-storage';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nimport { loadSubject } from '#core/identity/subject.ts';\nimport { type HonoEnv } from '#core/utils.ts';\nimport routes from './features/routes';\n\nconst application = new Hono<HonoEnv>();\napplication.use(timing(), cors(), logger(), contextStorage());\n\napplication.notFound(() => {\n	throw new ProblemDetailsException({\n		title: 'Not Found',\n		status: 404,\n		detail: 'The requested resource could not be found',\n	});\n});\n\napplication.onError((err, context) => {\n	if (err instanceof ProblemDetailsException) {\n		context.status((err.Details.status as StatusCode) ?? 500);\n		return context.json(err.Details);\n	}\n\n	console.error(err);\n\n	context.status(500);\n	return context.json({\n		title: 'Internal Server Error',\n		status: 500,\n		detail: 'An unexpected error occurred',\n	});\n});\n\nroutes.forEach(([path, route]) => {\n	application.route(path, route);\n});\n\nexport default application;\n";

// libs/extensions/src/hono/validator.txt
var validator_default = "import { createMiddleware } from 'hono/factory';\nimport { HTTPException } from 'hono/http-exception';\nimport z from 'zod';\n\ntype ValidatorConfig = Record<\n  string,\n  { select: unknown; against: z.ZodTypeAny }\n>;\n\ntype ExtractInput<T extends ValidatorConfig> = {\n  [K in keyof T]: z.infer<T[K]['against']>;\n};\n\nexport const validate = <T extends ValidatorConfig>(\n  selector: (payload: {\n    body: Record<string, unknown>;\n    query: Record<string, string>;\n    queries: Record<string, string[]>;\n    params: Record<string, string>;\n    headers: Record<string, string>;\n  }) => T,\n) => {\n  return createMiddleware<{\n    Variables: {\n      input: ExtractInput<T>;\n    };\n  }>(async (c, next) => {\n    const contentType = c.req.header('content-type') ?? '';\n    let body: unknown = null;\n\n    switch (contentType) {\n      case 'application/json':\n        body = await c.req.json();\n        break;\n      case 'application/x-www-form-urlencoded':\n        body = await c.req.parseBody();\n        break;\n      default:\n        body = {};\n    }\n\n    const payload = {\n      body: body as Record<string, unknown>,\n      query: c.req.query(),\n      queries: c.req.queries(),\n      params: c.req.param(),\n      headers: Object.fromEntries(\n        Object.entries(c.req.header()).map(([k, v]) => [k, v ?? '']),\n      ),\n    };\n\n    const config = selector(payload);\n    const schema = z.object(\n      Object.entries(config).reduce(\n        (acc, [key, value]) => {\n          acc[key] = value.against;\n          return acc;\n        },\n        {} as Record<string, z.ZodTypeAny>,\n      ),\n    );\n\n    const input = Object.entries(config).reduce(\n      (acc, [key, value]) => {\n        acc[key] = value.select;\n        return acc;\n      },\n      {} as Record<string, unknown>,\n    );\n\n    const parsed = parse(schema, input);\n    c.set('input', parsed as ExtractInput<T>);\n    await next();\n  });\n};\n\nexport function parse<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: unknown,\n) {\n  const result = schema.safeParse(input);\n  if (!result.success) {\n    const error = new HTTPException(400, {\n      message: 'Validation failed',\n      cause: {\n        code: 'api/validation-failed',\n        details: result.error.flatten((issue) => ({\n          message: issue.message,\n          code: issue.code,\n          fatel: issue.fatal,\n          path: issue.path.join('.'),\n        })).fieldErrors,\n      },\n    });\n    throw error;\n  }\n  return result.data;\n}\n\nexport const openapi = validate;\n ";

// libs/extensions/src/hono/zod.txt
var zod_default = "import { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { z } from 'zod';\n\nexport function parse<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: unknown,\n) {\n  const result = schema.safeParse(input);\n  if (!result.success) {\n    const errors = result.error.flatten((issue) => ({\n      message: issue.message,\n      code: issue.code,\n      fatel: issue.fatal,\n      path: issue.path.join('.'),\n    })).fieldErrors;\n    return [null, errors];\n  }\n  return [result.data, null];\n}\n\nexport function parseOrThrow<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: unknown,\n): z.infer<z.ZodObject<T>> {\n  const [data, errors] = parse(schema, input);\n  if (errors) {\n    const exception = new ProblemDetailsException({\n      type: 'validation-failed',\n      status: 400,\n      title: 'Bad Request.',\n      detail: 'Validation failed.',\n    });\n    exception.Details.errors = errors;\n    throw exception;\n  }\n  return data as z.infer<z.ZodObject<T>>;\n}\n";

// libs/extensions/src/hono/index.ts
import { join as join4 } from "node:path";
import { StructureKind as StructureKind4 } from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "node:path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}

// libs/compiler/generator/src/index.ts
import { isFunction } from "lodash-es";
import {
  Project as Project3,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project, SyntaxKind, VariableDeclarationKind } from "ts-morph";

// libs/compiler/generator/src/lib/sourcecode.ts
import { basename, dirname, extname, join as join3, relative, sep } from "node:path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project2,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";

// libs/compiler/generator/src/lib/project-fs.ts
import { join as join2 } from "node:path";
import { Injectable, ServiceLifetime } from "tiny-injector";
var config = {
  basePath: "./src/app",
  extensions: "./src/app/extensions",
  features: "./src/app/features",
  entities: "./src/app/entities"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join2(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join2(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join2(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeQueryPath = (tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectFS);
var commandsGlob = () => {
  return `${config.features}/**/*.command.ts`;
};
var routersGlob = () => {
  return "/**/*.router.ts";
};
var listenersGlob = () => {
  return "/**/*.github.ts";
};
var cronsGlob = () => {
  return "/**/*.cron.ts";
};
var entitiesGlob = () => {
  return "/**/*.entity.ts";
};
var makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
var makeControllerPath = (featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
);
var makeRoutePath = (featureName, name, suffix = "route") => makeFeatureFile(
  featureName,
  `${spinalcase2(name)}.${dotcase(`${suffix} ts`)}`
);
var makeFeaturePath = (fileName) => join2(config.features, fileName);

// libs/compiler/generator/src/lib/sourcecode.ts
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project2(options);
}
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join3(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
      }
    }
  }
};
findClassSourceFile_fn = function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
};
exportsDir_fn = function(dir) {
  const fullPath = join3(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportsCommands_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName)}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join3(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
};
exportRoutes_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { type HonoEnv } from '#core/utils.ts';import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono<HonoEnv>][]`,
    { overwrite: true }
  );
};
exportListeners_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportJobs_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportEntities_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from '../${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities ${exportDefaults.length ? "" : ": any[]"} = [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
};
tuneImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport || it.namespaceImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: false,
        namespaceImport: it.namespaceImport
      });
    }
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: true
      });
    }
  });
};
removeUnusedImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).filter((it) => !it.getAncestors().includes(importDeclaration)).some((it) => it.getText() === importedName);
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
};
moveImportsToTop_fn = function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index) => {
    file.insertImportDeclaration(index, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText(),
        isTypeOnly: namedImport.isTypeOnly()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
};
VirtualProject = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}

// libs/compiler/generator/src/index.ts
function getArrowFnBody(arrowFn) {
  const project = new Project3({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${arrowFn}`
  );
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind3.ArrowFunction);
  return guardFunction?.getBodyText();
}
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${typeof arg === "undefined" ? "" : arg})`;
  const guard = transferable.toString();
  const project = new Project3({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const subjectIdentifierText = "subject";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind3.ArrowFunction);
  let subjectUsed = false;
  const [config2] = guardFunction.getParameters();
  if (config2) {
    const name = config2.getNameNode();
    if (name.isKind(SyntaxKind3.ObjectBindingPattern)) {
      const properties = name.getElements();
      subjectUsed = properties.some(
        (prop) => prop.getName() === subjectIdentifierText
      );
    }
  }
  const inputs = /* @__PURE__ */ new Map();
  const parameters = guardFunction.getParameters();
  for (const [key, value] of Object.entries(options.inputs ?? {})) {
    if (isFunction(value)) {
      const result = value(parameters, subjectUsed);
      if (result) {
        inputs.set(key, result);
      }
    } else {
      inputs.set(key, value);
    }
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind3.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind3.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind3.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind2.ImportDeclaration,
      moduleSpecifier: `#entities/${spinalcase2(propertyAccess.getName())}.entity.ts`,
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!parent) {
      const triggerInput = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      inputs.set("trigger", triggerInput);
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind3.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind3.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind3.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs.set(v, {
      // TODO: do we still use "input"?
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()",
        source: "internal"
      }
    });
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = (ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind3.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  };
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind3.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  const atLeastOneOutputReturn = returns.some(isOutputReturn);
  if (!atLeastOneOutputReturn) {
    for (const ret of returns) {
      if (isOutputReturn(ret)) {
        continue;
      }
      const isReturningCall = ret.getExpressionIfKind(
        SyntaxKind3.CallExpression
      );
      let returnValue = ret.getText().trim().replace("return ", "");
      if (returnValue.endsWith(";")) {
        returnValue = returnValue.slice(0, -1);
      }
      if (returnValue === "return") {
        ret.replaceWithText(options.setOutput());
      } else {
        ret.replaceWithText(
          options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
        );
      }
    }
  }
  const body = guardFunction.getBodyText();
  const paramsUsed = [];
  if (parameters[0]) {
    const node = parameters[0].getNameNode();
    if (node.isKind(SyntaxKind3.ObjectBindingPattern)) {
      for (const name of node.getElements().map((prop) => prop.getName())) {
        if (name === "output" || name === "signal") continue;
        paramsUsed.push(name);
      }
    }
  }
  return {
    structures: tables,
    code: body,
    inputs: Object.fromEntries(inputs),
    metadata: { paramsUsed }
  };
}
function refineStreamExecute(transferable) {
  const guard = transferable.toString();
  const project = new Project3({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const subjectIdentifierText = "subject";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind3.ArrowFunction);
  const inputs = /* @__PURE__ */ new Map();
  const parameters = guardFunction.getParameters();
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind3.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind2.ImportDeclaration,
      moduleSpecifier: `#entities/${spinalcase2(propertyAccess.getName())}.entity.ts`,
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  const paramsUsed = [];
  if (parameters[0]) {
    const node = parameters[0].getNameNode();
    if (node.isKind(SyntaxKind3.ObjectBindingPattern)) {
      for (const name of node.getElements().map((prop) => prop.getName())) {
        if (name === "output" || name === "signal") continue;
        paramsUsed.push(name);
      }
    }
  }
  const returnNode = guardFunction.getFirstDescendantByKindOrThrow(
    SyntaxKind3.ReturnStatement
  );
  const returnText = returnNode.getText().replace("return ", "").replace(";", "");
  returnNode.remove();
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs: {},
    metadata: {
      paramsUsed,
      returnText
    }
  };
}

// libs/extensions/src/hono/trigger.ts
import { Project as Project4, SyntaxKind as SyntaxKind4 } from "ts-morph";
var honotriggers = {
  http(config2) {
    return {
      type: "http",
      inputs: config2.input ? inputize(config2.input) : {},
      config: {
        ...config2,
        structures: [`import { type trigger } from '@january/declarative';`]
      },
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => `input.${key}`,
          inputs: {
            request: (parameters) => parameters.length > 1 ? {
              static: true,
              type: "IncomingMessage",
              value: `(context.env as { incoming: IncomingMessage }).incoming`,
              data: {
                parameterName: "request",
                standalone: true
              },
              structure: [`import { IncomingMessage } from 'node:http';`]
            } : null
          }
        });
      }
    };
  },
  sse(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => "input"
        });
      }
    };
  },
  websocket(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  },
  stream(config2) {
    return {
      type: "stream",
      inputs: config2.input ? inputize(config2.input) : {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineStreamExecute(execute);
      }
    };
  },
  tus(config2) {
    const inputs = {};
    return {
      type: "tus",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  },
  file(config2) {
    return {
      type: "file",
      config: {
        ...config2,
        rewrite: config2.rewrite ? config2.rewrite.toString() : void 0
      },
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(
          () => {
          },
          {
            replaceKey: (key) => key
          }
        );
      }
    };
  }
};
function inputize(inputFn) {
  const inputs = {};
  const guard = inputFn.toString();
  const project = new Project4({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind4.ArrowFunction);
  if (guardFunction) {
    const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind4.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(SyntaxKind4.ReturnStatement);
    const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
      SyntaxKind4.ObjectLiteralExpression
    );
    returnObjExpr.getProperties().forEach((prop) => {
      const propAssignment = prop.asKindOrThrow(SyntaxKind4.PropertyAssignment);
      const propName = propAssignment.getName();
      const withSelectorAndAgainst = propAssignment.getInitializerIfKind(
        SyntaxKind4.ObjectLiteralExpression
      );
      if (withSelectorAndAgainst) {
        const propValue = withSelectorAndAgainst;
        const selectFn = propValue.getPropertyOrThrow(
          "select"
        );
        const againstFn = propValue.getProperty(
          "against"
        );
        const usageText = selectFn.getInitializerOrThrow().getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: againstFn.getInitializerOrThrow().getText(),
            source: rest[0]
          }
        };
      } else {
        const usageText = propAssignment.getInitializerIfKindOrThrow(SyntaxKind4.PropertyAccessExpression).getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: "z.any()",
            source: "internal"
          }
        };
      }
    });
  }
  return inputs;
}

// libs/extensions/src/hono/index.ts
var triggersManifest = [
  {
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger"
  },
  {
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    displayName: "File Trigger",
    name: "file",
    type: "trigger"
  },
  {
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];
var triggers = [
  "http",
  "sse",
  "stream",
  "github-trigger",
  "file",
  "tus",
  "node-cron-trigger"
];
var honoDefaultOptions = {
  useFeatureNameAsBasePath: false
};
function hono(options = honoDefaultOptions) {
  return {
    id: "hono",
    primitives: {
      trigger: honotriggers,
      policy: {
        http(transferable) {
          return (name) => `
    import { type Context } from 'hono';
    import { type HonoEnv } from '#core/utils.ts';

    export async function ${name}(context: Context<HonoEnv>): Promise<boolean> {
      ${getArrowFnBody(transferable)}
    }
  `;
        }
      }
    },
    packages: {
      boxen: {
        version: "^8.0.1",
        dev: false
      },
      "fast-glob": {
        version: "^3.3.2",
        dev: false
      },
      ip: {
        version: "^2.0.1",
        dev: false
      },
      "@types/ip": {
        version: "^1.1.3",
        dev: false
      },
      hono: {
        version: "^4.6.14",
        dev: false
      },
      "@hono/node-server": {
        version: "^1.13.7",
        dev: false
      },
      "@scalar/hono-api-reference": {
        version: "^0.5.165",
        dev: false
      },
      "@tus/file-store": {
        version: "^1.5.0",
        dev: false
      },
      "@tus/server": {
        version: "^1.8.0",
        dev: false
      }
    },
    files: {
      // this is here because we don't have core extension anymore, but that might change in the future
      "src/core/validation.ts": zod_default,
      "src/core/validator.ts": validator_default,
      "src/core/utils.ts": `import { type IdentitySubject } from '#core/identity/subject.ts';
export interface HonoEnv {
	Variables: { subject: IdentitySubject | null };
}
`,
      // 'src/extensions/hono/tus.ts': tus,
      "src/extensions/hono/output.ts": output_default,
      "src/extensions/hono/consume.ts": consume_default,
      "src/app.ts": { content: setup_default, ignoreIfExists: true }
    },
    onFeature(contract, { fs }) {
      const workflows = contract.workflows.filter(
        (it) => triggers.includes(it.trigger.sourceId)
      );
      if (!workflows.length) {
        return {};
      }
      const routes = workflows.reduce(
        (acc, workflow) => ({
          ...acc,
          [makeRoutePath(
            contract.displayName,
            spinalcase2(workflow.displayName)
          )]: createRoute(workflow, contract)
        }),
        {}
      );
      return {
        ...routes,
        [makeControllerPath(contract.displayName)]: [
          `import { Hono } from 'hono';`,
          `import { type HonoEnv } from '#core/utils.ts';`,
          "\n",
          `const router = new Hono<HonoEnv>();`,
          "\n",
          // FIXME: those should be imported lazely (fetch them once file written) to give the user chance to write custom route
          `for await (const route of [${workflows.map((it) => `import('./${spinalcase2(it.displayName)}.route.ts')`)}]){ route.default(router) }`,
          (writer) => writer.writeLine(
            `export default ['/${options.useFeatureNameAsBasePath ? spinalcase2(contract.displayName) : ""}', router] as const;`
          )
        ]
      };
    }
  };
}
function createRoute(workflow, contract) {
  const displayName = `${camelcase(workflow.featureName)}.${camelcase(
    workflow.trigger.displayName
  )}`;
  let workflowInputs = {};
  const standaloneInputs = {};
  const inputs = { ...workflow.inputs };
  for (const [key, value] of Object.entries(inputs)) {
    if (value.data?.["standalone"]) {
      standaloneInputs[key] = value;
      delete inputs[key];
    }
  }
  workflowInputs = {
    ...workflowInputs,
    ...standaloneInputs
  };
  const sourceTrigger = triggersManifest.find(
    (it) => it.name === workflow.trigger.sourceId
  );
  if (!sourceTrigger) {
    throw new Error(`Action with id ${workflow.trigger.sourceId} not found`);
  }
  const policies = workflow.trigger.policies.filter(Boolean);
  const imports = [
    ...Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean).flat(),
    `import { Hono } from 'hono';`,
    `import { type HonoEnv } from '#core/utils.ts';`
  ];
  let path = removeTrialingSlashes(
    addLeadingSlash(
      join4(
        contract.displayName !== "root" ? snakecase2(workflow.tag) : "/",
        workflow.trigger.details["path"]
      )
    )
  );
  path = path === "" ? "/" : path;
  const destructedVars = workflow.trigger.metadata.paramsUsed.length ? `const { ${workflow.trigger.metadata.paramsUsed} } = context.var;` : "";
  switch (sourceTrigger.name) {
    case "tus": {
      const displayName2 = `createUploader(${toLiteralObject(
        Object.fromEntries(
          Object.entries(workflow.trigger.details).filter(([key]) => !["path", "policies", "inputs"].includes(key)).concat([
            [
              "path",
              `'${addLeadingSlash(join4(snakecase2(contract.displayName), path))}'`
            ]
          ]).map(([key, value]) => [key, value])
        )
      )})`;
      return [
        ...imports,
        `import { createUploader } from '#hono';`,
        `router
              .all("${path}" ${policies.join(",")})
              .all("*", ${displayName2});`
      ];
    }
    case "http": {
      const method = workflow.trigger.details["method"].toLowerCase();
      const verb = `router.${method}`;
      const contentType = ["put", "patch", "post"].includes(method) ? 'consume("application/json")' : "";
      const selectors = Object.entries(workflow.inputs).map(([name, prop]) => {
        return `${name}: {select: payload.${prop.value}, against: ${prop.data?.zod ?? "z.any()"}}`;
      });
      const validator = `validate((payload) => ({${selectors.join(",")}}))`;
      const args = [
        `"${path}"`,
        policies.join(","),
        contentType,
        selectors.length ? validator : ""
      ].filter(Boolean);
      return [
        ...imports,
        `import { consume } from '#extensions/hono/consume.ts'`,
        `import { validate } from '#core/validator.ts';`,
        ...processWorkflow(
          workflow,
          `${verb.toLowerCase()}(${args.join(",")}, async (context,next)=>{
          ${destructedVars}
          ${workflow.code}
})`
        )
      ];
    }
    case "sse": {
      const verb = `router.get`;
      return [
        ...imports,
        createFn("output", {
          code: workflow.code
        }),
        `${verb.toLowerCase()}("${path}" ${policies.join(",")}, context => {
  return streamSSE(context, async (stream) => {

    for await (const chunk of await output()) {
      await stream.writeSSE({ data: JSON.stringify(chunk) });
    }
  });
              })`
      ];
    }
    case "stream": {
      const method = workflow.trigger.details["method"].toLowerCase();
      const verb = `router.${method}`;
      const contentType = ["put", "patch", "post"].includes(method) ? 'consume("application/json")' : "";
      const selectors = Object.entries(workflow.inputs).map(([name, prop]) => {
        return `${name}: {select: payload.${prop.value}, against: ${prop.data?.zod ?? "z.any()"}}`;
      });
      const validator = `validate((payload) => ({${selectors.join(",")}}))`;
      const args = [
        `"${path}"`,
        policies.join(","),
        contentType,
        validator
      ].filter(Boolean);
      return [
        `import { streamText } from 'hono/streaming';`,
        `import { consume } from '#extensions/hono/consume.ts'`,
        `import { validate } from '#core/validator.ts';`,
        ...imports,
        ...processWorkflow(
          workflow,
          `${verb.toLowerCase()}(${args.join(",")}, async (context,next)=>{
              ${destructedVars}
          const signal  = context.req.raw.signal;
            return streamText(context, async (stream) => {
              ${workflow.code}
              for await (const chunk of ${workflow.trigger.metadata.returnText}) {
                await stream.write(chunk);
              }
            });
          })`
          // FIXME: add stream method to output that will statically be mapped to for await
          // for await (const chunk of await output(${selectors.length ? 'input' : ''})) {
          //   await stream.write(chunk);
          // }
        )
      ];
    }
    case "file": {
      const verb = `router.use`;
      const rewrite = workflow.trigger.details["rewrite"] ? `rewriteRequestPath: ${workflow.trigger.details["rewrite"]}` : "";
      return `${verb.toLowerCase()}("${path}" ${policies.join(",")}, serveStatic({
                  root: join(relative(process.cwd(), import.meta.dirname), 'public', ${workflow.trigger.details["root"] ? `'${workflow.trigger.details["root"]}'` : ""}),
                  ${rewrite}
              }));`;
    }
    default:
      throw new Error(`Trigger ${sourceTrigger.name} is not supported`);
  }
}
function processWorkflow(contract, code) {
  const workflowInputs = contract.inputs;
  const workflowInputsStructures = Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean);
  const jsdocs = [
    "/**",
    ` * @openapi ${contract.displayName}`,
    ` * @tags ${contract.tag}`
  ];
  if (contract.description) {
    jsdocs.push(` * @description ${contract.description}`);
  }
  jsdocs.push(" */");
  return [
    ...contract.imports ?? [],
    ...workflowInputsStructures.flat(),
    ...contract.structures,
    {
      kind: StructureKind4.Function,
      isAsync: true,
      isDefaultExport: true,
      isExported: true,
      parameters: [{ name: "router", type: "Hono<HonoEnv>" }],
      statements: [...jsdocs, , code]
    }
  ];
}
function createFn(name, options) {
  return `export async function ${name}(${(options.parameters ?? []).map((it) => `${it.name}: ${it.type}`).join(",")}) {
    ${options.code}
  }`;
}
export {
  hono,
  honoDefaultOptions
};
//# sourceMappingURL=index.js.map
