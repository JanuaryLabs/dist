var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "23bfb249-0149-4033-a2a9-2dbec614d461",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "bytes",
    primitiveType: "Uint8Array",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      }
    },
    initialValidation: []
  },
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
function getSourceFieldById(id) {
  const field = fields_default.find((it) => it.id === id);
  if (!field) {
    throw new Error(`Field with id ${id} not found`);
  }
  return field;
}
function getValidationById(id) {
  const validation = validations_default.find((it) => it.id === id);
  if (!validation) {
    throw new Error(`Validation with id ${id} not found`);
  }
  return validation;
}

// libs/compiler/sdk/devkit/src/lib/project-config.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var _config;
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
ProjectConfig = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join } from "path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
var config = {
  basePath: "./src",
  extensions: "./src/extensions",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join("#{relative}", config.basePath, importPath);
  };
  makeEntityImportSpecifier = (tableName) => {
    return join("#{entity}", pascalcase(tableName));
  };
  makeFeatureFile = (featureName, fileName) => join(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeEntityPath = (featureName, tableName, suffix) => join(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  );
  makeQueryPath = (tableName, queryName) => join(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectFS);
var makeEntityPath = (featureName, tableName, suffix) => join(
  config.features,
  spinalcase2(featureName),
  `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
);

// libs/extensions/src/typeorm/typeorm.writer.ts
import * as morph from "ts-morph";
var TypeORMCodeWriter = class {
  constructor(_projectFS) {
    this._projectFS = _projectFS;
  }
  #generateField(contract) {
    const decorators = [];
    const structure = {
      kind: morph.StructureKind.Property,
      name: camelcase(contract.displayName),
      type: contract.primitiveType,
      decorators
    };
    return structure;
  }
  generateTable(contract) {
    const gf = contract.fields.map((it) => this.generateField(it));
    return [
      {
        kind: morph.StructureKind.ImportDeclaration,
        moduleSpecifier: "typeorm",
        namedImports: [
          "Brackets",
          "Entity",
          "PrimaryColumn",
          "PrimaryGeneratedColumn",
          "ManyToOne",
          "OneToMany",
          "OneToOne",
          "Column",
          "CreateDateColumn",
          "UpdateDateColumn",
          "DeleteDateColumn",
          "JoinColumn",
          "JoinTable",
          "ManyToMany",
          "Index",
          "RelationId",
          {
            name: "Relation",
            isTypeOnly: true
          }
        ]
      },
      ...gf.map((it) => it.topLevelStructure).flat(),
      {
        isDefaultExport: true,
        name: contract.tableName,
        kind: morph.StructureKind.Class,
        properties: gf.map((it) => it.fieldStructure),
        decorators: [
          {
            name: "Entity",
            arguments: [`"${pascalcase(contract.tableName)}"`]
          },
          ...gf.map((it) => it.classDecorators ?? []).flat(),
          ...(contract.indexes ?? []).map((index) => ({
            name: "Index",
            arguments: [
              `[${(index.columns ?? []).map((c) => `'${c}'`).join(",")}]`,
              /**index.unique*/
              true ? "{ unique: true }" : "{}"
            ]
          }))
        ]
      }
    ];
  }
  generateCreatedAtField(contract) {
    const structure = this.#generateField(contract);
    structure.decorators ??= [];
    structure.hasExclamationToken = true;
    structure.hasQuestionToken = false;
    structure.decorators.push({
      kind: morph.StructureKind.Decorator,
      name: "CreateDateColumn",
      arguments: []
    });
    return structure;
  }
  generateDeletedAtField(contract) {
    const structure = this.#generateField(contract);
    structure.decorators ??= [];
    structure.hasExclamationToken = false;
    structure.hasQuestionToken = true;
    structure.decorators.push({
      kind: morph.StructureKind.Decorator,
      name: "DeleteDateColumn",
      arguments: []
    });
    return structure;
  }
  generateUpdatedAtField(contract) {
    const structure = this.#generateField(contract);
    structure.decorators ??= [];
    structure.hasExclamationToken = false;
    structure.hasQuestionToken = true;
    structure.decorators.push({
      kind: morph.StructureKind.Decorator,
      name: "UpdateDateColumn",
      arguments: []
    });
    return structure;
  }
  generatePrimaryField(contract) {
    const structure = this.#generateField(contract);
    structure.decorators ??= [];
    structure.hasExclamationToken = true;
    structure.hasQuestionToken = false;
    switch (contract.keyType) {
      case "primary-key-custom":
        structure.decorators.push({
          kind: morph.StructureKind.Decorator,
          name: "PrimaryColumn",
          arguments: ['"varchar"']
        });
        break;
      case "primary-key-number":
        {
          if (contract.generated) {
            structure.decorators.push({
              kind: morph.StructureKind.Decorator,
              name: "PrimaryGeneratedColumn",
              arguments: ['"increment"']
            });
          } else {
            structure.decorators.push({
              kind: morph.StructureKind.Decorator,
              name: "PrimaryColumn",
              arguments: ['"integer"']
            });
          }
        }
        break;
      case "primary-key-uuid":
        if (contract.generated) {
          structure.decorators.push({
            kind: morph.StructureKind.Decorator,
            name: "PrimaryGeneratedColumn",
            arguments: ['"uuid"']
          });
        } else {
          structure.decorators.push({
            kind: morph.StructureKind.Decorator,
            name: "PrimaryColumn",
            arguments: ['"uuid"']
          });
        }
        break;
      default:
        throw new Error(
          `Primary key type "${contract.keyType}" is not supported.`
        );
    }
    return structure;
  }
  generateField(contract) {
    if (contract.nativeType === "primary-key") {
      return {
        fieldStructure: this.generatePrimaryField(contract),
        topLevelStructure: []
      };
    }
    if (contract.nativeType === "createdAt") {
      return {
        fieldStructure: this.generateCreatedAtField(contract),
        topLevelStructure: []
      };
    }
    if (contract.nativeType === "deletedAt") {
      return {
        fieldStructure: this.generateDeletedAtField(contract),
        topLevelStructure: []
      };
    }
    if (contract.nativeType === "updatedAt") {
      return {
        fieldStructure: this.generateUpdatedAtField(contract),
        topLevelStructure: []
      };
    }
    const structure = this.#generateField(contract);
    const topLevelStructure = [];
    const classDecorators = [];
    const columnOptions = [];
    structure.decorators ??= [];
    if (contract.mandatory) {
      structure.hasExclamationToken = true;
      structure.hasQuestionToken = false;
      columnOptions.push("nullable: false");
    } else {
      structure.hasExclamationToken = false;
      structure.hasQuestionToken = true;
      columnOptions.push("nullable: true");
      structure.type = `${structure.type}|null`;
    }
    switch (contract.nativeType) {
      case "relation-id":
        if (contract.virtualRelationField) {
          structure.decorators.push({
            kind: morph.StructureKind.Decorator,
            name: "RelationId",
            arguments: [
              `(entity: ${pascalcase(contract.tableName)}) => entity.${contract.columnNameOnSelfTable}`
            ]
          });
        }
        return {
          fieldStructure: structure,
          topLevelStructure
        };
      case "relation":
        structure.type = `Relation<${pascalcase(contract.relatedEntityName)}>`;
        switch (contract.relationship) {
          case "one-to-one":
            {
              topLevelStructure.push({
                kind: morph.StructureKind.ImportDeclaration,
                moduleSpecifier: this._projectFS.makeEntityImportSpecifier(
                  pascalcase(contract.relatedEntityName)
                ),
                defaultImport: pascalcase(contract.relatedEntityName)
              });
              if (contract.joinSide) {
                structure.decorators.push({
                  kind: morph.StructureKind.Decorator,
                  name: "JoinColumn",
                  arguments: []
                });
              }
              structure.decorators.push({
                kind: morph.StructureKind.Decorator,
                name: "OneToOne",
                arguments: [
                  `() => ${pascalcase(contract.relatedEntityName)}`,
                  `(relatedEntity) => relatedEntity.${camelcase(
                    contract.nameOfColumnOnRelatedEntity
                  )}`,
                  columnOptions.length ? `{${columnOptions.join(",")}}` : ""
                ]
              });
            }
            break;
          case "many-to-one":
          case "one-to-many":
            {
              topLevelStructure.push({
                kind: morph.StructureKind.ImportDeclaration,
                moduleSpecifier: this._projectFS.makeEntityImportSpecifier(
                  pascalcase(contract.relatedEntityName)
                ),
                defaultImport: pascalcase(contract.relatedEntityName)
              });
              if (contract.joinSide) {
                structure.decorators.push({
                  kind: morph.StructureKind.Decorator,
                  name: "ManyToOne",
                  arguments: [
                    `() => ${pascalcase(contract.relatedEntityName)}`,
                    `(relatedEntity) => relatedEntity.${contract.nameOfColumnOnRelatedEntity}`,
                    columnOptions.length ? `{${columnOptions.join(",")}}` : ""
                  ]
                });
              } else {
                structure.type = `${pascalcase(contract.relatedEntityName)}[]`;
                structure.decorators.push({
                  kind: morph.StructureKind.Decorator,
                  name: "OneToMany",
                  arguments: [
                    `() => ${pascalcase(contract.relatedEntityName)}`,
                    `(relatedEntity) => relatedEntity.${contract.nameOfColumnOnRelatedEntity}`,
                    columnOptions.length ? `{${columnOptions.join(",")}}` : ""
                  ]
                });
              }
            }
            break;
          case "many-to-many":
            {
            }
            break;
          default:
            throw new Error(
              `Relationship ${contract.relationship} is not supported.`
            );
        }
        return {
          fieldStructure: structure,
          topLevelStructure
        };
      case "json":
      case "uuid":
        if (contract.defaultValue !== void 0) {
          columnOptions.push(`default: "${contract.defaultValue}"`);
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        break;
      case "varchar":
        if (contract.defaultValue !== void 0) {
          columnOptions.push(`default: "${contract.defaultValue}"`);
        }
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        if (notNullOrUndefined(contract.length)) {
          columnOptions.push(`length: "${contract.length}"`);
        }
        if (contract.check) {
          topLevelStructure.push({
            kind: morph.StructureKind.ImportDeclaration,
            moduleSpecifier: "typeorm",
            namedImports: ["Check"]
          });
          classDecorators.push({
            kind: morph.StructureKind.Decorator,
            name: "Check",
            arguments: [`"${contract.check}"`]
          });
        }
        break;
      case "enum":
        if (contract.defaultValue !== void 0) {
          columnOptions.push(`default: "${contract.defaultValue}"`);
        }
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        columnOptions.push(`enum: [${contract.values.map((v) => `"${v}"`)}]`);
        break;
      case "decimal":
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        columnOptions.push(`precision: ${contract.precision}`);
        columnOptions.push(`scale: ${contract.scale}`);
        break;
      case "blob":
        columnOptions.push(`type: "${contract.nativeType}"`);
        break;
      case "bytea":
        columnOptions.push(`type: "${contract.nativeType}"`);
        break;
      case "integer":
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        break;
      case "boolean":
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.nativeType}"`);
        break;
      case "datetime":
      case "time":
        if (contract.unique) {
          columnOptions.push("unique: true");
        }
        columnOptions.push(`type: "${contract.zone}"`);
        columnOptions.push(` transformer: {
      to: (value: unknown) => value,
      from: (value: unknown) =>
        value instanceof Date ? value.toISOString() : value,
    },`);
        break;
      default:
        break;
    }
    structure.decorators.push({
      kind: morph.StructureKind.Decorator,
      name: "Column",
      arguments: [columnOptions.length ? `{${columnOptions.join(",")}}` : ""]
    });
    return {
      fieldStructure: structure,
      topLevelStructure,
      classDecorators
    };
  }
};

// libs/extensions/src/typeorm/validation.ts
function generateValidationContract(validations) {
  const result = [];
  for (const validation of validations) {
    const sourceValidation = getValidationById(validation.sourceId);
    result.push({
      id: validation.sourceId,
      details: validation.details,
      name: sourceValidation.name,
      type: sourceValidation.type
    });
  }
  return result;
}

// libs/extensions/src/typeorm/pagination.txt
var pagination_default = "import { camelCase } from 'lodash-es';\nimport {\n	Brackets,\n	ObjectLiteral,\n	SelectQueryBuilder,\n	WhereExpressionBuilder,\n} from 'typeorm';\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n	return column.replace(`${alias}.`, '');\n}\n\nexport interface PaginationMetadata {\n	hasNextPage: boolean;\n	hasPreviousPage: boolean;\n	pageSize: string | number | undefined;\n	currentPage: string | number | undefined;\n	totalCount: number;\n	totalPages: number;\n}\n\nexport class Pagination<T> {\n	constructor(\n		public records: T,\n		public metadata: PaginationMetadata\n	) {}\n}\n\nexport function limitOffsetPagination<Entity extends ObjectLiteral>(\n	qb: SelectQueryBuilder<Entity>,\n	options: {\n		pageNo?: number;\n		pageSize?: number;\n		count: number;\n	}\n) {\n	const pageSize = Number(options.pageSize || 50);\n	const pageNo = Number(options.pageNo || 1);\n	const offset = (pageNo - 1) * pageSize;\n	qb.take(pageSize);\n	qb.skip(offset);\n\n	return (result: Entity[]) => ({\n		hasNextPage: result.length === pageSize,\n		hasPreviousPage: offset > 0,\n		pageSize: options.pageSize,\n		currentPage: options.pageNo,\n		totalCount: options.count,\n		totalPages: Math.ceil(options.count / pageSize),\n	});\n}\n\nexport function deferredJoinPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    pageNo?: number | string | undefined;\n    pageSize?: number | string | undefined;\n    count: number;\n  },\n): (result: Entity[]) => PaginationMetadata {\n  const pageSize = Number(options.pageSize || 50);\n  const pageNo = Number(options.pageNo || 1);\n  const offset = (pageNo - 1) * pageSize;\n\n  const { tablePath: tableName } = qb.expressionMap.findAliasByName(qb.alias);\n  if (!tableName) {\n    throw new Error(`Could not find table path for alias ${qb.alias}`);\n  }\n\n  const subQueryAlias = `deferred_join_${tableName}`;\n\n  qb.innerJoin(\n    (subQuery) => {\n      const subQueryTableAlias = `deferred_${tableName}`;\n      const subQueryBuilder = subQuery\n        .from(tableName, subQueryTableAlias)\n        .select(`${subQueryTableAlias}.id`, 'id');\n\n      subQueryBuilder.expressionMap.wheres = qb.expressionMap.wheres.map((where) => {\n        const updatedCondition = where.condition.replace(\n          new RegExp(`\\\\b${qb.alias}\\\\b`, 'g'),\n          subQueryTableAlias,\n        );\n        return { ...where, condition: updatedCondition };\n      });\n\n      subQueryBuilder.expressionMap.withDeleted = qb.expressionMap.withDeleted;\n\n      return subQueryBuilder\n        .orderBy(`${subQueryTableAlias}.createdAt`)\n        .limit(pageSize)\n        .offset(offset);\n    },\n    subQueryAlias,\n    `${qb.alias}.id = ${subQueryAlias}.id`\n  );\n\n  return (result: Entity[]) => ({\n    hasNextPage: result.length === pageSize,\n    hasPreviousPage: offset > 0,\n    pageSize: options.pageSize,\n    currentPage: options.pageNo,\n    totalCount: options.count,\n    totalPages: Math.ceil(options.count / pageSize),\n  });\n}\n\n\nexport function cursorPagination<Entity extends ObjectLiteral>(\n	qb: SelectQueryBuilder<Entity>,\n	options: {\n		count: number;\n		pageSize: number;\n		/**\n		 * Base64 encoded string of the last record's cursor\n		 */\n		cursor?: string; // we shouldn't need to specify before or after cursor, the cursor should be enough\n	}\n) {\n	const cursorPayload = options.cursor\n		? JSON.parse(Buffer.from(options.cursor, 'base64').toString('utf-8'))\n		: null;\n	const alias = qb.alias;\n\n	let orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n	if (!orderByColumns.includes(`${alias}.createdAt`)) {\n		// always order by createdAt to ensure a consistent order\n		// createdAt will be either first order by in case no order by is specified by the caller function or last order by in case the caller function specified an order by\n		qb.addOrderBy(`${alias}.createdAt`);\n	}\n	if (!orderByColumns.includes(`${alias}.id`)) {\n		// fallback to order by id if more than one record is duplicated (have the same attributes used in order by clause)\n		qb.addOrderBy(`${alias}.id`);\n	}\n\n	orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n	if (cursorPayload) {\n		qb.andWhere(\n			new Brackets((qb) => {\n				function withCurrentColumn(qb: WhereExpressionBuilder, index: number) {\n					const column = orderByColumns[index];\n					const paramName = camelCase(\n						`last ${getColumnNameWithoutAlias(column, alias)}`\n					);\n					qb.andWhere(`${column} > :${paramName}`, {\n						[paramName]: cursorPayload[paramName],\n					});\n				}\n\n				for (let index = 0; index < orderByColumns.length; index++) {\n					if (index === 0) {\n						withCurrentColumn(qb, index);\n						continue;\n					}\n					qb.orWhere(\n						new Brackets((qb) => {\n							for (let j = 0; j < index; j++) {\n								const previousColumn = orderByColumns[j];\n								const paramName = camelCase(\n									`last ${getColumnNameWithoutAlias(previousColumn, alias)}`\n								);\n								qb.andWhere(`${previousColumn} = :${paramName}`, {\n									[paramName]: cursorPayload[paramName],\n								});\n							}\n							withCurrentColumn(qb, index);\n						})\n					);\n				}\n			})\n		);\n	}\n\n	qb.take(options.pageSize + 1);\n	return (result: Entity[]) => ({\n		nextCursor: Buffer.from(\n			JSON.stringify(\n				orderByColumns.reduce<Record<string, any>>((acc, column) => {\n					const paramName = camelCase(\n						`last ${getColumnNameWithoutAlias(column, alias)}`\n					);\n					return {\n						...acc,\n						[paramName]: qb.expressionMap.parameters[paramName],\n					};\n				}, {})\n			)\n		).toString('base64'),\n		previousCursor: null,\n		startCursor: null, // always null\n		endCursor: '', // think of it as startCursor but the order is reversed\n		hasNextPage: false, // if there is nextCursor, then there is a next page\n		hasPreviousPage: false, // if there is previousCursor, then there is a previous page\n		pageSize: options.pageSize,\n		totalCount: options.count,\n	});\n}\n";

// libs/extensions/src/typeorm/postgresql/execute.txt
var execute_default = "import { AsyncLocalStorage } from 'async_hooks';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport sqlTag, { RawValue } from 'sql-template-tag';\nimport { Transform } from 'stream';\nimport {\n	DeepPartial,\n	EntityManager,\n	EntityTarget,\n	ObjectLiteral,\n	QueryFailedError,\n	QueryRunner,\n	SelectQueryBuilder,\n} from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nimport { dataSource } from './data-source';\n\nconst asyncLocalStorage = new AsyncLocalStorage<QueryRunner>();\n\nexport type ExecutePipeline<I extends ObjectLiteral> = <\n  O extends Record<string, any>,\n>(\n  domainEntity: I,\n  rawEntity: Record<string, any>,\n) => I;\n\nexport async function execute<U extends ObjectLiteral>(\n  qb: SelectQueryBuilder<U>,\n  ...mappers: ExecutePipeline<U>[]\n) {\n  const { entities, raw } = await qb.getRawAndEntities();\n  return entities.map((entity, index) => {\n    return mappers.reduce((acc, mapper) => {\n      return mapper(acc, raw[index]);\n    }, entity);\n  });\n}\n\n/**\n * Begin a transaction and execute a computation. If the computation succeeds, the transaction is committed. If the computation fails, the transaction is rolled back.\n *\n * @param computation async function that takes a `EntityManager` and returns a `Promise`\n * @returns the result of the computation\n * @throws the error thrown by the computation or the error thrown by the transaction\n * @example\n *\n * // If the computation succeeds, the transaction is committed\n *\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  return user;\n * });\n *\n * // result is the updated user\n *\n * // If the computation fails, the transaction is rolled back\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  throw new Error('Something went wrong');\n * });\n *\n * // result is undefined\n * // If the transaction fails, the error is thrown\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  await manager.query('DROP TABLE users');\n * });\n *\n */\nexport async function useTransaction<TResult>(\n  computation: (manager: EntityManager) => Promise<TResult>,\n): Promise<TResult> {\n  const queryRunner = dataSource.createQueryRunner();\n  return asyncLocalStorage.run(queryRunner, async () => {\n    await queryRunner.connect();\n    await queryRunner.startTransaction();\n    try {\n      const result = await computation(queryRunner.manager);\n      await queryRunner.commitTransaction();\n      return result;\n    } catch (error) {\n      await queryRunner.rollbackTransaction();\n      throw error;\n    } finally {\n      await queryRunner.release();\n    }\n  });\n}\n\nfunction getManager() {\n  const queryRunner = asyncLocalStorage.getStore();\n  return queryRunner?.manager ?? dataSource.manager;\n}\n\nexport function getEntityById<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  id: string,\n) {\n  const qb = createQueryBuilder(entity, 'entity')\n    .where('entity.id = :id', { id })\n    .limit(1);\n  return qb.getOne();\n}\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n  return column.replace(`${alias}.`, '');\n}\n\nexport function createQueryBuilder<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  alias: string,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entity);\n  return repo.createQueryBuilder(alias);\n}\n\nexport async function removeEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  qbOrEntity: SelectQueryBuilder<T> | Entity,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  const entity =\n    qbOrEntity instanceof SelectQueryBuilder\n      ? await qbOrEntity.getOneOrFail()\n      : qbOrEntity;\n  await repo.softRemove(entity);\n  return entity;\n}\n\nexport async function patchEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>,\n) {\n  const result = await qb\n    .update()\n    .set(entity as unknown as Entity)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function setEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  // TODO: should throw an error if the entity does not exist or one of the required filed is missing\n  // put replaces the whole record one met validation\n  return patchEntity(qb, entity);\n}\n\nexport async function increment<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :incrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('incrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function decrement<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :decrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('decrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function saveEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  try {\n    return await repo.save(entity as T);\n  } catch (error) {\n		if (error instanceof QueryFailedError) {\n			const { severity, code, table, detail } = error.driverError ?? {};\n			throw new ProblemDetailsException({\n				title: error.message,\n				detail: `${severity} with code ${code} on table ${table}: ${detail}`,\n        status: 400,\n        engineCode: code,\n			});\n		}\n    throw error;\n  }\n}\n\nexport async function upsertEntity<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(\n	entityType: EntityTarget<Entity>,\n	entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n	options: {\n		upsertColumns?: Extract<keyof (Entity & { id: string }), string>[];\n		conflictColumns?: Extract<keyof (Entity & { id: string }), string>[];\n	} = {}\n) {\n	const manager = getManager();\n	const repo = manager.getRepository(entityType);\n	await repo\n		.createQueryBuilder()\n		.insert()\n		.into(entityType)\n		.values(entity as T)\n		.orUpdate(\n			options.upsertColumns ?? ['id'],\n			options.conflictColumns ??\n				(Object.keys(entity) as Extract<\n					keyof (Entity & { id: string }),\n					string\n				>[])\n		)\n		.execute();\n}\n\nexport function sql(\n  strings: readonly string[],\n  ...values: readonly RawValue[]\n) {\n  const manager = getManager();\n  const serializedSQL = sqlTag(strings, ...values);\n  return manager.query(serializedSQL.sql, serializedSQL.values);\n}\n\nexport function exists<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n) {\n  return qb.getOne().then(Boolean);\n}\n\n\n";

// libs/extensions/src/typeorm/postgresql/stream.txt
var stream_default = "import { Transform } from 'stream';\nimport { ObjectLiteral, SelectQueryBuilder } from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nexport async function stream<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(qb: SelectQueryBuilder<T>) {\n	const stream = await qb.stream();\n	return stream.pipe(\n		new Transform({\n			objectMode: true,\n			transform(record, encoding, callback) {\n				callback(\n					null,\n					JSON.stringify(\n						Object.fromEntries(\n							Object.entries(record).map(([key, value]) => [\n								key.replace(/projects_/g, ''),\n								value,\n							])\n						)\n					)\n				);\n			},\n		})\n	);\n}\n";

// libs/extensions/src/typeorm/postgresql/postgresql.ts
function postgresql(options = {}) {
  return {
    id: "postgresql",
    type: `'postgres'`,
    options: {
      useUTC: true,
      url: `process.env.CONNECTION_STRING`,
      ssl: `process.env.NODE_ENV === 'production'`,
      ...options
    },
    files: {
      "src/extensions/postgresql/execute.ts": execute_default,
      "src/extensions/postgresql/pagination.ts": pagination_default,
      "src/extensions/postgresql/stream.ts": stream_default
    },
    packages: {
      pg: {
        version: "8.11.5",
        dev: false
      },
      "pg-query-stream": {
        version: "^4.7.0",
        dev: false
      }
    }
  };
}

// libs/extensions/src/typeorm/sqlite/execute.txt
var execute_default2 = "import { AsyncLocalStorage } from 'async_hooks';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport sqlTag, { RawValue } from 'sql-template-tag';\nimport { Transform } from 'stream';\nimport {\n	DeepPartial,\n	EntityManager,\n	EntityTarget,\n	ObjectLiteral,\n	QueryFailedError,\n	QueryRunner,\n	SelectQueryBuilder,\n} from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nimport { dataSource } from './data-source';\n\nconst asyncLocalStorage = new AsyncLocalStorage<QueryRunner>();\n\nexport type ExecutePipeline<I extends ObjectLiteral> = <\n  O extends Record<string, any>,\n>(\n  domainEntity: I,\n  rawEntity: Record<string, any>,\n) => I;\n\nexport async function execute<U extends ObjectLiteral>(\n  qb: SelectQueryBuilder<U>,\n  ...mappers: ExecutePipeline<U>[]\n) {\n  const { entities, raw } = await qb.getRawAndEntities();\n  return entities.map((entity, index) => {\n    return mappers.reduce((acc, mapper) => {\n      return mapper(acc, raw[index]);\n    }, entity);\n  });\n}\n\n/**\n * Begin a transaction and execute a computation. If the computation succeeds, the transaction is committed. If the computation fails, the transaction is rolled back.\n *\n * @param computation async function that takes a `EntityManager` and returns a `Promise`\n * @returns the result of the computation\n * @throws the error thrown by the computation or the error thrown by the transaction\n * @example\n *\n * // If the computation succeeds, the transaction is committed\n *\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  return user;\n * });\n *\n * // result is the updated user\n *\n * // If the computation fails, the transaction is rolled back\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  throw new Error('Something went wrong');\n * });\n *\n * // result is undefined\n * // If the transaction fails, the error is thrown\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  await manager.query('DROP TABLE users');\n * });\n *\n */\nexport async function useTransaction<TResult>(\n  computation: (manager: EntityManager) => Promise<TResult>,\n): Promise<TResult> {\n  const queryRunner = dataSource.createQueryRunner();\n  return asyncLocalStorage.run(queryRunner, async () => {\n    await queryRunner.connect();\n    await queryRunner.startTransaction();\n    try {\n      const result = await computation(queryRunner.manager);\n      await queryRunner.commitTransaction();\n      return result;\n    } catch (error) {\n      await queryRunner.rollbackTransaction();\n      throw error;\n    } finally {\n      await queryRunner.release();\n    }\n  });\n}\n\nfunction getManager() {\n  const queryRunner = asyncLocalStorage.getStore();\n  return queryRunner?.manager ?? dataSource.manager;\n}\n\n\nexport function getEntityById<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  id: string,\n) {\n  const qb = createQueryBuilder(entity, 'entity')\n    .where('entity.id = :id', { id })\n    .limit(1);\n  return qb.getOne();\n}\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n  return column.replace(`${alias}.`, '');\n}\n\nexport function createQueryBuilder<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  alias: string,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entity);\n  return repo.createQueryBuilder(alias);\n}\n\nexport async function removeEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  qbOrEntity: SelectQueryBuilder<T> | Entity,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  const entity =\n    qbOrEntity instanceof SelectQueryBuilder\n      ? await qbOrEntity.getOneOrFail()\n      : qbOrEntity;\n  await repo.softRemove(entity);\n  return entity;\n}\n\nexport async function patchEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>,\n) {\n  const result = await qb\n    .update()\n    .set(entity as unknown as Entity)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function setEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  // TODO: should throw an error if the entity does not exist or one of the required filed is missing\n  // put replaces the whole record one met validation\n  return patchEntity(qb, entity);\n}\n\nexport async function increment<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :incrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('incrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function decrement<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :decrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('decrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function saveEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  try {\n    return await repo.save(entity as T);\n  } catch (error) {\n		if (error instanceof QueryFailedError) {\n			const { severity, code, table, detail } = error.driverError ?? {};\n			throw new ProblemDetailsException({\n				title: error.message,\n				detail: `${severity} with code ${code} on table ${table}: ${detail}`,\n        status: 400,\n        engineCode: code,\n			});\n		}\n    throw error;\n  }\n}\n\nexport async function upsertEntity<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(\n	entityType: EntityTarget<Entity>,\n	entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n	options: {\n		upsertColumns?: Extract<keyof (Entity & { id: string }), string>[];\n		conflictColumns?: Extract<keyof (Entity & { id: string }), string>[];\n	} = {}\n) {\n	const manager = getManager();\n	const repo = manager.getRepository(entityType);\n	await repo\n		.createQueryBuilder()\n		.insert()\n		.into(entityType)\n		.values(entity as T)\n		.orUpdate(\n			options.upsertColumns ?? ['id'],\n			options.conflictColumns ??\n				(Object.keys(entity) as Extract<\n					keyof (Entity & { id: string }),\n					string\n				>[])\n		)\n		.execute();\n}\n\nexport function sql(\n  strings: readonly string[],\n  ...values: readonly RawValue[]\n) {\n  const manager = getManager();\n  const serializedSQL = sqlTag(strings, ...values);\n  return manager.query(serializedSQL.sql, serializedSQL.values);\n}\n\nexport function exists<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n) {\n  return qb.getOne().then(Boolean);\n}\n";

// libs/extensions/src/typeorm/sqlite/stream.txt
var stream_default2 = "import { Transform } from 'stream';\nimport { ObjectLiteral, SelectQueryBuilder } from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nexport async function stream<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(qb: SelectQueryBuilder<T>) {\n	const stream = await qb.stream();\n	return stream.pipe(\n		new Transform({\n			objectMode: true,\n			transform(record, encoding, callback) {\n				callback(\n					null,\n					JSON.stringify(\n						Object.fromEntries(\n							Object.entries(record).map(([key, value]) => [\n								key.replace(/projects_/g, ''),\n								value,\n							])\n						)\n					)\n				);\n			},\n		})\n	);\n}\n";

// libs/extensions/src/typeorm/sqlite/sqlite.ts
function sqlite(options = {}) {
  return {
    id: "sqlite",
    type: `'better-sqlite3'`,
    options: {
      database: `process.env.CONNECTION_STRING`,
      ...options
    },
    files: {
      "src/extensions/sqlite/execute.ts": execute_default2,
      "src/extensions/sqlite/pagination.ts": pagination_default,
      "src/extensions/sqlite/stream.ts": stream_default2
    },
    packages: {
      "@types/better-sqlite3": { version: "^7.6.11", dev: true },
      "better-sqlite3": { version: "^11.3.0", dev: false }
    },
    onFeature: (feature, { fs }) => {
      const writer = new TypeORMCodeWriter(fs);
      return feature.tables.reduce((acc, contract) => {
        return {
          ...acc,
          [makeEntityPath(
            contract.featureName,
            contract.displayName,
            "entity"
          )]: writer.generateTable({
            fields: contract.fields.map(
              (field) => generateFieldContract(field, feature.tables)
            ),
            tableName: pascalcase(contract.displayName),
            indexes: contract.indexes
          })
        };
      }, {});
    }
  };
}
function generateFieldContract(input, tables) {
  const sourceField = getSourceFieldById(input.sourceId);
  const defaults = {
    displayName: input.displayName,
    primitiveType: sourceField.primitiveType
  };
  const result = handleField(
    {
      ...input,
      sourceField
    },
    tables
  );
  return {
    ...defaults,
    ...result
  };
}
function handleField(input, tables) {
  const mandatory = (input.validations ?? []).some(
    (it) => it.name === "mandatory" && it.details["value"] === "true"
  );
  const unique = (input.validations ?? []).some(
    (it) => it.name === "unique" && it.details["value"] === "true"
  );
  if (input.details["system_created_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "createdAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_updated_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "updatedAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_deleted_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "deletedAt",
      primitiveType: "Date"
    };
  }
  switch (input.sourceField.name) {
    case "primary-key-uuid":
    case "primary-key-custom":
    case "primary-key-number":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "primary-key",
        keyType: input.sourceField.name,
        generated: input.details["system_auto_generated"]
      };
    case "json":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "json",
        mandatory
      };
    case "bytes":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "blob",
        mandatory
      };
    case "integer":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "integer",
        mandatory,
        unique
      };
    case "boolean":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "boolean",
        mandatory,
        unique
      };
    case "datetime": {
      const local = input.validations.find((it) => it.name === "datetime");
      if (!local) {
        throw new Error("Datetime field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "datetime",
        zone: "datetime",
        mandatory,
        unique,
        primitiveType: "string"
      };
    }
    case "time": {
      const local = input.validations.find((it) => it.name === "time");
      if (!local) {
        throw new Error("Time field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "time",
        zone: local.details["value"] === "iso-time" ? "time" : "timetz",
        mandatory,
        unique
      };
    }
    case "uuid":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "uuid",
        mandatory,
        unique
      };
    case "url":
    case "short-text":
    case "email":
    case "long-text":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "varchar",
        mandatory,
        unique,
        length: input.details["length"],
        primitiveType: "string"
      };
    case "decimal":
    case "price":
    case "percentage":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "decimal",
        mandatory,
        unique,
        precision: input.details["precision"],
        scale: input.details["scale"]
      };
    case "single-select":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "varchar",
        unique,
        mandatory,
        primitiveType: input.details["values"].map((it) => `'${it}'`).join(" | "),
        defaultValue: input.details["defaultValue"],
        check: `${camelcase(input.displayName)} IN (${(input.details["values"] ?? []).map((x) => `'${x}'`)})`
      };
    case "relation-id": {
      const referenceEntity = tables.find(
        (it) => it.id === input.details["references"]
      );
      if (!referenceEntity) {
        throw new Error(`Table ${input.details["references"]} not found`);
      }
      const primaryKey = referenceEntity.fields.find(
        (field) => field.details["system_primary_key"]
      );
      if (!primaryKey) {
        throw new Error(
          `Primary key not found on table ${referenceEntity.displayName}`
        );
      }
      const primaryKeySourceField = getSourceFieldById(primaryKey.sourceId);
      const referencedPrimaryColumnType = primaryKeySourceField.primitiveType + `${input.details["relationship"] === "one-to-many" ? "[]" : ""}`;
      return {
        virtualRelationField: input.details["virtualRelationField"],
        validations: generateValidationContract(input.validations),
        nativeType: "relation-id",
        mandatory,
        unique,
        tableName: input.details["tableName"],
        primitiveType: referencedPrimaryColumnType,
        columnNameOnSelfTable: input.details["columnNameOnSelfTable"]
      };
    }
    case "relation":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "relation",
        primitiveType: input.sourceField.primitiveType,
        mandatory,
        unique,
        joinSide: input.details["joinSide"],
        nameOfColumnOnRelatedEntity: input.details["nameOfColumnOnRelatedEntity"],
        relationship: input.details["relationship"],
        // FIXME: deprecate relatedEntityName, fetch the table from the sdk using references
        relatedEntityName: input.details["relatedEntityName"]
      };
    default:
      throw new Error(`Field ${input.sourceField.name} not supported.`);
  }
}

// libs/extensions/src/typeorm/turso/execute.txt
var execute_default3 = "import { AsyncLocalStorage } from 'async_hooks';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport sqlTag, { RawValue } from 'sql-template-tag';\nimport { Transform } from 'stream';\nimport {\n	DeepPartial,\n	EntityManager,\n	EntityTarget,\n	ObjectLiteral,\n	QueryFailedError,\n	QueryRunner,\n	SelectQueryBuilder,\n} from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nimport { dataSource } from './data-source';\n\nconst asyncLocalStorage = new AsyncLocalStorage<QueryRunner>();\n\nexport type ExecutePipeline<I extends ObjectLiteral> = <\n  O extends Record<string, any>,\n>(\n  domainEntity: I,\n  rawEntity: Record<string, any>,\n) => I;\n\nexport async function execute<U extends ObjectLiteral>(\n  qb: SelectQueryBuilder<U>,\n  ...mappers: ExecutePipeline<U>[]\n) {\n  const { entities, raw } = await qb.getRawAndEntities();\n  return entities.map((entity, index) => {\n    return mappers.reduce((acc, mapper) => {\n      return mapper(acc, raw[index]);\n    }, entity);\n  });\n}\n\n/**\n * Begin a transaction and execute a computation. If the computation succeeds, the transaction is committed. If the computation fails, the transaction is rolled back.\n *\n * @param computation async function that takes a `EntityManager` and returns a `Promise`\n * @returns the result of the computation\n * @throws the error thrown by the computation or the error thrown by the transaction\n * @example\n *\n * // If the computation succeeds, the transaction is committed\n *\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  return user;\n * });\n *\n * // result is the updated user\n *\n * // If the computation fails, the transaction is rolled back\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  throw new Error('Something went wrong');\n * });\n *\n * // result is undefined\n * // If the transaction fails, the error is thrown\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  await manager.query('DROP TABLE users');\n * });\n *\n */\nexport async function useTransaction<TResult>(\n  computation: (manager: EntityManager) => Promise<TResult>,\n): Promise<TResult> {\n  const queryRunner = dataSource.createQueryRunner();\n  return asyncLocalStorage.run(queryRunner, async () => {\n    await queryRunner.connect();\n    await queryRunner.startTransaction();\n    try {\n      const result = await computation(queryRunner.manager);\n      await queryRunner.commitTransaction();\n      return result;\n    } catch (error) {\n      await queryRunner.rollbackTransaction();\n      throw error;\n    } finally {\n      await queryRunner.release();\n    }\n  });\n}\n\nfunction getManager() {\n  const queryRunner = asyncLocalStorage.getStore();\n  return queryRunner?.manager ?? dataSource.manager;\n}\n\nexport function getEntityById<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  id: string,\n) {\n  const qb = createQueryBuilder(entity, 'entity')\n    .where('entity.id = :id', { id })\n    .limit(1);\n  return qb.getOne();\n}\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n  return column.replace(`${alias}.`, '');\n}\n\nexport function createQueryBuilder<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  alias: string,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entity);\n  return repo.createQueryBuilder(alias);\n}\n\nexport async function removeEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  qbOrEntity: SelectQueryBuilder<T> | Entity,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  const entity =\n    qbOrEntity instanceof SelectQueryBuilder\n      ? await qbOrEntity.getOneOrFail()\n      : qbOrEntity;\n  await repo.softRemove(entity);\n  return entity;\n}\n\nexport async function patchEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>,\n) {\n  const result = await qb\n    .update()\n    .set(entity as unknown as Entity)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function setEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  // TODO: should throw an error if the entity does not exist or one of the required filed is missing\n  // put replaces the whole record one met validation\n  return patchEntity(qb, entity);\n}\n\nexport async function increment<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :incrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('incrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function decrement<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :decrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('decrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function saveEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  const manager = getManager();\n  const repo = manager.getRepository(entityType);\n  try {\n    return await repo.save(entity as T);\n  } catch (error) {\n		if (error instanceof QueryFailedError) {\n			const { severity, code, table, detail } = error.driverError ?? {};\n			throw new ProblemDetailsException({\n				title: error.message,\n				detail: `${severity} with code ${code} on table ${table}: ${detail}`,\n        status: 400,\n        engineCode: code,\n			});\n		}\n    throw error;\n  }\n}\n\nexport async function upsertEntity<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(\n	entityType: EntityTarget<Entity>,\n	entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n	options: {\n		upsertColumns?: Extract<keyof (Entity & { id: string }), string>[];\n		conflictColumns?: Extract<keyof (Entity & { id: string }), string>[];\n	} = {}\n) {\n	const manager = getManager();\n	const repo = manager.getRepository(entityType);\n	await repo\n		.createQueryBuilder()\n		.insert()\n		.into(entityType)\n		.values(entity as T)\n		.orUpdate(\n			options.upsertColumns ?? ['id'],\n			options.conflictColumns ??\n				(Object.keys(entity) as Extract<\n					keyof (Entity & { id: string }),\n					string\n				>[])\n		)\n		.execute();\n}\n\nexport function sql(\n  strings: readonly string[],\n  ...values: readonly RawValue[]\n) {\n  const manager = getManager();\n  const serializedSQL = sqlTag(strings, ...values);\n  return manager.query(serializedSQL.sql, serializedSQL.values);\n}\n\nexport function exists<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n) {\n  return qb.getOne().then(Boolean);\n}\n";

// libs/extensions/src/typeorm/turso/stream.txt
var stream_default3 = "import { Transform } from 'stream';\nimport { ObjectLiteral, SelectQueryBuilder } from 'typeorm';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';\n\nexport async function stream<\n	Entity extends ObjectLiteral,\n	T extends QueryDeepPartialEntity<Entity>,\n>(qb: SelectQueryBuilder<T>) {\n	const stream = await qb.stream();\n	return stream.pipe(\n		new Transform({\n			objectMode: true,\n			transform(record, encoding, callback) {\n				callback(\n					null,\n					JSON.stringify(\n						Object.fromEntries(\n							Object.entries(record).map(([key, value]) => [\n								key.replace(/projects_/g, ''),\n								value,\n							])\n						)\n					)\n				);\n			},\n		})\n	);\n}\n";

// libs/extensions/src/typeorm/turso/turso.ts
function turso(options = {}) {
  return {
    id: "turso",
    type: `'sqlite'`,
    options: {
      database: `process.env.CONNECTION_STRING`,
      driver: `require("@libsql/sqlite3")`,
      flags: "0x00000040",
      ...options
    },
    files: {
      "src/extensions/turso/execute.ts": execute_default3,
      "src/extensions/turso/pagination.ts": pagination_default,
      "src/extensions/turso/stream.ts": stream_default3
    },
    packages: {
      "@libsql/client": {
        version: "^0.14.0"
      },
      "@libsql/sqlite3": {
        version: "^0.3.1"
      },
      sqlite3: {
        version: "^5.1.7"
      }
    },
    onFeature: (feature, { fs }) => {
      const writer = new TypeORMCodeWriter(fs);
      return feature.tables.reduce((acc, contract) => {
        return {
          ...acc,
          [makeEntityPath(
            contract.featureName,
            contract.displayName,
            "entity"
          )]: writer.generateTable({
            fields: contract.fields.map(
              (field) => generateFieldContract2(field, feature.tables)
            ),
            tableName: pascalcase(contract.displayName),
            indexes: contract.indexes
          })
        };
      }, {});
    }
  };
}
function generateFieldContract2(input, tables) {
  const sourceField = getSourceFieldById(input.sourceId);
  const defaults = {
    displayName: input.displayName,
    primitiveType: sourceField.primitiveType
  };
  const result = handleField2(
    {
      ...input,
      sourceField
    },
    tables
  );
  return {
    ...defaults,
    ...result
  };
}
function handleField2(input, tables) {
  const mandatory = (input.validations ?? []).some(
    (it) => it.name === "mandatory" && it.details["value"] === "true"
  );
  const unique = (input.validations ?? []).some(
    (it) => it.name === "unique" && it.details["value"] === "true"
  );
  if (input.details["system_created_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "createdAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_updated_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "updatedAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_deleted_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "deletedAt",
      primitiveType: "Date"
    };
  }
  switch (input.sourceField.name) {
    case "primary-key-uuid":
    case "primary-key-custom":
    case "primary-key-number":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "primary-key",
        keyType: input.sourceField.name,
        generated: input.details["system_auto_generated"]
      };
    case "json":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "json",
        mandatory
      };
    case "bytes":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "blob",
        mandatory
      };
    case "integer":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "integer",
        mandatory,
        unique
      };
    case "boolean":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "boolean",
        mandatory,
        unique
      };
    case "datetime": {
      const local = input.validations.find((it) => it.name === "datetime");
      if (!local) {
        throw new Error("Datetime field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "datetime",
        zone: "datetime",
        mandatory,
        unique,
        primitiveType: "string"
      };
    }
    case "time": {
      const local = input.validations.find((it) => it.name === "time");
      if (!local) {
        throw new Error("Time field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "time",
        zone: local.details["value"] === "iso-time" ? "time" : "timetz",
        mandatory,
        unique
      };
    }
    case "uuid":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "uuid",
        mandatory,
        unique
      };
    case "url":
    case "short-text":
    case "email":
    case "long-text":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "varchar",
        mandatory,
        unique,
        length: input.details["length"],
        primitiveType: "string"
      };
    case "decimal":
    case "price":
    case "percentage":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "decimal",
        mandatory,
        unique,
        precision: input.details["precision"],
        scale: input.details["scale"]
      };
    case "single-select":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "varchar",
        unique,
        mandatory,
        primitiveType: input.details["values"].map((it) => `'${it}'`).join(" | "),
        defaultValue: input.details["defaultValue"],
        check: `${camelcase(input.displayName)} IN (${(input.details["values"] ?? []).map((x) => `'${x}'`)})`
      };
    case "relation-id": {
      const referenceEntity = tables.find(
        (it) => it.id === input.details["references"]
      );
      if (!referenceEntity) {
        throw new Error(`Table ${input.details["references"]} not found`);
      }
      const primaryKey = referenceEntity.fields.find(
        (field) => field.details["system_primary_key"]
      );
      if (!primaryKey) {
        throw new Error(
          `Primary key not found on table ${referenceEntity.displayName}`
        );
      }
      const primaryKeySourceField = getSourceFieldById(primaryKey.sourceId);
      const referencedPrimaryColumnType = primaryKeySourceField.primitiveType + `${input.details["relationship"] === "one-to-many" ? "[]" : ""}`;
      return {
        virtualRelationField: input.details["virtualRelationField"],
        validations: generateValidationContract(input.validations),
        nativeType: "relation-id",
        mandatory,
        unique,
        tableName: input.details["tableName"],
        primitiveType: referencedPrimaryColumnType,
        columnNameOnSelfTable: input.details["columnNameOnSelfTable"]
      };
    }
    case "relation":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "relation",
        primitiveType: input.sourceField.primitiveType,
        mandatory,
        unique,
        joinSide: input.details["joinSide"],
        nameOfColumnOnRelatedEntity: input.details["nameOfColumnOnRelatedEntity"],
        relationship: input.details["relationship"],
        // FIXME: deprecate relatedEntityName, fetch the table from the sdk using references
        relatedEntityName: input.details["relatedEntityName"]
      };
    default:
      throw new Error(`Field ${input.sourceField.name} not supported.`);
  }
}

// libs/extensions/src/typeorm/index.ts
function toLiteralObject(entries) {
  return removeDuplicates(entries, ([name]) => name).reduce((acc, [key, value]) => acc + `${key}: ${value},
`, ``).trim();
}
function typeorm(config2) {
  const runtimeProps = [
    ["migrationsRun", "process.env.ORM_MIGRATIONS_RUN"],
    ["logging", "process.env.ORM_LOGGING"],
    ["synchronize", "process.env.ORM_SYNCHRONIZE"],
    ["entityPrefix", "process.env.ORM_ENTITY_PREFIX"]
  ];
  const dbExtensionPath = `src/extensions/${config2.database.id}`;
  const exportFiles = [
    `${dbExtensionPath}/data-source.ts`,
    ...Object.keys(config2.database.files)
  ].reduce((acc, key) => {
    if (key.startsWith(dbExtensionPath)) {
      return `${acc}export * from './${key.replace(dbExtensionPath + "/", "")}';
`;
    }
    return acc;
  }, "");
  return {
    id: "typeorm",
    packages: {
      typeorm: {
        version: "0.3.20",
        dev: false
      },
      "sql-template-tag": {
        version: "5.2.1",
        dev: false
      },
      ...config2.database.packages
    },
    scripts: {
      "typeorm:generate": "npx dotenv-cli -e .env -- npx typeorm-ts-node-esm migration:generate -d output/build/database-migration-source.js ./migrations/migrate",
      "typeorm:migrate": "npx dotenv-cli -e .env -- npx typeorm-ts-node-esm migration:run -d output/src/core/database-migration-source.js",
      "typeorm:revert": "npx dotenv-cli -e .env -- npx typeorm-ts-node-esm migration:revert -d output/src/core/database-migration-source.js",
      "typeorm:drop": "npx dotenv-cli -e .env -- npx typeorm-ts-node-esm schema:drop -d output/src/core/database-migration-source.js"
    },
    files: {
      ...config2.database.files,
      [`${dbExtensionPath}/index.ts`]: exportFiles.concat(`import { z } from 'zod';

export const env = {
	CONNECTION_STRING: z.string(),
	ORM_MIGRATIONS_RUN: z.coerce.boolean().optional(),
	ORM_SYNCHRONIZE: z.coerce.boolean().optional(),
	ORM_LOGGING: z.coerce.boolean().optional(),
	ORM_ENTITY_PREFIX: z.string().optional(),
};
`),
      "build/database-migration-source.js": `
import { DataSource, DefaultNamingStrategy } from 'typeorm';

class NamingStrategy extends DefaultNamingStrategy {
	tableName(targetName, userSpecifiedName) {
		return super.tableName(userSpecifiedName ?? targetName, undefined);
	}
}

export default new DataSource({
  ${toLiteralObject(Object.entries(config2.database.options))}
	entities: ['output/**/*.entity.ts'],
	namingStrategy: new NamingStrategy(),
	migrations: ['migrations/*{.ts,.js}'],
});

    `,
      [`${dbExtensionPath}/data-source.ts`]: `
import entities from '@workspace/entities';
import { DataSource, DefaultNamingStrategy } from 'typeorm';

class NamingStrategy extends DefaultNamingStrategy {
  override tableName(
    targetName: string,
    userSpecifiedName: string | undefined,
  ): string {
    return super.tableName(userSpecifiedName ?? targetName, undefined);
  }
}

export const dataSource = new DataSource({
  type: ${config2.database.type},
});

export function initialize() {
	return dataSource
		.setOptions({
      ${toLiteralObject([...Object.entries(config2.database.options), ...runtimeProps])}
      entities: [...entities],
      namingStrategy: new NamingStrategy(),
		})
		.initialize();
}

    `
    },
    onFeature: config2.database.onFeature ?? ((feature, { fs }) => {
      const writer = new TypeORMCodeWriter(fs);
      return feature.tables.reduce((acc, contract) => {
        return {
          ...acc,
          [makeEntityPath(
            contract.featureName,
            contract.displayName,
            "entity"
          )]: writer.generateTable({
            fields: contract.fields.map(
              (field) => generateFieldContract3(field, feature.tables)
            ),
            tableName: pascalcase(contract.displayName),
            indexes: contract.indexes
          })
        };
      }, {});
    })
  };
}
function generateFieldContract3(input, tables) {
  const sourceField = getSourceFieldById(input.sourceId);
  const defaults = {
    displayName: input.displayName,
    primitiveType: sourceField.primitiveType
  };
  const result = handleField3(
    {
      ...input,
      sourceField
    },
    tables
  );
  return {
    ...defaults,
    ...result
  };
}
function handleField3(input, tables) {
  const mandatory = (input.validations ?? []).some(
    (it) => it.name === "mandatory" && it.details["value"] === "true"
  );
  const unique = (input.validations ?? []).some(
    (it) => it.name === "unique" && it.details["value"] === "true"
  );
  if (input.details["system_created_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "createdAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_updated_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "updatedAt",
      primitiveType: "Date"
    };
  }
  if (input.details["system_deleted_at"]) {
    return {
      validations: generateValidationContract(input.validations),
      mandatory,
      nativeType: "deletedAt",
      primitiveType: "Date"
    };
  }
  switch (input.sourceField.name) {
    case "primary-key-uuid":
    case "primary-key-custom":
    case "primary-key-number":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "primary-key",
        keyType: input.sourceField.name,
        generated: input.details["system_auto_generated"]
      };
    case "json":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "json",
        mandatory
      };
    case "bytes":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "bytea",
        mandatory
      };
    case "integer":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "integer",
        mandatory,
        unique
      };
    case "boolean":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "boolean",
        mandatory,
        unique
      };
    case "datetime": {
      const local = input.validations.find((it) => it.name === "datetime");
      if (!local) {
        throw new Error("Datetime field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "datetime",
        zone: local.details["value"] === "iso-date-time" ? "timestamp" : "timestamptz",
        mandatory,
        unique,
        primitiveType: "string"
      };
    }
    case "time": {
      const local = input.validations.find((it) => it.name === "time");
      if (!local) {
        throw new Error("Time field must specifiy timezone.");
      }
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "time",
        zone: local.details["value"] === "iso-time" ? "time" : "timetz",
        mandatory,
        unique
      };
    }
    case "uuid":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "uuid",
        mandatory,
        unique
      };
    case "url":
    case "short-text":
    case "email":
    case "long-text":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "varchar",
        mandatory,
        unique,
        length: input.details["length"],
        primitiveType: "string"
      };
    case "decimal":
    case "price":
    case "percentage":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "decimal",
        mandatory,
        unique,
        precision: input.details["precision"],
        scale: input.details["scale"]
      };
    case "single-select":
      if (input.details["style"] === "enum") {
        return {
          validations: generateValidationContract(input.validations),
          nativeType: "enum",
          unique,
          mandatory,
          primitiveType: input.details["values"].map((it) => `'${it}'`).join(" | "),
          defaultValue: input.details["defaultValue"],
          values: input.details["values"]
        };
      }
      if (input.details["style"] === "varchar") {
        return {
          validations: generateValidationContract(input.validations),
          nativeType: "varchar",
          unique,
          mandatory,
          primitiveType: "string"
        };
      }
      throw new Error("Lookup not supported yet.");
    case "relation-id": {
      const referenceEntity = tables.find(
        (it) => it.id === input.details["references"]
      );
      if (!referenceEntity) {
        throw new Error(`Table ${input.details["references"]} not found`);
      }
      const primaryKey = referenceEntity.fields.find(
        (field) => field.details["system_primary_key"]
      );
      if (!primaryKey) {
        throw new Error(
          `Primary key not found on table ${referenceEntity.displayName}`
        );
      }
      const primaryKeySourceField = getSourceFieldById(primaryKey.sourceId);
      const referencedPrimaryColumnType = primaryKeySourceField.primitiveType + `${input.details["relationship"] === "one-to-many" ? "[]" : ""}`;
      return {
        virtualRelationField: input.details["virtualRelationField"],
        validations: generateValidationContract(input.validations),
        nativeType: "relation-id",
        mandatory,
        unique,
        tableName: input.details["tableName"],
        primitiveType: referencedPrimaryColumnType,
        columnNameOnSelfTable: input.details["columnNameOnSelfTable"]
      };
    }
    case "relation":
      return {
        validations: generateValidationContract(input.validations),
        nativeType: "relation",
        primitiveType: input.sourceField.primitiveType,
        mandatory,
        unique,
        joinSide: input.details["joinSide"],
        nameOfColumnOnRelatedEntity: input.details["nameOfColumnOnRelatedEntity"],
        relationship: input.details["relationship"],
        // FIXME: deprecate relatedEntityName, fetch the table from the sdk using references
        relatedEntityName: input.details["relatedEntityName"]
      };
    default:
      throw new Error(`Field ${input.sourceField.name} not supported.`);
  }
}
export {
  postgresql,
  sqlite,
  turso,
  typeorm
};
//# sourceMappingURL=index.js.map
