export * from './lib/console';
