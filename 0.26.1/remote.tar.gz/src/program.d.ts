import { Option } from 'commander';
import debug from 'debug';
export declare const defaultHealthCheck: Record<string, any>;
export declare const cli: import("commander").Command;
export interface AST {
    healthCheckOptions: Record<string, any> | undefined;
    paths: string[];
    expose: string;
    dockerfile: string;
}
export declare function toAst(projectDockerFilePath: string): Promise<AST>;
export declare const logger: debug.Debugger;
export declare const spinner: import("ora").Ora;
export declare function printDivider(character?: string): void;
export declare function tell(message: string, newLine?: boolean): void;
export declare const askForProjectName: () => import("@inquirer/type").CancelablePromise<string>;
export declare const projectOption: Option;
export declare function ensureUser(): Promise<{
    user: import("@firebase/auth").User;
    claims: import("@firebase/auth").ParsedToken;
} | null>;
export declare function dropdown(config: {
    title: string;
    default?: string;
    choices: {
        name: string;
        value: string;
    }[];
}): Promise<string>;
export declare function getCurrentProject(project?: string): Promise<{
    projectId: string;
    projectName: string;
    token: string;
} | undefined>;
