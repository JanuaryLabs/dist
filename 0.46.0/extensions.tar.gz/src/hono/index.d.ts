import type { Server } from '@tus/server';
import type { Context } from 'hono';
import type { IncomingMessage } from 'http';
import { Policy, type TriggerDefinition } from '@january/declarative';
import type { Extension } from '../extension';
import { type HttpTrigger, type HttpTriggerConfig, type Input, type SSETrigger } from './trigger';
interface HonoOptions {
    useFeatureNameAsBasePath: boolean;
    generateSwagger: (featureName: string) => boolean;
}
export declare const honoDefaultOptions: HonoOptions;
export declare function hono(options?: HonoOptions): Extension;
declare module '@january/declarative' {
    namespace policy {
        function http(policyFn: (context: Context) => void): Policy;
    }
    namespace trigger {
        function tus(config: Omit<ConstructorParameters<typeof Server>[0], 'allowedCredentials' | 'allowedHeaders' | 'allowedMethods' | 'allowedOrigins' | 'respectForwardedHeaders' | 'relativeLocation'> & {
            policies?: string[];
        }): TriggerDefinition<[
            {
                id: string;
                mimeType: string;
                size: string;
            },
            IncomingMessage
        ], unknown>;
        function file(config: {
            path: string;
            root?: string;
            rewrite?: (path: string) => string;
            policies?: string[];
        }): TriggerDefinition<[string], string>;
        function stream<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
            {
                trigger: HttpTrigger;
                input: Input<M>;
            },
            IncomingMessage
        ], M>;
        function sse(config: {
            path: string;
            policies?: string[];
        }): TriggerDefinition<[{
            trigger: HttpTrigger;
        }, IncomingMessage], unknown>;
        function websocket(config: {
            topic: string;
            policies?: string[];
        }): TriggerDefinition<[SSETrigger, IncomingMessage], unknown>;
        function http<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
            {
                trigger: HttpTrigger;
                input: Input<M>;
                output: trigger.http.output;
            },
            IncomingMessage
        ], M>;
    }
}
export {};
