import type { Server } from '@tus/server';
import type { IncomingMessage } from 'http';
import type z from 'zod';
import type { TriggerDefinition } from '@january/declarative';
type InferZodProp<T> = T extends {
    against: infer Against;
} ? Against extends z.ZodType<any, any, any> ? z.infer<Against> : never : T;
export type Input<T> = {
    [K in keyof T]: InferZodProp<T[K]>;
};
export interface SSETrigger {
    body: Record<string, any>;
    query: Record<string, string>;
    headers: Record<string, string>;
    path: Record<string, string>;
}
export interface HttpTrigger {
    body: Record<string, any>;
    query: Record<string, string>;
    headers: Record<string, string>;
    path: Record<string, string>;
}
export type HttpTriggerConfig<M> = {
    path: string;
    method: string;
    policies?: string[];
    input?: (trigger: HttpTrigger) => M;
};
export declare namespace trigger {
    function http<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
        {
            trigger: HttpTrigger;
            input: Input<M>;
            output: trigger.http.output;
        },
        IncomingMessage
    ], M>;
    function sse(config: {
        path: string;
        policies?: string[];
    }): TriggerDefinition<[{
        trigger: HttpTrigger;
    }, IncomingMessage], unknown>;
    function websocket(config: {
        topic: string;
        policies?: string[];
    }): TriggerDefinition<[SSETrigger, IncomingMessage], unknown>;
    function stream<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
        {
            trigger: HttpTrigger;
            input: Input<M>;
        },
        IncomingMessage
    ], M>;
    function tus(config: Omit<ConstructorParameters<typeof Server>[0], 'allowedCredentials' | 'allowedHeaders' | 'allowedMethods' | 'allowedOrigins' | 'respectForwardedHeaders' | 'relativeLocation'> & {
        policies?: string[];
    }): TriggerDefinition<[
        {
            id: string;
            mimeType: string;
            size: string;
        },
        IncomingMessage
    ], unknown>;
    function file(config: {
        path: string;
        root?: string;
        rewrite?: (path: string) => string;
        policies?: string[];
    }): TriggerDefinition<[string], string>;
}
export {};
