import type { EmitterWebhookEvent, EmitterWebhookEventName } from '@octokit/webhooks';
import type { TriggerDefinition } from '@january/declarative';
import type { Extension } from '../../extension';
export declare const webhooks: Extension;
declare module '@january/declarative' {
    namespace trigger {
        function github<EventName extends EmitterWebhookEventName, Y>(config: {
            event: EventName;
            policies?: string[];
        }): TriggerDefinition<[EmitterWebhookEvent<EventName>], Y>;
    }
}
