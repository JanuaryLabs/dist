var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// libs/parser/src/index.ts
import { readFileSync } from "node:fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  globalThis.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      list.push(resolveMemberExpression(arg.expression, []).join("."));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
var checker, Checker;
var init_src = __esm({
  "libs/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression2(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression2;
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      function isCallExpression2(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression2;
      function isObjectExpression(value) {
        return !isCallExpression2(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
    })(Checker || (Checker = {}));
  }
});

// libs/openapi/src/lib/client.ts
import { merge as merge2 } from "lodash-es";
import { readFile as readFile2, readdir as readdir2 } from "node:fs/promises";
import { basename as basename2, extname, join as join4 } from "node:path";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "node:path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}

// libs/sdk/evaluator/src/lib/evaluate.ts
import { randomBytes } from "node:crypto";
import { get } from "lodash-es";

// libs/sdk/declarative/src/lib/feature.ts
function feature(nameOrConfig) {
  return {
    name: "",
    tables: nameOrConfig.tables,
    workflows: nameOrConfig.workflows,
    imports: [],
    policies: Object.entries(nameOrConfig.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config.message
    }
  };
}
var required = mandatory;
function unique(config = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config.message
      }
    }
  ];
}
function defineValidation(config) {
  return {
    name: config.name,
    config
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config) {
  const additionalFields = {};
  const idField = Object.values(config.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config.fields,
      ...additionalFields
    },
    constraints: config.constraints || []
  };
}
function field(config) {
  const { type, validations = [], metadata = {}, ...rest } = config;
  return {
    type: config.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config) {
    const [, relatedTableName, ...rest] = config.references.split(".");
    if (rest.length) {
      throw new Error(
        `Wrong relation reference: ${config.references}. Did you mean tables.${relatedTableName}`
      );
    }
    return field2({
      type: "relation",
      metadata: { ...config, references: relatedTableName },
      validations: config.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
field.enum = (config) => {
  return field({
    type: "single-select",
    validations: config.validations,
    metadata: {
      style: "enum",
      values: config.values,
      defaultValue: config.defaultValue
    }
  });
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(name, config) {
  const execute = config.trigger.refineExecute(config.execute);
  return {
    name,
    trigger: config.trigger,
    raw: !Object.keys(config.trigger.inputs ?? {}).length,
    execute,
    tag: config.tag
  };
}

// libs/sdk/evaluator/src/lib/evaluate.ts
init_src();
var defaultPrimitiveCallers = {
  table,
  feature,
  workflow,
  field: field.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  index
  // z: {
  //   object(...args: any[]) {
  //     logMe({ 'z.objectile': args });
  //     return args;
  //   },
  //   uuid() {
  //     return 'uuid';
  //   },
  //   int(...args: any[]) {
  //     logMe({ 'z.int': args });
  //     return 'int';
  //   },
  //   number(...args: any[]) {
  //     logMe({ 'z.number': args });
  //     return 'number';
  //   },
  //   string() {
  //     return 'string';
  //   },
  //   array(...args: any[]) {
  //     logMe({ 'z.array': args });
  //     return {
  //       type: 'array',
  //     };
  //   },
  // } as any,
  // z(...args: any[]) {
  //   logMe({ z: args });
  //   return args;
  // },
  // object(...args: any[]) {
  //   logMe({ 'z.object': args });
  //   return 'object';
  // },
  // uuid() {
  //   return 'uuid';
  // },
  // int() {
  //   return 'int';
  // },
  // number() {
  //   return 'string';
  // },
  // string() {
  //   return 'string';
  // },
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers, node, hooks = {}) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    let callerImpl = callers[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node.arguments.map((it) => staticEval(callers, it, hooks));
    if (typeof callerImpl === "function") {
      if (type.length) {
        args.unshift(type.join("."));
      }
      return callerImpl(...args);
    }
    callerImpl = get(callerImpl, type);
    if (!callerImpl) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => staticEval(callers, it, hooks));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      obj[key] = staticEval(callers, value, hooks);
    }
    return obj;
  }
  return node;
}
async function evaluate(code, callers) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    ...staticEval(callers, ast.project),
    imports: ast.imports
  };
}

// libs/modern/src/index.ts
import {
  cp,
  mkdir,
  readFile,
  readdir,
  stat,
  writeFile
} from "node:fs/promises";
import { basename, dirname, isAbsolute, join as join2 } from "node:path";
import { tap } from "rxjs/operators";

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
async function writeFiles(dir, contents, format = true) {
  return Promise.all(
    Object.entries(contents).map(async ([file, content]) => {
      const filePath = isAbsolute(file) ? file : join2(dir, file);
      await mkdir(dirname(filePath), { recursive: true });
      if (typeof content === "string") {
        await writeFile(
          filePath,
          format ? await formatCode(content, getExt(file)) : content,
          "utf-8"
        );
      } else {
        if (content.ignoreIfExists) {
          if (!await exist(filePath)) {
            await writeFile(
              filePath,
              format ? await formatCode(content.content, getExt(file)) : content.content,
              "utf-8"
            );
          }
        }
      }
    })
  );
}
async function exist(file) {
  return stat(file).then(() => true).catch(() => false);
}
async function readFolder(path) {
  if (await exist(path)) {
    return readdir(path);
  }
  return [];
}
async function getFile(filePath) {
  if (await exist(filePath)) {
    return readFile(filePath, "utf-8");
  }
  return null;
}
async function getFolderExports(folder, extensions = ["ts"]) {
  const files = await readdir(folder, { withFileTypes: true });
  const exports = [];
  for (const file of files) {
    if (file.isDirectory()) {
      exports.push(`export * from './${file.name}';`);
    } else if (file.name !== "index.ts" && extensions.includes(getExt(file.name))) {
      exports.push(
        `export * from './${file.name.replace(`.${getExt(file.name)}`, "")}';`
      );
    }
  }
  return exports.join("\n");
}

// libs/opensdk/src/index.ts
import { get as get3, merge } from "lodash-es";

// libs/opensdk/src/json-zod.ts
import { get as get2 } from "lodash-es";

// libs/opensdk/src/client.txt
var client_default = "import { parse } from 'fast-content-type-parse';\nimport type { Endpoints } from './endpoints';\nimport schemas from './schemas';\nimport { validateOrThrow, ServerError } from './validator';\n\nexport interface RequestInterface<D extends object = object> {\n	/**\n	 * Sends a request based on endpoint options\n	 *\n	 * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'\n	 * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.\n	 */\n	<R extends keyof Endpoints>(\n		route: R,\n		options?: Endpoints[R]['input']\n	): Promise<Endpoints[R]['output']>;\n}\n\nexport async function handleError(response: Response) {\n	try {\n		if (response.status >= 400 && response.status < 500) {\n			const body = (await response.json()) as Record<string, any>;\n			return new ServerError(body.title || body.detail, response.status, body.errors ?? {});\n		}\n		return new Error(\n			`An error occurred while fetching the data. Status: ${response.status}`\n		);\n	} catch (error) {\n		// in case the response is not a json\n		// this is a workaround but we should change\n		// it from the server to always return json\n\n		return error as Error;\n	}\n}\n\nexport async function parseResponse(response: Response) {\n	const contentType = response.headers.get('Content-Type');\n	if (!contentType) {\n		throw new Error('Content-Type header is missing');\n	}\n\n	if (response.status === 204) {\n		return null;\n	}\n\n	const { type } = parse(contentType);\n	switch (type) {\n		case 'application/json':\n			return response.json();\n		case 'text/plain':\n			return response.text();\n		default:\n			throw new Error(`Unsupported content type: ${contentType}`);\n	}\n}";

// libs/opensdk/src/request.txt
var request_default = "type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';\ntype Endpoint = `${Method} ${string}`;\n\nexport function createUrl(base: string, path: string, query: URLSearchParams) {\n	const url = new URL(path, base);\n	url.search = query.toString();\n	return url;\n}\nfunction template(\n	templateString: string,\n	templateVariables: Record<string, any>\n): string {\n	const nargs = /{([0-9a-zA-Z_]+)}/g;\n	return templateString.replace(nargs, (match, key: string, index: number) => {\n		// Handle escaped double braces\n		if (\n			templateString[index - 1] === '{' &&\n			templateString[index + match.length] === '}'\n		) {\n			return key;\n		}\n\n		const result = key in templateVariables ? templateVariables[key] : null;\n		return result === null || result === undefined ? '' : String(result);\n	});\n}\nexport function toRequest<T extends Endpoint>(\n	endpoint: T,\n	input: Record<string, any>,\n	props: {\n		inputHeaders: string[];\n		inputQuery: string[];\n		inputBody: string[];\n		inputParams: string[];\n	},\n	defaults: {\n		baseUrl: string;\n		headers?: Record<string, string>;\n	}\n): Request {\n	const [method, path] = endpoint.split(' ');\n\n	const headers = new Headers({\n		...defaults?.headers,\n		'Content-Type': 'application/json',\n		Accept: 'application/json',\n	});\n\n	for (const header of props.inputHeaders) {\n		headers.set(header, input[header]);\n	}\n\n	const query = new URLSearchParams();\n	for (const key of props.inputQuery) {\n		const value = input[key];\n		if (value !== undefined) {\n			query.set(key, String(value));\n		}\n	}\n\n	const body = props.inputBody.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const init = {\n		path: template(path, params),\n		method,\n		headers,\n		query,\n		body: JSON.stringify(body),\n	};\n\n	const url = createUrl(defaults.baseUrl, init.path, init.query);\n	return new Request(url, {\n		method: init.method,\n		headers: init.headers,\n		body: method === 'GET' ? undefined : JSON.stringify(body),\n	});\n}\n";

// libs/opensdk/src/validator.txt
var validator_default = "import { z } from 'zod';\n\nexport function validate<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n) {\n	const result = schema.safeParse(input);\n	if (!result.success) {\n		return result.error.flatten((issue) => ({\n			message: issue.message,\n			code: issue.code,\n			fatel: issue.fatal,\n			path: issue.path.join('.'),\n		})).fieldErrors;\n	}\n	return null;\n}\n\nexport class ValidationError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ValidationError';\n		Error.captureStackTrace(this, ValidationError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport class ServerError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public status: number,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ServerError';\n		Error.captureStackTrace(this, ServerError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport function validateOrThrow<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n): asserts input is z.infer<z.ZodObject<T>> {\n	const errors = validate(schema, input);\n	if (errors) {\n		throw new ValidationError('Validation failed', errors);\n	}\n}\n";

// libs/opensdk/src/sdk.ts
import { camelcase as camelcase2 } from "stringcase";

// libs/opensdk/src/backend.ts
var backend_default = (spec) => {
  const specOptions = {
    ...spec.options ?? {},
    baseUrl: { schema: "z.string().url()" }
  };
  if (spec.securityScheme) {
    specOptions["token"] = { schema: "z.string().optional()" };
  }
  const defaultHeaders = spec.securityScheme ? `{Authorization: \`${titlecase(spec.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}` : `{}`;
  return `

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { validateOrThrow } from './validator';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${toLitObject(specOptions, (x) => x.schema)});
      type ${spec.name}Options = z.infer<typeof optionsSchema>;
    export class ${spec.name} {

      constructor(public options: ${spec.name}Options) {}

async stream<E extends keyof StreamEndpoints>(
    endpoint: E,
    input: StreamEndpoints[E]['input'],
  ): Promise<readonly [ReadableStream, Error | null]> {
    try {
      const route = schemas[endpoint];
      validateOrThrow(route.schema, input);
      const response = await fetch(
        route.toRequest(input as never, {
          headers: this.defaultHeaders,
          baseUrl: this.options.baseUrl,
        }),
      );

      if (response.ok) {
        return [response.body!, null] as const;
      }
      const error = await handleError(response);
      return [null as never, error] as const;
    } catch (error) {
      return [null as never, error as Error] as const;
    }
  }

async request<E extends keyof Endpoints>(
		endpoint: E,
		input: Endpoints[E]['input']
	): Promise<readonly [Endpoints[E]['output'], Error | null]> {
		try {
			const route = schemas[endpoint];
			validateOrThrow(route.schema, input);
			const response = await fetch(
				route.toRequest(input as never, {
					headers: this.defaultHeaders,
					baseUrl: this.options.baseUrl,
				})
			);

			if (response.ok) {
				const data = await parseResponse(response);
				return [data as Endpoints[E]['output'], null] as const;
			}
			const error = await handleError(response);
			return [null, error] as const;
		} catch (error) {
			return [null, error as Error] as const;
		}
	}

      get defaultHeaders() {
        return ${defaultHeaders}
      }

  setOptions(options: Partial<${spec.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${spec.name}Options)[]) {
      if (validated[key] !== undefined) {
        this.options[key] = validated[key]!;
      }
    }
  }
}`;
};

// libs/opensdk/src/sdk.ts
var SchemaEndpoint = class {
  #imports = [
    `import z from 'zod';`,
    'import type { Endpoints } from "./endpoints";',
    'import type { StreamEndpoints } from "./stream-endpoints";',
    `import { toRequest, createUrl } from './request';`
  ];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation},`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export default {
${this.#endpoints.join("\n")}
}`;
  }
};
var Emitter = class {
  imports = [`import z from 'zod';`];
  endpoints = [];
  addEndpoint(endpoint, operation) {
    this.endpoints.push(`  "${endpoint}": ${operation};`);
  }
  addImport(value) {
    this.imports.push(value);
  }
  complete() {
    return `${this.imports.join("\n")}
export interface Endpoints {
${this.endpoints.join("\n")}
}`;
  }
};
var StreamEmitter = class extends Emitter {
  complete() {
    return `${this.imports.join("\n")}
export interface StreamEndpoints {
${this.endpoints.join("\n")}
}`;
  }
};
function generateClientSdk(spec) {
  const emitter = new Emitter();
  const streamEmitter = new StreamEmitter();
  const schemas = {};
  const schemasImports = [];
  const schemaEndpoint = new SchemaEndpoint();
  for (const [name, operations] of Object.entries(spec.groups)) {
    const featureSchemaFileName = camelcase2(name);
    schemas[featureSchemaFileName] = [`import z from 'zod';`];
    emitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    streamEmitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    schemaEndpoint.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    for (const operation of operations) {
      const schemaName = camelcase2(`${operation.name} schema`);
      const schema = `export const ${schemaName} = ${operation.schema};`;
      schemas[featureSchemaFileName].push(schema);
      schemasImports.push(
        ...operation.imports.map((it) => (it.namedImports ?? []).map((it2) => it2.name)).flat()
      );
      const endpoint = `${operation.trigger.method.toUpperCase()} ${operation.trigger.path}`;
      const schemaRef = `${featureSchemaFileName}.${schemaName}`;
      const input = `z.infer<typeof ${schemaRef}>`;
      const output = operation.formatOutput();
      const inputHeaders = [];
      const inputQuery = [];
      const inputBody = [];
      const inputParams = [];
      for (const [name2, prop] of Object.entries(operation.inputs)) {
        if (prop.source === "headers") {
          inputHeaders.push(`"${name2}"`);
        } else if (prop.source === "query") {
          inputQuery.push(`"${name2}"`);
        } else if (prop.source === "body") {
          inputBody.push(`"${name2}"`);
        } else if (prop.source === "path") {
          inputParams.push(`"${name2}"`);
        } else if (prop.source === "internal") {
          continue;
        } else {
          throw new Error(
            `Unknown source ${prop.source} in ${name2} ${JSON.stringify(
              prop
            )} in ${operation.name}`
          );
        }
      }
      if (operation.type === "stream") {
        streamEmitter.addImport(
          `import {${pascalcase(operation.name)}} from './outputs/${operation.name}';`
        );
        streamEmitter.addEndpoint(
          endpoint,
          `{input: ${input}, output: ${output}}`
        );
        schemaEndpoint.addEndpoint(
          endpoint,
          `{
        schema: ${schemaRef},
        toRequest(input: StreamEndpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${endpoint}';
            return toRequest(endpoint, input, {
            inputHeaders: [${inputHeaders}],
            inputQuery: [${inputQuery}],
            inputBody: [${inputBody}],
            inputParams: [${inputParams}],
          }, init);
          },
        }`
        );
      } else {
        emitter.addImport(
          `import {${pascalcase(operation.name)}} from './outputs/${operation.name}';`
        );
        emitter.addEndpoint(endpoint, `{input: ${input}, output: ${output}}`);
        schemaEndpoint.addEndpoint(
          endpoint,
          `{
        schema: ${schemaRef},
        toRequest(input: Endpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${endpoint}';
            return toRequest(endpoint, input, {
            inputHeaders: [${inputHeaders}],
            inputQuery: [${inputQuery}],
            inputBody: [${inputBody}],
            inputParams: [${inputParams}],
          }, init);
          },
        }`
        );
      }
    }
  }
  return {
    ...Object.fromEntries(
      Object.entries(schemas).map(([key, value]) => [
        `inputs/${key}.ts`,
        [
          schemasImports.length ? `import {${removeDuplicates(schemasImports, (it) => it)}} from '../zod';` : "",
          ...value
        ].join("\n")
      ])
    ),
    "backend.ts": backend_default(spec),
    "validator.ts": validator_default,
    "client.ts": client_default,
    "request.ts": request_default,
    "schemas.ts": schemaEndpoint.complete(),
    "endpoints.ts": emitter.complete(),
    "stream-endpoints.ts": streamEmitter.complete()
  };
}

// libs/openapi/src/lib/serializer.ts
import debug from "debug";
import { dirname as dirname2, join as join3 } from "node:path";
import ts from "typescript";

// libs/openapi/src/lib/emitter.ts
var typeMappings = {
  DateConstructor: "Date"
};
function deserializeTypes(data, onType) {
  const tokens = [];
  for (const type of data.types) {
    if (type === null || type === void 0) {
      tokens.push("any");
    } else if (typeof type === "string") {
      tokens.push(
        `${typeMappings[type] || type}${data.kind === "array" ? "[]" : ""}`
      );
      onType(type);
    } else if ("types" in type) {
      tokens.push(deserializeTypes(type, onType));
    }
  }
  return tokens.join(" | ");
}
function toInterface(contents, serializeSymbol2) {
  const contentMap = {};
  for (const [filePath, models] of Object.entries(contents)) {
    for (const [key, value] of Object.entries(models)) {
      const props = [];
      const isTypeAlias = value[serializeSymbol2];
      const maybeImports = /* @__PURE__ */ new Set();
      if (isTypeAlias) {
        const prop = deserializeTypes(value, (type) => {
          maybeImports.add(type);
        });
        contentMap[filePath] = {
          exports: [key],
          imports: Array.from(maybeImports),
          content: `export type ${key} = ${prop};`
        };
      } else {
        for (const [prop, data] of Object.entries(value)) {
          const tokens = [prop];
          if (data.optional) {
            tokens.push("?");
          }
          tokens.push(": ");
          tokens.push(
            deserializeTypes(data, (type) => {
              maybeImports.add(type);
            })
          );
          props.push(tokens.join(""));
        }
        contentMap[filePath] = {
          exports: [key],
          imports: Array.from(maybeImports),
          content: `export interface ${key} {
${props.join("\n")}
}
`
        };
      }
    }
  }
  const combinedExports = Object.values(contentMap).flatMap((it) => it.exports);
  const emits = {};
  for (const [filePath, { content, exports, imports }] of Object.entries(
    contentMap
  )) {
    const fileImports = [];
    for (const importName of imports) {
      if (combinedExports.includes(importName) && importName !== filePath) {
        fileImports.push(`import { ${importName} } from './${importName}';`);
      }
    }
    const fileContent = `${fileImports.join("\n")}
${content}`;
    emits[filePath] = fileContent;
  }
  return emits;
}

// libs/openapi/src/lib/serializer.ts
var logger = debug("january:client");
function parseTsConfig(tsconfigPath) {
  logger(`Using TypeScript version: ${ts.version}`);
  const configContent = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
  if (configContent.error) {
    console.error(
      `Failed to read tsconfig file:`,
      ts.formatDiagnosticsWithColorAndContext([configContent.error], {
        getCanonicalFileName: (path) => path,
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: () => ts.sys.newLine
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  const parsed = ts.parseJsonConfigFileContent(
    configContent.config,
    ts.sys,
    dirname2(tsconfigPath)
  );
  if (parsed.errors.length > 0) {
    console.error(
      `Errors found in tsconfig.json:`,
      ts.formatDiagnosticsWithColorAndContext(parsed.errors, {
        getCanonicalFileName: (path) => path,
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: () => ts.sys.newLine
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  return parsed;
}
var visitor = (on) => {
  return (node) => {
    if (ts.isReturnStatement(node) && node.expression) {
      if (ts.isCallExpression(node.expression) && node.expression.expression && ts.isPropertyAccessExpression(node.expression.expression)) {
        const propAccess = node.expression.expression;
        if (ts.isIdentifier(propAccess.expression) && propAccess.expression.text === "output") {
          const [ole] = node.expression.arguments;
          if (!ole) {
            return;
          }
          on(ole);
        }
      } else {
        on(node.expression);
      }
    }
    return ts.forEachChild(node, visitor(on));
  };
};
function isCallExpression(node, name) {
  return ts.isCallExpression(node) && node.expression && ts.isIdentifier(node.expression) && node.expression.text === name;
}
function getPropertyAssignment(node, name) {
  if (ts.isObjectLiteralExpression(node)) {
    return node.properties.filter((prop) => ts.isPropertyAssignment(prop)).find((prop) => prop.name.getText() === name);
  }
  return void 0;
}
function searchInFeature(sourceFile, serializer) {
  const results = [];
  sourceFile.forEachChild((node) => {
    if (ts.isExportAssignment(node) && isCallExpression(node.expression, "feature")) {
      const [configArg] = node.expression.arguments;
      if (ts.isObjectLiteralExpression(configArg)) {
        const workflows = getPropertyAssignment(configArg, "workflows");
        if (!workflows) {
          return;
        }
        if (ts.isArrayLiteralExpression(workflows.initializer)) {
          workflows.initializer.forEachChild((workflow2) => {
            if (isCallExpression(workflow2, "workflow")) {
              const [workflowNameArg, workflowConfigArg] = workflow2.arguments;
              const name = ts.isStringLiteral(workflowNameArg) ? workflowNameArg.text : "";
              if (!name) {
                return;
              }
              if (ts.isObjectLiteralExpression(workflowConfigArg)) {
                const execute = getPropertyAssignment(
                  workflowConfigArg,
                  "execute"
                );
                if (execute?.initializer) {
                  if (ts.isArrowFunction(execute.initializer)) {
                    if (ts.isBlock(execute.initializer.body)) {
                      const contents = {
                        [name]: {
                          [serializeSymbol]: true,
                          optional: false,
                          types: ["void"]
                        }
                      };
                      visitor((node2) => {
                        contents[name] = serializer.serializeNode(node2);
                      })(execute.initializer.body);
                      results.push(contents);
                    }
                  }
                }
              }
            }
          });
        }
      }
    }
  });
  return results;
}
var serializeSymbol = Symbol.for("serialize");
function isInterfaceType(type) {
  if (type.isClassOrInterface()) {
    return !!(type.symbol.flags & ts.SymbolFlags.Interface);
  }
  return false;
}
var Serializer = class {
  constructor(checker2) {
    this.checker = checker2;
  }
  collector = {};
  serializeType(type) {
    if (type.isUnion() || type.isIntersection()) {
      let optional;
      const types = [];
      for (const unionType of type.types) {
        if (optional === void 0) {
          optional = (unionType.flags & ts.TypeFlags.Undefined) !== 0;
          if (optional) {
            continue;
          }
        }
        types.push(this.serializeType(unionType));
      }
      return {
        [serializeSymbol]: true,
        optional,
        types
      };
    }
    if (this.checker.isArrayLikeType(type)) {
      const [argType] = this.checker.getTypeArguments(type);
      if (!argType) {
        console.warn(
          `No argument type found for ${type.symbol?.name} of ${this.checker.typeToString(type)}`
        );
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: ["any"]
        };
      }
      const typeSymbol = argType.getSymbol();
      if (!typeSymbol) {
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: [this.checker.typeToString(argType)]
        };
      }
      const declaration = typeSymbol.valueDeclaration;
      if (!declaration) {
        return null;
      }
      return {
        kind: "array",
        ...this.serializeNode(declaration)
      };
    }
    if (type.isClass()) {
      const declaration = type.symbol?.valueDeclaration;
      if (!declaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(declaration);
    }
    if (isInterfaceType(type)) {
      const valueDeclaration = type.symbol.valueDeclaration ?? type.symbol.declarations?.[0];
      if (!valueDeclaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(valueDeclaration);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: [this.checker.typeToString(type)]
    };
  }
  serializeNode(node) {
    if (ts.isObjectLiteralExpression(node)) {
      const symbolType = this.checker.getTypeAtLocation(node);
      const props = {};
      for (const symbol of symbolType.getProperties()) {
        const type = this.checker.getTypeOfSymbol(symbol);
        props[symbol.name] = this.serializeType(type);
      }
      return props;
    }
    if (ts.isPropertySignature(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isPropertyDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isInterfaceDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Interface has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertySignature)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isClassDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Class has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertyDeclaration)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isVariableDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      if (!node.type) {
        return "any";
      }
      const type = this.checker.getTypeFromTypeNode(node.type);
      return this.serializeType(type);
    }
    if (ts.isIdentifier(node)) {
      const symbol = this.checker.getSymbolAtLocation(node);
      if (!symbol) {
        console.warn(`No symbol found for ${node.getText()}`);
        return null;
      }
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    if (ts.isAwaitExpression(node)) {
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: ["any"]
    };
  }
};
function serialize(tsconfigPath, features) {
  const tsConfigParseResult = parseTsConfig(tsconfigPath);
  logger(`Parsing tsconfig`);
  const program = ts.createProgram({
    options: {
      ...tsConfigParseResult.options,
      noEmit: true,
      incremental: true,
      tsBuildInfoFile: join3(dirname2(tsconfigPath), "./.tsbuildinfo")
      // not working atm
    },
    rootNames: tsConfigParseResult.fileNames,
    projectReferences: tsConfigParseResult.projectReferences,
    configFileParsingDiagnostics: tsConfigParseResult.errors
  });
  logger(`Program created`);
  const typeChecker2 = program.getTypeChecker();
  logger(`Type checker created`);
  const serializer = new Serializer(typeChecker2);
  const emits = {};
  for (const feature2 of features) {
    logger(`Transforming feature ${feature2.name}`);
    const sourceFile = program.getSourceFile(feature2.path);
    if (!sourceFile) {
      throw new Error(`File not found: ${feature2.path}`);
    }
    const result = searchInFeature(sourceFile, serializer);
    const collector = { ...serializer.collector };
    for (const workflow2 of result) {
      for (const [key, value] of Object.entries(workflow2)) {
        collector[key] = value;
      }
    }
    const contents = Object.entries(collector).reduce(
      (acc, [key, value]) => {
        acc[key] = { [key]: value };
        return acc;
      },
      {}
    );
    logger(`Converting feature ${feature2.name} to interface`);
    emits[feature2.name] = toInterface(contents, serializeSymbol);
  }
  return emits;
}
function flattenSerialized(serialized) {
  const outputs = {};
  for (const [featureName, content] of Object.entries(serialized)) {
    for (const [fileName, fileContent] of Object.entries(content)) {
      outputs[
        // join(
        //   basename(featureName).replace(extname(featureName), ''),
        //   `${fileName}.ts`,
        // )
        `${fileName}.ts`
      ] = fileContent;
    }
  }
  return outputs;
}

// libs/openapi/src/lib/client.ts
async function evaluateFeatures(featuresDir, primitives) {
  const files = await readdir2(featuresDir);
  return Object.fromEntries(
    await Promise.all(
      files.map(async (featureFile) => {
        const featurePath = join4(featuresDir, featureFile);
        const featureText = await readFile2(featurePath, "utf-8");
        const feature2 = await evaluate(
          featureText,
          merge2(...[...primitives, defaultPrimitiveCallers])
        );
        const groupName = basename2(featurePath).replace(
          extname(featurePath),
          ""
        );
        return [
          groupName,
          feature2.workflows.map((it) => {
            const inputs = Object.fromEntries(
              Object.entries(it.trigger.inputs).map(
                ([key, value]) => {
                  return [
                    key,
                    {
                      schema: value.data.zod,
                      source: value.data.source
                    }
                  ];
                }
              )
            );
            return {
              imports: feature2.imports.filter(
                (it2) => it2.moduleSpecifier === "@workspace/extensions/zod"
              ),
              inputs,
              schema: `z.object(${toLitObject(inputs, (x) => x.schema)})`,
              name: it.name,
              type: it.trigger.type,
              formatOutput: () => pascalcase(it.name),
              trigger: {
                path: normalizeWorkflowPath({
                  featureName: "/",
                  workflowTag: it.tag,
                  workflowPath: it.trigger.config.path
                }),
                method: it.trigger.config.method
              }
            };
          })
        ];
      })
    )
  );
}
async function generate({ client, fs, primitives }) {
  const spec = {
    name: client.name,
    options: client.options,
    securityScheme: client.securityScheme,
    groups: await evaluateFeatures(fs.features, primitives)
  };
  const clientFiles = generateClientSdk(spec);
  const [commonZod, featurePaths] = await Promise.all([
    getFile(join4(fs.extensions, "zod", "index.ts")).then((it) => it || ""),
    readFolder(fs.features)
  ]);
  await writeFiles(
    client.output,
    { ...clientFiles, "zod.ts": commonZod },
    client.formatGeneratedCode
  );
  const serialized = serialize(
    fs.tsconfig,
    featurePaths.map((it) => ({
      name: it,
      path: join4(fs.features, it)
    }))
  );
  await writeFiles(
    join4(client.output, "outputs"),
    flattenSerialized(serialized),
    client.formatGeneratedCode
  );
  const [index2, outputIndex, inputsIndex] = await Promise.all([
    getFolderExports(client.output),
    getFolderExports(join4(client.output, "outputs")),
    getFolderExports(join4(client.output, "inputs"))
  ]);
  await writeFiles(
    client.output,
    {
      "index.ts": index2,
      "outputs/index.ts": outputIndex,
      "inputs/index.ts": inputsIndex,
      ...client.packageName && {
        "../package.json": toJson({
          name: client.packageName,
          version: "0.0.0",
          type: "module",
          main: "./index.js",
          module: "./index.js",
          types: "./src/index.d.ts",
          dependencies: {
            validator: "^13.12.0",
            zod: "^3.23.8",
            "fast-content-type-parse": "^2.0.0"
          },
          exports: {
            "./package.json": "./package.json",
            ".": {
              node: "./index.js",
              default: "./index.js",
              import: "./index.js",
              types: "./src/index.d.ts"
            }
          }
        })
      }
    },
    client.formatGeneratedCode
  );
}
export {
  generate
};
