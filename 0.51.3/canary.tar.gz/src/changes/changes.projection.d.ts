import type { Checker } from '@january/parser';
export interface WorkflowVM {
    id: string;
    displayName: string;
    featureName: string;
    trigger: IWorkflowTriggerVM;
    tag: string;
    code: string;
    structures: any;
    params: any;
    imports: Checker.Import[];
    output: Record<string, any>;
}
export interface IWorkflowTriggerVM {
    sourceId: string;
    details: Record<string, any>;
}
export interface IWorkflowActionVM {
    id: string;
    sourceId: string;
    details: Record<string, any>;
    outputName: string;
    displayName: string;
}
export type FieldValidationType = 'longitude' | 'latitude' | 'email' | 'contains' | 'tel' | 'optional' | 'required' | 'string' | 'number' | 'decimal' | 'url' | 'uuid' | 'matches' | 'datetime' | 'min' | 'max' | 'minlength' | 'minlength' | 'maxlength' | 'startwith' | 'endwith' | 'boolean';
export declare class FieldValidation {
    details: Record<string, any>;
    sourceId: string;
    name: string;
}
export interface TableFieldVM {
    id: string;
    tableId: string;
    sourceId: string;
    displayName: string;
    details: Record<string, any>;
    validations: FieldValidation[];
}
export interface TableVM {
    id: string;
    featureName: string;
    displayName: string;
    fields: TableFieldVM[];
    indexes: {
        columns: string[];
    }[];
}
export interface PolicyVM {
    id: string;
    displayName: string;
    rule: string;
    imports: Checker.Import[];
}
export interface ExtensionVM {
    id: string;
    name: string;
    main?: string;
    details: Record<string, any>;
}
export interface FeatureVM {
    displayName: string;
}
export interface Changes {
    tables: TableVM[];
    features: FeatureVM[];
    policies: PolicyVM[];
    workflows: WorkflowVM[];
}
