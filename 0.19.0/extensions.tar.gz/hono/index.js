// libs/extensions/src/hono/setup.txt
var setup_default = "import './features/crons'\nimport './features/listeners'\nimport { Hono } from 'hono';\nimport { cors } from 'hono/cors';\nimport { logger } from 'hono/logger';\n\nimport dataSource from './core/data-source';\nimport { ValidationFailedException } from './core/validation';\nimport routes from './features/routes';\nimport { IdentitySubject, loadSubject } from '@extensions/identity';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { StatusCode } from 'hono/utils/http-status';\n\nconst application = new Hono<{\n  Variables: { subject: IdentitySubject | null };\n}>();\napplication.use(cors(), logger());\n\napplication.use(async (context, next) => {\n  const subject = await loadSubject(context.req.header('Authorization'));\n  context.set('subject', subject);\n  await next();\n});\n\n// TODO: use rfc-7807-problem-details\napplication.onError((err, context) => {\n  console.error(err);\n\n  if (err instanceof ValidationFailedException) {\n    context.status(400);\n    return context.json(err);\n  }\n\n  if (err instanceof ProblemDetailsException) {\n    context.status(err.Details.status as StatusCode ?? 500);\n    return context.json(err.Details);\n  }\n\n  context.status(500);\n  return context.json({\n    type: 'about:blank',\n    title: 'Internal Server Error',\n    status: 500,\n    detail: 'An unexpected error occurred',\n  });\n});\n\nroutes.forEach(([path, route]) => {\n  application.route(path, route);\n});\n\ndataSource\n  .initialize()\n  .then(() => {\n    console.log('Database initialized');\n  })\n  .catch((error) => {\n    console.error(error);\n    process.exit(1);\n  });\n\napplication.get('/', (context, next) => {\n  return context.json({\n    status: 'UP',\n  });\n});\n\napplication.get('/health', async (context, next) => {\n  await dataSource.query('SELECT 1');\n  return context.json({\n    status: 'UP',\n  });\n});\n\nexport default application;";

// libs/extensions/src/hono/uploader.txt
var uploader_default = "import { Server } from '@tus/server';\nimport { Context, Next } from 'hono';\nimport { ServerResponse } from 'http';\nimport { PassThrough } from 'stream';\nimport { ReadableStream } from 'stream/web';\nimport { StatusCode } from 'hono/utils/http-status';\nimport { IncomingMessage } from 'http';\n\nexport function tusHandler(tus: Server) {\n  return async (context: Context, next: Next) => {\n    const { incoming: request, outgoing } = context.env as {\n      incoming: IncomingMessage;\n      outgoing: ServerResponse<IncomingMessage>;\n    };\n    let statusCode = 200;\n    let headers = {};\n\n    const originalWriteHead = outgoing.writeHead;\n    outgoing.writeHead = function (...args: any[]) {\n      statusCode = args[0];\n      headers = args[1];\n      return this;\n    };\n\n    Object.defineProperty(outgoing, 'statusCode', {\n      set: function (value) {\n        statusCode = value;\n      },\n    });\n\n    const orignalWrite = outgoing.write;\n    const orignalEnd = outgoing.end;\n    const pass = new PassThrough();\n\n    outgoing.end = pass.end.bind(pass);\n    outgoing.write = pass.write.bind(pass);\n\n    await tus.handle(request, outgoing);\n\n    const response$ = context.body(\n      statusCode === 204 ? null : (ReadableStream.from(pass) as any),\n      statusCode as StatusCode,\n      Object.fromEntries(\n        Object.entries(headers).map(([key, value]) => [\n          key,\n          typeof value === 'number' ? value.toString() : value,\n        ]),\n      ) as Record<string, string>,\n    );\n    outgoing.write = orignalWrite;\n    outgoing.end = orignalEnd;\n    outgoing.writeHead = originalWriteHead;\n    return response$;\n  };\n}\n\nexport function createUploader(\n  options: Omit<\n    ConstructorParameters<typeof Server>[0],\n    | 'allowedCredentials'\n    | 'allowedHeaders'\n    | 'allowedMethods'\n    | 'allowedOrigins'\n    | 'respectForwardedHeaders'\n    | 'relativeLocation'\n    | 'respectForwardedHeaders'\n  >,\n) {\n  const tus = new Server({\n    ...options,\n    respectForwardedHeaders: true,\n  });\n  return tusHandler(tus);\n}\n\nexport function parseMetadata(header: string) {\n  const metadata: Record<string, string> = {};\n  header.split(',').forEach((item) => {\n    const [key, base64Value] = item.split(' ');\n    metadata[key] = Buffer.from(base64Value, 'base64').toString('utf8');\n  });\n  return metadata;\n}\n";

// libs/extensions/src/hono/zod.txt
var zod_default = "import { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { z } from 'zod';\n\nexport class ValidationFailedException extends ProblemDetailsException {\n  constructor(errors: Record<string, unknown>) {\n    super({\n      type: 'validation-failed',\n      status: 400,\n      title: 'Bad Request.',\n      detail: 'Validation failed.',\n    });\n    this.Details.errors = errors;\n  }\n}\n\nexport function validateOrThrow<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: z.infer<z.ZodObject<T>>,\n): asserts input is z.infer<z.ZodObject<T>> {\n  const result = schema.safeParse(input);\n  if (!result.success) {\n    const errors = result.error.flatten((issue) => ({\n      message: issue.message,\n      code: issue.code,\n      fatel: issue.fatal,\n      path: issue.path.join('.'),\n    })).fieldErrors;\n    throw new ValidationFailedException(errors);\n  }\n}\n";

// libs/extensions/src/hono/index.ts
var hono = {
  packages: {
    boxen: {
      version: "^8.0.1",
      dev: false
    },
    "fast-glob": {
      version: "^3.3.2",
      dev: false
    },
    ip: {
      version: "^2.0.1",
      dev: false
    },
    "@types/ip": {
      version: "^1.1.3",
      dev: false
    },
    hono: {
      version: "^4.4.0",
      dev: false
    },
    "@hono/node-server": {
      version: "^1.11.1",
      dev: false
    },
    "@scalar/hono-api-reference": {
      version: "^0.5.145",
      dev: false
    },
    "@tus/file-store": {
      version: "^1.5.0",
      dev: false
    },
    "@tus/server": {
      version: "^1.8.0",
      dev: false
    }
  },
  files: {
    // this is here because we don't have core extension anymore, but that might change in the future
    "src/core/validation.ts": zod_default,
    "src/app.ts": setup_default,
    "src/extensions/tus/index.ts": uploader_default
  }
};
export {
  hono
};
//# sourceMappingURL=index.js.map
