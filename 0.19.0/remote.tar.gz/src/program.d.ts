export declare const cli: import("commander").Command;
export declare function dfn(): any;
export declare function apiKey(): any;
export declare const ast: {
    healthCheckOptions: Record<string, any> | undefined;
    paths: string[];
    expose: string;
};
