import type { OpenAPIObject, OperationObject } from 'openapi3-ts/oas31';
import { type Operation } from './sdk';
export interface GenerateSdkConfig {
    spec: OpenAPIObject;
    target?: 'javascript';
    style?: 'github';
    operationId?: (operation: OperationObject, path: string, method: string) => string;
}
export declare const defaults: Partial<GenerateSdkConfig> & Required<Pick<GenerateSdkConfig, 'operationId'>>;
export declare function generate(config: GenerateSdkConfig): {
    groups: Record<string, Operation[]>;
    commonSchemas: Record<string, string>;
    outputs: Record<string, string>;
};
export * from './sdk';
