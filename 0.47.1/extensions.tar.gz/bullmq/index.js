var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/utils/src/lib/utils.ts
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        const canRetry = operation.retry(error);
        if (!canRetry) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config2) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config2.accessor(item)]: config2.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config2) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config2.featureName),
        snakecase(config2.workflowTag),
        toCurlyBraces(config2.workflowPath)
      )
    )
  );
  return config2.workflowMethod ? `${config2.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && !Array.isArray(obj) && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
function msToNs(ms) {
  return ms * 1e6;
}
__name(msToNs, "msToNs");
function nsToMs(nano) {
  return parseInt(typeof nano === "number" ? String(nano) : nano, 10) / 1e6;
}
__name(nsToMs, "nsToMs");
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input, sub) {
  const index = input.indexOf(sub);
  if (index === -1) {
    return input;
  }
  return input.slice(sub.length);
}
__name(substring, "substring");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";
var Contracts;
((Contracts2) => {
  function fffffff(input) {
    const [namespace, value] = input.split(":");
    return {
      namespace,
      value
    };
  }
  __name(fffffff, "fffffff");
})(Contracts || (Contracts = {}));
function makeSchema(property) {
  const result = {};
  (property.validations ?? []).filter((validation) => validation.type !== "unique").map((validation) => {
    const validationType = validation.type;
    if (!validationType) {
      throw new Error(`Validation ${validation.id} not found.`);
    }
    if (validation.details["message"]) {
      result["errorMessage"] = validation.details["message"];
    }
    switch (validationType) {
      case "mandatory":
        result["required"] = true;
        if (property.type === "string") {
          result["minLength"] ??= 1;
        }
        break;
      case "string":
        break;
      case "number":
        result["type"] = "number";
        break;
      case "oneof":
        result["type"] = "string";
        result["enum"] = validation.details["value"];
        break;
      case "email":
        result["type"] = "string";
        result["format"] = "email";
        result["isEmail"] = [];
        break;
      case "minlength":
        result["type"] = "string";
        result["minLength"] = validation.details["value"];
        break;
      case "maxlength":
        result.type = "string";
        result.maxLength = validation.details["value"];
        break;
      case "min":
        result.minLength = void 0;
        result.type = "number";
        result.minimum = validation.details["value"];
        break;
      case "max":
        result.type = "number";
        result.maximum = validation.details["value"];
        break;
      case "pattern":
        result.type = "string";
        result.regex = validation.details["value"];
        break;
      case "url":
        result.type = "string";
        result.format = "uri";
        result["isURL"] = [];
        break;
      case "uuid":
        result.type = "string";
        result.format = "uuid";
        break;
      case "startswith":
        result.type = "string";
        result.pattern = `^${validation.details["value"]}`;
        break;
      case "endswith":
        result.type = "string";
        result.pattern = `${validation.details["value"]}$`;
        break;
      case "contains":
        result.type = "string";
        result.pattern = validation.details["value"];
        break;
      case "before":
        result.type = "string";
        result["isBefore"] = [validation.details["value"]];
        break;
      case "after":
        result.type = "string";
        result["isAfter"] = [validation.details["value"]];
        break;
      case "boolean":
        result.type = "boolean";
        break;
      case "date":
        result.type = "string";
        result.format = "date";
        break;
      case "datetime":
        result.type = "string";
        result.format = validation.details["value"];
        break;
      case "time":
        result.type = "string";
        result.format = validation.details["value"];
        break;
      case "tel":
        result["isMobilePhone"] = ["any"];
        break;
      case "longitude":
      case "latitude":
        result.type = "string";
        result["isLatLong"] = [];
        break;
      case "ip":
        result.type = "string";
        result.format = validation.details["value"];
        break;
      case "decimal":
        result.type = "string";
        result.format = "double";
        result.multipleOf = 1 / Math.pow(10, +validation.details["value"]);
        break;
      default:
        throw new Error(`Validation ${validationType} not supported.`);
    }
  });
  return result;
}
__name(makeSchema, "makeSchema");
function isActionProperty(property) {
  return property.name && property.namespace;
}
__name(isActionProperty, "isActionProperty");
function createSwitch(cases, fallback) {
  const project = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile("index.ts");
  const fn = sourceFile.addFunction({
    name: "myFunction",
    parameters: [{ name: "value", type: "string" }],
    returnType: "void",
    isExported: true
  });
  const [switchStmt] = fn.addStatements(
    (writer) => writer.write(
      dedent(`switch (true) {
        ${cases.map((it) => `case ${it.condition}:`).join("\n")}
        ${fallback ? "default:" : ""}
        }`)
    )
  );
  const clauses = switchStmt.getClauses();
  for (let index = 0; index < cases.length; index++) {
    clauses[index].addStatements(
      Array.isArray(cases[index].logic) ? [...cases[index].logic, "break;"] : [cases[index].logic, "break;"]
    );
  }
  if (fallback && fallback.logic) {
    clauses.at(-1)?.addStatements(
      Array.isArray(fallback.logic) ? [...fallback.logic, "break;"] : [fallback.logic, "break;"]
    );
  }
  return [switchStmt.getFullText()];
}
__name(createSwitch, "createSwitch");
function createIfElse(defaultCase, fallback) {
  const project = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile("index.ts");
  const fn = sourceFile.addFunction({
    name: "myFunction",
    parameters: [{ name: "value", type: "string" }],
    returnType: "void",
    isExported: true
  });
  const [ifStmt] = fn.addStatements(
    (writer) => writer.write(
      dedent(`
        if(${defaultCase.condition}) {}
        ${fallback ? "else {}" : ""}
      `)
    )
  );
  ifStmt.getThenStatement().addStatements(defaultCase.logic);
  if (fallback && fallback.logic) {
    ifStmt.getElseStatement().addStatements(fallback.logic);
  }
  return [ifStmt.getFullText()];
}
__name(createIfElse, "createIfElse");
function createArrowFn(name, params, body) {
  const project = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile("index.ts");
  const varFnStm = sourceFile.addVariableStatement({
    declarationKind: VariableDeclarationKind.Const,
    declarations: [
      {
        name,
        initializer: "async () => {}"
      }
    ]
  });
  const [declaration] = varFnStm.getDeclarations();
  const arrowFn = declaration.getInitializerOrThrow();
  for (const stmt of body) {
    arrowFn.addStatements(stmt);
    arrowFn.addParameters(params);
  }
  return varFnStm.getFullText();
}
__name(createArrowFn, "createArrowFn");
function useInput(parsedInput) {
  if (!parsedInput) {
    return void 0;
  }
  return parsedInput.data?.["parameterName"] ?? parsedInput.value;
}
__name(useInput, "useInput");
function nonStatic(inputs) {
  return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
__name(nonStatic, "nonStatic");
function standaloneInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique = uniquify(
    Object.entries(inputs).filter(
      ([name, prop]) => prop.data?.["standalone"] && predicate([name, prop])
    ),
    ([name, prop]) => paramName([name, prop])
  );
  return unique.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
__name(standaloneInputs, "standaloneInputs");
function nonStaticInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique = uniquify(
    nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])),
    ([name, prop]) => paramName([name, prop])
  );
  return unique.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
__name(nonStaticInputs, "nonStaticInputs");
function paramName([name, prop]) {
  return prop.data?.["parameterName"] || name;
}
__name(paramName, "paramName");

// libs/compiler/sdk/devkit/src/lib/project-config.ts
var _config;
import { Injectable, ServiceLifetime } from "tiny-injector";
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
__name(ProjectConfig, "ProjectConfig");
ProjectConfig = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var config = {
  basePath: "./src",
  extensions: "./src/extensions",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = /* @__PURE__ */ __name((importPath) => {
    return join2("#{relative}", config.basePath, importPath);
  }, "makeCoreImportSpecifier");
  makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  }, "makeEntityImportSpecifier");
  makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
  makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
  makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
  makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  ), "makeWorkspacePath");
  makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
  makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  ), "makeCommandPath");
  makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
  makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  ), "makeControllerPath");
  makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  ), "makeControllerRoutePath");
  makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  ), "makeListenerRoutePath");
  makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  ), "makeJobRoutePath");
  makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  ), "makeEntityPath");
  makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  ), "makeQueryPath");
  makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
};
__name(ProjectFS, "ProjectFS");
ProjectFS = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectFS);
var identityDir = /* @__PURE__ */ __name(() => {
  return `${config.extensions}/identity`;
}, "identityDir");
var policiesGlob = /* @__PURE__ */ __name(() => {
  return `${config.extensions}/identity/**/*.policy.ts`;
}, "policiesGlob");
var commandsGlob = /* @__PURE__ */ __name(() => {
  return `${config.features}/**/*.command.ts`;
}, "commandsGlob");
var routersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.router.ts";
}, "routersGlob");
var listenersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.github.ts";
}, "listenersGlob");
var cronsGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.cron.ts";
}, "cronsGlob");
var entitiesGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.entity.ts";
}, "entitiesGlob");
var makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
var makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
var makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(config.extensions, "identity", fileName), "makeIdentityPath");
var makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
var makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
  config.basePath,
  "../",
  /** We need this to work with new january cli */
  "../",
  fileName
), "makeWorkspacePath");
var makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
var makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => makeFeatureFile(
  featureName,
  join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
), "makeCommandPath");
var makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
var makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
), "makeControllerRoutePath");
var makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
), "makeListenerRoutePath");
var makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
), "makeJobRoutePath");
var makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
  config.features,
  spinalcase2(featureName),
  `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
), "makeEntityPath");
var makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
  config.features,
  spinalcase2(tableName),
  "queries",
  `${spinalcase2(queryName)}.query.ts`
), "makeQueryPath");
var makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
var makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
  return join2("#{entity}", pascalcase(tableName));
}, "makeEntityImportSpecifier");
var makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
), "makeControllerPath");
var makeFeaturePath = /* @__PURE__ */ __name((fileName) => join2(config.features, fileName), "makeFeaturePath");

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project as Project2, SyntaxKind, VariableDeclarationKind as VariableDeclarationKind2 } from "ts-morph";
function getDefaultExport(code, project = new Project2({ useInMemoryFileSystem: true })) {
  const sourceFile = project.createSourceFile("index.ts", code);
  const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
  const exportAssignment = defaultExport.getValueDeclarationOrThrow();
  return {
    value: exportAssignment.getExpression().getFullText(),
    sourceFile
  };
}
__name(getDefaultExport, "getDefaultExport");
function getReturnTypeOfDefaultExport(workflowOutput, project = new Project2({ useInMemoryFileSystem: true })) {
  const sourceFile = project.createSourceFile("index.ts", workflowOutput);
  const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
  const exportAssignment = defaultExport.getValueDeclarationOrThrow();
  const fn = exportAssignment.getFirstDescendantByKind(SyntaxKind.ArrowFunction) ?? exportAssignment.getFirstDescendantByKindOrThrow(
    SyntaxKind.FunctionDeclaration
  );
  const returnStatement = fn.getFirstDescendantByKind(
    SyntaxKind.ReturnStatement
  );
  const returnType = fn.getReturnType();
  if (!returnStatement) {
    return {
      properties: [],
      returnCode: "",
      returnTypeStr: ""
    };
  }
  const objectLiteral = returnStatement.getFirstChildByKind(
    SyntaxKind.ObjectLiteralExpression
  );
  if (!objectLiteral) {
    throw new Error("Return statement should return an object literal");
  }
  return {
    returnTypeStr: returnType.getText(),
    // replace "steps" with "" to get the name of the property
    returnCode: returnStatement.getText().replace(/steps\./g, ""),
    properties: returnType.getProperties().map((it) => ({
      name: it.getName(),
      primitiveType: it.getValueDeclaration()?.getType().getText(),
      parameter: it.getValueDeclaration()?.getFirstDescendantByKindOrThrow(SyntaxKind.PropertyAccessExpression)?.getText()
    }))
  };
}
__name(getReturnTypeOfDefaultExport, "getReturnTypeOfDefaultExport");
function assignDefaultExportToVar(code, varName, project = new Project2({ useInMemoryFileSystem: true })) {
  const { value, sourceFile } = getDefaultExport(code, project);
  const varStmt = sourceFile.addVariableStatement({
    declarationKind: VariableDeclarationKind2.Const,
    declarations: [
      {
        name: varName,
        initializer: value
      }
    ]
  });
  return varStmt.getFullText();
}
__name(assignDefaultExportToVar, "assignDefaultExportToVar");

// libs/compiler/generator/src/lib/sourcecode.ts
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
import { basename, dirname, extname, join as join3, relative, sep } from "path";
import { Injectable as Injectable3, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project3,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project3(options);
}
__name(getMorph, "getMorph");
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join3(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = /* @__PURE__ */ __name(function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
        case moduleSpecifier.startsWith("#{entity}"): {
          const entityName = moduleSpecifier.replace("#{entity}/", "");
          const files = __privateGet(this, _morphProject).getSourceFiles(
            join3(__privateGet(this, _outputDir), "/**/src/features/**/*.entity.ts")
          );
          const filePath = __privateMethod(this, _VirtualProject_instances, findClassSourceFile_fn).call(this, files, entityName);
          if (!filePath) {
            throw new Error(`Entity ${entityName} file not found.`);
          }
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(`${moduleSpecifier}.ts`);
          break;
        }
      }
    }
  }
}, "#resolveImports");
findClassSourceFile_fn = /* @__PURE__ */ __name(function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
}, "#findClassSourceFile");
exportsDir_fn = /* @__PURE__ */ __name(function(dir) {
  const fullPath = join3(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  console.log(
    imports,
    __privateGet(this, _morphProject).getSourceFile(join3(fullPath, "index.ts"))
  );
  __privateGet(this, _morphProject).createSourceFile(
    join3(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
}, "#exportsDir");
exportsCommands_fn = /* @__PURE__ */ __name(function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join3(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
}, "#exportsCommands");
exportRoutes_fn = /* @__PURE__ */ __name(function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono][]`,
    { overwrite: true }
  );
}, "#exportRoutes");
exportListeners_fn = /* @__PURE__ */ __name(function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
}, "#exportListeners");
exportJobs_fn = /* @__PURE__ */ __name(function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
}, "#exportJobs");
exportEntities_fn = /* @__PURE__ */ __name(function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities= [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
}, "#exportEntities");
tuneImports_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      assertElements: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
    importDeclaration.getAssertClause()?.getElements().forEach((item) => {
      uniqueImports[moduleSpecifierValue].assertElements.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    const assertElements = Array.from(it.assertElements.values());
    file.addImportDeclaration({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements,
      defaultImport: it.defaultImport,
      isTypeOnly: false,
      namespaceImport: it.namespaceImport
    });
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    file.addImportDeclaration({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements: [],
      defaultImport: it.defaultImport,
      isTypeOnly: true
    });
  });
}, "#tuneImports");
removeUnusedImports_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).some(
        (it) => it.getText() === importedName && it.getParent() !== namedImport
      );
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
}, "#removeUnusedImports");
moveImportsToTop_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index) => {
    file.insertImportDeclaration(index, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
}, "#moveImportsToTop");
__name(VirtualProject, "VirtualProject");
VirtualProject = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}
__name(getLastNParts, "getLastNParts");
function emitFiles(concreteStructure, generateDir) {
  const vProject = new VirtualProject(generateDir);
  vProject.generate(concreteStructure);
  return {
    files: vProject.getOutput(),
    save: vProject.emit.bind(vProject),
    cleanup: /* @__PURE__ */ __name(() => vProject.cleanup(), "cleanup")
  };
}
__name(emitFiles, "emitFiles");

// libs/compiler/generator/src/index.ts
import {
  Project as Project4,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";
function getArrowFnBody(arrowFn) {
  const project = new Project4({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${arrowFn}`
  );
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind3.ArrowFunction);
  return guardFunction?.getBodyText();
}
__name(getArrowFnBody, "getArrowFnBody");
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${typeof arg === "undefined" ? "" : arg})`;
  const guard = transferable.toString();
  const project = new Project4({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind3.ArrowFunction);
  const inputs = {};
  const parameters = guardFunction.getParameters();
  if (parameters.length > 1) {
    inputs["request"] = {
      static: true,
      type: "IncomingMessage",
      value: `(context.env as { incoming: IncomingMessage }).incoming`,
      data: {
        parameterName: "request",
        standalone: true
      },
      structure: [
        {
          kind: StructureKind2.ImportDeclaration,
          moduleSpecifier: "http",
          namedImports: ["IncomingMessage"]
        }
      ]
    };
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind3.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind3.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind3.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind2.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!parent) {
      inputs["trigger"] = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind3.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind3.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind3.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs[v] = {
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()"
      }
    };
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = /* @__PURE__ */ __name((ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind3.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  }, "isOutputReturn");
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind3.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  const atLeastOneOutputReturn = returns.some(isOutputReturn);
  if (!atLeastOneOutputReturn) {
    for (const ret of returns) {
      if (isOutputReturn(ret)) {
        continue;
      }
      const isReturningCall = ret.getExpressionIfKind(
        SyntaxKind3.CallExpression
      );
      let returnValue = ret.getText().trim().replace("return ", "");
      if (returnValue.endsWith(";")) {
        returnValue = returnValue.slice(0, -1);
      }
      if (returnValue === "return") {
        ret.replaceWithText(options.setOutput());
      } else {
        ret.replaceWithText(
          options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
        );
      }
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs
  };
}
__name(refineExecute, "refineExecute");

// libs/extensions/src/bullmq/index.ts
import { StructureKind as StructureKind3 } from "ts-morph";
var bullmq = /* @__PURE__ */ __name(() => {
  return {
    id: "bullmq",
    primitives: {
      trigger: {
        queue(config2) {
          return {
            type: "bullmq-job",
            config: {
              ...config2 ?? {},
              params: [
                !config2?.status || config2?.local ? { name: "job", type: "Job" } : { name: "job", type: `Params[0]` }
              ],
              structures: [
                {
                  kind: StructureKind3.ImportDeclaration,
                  moduleSpecifier: "bullmq",
                  namedImports: ["Job", "QueueEventsListener"]
                },
                !(!config2?.status || config2?.local) ? `type Params = Parameters<QueueEventsListener['${config2.status}']>;` : ""
              ]
            },
            policies: [],
            refineExecute: /* @__PURE__ */ __name((execute) => {
              return refineExecute(execute, {
                replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey"),
                setOutput: /* @__PURE__ */ __name((arg) => `${typeof arg === "undefined" ? "" : `return ${arg}`}`, "setOutput")
              });
            }, "refineExecute")
          };
        }
      }
    },
    packages: {
      bullmq: {
        version: "^5.34.0",
        dev: false
      }
    },
    files: {},
    onFeature(contract, api) {
      const relatedTags = {};
      contract.workflows.forEach((workflow) => {
        if (workflow.trigger.sourceId === "bullmq-job") {
          relatedTags[workflow.trigger.tag] = (relatedTags[workflow.trigger.tag] ?? []).concat(workflow);
        }
      });
      return {
        [makeControllerPath(contract.displayName, "worker")]: [
          {
            kind: StructureKind3.ImportDeclaration,
            moduleSpecifier: "bullmq",
            namedImports: ["Queue", "Worker", "Job", "JobState", "QueueEvents"]
          },
          ...Object.keys(relatedTags).map(
            (tag) => ({
              kind: StructureKind3.ImportDeclaration,
              moduleSpecifier: `./${spinalcase2(tag)}`,
              namespaceImport: camelcase(tag)
            })
          ),
          ...Object.entries(relatedTags).map(([tag, workflows]) => {
            const workerName = camelcase(tag + "_worker");
            const queueEventsName = camelcase(tag + "_events");
            const localListeners = workflows.filter(
              (workflow) => workflow.trigger.details.status && workflow.trigger.details.local === true
            );
            const listeners = workflows.filter(
              (workflow) => workflow.trigger.details.status && !workflow.trigger.details.local
            );
            const handlers = workflows.filter(
              (workflow) => !workflow.trigger.details.status
            );
            const queueName = tag;
            const operationName = /* @__PURE__ */ __name((workflow) => `${camelcase(
              workflow.tag
            )}.${camelcase(workflow.trigger.operationName)}`, "operationName");
            const listenersLogic = listeners.map((workflow) => {
              return `${queueEventsName}.on(
              "${workflow.trigger.details.status}",
              async (job) => {
                await ${operationName(workflow)}(job);
              })`;
            });
            const localListenersLogic = Object.entries(
              Object.groupBy(
                localListeners,
                (workflow) => workflow.trigger.details.status
              )
            ).map(([status, workflows2 = []]) => {
              return `${workerName}.on("${status}", async (job) => {
                 ${createSwitch(
                workflows2.map((workflow) => ({
                  condition: `job.name === "${workflow.trigger.details.jobName}"`,
                  logic: `return await ${operationName(workflow)}(job);`
                }))
              )}

                });`;
            });
            return `
            const ${workerName} = new Worker("${queueName}", async (job)=>{
                     ${createSwitch(
              handlers.map((workflow) => ({
                condition: `job.name === "${workflow.trigger.details.jobName}"`,
                logic: `return await ${operationName(workflow)}(job);`
              }))
            )}
            });
            ${localListenersLogic.join("\n")}
            ${localListeners.length ? `const ${queueEventsName} = new QueueEvents("${queueName}");${listenersLogic.join("\n")}` : ""}`;
          })
        ]
      };
    }
  };
}, "bullmq");
export {
  bullmq
};
//# sourceMappingURL=index.js.map
