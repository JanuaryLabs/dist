import type { ArrayExpression, BigIntLiteral, BlockStatement, BooleanLiteral, CallExpression, ExportAllDeclaration, ExportDeclaration, ExportDefaultDeclaration, ExportDefaultExpression, ExportNamedDeclaration, Expression, HasSpan, Identifier, Import, KeyValueProperty, MemberExpression, NumericLiteral, ObjectExpression, PrivateName, Property, PropertyName, Span, SpreadElement, StringLiteral, Super } from '@swc/wasm-web';
export declare namespace checker {
    function isCallExpression(node?: Expression | BlockStatement, name?: string): node is CallExpression;
    function isObjectExpression(node: Expression): node is ObjectExpression;
    function isKeyValueProperty<T extends Expression>(node: Property | SpreadElement, valueType?: T['type'], keyName?: string): node is KeyValueProperty & {
        value: T;
    };
    function isNullLiteral(node: Expression): node is StringLiteral;
    function isPrimitive(node: Expression): node is StringLiteral | BooleanLiteral | NumericLiteral | BigIntLiteral;
    function isIdentifier(node?: PropertyName | PrivateName | Expression | Super | Import, name?: string): node is Identifier;
    function isMemberExpression(node?: Expression | Super | Import, name?: string): node is MemberExpression;
    function isArrayExpression(node: Expression): node is ArrayExpression;
}
export declare namespace diagnostic {
    interface Diagnostic {
        message: string | Record<string, string> | string[];
        node: Expression;
        span?: Span;
        severity: 'error' | 'warning' | 'info';
    }
}
export declare namespace Checker {
    function isPrimitive(value: any): value is string | number | boolean | bigint;
    function isCallExpression(value: any): value is CallExpression;
    function isObjectExpression(value: any): value is Record<string, Expression>;
    function isArrayExpression(value: any): value is Array<Expression>;
    type Literal = string | number | bigint | boolean | null;
    type Expression = CallExpression | Literal | {
        [key in string]: Expression;
    } | Array<Expression>;
    interface CallExpression extends HasSpan {
        caller: string;
        arguments: Expression[];
    }
    interface Import {
        isTypeOnly: boolean;
        moduleSpecifier: string;
        defaultImport: string | undefined;
        namedImports: NamedImport[];
        namespaceImport: string | undefined;
    }
    interface NamedImport {
        name: string;
        alias?: string;
        isTypeOnly: boolean;
    }
    type Exports = ExportDefaultExpression | ExportDefaultDeclaration | ExportNamedDeclaration | ExportAllDeclaration | ExportDeclaration;
}
export declare function parseCode(code: string): Promise<import("@swc/wasm-web").Module | null>;
export declare function legacy_parse(code: string): Promise<{
    imports: Checker.Import[];
    project: Checker.CallExpression;
} | null>;
export declare function parse(code: string): Promise<{
    imports: Checker.Import[];
    project: Checker.Expression;
} | null>;
export declare function resolveCallExpression(node: CallExpression, sourceCode: string): Checker.CallExpression;
export declare function getExports(code: string): Promise<(ExportDefaultExpression | ExportDefaultDeclaration | ExportNamedDeclaration | ExportAllDeclaration | ExportDeclaration)[]>;
