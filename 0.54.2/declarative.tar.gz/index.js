// libs/sdk/declarative/src/lib/table.ts
import pluralize from "pluralize";

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config.message
    }
  };
}
var required = mandatory;
function unique(config = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config.message
      }
    }
  ];
}
function defineValidation(config) {
  return {
    name: config.name,
    config
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config) {
  const additionalFields = {};
  const idField = Object.values(config.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        mode: "string"
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true,
        mode: "string"
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config.fields,
      ...additionalFields
    },
    constraints: config.constraints || []
  };
}
((table2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = table2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown table type: ${type}`);
    }
    return table2(type);
  }
  table2.fromConfig = fromConfig;
  function link(config) {
    const { table1, table2: table22 } = config;
    return table2({
      fields: {
        ...config.fields,
        [pluralize.singular(distilTableName(table1))]: field.relation({
          references: table1,
          relationship: "many-to-one"
        }),
        [pluralize.singular(distilTableName(table22))]: field.relation({
          references: table22,
          relationship: "many-to-one"
        })
      },
      constraints: config.constraints
    });
  }
  table2.link = link;
})(table || (table = {}));
function field(config) {
  const { type, validations = [], metadata = {}, ...rest } = config;
  return {
    type: config.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config) {
    return field2({
      type: "relation",
      metadata: { ...config, references: distilTableName(config.references) },
      validations: config.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
function distilTableName(table2) {
  const [, relatedTableName, ...rest] = table2.split(".");
  if (rest.length) {
    throw new Error(
      `Wrong relation reference: ${table2}. Did you mean tables.${relatedTableName}`
    );
  }
  return relatedTableName;
}
field.enum = (config) => {
  return field({
    type: "single-select",
    validations: config.validations,
    metadata: {
      style: "enum",
      values: config.values,
      defaultValue: config.defaultValue
    }
  });
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(config) {
  const execute = config.trigger.refineExecute(config.execute);
  return {
    trigger: config.trigger,
    execute,
    description: config.description,
    tag: config.tag
  };
}
export {
  field,
  index,
  mandatory,
  required,
  table,
  unique,
  validation,
  workflow
};
