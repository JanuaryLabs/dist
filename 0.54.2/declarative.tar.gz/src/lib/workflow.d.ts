import type { refineExecute } from '@january/generator';
import type { Checker } from '@january/parser';
export type MapObj<T> = T extends {
    value: infer Value;
} ? Value : T;
export type InferTriggerProps<T> = T extends TriggerDefinition<infer TriggerProps> ? TriggerProps extends unknown[] ? TriggerProps : never : never;
export interface WorkflowDefinition<Trigger extends TriggerDefinition<unknown>> {
    trigger: Trigger;
    execute: any;
    description?: string;
    tag: string;
}
export interface TriggerDefinition<RT> {
    type: string;
    config: Record<string, unknown>;
    policies?: any[];
    inputs?: Record<string, {
        value: string;
    }>;
    refineExecute: (execute: any) => ReturnType<typeof refineExecute>;
}
export interface ActionDefinition<Output = unknown> {
    type: string;
    config: Record<string, unknown>;
}
export declare function workflow<Result extends any, Trigger extends TriggerDefinition<unknown>>(config: WorkflowConfig<Trigger, Result>): WorkflowDefinition<Trigger>;
export type WorkflowConfig<Trigger extends TriggerDefinition<unknown>, R> = {
    tag: string;
    description?: string;
    trigger: Trigger;
    execute: (...args: InferTriggerProps<Trigger>) => R;
};
export declare namespace trigger { }
export declare namespace policy { }
export declare namespace trigger {
}
export type Feature = {
    name: string;
    workflows: Record<string, WorkflowDefinition<TriggerDefinition<unknown>>>;
    imports: Checker.Import[];
};
export interface PolicyDefinition {
    name: string;
    rule: string;
    imports: Checker.Import[];
}
export type Policy = (name: string) => string;
