// libs/extensions/src/firebase/auth/firebase-app-setup.txt
var firebase_app_setup_default = "import { cert, initializeApp } from 'firebase-admin/app';\nimport type { GoogleServiceAccount } from '../../core/service-account';\n\nconst serviceAccount: GoogleServiceAccount = JSON.parse(\n	Buffer.from(process.env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY, 'base64').toString(\n		'ascii'\n	)\n);\n\nexport const firebaseApp = initializeApp({\n	credential: cert({\n		clientEmail: serviceAccount.client_email,\n		privateKey: serviceAccount.private_key,\n		projectId: serviceAccount.project_id,\n	}),\n	projectId: serviceAccount.project_id,\n	serviceAccountId: serviceAccount.client_email,\n});\n";

// libs/extensions/src/firebase/auth/service-account-interface.txt
var service_account_interface_default = "export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n";

// libs/extensions/src/firebase/auth/subject.txt
var subject_default = "import { firebaseApp } from './firebase';\nimport { UnauthorizedException } from '#core/identity';\nimport {\n	AuthClientErrorCode,\n	type DecodedIdToken,\n	FirebaseAuthError,\n	getAuth,\n} from 'firebase-admin/auth';\nimport { type IResult } from 'ua-parser-js';\n\nexport interface ClientInfo {\n	ip?: string | null;\n	userAgent?: string | null;\n	userAgentData: IResult;\n}\n\nexport type IdentitySubject = {\n	claims: DecodedIdToken;\n};\n\nexport const auth = getAuth(firebaseApp);\n\nfunction isBearerToken(\n	token: string | null | undefined\n): token is `Bearer ${string}` {\n	if (!token || typeof token !== 'string') {\n		return false;\n	}\n\n	if (!token.startsWith('Bearer ')) {\n		return false;\n	}\n\n	return true;\n}\n\nexport async function verifyToken(\n	token: string | null | undefined\n): Promise<boolean> {\n	if (!isBearerToken(token)) {\n		throw new UnauthorizedException();\n	}\n\n	try {\n		await auth.verifyIdToken(token.replace('Bearer ', ''));\n		return true;\n	} catch (error) {\n		if (error instanceof FirebaseAuthError) {\n			if (error.hasCode(AuthClientErrorCode.ID_TOKEN_EXPIRED.code)) {\n				const exception = new UnauthorizedException();\n				exception.cause = error;\n				throw exception;\n			}\n		}\n\n		// TODO: log the error\n		const exception = new UnauthorizedException();\n		exception.cause = error;\n		throw exception;\n	}\n}\n\nexport async function loadSubject(\n	token: string | null | undefined\n): Promise<IdentitySubject | null> {\n	if (!isBearerToken(token)) {\n		return null;\n	}\n\n	try {\n		const claims = await auth.verifyIdToken(token.replace('Bearer ', ''));\n		return { claims };\n	} catch (error) {\n		return null;\n	}\n}\n";

// libs/extensions/src/firebase/auth/index.ts
function auth() {
  return {
    id: "firebase/auth",
    packages: {
      "firebase-admin": {
        version: "^12.4.0",
        dev: false
      },
      "ua-parser-js": {
        version: "^1.0.37",
        dev: false
      },
      "@types/ua-parser-js": {
        version: "^0.7.39",
        dev: true
      },
      "@types/request-ip": {
        version: "^0.0.41",
        dev: true
      },
      "request-ip": {
        version: "^3.3.0",
        dev: false
      }
    },
    files: {
      "src/extensions/firebase-auth/subject.ts": subject_default,
      "src/core/service-account.ts": service_account_interface_default,
      "src/extensions/firebase-auth/firebase.ts": firebase_app_setup_default,
      "src/extensions/firebase-auth/index.ts": `
    export * from './firebase';
import z from 'zod';
export const env = {
  FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: z.string()
}
`
    },
    primitives: {
      policy: {
        authenticated() {
          return (name) => `
    import { type Context } from 'hono';
    import { verifyToken } from '#core/identity';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
        }
      }
    }
  };
}

// libs/extensions/src/firebase/functions/index.ts
import yaml from "js-yaml";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}

// libs/extensions/src/firebase/functions/index.ts
var deployContent = () => {
  return yaml.dump(
    {
      name: "Deploy To Firebase Functions",
      on: {
        // push: {
        //   branches: ['main'],
        // },
        workflow_dispatch: {
          inputs: {
            correlationId: {
              description: '"Correlation Id"',
              required: true
            }
          }
        }
      },
      env: {
        FASLH_API_URL: "https://us-central1-january-9f554.cloudfunctions.net/ghevents"
        // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
      },
      jobs: {
        deploy_to_firebase_functions: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v4"
            },
            {
              id: "cache",
              name: "Cache Or Restore Node Modules",
              uses: "actions/cache@v3",
              with: {
                path: "node_modules",
                key: "node-modules-${{ hashFiles('package-lock.json') }}"
              }
            },
            {
              id: "install_deps",
              name: "Install Deps",
              run: "npm install --no-audit --no-fund"
            },
            {
              id: "build",
              name: "Build",
              run: "npm run build:prod -- --entry ./src/firebase-functions.ts"
            },
            {
              id: "deploy",
              name: "Deploy to Firebase",
              uses: "w9jds/firebase-action@master",
              with: {
                args: "deploy --only functions --debug"
              },
              env: {
                GCP_SA_KEY: `\${{ secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY }}`,
                PROJECT_ID: `\${{ secrets.FIREBASE_FUNCTION_PROJECT_ID }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
};
var functions = {
  id: "firebase/functions",
  packages: {
    "firebase-functions": {
      version: "^5.0.1",
      dev: false
    },
    "firebase-admin": {
      version: "^12.4.0",
      dev: false
    }
  },
  files: {
    "../.github/workflows/deploy.yml": deployContent(),
    "server.ts": `
		import * as functions from 'firebase-functions';
		import application from './app';
		exports.api = functions.https.onRequest(application.callback());
		exports.hello = functions.https.onRequest((req, res) => {
			res.json({ result: 'Hello from Firebase!' });
		});
		`,
    "../firebase.json": toJson({
      functions: [
        {
          ignore: ["**/node_modules/**", "**/src/**", "**/public/**"],
          codebase: "faslh",
          source: "dist",
          runtime: "nodejs16"
        }
      ]
    })
  }
};
export {
  auth,
  functions
};
//# sourceMappingURL=index.js.map
