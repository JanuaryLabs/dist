export interface ExtensionPackage {
    name: string;
    version: string;
    dev?: boolean;
}
export interface ExtensionVM {
    id: string;
    name: string;
    main?: string;
    categories: string[];
    title: string;
    subtitle: string;
    description: string;
    logo?: string;
    visible?: boolean;
    metadata: FieldMetadata;
    tableMetadata?: FieldMetadata;
    svg: string;
    disabled?: boolean;
    packages?: ExtensionPackage[];
}
export type FieldMetadata = Record<string, _Field>;
export type FieldSourceArray = {
    displayName: string;
    id: string;
}[];
export type FieldSourceDynamic = {
    /**
     * Url to fetch data from. it shouldn't start with protocol
     *
     * @example
     * /tables
     * /tables/{current}/fields
     * /tables/:id/fields
     */
    url: string;
    /**
     * Bindings to pass to the url
     *
     * @example get fields from current table
     * /tables/{current}/fields
     *
     * @example get fields from specific table
     * /tables/:id/fields
     * bindings: {
     *  id: 'uuid-goes-here'
     * }
     */
    binding?: Record<string, string>;
    except?: string[];
};
export type FieldMetadataSource<T = NonNullable<unknown>> = FieldSourceArray | FieldSourceDynamic;
type _Field = {
    /**
     * Name that a user will see
     */
    displayName: string;
    /**
     * Field type to display on the UI
     */
    type: 'string' | 'json' | 'number' | 'single-select' | 'multi-select' | 'query-builder' | 'boolean' | 'columns-list' | 'columns-list-multiple' | string;
    /**
     * If the field should act as drop down, then populate this property
     *
     * you can use also with string type. the field then will be autocomplete
     */
    defaultValue?: string | number | boolean | string[];
    description?: string;
    /**
     * Where to fetch values for dropdown fields
     *
     */
    source?: FieldMetadataSource;
    required?: boolean;
    /**
     * List of regex patterns to validate the field
     */
    pattern?: string;
    /**
     * Is this field visible to the user
     */
    visible?: boolean;
    /**
     * If this field is a part of a group, then specify the group name here
     */
    fieldset?: string;
    extras?: Record<string, any>;
    validations?: any[];
};
export interface ExtensionValidation {
    id: string;
    extensionId: string;
    description: string;
    displayName: string;
    /**
     * Unique Validation Indentifier name
     */
    name: string;
    /**
     * Type of validation endswith | startswith | matches | regex | etc
     * type of validation is that will be performed on the field
     * @example
     * isArabic will use regex to validate the field
     */
    type: string;
    metadata: FieldMetadata;
}
export type ConditionLogic = {
    _kind: 'if';
    operator: 'equal' | 'not_equal';
    input: string;
    value: string;
    then: any;
    else: any;
};
export interface ExtensionFieldInitialValidation {
    /**
     * The value of the validation.
     * should reflect source validation metadata
     *
     * @example
     * // assume we have source validation as follows
     * {
     * "name": "required",
     * "displayName": "Required",
     * "metadata": {
     *  "value": {
     *    "type": "boolean",
     *    "default": true,
     *    "required": true,
     *    "displayName": "Required"
     *    }
     *  }
     * }
     *
     * // then the details should be
     * {
     *  "value": true, // or false
     * }
     *
     */
    details: Record<string, any>;
    name: string;
    /**
     * If this validation should be applied only if the condition is met.
     *
     * we added this because date/datetime fields are composed into 2 fields instead of 4
     *
     * operator: equals
     * input: field metadata name
     * value: user input
     *
     * @example
     * {
     *  "if": {
     *    "operator": 'equals',
     *    "input": 'nativeType',
     *    "value": 'timestamptz'
     *  }
     * }
     *
     * // that means if the field is a timestamptz then apply this validation
     */
    if?: ConditionLogic;
}
export interface ExtensionFieldOperator {
    details: Record<string, any>;
    name: string;
}
export type PrimitiveTypeName = string | (FieldSourceDynamic & {
    use: string;
});
export type PrimitiveTypeSource = string | ConditionLogic | {
    _kind: never;
    transformer: 'pascalcase';
    interface: FieldSourceDynamic;
    typeName: PrimitiveTypeName;
};
export interface ExtensionField {
    id: string;
    name: string;
    displayName: string;
    extensionId: string;
    references?: string;
    description: string;
    categories: string[];
    /**
     * The list of validations that are allowed for this field.
     *
     * visible will be used to force the validation on a validation.
     */
    allowedValidations: (string | {
        visible: boolean;
        name: string;
        required: boolean;
    })[];
    allowedOperators: ExtensionFieldOperator[];
    icon: string;
    primitiveType: PrimitiveTypeSource;
    metadata: FieldMetadata;
    initialValidation: Array<ExtensionFieldInitialValidation>;
}
export interface HandleFieldInput {
    sourceField: ExtensionField;
    details: Record<string, any>;
    displayName: string;
    validations: {
        details: Record<string, any>;
        name: string;
        sourceId: string;
    }[];
}
export {};
