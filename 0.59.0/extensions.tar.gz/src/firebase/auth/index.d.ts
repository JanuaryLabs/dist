import type { Extension } from '../../extension';
export declare function auth(): Extension;
