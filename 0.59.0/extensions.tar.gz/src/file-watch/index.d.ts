import type { Readable } from 'node:stream';
import { type TriggerDefinition } from '@january/declarative';
import type { Extension } from '../extension';
export declare const fileWatch: () => Extension;
declare module '@january/declarative' {
    interface Config {
        filePath: string;
        autoRestart?: boolean;
    }
    namespace trigger {
        interface HttpTrigger<M> {
        }
        function watchFile(config: Config): TriggerDefinition<[Readable, AbortController]>;
    }
}
