import type { Server } from '@tus/server';
import type { Context, Env } from 'hono';
import type { IncomingMessage } from 'http';
import type z from 'zod';
import { Policy, type TriggerDefinition } from '@january/declarative';
import type { Extension } from '../extension';
interface HonoOptions {
    useFeatureNameAsBasePath?: boolean;
}
export declare const honoDefaultOptions: HonoOptions;
export declare function hono(options?: HonoOptions): Extension;
declare module '@january/declarative' {
    namespace policy {
        function http<T extends Env>(policyFn: (context: Context<T>) => void): Policy;
    }
    namespace trigger {
        type Policies = Array<(context: Context) => Promise<boolean | void> | boolean | void>;
        type InferZodProp<T> = T extends {
            against: infer Against;
        } ? Against extends z.ZodType<any, any, any> ? z.infer<Against> : never : T;
        type Input<T> = {
            [K in keyof T]: InferZodProp<T[K]>;
        };
        interface SSETrigger {
            body: Record<string, any>;
            query: Record<string, string>;
            headers: Record<string, string>;
            path: Record<string, string>;
        }
        type HttpTriggerConfig<M> = {
            path: string;
            method: string;
            policies?: Policies;
            input?: (payload: HttpTriggerPayload) => M;
            output?: z.ZodObject<{}, 'strip', z.ZodTypeAny, {}, {}>;
        };
        interface HttpTriggerPayload {
            body: Record<string, any>;
            query: Record<string, string>;
            headers: Record<string, string>;
            path: Record<string, string>;
        }
        function tus(config: Omit<ConstructorParameters<typeof Server>[0], 'allowedCredentials' | 'allowedHeaders' | 'allowedMethods' | 'allowedOrigins' | 'respectForwardedHeaders' | 'relativeLocation'> & {
            policies?: Policies;
        }): TriggerDefinition<[
            {
                id: string;
                mimeType: string;
                size: string;
            },
            IncomingMessage
        ]>;
        function file(config: {
            path: string;
            root?: string;
            rewrite?: (path: string) => string;
            policies?: Policies;
        }): TriggerDefinition<[string]>;
        function stream<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
            {
                input: Input<M>;
                signal: AbortSignal;
            },
            IncomingMessage
        ]>;
        function sse(config: {
            path: string;
            policies?: Policies;
        }): TriggerDefinition<[{
            trigger: HttpTriggerPayload;
        }, IncomingMessage]>;
        function websocket(config: {
            topic: string;
            policies?: Policies;
        }): TriggerDefinition<[SSETrigger, IncomingMessage]>;
        interface HttpTrigger<M> {
            trigger: HttpTriggerPayload;
            input: Input<M>;
            output: trigger.http.output;
            signal: AbortSignal;
        }
        function http<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[HttpTrigger<M>, IncomingMessage]>;
    }
}
export {};
