import type { diagnostic } from '@january/sdk/parser';
import type { SqlQuery } from './query';
import { type UseField, type UseTable } from './table';
import type { ActionDefinition } from './workflow';
export declare function action<T>(transferable: string | ((trigger: T) => void), config?: {
    inline?: boolean;
    structures?: unknown[];
}): ActionDefinition;
export declare namespace action {
    export namespace core {
        function raw<T>(config: {
            code: string;
            inline: boolean;
        }): ActionDefinition;
        function branch(config: {
            paths: Record<string, string>;
        }): ActionDefinition;
    }
    export namespace unstable_discord {
        function send(config: {
            webhook: string;
            message: any;
        }): ActionDefinition<unknown>;
    }
    export namespace database {
        const list: typeof listRecord;
        const single: typeof singleRecord;
        const search: typeof searchRecords;
        const set: typeof setFields;
        const remove: typeof deleteRecord;
        const exists: typeof recordExists;
        const upsert: typeof upsertRecord;
        const increment: typeof incrementField;
        const decrement: typeof decrementField;
        function insert<Workflow>(config: {
            table: UseTable;
            columns: UseField[];
        }): ActionDefinition;
        namespace insert {
            var rule: ({ node }: {
                parent: unknown;
                node: unknown;
            }, service: import("@january/evaluator").RuleService) => diagnostic.Diagnostic[];
        }
        function sql<T>(config: {
            query: string;
        }): ActionDefinition;
    }
    function incrementField(config: {
        table: UseTable;
        field: UseField;
        query?: SqlQuery;
    }): ActionDefinition;
    function decrementField(config: {
        table: UseTable;
        field: UseField;
        query?: SqlQuery;
    }): ActionDefinition;
    export type ListRecordConfig = {
        pagination?: 'limit_offset' | 'deferred_joins' | 'cursor' | 'none';
        table: UseTable;
        query?: SqlQuery;
        limit?: number;
    };
    export type ListRecordOutput = {
        meta: Record<string, unknown>;
        records: unknown[];
    };
    export type SingleRecordOutput = Record<string, any>;
    function listRecord(config: ListRecordConfig): ActionDefinition<ListRecordOutput>;
    function searchRecords(config: {
        table: UseTable;
        fields: UseField[];
        queryTerm?: string;
        pagination?: 'limit_offset' | 'deferred_joins' | 'cursor' | 'none';
        limit?: number;
    }): ActionDefinition;
    namespace searchRecords {
        var rule: () => diagnostic.Diagnostic[];
    }
    function singleRecord(config: {
        table: UseTable;
        query: SqlQuery;
    }): ActionDefinition;
    namespace singleRecord {
        var rule: () => diagnostic.Diagnostic[];
    }
    function upsertRecord(config: {
        table: UseTable;
        conflictFields?: UseField[];
        columns: UseField[];
    }): ActionDefinition;
    function setFields(config: {
        table: UseTable;
        columns: UseField[];
        query: SqlQuery;
    }): ActionDefinition;
    namespace setFields {
        var rule: () => diagnostic.Diagnostic[];
    }
    function deleteRecord(config: {
        table: UseTable;
        query: SqlQuery;
    }): ActionDefinition;
    namespace deleteRecord {
        var rule: () => diagnostic.Diagnostic[];
    }
    function recordExists(config: {
        table: UseTable;
        query: SqlQuery;
    }): ActionDefinition;
    namespace recordExists {
        var rule: () => diagnostic.Diagnostic[];
    }
    export {};
}
export declare namespace action {
    function fromConfig(type: string, ...args: unknown[]): ActionDefinition;
    namespace googleCloudStorage {
        function uploadSingle(config: {
            maxFileSize?: number;
            types?: string[];
        }): ActionDefinition<unknown>;
        namespace uploadSingle {
            var rule: () => diagnostic.Diagnostic[];
        }
    }
}
export declare namespace action {
    namespace resend {
        function sendEmail(config: {
            to: string;
            subject: string;
            from: string;
            html: string;
        }): ActionDefinition<unknown>;
        namespace sendEmail {
            var rule: () => diagnostic.Diagnostic[];
        }
        function createContact(config: {
            email: string;
            firstName: string;
            audienceId: string;
        }): ActionDefinition<unknown>;
        namespace createContact {
            var rule: () => diagnostic.Diagnostic[];
        }
    }
    function openai(): void;
    namespace openai {
    }
}
