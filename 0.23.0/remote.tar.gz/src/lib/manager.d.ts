export declare function createRemoteServer(projectId: string, processImage: () => Promise<string>, env?: Record<string, string>, restartContainer?: boolean, instructions?: {
    internalPort?: number;
    Healthcheck?: Record<string, any>;
    hostPort?: string;
}): Promise<string>;
export declare function liveness(projectUrl: string): Promise<void>;
