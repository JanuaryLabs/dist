import tarStream from 'tar-stream';
import type { BundableFile } from '@january/generator/bundler';
export declare function buildRunnerImage(distDir: string, baseTag: string, runTag: string): Promise<unknown>;
export declare function createTar(files: BundableFile[]): tarStream.Pack;
export declare function getRunnerDockerfile(imageName: string): string;
