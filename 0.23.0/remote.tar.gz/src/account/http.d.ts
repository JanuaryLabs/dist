export declare function get(path: string, config?: {
    withAuth?: boolean;
    headers?: Record<string, string | undefined>;
    baseUrl?: string;
}): Promise<{
    data: any;
    error?: undefined;
} | {
    error: unknown;
    data?: undefined;
}>;
export declare function put(path: string, data: Record<string, unknown>): Promise<{
    data: any;
    error?: undefined;
} | {
    error: unknown;
    data?: undefined;
}>;
export declare function patch<T extends Record<string, unknown>>(path: string, data: T, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
    headers?: Record<string, string | undefined>;
    baseUrl?: string;
}): Promise<{
    data: any;
    error?: undefined;
} | {
    error: unknown;
    data?: undefined;
}>;
export declare function post<T extends Record<string, unknown>>(path: string, data: T, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
    headers?: Record<string, string | undefined>;
    baseUrl?: string;
}): Promise<{
    data: any;
    error?: undefined;
} | {
    error: unknown;
    data?: undefined;
}>;
export declare function request<T extends Record<string, unknown>>(path: string, method: 'GET' | 'POST' | 'PUT' | 'DELETE', data: T, init?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
    headers: Record<string, string | undefined>;
}): Promise<Response | {
    error: unknown;
}>;
export declare function remove(path: string, data: Record<string, unknown>): Promise<{
    data: any;
    error?: undefined;
} | {
    error: unknown;
    data?: undefined;
}>;
