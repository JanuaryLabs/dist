#!/usr/bin/env node
import { createRequire } from 'module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/sdk/parser/src/index.ts
var src_exports = {};
__export(src_exports, {
  Checker: () => Checker,
  checker: () => checker,
  getExports: () => getExports,
  legacy_parse: () => legacy_parse,
  parse: () => parse,
  parseCode: () => parseCode,
  resolveCallExpression: () => resolveCallExpression
});
import { readFileSync } from "fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node2, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node2.expression)) {
    args.push(null);
  }
  if (node2.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node2.expression.span.start + 1,
        // remove start `
        node2.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node2.expression)) {
    args.push(node2.expression.value);
  }
  if (checker.isIdentifier(node2.expression)) {
    args.push(node2.expression.value);
  }
  if (checker.isObjectExpression(node2.expression)) {
    args.push(resolveObjectExpression(node2.expression, sourceCode));
  }
  if (checker.isCallExpression(node2.expression)) {
    args.push(resolveCallExpression(node2.expression, sourceCode));
  }
  if (checker.isMemberExpression(node2.expression)) {
    args.push(resolveMemberExpression(node2.expression, []).join("."));
  }
  if (node2.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node2.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node2, sourceCode) {
  const args = [];
  for (const arg of node2.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node2.callee)) {
    const [...actionPath] = resolveMemberExpression(node2.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node2.callee)) {
    calleeName = node2.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node2.span
  };
}
function resolveUnaryExpression(node2) {
  if (node2.argument.type === "NumericLiteral") {
    return Number(`${node2.operator}${node2.argument.value}`);
  }
  return `${node2.operator}${node2.argument.value}`;
}
function resolveArrayExpression(node2, sourceCode) {
  const list4 = [];
  for (const arg of node2.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list4.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list4.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list4.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list4.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list4.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list4.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list4;
}
function resolveObjectExpression(node2, sourceCode) {
  const obj = {};
  for (const prop of node2.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node2, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node2.object)) {
    collection.push(node2.object.value);
  }
  if (checker.isMemberExpression(node2.object)) {
    collection.push(...resolveMemberExpression(node2.object, acc));
  }
  if (checker.isIdentifier(node2.property)) {
    collection.push(node2.property.value);
  }
  return collection;
}
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
async function getExports(code) {
  const ast = await parseCode(code);
  if (!ast) {
    return [];
  }
  return ast.body.filter(isExportItem);
}
var checker, Checker, isWorker, exportTypes;
var init_src = __esm({
  "libs/sdk/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node2, name) {
        if (!node2) {
          return false;
        }
        const isCallExpr = node2.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node2.callee.type === "MemberExpression") {
          return node2.callee.property.type === "Identifier" && node2.callee.property.value === name;
        }
        return node2.callee.type === "Identifier" && node2.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(node2) {
        return node2.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isKeyValueProperty(node2, valueType, keyName) {
        if (node2.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node2.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node2.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      __name(isKeyValueProperty, "isKeyValueProperty");
      function isNullLiteral(node2) {
        return node2.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      __name(isNullLiteral, "isNullLiteral");
      function isPrimitive(node2) {
        if (node2.type === "StringLiteral" || node2.type === "BooleanLiteral" || node2.type === "NumericLiteral" || node2.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isIdentifier(node2, name) {
        if (!node2) {
          return false;
        }
        const isIdentifier2 = node2.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node2.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      __name(isIdentifier, "isIdentifier");
      function isMemberExpression(node2, name) {
        if (!node2) {
          return false;
        }
        const isMemberExpr = node2.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node2.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      __name(isMemberExpression, "isMemberExpression");
      function isArrayExpression(node2) {
        return node2.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(Checker || (Checker = {}));
    isWorker = /* @__PURE__ */ __name(() => {
      return typeof global.importScripts === "function";
    }, "isWorker");
    __name(isRecord, "isRecord");
    __name(isSpan, "isSpan");
    __name(adjustOffsetOfAst, "adjustOffsetOfAst");
    __name(parseCode, "parseCode");
    __name(legacy_parse, "legacy_parse");
    __name(parse, "parse");
    __name(getImports, "getImports");
    __name(resolveAsExpression, "resolveAsExpression");
    __name(resolveCallExpression, "resolveCallExpression");
    __name(resolveUnaryExpression, "resolveUnaryExpression");
    __name(resolveArrayExpression, "resolveArrayExpression");
    __name(resolveObjectExpression, "resolveObjectExpression");
    __name(resolveMemberExpression, "resolveMemberExpression");
    exportTypes = [
      "ExportAllDeclaration",
      "ExportDeclaration",
      "ExportDefaultDeclaration",
      "ExportDefaultExpression",
      "ExportNamedDeclaration",
      "ImportDeclaration"
    ];
    __name(isExportItem, "isExportItem");
    __name(getExports, "getExports");
  }
});

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index2, item] = byId(array, id);
  if (item) {
    array[index2] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index2, item] = byId(array, id);
  if (item) {
    array[index2] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index2 = array.findIndex((it) => it.id === id);
  return [index2, array[index2]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input5 = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input5 === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input5 !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve2, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve2(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config2) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config2.accessor(item)]: config2.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms2) {
  return new Promise((resolve2) => setTimeout(resolve2, ms2));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config2) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config2.featureName),
        snakecase(config2.workflowTag),
        toCurlyBraces(config2.workflowPath)
      )
    )
  );
  return config2.workflowMethod ? `${config2.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer2 = new Promise((resolve2, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve2(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer2;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node2) {
    return node2.value;
  }
  async visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    const where2 = node2.args.map((arg) => arg.accept(this)).join(", ");
    return `${node2.name.accept(this)} WHERE id = ${where2}`;
  }
  visitNamespace(node2) {
    if (node2.name.value === "tables") {
      return `SELECT ${node2.expression.accept(this)}`;
    }
    return `'${node2.toLiteral(this)}'`;
  }
  visitPropertyAccess(node2) {
    return `${node2.expression.accept(this)} FROM ${node2.name.accept(this)}`;
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toSqlite(input5) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input5));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    const where2 = node2.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node2.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where2,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node2) {
    return `.select('${node2.expression.accept(this)}')${node2.name.accept(
      this
    )}`;
  }
  visitNamespace(node2) {
    if (node2.name.value === "tables") {
      return `qb${node2.expression.accept(this)}`;
    }
    return `'${node2.toLiteral(this)}'`;
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toTypeorm(input5) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input5));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    return node2.toLiteral(this);
  }
  visitPropertyAccess(node2) {
    return node2.toLiteral(this);
  }
  visitNamespace(node2) {
    return {
      namespace: node2.name.value,
      value: node2.expression.accept(this)
    };
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toSimple(input5) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input5));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input5) {
  let index2 = 0;
  const tokens = [];
  let lexeme = "";
  while (index2 < input5.length) {
    const char = input5[index2];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "!":
        if (input5[index2 + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index2
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index2
          });
          index2 += 2;
        } else {
          lexeme += char;
          index2++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index2
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "'":
      case '"':
        {
          index2++;
          while (input5[index2] !== "'" && input5[index2] !== '"') {
            lexeme += input5[index2];
            index2++;
          }
          index2++;
          const column = index2;
          if (input5[index2] === "]") {
            lexeme += input5[index2];
            index2++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index2
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index2
        });
        index2++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        index2++;
        break;
      default:
        lexeme += char;
        index2++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input5) {
  return toSimple(input5);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input5) {
    super(tokeniser(input5));
    this.input = input5;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index: index2 } = parser.subparse();
    this.currentIdx += index2;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input5) {
  const parser = new DSLParser(input5);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index2) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index2 + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index2) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index2 + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index2) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index2;
    });
    return lexeme;
  }
  replaceLexeme(index2, value) {
    const lexeme = this.nearestLexeme(index2);
    console.log({ lexeme, index: index2 });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index2 = 0;
  const lexemes = [];
  while (index2 < prompt.length) {
    const char = prompt[index2];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index2++],
          column: index2
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index2++],
          column: index2
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index2
          };
          token.value += char;
          index2++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node2) {
    const name = node2.name.accept(this);
    if (typeChecker.isNamespace(node2.value)) {
      const value2 = node2.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node2.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node2) {
    const left = node2.left.accept(this);
    const right = node2.right.accept(this);
  }
  visitCall(node2) {
    const name = node2.name.accept(this);
    const args = node2.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node2) {
    return `${node2.name.accept(this)}.${node2.expression.accept(this)}`;
  }
  visitNamespace(node2) {
    const id = v4();
    const name = `@${node2.name.accept(this)}:${node2.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    node2.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input5) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input5));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
var colors2 = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 0.85,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
__name(box, "box");
box.print = function(title, ...lines) {
  console.log(box(title, ...lines.map((it) => it.trimEnd())));
};
function network(port = process.env["PORT"]) {
  console.log(
    box(
      "Server",
      `\u2139 Localhost: http://localhost:${port}`,
      `\u2714 Network IP: http://${ip.address()}:${port}`,
      `\u26A0 Note: Ensure the requesting device connected on the same network`
    )
  );
}
__name(network, "network");
var pretty = {
  network,
  box,
  swagger: /* @__PURE__ */ __name(async (pattern, cwd = import.meta.dirname) => {
    const swaggerFiles = await glob(pattern, {
      cwd
    });
    const swaggerEndpoints = swaggerFiles.map((x) => x.split(".swagger.json").shift()).map((it) => `/${it}/swagger`);
    console.log(box("Swagger Docs", ...swaggerEndpoints));
  }, "swagger")
};

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  __name(whatIsParserImport, "whatIsParserImport");
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}
__name(formatCode, "formatCode");

// libs/compiler/generator/utils/src/index.ts
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toVirtualFile(it) {
  const parts = it.path.split("/").filter(Boolean);
  const fileName = parts.at(-1);
  return {
    isFolder: false,
    name: it.path.split("/").pop() || "unknown",
    path: parts.join("/"),
    extension: getExt(fileName),
    content: it.content,
    metadata: {
      path: it.path
    }
  };
}
__name(toVirtualFile, "toVirtualFile");
function mapFilesToTree(files) {
  function toTree(parts, tree, content) {
    const [part, ...rest] = parts;
    if (rest.length === 0) {
      return {
        ...tree,
        [part]: content
      };
    }
    return {
      ...tree,
      [part]: toTree(rest, tree[part] || {}, content)
    };
  }
  __name(toTree, "toTree");
  return files.reduce((acc, it) => {
    const parts = it.path.split("/").filter(Boolean);
    return toTree(parts, acc, it.content);
  }, {});
}
__name(mapFilesToTree, "mapFilesToTree");
function mapFilesToTreeNodes(files) {
  const tree = mapFilesToTree(files);
  function toTreeNodes(tree2, path = []) {
    return Object.entries(tree2).map(([name, value]) => {
      const newPath = [...path, name];
      if (typeof value === "string") {
        return {
          id: newPath.join("/"),
          name,
          path: newPath.join("/"),
          metadata: {
            path: newPath.join("/")
          }
        };
      }
      return {
        id: newPath.join("/"),
        name,
        children: toTreeNodes(value, newPath),
        metadata: {
          path: newPath.join("/")
        }
      };
    }).sort((a, b) => "children" in a ? -1 : 1);
  }
  __name(toTreeNodes, "toTreeNodes");
  return toTreeNodes(tree);
}
__name(mapFilesToTreeNodes, "mapFilesToTreeNodes");
function getFile(list4, path) {
  const file2 = list4.find(
    (it) => JSON.stringify(it.path.split("/").filter(Boolean)) === JSON.stringify(path.split("/").filter(Boolean))
  );
  if (!file2) {
    throw new Error(`File not found: ${path}`);
  }
  return file2;
}
__name(getFile, "getFile");
function emptyFile(file2 = {}) {
  return {
    isFolder: false,
    name: "unknown",
    extension: "",
    content: "",
    path: "",
    ...file2
  };
}
__name(emptyFile, "emptyFile");

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";
var BrowserLookupFs = class {
  static {
    __name(this, "BrowserLookupFs");
  }
  #lookupModules = /* @__PURE__ */ new Set();
  exists(path) {
    return localforage.getItem(path).then((item) => !!item).catch(() => false);
  }
  moduleExists(sourceData) {
    return this.exists(`package:${sourceData.package}`);
  }
  getFiles(sourceData) {
    return localforage.getItem(`files:${sourceData.package}`).then((files) => files || []).catch(() => []);
  }
  getFileContent(path) {
    return localforage.getItem(path).then((item) => item);
  }
  getPackageJson(sourceData) {
    return localforage.getItem(`package:${sourceData.package}`).then((item) => item);
  }
  mapFiles(files) {
    return files.map((file2) => ({
      originalFile: file2,
      relativeFile: file2
    }));
  }
  lock(source) {
    this.#lookupModules.add(source);
  }
  isLocked(source) {
    return this.#lookupModules.has(source);
  }
};

// libs/playground/package-installer/src/lib/parser.ts
import { dirname as dirname2, join as join2 } from "path";
function coercePackageJson(packageJson) {
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.peerDependencies = packageJson.peerDependencies || {};
  return packageJson;
}
__name(coercePackageJson, "coercePackageJson");
function makeFileUri(specifier, fileName) {
  return `file:///node_modules/${specifier}/${fileName}`;
}
__name(makeFileUri, "makeFileUri");
function parseSpecifer(specifier) {
  const [moduleName, version] = specifier.split("@").filter(Boolean);
  return {
    moduleName,
    version: version === "*" ? "latest" : version
  };
}
__name(parseSpecifer, "parseSpecifer");
function normalizeImport(typesUrl, relativeImport) {
  const url = new URL(typesUrl);
  const relativeImportPathname = join2(dirname2(url.pathname), relativeImport);
  return new URL(relativeImportPathname, url.origin).href;
}
__name(normalizeImport, "normalizeImport");
function cleanText(text) {
  return text.replace("export {}", "").replaceAll("export function", "export declare function").replaceAll("export const", "export declare const");
}
__name(cleanText, "cleanText");
async function fetchDts(typesUrl) {
  const result = {
    error: false,
    loaded: false,
    text: ""
  };
  try {
    const response = await fetch(typesUrl);
    if (response.ok) {
      const text = await response.text();
      if (text.includes("[Package Error]")) {
        throw new Error("Package Error");
      }
      result.text = cleanText(text);
      result.loaded = true;
    } else {
      result.error = true;
    }
  } catch (error) {
    result.error = true;
    result.loaded = false;
  }
  return result;
}
__name(fetchDts, "fetchDts");
function parseSource(source) {
  let index2 = 0;
  const tokens = [];
  while (index2 < source.length) {
    switch (source[index2]) {
      case "@":
        {
          let subindex = index2 + 1;
          while (subindex < source.length && source[subindex] !== "/") {
            subindex++;
          }
          tokens.push({
            type: "at",
            value: source.slice(index2 + 1, subindex)
          });
          index2 = subindex;
        }
        break;
      default:
        {
          let lastToken = tokens[tokens.length - 1];
          if (!lastToken || lastToken.type !== "string") {
            lastToken = {
              type: "string",
              value: ""
            };
            tokens.push(lastToken);
          }
          lastToken.value += source[index2];
          index2++;
        }
        break;
    }
  }
  if (tokens[0].type === "at") {
    tokens[0].type = "scope";
    tokens[1].type = "package";
    if (tokens[2]) {
      tokens[2].type = "version";
    }
  }
  if (tokens[0].type === "string") {
    tokens[0].type = "package";
    if (tokens[1]) {
      tokens[1].type = "version";
    }
  }
  const moduleName = (tokens.find((x) => x.type === "package")?.value || "").replace("/", "");
  const version = tokens.find((x) => x.type === "version")?.value || "latest";
  const scope = tokens.find((x) => x.type === "scope")?.value;
  const file2 = tokens.find((x) => x.type === "string")?.value;
  return {
    moduleName,
    version,
    scope,
    package: `${scope ? `@${scope}/` : ""}${moduleName}`,
    full: `${scope ? `@${scope}/` : ""}${moduleName}@${version}`,
    file: file2
  };
}
__name(parseSource, "parseSource");
function sourceDataToString(source) {
  return `${source.scope ? `${source.scope}/` : ""}${source.moduleName}@${source.version}`;
}
__name(sourceDataToString, "sourceDataToString");

// libs/playground/package-installer/src/lib/deps-install-manager.ts
import { basename, dirname as dirname3, extname, join as join3, relative } from "path";
var PackageExports = class {
  constructor(pkg) {
    this.pkg = pkg;
  }
  static {
    __name(this, "PackageExports");
  }
  #extractTypes(exportConfig) {
    if (Array.isArray(exportConfig)) {
      return this.#extractTypes(
        exportConfig.filter((it) => typeof it === "string")[0]
      );
    }
    if (typeof exportConfig === "object") {
      if (typeof exportConfig?.types === "string") {
        return this.#extractTypes(exportConfig.types);
      }
      if (typeof exportConfig?.default === "string") {
        return this.#extractTypes(exportConfig?.default);
      }
    }
    if (typeof exportConfig === "string") {
      return fixTypeExportName(exportConfig);
    }
    return null;
  }
  #correctEndpoint(endpoint) {
    if (typeof endpoint === "string") {
      return fixTypeExportName(endpoint);
    }
    return this.#extractTypes(endpoint);
  }
  #tryFiles(index2) {
    if (!index2.endsWith("index.d.ts")) {
      return this.pkg.files?.find((it) => it.endsWith("index.d.ts")) || index2;
    }
    return index2;
  }
  formatExports() {
    const exports = this.mainExport();
    const deleteKeys = [
      (it) => it.includes("*"),
      (it) => it.includes("production"),
      (it) => it.includes("development"),
      (it) => it.includes("package.json"),
      (it) => it.includes("default"),
      (it) => it.includes("require"),
      (it) => it.includes("import"),
      (it) => it === ".",
      (it) => it === "./",
      (it) => it === "/"
    ];
    const cleanedExports = Object.fromEntries(
      Object.entries(this.pkg.exports).filter(
        ([endpoint]) => !deleteKeys.some((x) => x(endpoint))
      )
    );
    const formattedEndpoints = Object.fromEntries(
      Object.entries(cleanedExports).map(([endpoint, exports2]) => [
        endpoint,
        {
          types: this.#correctEndpoint(exports2) || // use the endpoint as the type as last resort
          fixTypeExportName(endpoint)
        }
      ])
    );
    return {
      ...exports,
      ...formattedEndpoints
    };
  }
  mainExport() {
    if (!this.pkg.exports) {
      return {
        ".": {
          types: this.#tryFiles(
            fixTypeExportName(
              this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
            )
          )
        }
      };
    }
    if (typeof this.pkg.exports === "string") {
      return {
        ".": {
          types: this.#tryFiles(fixTypeExportName(this.pkg.exports))
        }
      };
    }
    return {
      ".": {
        types: this.#correctEndpoint(this.pkg.exports["."]) || this.#tryFiles(
          fixTypeExportName(
            this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
          )
        )
      }
    };
  }
};
var nodeTypes = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
var Resolver = class {
  constructor(pkgKeeper, keeper, registries) {
    this.pkgKeeper = pkgKeeper;
    this.keeper = keeper;
    this.registries = registries;
  }
  static {
    __name(this, "Resolver");
  }
  async resolve(source) {
    if (nodeTypes.includes(source) || nodeTypes.some((it) => `node:${it}` === source) || nodeTypes.includes(`node:${source}`) || source.startsWith("@extensions")) {
      return null;
    }
    console.log("Resolving => ", source);
    const info = {
      deps: []
    };
    const resolutions$ = [];
    const pkg = await this.#packageJson(source).catch((error) => null);
    if (pkg === null) {
      console.log(`Resolution stopped: package.json not found for ${source}`);
      return null;
    }
    if (!pkg) {
      console.log(`Resolution stopped: missing package.json for ${source}`);
      return null;
    }
    const sourceData = parseSource(source);
    if (sourceData.version === "latest") {
      source = sourceDataToString({
        ...sourceData,
        version: pkg.version
      });
    }
    const recorder = createRecorder({ label: source });
    for (const [specifier, version] of [
      ...Object.entries(pkg.dependencies ?? {}),
      ...Object.entries(pkg.peerDependencies ?? {})
    ]) {
      const source2 = `${specifier}@${version}`;
      resolutions$.push(async () => {
        info.deps.push(await this.resolve(source2));
      });
    }
    const endpoints = [];
    for (const [secondaryEndpoint, exportedModule] of Object.entries(
      pkg.exports
    )) {
      resolutions$.push(async () => {
        const secondaryEndpointSource = join3(source, secondaryEndpoint);
        console.log("Resolving secondary", secondaryEndpointSource);
        await this.#fetch(
          secondaryEndpointSource,
          join3(source, exportedModule.types)
        ).then((r) => {
          if (secondaryEndpoint === "." && r.loaded) {
            info.resolved = true;
          }
        });
        endpoints.push({
          source: secondaryEndpointSource,
          typePath: exportedModule.types,
          typeSource: join3(source, exportedModule.types),
          name: secondaryEndpoint
        });
      });
    }
    info.source = source;
    info.endpoints = endpoints;
    await Promise.all(
      resolutions$.map(
        (it) => it()
        //   .catch((error) => {
        //   console.error(error);
        //   throw error;
        // }),
        //   .catch((error) => {
        //   console.log(`Failed to resolve ${source} due to`);
        //   console.error(error);
        // }),
      )
    );
    recorder.end();
    console.log("Resolved", source);
    return info;
  }
  async #resolveRelativeImports(fileContent, source) {
    const exports = await getFileExports(
      fileContent.replaceAll("export const", "declare const")
    );
    const types$ = exports.map(async (exportSepecifier) => {
      const maybeDeps = !exportSepecifier.startsWith(".");
      if (maybeDeps) {
        console.log("Resolving relative deps", exportSepecifier);
        const isDeps = await this.resolve(exportSepecifier).catch(() => null);
        if (isDeps?.resolved) {
          return null;
        }
      }
      console.log("Resolving relative file", exportSepecifier);
      const relativeExportSource = join3(source, exportSepecifier);
      const relativeExportTypeExport = fixTypeExportName(relativeExportSource);
      const entry = await this.#entry(relativeExportSource);
      entry.path = exportSepecifier;
      if (entry.loaded) {
        return null;
      }
      if (entry.error || entry.loading) {
        return null;
      }
      return this.#fetch(relativeExportSource, relativeExportTypeExport);
    });
    return Promise.all(types$);
  }
  async #fetch(source, typeExport) {
    const entry = await this.#entry(source);
    if (entry.loaded) {
      console.log(`Already loaded ${source}`);
      return entry;
    }
    if (entry.error) {
      console.log(`Already errored ${source}`);
      return entry;
    }
    if (entry.loading) {
      console.log(`Already loading ${source}`);
      return entry;
    }
    entry.loading = true;
    entry.loaded = false;
    const registries = this.registries.slice(0);
    while (!entry.loaded) {
      const registry = registries.shift();
      if (!registry) {
        break;
      }
      const result = await registry.resolve(typeExport);
      if (result.loaded) {
        entry.loaded = true;
        entry.text = result.text;
        await this.keeper.set(source, entry);
        break;
      }
    }
    entry.typeExport = typeExport;
    entry.loading = false;
    if (entry.loaded) {
      const entries = await this.#resolveRelativeImports(
        entry.text,
        dirname3(typeExport)
      );
      entry.related = entries.filter(notNullOrUndefined);
    }
    entry.error = entry.loaded === false;
    return entry;
  }
  async #packageJson(source) {
    let pkg = await this.pkgKeeper.get(source).catch((error) => {
      console.error(error);
      return null;
    });
    if (pkg === null) {
      console.log(`Using cached package ${source}`);
      return pkg;
    }
    if (!pkg) {
      const registries = this.registries.slice(0);
      while (!pkg) {
        const registry = registries.shift();
        if (!registry) {
          break;
        }
        pkg = await registry.packageJson(source).catch(() => null);
      }
      await this.pkgKeeper.set(source, pkg || null);
    }
    if (!pkg) {
      throw new Error(`Failed to resolve package ${source}`);
    }
    pkg.dependencies = pkg.dependencies || {};
    pkg.devDependencies = pkg.devDependencies || {};
    pkg.peerDependencies = pkg.peerDependencies || {};
    const packageExports = new PackageExports(pkg);
    pkg.exports = packageExports.formatExports();
    pkg.dependencies = Object.fromEntries(
      Object.entries(pkg.dependencies).map(([specifier, version]) => {
        if (pkg.devDependencies && pkg.devDependencies[`@types/${specifier}`]) {
          return [
            `@types/${specifier}`,
            pkg.devDependencies[`@types/${specifier}`]
          ];
        }
        return [specifier, version];
      })
    );
    return pkg;
  }
  async #entry(source) {
    const inCache = await this.keeper.get(source);
    if (inCache) {
      return inCache;
    }
    const entry = {
      loaded: false,
      source,
      text: "",
      loading: false,
      typeExport: "",
      related: [],
      path: ""
    };
    return entry;
  }
  async #flatEntry(entry, basePath, seed) {
    for (const endpointEntry of (await this.#entry(entry.source)).related) {
      if (!endpointEntry.loaded) {
        continue;
      }
      seed.push({
        path: join3(
          dirname3(
            join3(
              basePath,
              relative(dirname3(entry.typeSource), endpointEntry.source)
            )
          ),
          basename(endpointEntry.typeExport)
        ),
        content: endpointEntry.text,
        loaded: endpointEntry.loaded
      });
      for (const nestedEntry of endpointEntry.related) {
        seed.push({
          path: join3(
            dirname3(
              join3(
                basePath,
                relative(dirname3(entry.typeSource), nestedEntry.source)
              )
            ),
            basename(nestedEntry.typeExport)
          ),
          content: nestedEntry.text,
          loaded: nestedEntry.loaded
        });
        await this.#flatEntry(
          {
            source: nestedEntry.source,
            typeSource: nestedEntry.typeExport
          },
          join3(basePath, nestedEntry.path),
          seed
        );
      }
    }
  }
  async flatten(info, basePath, seed) {
    for (const endpoint of info.endpoints) {
      const secondaryPath = join3(basePath, endpoint.name);
      await this.#flatEntry(endpoint, secondaryPath, seed);
      const entry = await this.#entry(endpoint.source);
      seed.push({
        path: join3(secondaryPath, basename(endpoint.typePath)),
        content: entry.text,
        loaded: entry.loaded
      });
    }
    for (const deps10 of info.deps) {
      if (!deps10) {
        continue;
      }
      const depsSourceData = parseSource(deps10.source);
      await this.flatten(
        deps10,
        join3(basePath, "node_modules", depsSourceData.package),
        seed
      );
    }
  }
};
async function getFileExports(content) {
  const isNodejs = typeof process !== "undefined";
  const exports = isNodejs ? await Promise.resolve().then(() => (init_src(), src_exports)).then(
    ({ getExports: getExports2 }) => getExports2(content)
  ) : await runWorker("/morph/parser.worker.js", {
    type: "getExports",
    payload: content
  });
  return removeDuplicates(
    exports.filter(
      (it) => it.type === "ExportAllDeclaration" || it.type === "ExportNamedDeclaration" || it.type === "ImportDeclaration"
    ).map((it) => it.source?.value).filter(notNullOrUndefined),
    (it) => it
  );
}
__name(getFileExports, "getFileExports");
function fixTypeExportName(name) {
  if (extname(name)) {
    name = name.replace(".d.ts", "").replace(".ts", "").replace(".js", "");
  }
  return `${name}.d.ts`;
}
__name(fixTypeExportName, "fixTypeExportName");

// libs/modern/src/lib/module-lookup.ts
var nodeTypes2 = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
async function lookupModule(source, fs, options) {
  const sourceData = parseSource(source);
  if (nodeTypes2.includes(sourceData.package) || nodeTypes2.some((it) => `node:${it}` === sourceData.package) || nodeTypes2.includes(`node:${sourceData.package}`) || source.startsWith("@extensions")) {
    console.log(`Source ${source} is a node type`);
    return;
  }
  if (fs.isLocked(source)) {
    return;
  }
  fs.lock(source);
  if (!await fs.moduleExists(sourceData)) {
    console.log(`Source ${source} not found`);
    const installed = await options.onMissingPackage(source, sourceData);
    if (!installed) {
      return;
    }
  }
  const packageJson = await fs.getPackageJson(sourceData);
  const files = await fs.getFiles(sourceData);
  await options.onFiles(sourceData, packageJson, files);
  await options.onPackageJson(sourceData, packageJson);
  await lookupPackage(packageJson, fs, options);
}
__name(lookupModule, "lookupModule");
async function lookupPackage(packageJson, fs, options) {
  coercePackageJson(packageJson);
  for (const depKey of ["dependencies", "peerDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      await lookupModule(depsName, fs, options);
    }
  }
  for (const depKey of ["devDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      if (depsName.startsWith("@types/")) {
        await lookupModule(depsName, fs, options);
      }
    }
  }
}
__name(lookupPackage, "lookupPackage");

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";
var octokit = /* @__PURE__ */ __name((token) => import("@octokit/core").then(({ Octokit }) => new Octokit({ auth: token })), "octokit");
async function generateKey() {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.crypto_secretbox_keygen();
}
__name(generateKey, "generateKey");
async function encrypt(key, plain) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const secret = sodium.crypto_secretbox_easy(
    plain,
    nonce,
    new Uint8Array(key)
  );
  return {
    secret,
    nonce
  };
}
__name(encrypt, "encrypt");
async function decrypt(secret, nonce, key) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.to_string(
    sodium.crypto_secretbox_open_easy(secret, nonce, key)
  );
}
__name(decrypt, "decrypt");
async function createEmptySecret(token, repositoryName, name) {
  const [owner, repo] = repositoryName.split("/");
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  try {
    await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
      owner,
      repo,
      secret_name: name
    });
    return;
  } catch (error) {
    const _error = error;
    if ("documentation_url" in _error) {
      if (_error.status !== 404) {
        throw error;
      }
    }
  }
  const key = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/public-key", {
    owner,
    repo
  });
  const binkey = sodium.from_base64(
    key.data.key,
    sodium.base64_variants.ORIGINAL
  );
  const binsec = sodium.from_string(" ");
  const encBytes = sodium.crypto_box_seal(binsec, binkey);
  const output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  await (await octokit(token)).request("PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
    owner,
    repo,
    secret_name: name,
    encrypted_value: output,
    key_id: key.data.key_id
  });
}
__name(createEmptySecret, "createEmptySecret");
async function createRepoistory(token, repositoryName, organizationId, workspaceId, projectId) {
  try {
    const result = await (await octokit(token)).request("POST /user/repos", {
      name: repositoryName,
      description: "January generated repository.",
      gitignore_template: "Node",
      private: true,
      auto_init: false,
      request: {
        projectId
      },
      homepage: "https://january.sh"
      // TODO: it should be user server or user local development server (january ones)
    });
    return {
      id: result.data.id,
      name: result.data.full_name
    };
  } catch (error) {
    if (error?.response?.data) {
      const _error = error.response;
      const [firstError] = _error.errors ?? [];
      if (firstError && firstError.code === "custom" && firstError.field === "name") {
        throw new Error(
          "Repository already exists on this account. Please change the project name and try again."
        );
      }
    }
    throw error;
  }
}
__name(createRepoistory, "createRepoistory");
async function triggerDeploy(token, repositoryName, inputs = {}) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request(
    "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
    {
      owner,
      repo,
      // TODO: we should get the installed hosting extension and get the workflow id from it
      workflow_id: "deploy.yml",
      ref: "main",
      inputs
    }
  );
}
__name(triggerDeploy, "triggerDeploy");
async function deleteRepository(token, repositoryName) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request("DELETE /repos/{owner}/{repo}", {
    owner,
    repo
  });
}
__name(deleteRepository, "deleteRepository");
async function listWorkflows(token, repositoryName, workflowFileName) {
  const [owner, repo] = repositoryName.split("/");
  const client = await octokit(token);
  const workflow2 = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  const run = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  return { workflow: workflow2, run };
}
__name(listWorkflows, "listWorkflows");
async function getWorkflowRun(token, repositoryName, workflowFileName, sha) {
  const [owner, repo] = repositoryName.split("/");
  const result = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs", {
    owner,
    repo,
    workflow_id: workflowFileName,
    head_sha: sha,
    branch: "main",
    exclude_pull_requests: true
  });
  const run = result.data.workflow_runs[0];
  if (!run) {
    return {
      run: {
        status: "queued",
        conclusion: null
      },
      jobs: []
    };
  }
  const runJobs = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs", {
    owner,
    repo,
    run_id: run.id
  });
  return {
    run,
    jobs: runJobs.data.jobs.map((it) => ({
      id: it.id,
      name: it.name,
      status: it.status,
      conclusion: it.conclusion,
      steps: (it.steps ?? []).map((step) => ({
        id: `${step.name}-${step.number}-${step.completed_at ?? 0}`,
        name: step.name,
        status: step.status,
        conclusion: step.conclusion,
        elapsed: step.completed_at && step.started_at ? differenceInSeconds(
          new Date(step.completed_at),
          new Date(step.started_at)
        ) : null
      }))
    }))
  };
}
__name(getWorkflowRun, "getWorkflowRun");

// libs/modern/src/index.ts
import { mkdir, writeFile } from "fs/promises";
import { dirname as dirname4, isAbsolute, join as join4 } from "path";
import { tap } from "rxjs/operators";
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag, enabled = true) {
  const header = /* @__PURE__ */ __name((value, error) => typeof tag === "string" ? tag : tag(value, error), "header");
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}
__name(debug, "debug");
async function writeFiles(dir, contents) {
  for (const [file2, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file2) ? file2 : join4(dir, file2);
    await mkdir(dirname4(filePath), { recursive: true });
    await writeFile(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file2)
      ),
      "utf-8"
    );
  }
}
__name(writeFiles, "writeFiles");

// libs/docker/src/lib/compose/compose.ts
import yaml from "js-yaml";
function service(serviceLike) {
  const ports = (serviceLike.ports ?? []).map((it) => {
    const [host, internal] = it.split(":");
    return {
      host,
      internal
    };
  });
  const volumes = (serviceLike.volumes ?? []).map((it) => {
    const [src, dest] = it.split(":");
    return {
      src,
      dest,
      isNamedVolume: !(src.startsWith("/") || src.startsWith("./"))
    };
  });
  return {
    composeService: serviceLike,
    ports,
    volumes,
    networks: serviceLike.networks ?? [],
    dependsOn: /* @__PURE__ */ __name((services) => {
      const depends_on = [];
      for (const dependencie of serviceLike.depends_on ?? []) {
        for (const [serviceName, serviceLike2] of Object.entries(services)) {
          if (serviceLike2.composeService === dependencie) {
            depends_on.push(serviceName);
          }
        }
      }
      return depends_on;
    }, "dependsOn")
  };
}
__name(service, "service");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
var postgres = {
  image: "postgres:16",
  ports: ["5432:5432"],
  volumes: ["postgres_data:/var/lib/postgresql/data"],
  networks: ["development"],
  environment: {
    POSTGRES_PASSWORD: "yourpassword",
    POSTGRES_USER: "youruser",
    POSTGRES_DB: "yourdatabase"
  },
  get appEnvironment() {
    const {
      POSTGRES_PASSWORD: password2,
      POSTGRES_USER: user,
      POSTGRES_DB: db
    } = this.environment;
    const [host, internal] = (this.ports ?? [])[0].split(":");
    return {
      CONNECTION_STRING: `postgresql://${user}:${password2}@database:${host}/${db}`
    };
  }
};
var pgadmin = {
  image: "dpage/pgadmin4",
  ports: ["8080:8080"],
  networks: ["development"],
  environment: {
    PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
    PGADMIN_DEFAULT_PASSWORD: "password"
  }
};
var localServer = /* @__PURE__ */ __name((options = {
  port: "3000"
}) => {
  options.port ??= "3000";
  return {
    image: "node:alpine",
    build: {
      context: ".",
      dockerfile: "Dockerfile"
    },
    networks: ["development"],
    restart: "unless-stopped",
    command: "node --watch /app/build/server.js",
    develop: {
      watch: [
        {
          action: "sync",
          path: "./output/build/server.js",
          target: "/app/build/server.js",
          ignore: ["node_modules/"]
        },
        {
          action: "rebuild",
          path: "./output/package.json"
        },
        {
          action: "rebuild",
          path: "./package.json"
        }
      ]
    },
    ports: [`${options.port}:${options.port}`, "9229:9229"],
    environment: {
      NODE_ENV: "development",
      PORT: options.port
    },
    env_file: removeDuplicates(
      [".env", ...options.env_file ?? [], ".env.compose"],
      (key) => key
    )
  };
}, "localServer");
function compose(services) {
  const dockerCompose = {
    volumes: {},
    networks: {},
    services: {}
  };
  const appEnvironment = {};
  for (const [serviceName, it] of Object.entries(services)) {
    const depends_on = it.dependsOn(services);
    Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
    delete it.composeService.appEnvironment;
    dockerCompose.services[serviceName] = {
      ...it.composeService,
      environment: Object.keys(it.composeService.environment).length ? it.composeService.environment : void 0,
      depends_on: depends_on.length ? depends_on : void 0
    };
    dockerCompose.volumes = {
      ...dockerCompose.volumes,
      ...it.volumes.filter((it2) => it2.isNamedVolume).reduce(
        (acc, it2) => ({
          ...acc,
          [it2.src]: {}
        }),
        {}
      )
    };
    dockerCompose.networks = {
      ...dockerCompose.networks,
      ...it.networks.reduce(
        (acc, it2) => ({
          ...acc,
          [it2]: {}
        }),
        {}
      )
    };
  }
  return {
    dockerCompose,
    environment: appEnvironment,
    print() {
      return yaml.dump(dockerCompose, {
        skipInvalid: false,
        noRefs: true,
        forceQuotes: true,
        noCompatMode: true,
        schema: yaml.JSON_SCHEMA
      });
    },
    write() {
      writeFiles(process.cwd(), {
        "compose.dev.yml": this.print(),
        ".env.compose": toKevValEnv(appEnvironment)
      });
    },
    run: /* @__PURE__ */ __name(() => {
    }, "run")
  };
}
__name(compose, "compose");
function writeCompose({
  dockerCompose,
  environment
}) {
  return writeFiles(process.cwd(), {
    "compose.dev.yml": yaml.dump(dockerCompose, {
      skipInvalid: false,
      noRefs: true,
      forceQuotes: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }),
    ".env.compose": toKevValEnv(environment)
  });
}
__name(writeCompose, "writeCompose");

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
import crypto2 from "crypto";
import { createReadStream, existsSync } from "fs";
import { mkdir as mkdir2, readFile, rm, writeFile as writeFile2 } from "fs/promises";
import { tmpdir } from "os";
import { basename as basename2, dirname as dirname5, join as join5 } from "path";
function followProgress(stream, logger3 = console) {
  return new Promise((resolve2, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve2(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger3.log(obj);
        }
      }
    );
  });
}
__name(followProgress, "followProgress");
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
__name(upsertVolume, "upsertVolume");
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
__name(upsertNetwork, "upsertNetwork");
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
__name(getContainer, "getContainer");
async function removeContainer(nameOrContainer, wait) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    const options = wait === 0 ? { t: wait } : {};
    await container.stop(options).catch(console.error);
  }
  await container.remove({
    force: wait === 0
  }).catch(console.error);
}
__name(removeContainer, "removeContainer");
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
__name(isContainerRunning, "isContainerRunning");
function computeChecksum(filePath) {
  return new Promise((resolve2, reject) => {
    const hash = crypto2.createHash("md5");
    const stream = typeof filePath === "string" ? createReadStream(filePath) : filePath;
    stream.on("data", (data) => hash.update(data));
    stream.on("end", () => resolve2(hash.digest("hex")));
    stream.on("error", (err) => reject(err));
  });
}
__name(computeChecksum, "computeChecksum");
async function fileChanged(filePath, discrminator) {
  const checksumDirPath = join5(tmpdir(), discrminator);
  await mkdir2(checksumDirPath, { recursive: true });
  const checksumFilePath = join5(checksumDirPath, basename2(filePath));
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile2(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile2(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(fileChanged, "fileChanged");
async function contentChanged(content, fileName, discrminator) {
  const checksumFilePath = join5(tmpdir(), discrminator, fileName);
  await mkdir2(dirname5(checksumFilePath), { recursive: true });
  const filePath = join5(tmpdir(), "check", discrminator, fileName);
  await mkdir2(dirname5(filePath), { recursive: true });
  await writeFile2(filePath, content, "utf-8");
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile2(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile2(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(contentChanged, "contentChanged");
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}
__name(followLogs, "followLogs");
async function startContainer(name, createContainer) {
  let container = null;
  if (typeof name === "string") {
    container = await getContainer({ name });
  } else {
    container = name;
  }
  if (!container) {
    if (!createContainer) {
      throw new Error(`Cannot initialize server for project: ${name}`);
    }
    container = await createContainer();
  }
  const running = await isContainerRunning(container);
  if (!running) {
    await container.start().catch((error) => {
      if (error.statusCode === 304) {
        return;
      }
      throw error;
    });
  }
  return container;
}
__name(startContainer, "startContainer");
async function getContainerNet(containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings;
}
__name(getContainerNet, "getContainerNet");
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}
__name(getContainerExternalPort, "getContainerExternalPort");
async function pushImage(repo, tag = "latest") {
  const image = docker.getImage(repo);
  const stream = await image.push({
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    },
    tag
  });
  await followProgress(stream);
  return image;
}
__name(pushImage, "pushImage");
async function pullImage(image, tag = "latest") {
  const stream = await docker.createImage({
    fromImage: image,
    tag,
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    }
  });
  await followProgress(stream);
  return image;
}
__name(pullImage, "pullImage");
async function imagesExists(...tags) {
  const images = await docker.listImages({
    all: true
  });
  const imageTags = images.flatMap((image) => image.RepoTags);
  return tags.every((tag) => {
    return imageTags.includes(tag.includes(":") ? tag : `${tag}:latest`);
  });
}
__name(imagesExists, "imagesExists");

// libs/docker/src/lib/file/declarative.ts
import { AsyncLocalStorage } from "node:async_hooks";
import { writeFile as writeFile3 } from "node:fs/promises";
import { join as join6, normalize as normalize2 } from "node:path";
var store = new AsyncLocalStorage();
function followStage(stages, stage4) {
  return typeof stage4.from === "string" ? [stage4.from, stage4] : (() => {
    const s = Object.entries(stages).find(([, stageValue]) => {
      return stageValue === stage4.from;
    });
    if (!s) {
      throw new Error(`Stage ${JSON.stringify(stage4.from.from)} not found`);
    }
    return s;
  })();
}
__name(followStage, "followStage");
function copyWriter(stages) {
  const writeCopy = /* @__PURE__ */ __name((workdir, copy) => {
    const lines = [];
    if (!copy) return lines;
    if ("link" in copy) {
      lines.push(...writeShortCopy(workdir, copy));
    } else {
      lines.push(...writePointToPointCopy(workdir, copy));
    }
    return lines;
  }, "writeCopy");
  const writeShortCopy = /* @__PURE__ */ __name((workdir, copy) => {
    const lines = [];
    const fixedPoint = normalize2(join6("/", copy.link, "/"));
    const path = fixedPoint.replace(/^\//, "./").replace(/\/$/, "");
    if (copy.from) {
      const relatedStage = followStage(stages, copy);
      lines.push(
        `COPY --from=${relatedStage[0]} ${normalize2(
          join6(
            store.getStore()?.stagesSet[relatedStage[0]].config.workdir || "",
            copy.link
          )
        )} ${path}`
      );
    } else {
      lines.push(`COPY ${path} ${path}`);
    }
    return lines;
  }, "writeShortCopy");
  function writePointToPointCopy(workdir, copy) {
    function normalizeDest(srcs, dest) {
      return dest === "." ? srcs.length === 1 ? "." : "./" : dest;
    }
    __name(normalizeDest, "normalizeDest");
    let instruction = "COPY";
    let copySrcs = (Array.isArray(copy.src) ? copy.src : [copy.src]).map(
      (src) => normalize2(join6(src))
    );
    if (copy.from) {
      const relatedStage = followStage(stages, copy);
      instruction = `COPY --from=${relatedStage[0]}`;
      copySrcs = copySrcs.map(
        (it) => `${normalize2(
          join6(
            store.getStore()?.stagesSet[relatedStage[0]].config.workdir || "",
            it
          )
        )}`
      );
    }
    if (!copy.dest) {
      const dest = ".";
      return [
        `${instruction} ${copySrcs.join(" ")} ${normalizeDest(copySrcs, dest)}`
      ];
    }
    if (typeof copy.dest === "string") {
      return [
        `${instruction} ${copySrcs.join(" ")} ${normalizeDest(copySrcs, copy.dest)}`
      ];
    } else {
      const lines = [
        copy.dest.create ? `RUN mkdir -p ${normalize2(join6("./", copy.dest.path))}` : "",
        `COPY ${copySrcs.join(" ")} ${normalize2(join6("./", normalizeDest(copySrcs, copy.dest.path)))}`
      ];
      return lines;
    }
  }
  __name(writePointToPointCopy, "writePointToPointCopy");
  return {
    writeCopy,
    writeShortCopy,
    writePointToPointCopy
  };
}
__name(copyWriter, "copyWriter");
function createWriter(stages) {
  let entrypoint;
  let cmd;
  let expose;
  const stagesSet = {};
  return {
    cmd(value) {
      cmd = value;
    },
    entrypoint(value) {
      entrypoint = value;
    },
    expose(port) {
      expose = port;
    },
    addStage(name, stage4) {
      stagesSet[name] = stage4;
    },
    print: /* @__PURE__ */ __name(() => {
      return store.run({ stages, stagesSet }, () => {
        const lines = [];
        Object.entries(stagesSet).forEach(([name, stage4]) => {
          lines.push(...stage4.format(name, stages));
        });
        if (expose) {
          lines.push(`EXPOSE ${expose}`);
        }
        if (entrypoint && entrypoint.length) {
          lines.push(
            `ENTRYPOINT [${coerceArray(entrypoint).map((it) => safeFail(() => `"${JSON.parse(`"${it}"`)}"`, it)).join(", ")}]`
          );
        }
        if (cmd && cmd.length) {
          lines.push(
            `CMD [${coerceArray(cmd).map((it) => safeFail(() => `"${JSON.parse(`"${it}"`)}"`, it)).join(", ")}]`
          );
        }
        return lines.join("\n").trim();
      });
    }, "print")
  };
}
__name(createWriter, "createWriter");
function coerceArray(value) {
  return Array.isArray(value) ? value : [value];
}
__name(coerceArray, "coerceArray");
function stageFactory(config2) {
  config2.environment ??= {};
  function env(name, value) {
    if (typeof name === "string" && value) {
      config2.environment[name] = value;
      return this;
    }
    Object.entries(name).forEach(
      ([name2, value2]) => config2.environment[name2] = value2
    );
    return this;
  }
  __name(env, "env");
  return {
    config: config2,
    package(...packages) {
      config2.packages = packages;
      return this;
    },
    from(from3) {
      config2.from = from3;
      return this;
    },
    workdir(workdir) {
      config2.workdir = workdir;
      return this;
    },
    addCopy(value) {
      if (!config2.copy) {
        config2.copy = value;
        return this;
      }
      value = Array.isArray(value) ? value : [value];
      if (Array.isArray(config2.copy)) {
        config2.copy = [...config2.copy, ...value];
      } else {
        config2.copy = [
          ...Array.isArray(config2.copy) ? config2.copy : [config2.copy],
          ...value
        ];
      }
      return this;
    },
    addUser() {
      return this;
    },
    user(name) {
      config2.user = name;
      return this;
    },
    addOutput(value) {
      config2.output;
      return this;
    },
    env,
    format: /* @__PURE__ */ __name((name, stages) => {
      const lines = [];
      const pkgs = config2.packages || [];
      const moreCopies = [];
      if (config2.from) {
        lines.push("\n");
        const [from3] = followStage(stages, config2);
        lines.push(`FROM ${from3} AS ${name}`);
      }
      if (pkgs.length) {
        lines.push(
          `RUN apt-get update && apt-get install -y ${pkgs.join(" ")}`
        );
      }
      if (config2.workdir) {
        lines.push(`WORKDIR ${config2.workdir}`);
      }
      if (config2.copy) {
        const copies = Array.isArray(config2.copy) ? config2.copy : [config2.copy];
        for (const copy of [...copies, ...moreCopies]) {
          lines.push(
            ...copyWriter(stages).writeCopy(
              config2.workdir || "",
              typeof copy === "string" ? { src: copy } : copy
            )
          );
        }
      }
      Object.entries(config2.environment ?? {}).forEach(([name2, value]) => {
        lines.push(`ENV ${name2}=${value}`);
      });
      const run = coerceArray(config2.run ?? []);
      const userIndex = lines.length - 1;
      if (config2.user) {
        lines.push(`USER ${config2.user}`);
      }
      run.forEach((it) => {
        if (typeof it === "string") {
          if (it.trim()) {
            lines.push(`RUN ${it.trim()}`);
          }
        } else if (Array.isArray(it)) {
          const cmds = [
            "\\",
            ...it.map((l, index2, arr) => {
              if (arr.length === index2 + 1) return `	${l}`;
              return `	${l} \\`;
            })
          ];
          lines.push(`RUN ${cmds.join("\n")}`);
        } else {
          const cmds = [it.cwd ? `cd ${it.cwd}` : "", ...coerceArray(it.cmd)].filter(Boolean).join(" && ");
          if (it.root) {
            lines.splice(userIndex, 0, `RUN ${cmds}`);
          } else {
            lines.push(`RUN ${cmds}`);
          }
        }
      });
      return lines;
    }, "format")
  };
}
__name(stageFactory, "stageFactory");
function dockerfile(config2) {
  const dismantleStage = /* @__PURE__ */ __name((value) => Array.isArray(value) ? value[0] : value, "dismantleStage");
  config2.stages ??= {};
  const stages = Object.entries(config2.stages).reduce(
    (acc, [name, value]) => ({
      ...acc,
      [name]: dismantleStage(value)
    }),
    {}
  );
  const writer = createWriter(stages);
  const startStage = stageFactory(config2.start).env(config2.start.environment ?? {}).env("PORT", config2.start.port);
  Object.entries(config2.stages).forEach(([name, value]) => {
    const stageConfig = Array.isArray(value) ? typeof value[0] === "function" ? value[0](value[1]) : value[0] : value;
    writer.addStage(name, stageFactory(stageConfig));
    const output = (stageConfig.output ? Array.isArray(stageConfig.output) ? stageConfig.output : [stageConfig.output] : []).map((it) => {
      const src = typeof it === "string" ? it : it.src;
      const dest = typeof it === "string" ? it : it.dest;
      return {
        from: dismantleStage(value),
        src,
        dest
      };
    });
    startStage.addCopy(output);
  });
  writer.addStage("start", startStage);
  writer.expose(config2.start.port);
  writer.entrypoint(config2.start.entrypoint ?? []);
  writer.cmd(config2.start.cmd ?? []);
  return {
    print: /* @__PURE__ */ __name(() => writer.print(), "print"),
    save: /* @__PURE__ */ __name((filePath) => {
      return writeFile3(filePath, writer.print(), "utf-8");
    }, "save")
  };
}
__name(dockerfile, "dockerfile");

// libs/docker/src/lib/file/servers.ts
function nodeServer(config2) {
  if (typeof config2 === "string") {
    return {
      from: nodeServer.alpine,
      workdir: "/app",
      cmd: `node ${config2}`,
      port: 3e3,
      user: "node",
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  const additionalProps = {};
  if (typeof config2.entry === "string") {
    additionalProps.cmd = [`node`, config2.entry];
  } else if (config2.entry.type === "script") {
    additionalProps.cmd = ["npm", "run", config2.entry.value];
  } else if (config2.entry.type === "file") {
    additionalProps.cmd = ["npm", config2.entry.value];
  } else {
    throw new Error("Invalid entry type");
  }
  return {
    from: nodeServer.alpine,
    workdir: "/app",
    port: 3e3,
    user: "node",
    ...config2,
    ...additionalProps,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config2.environment ?? {}
    }
  };
}
__name(nodeServer, "nodeServer");
denoServer.alpine = "denoland/deno:alpine";
function denoServer(config2) {
  if (typeof config2 === "string") {
    return {
      from: denoServer.alpine,
      workdir: "/app",
      cmd: [`deno`, "--allow-net", config2],
      port: 8e3,
      user: "deno",
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  const additionalProps = {};
  if (config2.entry.type === "script") {
    additionalProps.cmd = ["deno", "task", config2.entry.value];
  } else if (config2.entry.type === "file") {
    additionalProps.cmd = [
      "deno",
      "run",
      ...config2.entry.flags,
      config2.entry.value
    ];
  } else if (config2.entry.type === "executable") {
    additionalProps.cmd = [`./${config2.entry.value}`];
  } else {
    throw new Error("Invalid entry type");
  }
  return {
    from: denoServer.alpine,
    workdir: "/app",
    ...additionalProps,
    port: 8e3,
    user: "deno",
    ...config2,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config2.environment ?? {}
    }
  };
}
__name(denoServer, "denoServer");
nodeServer.alpine = "node:alpine";
nodeServer.dockerignore = [
  "**/node_modules/",
  "**/.git",
  "**/README.md",
  "**/LICENSE",
  "**/.vscode",
  "**/.idea",
  "**/npm-debug.log",
  "**/coverage*",
  "**/.env",
  "**/.editorconfig",
  "**/.aws",
  "**/dist",
  "**/build",
  "**/.output",
  "**/output",
  "**/tmp",
  "**/test-results",
  "**/tests",
  "**/__tests__",
  "**/docs",
  ".dockerignore",
  "docker-compose*",
  ".gitignore",
  "Dockerfile*",
  "Jenkinsfile*",
  "helm-charts",
  "Makefile",
  "Thumbs.db",
  ".DS_Store"
];
function bunServer(config2) {
  if (typeof config2 === "string") {
    return {
      from: bunServer.alpine,
      user: "bun",
      workdir: "/app",
      port: 3e3,
      cmd: `bun ${config2}`,
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  return {
    from: bunServer.alpine,
    user: "bun",
    workdir: "/app",
    port: 3e3,
    cmd: ["bun", "run", config2.entry],
    ...config2,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config2.environment ?? {}
    }
  };
}
__name(bunServer, "bunServer");
bunServer.alpine = "oven/bun:1";
function nginx(config2 = {}) {
  return {
    from: "nginxinc/nginx-unprivileged",
    workdir: "/usr/share/nginx/html",
    user: "nginx",
    port: 8080,
    cmd: ["nginx", "-g", '"daemon off;"'],
    environment: {},
    ...config2
  };
}
__name(nginx, "nginx");
function httpd() {
  return {
    from: "httpd:alpine",
    workdir: "/usr/local/apache2/htdocs/",
    user: "nginx",
    port: 80,
    cmd: 'nginx -g "daemon off;"',
    environment: {}
  };
}
__name(httpd, "httpd");
denoServer.dockerignore = [...nodeServer.dockerignore, ".vscode"];

// libs/docker/src/lib/file/utils.ts
function knownPackageManager(userSepcified) {
  if (!userSepcified) {
    return false;
  }
  return ["yarn", "npm", "pnpm"].includes(userSepcified);
}
__name(knownPackageManager, "knownPackageManager");
var packageManagerCommands = {
  npm: {
    install: "npm ci",
    build: "npm run build"
  },
  yarn: {
    install: "yarn --frozen-lockfile",
    build: "yarn run build"
  },
  pnpm: {
    install: "corepack enable pnpm && pnpm i --frozen-lockfile",
    build: "corepack enable pnpm && pnpm run build"
  },
  bun: {
    install: "bun install --frozen-lockfile",
    build: "bun run build"
  }
};
function stage(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage, "stage");

// libs/docker/src/lib/file/angular.ts
var base = {
  from: nodeServer.alpine,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps = /* @__PURE__ */ __name((options) => ({
  from: base,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ]
}), "deps");
var builder = /* @__PURE__ */ __name((packageManager) => ({
  from: base,
  workdir: "/app",
  copy: [
    {
      from: deps,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ]
}), "builder");
var angular = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: {
    base: stage(base),
    deps: stage(deps, {
      packageManager: config2.packageManager,
      mode: config2.mode
    }),
    builder: stage(builder, config2.packageManager)
  },
  start: config2.mode === "spa" ? nginx({
    copy: {
      from: builder,
      src: `${config2.outputPath}/browser`
    }
  }) : nodeServer({
    from: base,
    copy: {
      from: builder,
      src: config2.outputPath
    },
    entry: "server/server.mjs"
  })
}), "angular");
angular.dockerignore = [...nodeServer.dockerignore, ".angular"];

// libs/docker/src/lib/file/astro.ts
var base2 = {
  from: nodeServer.alpine,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps2 = /* @__PURE__ */ __name((options) => ({
  from: base2,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ],
  output: options.mode !== "static" ? ["node_modules"] : []
}), "deps");
var builder2 = /* @__PURE__ */ __name((packageManager) => ({
  from: base2,
  workdir: "/app",
  copy: [
    {
      from: deps2,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ],
  output: [{ src: "dist", dest: "." }]
}), "builder");
var astrojs = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage(base2),
    deps: stage(deps2, {
      packageManager: options.packageManager,
      mode: options.mode
    }),
    builder: stage(builder2, options.packageManager)
  },
  start: options.mode === "static" ? nginx() : nodeServer({
    from: base2,
    entry: "server/entry.mjs"
  })
}), "astrojs");
astrojs.dockerignore = [...nodeServer.dockerignore, ".astro"];

// libs/docker/src/lib/file/deno.ts
var base3 = {
  from: "denoland/deno:alpine",
  workdir: "/app"
};
var deps3 = {
  from: base3,
  workdir: "/app",
  copy: ["deno.{json*,lock}"],
  run: "deno install"
};
var builder3 = {
  from: deps3,
  workdir: "/app",
  copy: ".",
  run: "deno compile --allow-net --allow-env --output entry main.ts"
};
var deno = /* @__PURE__ */ __name(() => dockerfile({
  stages: { base: base3, deps: deps3, builder: builder3 },
  start: denoServer({
    from: base3,
    entry: {
      type: "executable",
      value: "entry"
    },
    copy: {
      from: builder3,
      link: "entry"
    }
  })
}), "deno");
deno.dockerignore = [...nodeServer.dockerignore];

// libs/docker/src/lib/file/dotnet.ts
var build = {
  from: "mcr.microsoft.com/dotnet/sdk",
  workdir: "/app",
  copy: ".",
  run: ["dotnet restore", "dotnet publish -c Release -o out"]
};
var dotnet = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: { build },
  start: {
    from: "mcr.microsoft.com/dotnet/aspnet:8.0",
    workdir: "/app",
    copy: { from: build, src: "out" },
    port: 8080,
    entrypoint: ["dotnet", `${config2.projectName}.dll`]
  }
}), "dotnet");
dotnet.dockerignore = [
  ...nodeServer.dockerignore,
  "# Created by https://www.gitignore.io/api/csharp",
  "",
  "### Csharp ###",
  "## Ignore Visual Studio temporary files, build results, and",
  "## files generated by popular Visual Studio add-ons.",
  "",
  "# User-specific files",
  "*.suo",
  "*.user",
  "*.userosscache",
  "*.sln.docstates",
  "",
  "# User-specific files (MonoDevelop/Xamarin Studio)",
  "*.userprefs",
  "",
  "# Build results",
  "# [Dd]ebug/",
  "[Dd]ebugPublic/",
  "[Rr]elease/",
  "[Rr]eleases/",
  "x64/",
  "x86/",
  "bld/",
  "# [Bb]in/",
  "[Oo]bj/",
  "[Ll]og/",
  "",
  "# Visual Studio 2015 cache/options directory",
  ".vs/",
  "# Uncomment if you have tasks that create the project's static files in wwwroot",
  "#wwwroot/",
  "",
  "# MSTest test Results",
  "[Tt]est[Rr]esult*/",
  "[Bb]uild[Ll]og.*",
  "",
  "# NUNIT",
  "*.VisualState.xml",
  "TestResult.xml",
  "",
  "# Build Results of an ATL Project",
  "[Dd]ebugPS/",
  "[Rr]eleasePS/",
  "dlldata.c",
  "",
  "# DNX",
  "project.lock.json",
  "project.fragment.lock.json",
  "artifacts/",
  "Properties/launchSettings.json",
  "",
  "*_i.c",
  "*_p.c",
  "*_i.h",
  "*.ilk",
  "*.meta",
  "*.obj",
  "*.pch",
  "*.pdb",
  "*.pgc",
  "*.pgd",
  "*.rsp",
  "*.sbr",
  "*.tlb",
  "*.tli",
  "*.tlh",
  "*.tmp",
  "*.tmp_proj",
  "*.log",
  "*.vspscc",
  "*.vssscc",
  ".builds",
  "*.pidb",
  "*.svclog",
  "*.scc",
  "",
  "# Chutzpah Test files",
  "_Chutzpah*",
  "",
  "# Visual C++ cache files",
  "ipch/",
  "*.aps",
  "*.ncb",
  "*.opendb",
  "*.opensdf",
  "*.sdf",
  "*.cachefile",
  "*.VC.db",
  "*.VC.VC.opendb",
  "",
  "# Visual Studio profiler",
  "*.psess",
  "*.vsp",
  "*.vspx",
  "*.sap",
  "",
  "# TFS 2012 Local Workspace",
  "$tf/",
  "",
  "# Guidance Automation Toolkit",
  "*.gpState",
  "",
  "# ReSharper is a .NET coding add-in",
  "_ReSharper*/",
  "*.[Rr]e[Ss]harper",
  "*.DotSettings.user",
  "",
  "# JustCode is a .NET coding add-in",
  ".JustCode",
  "",
  "# TeamCity is a build add-in",
  "_TeamCity*",
  "",
  "# DotCover is a Code Coverage Tool",
  "*.dotCover",
  "",
  "# Visual Studio code coverage results",
  "*.coverage",
  "*.coveragexml",
  "",
  "# NCrunch",
  "_NCrunch_*",
  ".*crunch*.local.xml",
  "nCrunchTemp_*",
  "",
  "# MightyMoose",
  "*.mm.*",
  "AutoTest.Net/",
  "",
  "# Web workbench (sass)",
  ".sass-cache/",
  "",
  "# Installshield output folder",
  "[Ee]xpress/",
  "",
  "# DocProject is a documentation generator add-in",
  "DocProject/buildhelp/",
  "DocProject/Help/*.HxT",
  "DocProject/Help/*.HxC",
  "DocProject/Help/*.hhc",
  "DocProject/Help/*.hhk",
  "DocProject/Help/*.hhp",
  "DocProject/Help/Html2",
  "DocProject/Help/html",
  "",
  "# Click-Once directory",
  "publish/",
  "",
  "# Publish Web Output",
  "*.[Pp]ublish.xml",
  "*.azurePubxml",
  "# TODO: Comment the next line if you want to checkin your web deploy settings",
  "# but database connection strings (with potential passwords) will be unencrypted",
  "*.pubxml",
  "*.publishproj",
  "",
  "# Microsoft Azure Web App publish settings. Comment the next line if you want to",
  "# checkin your Azure Web App publish settings, but sensitive information contained",
  "# in these scripts will be unencrypted",
  "PublishScripts/",
  "",
  "# NuGet Packages",
  "*.nupkg",
  "# The packages folder can be ignored because of Package Restore",
  "**/packages/*",
  "# except build/, which is used as an MSBuild target.",
  "!**/packages/build/",
  "# Uncomment if necessary however generally it will be regenerated when needed",
  "#!**/packages/repositories.config",
  "# NuGet v3's project.json files produces more ignoreable files",
  "*.nuget.props",
  "*.nuget.targets",
  "",
  "# Microsoft Azure Build Output",
  "csx/",
  "*.build.csdef",
  "",
  "# Microsoft Azure Emulator",
  "ecf/",
  "rcf/",
  "",
  "# Windows Store app package directories and files",
  "AppPackages/",
  "BundleArtifacts/",
  "Package.StoreAssociation.xml",
  "_pkginfo.txt",
  "",
  "# Visual Studio cache files",
  "# files ending in .cache can be ignored",
  "*.[Cc]ache",
  "# but keep track of directories ending in .cache",
  "!*.[Cc]ache/",
  "",
  "# Others",
  "ClientBin/",
  "~$*",
  "*~",
  "*.dbmdl",
  "*.dbproj.schemaview",
  "*.jfm",
  "*.pfx",
  "*.publishsettings",
  "node_modules/",
  "orleans.codegen.cs",
  "",
  "# Since there are multiple workflows, uncomment next line to ignore bower_components",
  "# (https://github.com/github/gitignore/pull/1529#issuecomment-104372622)",
  "#bower_components/",
  "",
  "# RIA/Silverlight projects",
  "Generated_Code/",
  "",
  "# Backup & report files from converting an old project file",
  "# to a newer Visual Studio version. Backup files are not needed,",
  "# because we have git ;-)",
  "_UpgradeReport_Files/",
  "Backup*/",
  "UpgradeLog*.XML",
  "UpgradeLog*.htm",
  "",
  "# SQL Server files",
  "*.mdf",
  "*.ldf",
  "",
  "# Business Intelligence projects",
  "*.rdl.data",
  "*.bim.layout",
  "*.bim_*.settings",
  "",
  "# Microsoft Fakes",
  "FakesAssemblies/",
  "",
  "# GhostDoc plugin setting file",
  "*.GhostDoc.xml",
  "",
  "# Node.js Tools for Visual Studio",
  ".ntvs_analysis.dat",
  "",
  "# Visual Studio 6 build log",
  "*.plg",
  "",
  "# Visual Studio 6 workspace options file",
  "*.opt",
  "",
  "# Visual Studio 6 auto-generated workspace file (contains which files were open etc.)",
  "*.vbw",
  "",
  "# Visual Studio LightSwitch build output",
  "**/*.HTMLClient/GeneratedArtifacts",
  "**/*.DesktopClient/GeneratedArtifacts",
  "**/*.DesktopClient/ModelManifest.xml",
  "**/*.Server/GeneratedArtifacts",
  "**/*.Server/ModelManifest.xml",
  "_Pvt_Extensions",
  "",
  "# Paket dependency manager",
  ".paket/paket.exe",
  "paket-files/",
  "",
  "# FAKE - F# Make",
  ".fake/",
  "",
  "# JetBrains Rider",
  ".idea/",
  "*.sln.iml",
  "",
  "# CodeRush",
  ".cr/",
  "",
  "# Python Tools for Visual Studio (PTVS)",
  "__pycache__/",
  "*.pyc",
  "",
  "# Cake - Uncomment if you are using it",
  "tools/",
  "tools/Cake.CoreCLR",
  "tools",
  ".dotnet"
];

// libs/docker/src/lib/file/nextjs.ts
var base4 = {
  from: nodeServer.alpine,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps4 = /* @__PURE__ */ __name((config2) => ({
  from: base4,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(config2.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config2.packageManager].install
  ],
  output: config2.mode === "export" ? [] : ["node_modules"]
}), "deps");
var builder4 = /* @__PURE__ */ __name((config2) => ({
  from: base4,
  workdir: "/app",
  copy: [
    {
      from: deps4,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    config2.mode === "export" ? "" : "mkdir -p ./public",
    !knownPackageManager(config2.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config2.packageManager].build
  ],
  environment: {
    NEXT_TELEMETRY_DISABLED: "1"
  },
  output: config2.mode === "export" ? [{ src: "out", dest: "." }] : config2.mode === "standalone" ? [
    "public",
    ".next/static",
    {
      src: ".next/standalone",
      dest: "."
    }
  ] : ["public", ".next"]
}), "builder");
function stage2(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage2, "stage");
var nextjs = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage2(base4),
    deps: stage2(deps4, options),
    builder: stage2(builder4, options)
  },
  start: options.mode === "export" ? nginx() : nodeServer({
    from: base4,
    entry: {
      ...options.mode === "standalone" ? { type: "file", value: "server.js" } : { type: "script", value: "start" }
    },
    environment: {
      NEXT_TELEMETRY_DISABLED: "1"
    },
    copy: "package.json"
  })
}), "nextjs");
nextjs.dockerignore = [...nodeServer.dockerignore, ".next"];

// libs/docker/src/lib/file/nuxtjs.ts
var base5 = {
  from: nodeServer.alpine,
  packages: ["libc6-compat"]
};
var deps5 = /* @__PURE__ */ __name((packageManager) => ({
  from: base5,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].install
  ],
  output: ["node_modules"]
}), "deps");
var builder5 = /* @__PURE__ */ __name((config2) => {
  const buildScript = config2.mode === "static" ? "generate" : "build";
  return {
    from: base5,
    workdir: "/app",
    copy: [
      {
        from: deps5,
        link: "node_modules"
      },
      { link: "." }
    ],
    run: [
      !knownPackageManager(config2.packageManager) ? [
        `if [ -f yarn.lock ]; then yarn run ${buildScript};`,
        `elif [ -f package-lock.json ]; then npm run ${buildScript};`,
        `elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run ${buildScript};`,
        'else echo "Lockfile not found." && exit 1;',
        "fi"
      ] : packageManagerCommands[config2.packageManager].build.replace(
        "build",
        buildScript
      )
    ],
    environment: {
      NUXT_TELEMETRY_DISABLED: "1"
    },
    output: config2.mode === "static" ? [
      {
        src: ".output/public",
        dest: "."
      }
    ] : [".output"]
  };
}, "builder");
var nuxtjs = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: {
    base: stage(base5),
    deps: stage(deps5, config2.packageManager),
    builder: stage(builder5, config2)
  },
  start: config2.mode === "static" ? nginx() : nodeServer({
    from: base5,
    entry: ".output/server/index.mjs",
    environment: {
      NUXT_TELEMETRY_DISABLED: "1"
    }
  })
}), "nuxtjs");
nuxtjs.dockerignore = [...nodeServer.dockerignore, ".nuxt"];

// libs/docker/src/lib/file/remix.ts
var base6 = {
  from: nodeServer.alpine,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps6 = /* @__PURE__ */ __name((options) => ({
  from: base6,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ]
}), "deps");
var builder6 = /* @__PURE__ */ __name((packageManager) => ({
  from: base6,
  workdir: "/app",
  copy: [
    {
      from: deps6,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ]
}), "builder");
var remix = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: {
    base: stage(base6),
    deps: stage(deps6, {
      packageManager: config2.packageManager,
      mode: config2.mode
    }),
    builder: stage(builder6, config2.packageManager)
  },
  start: config2.mode === "spa" ? nginx({
    copy: [{ from: builder6, src: "build/client" }]
  }) : nodeServer({
    from: base6,
    entry: {
      type: "script",
      value: "start"
    },
    copy: [
      { from: builder6, link: "build" },
      { from: deps6, link: "node_modules" },
      "package.json"
    ]
  })
}), "remix");
remix.dockerignore = [...nodeServer.dockerignore, ".astro"];

// libs/docker/src/lib/file/streamlit.ts
var base7 = {
  from: "python:3.9-slim",
  packages: ["build-essential", "curl", "software-properties-common", "git"],
  run: ["rm -rf /var/lib/apt/lists/*"]
};
var streamlit = /* @__PURE__ */ __name(() => dockerfile({
  stages: { base: base7 },
  start: {
    from: base7,
    workdir: "/app",
    copy: [
      // 'requirements.txt',
      "."
    ],
    run: "pip3 install -r requirements.txt",
    port: 8501,
    healthCheck: {
      test: "curl --fail http://localhost:8501/_stcore/health"
    },
    cmd: ["app.py", "--server.port=8501", "--server.address=0.0.0.0"],
    entrypoint: ["streamlit", "run"]
  }
}), "streamlit");
streamlit.dockerignore = [
  ...nodeServer.dockerignore,
  "__pycache__/",
  "*.pyc",
  "venv/"
];

// libs/docker/src/lib/file/vite.ts
var base8 = {
  from: nodeServer.alpine,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps7 = /* @__PURE__ */ __name((options) => ({
  from: base8,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ]
}), "deps");
var builder7 = /* @__PURE__ */ __name((packageManager) => ({
  from: base8,
  workdir: "/app",
  copy: [
    {
      from: deps7,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ]
}), "builder");
function stage3(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage3, "stage");
var vite = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage3(base8),
    deps: stage3(deps7, {
      packageManager: options.packageManager
    }),
    builder: stage3(builder7, options.packageManager)
  },
  start: nginx({
    copy: "dist"
  })
}), "vite");
vite.dockerignore = [...nodeServer.dockerignore];

// libs/docker/src/lib/file/bun.ts
var base9 = {
  from: "oven/bun:1",
  packages: ["wget"]
};
var installDev = {
  from: base9,
  copy: [
    {
      src: ["package.json", "bun.lockb"],
      dest: {
        path: "/temp/dev",
        create: true
      }
    }
  ],
  run: [
    {
      cwd: "/temp/dev",
      cmd: "bun install --frozen-lockfile"
    }
  ]
};
var installProd = {
  from: base9,
  copy: [
    {
      src: ["package.json", "bun.lockb"],
      dest: {
        path: "/temp/prod",
        create: true
      }
    }
  ],
  run: [
    {
      cwd: "/temp/prod",
      cmd: "bun install --frozen-lockfile --production"
    }
  ]
};
var prerelease = {
  from: base9,
  copy: [
    {
      src: "/temp/dev/node_modules",
      dest: "node_modules"
    },
    { link: "." }
  ],
  run: "bun run ./src/index.ts"
};
var release = {
  from: base9,
  copy: [
    {
      src: "/temp/prod/node_modules",
      dest: "node_modules"
    },
    { from: prerelease, link: "." }
  ]
};
var deps8 = {
  from: base9,
  workdir: "/app",
  copy: ["package.json", "bun.lockb"],
  run: "bun install --frozen-lockfile"
};
var builder8 = /* @__PURE__ */ __name((config2) => ({
  from: deps8,
  workdir: "/app",
  copy: [{ from: deps8, link: "node_modules" }, "."],
  run: config2.buildCommand,
  output: config2.entrypoint
}), "builder");
var bun = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: {
    base: base9,
    deps: deps8,
    builder: stage(builder8, config2)
  },
  start: bunServer({
    from: base9,
    entry: "index.js"
  })
}), "bun");
bun.dockerignore = [...nodeServer.dockerignore];

// libs/docker/src/lib/file/node.ts
import { basename as basename3, dirname as dirname6 } from "path";
var base10 = {
  from: nodeServer.alpine
};
var deps9 = /* @__PURE__ */ __name((config2) => ({
  from: base10,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(config2.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config2.packageManager].install
  ]
}), "deps");
var builder9 = /* @__PURE__ */ __name((config2) => ({
  from: deps9,
  workdir: "/app",
  copy: [{ from: deps9, link: "node_modules" }, "."],
  run: [
    !knownPackageManager(config2.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config2.packageManager].build
  ]
}), "builder");
var node = /* @__PURE__ */ __name((config2) => dockerfile({
  stages: {
    base: base10,
    deps: stage(deps9, config2),
    ...config2.shouldBuild ? { builder: stage(builder9, config2) } : {}
  },
  start: nodeServer({
    from: base10,
    entry: config2.entrypoint,
    copy: [
      config2.shouldBuild ? [{ from: builder9, link: basename3(dirname6(config2.entrypoint)) }] : [{ from: deps9, link: "node_modules" }, "."]
    ].flat()
  })
}), "node");
node.dockerignore = [...nodeServer.dockerignore];

// libs/docker/src/index.ts
import { parse as parse2 } from "dotenv";
import { readFile as readFile2 } from "fs/promises";
import { join as join7 } from "path";
async function mergeEnvs(...files) {
  const env = {};
  for (const file2 of files) {
    const filePath = join7(process.cwd(), file2);
    const envFile = await readFile2(filePath, "utf-8");
    const envFileContent = parse2(envFile);
    Object.assign(env, envFileContent);
  }
  return env;
}
__name(mergeEnvs, "mergeEnvs");

// libs/sdk/declarative/src/lib/feature.ts
function feature(nameOrConfig, config2) {
  if (typeof nameOrConfig === "string") {
    if (!config2) {
      throw new Error(`Missing config for feature ${nameOrConfig}`);
    }
    return {
      name: nameOrConfig,
      tables: config2.tables,
      workflows: config2.workflows,
      policies: Object.entries(config2.policies || {}).reduce(
        (acc, [key, value]) => {
          const result = value(key);
          if (result) {
            acc[key] = result;
          }
          return acc;
        },
        {}
      )
    };
  }
  return {
    name: "",
    tables: nameOrConfig.tables,
    workflows: nameOrConfig.workflows,
    policies: Object.entries(nameOrConfig.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}
__name(feature, "feature");
feature.new = (name, config2) => {
  throw new Error("Not implemented");
};

// libs/sdk/declarative/src/lib/functional.ts
function input(value) {
  if (typeof value === "number" || typeof value === "boolean" || value === null) {
    return input.primitive(value);
  }
  if (value.startsWith("context") || value.startsWith("workflow")) {
    return input.workflow(value.replace("context.", ""));
  }
  if (value.startsWith("trigger")) {
    return input.trigger(value.replace("trigger.", ""));
  }
  if (!value.startsWith("@")) {
    return input.primitive(value);
  }
  return {
    input: value
  };
}
__name(input, "input");
((input5) => {
  function primitive(value) {
    return {
      input: `@fixed:${typeof value === "boolean" || typeof value === "number" || value === null ? value : `'${value}'`}`
    };
  }
  input5.primitive = primitive;
  __name(primitive, "primitive");
  function workflow2(path) {
    return {
      input: `@workflow:${path}`
    };
  }
  input5.workflow = workflow2;
  __name(workflow2, "workflow");
  function trigger2(path) {
    return {
      input: `@trigger:${path}`
    };
  }
  input5.trigger = trigger2;
  __name(trigger2, "trigger");
  function field2(name) {
    return {
      input: `@tables:fields.${name}`
    };
  }
  input5.field = field2;
  __name(field2, "field");
})(input || (input = {}));

// libs/sdk/declarative/src/lib/project.ts
function current_Project(config2) {
  return {
    features: config2.modules,
    imports: config2.imports ?? []
  };
}
__name(current_Project, "current_Project");
function project(...features) {
  return features;
}
__name(project, "project");

// libs/compiler/transpilers/src/lib/expression.ts
var QueryBuilder;
((QueryBuilder2) => {
  class Expression2 {
    static {
      __name(this, "Expression");
    }
  }
  QueryBuilder2.Expression = Expression2;
  function createBooleanLiteral(value) {
    return {
      value,
      type: "boolean",
      accept(visitor, context) {
        return visitor.visitBooleanLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createBooleanLiteral = createBooleanLiteral;
  __name(createBooleanLiteral, "createBooleanLiteral");
  function createDateLiteral(value) {
    return {
      value,
      type: "date",
      accept(visitor, context) {
        return visitor.visitDateLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createDateLiteral = createDateLiteral;
  __name(createDateLiteral, "createDateLiteral");
  function createStringLiteral(value, defaultContext) {
    return {
      value,
      type: "string",
      accept(visitor, context = defaultContext) {
        return visitor.visitStringLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createStringLiteral = createStringLiteral;
  __name(createStringLiteral, "createStringLiteral");
  function createNumericLiteral(value) {
    return {
      value,
      type: "numeric",
      accept(visitor, context) {
        return visitor.visitNumericLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNumericLiteral = createNumericLiteral;
  __name(createNumericLiteral, "createNumericLiteral");
  function createNullLiteral(defaultContext) {
    return {
      type: "null",
      accept(visitor, context = defaultContext) {
        return visitor.visitNullLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNullLiteral = createNullLiteral;
  __name(createNullLiteral, "createNullLiteral");
  function createIdentifier(value, defaultContext) {
    return {
      value,
      type: "identifier",
      accept(visitor, context) {
        return visitor.visitIdentifier(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createIdentifier = createIdentifier;
  __name(createIdentifier, "createIdentifier");
  function createCombinator(operator) {
    return {
      operator,
      type: "combinator",
      accept(visitor, context) {
        return visitor.visitCombinator(this, context);
      }
    };
  }
  QueryBuilder2.createCombinator = createCombinator;
  __name(createCombinator, "createCombinator");
  function createBinaryExpression(left, operator, right, defaultContext) {
    return {
      type: "binary",
      left,
      operator,
      right,
      accept(visitor, context = defaultContext) {
        return visitor.visitBinaryExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createBinaryExpression = createBinaryExpression;
  __name(createBinaryExpression, "createBinaryExpression");
  function createGroupExpression(list4, combinator, defaultContext) {
    return {
      type: "group",
      combinator,
      value: list4,
      accept(visitor, context = defaultContext) {
        return visitor.visitGroupExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createGroupExpression = createGroupExpression;
  __name(createGroupExpression, "createGroupExpression");
  function createQuerySelectExpression(groups, defaultContext) {
    return {
      type: "querySelect",
      value: groups,
      accept(visitor, context = defaultContext) {
        return visitor.visitQuerySelectExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createQuerySelectExpression = createQuerySelectExpression;
  __name(createQuerySelectExpression, "createQuerySelectExpression");
  function createListExpression(list4, defaultContext) {
    return {
      type: "list",
      value: list4,
      accept(visitor, context = defaultContext) {
        return visitor.visitListExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createListExpression = createListExpression;
  __name(createListExpression, "createListExpression");
})(QueryBuilder || (QueryBuilder = {}));
var Visitor2 = class {
  static {
    __name(this, "Visitor");
  }
};

// libs/compiler/transpilers/src/lib/ast.ts
import { camelcase as camelcase2 } from "stringcase";
var formatInput = /* @__PURE__ */ __name((input5) => input5.join("."), "formatInput");
function collectJoinsFromGroup(it) {
  const tablesNames = [];
  it.data.forEach((it2) => {
    if (it2.operator === "querySelect") {
      throw new Error("querySelect must not be inside a group");
    } else if (it2.operator === "group") {
      const groupJoins = collectJoinsFromGroup(it2);
      groupJoins.forEach((it3) => {
        if (!tablesNames.includes(it3)) {
          tablesNames.push(it3);
        }
      });
    } else if (it2.input.length === 2) {
      const tableOrColumn = it2.input[0];
      if (!tablesNames.includes(tableOrColumn) && it2.input.length === 2) {
        tablesNames.push(tableOrColumn);
      }
    }
  });
  return tablesNames;
}
__name(collectJoinsFromGroup, "collectJoinsFromGroup");
function collectJoins(query2) {
  const columns = query2.input ?? [];
  const groups = query2.data;
  const tablesFromSelect = (columns ?? []).map((it) => {
    if (it.name.split(".").length === 2) {
      return it.name.split(".")[0];
    }
    return "";
  }).filter((it) => it !== "");
  const tablesNames = [...tablesFromSelect];
  groups.forEach((group) => {
    collectJoinsFromGroup(group).forEach((it) => {
      if (!tablesNames.includes(it)) {
        tablesNames.push(it);
      }
    });
  });
  return tablesNames;
}
__name(collectJoins, "collectJoins");
function toAst(it) {
  const operator = it.operator;
  if (it.operator === "querySelect") {
    const columns = it.input ?? [];
    const groups = it.data;
    const groupsAst = [];
    for (const group of groups) {
      const combinator = group.input[0];
      if (combinator !== "and" && combinator !== "or") {
        throw new Error(`Invalid combinator ${combinator}`);
      }
      if (!group.data.length) {
        continue;
      }
      const groupAst = [];
      for (const item of group.data) {
        const result = toAst(item);
        if (result) groupAst.push(result);
      }
      groupsAst.push(
        QueryBuilder.createGroupExpression(
          groupAst,
          QueryBuilder.createCombinator(combinator)
        )
      );
    }
    return QueryBuilder.createQuerySelectExpression(groupsAst, {
      columns: columns ?? [],
      joinsFields: collectJoins(it)
    });
  }
  if (it.operator === "group") {
    const combinator = it.input[0];
    if (combinator !== "and" && combinator !== "or") {
      throw new Error(`Invalid combinator ${combinator}`);
    }
    if (!it.data.length) {
      return null;
    }
    const groupAst = [];
    for (const item of it.data) {
      const result = toAst(item);
      if (result) groupAst.push(result);
    }
    return QueryBuilder.createGroupExpression(
      groupAst,
      QueryBuilder.createCombinator(combinator)
    );
  }
  if (it.operator === "equals") {
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "===",
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "===",
      QueryBuilder.createIdentifier(it.input[0]),
      // QueryBuilder.createIdentifier('WILL_BE_USED_FROM_DESTRUCTURED_INPUT'),
      it.data
    );
  }
  if (it.operator === "one_of") {
    const oneOfArr = it.data.value;
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "in",
        QueryBuilder.createListExpression(oneOfArr.map((a) => pickLiteral(a))),
        { ...it.data, required: true }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "in",
      QueryBuilder.createListExpression(
        oneOfArr.map((a) => QueryBuilder.createIdentifier(a))
      ),
      it.data
    );
  }
  if (it.operator === "ends_with" || it.operator === "contains" || it.operator === "starts_with") {
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "like",
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "like",
      QueryBuilder.createIdentifier(it.data.value),
      it.data
    );
  }
  if (it.operator === "is") {
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "is",
      pickLiteral(it.data),
      {
        ...it.data,
        required: true
      }
    );
  }
  if (it.operator === "is_empty") {
    const combinator = it.data.inverse ? QueryBuilder.createCombinator("and") : QueryBuilder.createCombinator("or");
    const identifier = QueryBuilder.createIdentifier(formatInput(it.input));
    const nullBnryExpr = QueryBuilder.createBinaryExpression(
      identifier,
      "is",
      QueryBuilder.createNullLiteral(),
      {
        inverse: it.data.inverse,
        required: true
      }
    );
    if (it.data.type === "string") {
      const stringBnryExpr = QueryBuilder.createBinaryExpression(
        identifier,
        "is",
        QueryBuilder.createStringLiteral(""),
        {
          inverse: it.data.inverse,
          required: true
        }
      );
      return QueryBuilder.createGroupExpression(
        [stringBnryExpr, nullBnryExpr],
        combinator,
        {
          inverse: it.data.inverse
        }
      );
    } else {
      return QueryBuilder.createGroupExpression([nullBnryExpr], combinator, {
        inverse: it.data.inverse
      });
    }
  }
  const comparisonMap = {
    less_than: "<",
    more_than: ">",
    less_than_or_equal: "<=",
    more_than_or_equal: ">="
  };
  if (comparisonMap[operator]) {
    const sqlOperator = comparisonMap[operator];
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        sqlOperator,
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      sqlOperator,
      QueryBuilder.createIdentifier(it.data.value),
      // the ui should validate that the value is string in case of dynamic
      it.data
    );
  }
  const dateMap = {
    before: "<",
    after: ">",
    before_on: "<=",
    after_on: ">="
  };
  if (dateMap[operator]) {
    const sqlOperator = dateMap[operator];
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        sqlOperator,
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      sqlOperator,
      pickDateOperation(it.data),
      { ...it.data, required: true }
    );
  }
  if (it.operator === "between") {
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "between",
      QueryBuilder.createBinaryExpression(
        it.data.min.kind === "@fixed" ? QueryBuilder.createStringLiteral(it.data.min.value) : QueryBuilder.createIdentifier(it.data.min.value),
        "AND",
        it.data.max.kind === "@fixed" ? QueryBuilder.createStringLiteral(it.data.max.value) : QueryBuilder.createIdentifier(it.data.max.value)
      )
    );
  }
  throw new Error(`Operator is not supported. operator: ${it.operator}`);
}
__name(toAst, "toAst");
function pickLiteral(data) {
  switch (data.type) {
    case "string":
      return QueryBuilder.createStringLiteral(data.value);
    case "number":
      return QueryBuilder.createNumericLiteral(data.value);
    case "date":
      return QueryBuilder.createDateLiteral(data.value);
    case "boolean":
      return QueryBuilder.createBooleanLiteral(data.value);
    case "null":
      return QueryBuilder.createNullLiteral();
    default:
      if (data.static && data.value === "null") {
        return QueryBuilder.createNullLiteral();
      }
      throw new Error(`Data Type ${data.type} Not Supported`);
  }
}
__name(pickLiteral, "pickLiteral");
function pickDateOperation(data) {
  const { period, relativeTo, amount } = data;
  if (!["day", "week", "month", "quarter", "year"].includes(period)) {
    throw new Error(`Period ${period} Not Supported`);
  }
  if (!amount) {
    return QueryBuilder.createIdentifier(camelcase2(`current_${period}()`));
  }
  const args = [];
  if (relativeTo && relativeTo !== "now") {
    args.push(`date: '${relativeTo}'`);
  }
  args.push(`amount: ${amount}`);
  const argsObjectLiteral = `{ ${args.join(", ")} }`;
  return QueryBuilder.createIdentifier(`${period}(${argsObjectLiteral})`);
}
__name(pickDateOperation, "pickDateOperation");

// libs/compiler/transpilers/src/lib/factory.ts
var QueryFactory;
((QueryFactory2) => {
  function createEmptyGroupRule() {
    return {
      data: [],
      operator: "group",
      input: ["and"]
    };
  }
  QueryFactory2.createEmptyGroupRule = createEmptyGroupRule;
  __name(createEmptyGroupRule, "createEmptyGroupRule");
  function createGroupRule(combinator, data) {
    return {
      input: [combinator],
      operator: "group",
      data
    };
  }
  QueryFactory2.createGroupRule = createGroupRule;
  __name(createGroupRule, "createGroupRule");
  function createSelectRule(groups, columns) {
    return {
      operator: "querySelect",
      input: columns ?? [],
      data: groups
    };
  }
  QueryFactory2.createSelectRule = createSelectRule;
  __name(createSelectRule, "createSelectRule");
  function createIsEmptyRule(input5, data) {
    return {
      operator: "is_empty",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsEmptyRule = createIsEmptyRule;
  __name(createIsEmptyRule, "createIsEmptyRule");
  function createIsNotEmptyRule(input5, data) {
    return {
      operator: "is_empty",
      input: input5,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotEmptyRule = createIsNotEmptyRule;
  __name(createIsNotEmptyRule, "createIsNotEmptyRule");
  function createEqualRule(input5, data) {
    return {
      operator: "equals",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createEqualRule = createEqualRule;
  __name(createEqualRule, "createEqualRule");
  function createGreaterThanRule(input5, data) {
    return {
      operator: "more_than",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanRule = createGreaterThanRule;
  __name(createGreaterThanRule, "createGreaterThanRule");
  function createGreaterThanEqualRule(input5, data) {
    return {
      operator: "more_than_or_equal",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanEqualRule = createGreaterThanEqualRule;
  __name(createGreaterThanEqualRule, "createGreaterThanEqualRule");
  function createLessThanRule(input5, data) {
    return {
      operator: "less_than",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanRule = createLessThanRule;
  __name(createLessThanRule, "createLessThanRule");
  function createLessThanEqualRule(input5, data) {
    return {
      operator: "less_than_or_equal",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanEqualRule = createLessThanEqualRule;
  __name(createLessThanEqualRule, "createLessThanEqualRule");
  function createIsRule(input5, data) {
    return {
      operator: "is",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsRule = createIsRule;
  __name(createIsRule, "createIsRule");
  function createIsNotRule(input5, data) {
    return {
      operator: "is",
      input: input5,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotRule = createIsNotRule;
  __name(createIsNotRule, "createIsNotRule");
  function createNotEqualRule(input5, data) {
    return {
      operator: "equals",
      input: input5,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotEqualRule = createNotEqualRule;
  __name(createNotEqualRule, "createNotEqualRule");
  function createOneOfRule(input5, data) {
    return {
      operator: "one_of",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createOneOfRule = createOneOfRule;
  __name(createOneOfRule, "createOneOfRule");
  function createNotOneOfRule(input5, data) {
    return {
      operator: "one_of",
      input: input5,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotOneOfRule = createNotOneOfRule;
  __name(createNotOneOfRule, "createNotOneOfRule");
  function createBetweenRule(input5, data) {
    return {
      operator: "between",
      input: input5,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createBetweenRule = createBetweenRule;
  __name(createBetweenRule, "createBetweenRule");
  function createNotBetweenRule(input5, data) {
    return {
      operator: "between",
      input: input5,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotBetweenRule = createNotBetweenRule;
  __name(createNotBetweenRule, "createNotBetweenRule");
  function createContainRule(input5, data) {
    return {
      operator: "contains",
      input: input5,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createContainRule = createContainRule;
  __name(createContainRule, "createContainRule");
  function createMatchRule(input5, data) {
    return {
      operator: "contains",
      input: input5,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createMatchRule = createMatchRule;
  __name(createMatchRule, "createMatchRule");
  function createNotMatchRule(input5, data) {
    return {
      operator: "contains",
      input: input5,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotMatchRule = createNotMatchRule;
  __name(createNotMatchRule, "createNotMatchRule");
  function createNotContainRule(input5, data) {
    return {
      operator: "contains",
      input: input5,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotContainRule = createNotContainRule;
  __name(createNotContainRule, "createNotContainRule");
  function createStartsWithRule(input5, data) {
    return {
      operator: "starts_with",
      input: input5,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createStartsWithRule = createStartsWithRule;
  __name(createStartsWithRule, "createStartsWithRule");
  function createNotStartsWithRule(input5, data) {
    return {
      operator: "starts_with",
      input: input5,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotStartsWithRule = createNotStartsWithRule;
  __name(createNotStartsWithRule, "createNotStartsWithRule");
  function createEndsWithRule(input5, data) {
    return {
      operator: "ends_with",
      input: input5,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createEndsWithRule = createEndsWithRule;
  __name(createEndsWithRule, "createEndsWithRule");
  function createNotEndsWithRule(input5, data) {
    return {
      operator: "ends_with",
      input: input5,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotEndsWithRule = createNotEndsWithRule;
  __name(createNotEndsWithRule, "createNotEndsWithRule");
  function createPeriodRule(input5, operator, data) {
    return {
      operator,
      input: input5,
      data: {
        ...data,
        input: "",
        inverse: false
      }
    };
  }
  QueryFactory2.createPeriodRule = createPeriodRule;
  __name(createPeriodRule, "createPeriodRule");
  function createNotPeriodRule(input5, operator, data) {
    return {
      operator,
      input: input5,
      data: {
        ...data,
        input: "",
        inverse: true
      }
    };
  }
  QueryFactory2.createNotPeriodRule = createNotPeriodRule;
  __name(createNotPeriodRule, "createNotPeriodRule");
})(QueryFactory || (QueryFactory = {}));

// libs/compiler/transpilers/src/lib/visitors/js.visitor.ts
var JsVisitor = class extends Visitor2 {
  constructor(_rootExpr) {
    super();
    this._rootExpr = _rootExpr;
  }
  static {
    __name(this, "JsVisitor");
  }
  visitCombinator(expr, context) {
    return "";
  }
  visitListExpr(expr, context) {
    const list4 = expr.value.map((item) => item.accept(this, context));
    return list4.join(",");
  }
  visitQuerySelectExpr(expr, context) {
    return "";
  }
  visitGroupExpr(expr, context) {
    throw new Error("Method not implemented.");
  }
  visitDateLiteralExpr(expr, context = {}) {
    return expr.value;
  }
  visitBinaryExpr(expr, context) {
    const left = expr.left.accept(this, context);
    const right = expr.right.accept(this, context);
    switch (expr.operator) {
      case "===":
        return `(${left} === ${right})`;
      case "like":
        switch (context.pattern) {
          case "%{}":
            return `${left}.endsWith(${right})`;
          case "{}%":
            return `${left}.startsWith(${right})`;
          case "%{}%":
            return `${left}.includes(${right})`;
          default:
            throw new Error(
              `Like operator not supported. pattern: ${context.pattern}`
            );
        }
        break;
      default:
        throw new Error(
          `Expression is not supported. operator: ${expr.operator}`
        );
    }
  }
  visitNumericLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitNullLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitBooleanLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitStringLiteralExpr(expr) {
    return `"${expr.value}"`;
  }
  visitIdentifier(expr) {
    return `${expr.value}`;
  }
  execute() {
    return this.visitGroupExpr(this._rootExpr, {});
  }
};

// libs/compiler/sdk/devkit/src/lib/data/actions.json
var actions_default = [
  {
    id: "077b1325-0ade-4f63-8f66-ced39cef38ba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Atomic",
    name: "atomic",
    visible: true,
    multi: true,
    allowedActions: [],
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "9c858969-f48b-4b72-8282-bfe82654ae9a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Delete Record",
    name: "delete-record",
    visible: true,
    output: {
      displayName: "deletedRecord",
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    },
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      cascade: {
        displayName: "Cascade",
        type: "boolean",
        defaultValue: true,
        required: true,
        visible: false
      }
    }
  },
  {
    id: "b036bc50-9292-486a-9714-1f551fee5dc4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Record Exist",
    name: "check-record-existance",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "recordExists",
      source: [
        {
          id: "recordExists",
          primitiveType: "boolean",
          displayName: "recordExists"
        }
      ]
    }
  },
  {
    id: "83ce1e80-0117-4ebc-86ac-3bdad3b32796",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Insert Record",
    name: "insert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      columns: {
        displayName: "Payload",
        type: "columns-list",
        required: false,
        source: {
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ],
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "2bb630dd-7ba3-4cda-95a7-f65ee22116ee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Raw SQL Query",
    name: "raw-sql-query",
    metadata: {
      query: {
        displayName: "Query",
        type: "string",
        required: true
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "62e55ba2-9a81-4f88-995e-2093ca3fc067",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Upsert Record",
    name: "upsert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select"
      },
      columns: {
        displayName: "Payload",
        type: "columns-list"
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "a8ded515-b99e-4fca-9654-7d2c12624a7a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "increment-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "b5a5e901-9ef8-4d2c-86f2-39263ca8ebee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "decrement-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    output: {
      type: "context.tableId",
      displayName: "updatedRecord",
      source: []
    },
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Set Fields",
    name: "set-fields",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      columns: {
        displayName: "Field",
        type: "columns-list",
        required: true,
        source: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          },
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ]
        }
      }
    }
  },
  {
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    displayName: "With i18n",
    name: "i18n"
  },
  {
    id: "3c40908c-1c69-4222-a936-7a569a1198b5",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "Upload file to google storage",
    name: "upload-file",
    output: {
      displayName: "uploadedFile",
      source: []
    },
    metadata: {
      multiple: {
        displayName: "Can upload multiple files",
        type: "boolean",
        required: false,
        defaultValue: "@fixed:false"
      },
      maxFileCount: {
        displayName: "Maximum file count",
        type: "number",
        required: false,
        defaultValue: "@fixed:1",
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxTotalSize: {
        displayName: "Maximum total size",
        type: "number",
        required: false,
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxFileSize: {
        displayName: "Maximum file size",
        type: "number",
        required: false
      }
    }
  },
  {
    id: "c4ec127b-e167-4a30-8544-732c55d1bd24",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "List Records",
    name: "list-records",
    metadata: {
      localizable: {
        displayName: "Localizable",
        type: "boolean",
        required: false,
        fieldset: "first",
        visible: false,
        defaultValue: "false"
      },
      pagination: {
        displayName: "Pagination",
        type: "single-select",
        required: true,
        fieldset: "pagination",
        defaultValue: "deferred_joins",
        source: [
          {
            id: "none",
            displayName: "None"
          },
          {
            id: "limit_offset",
            displayName: "Limit & Offset"
          },
          {
            id: "deferred_joins",
            displayName: "Deferred Joins"
          },
          {
            id: "cursor",
            displayName: "Cursor"
          }
        ]
      },
      tableId: {
        displayName: "Table",
        type: "single-select",
        fieldset: "first",
        required: true,
        source: {
          url: "/tables"
        }
      },
      limit: {
        displayName: "Limit",
        type: "number",
        required: false,
        fieldset: "pagination",
        defaultValue: 50
      },
      query: {
        displayName: "Query",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      source: {
        input: "context.pagination",
        operator: "equal",
        value: "none",
        then: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        },
        else: [
          {
            id: "records",
            displayName: "records",
            primitiveType: {
              input: "context.limit",
              operator: "equal",
              value: 1,
              then: "object",
              else: "array"
            },
            typeName: {
              url: "/tables/:id",
              binding: {
                id: "context.tableId"
              },
              use: "displayName"
            },
            interface: {
              url: "/tables/:id/fields",
              binding: {
                id: "context.tableId"
              }
            },
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          },
          {
            id: "meta",
            displayName: "meta",
            typeName: "Meta",
            primitiveType: "object",
            interface: [
              {
                id: "hasNextPage",
                displayName: "hasNextPage",
                primitiveType: "boolean"
              },
              {
                id: "hasPreviousPage",
                displayName: "hasPreviousPage",
                primitiveType: "boolean"
              },
              {
                id: "pageSize",
                displayName: "pageSize",
                primitiveType: "number"
              },
              {
                id: "currentPage",
                displayName: "currentPage",
                primitiveType: "number"
              },
              {
                id: "totalCount",
                displayName: "totalCount",
                primitiveType: "number"
              },
              {
                id: "totalPages",
                displayName: "totalPages",
                primitiveType: "number"
              }
            ],
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          }
        ]
      }
    }
  },
  {
    id: "89ad4cdb-2ed1-4c42-84bd-4986648bbfe2",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "List Files",
    name: "list-files",
    output: {
      displayName: "files",
      source: []
    },
    metadata: {
      prefix: {
        displayName: "Prefix",
        type: "string",
        required: false,
        fieldset: "first"
      },
      flat: {
        displayName: "Flat",
        type: "boolean",
        required: false,
        fieldset: "first"
      }
    }
  },
  {
    id: "43ea3f72-f3b0-419f-abef-f1bd4b5e9b22",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Custom Code",
    name: "custom-code",
    output: {
      source: []
    },
    metadata: {
      code: {
        displayName: "Code",
        type: "code-editor",
        required: true,
        extras: {
          language: "typescript"
        }
      }
    }
  },
  {
    id: "e0c60892-6b26-417e-8140-8e8d31f64ab2",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Branch",
    name: "branch",
    type: "branch",
    multi: true,
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "89e16a38-25f1-444e-bcf7-96e6455c3707",
    extensionId: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    displayName: "Send Email",
    name: "send-email",
    output: {
      outputName: "sentEmail",
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        required: true,
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        required: true,
        fieldset: "email"
      },
      replayTo: {
        displayName: "Replay To",
        type: "string",
        required: false
      },
      subject: {
        displayName: "Subject",
        type: "string",
        required: true,
        fieldset: "content"
      },
      templateId: {
        displayName: "Template",
        type: "string",
        fieldset: "content",
        required: true
      }
    }
  },
  {
    id: "69a01ada-a83a-451f-a3fe-fb486e08ffa9",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Send Email",
    name: "resend-send-email",
    output: {
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      subject: {
        displayName: "Subject",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "content"
      },
      text: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      html: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "c292a9d7-1f66-47b9-b366-e25f3faff840",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Create Contact",
    name: "resend-create-contact",
    output: {
      source: []
    },
    metadata: {
      firstName: {
        displayName: "First name",
        type: "string",
        fieldset: "general"
      },
      lastName: {
        displayName: "Last name",
        type: "string",
        required: false,
        fieldset: "general"
      },
      email: {
        displayName: "Email",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      unsubscribed: {
        displayName: "Unsubscribed",
        type: "string",
        required: false,
        fieldset: "email"
      },
      audienceId: {
        displayName: "Audience id",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b",
    extensionId: "389d81cd-5b58-4ade-b815-add468c48e37",
    displayName: "Ajax",
    name: "ajax",
    output: {
      source: []
    },
    metadata: {
      url: {
        displayName: "URL",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      method: {
        displayName: "Method",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      body: {
        displayName: "Body",
        type: "json",
        required: false
      }
    }
  },
  {
    id: "7a9d9a29-7079-4aa8-bdc0-d93a713a2440",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger",
    metadata: {
      path: {
        fieldset: "config",
        type: "string",
        displayName: "Path",
        required: true,
        pattern: "^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"
      },
      method: {
        fieldset: "config",
        displayName: "Method",
        type: "single-select",
        source: [
          {
            id: "get",
            displayName: "GET"
          },
          {
            id: "post",
            displayName: "POST"
          },
          {
            id: "put",
            displayName: "PUT"
          },
          {
            id: "patch",
            displayName: "PATCH"
          },
          {
            id: "delete",
            displayName: "DELETE"
          },
          {
            id: "head",
            displayName: "HEAD"
          }
        ],
        required: true
      },
      contentType: {
        visible: false,
        fieldset: "optional",
        type: "single-select",
        displayName: "Content Type",
        required: false,
        source: [
          {
            id: "application/json",
            displayName: "application/json"
          },
          {
            id: "application/x-www-form-urlencoded",
            displayName: "application/x-www-form-urlencoded"
          },
          {
            id: "multipart/form-data",
            displayName: "multipart/form-data"
          }
        ]
      },
      summary: {
        fieldset: "optional",
        type: "string",
        displayName: "Summary",
        required: false,
        visible: false
      }
    }
  },
  {
    id: "0aec7685-5c19-43eb-bc2c-93597b5cecfc",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    id: "6432f258-6511-4d8a-86a6-628db3f333e7",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    id: "7b1696e9-9c89-4ba7-abc0-e1448b287772",
    extensionId: "9c034274-069e-4567-ab33-bab8f31f874c",
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    id: "11e4e048-cf30-4fa1-b0ff-25baa7a5f416",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "File Trigger",
    name: "file",
    type: "trigger"
  },
  {
    id: "0bd0b432-5f7a-447a-afab-6db83d8976b1",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    id: "cd76caa3-e9f0-49b8-bf7a-0ebed83bd486",
    extensionId: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/extensions.json
var extensions_default = [
  {
    id: "e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b",
    visible: false,
    name: "soft-delete",
    categories: ["soft-delete"],
    title: "",
    subtitle: "Support Soft Delete functionality in any table.",
    description: "Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.",
    tableMetadata: {
      tableId: {
        displayName: "Support Soft Delete",
        required: false,
        visible: false,
        type: "single-select",
        source: [
          {
            id: "none",
            displayName: "No soft delete"
          },
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag"
          },
          {
            id: "trash",
            displayName: "Using trash table"
          }
        ]
      }
    },
    metadata: {}
  },
  {
    id: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    visible: true,
    name: "core",
    categories: ["misc"],
    title: "Core",
    main: "src/core/validation.ts",
    subtitle: "Core functionality",
    metadata: {},
    description: "Essential functionality that is required for all projects."
  },
  {
    id: "977a059f-ddda-4677-b785-4d1b04a7c201",
    visible: true,
    name: "prettier",
    categories: ["misc"],
    title: "Prettier",
    subtitle: "An opinionated code formatter",
    description: "Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.",
    logo: "assets/prettier.png",
    metadata: {}
  },
  {
    id: "e81b26bb-051b-4b30-a94d-e34ad615504c",
    visible: true,
    name: "identity",
    categories: ["misc"],
    title: "identity",
    subtitle: "identity",
    description: "",
    metadata: {}
  },
  {
    id: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "postgresql",
    categories: ["database"],
    main: "src/extensions/postgresql/index.ts",
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "PostgreSQL",
    subtitle: "A free and open-source relational database management system emphasizing extensibility and SQL compliance.",
    description: "PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "71c97a1c-3efe-4712-b35b-56714dafa02f",
    name: "mysql",
    categories: ["database"],
    disabled: true,
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "MySQL",
    description: "MySQL is an open-source relational database management system.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    name: "firebase-functions",
    categories: ["hosting"],
    disabled: true,
    logo: "assets/firebase-functions.png",
    svg: "SiFirebase",
    title: "Firebase Functions",
    subtitle: "Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code",
    description: "Firebase Functions is a serverless framework that lets you automatically run backend code.",
    metadata: {
      FIREBASE_FUNCTION_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"
      }
    }
  },
  {
    id: "d9e83836-e41d-4ae2-aa93-229a0ef27069",
    name: "firebase-auth",
    categories: ["identity"],
    disabled: false,
    main: "firebase.ts",
    metadata: {
      FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"
      }
    },
    title: "Firebase Authentication",
    description: "Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.",
    subtitle: "Authenticate users with Firebase"
  },
  {
    id: "34d9ec05-de0d-4d79-ae2a-9a06200d20dd",
    name: "fly",
    categories: ["hosting"],
    logo: "assets/fly.png",
    title: "Fly",
    description: "Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.",
    metadata: {
      FLY_API_TOKEN: {
        displayName: "Deploy Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_API_TOKEN",
        description: "The token to deploy the app"
      },
      FLY_APP_NAME: {
        displayName: "App Name",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_APP_NAME",
        description: "The name of the app"
      }
    }
  },
  {
    name: "vercel",
    id: "4c82c872-1a2f-4849-98a6-bd7017498191",
    categories: ["hosting"],
    title: "Vercel",
    description: "Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.",
    metadata: {
      VERCEL_ORG_ID: {
        displayName: "Org ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_ORG_ID"
      },
      VERCEL_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_PROJECT_ID"
      },
      VERCEL_API_TOKEN: {
        displayName: "API Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_API_TOKEN"
      }
    }
  },
  {
    id: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    name: "hono",
    categories: ["routing"],
    title: "Hono.dev",
    main: "src/extensions/tus/index.ts",
    description: "Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.",
    metadata: {}
  },
  {
    id: "109aa1af-f9d0-4d31-bbc6-c4603be5b7b0",
    name: "koajs",
    disabled: true,
    categories: ["routing"],
    title: "Koa.js",
    description: "Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.",
    logo: "assets/http.svg",
    metadata: {},
    svg: "SiKoa",
    packages: [
      {
        name: "koa",
        version: "latest"
      },
      {
        name: "koa-static",
        version: "latest"
      },
      {
        name: "@types/koa-static",
        version: "latest"
      },
      {
        name: "@koa/router",
        version: "latest"
      },
      {
        name: "koa-body",
        version: "latest"
      },
      {
        name: "koa-bodyparser",
        version: "latest"
      },
      {
        name: "koa-logger",
        version: "latest"
      },
      {
        name: "koa-qs",
        version: "latest"
      },
      {
        name: "@koa/cors",
        version: "latest"
      },
      {
        name: "@types/koa-logger",
        version: "latest"
      },
      {
        name: "@types/koa__cors",
        version: "^3.3.0"
      },
      {
        name: "@types/koa__router",
        version: "^12.0.0"
      },
      {
        name: "@types/koa-bodyparser",
        version: "^4.3.10"
      },
      {
        name: "@types/koa-qs",
        version: "^2.0.0"
      },
      {
        name: "swagger-ui-dist",
        version: "latest"
      },
      {
        name: "@types/swagger-ui-dist",
        version: "latest"
      }
    ]
  },
  {
    id: "3633c476-c120-4f9f-893b-b6b03f67b9e9",
    name: "expressjs",
    svg: "SiExpress",
    disabled: true,
    categories: ["routing"],
    title: "Express.js",
    description: "Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
    logo: "assets/http.svg",
    metadata: {},
    packages: [
      {
        name: "express",
        version: "latest"
      },
      {
        name: "body-parser",
        version: "latest"
      },
      {
        name: "morgan",
        version: "latest"
      },
      {
        name: "cors",
        version: "latest"
      },
      {
        name: "@types/express",
        version: "latest",
        dev: true
      },
      {
        name: "@types/body-parser",
        version: "latest",
        dev: true
      },
      {
        name: "@types/cors",
        version: "latest",
        dev: true
      },
      {
        name: "@types/morgan",
        version: "latest",
        dev: true
      }
    ]
  },
  {
    id: "3e184f8b-d2dc-4592-9507-979d649277f5",
    visible: true,
    name: "gcs",
    categories: ["file-storage"],
    logo: "assets/cloud-storage.svg",
    title: "Google Cloud Storage",
    description: "Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google's cloud with advanced security and sharing capabilities.",
    main: "src/extensions/gcs/index.ts",
    metadata: {
      BUCKET_NAME: {
        _comment: "// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won't work",
        displayName: "Bucket Name",
        type: "string",
        required: true,
        description: "The name of the bucket"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        type: "json",
        description: "The service account key to access the bucket",
        required: true
      }
    }
  },
  {
    id: "9c034274-069e-4567-ab33-bab8f31f874c",
    visible: true,
    name: "github",
    categories: [],
    title: "GitHub Webhooks",
    description: "GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com",
    metadata: {
      WEBHOOK_SECRET: {
        displayName: "Webhook Secret",
        defaultValue: "@process:env.WEBHOOK_SECRET",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    visible: true,
    name: "node-cron",
    categories: ["schedulers"],
    title: "Node Cron",
    description: "A simple cron-like job scheduler for Node.js",
    metadata: {},
    packages: [
      {
        name: "@types/node-cron",
        version: "^3.0.11",
        dev: true
      },
      {
        name: "node-cron",
        version: "^3.0.3"
      }
    ]
  },
  {
    id: "389d81cd-5b58-4ade-b815-add468c48e37",
    visible: true,
    disabled: true,
    name: "ajax",
    categories: ["misc"],
    logo: "assets/ajax.png",
    title: "Ajax",
    description: "Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.",
    metadata: {},
    svg: "SiAjax"
  },
  {
    id: "8c438fcd-b8c0-444e-9100-24abd93a6bcb",
    visible: true,
    disabled: true,
    name: "sqlite",
    categories: ["database"],
    main: "src/extensions/sqlite/index.ts",
    title: "Sqlite",
    description: "Sqlite is a relational database management system.",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "23bfb249-0149-4033-a2a9-2dbec614d461",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "bytes",
    primitiveType: "Uint8Array",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      }
    },
    initialValidation: []
  },
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/operators.json
var operators_default = [
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Equal To",
    name: "equals",
    metadata: {}
  },
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Not Equal To",
    name: "not_equals",
    metadata: {}
  },
  {
    id: "f3d3c1af-0066-4884-8533-917ec2c71fd1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "One Of",
    name: "one_of",
    metadata: {}
  },
  {
    id: "f56f9948-7745-4203-928f-e75c481d13d8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Between",
    name: "between",
    metadata: {}
  },
  {
    id: "c2e22f65-ce15-42cc-a99f-7e5bca84b69f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "63ec8fb7-357f-403a-b753-6df8a3f25737",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "More Than",
    name: "more_than",
    metadata: {}
  },
  {
    id: "162eedc3-3ace-48c2-8a38-0c1db9058d8a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    name: "contains",
    metadata: {}
  },
  {
    id: "60e18406-a4a7-44a4-8b91-2481710fb4e8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    name: "starts_with",
    metadata: {}
  },
  {
    id: "d3b7f462-d154-4bfa-8645-3f74a958bed6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    name: "ends_with",
    metadata: {}
  },
  {
    id: "d1a02de2-8928-4517-884d-502bdb8d8409",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "fa2b1831-9ceb-4808-984e-1f834a723c56",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Greater Than",
    name: "greater-than",
    metadata: {}
  },
  {
    id: "a2c10af5-c9dd-401c-b28c-59bb48c85345",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Not Empty",
    name: "is_not_empty",
    metadata: {}
  },
  {
    id: "8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Empty",
    name: "is_empty",
    metadata: {}
  },
  {
    id: "73963f47-092a-4bf2-a38a-50dca50ca5e6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before",
    name: "before",
    metadata: {}
  },
  {
    id: "a830cb78-e9f2-4259-9753-d6259bea1bed",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before On",
    name: "before_on",
    metadata: {}
  },
  {
    id: "d23be707-a71d-44bd-8b61-9489e84f1a2d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After On",
    name: "after_on",
    metadata: {}
  },
  {
    id: "8648374e-f78a-4322-ac67-67467d4fbff5",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After",
    name: "after",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var DevKit = class {
  getDeps() {
    const exts = this.extensions();
    const dependencies = exts.map((it) => it.packages ?? []).flat();
    const possibleDeps = [
      {
        name: "discord.js",
        version: "^14.15.3",
        dev: false
      }
    ];
    return [...dependencies, ...possibleDeps].reduce((acc, it) => {
      return {
        ...acc,
        [it.name]: it.version
      };
    }, {});
  }
  getExtensionActions(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return actions_default.filter((it) => it.extensionId === id);
  }
  actions() {
    return actions_default;
  }
  async getExtensionTriggers(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return (await this.triggers()).filter((it) => it.extensionId === id);
  }
  async triggers() {
    return (await this.actions()).filter((it) => it.type === "trigger");
  }
  extensions() {
    return extensions_default;
  }
  toJson(obj) {
    return JSON.stringify(obj, null, 2);
  }
  async getValidationsByIds(ids) {
    const validations = await this.validations();
    const list4 = [];
    for (const id of ids) {
      const validation2 = validations.find((it) => it.id === id);
      if (!validation2) {
        throw new Error(`Validation with id ${id} not found`);
      }
      list4.push(validation2);
    }
    return list4;
  }
  async getValidationsByNames(names) {
    const validations = await this.validations();
    const list4 = [];
    for (const name of names) {
      const validation2 = validations.find((it) => it.name === name);
      if (!validation2) {
        throw new Error(`Validation with name ${name} not found`);
      }
      list4.push(validation2);
    }
    return list4;
  }
  async getFieldsByExtension() {
    return await this.fields();
  }
  fields() {
    return fields_default;
  }
  validations() {
    return validations_default;
  }
  operators() {
    return operators_default;
  }
};
__name(DevKit, "DevKit");
DevKit = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], DevKit);
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input5, sub) {
  const index2 = input5.indexOf(sub);
  if (index2 === -1) {
    return input5;
  }
  return input5.slice(sub.length);
}
__name(substring, "substring");
function getSourceActionById(id) {
  const action = actions_default.find((it) => it.id === id);
  if (!action) {
    throw new Error(`Action with id ${id} not found`);
  }
  return action;
}
__name(getSourceActionById, "getSourceActionById");
function getExtensionById(id) {
  const item = extensions_default.find((it) => it.id === id);
  if (!item) {
    throw new Error(`Extension with id ${id} not found`);
  }
  return item;
}
__name(getExtensionById, "getExtensionById");
function getValidationByName(name) {
  const validation2 = validations_default.find((a) => a.name === name);
  if (!validation2) {
    throw new Error(`Validation with name ${name} not found`);
  }
  return validation2;
}
__name(getValidationByName, "getValidationByName");
function getSourceFieldById(id) {
  const field2 = fields_default.find((it) => it.id === id);
  if (!field2) {
    throw new Error(`Field with id ${id} not found`);
  }
  return field2;
}
__name(getSourceFieldById, "getSourceFieldById");
function getSourceFieldByName(name) {
  const field2 = fields_default.find((it) => it.name === name);
  if (!field2) {
    throw new Error(`Field with name ${name} not found`);
  }
  return field2;
}
__name(getSourceFieldByName, "getSourceFieldByName");
function assignDefaults(metadata, details) {
  Object.entries(metadata ?? {}).forEach(([name, config2]) => {
    if (details[name] === void 0 && config2.defaultValue !== void 0) {
      details[name] = config2.defaultValue;
    }
  });
  return details;
}
__name(assignDefaults, "assignDefaults");
function getTriggerByName(name) {
  const trigger2 = actions_default.find(
    (it) => it.type === "trigger" && it.name === name
  );
  if (!trigger2) {
    throw new Error(`Trigger with name ${name} not found`);
  }
  return trigger2;
}
__name(getTriggerByName, "getTriggerByName");
function getValidationById(id) {
  const validation2 = validations_default.find((it) => it.id === id);
  if (!validation2) {
    throw new Error(`Validation with id ${id} not found`);
  }
  return validation2;
}
__name(getValidationById, "getValidationById");
function getSourceActionByName(name) {
  if (isNullOrUndefined(name)) {
    throw new Error(
      "getSourceActionByName:name is required. received: " + name
    );
  }
  const action = actions_default.find((it) => it.name === name);
  if (!action) {
    throw new Error(`Action with name ${name} not found`);
  }
  return action;
}
__name(getSourceActionByName, "getSourceActionByName");
function getExtensionByName(name) {
  const item = extensions_default.find((it) => it.name === name);
  if (!item) {
    throw new Error(`Extension with name ${name} not found`);
  }
  return item;
}
__name(getExtensionByName, "getExtensionByName");

// libs/compiler/sdk/devkit/src/lib/project-config.ts
var _config;
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
__name(ProjectConfig, "ProjectConfig");
ProjectConfig = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join8 } from "path";
import { Injectable as Injectable3, Injector, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
var config = {
  basePath: "./src",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  _projectConfig = Injector.GetRequiredService(ProjectConfig);
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = /* @__PURE__ */ __name((importPath) => {
    return join8("#{relative}", config.basePath, importPath);
  }, "makeCoreImportSpecifier");
  makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
    return join8("#{entity}", pascalcase(tableName));
  }, "makeEntityImportSpecifier");
  makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join8(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
  makeCorePath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "core", fileName), "makeCorePath");
  makeIdentityPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "identity", fileName), "makeIdentityPath");
  makeSrcPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, fileName), "makeSrcPath");
  makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join8(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  ), "makeWorkspacePath");
  makeRootPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "../", fileName), "makeRootPath");
  makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join8(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  ), "makeCommandPath");
  makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => this.makeFeatureFile(featureName, join8(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
  makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  ), "makeControllerPath");
  makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join8("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  ), "makeControllerRoutePath");
  makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join8("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  ), "makeListenerRoutePath");
  makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join8("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  ), "makeJobRoutePath");
  makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join8(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  ), "makeEntityPath");
  makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join8(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  ), "makeQueryPath");
  makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
};
__name(ProjectFS, "ProjectFS");
ProjectFS = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], ProjectFS);
var commandsGlob = /* @__PURE__ */ __name(() => {
  return `${config.features}/**/*.command.ts`;
}, "commandsGlob");
var routersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.router.ts";
}, "routersGlob");
var listenersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.github.ts";
}, "listenersGlob");
var cronsGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.cron.ts";
}, "cronsGlob");
var entitiesGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.entity.ts";
}, "entitiesGlob");
var makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join8(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
var makeCorePath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "core", fileName), "makeCorePath");
var makeIdentityPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "identity", fileName), "makeIdentityPath");
var makeSrcPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, fileName), "makeSrcPath");
var makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join8(
  config.basePath,
  "../",
  /** We need this to work with new january cli */
  "../",
  fileName
), "makeWorkspacePath");
var makeRootPath = /* @__PURE__ */ __name((fileName) => join8(config.basePath, "../", fileName), "makeRootPath");
var makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => makeFeatureFile(
  featureName,
  join8(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
), "makeCommandPath");
var makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => makeFeatureFile(featureName, join8(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
var makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join8("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
), "makeControllerRoutePath");
var makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join8("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
), "makeListenerRoutePath");
var makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join8("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
), "makeJobRoutePath");
var makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join8(
  config.features,
  spinalcase2(featureName),
  `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
), "makeEntityPath");
var makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join8(
  config.features,
  spinalcase2(tableName),
  "queries",
  `${spinalcase2(queryName)}.query.ts`
), "makeQueryPath");
var makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
var makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
  return join8("#{entity}", pascalcase(tableName));
}, "makeEntityImportSpecifier");
var makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
), "makeControllerPath");
var makeFeaturePath = /* @__PURE__ */ __name((fileName) => join8(config.features, fileName), "makeFeaturePath");

// libs/sdk/declarative/src/lib/utils.ts
import { Project, StructureKind, SyntaxKind } from "ts-morph";
function isValidIdentifier(property) {
  const regex = /^[a-zA-Z_$][0-9a-zA-Z_$]*$/;
  return regex.test(property);
}
__name(isValidIdentifier, "isValidIdentifier");
function createPathProxy(path = "###$$$###") {
  return new Proxy(
    () => {
    },
    {
      get(target, property) {
        if (property === "valueOf") {
          return () => path;
        }
        if (property === Symbol.toPrimitive) {
          return (hint) => {
            if (hint === "string") {
              return path;
            }
            throw new Error("Invalid hint");
          };
        }
        if (path === "###$$$###") {
          return createPathProxy(`@trigger:` + String(property));
        }
        return createPathProxy(
          path + (typeof property === "string" ? isValidIdentifier(property) ? `.${property}` : `['${property}']` : `.${String(property)}`)
        );
      },
      apply(target, thisArg, argumentsList) {
        const argsString = argumentsList.map((arg) => JSON.stringify(arg)).join(", ");
        return createPathProxy(path + `(${argsString})`);
      }
    }
  );
}
__name(createPathProxy, "createPathProxy");
function createEnvProxy() {
  return new Proxy(process.env, {
    get(target, property, receiver) {
      if (typeof property === "string") {
        return `process.env.${property}`;
      }
      return Reflect.get(target, property, receiver);
    }
  });
}
__name(createEnvProxy, "createEnvProxy");
function getErrors(fn) {
  try {
    fn();
    return [];
  } catch (e) {
    return [e].flat();
  }
}
__name(getErrors, "getErrors");
function coerceString(value) {
  if (value === void 0 || value === null) {
    return value;
  }
  if (typeof value === "number") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.join(".");
  }
  return value.valueOf();
}
__name(coerceString, "coerceString");
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${arg})`;
  const guard = transferable.toString();
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind.ArrowFunction);
  const inputs = {};
  const parameters = guardFunction.getParameters();
  if (parameters.length > 1) {
    inputs["request"] = {
      static: true,
      type: "IncomingMessage",
      value: `(context.env as { incoming: IncomingMessage }).incoming`,
      data: {
        parameterName: "request",
        standalone: true
      },
      structure: [
        {
          kind: StructureKind.ImportDeclaration,
          moduleSpecifier: "http",
          namedImports: ["IncomingMessage"]
        }
      ]
    };
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!parent) {
      inputs["trigger"] = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs[v] = {
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()"
      }
    };
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = /* @__PURE__ */ __name((ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  }, "isOutputReturn");
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  for (const ret of returns) {
    if (isOutputReturn(ret)) {
      continue;
    }
    const isReturningCall = ret.getExpressionIfKind(SyntaxKind.CallExpression);
    let returnValue = ret.getText().trim().replace("return ", "");
    if (returnValue.endsWith(";")) {
      returnValue = returnValue.slice(0, -1);
    }
    if (returnValue === "return") {
      ret.replaceWithText(options.setOutput());
    } else {
      ret.replaceWithText(
        options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
      );
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs
  };
}
__name(refineExecute, "refineExecute");

// libs/sdk/declarative/src/lib/query.ts
function where(column, operator, value) {
  const columnName = coerceColumnName(column);
  let condition;
  value = coerceString(value);
  switch (operator) {
    case "after":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "after",
        value
      );
      break;
    case "before":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "before",
        value
      );
      break;
  }
  if (condition) {
    return {
      kind: "condition",
      implementation: condition
    };
  }
  if (typeof value !== "string") {
    throw new Error(`Value ${value} is not supported`);
  }
  const data = {
    type: "string",
    input: value
  };
  switch (operator) {
    case "equals":
      condition = QueryFactory.createEqualRule([columnName], data);
      break;
    case "not_equals":
      condition = QueryFactory.createNotEqualRule([columnName], data);
      break;
    case "more_than":
      condition = QueryFactory.createGreaterThanRule([columnName], data);
      break;
    case "less_than":
      condition = QueryFactory.createLessThanRule([columnName], data);
      break;
    case "more_than_or_equal":
      condition = QueryFactory.createGreaterThanEqualRule([columnName], data);
      break;
    case "less_than_or_equal":
      condition = QueryFactory.createLessThanEqualRule([columnName], data);
      break;
    case "is":
      condition = QueryFactory.createIsRule([columnName], data);
      break;
    case "is_not_empty":
      condition = QueryFactory.createIsNotEmptyRule([columnName], data);
      break;
    case "is_empty":
      condition = QueryFactory.createIsEmptyRule([columnName], data);
      break;
    case "contains":
      condition = QueryFactory.createContainRule([columnName], data);
      break;
    case "starts_with":
      condition = QueryFactory.createStartsWithRule([columnName], data);
      break;
    case "ends_with":
      condition = QueryFactory.createEndsWithRule([columnName], data);
      break;
    default:
      throw new Error(`Operator ${operator} is not supported`);
  }
  return {
    kind: "condition",
    implementation: condition
  };
}
__name(where, "where");
function sort(name, input5) {
  return {
    kind: "sort",
    implementation: {
      id: coerceColumnName(name),
      input: input5.startsWith("@fixed") ? input5 : `@fixed:${input5}`
    }
  };
}
__name(sort, "sort");
function isKind(featureOrKind, kind) {
  if (!featureOrKind) {
    return false;
  }
  if (typeof featureOrKind === "string") {
    return (feature2) => feature2 && feature2.kind === featureOrKind;
  }
  return featureOrKind.kind === kind;
}
__name(isKind, "isKind");
function assertKind(feature2, kind, label) {
  if (!feature2 || feature2.kind !== kind) {
    throw new Error(label ?? `Expected ${kind} feature`);
  }
}
__name(assertKind, "assertKind");
function query(...features) {
  const sorts = features.filter(isKind("sort"));
  const columns = features.filter((f) => f.kind === "select").map((f) => f.implementation);
  const conditions = features.filter(isKind("condition"));
  const groups = [
    ...features.filter((f) => f.kind === "group"),
    and(...conditions)
    // wrap this in an "and" group to simulate implicit "and" condition
  ].map((f) => f.implementation);
  const limit2 = features.find(isKind("limit"))?.implementation;
  return {
    whereBy: QueryFactory.createSelectRule(groups, columns),
    sortBy: sorts.map((it) => it.implementation),
    limit: limit2
  };
}
__name(query, "query");
query.sql = (sql) => {
};
function select(name) {
  return {
    kind: "select",
    implementation: {
      name
    }
  };
}
__name(select, "select");
function and(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("and", rules)
  };
}
__name(and, "and");
function or(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("or", rules)
  };
}
__name(or, "or");
var coerceColumnName = /* @__PURE__ */ __name((column) => {
  if (!column.startsWith("@tables")) {
    return `@tables:fields.${column}`;
  }
  return column;
}, "coerceColumnName");
var date;
((date2) => {
  let after;
  ((after2) => {
    function startOfThisWeek() {
      return weeksAgo(0);
    }
    after2.startOfThisWeek = startOfThisWeek;
    __name(startOfThisWeek, "startOfThisWeek");
    function weekAgo() {
      return weeksAgo(1);
    }
    after2.weekAgo = weekAgo;
    __name(weekAgo, "weekAgo");
    function weeksAgo(amount, relativeTo = "now") {
      return {
        period: "week",
        amount: -Math.abs(amount),
        relativeTo
      };
    }
    after2.weeksAgo = weeksAgo;
    __name(weeksAgo, "weeksAgo");
    function weekInYear(n, relativeTo = "now") {
    }
    __name(weekInYear, "weekInYear");
    function monthInYear(n) {
    }
    __name(monthInYear, "monthInYear");
    function startOfThisMonth() {
      return monthsAgo(0);
    }
    after2.startOfThisMonth = startOfThisMonth;
    __name(startOfThisMonth, "startOfThisMonth");
    function monthAgo() {
      return monthsAgo(1);
    }
    after2.monthAgo = monthAgo;
    __name(monthAgo, "monthAgo");
    function monthsAgo(amount) {
      return {
        period: "month",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.monthsAgo = monthsAgo;
    __name(monthsAgo, "monthsAgo");
    function startOfThisYear() {
      return yearsAgo(0);
    }
    after2.startOfThisYear = startOfThisYear;
    __name(startOfThisYear, "startOfThisYear");
    function yearAgo() {
      return yearsAgo(1);
    }
    after2.yearAgo = yearAgo;
    __name(yearAgo, "yearAgo");
    function yearsAgo(amount) {
      return {
        period: "year",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.yearsAgo = yearsAgo;
    __name(yearsAgo, "yearsAgo");
  })(after = date2.after || (date2.after = {}));
})(date || (date = {}));
function limit(upTo) {
  return {
    kind: "limit",
    implementation: upTo
  };
}
__name(limit, "limit");

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config2 = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config2.message
    }
  };
}
__name(mandatory, "mandatory");
var required = mandatory;
function unique(config2 = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config2.message
      }
    }
  ];
}
__name(unique, "unique");
function defineValidation(config2) {
  return {
    name: config2.name,
    config: config2
  };
}
__name(defineValidation, "defineValidation");
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config2) {
  const additionalFields = {};
  const idField = Object.values(config2.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config2.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config2.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config2.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config2.fields,
      ...additionalFields
    },
    constraints: config2.constraints || []
  };
}
__name(table, "table");
table.unique = (...fields) => {
  return {
    type: "unique",
    details: {
      columns: fields
    }
  };
};
table.index = (...fields) => {
  return {
    type: "index",
    details: {
      columns: fields
    }
  };
};
table.use = useTable;
function useTable(name) {
  return {
    command: "QueryTable",
    payload: {
      name
    }
  };
}
__name(useTable, "useTable");
function field(config2) {
  const { type, validations = [], metadata = {}, ...rest } = config2;
  return {
    type: config2.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
__name(field, "field");
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      if (type.endsWith(".rule")) {
        const reports = [];
        return reports;
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
  function primary(config2) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config2.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config2.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  __name(primary, "primary");
  function shortText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  __name(shortText, "shortText");
  function longText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  __name(longText, "longText");
  function datetime(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  __name(datetime, "datetime");
  function url(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  __name(url, "url");
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  __name(integer, "integer");
  function decimal(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  __name(decimal, "decimal");
  function price(config2 = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config2;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  __name(price, "price");
  function boolean(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  __name(boolean, "boolean");
  function bytes(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  __name(bytes, "bytes");
  function relation(config2) {
    return field2({
      type: "relation",
      metadata: config2,
      validations: config2.validations
    });
  }
  field2.relation = relation;
  __name(relation, "relation");
})(field || (field = {}));
field.enum = (config2) => {
  return field({
    type: "single-select",
    metadata: {
      style: "enum",
      values: config2.values,
      defaultValue: config2.defaultValue
    }
  });
};
function useField(name, value) {
  value = coerceString(value);
  if (value === void 0) {
    return {
      input: {
        command: "QueryFieldName",
        payload: {
          name
        }
      }
    };
  }
  return {
    ...input(value),
    name: {
      command: "QueryField",
      payload: {
        name
      }
    }
  };
}
__name(useField, "useField");
useField.increment = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      increment: true
    }
  };
};
useField.decrement = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      decrement: true
    }
  };
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}
__name(index, "index");

// libs/sdk/declarative/src/lib/workflow.ts
import { Project as Project2, StructureKind as StructureKind2, SyntaxKind as SyntaxKind2 } from "ts-morph";
function experimental_wokflow(features) {
}
__name(experimental_wokflow, "experimental_wokflow");
function workflow(name, config2) {
  const execute = config2.trigger.refineExecute(config2.execute);
  return {
    name,
    trigger: config2.trigger,
    raw: !Object.keys(config2.trigger.inputs ?? {}).length,
    execute,
    tag: config2.tag
  };
}
__name(workflow, "workflow");
function defineTrigger(type, config2) {
  return {
    type,
    config: config2
  };
}
__name(defineTrigger, "defineTrigger");
var trigger;
((trigger2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? trigger2 : defineTrigger;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown trigger type: ${type}`);
  }
  trigger2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
})(trigger || (trigger = {}));
((trigger2) => {
  function schedule(config2) {
    return {
      type: "node-cron-trigger",
      config: config2,
      policies: [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.schedule = schedule;
  __name(schedule, "schedule");
})(trigger || (trigger = {}));
function inputize(inputFn) {
  const inputs = {};
  const guard = inputFn.toString();
  const project2 = new Project2({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind2.ArrowFunction);
  if (guardFunction) {
    const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind2.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(SyntaxKind2.ReturnStatement);
    const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
      SyntaxKind2.ObjectLiteralExpression
    );
    returnObjExpr.getProperties().forEach((prop) => {
      const propAssignment = prop.asKindOrThrow(SyntaxKind2.PropertyAssignment);
      const propName = propAssignment.getName();
      const withSelectorAndAgainst = propAssignment.getInitializerIfKind(
        SyntaxKind2.ObjectLiteralExpression
      );
      if (withSelectorAndAgainst) {
        const propValue = withSelectorAndAgainst;
        const selectFn = propValue.getPropertyOrThrow(
          "select"
        );
        const againstFn = propValue.getProperty(
          "against"
        );
        const usageText = selectFn.getInitializerOrThrow().getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: againstFn.getInitializerOrThrow().getText()
          }
        };
      } else {
        const usageText = propAssignment.getInitializerIfKindOrThrow(SyntaxKind2.PropertyAccessExpression).getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: "z.any()"
          }
        };
      }
    });
  }
  return inputs;
}
__name(inputize, "inputize");
((trigger2) => {
  function http(config2) {
    return {
      type: "http",
      inputs: config2.input ? inputize(config2.input) : {},
      config: {
        ...config2,
        params: [
          {
            name: "output",
            type: "trigger.http.output"
          }
        ],
        structures: [
          {
            kind: StructureKind2.ImportDeclaration,
            moduleSpecifier: "@january/declarative",
            namedImports: ["trigger"]
          }
        ]
      },
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => `input.${key}`, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.http = http;
  __name(http, "http");
})(trigger || (trigger = {}));
((trigger2) => {
  function sse2(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => "input", "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.sse = sse2;
  __name(sse2, "sse");
  function websocket(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.websocket = websocket;
  __name(websocket, "websocket");
  function stream(config2) {
    return {
      type: "stream",
      inputs: config2.input ? inputize(config2.input) : {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => `input.${key}`, "replaceKey"),
          setOutput: /* @__PURE__ */ __name((arg) => `return ${arg}`, "setOutput")
        });
      }, "refineExecute")
    };
  }
  trigger2.stream = stream;
  __name(stream, "stream");
})(trigger || (trigger = {}));
((trigger2) => {
  function github2(config2) {
    const inputs = {};
    return {
      type: "github-trigger",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.github = github2;
  __name(github2, "github");
})(trigger || (trigger = {}));
((trigger2) => {
  function tus(config2) {
    const inputs = {};
    return {
      type: "tus",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.tus = tus;
  __name(tus, "tus");
})(trigger || (trigger = {}));
((trigger2) => {
  function file2(config2) {
    return {
      type: "file",
      config: {
        ...config2,
        rewrite: config2.rewrite ? config2.rewrite.toString() : void 0
      },
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(
          () => {
          },
          {
            replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
          }
        );
      }, "refineExecute")
    };
  }
  trigger2.file = file2;
  __name(file2, "file");
})(trigger || (trigger = {}));
function policy(rule) {
  return rule;
}
__name(policy, "policy");
function definePolicy(rule) {
  return (name) => rule;
}
__name(definePolicy, "definePolicy");
((policy2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? policy2 : definePolicy;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown policy type: ${type}`);
  }
  policy2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
  function authenticated() {
    return (name) => `
    import { Context } from 'hono';
    import { verifyToken } from './subject';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
  }
  policy2.authenticated = authenticated;
  __name(authenticated, "authenticated");
  function http() {
    return () => "";
  }
  __name(http, "http");
  function github2(config2) {
    if (!config2.events || !config2.events.length || !config2.guard) {
      return () => "";
    }
    const project2 = new Project2({
      useInMemoryFileSystem: true
    });
    let body = "return true";
    if (config2.guard) {
      const guard = config2.guard.toString();
      const sourceFile = project2.createSourceFile(
        "guard.ts",
        `const guard = ${guard}`
      );
      const guardFunction = sourceFile.getVariableDeclarationOrThrow("guard").getInitializerOrThrow();
      const isBlock = guardFunction.getBody().isKind(SyntaxKind2.Block);
      body = isBlock ? guardFunction.getBodyText() : `return ${guardFunction.getBodyText()}`;
    }
    return (name) => `
    import { EmitterWebhookEvent } from '@octokit/webhooks';
    import { isEventOfType } from '../core/github-webhooks';

    export async function ${name}(event: EmitterWebhookEvent) {
      if(isEventOfType(event, ${(config2.events ?? []).map((it) => `'${it}'`).join(", ")})) {
        ${body}
      }
      return false;

  }`;
  }
  policy2.github = github2;
  __name(github2, "github");
})(policy || (policy = {}));
policy.unstable_country = (country) => {
  return `@trigger:context.country === '${country}'`;
};

// libs/sdk/evaluator/src/lib/evaluate.ts
init_src();
import { randomBytes } from "crypto";
var callers = {
  project,
  table,
  feature,
  workflow,
  trigger: trigger.fromConfig,
  field: field.fromConfig,
  policy: policy.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  useTable,
  useField,
  query,
  select,
  sort,
  where,
  limit,
  and,
  or,
  input,
  index,
  withTrigger: /* @__PURE__ */ __name((...args) => {
  }, "withTrigger")
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers3, node2, hooks = {}) {
  if (Checker.isCallExpression(node2)) {
    const [implFn, ...type] = node2.caller.split(".");
    let callerImpl = callers3[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node2.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node2, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node2.arguments.map((it) => staticEval(callers3, it, hooks));
    if (type.length) {
      args.unshift(type.join("."));
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node2)) {
    return node2.map((it) => staticEval(callers3, it, hooks));
  }
  if (Checker.isObjectExpression(node2)) {
    const obj = {};
    for (const [key, value] of Object.entries(node2)) {
      obj[key] = staticEval(callers3, value, hooks);
    }
    return obj;
  }
  return node2;
}
__name(staticEval, "staticEval");
function diagnose(service2, ast) {
  const reports = [];
  if (Checker.isCallExpression(ast.node)) {
    const [implFn, ...type] = ast.node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${ast.node.caller}`);
    }
    const args = [ast, service2];
    reports.push(
      ...ast.node.arguments.map(
        (it) => diagnose(service2, {
          parent: ast,
          node: it
        })
      )
    );
    if (type.length) {
      args.unshift([...type, "rule"].join("."));
      reports.push(...callerImpl(...args));
    } else {
      if ("rule" in callerImpl) {
        reports.push(...callerImpl.rule(...args));
      }
    }
    return reports;
  }
  if (Checker.isArrayExpression(ast.node)) {
    return ast.node.map(
      (it) => diagnose(service2, {
        parent: ast,
        node: it
      })
    );
  }
  if (Checker.isObjectExpression(ast.node)) {
    for (const [key, value] of Object.entries(ast.node)) {
      reports.push(
        ...diagnose(service2, {
          parent: ast,
          node: value
        })
      );
    }
    return reports;
  }
  return reports;
}
__name(diagnose, "diagnose");
async function defensiveEvaluate(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  const features = staticEval(callers, ast.project);
  const service2 = {
    getFeature(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "feature") {
          return features.find(
            (feature2) => feature2.name === parent.node.arguments[0]
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    getWorkflow(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "workflow") {
          const feature2 = this.getFeature(parent);
          const [workflowName] = parent.node.arguments;
          return feature2?.workflows.find(
            (workflow2) => workflow2.name === workflowName
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    duplicateWorkflowTriggerConfig: /* @__PURE__ */ __name((relatedWorkflow, check) => {
      for (const feature2 of features) {
        for (const workflow2 of feature2.workflows) {
          if (workflow2 === relatedWorkflow) {
            continue;
          }
          if (check(workflow2, feature2)) {
            return true;
          }
        }
      }
      return false;
    }, "duplicateWorkflowTriggerConfig"),
    hasField: /* @__PURE__ */ __name((name) => features.some(
      (feature2) => Object.keys(feature2.tables ?? {}).some(
        (table2) => Object.keys(feature2.tables[table2].fields).includes(name)
      )
    ), "hasField"),
    hasTable: /* @__PURE__ */ __name((name) => features.some((feature2) => {
      return (feature2.tables ?? {})[name];
    }), "hasTable"),
    inUniqueFeature: /* @__PURE__ */ __name((name) => {
      let count = 0;
      for (const feature2 of features) {
        if (feature2.name === name) {
          count++;
        }
      }
      return count === 1;
    }, "inUniqueFeature"),
    isUniqueWorkflow: /* @__PURE__ */ __name((name) => {
      for (const feature2 of features) {
        let count = 0;
        for (const workflow2 of feature2.workflows) {
          if (workflow2.name === name) {
            count++;
          }
        }
        if (count > 1) {
          return false;
        }
      }
      return true;
    }, "isUniqueWorkflow"),
    validateName(name, context) {
      const errors = [];
      if (typeof name !== "string") {
        errors.push(`${context} must be a string`);
      } else if (name.trim().length === 0) {
        errors.push(`${context} must not be empty`);
      }
      return errors;
    }
  };
  return {
    reports: [],
    definition: {
      features,
      imports: ast.imports
    }
  };
}
__name(defensiveEvaluate, "defensiveEvaluate");
async function evaluate(code) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    feature: staticEval(callers, ast.project),
    imports: ast.imports
  };
}
__name(evaluate, "evaluate");
async function compare(a, b) {
  const removeSpans = /* @__PURE__ */ __name((node2) => {
    if (!node2) return "";
    return JSON.stringify(node2, (key, value) => {
      if (key === "span") {
        return void 0;
      }
      return value;
    });
  }, "removeSpans");
  return removeSpans((await legacy_parse(a))?.project ?? null) === removeSpans((await legacy_parse(a))?.project ?? null);
}
__name(compare, "compare");

// libs/sdk/evaluator/src/lib/infertype.ts
init_src();
var noop = /* @__PURE__ */ __name(() => {
}, "noop");
var callers2 = {
  project: /* @__PURE__ */ __name((...args) => {
    const [name, config2] = args;
    return args[0];
  }, "project"),
  feature: /* @__PURE__ */ __name((...args) => {
    const [name, config2] = args;
    return {
      workflows: config2.workflows,
      tables: config2.tables,
      featureName: name
    };
  }, "feature"),
  table,
  field,
  workflow,
  trigger: trigger.fromConfig,
  useTable: noop,
  mandatory: noop,
  required: noop,
  unique: noop,
  useField: noop,
  query: noop,
  select: noop,
  sort: noop,
  where: noop,
  limit: noop,
  and: noop,
  or: noop,
  input: noop,
  index: noop
};
function call(node2, metadata, parent) {
  if (Checker.isCallExpression(node2)) {
    const [implFn, ...type] = node2.caller.split(".");
    const callerImpl = callers2[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node2.caller}`);
    }
    const args = node2.arguments.map((it) => call(it));
    if (type.length) {
      args.unshift([...type, "dts"].join("."));
    } else {
      if ("dts" in callerImpl) {
        return callerImpl.dts(...args, metadata);
      }
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node2)) {
    return node2.map((it) => call(it));
  }
  if (Checker.isObjectExpression(node2)) {
    const obj = {};
    for (const [key, value] of Object.entries(node2)) {
      if (metadata === "actions") {
        obj[key] = call(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          key
        );
      } else {
        obj[key] = call(value, key, node2);
      }
    }
    return obj;
  }
  return node2;
}
__name(call, "call");
async function inferType(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    return [];
  }
  const result = call(ast.project);
  return result;
}
__name(inferType, "inferType");

// libs/compiler/generator/src/bundling/virtual.ts
import esbuild from "esbuild";
import { dirname as dirname7, relative as relative2, resolve } from "path";
var nodeExternalsPlugin = /* @__PURE__ */ __name((packageJsonV) => {
  const packageJson = JSON.parse(packageJsonV);
  const keys = [
    "dependencies",
    "devDependencies",
    "peerDependencies",
    "optionalDependencies"
  ];
  const nodeModules = keys.map((key) => Object.keys(packageJson[key] || {})).flat();
  return {
    name: "node-externals",
    setup(build2) {
      build2.onResolve(
        {
          namespace: "virtual",
          filter: /.*/
        },
        (args) => {
          let moduleName = args.path.split("/")[0];
          if (args.path.startsWith("@")) {
            const split = args.path.split("/");
            moduleName = `${split[0]}/${split[1]}`;
          }
          if (nodeModules.includes(moduleName)) {
            return { path: args.path, external: true };
          }
          return null;
        }
      );
    }
  };
}, "nodeExternalsPlugin");
function virtualBundle(options) {
  const getFile3 = /* @__PURE__ */ __name((name) => {
    const file2 = options.files.find((file3) => file3.path.endsWith(name));
    if (!file2) {
      return null;
    }
    return file2;
  }, "getFile");
  const packageJsonFile = getFile3("package.json");
  const configJson = getFile3("tsconfig.json");
  const filesMap = Object.fromEntries(
    options.files.map((file2) => [file2.path, file2.content])
  );
  return esbuild.build({
    entryPoints: [options.src],
    write: false,
    platform: "node",
    treeShaking: true,
    minify: true,
    format: "esm",
    outfile: options.dist,
    keepNames: true,
    bundle: true,
    assetNames: "[name]",
    loader: {
      ".json": "file"
    },
    tsconfigRaw: configJson ? JSON.parse(configJson.content) : void 0,
    plugins: [
      packageJsonFile ? nodeExternalsPlugin(packageJsonFile.content) : {
        name: "node-externals",
        setup(build2) {
        }
      },
      {
        name: "virtual-files",
        setup(build2) {
          build2.onResolve({ filter: /.*/ }, (args) => {
            const path = relative2(
              process.cwd(),
              resolve(dirname7(args.importer), args.path)
            );
            const attempts = [path, `${path}.ts`, `${path}/index.ts`];
            for (const attempt of attempts) {
              if (attempt in filesMap) {
                return {
                  path: attempt,
                  namespace: "virtual"
                };
              }
            }
            return null;
          });
          build2.onLoad(
            {
              filter: /.*/,
              namespace: "virtual"
            },
            (args) => {
              return {
                contents: filesMap[args.path],
                loader: "default"
              };
            }
          );
        }
      }
    ]
  });
}
__name(virtualBundle, "virtualBundle");

// libs/compiler/generator/src/bundling/bundler.ts
import esbuild2 from "esbuild";
import { nodeExternalsPlugin as nodeExternalsPlugin2 } from "esbuild-node-externals";
import { readFile as readFile3 } from "fs/promises";
import { join as join9 } from "path";
async function bundle(options) {
  const tsconfig = JSON.parse(
    await readFile3(join9(options.projectRoot, "tsconfig.json"), "utf-8")
  );
  const paths = tsconfig.compilerOptions.paths;
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    },
    plugins: [
      nodeExternalsPlugin2({
        packagePath: [join9(options.projectRoot, "package.json")],
        allowList: Object.keys(paths)
      })
    ],
    assetNames: "[name]",
    loader: {
      ".swagger.json": "file"
    }
  });
}
__name(bundle, "bundle");
async function fileBundler(options) {
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: false,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: false,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    }
  }).then((x) => x.outputFiles?.[0]?.text);
}
__name(fileBundler, "fileBundler");

// libs/remote/src/lib/requirements-parser.ts
var parse3 = /* @__PURE__ */ __name((content) => {
  const lines = content.split(/\r?\n/);
  return lines.map((line) => {
    const commentIndex = line.indexOf("#");
    if (commentIndex !== -1) {
      line = line.slice(0, commentIndex);
    }
    line = line.trim();
    if (!line) return null;
    if (line.startsWith("-r") || line.startsWith("--requirement")) {
      const [, ...fileParts] = line.split(/\s+/);
      return {
        type: "requirement",
        file: fileParts.join(" ").trim()
      };
    }
    let envMarker = null;
    if (line.includes(";")) {
      [line, envMarker] = line.split(";").map((part) => part.trim());
    }
    if (line.startsWith("git+") || line.includes("://")) {
      return {
        type: "url",
        url: line,
        envMarker
      };
    }
    const packageMatch = line.match(
      /^([a-zA-Z0-9\-._]+(?:\[[a-zA-Z0-9\-._,\s]+\])?)/
    );
    if (!packageMatch) return null;
    const packageName = packageMatch[1];
    const versionMatch = line.slice(packageName.length).match(/\s*(==|>=|<=|!=|~=|>|<)\s*([a-zA-Z0-9\-._*]+)/);
    return {
      type: "package",
      package: packageName,
      version: versionMatch ? versionMatch[2] : null,
      specifier: versionMatch ? versionMatch[1] : null,
      envMarker,
      extras: parseExtras(packageName)
    };
  }).filter(Boolean);
}, "parse");
var parseExtras = /* @__PURE__ */ __name((packageName) => {
  const extrasMatch = packageName.match(/\[(.*)\]$/);
  if (!extrasMatch) return null;
  return extrasMatch[1].split(",").map((extra) => extra.trim());
}, "parseExtras");
async function parseRequirements(content) {
  try {
    return parse3(content).filter(notNullOrUndefined);
  } catch (error) {
    console.error("Error parsing requirements:");
    console.error(error);
    return [];
  }
}
__name(parseRequirements, "parseRequirements");

// libs/remote/src/lib/firebase.ts
import { initializeApp } from "firebase/app";
import { initializeAuth } from "firebase/auth";
import { readFile as readFile4, rm as rm2, writeFile as writeFile4 } from "fs/promises";
import { tmpdir as tmpdir2 } from "os";
import { join as join10 } from "path";
var file = join10(tmpdir2(), "serverize");
var FilePersistence = class {
  static {
    __name(this, "FilePersistence");
  }
  static type = "NONE";
  type = "NONE";
  async _isAvailable() {
    return true;
  }
  decode(key) {
    return key;
  }
  async _set(key, value) {
    return writeFile4(join10(tmpdir2(), this.decode(key)), JSON.stringify(value));
  }
  async _get(base64) {
    return await readFile4(join10(tmpdir2(), this.decode(base64)), "utf-8").then((data) => {
      return safeFail(() => JSON.parse(data), null);
    }).catch((error) => {
      return null;
    });
  }
  async _remove(base64) {
    await rm2(join10(tmpdir2(), this.decode(base64)), { force: true });
  }
  _addListener(_key, _listener) {
    return;
  }
  _removeListener(_key, _listener) {
    return;
  }
};
var app = initializeApp({
  apiKey: "AIzaSyA6OFi52evEph_dFBFxHd-71BIGpJiCTOA",
  authDomain: "january-9f554.firebaseapp.com",
  projectId: "january-9f554",
  storageBucket: "january-9f554.appspot.com",
  messagingSenderId: "299506012875",
  appId: "1:299506012875:web:ac6e9ff54cd104fdfcc14e"
});
var auth = initializeAuth(app, {
  persistence: [FilePersistence]
});

// libs/remote/src/lib/http.ts
import { v4 as v42 } from "uuid";
var baseUrl2 = process.env.NODE_ENV === "development" ? "http://localhost:3000" : "https://serverize.fly.dev";
var request;
((_request) => {
  async function makeHeaders(withAuth = true) {
    const headers = [
      ["Content-Type", "application/json"],
      ["x-request-id", v42()]
    ];
    if (withAuth) {
      const token = await auth.currentUser?.getIdToken();
      if (token) {
        headers.push(["Authorization", `Bearer ${token}`]);
      }
    }
    return headers;
  }
  __name(makeHeaders, "makeHeaders");
  async function get2(path, config2 = { withAuth: true }) {
    const [response, error] = await request2(path, "GET", void 0, config2);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.get = get2;
  __name(get2, "get");
  async function put(path, data, config2) {
    const [response, error] = await request2(path, "PUT", data, config2);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.put = put;
  __name(put, "put");
  async function patch(path, data, config2) {
    const [response, error] = await request2(path, "PATCH", data, config2);
    if (error || !response) {
      return [null, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.patch = patch;
  __name(patch, "patch");
  async function post(path, data, config2) {
    const [response, error] = await request2(path, "POST", data, config2);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.post = post;
  __name(post, "post");
  async function request2(path, method, data, config2) {
    const extraHeaders = config2?.headers ? Object.entries(config2.headers).filter(
      ([_, value]) => notNullOrUndefined(value)
    ) : [];
    try {
      const response = await fetch(
        `${config2?.baseUrl || baseUrl2}${addLeadingSlash(path)}`,
        {
          method,
          body: data ? JSON.stringify(data) : void 0,
          headers: [...await makeHeaders(), ...extraHeaders]
        }
      );
      if (response.ok) {
        return [response];
      }
      const error = await handleError(response);
      return [null, error];
    } catch (error) {
      return [null, error];
    }
  }
  _request.request = request2;
  __name(request2, "request");
  async function remove(path, data, config2 = { withAuth: true }) {
    const [response, error] = await request2(path, "DELETE", data, config2);
    if (error || !response) {
      return [null, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.remove = remove;
  __name(remove, "remove");
})(request || (request = {}));
async function handleError(response) {
  try {
    if (response.status >= 400 && response.status < 500) {
      const body = await response.json();
      return new Error(body.detail);
    }
    return new Error(
      `An error occurred while fetching the data. Status: ${response.status}`
    );
  } catch (error) {
    return error;
  }
}
__name(handleError, "handleError");

// libs/remote/src/lib/api-client.ts
function fetchReleases(options = {}) {
  const params = new URLSearchParams();
  Object.entries(options).forEach(([key, value]) => {
    if (value !== void 0) {
      params.append(key, value);
    }
  });
  return request.get(`/releases?${params}`);
}
__name(fetchReleases, "fetchReleases");
function fetchProjects(options = {}) {
  const params = new URLSearchParams();
  Object.entries(options).forEach(([key, value]) => {
    if (value !== void 0) {
      params.append(key, value);
    }
  });
  return request.get(`/projects?${params}`);
}
__name(fetchProjects, "fetchProjects");
function fetchTokens() {
  return request.get("/tokens");
}
__name(fetchTokens, "fetchTokens");
function validateToken(token) {
  return request.get(`/tokens/${token}`);
}
__name(validateToken, "validateToken");
function setSecret(data) {
  return request.post(`/secrets`, data);
}
__name(setSecret, "setSecret");
function getProjectEnv(projectId) {
  const params = new URLSearchParams({ projectId });
  return request.get(`/secrets/values?${params}`).then(([data, error]) => {
    if (error || !data) {
      throw new Error("Failed to fetch project env");
    }
    return data;
  });
}
__name(getProjectEnv, "getProjectEnv");
async function stopRelease(id) {
  const token = await auth.currentUser?.getIdToken();
  const config2 = {
    headers: { Authorization: `Bearer ${token}` },
    withAuth: false
  };
  return request.remove(`/releases/${id}`, {}, config2);
}
__name(stopRelease, "stopRelease");
async function makeRelease(releaseInfo, token) {
  let id;
  token ||= await auth.currentUser?.getIdToken();
  const config2 = {
    headers: { Authorization: `Bearer ${token}` },
    withAuth: false
  };
  return {
    create: /* @__PURE__ */ __name(async () => {
      const [data, error] = await request.post(
        `/releases`,
        {
          channel: releaseInfo.channel,
          projectId: releaseInfo.projectId,
          releaseName: releaseInfo.release
        },
        config2
      );
      if (error || !data) {
        throw new Error("Failed to create release");
      }
      id = data.id;
    }, "create"),
    waiting: /* @__PURE__ */ __name(() => request.patch(`/releases/${id}`, { status: "waiting" }, config2), "waiting"),
    fail: /* @__PURE__ */ __name(() => request.patch(
      `/releases/complete/${id}`,
      {
        conclusion: "failure"
      },
      config2
    ), "fail"),
    success: /* @__PURE__ */ __name((options) => request.patch(
      `/releases/complete/${id}`,
      {
        conclusion: "success",
        containerName: options.containerName
      },
      config2
    ), "success")
  };
}
__name(makeRelease, "makeRelease");

// libs/remote/src/lib/auth.ts
import { FirebaseError } from "firebase/app";
import {
  AuthErrorCodes,
  EmailAuthProvider,
  GithubAuthProvider,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  getRedirectResult,
  linkWithCredential,
  linkWithPopup,
  onAuthStateChanged,
  signInAnonymously,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect
} from "firebase/auth";
async function anonymouslySignIn() {
  if (auth.currentUser) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  const result = await signInAnonymously(auth);
  const user = result.user;
  const token = await user.getIdToken(true);
  return { user, token };
}
__name(anonymouslySignIn, "anonymouslySignIn");
async function signInWithGithub() {
  const isAlreadyLinkedToGithub = (auth.currentUser?.providerData ?? []).some(
    (provider2) => provider2.providerId === GithubAuthProvider.PROVIDER_ID
  );
  if (auth.currentUser && isAlreadyLinkedToGithub) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  const provider = new GithubAuthProvider();
  provider.addScope("repo");
  provider.addScope("workflow");
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithPopup(auth.currentUser, provider);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  {
    try {
      await signInWithRedirect(auth, provider);
      const result = await getRedirectResult(auth);
      if (!result) {
        return { user: null };
      }
      const credential = GithubAuthProvider.credentialFromResult(result);
      const user = result.user;
      const token = await user.getIdToken(true);
      return { user, token, accessToken: credential?.accessToken };
    } catch (error) {
      console.error(error);
    }
  }
  return { user: null };
}
__name(signInWithGithub, "signInWithGithub");
async function linkAccountWithGithub() {
  if (!auth.currentUser) {
    return signInWithGithub();
  }
  const isAlreadyLinked = auth.currentUser.providerData.some(
    (provider2) => provider2.providerId === GithubAuthProvider.PROVIDER_ID
  );
  if (isAlreadyLinked) {
    return;
  }
  const provider = new GithubAuthProvider();
  provider.addScope("repo");
  provider.addScope("workflow");
  try {
    const result = await linkWithPopup(auth.currentUser, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token, accessToken: credential?.accessToken };
  } catch (error) {
    if (process.env.NODE_ENV === "development") {
      console.error(error);
    }
    if (error instanceof FirebaseError) {
      if (error.code === AuthErrorCodes.CREDENTIAL_ALREADY_IN_USE) {
        const result = await signInWithPopup(auth, provider);
        const credential = GithubAuthProvider.credentialFromResult(result);
        const user = result.user;
        const token = await user.getIdToken(true);
        return { user, token, accessToken: credential?.accessToken };
      }
    }
  }
  return { user: null };
}
__name(linkAccountWithGithub, "linkAccountWithGithub");
async function signInWithGoogle() {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  const provider = new GoogleAuthProvider();
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithPopup(auth.currentUser, provider);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token, accessToken: credential?.accessToken };
  } catch (error) {
    if (error instanceof FirebaseError) {
      if (error.code === AuthErrorCodes.EMAIL_EXISTS) {
        throw new Error(
          "Looks like you already have an account. Please sign in."
        );
      }
    }
  }
  return { user: null };
}
__name(signInWithGoogle, "signInWithGoogle");
async function signUpWithEmail(email, password2) {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(
      auth.currentUser,
      EmailAuthProvider.credential(email, password2)
    );
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password2);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  } catch (error) {
    if (error instanceof FirebaseError) {
      switch (error.code) {
        case AuthErrorCodes.INVALID_EMAIL:
          throw new Error("Invalid email address");
        case AuthErrorCodes.WEAK_PASSWORD:
          throw new Error("Password is too weak");
        case AuthErrorCodes.EMAIL_EXISTS:
          throw new Error(
            box(
              "User already exists",
              "Looks like you already have an account. Please sign in.",
              `$ npx serverize auth signin`
            )
          );
        case AuthErrorCodes.CREDENTIAL_ALREADY_IN_USE:
          throw new Error(
            "Looks like you already have an account. Please sign in."
          );
        default:
          throw error;
      }
    }
    throw error;
  }
}
__name(signUpWithEmail, "signUpWithEmail");
async function signInWithEmail(email, password2) {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(
      auth.currentUser,
      EmailAuthProvider.credential(email, password2)
    );
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await signInWithEmailAndPassword(auth, email, password2);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  } catch (error) {
    if (error instanceof FirebaseError) {
      switch (error.code) {
        case AuthErrorCodes.INVALID_IDP_RESPONSE:
        case AuthErrorCodes.INVALID_LOGIN_CREDENTIALS:
          throw new Error("Wrong email or password, please try again.");
        default:
          throw error;
      }
    }
  }
  return { user: null };
}
__name(signInWithEmail, "signInWithEmail");
function initialise() {
  return new Promise((resolve2, reject) => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (user) => {
        unsubscribe();
        resolve2(user);
      },
      reject
    );
  });
}
__name(initialise, "initialise");
Error.stackTraceLimit = Infinity;

// libs/remote/src/program.ts
import ignore from "@balena/dockerignore";
import { input as input2, select as select2 } from "@inquirer/prompts";
import chalk from "chalk";
import cliSpinners from "cli-spinners";
import { Option, program } from "commander";
import debug2 from "debug";
import { DockerfileParser } from "dockerfile-ast";
import glob2 from "fast-glob";
import { existsSync as existsSync2 } from "fs";
import { readFile as readFile5 } from "fs/promises";
import { marked } from "marked";
import { markedTerminal } from "marked-terminal";
import ms from "ms";
import ora from "ora";
import { platform } from "os";
import { join as join11 } from "path";
import validator from "validator";
var defaultHealthCheck = {
  Test: "CMD wget --no-verbose --spider --tries=1 / || exit 1",
  Retries: 3,
  StartPeriod: ns(ms("2s")),
  Timeout: ns(ms("3s")),
  Interval: ns(ms("30s"))
};
var cli = program.name("Serverize").version("1.0.0").description("Serverize");
async function toAst2(projectDockerFilePath) {
  const dockerignorefilePath = join11(process.cwd(), ".dockerignore");
  const dockerfilePath = join11(process.cwd(), projectDockerFilePath);
  let dockerignore = "";
  if (!existsSync2(dockerfilePath)) {
    throw new Error(`No Dockerfile found at ${dockerfilePath}`);
  }
  if (!existsSync2(dockerignorefilePath)) {
    spinner.warn(
      `No .dockerignore found at ${dockerignorefilePath}. Using defaults.`
    );
    dockerignore = nodeServer.dockerignore.join("\n");
  } else {
    logger("Reading .dockerignore at %s", dockerignorefilePath);
    dockerignore = await readFile5(dockerignorefilePath, "utf-8");
  }
  logger("Reading Dockerfile at %s", dockerfilePath);
  const dockerfile2 = await readFile5(dockerfilePath, "utf-8");
  const ast = DockerfileParser.parse(dockerfile2);
  const exposeInstructions = ast.getInstructions().find((instruction) => instruction.getInstruction() === "EXPOSE");
  const copies = ast.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    let path = srcArg.getValue();
    if (path === ".") {
      path = "./";
    }
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const filteredPaths = ignore({ ignorecase: true }).add(dockerignore).filter(
    await glob2(Array.from(paths), {
      cwd: process.cwd()
    })
  );
  const [healthCheck] = ast.getHEALTHCHECKs();
  const healthCheckOptions = {};
  if (healthCheck) {
    const flags = healthCheck.getFlags();
    const keys = [
      {
        prop: "StartPeriod",
        flag: "start-period",
        format: /* @__PURE__ */ __name((value) => ns(ms(value)), "format")
      },
      {
        prop: "Retries",
        flag: "retries",
        format: /* @__PURE__ */ __name((value) => parseInt(value, 10), "format")
      },
      {
        prop: "Timeout",
        flag: "timeout",
        format: /* @__PURE__ */ __name((value) => ns(ms(value)), "format")
      },
      {
        prop: "Interval",
        flag: "interval",
        format: /* @__PURE__ */ __name((value) => ns(ms(value)), "format")
      }
    ];
    for (const { prop, flag, format } of keys) {
      const value = flags.find((it) => it.getName() === flag);
      if (value) {
        healthCheckOptions[prop] = format ? format(value.getValue()) : value.getValue();
      } else {
        healthCheckOptions[prop] = defaultHealthCheck[prop];
      }
    }
    healthCheckOptions["Test"] = healthCheck.getRawArgumentsContent();
  }
  const exposedPort = exposeInstructions ? exposeInstructions.getArguments().map((it) => it.getValue())[0].split("/tcp")[0] : "";
  return {
    healthCheckOptions: Object.keys(healthCheckOptions).length ? healthCheckOptions : void 0,
    paths: filteredPaths,
    expose: exposedPort,
    dockerfile: dockerfilePath
  };
}
__name(toAst2, "toAst");
function ns(ms2) {
  return ms2 * 1e6;
}
__name(ns, "ns");
var logger = debug2("serverize");
console.log("\n");
var SPINNER_TYPE = platform() === "win32" ? cliSpinners.material : cliSpinners.pipe;
var spinner = ora({
  spinner: SPINNER_TYPE,
  prefixText: "\u2500 Serverize"
});
function printDivider(character = "\u2500") {
  const columns = process.stdout.columns || 80;
  const line = character.repeat(columns);
  console.log(line);
}
__name(printDivider, "printDivider");
function tell(message, newLine = false) {
  spinner.text = `${message}${newLine ? "\n" : ""}`;
  spinner.render();
}
__name(tell, "tell");
var askForProjectName = /* @__PURE__ */ __name(() => input2({
  message: "Project name",
  validate: /* @__PURE__ */ __name((v) => {
    const isValid = validator.isAlpha(v, "en-US", { ignore: "-" });
    if (!isValid) {
      return "Project name can only contain letters and hyphens";
    }
    return true;
  }, "validate")
}), "askForProjectName");
var channelOption = new Option(
  "-c, --channel <channel>",
  "Channel to deploy to"
).default("dev");
var releaseOption = new Option(
  "-r, --release <release>",
  "Release name"
).default("latest");
var projectOption = new Option(
  "-p, --project <projectName>",
  "The project name"
).makeOptionMandatory(true);
if (process.env.SERVERIZE_PROJECT) {
  projectOption.default(process.env.SERVERIZE_PROJECT);
}
if (process.env.SERVERIZE_PROJECT || process.env.SERVERIZE_API_TOKEN) {
  projectOption.makeOptionMandatory(false);
}
async function ensureUser() {
  const user = await initialise();
  const say = /* @__PURE__ */ __name(() => {
    tell("You need to sign in first", true);
    box.print(
      "Authentication",
      "Login $ npx serverize auth signin",
      "Signup $ npx serverize auth signup"
    );
  }, "say");
  if (!user) {
    say();
    return null;
  }
  const { claims } = await user.getIdTokenResult(true);
  if (!claims.aknowledged) {
    await user.delete().catch(() => {
    });
    say();
    return null;
  }
  if (!user.emailVerified) {
    spinner.warn("Email not verified: Please verify your email.");
  }
  return { user, claims };
}
__name(ensureUser, "ensureUser");
async function dropdown(config2) {
  return select2({
    message: config2.title,
    default: config2.default,
    loop: true,
    choices: config2.choices
  });
}
__name(dropdown, "dropdown");
async function getCurrentProject(project2) {
  const apiToken = process.env.SERVERIZE_API_TOKEN?.trim();
  const useProject = /* @__PURE__ */ __name(async () => {
    const user = await ensureUser();
    if (!user) return;
    const [data, error] = await fetchProjects({ name: project2 });
    if (error || !data) {
      spinner.fail(`Failed to get project ${project2}`);
      return;
    }
    if (data.records.length === 0) {
      spinner.fail(`Project ${chalk.green(project2)} not found`);
      return;
    }
    return {
      projectId: data.records[0].id,
      projectName: data.records[0].name,
      token: await user.user.getIdToken()
    };
  }, "useProject");
  if (project2 && apiToken) {
    return await useProject();
  } else if (project2) {
    return await useProject();
  } else if (apiToken) {
    const [data, error] = await validateToken(apiToken);
    if (error || !data) {
      spinner.fail("Invalid token");
      process.exit(1);
    }
    return {
      projectId: data.project.id,
      projectName: data.project.name,
      token: apiToken
    };
  }
  await ensureUser();
  return;
}
__name(getCurrentProject, "getCurrentProject");
function renderMD(md) {
  try {
    marked.use(markedTerminal({}));
  } catch {
  }
  return marked(md);
}
__name(renderMD, "renderMD");

// libs/remote/src/setup.ts
init_src();
import { confirm, input as input3 } from "@inquirer/prompts";
import chalk2 from "chalk";
import { Command } from "commander";
import { detect } from "detect-package-manager";
import { existsSync as existsSync3 } from "fs";
import { readFile as readFile6, readdir, rm as rm3, writeFile as writeFile5 } from "fs/promises";
import { dirname as dirname8, join as join12 } from "path";
var supportedFrameworks = [
  "nextjs",
  "nuxtjs",
  "astrojs",
  "vite",
  "angular",
  "streamlit",
  "dotnet",
  "remix",
  "node",
  "bun",
  "deno"
  // 'jamstack' // check if package.json is there and if so, check if it has a build script, otherwise just use nginx
];
var frameworks = {
  nextjs: [
    (config2) => {
      const configFiles = [
        "next.config.js",
        "next.config.mjs",
        "next.config.ts",
        "next.config.cjs"
      ];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  nuxtjs: [
    (config2) => {
      const configFiles = [
        "nuxt.config.js",
        "nuxt.config.mjs",
        "nuxt.config.ts",
        "nuxt.config.cjs"
      ];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  astrojs: [
    (config2) => {
      const configFiles = [
        "astro.config.js",
        "astro.config.mjs",
        "astro.config.ts",
        "astro.config.cjs"
      ];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  angular: [
    (config2) => {
      const configFiles = ["angular.json"];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  remix: [
    async (config2) => {
      const configFilePath = (await readdir(config2.cwd)).find(
        (it) => it.startsWith("vite.config.")
      );
      if (!configFilePath) {
        return false;
      }
      const hasRemixPlugin = await readConfig(
        join12(config2.cwd, configFilePath),
        {
          static: true,
          callers: {
            defineConfig: /* @__PURE__ */ __name((config3) => {
              return config3.plugins.filter(Boolean).find((it) => it.remix);
            }, "defineConfig"),
            remix: /* @__PURE__ */ __name((config3) => {
              return { remix: true, mode: config3.ssr };
            }, "remix")
          }
        }
      );
      return hasRemixPlugin;
    }
  ],
  vite: [
    (config2) => {
      const configFiles = [
        "vite.config.js",
        "vite.config.mjs",
        "vite.config.ts",
        "vite.config.cjs"
      ];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  streamlit: [
    async (config2) => {
      const content = await getFile2(join12(config2.cwd, "requirements.txt"));
      if (!content) return false;
      const requirements = await parseRequirements(content);
      const hasStreamlit = requirements.find(
        (it) => it.type === "package" && it.package === "streamlit"
      );
      return !!hasStreamlit;
    }
  ],
  dotnet: [
    async (config2) => {
      return (await readdir(config2.cwd)).some((it) => it.endsWith(".csproj"));
    }
  ],
  deno: [
    async (config2) => {
      const configFiles = ["deno.json"];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  bun: [
    async (config2) => {
      const configFiles = ["package.json", "bun.lockb"];
      return configFiles.every((it) => existsSync3(join12(config2.cwd, it)));
    }
  ],
  node: [
    async (config2) => {
      const configFiles = [
        "package.json",
        "package-lock.json",
        "package-lock.jsonc"
      ];
      return configFiles.some((it) => existsSync3(join12(config2.cwd, it)));
    }
  ]
};
async function detectFramework(cwd) {
  for (const [framework, clues] of Object.entries(frameworks)) {
    for (const clue of clues) {
      if (await clue({ cwd })) {
        return framework;
      }
    }
  }
  return;
}
__name(detectFramework, "detectFramework");
var listCommand = new Command("list").action(() => {
  console.log(
    supportedFrameworks.map(
      (it) => `Framework: ${it} | ${renderMD(`[Guide](https://serverize.sh/#integrations-section)`)}`.trim()
    ).join("\n"),
    "\n"
  );
  box.print("Example", "$ npx serverize setup astrojs");
});
var setup_default = new Command("setup").alias("init").addCommand(listCommand).argument("[framework]", "Framework to setup").allowUnknownOption().option("-f, --force", "Force setup").option("-c, --cwd [cwd]", "Project directory", process.cwd()).action(
  async (framework, options) => {
    const projectDir = options?.cwd || process.cwd();
    spinner.start(framework ? "" : "Detecting framework...");
    framework ??= await detectFramework(projectDir);
    if (!framework) {
      spinner.fail(`Could not detect the framework in "${projectDir}"`);
      box.print(
        "Help",
        "- Run the command again with the framework name.",
        "- Example: $ npx serverize setup astrojs",
        "- Supported frameworks: $ npx serverize setup list",
        `- ${await renderMD(
          `Tell us what framework you're using in [discord](https://discord.gg/aj9bRtrmNt)`
        )}`
      );
      return;
    }
    spinner.info(`Framework/Language: ${chalk2.blue.bold(framework)}`);
    const dockerfilepath = join12(projectDir, "Dockerfile");
    if (existsSync3(dockerfilepath)) {
      if (process.env.NODE_ENV === "development") {
        spinner.warn(`Dockerfile already exists. Skipping...`);
      } else {
        await confirm({
          message: "Looks like you already have a Dockerfile. Do you want to overwrite it?"
        });
      }
    }
    switch (framework) {
      case "nextjs":
        {
          const configFilePath = (await readdir(projectDir)).find(
            (it) => it.startsWith("next.config.")
          );
          if (!configFilePath) {
            cli.error(
              `Detected Next.js framework but no next.config.js file found in the current directory.`
            );
            return;
          }
          const config2 = await readConfig(join12(projectDir, configFilePath));
          await nextjs({
            packageManager: await detect({ cwd: projectDir }),
            mode: config2.output
          }).save(dockerfilepath);
          await writeDockerIgnore(projectDir, nextjs.dockerignore);
        }
        break;
      case "nuxtjs":
        {
          const configFilePath = (await readdir(projectDir)).find(
            (it) => it.startsWith("nuxt.config.")
          );
          if (!configFilePath) {
            cli.error(
              `Detected "Nuxt.js" framework but no "nuxt.config" file found in the current directory.`
            );
            return;
          }
          const config2 = await readConfig(join12(projectDir, configFilePath), {
            static: true,
            callers: {
              defineNuxtConfig: /* @__PURE__ */ __name((config3) => {
                return config3;
              }, "defineNuxtConfig")
            }
          });
          const outputMode = "ssr" in config2 ? "static" : "ssr";
          spinner.info(`Output: ${outputMode}`);
          await nuxtjs({
            mode: outputMode,
            packageManager: await detect({ cwd: projectDir })
          }).save(dockerfilepath);
          await writeDockerIgnore(projectDir, nuxtjs.dockerignore);
        }
        break;
      case "astrojs":
        {
          const configFilePath = (await readdir(projectDir)).find(
            (it) => it.startsWith("astro.config.")
          );
          if (!configFilePath) {
            cli.error(
              `Detected "Astro" framework but no "astro.config" file found in the current directory.`
            );
            return;
          }
          const config2 = await readConfig(join12(projectDir, configFilePath), {
            static: true,
            callers: {
              defineConfig: /* @__PURE__ */ __name((config3) => {
                return config3;
              }, "defineConfig")
            }
          });
          spinner.info(`Output: ${config2.output}`);
          await astrojs({
            packageManager: await detect({ cwd: projectDir }),
            mode: config2.output
          }).save(dockerfilepath);
          await writeDockerIgnore(projectDir, astrojs.dockerignore);
        }
        break;
      case "vite":
        await vite({
          packageManager: await detect({ cwd: projectDir })
        }).save(dockerfilepath);
        await writeDockerIgnore(projectDir, vite.dockerignore);
        break;
      case "angular":
        {
          const ssr = (await readdir(projectDir)).some(
            (it) => it.endsWith("server.ts")
          );
          const outputMode = ssr ? "ssr" : "spa";
          spinner.info(`Output: ${outputMode}`);
          const angularJson = JSON.parse(
            await readFile6(join12(projectDir, "angular.json"), "utf-8")
          );
          const outputPath = safeFail(
            () => angularJson.projects.angular.architect.build.options.outputPath,
            "dist/angular"
          );
          await angular({
            packageManager: await detect({ cwd: projectDir }),
            mode: outputMode,
            outputPath
          }).save(dockerfilepath);
          await writeDockerIgnore(projectDir, angular.dockerignore);
        }
        break;
      case "streamlit": {
        await streamlit().save(dockerfilepath);
        await writeDockerIgnore(projectDir, streamlit.dockerignore);
        break;
      }
      case "dotnet": {
        const csProjFile = (await readdir(projectDir)).find(
          (it) => it.endsWith(".csproj")
        );
        if (!csProjFile) {
          cli.error(`Could not find .csproj file in ${projectDir}`);
          return;
        }
        const projectName = csProjFile.replace(".csproj", "");
        spinner.info(`Project name: ${projectName}`);
        await dotnet({ projectName }).save(dockerfilepath);
        await writeDockerIgnore(projectDir, dotnet.dockerignore);
        break;
      }
      case "remix": {
        const configFilePath = (await readdir(projectDir)).find(
          (it) => it.startsWith("vite.config.")
        );
        if (!configFilePath) {
          cli.error(
            `Detected "Vite" framework but no "vite.config" file found in the current directory.`
          );
          return;
        }
        const config2 = await readConfig(join12(projectDir, configFilePath), {
          static: true,
          callers: {
            defineConfig: /* @__PURE__ */ __name((config3) => {
              return config3.plugins.filter(Boolean).find((it) => it.remix);
            }, "defineConfig"),
            remix: /* @__PURE__ */ __name((config3) => {
              return { remix: true, mode: config3.ssr };
            }, "remix")
          }
        });
        const outputMode = config2?.mode === false ? "spa" : "ssr";
        spinner.info(`Output: ${outputMode}`);
        await remix({
          packageManager: await detect({ cwd: projectDir }),
          mode: outputMode
        }).save(dockerfilepath);
        await writeDockerIgnore(projectDir, remix.dockerignore);
        break;
      }
      case "deno": {
        await deno().save(dockerfilepath);
        await writeDockerIgnore(projectDir, deno.dockerignore);
        break;
      }
      case "bun": {
        const { content } = await readPackageJson(projectDir);
        let buildCommand = content.scripts?.build;
        if (!buildCommand) {
          spinner.info("Could not find a build script in package.json");
          buildCommand ??= await input3({
            message: "Build command",
            required: true,
            default: "bun build ./src/index.ts --outfile index.js"
          });
        }
        const entrypoint = await input3({
          message: 'Entrypoint (the --outfile of the "bun build" command)',
          default: "./index.js"
        });
        await bun({
          buildCommand,
          entrypoint
        }).save(dockerfilepath);
        await writeDockerIgnore(projectDir, bun.dockerignore);
        break;
      }
      case "node": {
        const { content } = await readPackageJson(projectDir);
        const tsconfig = getFile2(join12(projectDir, "tsconfig.json"));
        if (tsconfig && !content.scripts?.build) {
          spinner.fail(
            `Could not find a build script in package.json. Please add a build script to your package.json`
          );
          return;
        }
        const entrypoint = content.main ?? await input3({
          message: "Entrypoint (relative to the project root)",
          default: "./index.js"
        });
        await node({
          shouldBuild: !!content.scripts?.build,
          entrypoint,
          packageManager: await detect({ cwd: projectDir })
        }).save(dockerfilepath);
        await writeDockerIgnore(projectDir, node.dockerignore);
        break;
      }
      default:
        throw new Error(`Unknown framework ${framework}`);
    }
    spinner.succeed(`Dockerfile: ${join12(projectDir, "Dockerfile")}`);
    spinner.succeed(`.dockerignore: ${join12(projectDir, ".dockerignore")}`);
    spinner.succeed("Setup complete");
  }
);
function writeDockerIgnore(projectDir, dockerignore) {
  return writeFile5(
    join12(projectDir, ".dockerignore"),
    coerceArray(dockerignore).join("\n"),
    "utf-8"
  );
}
__name(writeDockerIgnore, "writeDockerIgnore");
async function parse4(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression)) {
    return null;
  }
  return resolveCallExpression(defaultExpr.expression, code);
}
__name(parse4, "parse");
async function dynamicConfig(path) {
  if (!path.endsWith(".ts")) {
    return import(path).then((x) => x.default);
  }
  const tempFile = join12(dirname8(path), `${crypto.randomUUID()}.mjs`);
  try {
    await fileBundler({
      entry: path,
      out: tempFile
    });
    return import(tempFile).then((x) => x.default);
  } finally {
    await rm3(tempFile, { force: true });
  }
}
__name(dynamicConfig, "dynamicConfig");
async function staticConfig(path, callers3) {
  const configContent = await readFile6(path, "utf-8");
  return staticEval(callers3, await parse4(configContent), {
    unknownCaller: /* @__PURE__ */ __name((node2, caller) => {
      return null;
    }, "unknownCaller")
  });
}
__name(staticConfig, "staticConfig");
async function readConfig(path, config2 = {}) {
  return config2.static ? staticConfig(path, config2.callers ?? {}) : dynamicConfig(path);
}
__name(readConfig, "readConfig");
function getFile2(filePath) {
  return existsSync3(filePath) ? readFile6(filePath, "utf-8") : null;
}
__name(getFile2, "getFile");
async function readPackageJson(dir) {
  const packageJsonPath = join12(dir, "package.json");
  const content = JSON.parse(
    await readFile6(packageJsonPath, "utf-8")
  );
  return {
    content,
    write: /* @__PURE__ */ __name((value = content) => writeFile5(packageJsonPath, JSON.stringify(value, null, 2), "utf-8"), "write")
  };
}
__name(readPackageJson, "readPackageJson");

// libs/remote/src/auth.ts
import { confirm as confirm2, input as input4, password } from "@inquirer/prompts";
import { Command as Command2 } from "commander";
import { signOut } from "firebase/auth";
import open from "open";
import validator2 from "validator";
var CLIENT_ID = process.env.NODE_ENV === "development" ? "Ov23liFrVjYBjqttXVYt" : "Ov23liTdbDl03bHIuT4N";
var REDIRECT_URI = `${serverizeUrl}/callback`;
async function github() {
  const timestamp = Date.now();
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    cache_bust: timestamp.toString(),
    redirect_uri: encodeURI(`${REDIRECT_URI}/github`)
  });
  const authUrl = `https://github.com/login/oauth/authorize?${params}`;
  await open(authUrl);
}
__name(github, "github");
async function google() {
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=1073944994711-7&redirect_uri=${REDIRECT_URI}/google&response_type=code`;
  await open(authUrl);
}
__name(google, "google");
async function selectProvider() {
  return "password";
}
__name(selectProvider, "selectProvider");
async function credsForm(validatePassword = true) {
  const email = await input4({
    message: "Email",
    validate: validator2.isEmail
  });
  const pw = await password({
    message: "Password",
    validate: /* @__PURE__ */ __name((value) => {
      if (!validatePassword) {
        return validator2.isStrongPassword(value, {
          minLength: 8,
          minLowercase: 0,
          minNumbers: 0,
          minUppercase: 0,
          minSymbols: 0
        });
      }
      const strongEnough = validator2.isStrongPassword(value, {
        minLength: 8,
        minLowercase: 1,
        minNumbers: 1,
        minUppercase: 1,
        minSymbols: 1
      });
      if (!strongEnough) {
        return "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one symbol.";
      }
      return true;
    }, "validate")
  });
  return { email, pw };
}
__name(credsForm, "credsForm");
async function askUser() {
  const user = await initialise();
  if (user) {
    const yes = await confirm2({
      message: "You are already signed in. Do you want to sign out first?",
      default: false
    });
    if (yes) {
      await signOut(auth);
      return true;
    }
    return false;
  }
  return true;
}
__name(askUser, "askUser");
var signin = new Command2("signin").alias("login").action(async () => {
  const wants = await askUser();
  if (!wants) {
    return;
  }
  const value = await selectProvider();
  switch (value) {
    case "github":
      await github();
      break;
    case "google":
      await signInWithGoogle();
      break;
    case "password":
      {
        try {
          const { email, pw } = await credsForm(false);
          tell("Signing in...");
          await signInWithEmail(email, pw);
          tell("Signed in");
        } catch (error) {
          spinner.fail(error.message);
        }
      }
      break;
  }
});
var signup = new Command2("signup").alias("register").action(async () => {
  const wants = await askUser();
  if (!wants) {
    return;
  }
  const value = await selectProvider();
  switch (value) {
    case "github":
      await github();
      break;
    case "google":
      await signInWithGoogle();
      break;
    case "password":
      {
        const { email, pw } = await credsForm();
        try {
          tell("Creating account...", true);
          const { user } = await signUpWithEmail(email, pw);
          tell("Few more things please...", true);
          const orgName = await input4({
            message: "Organization name",
            validate: /* @__PURE__ */ __name((v) => {
              const isValid = validator2.isAlpha(v, "en-US", { ignore: "-" });
              if (!isValid) {
                return "Organization name can only contain letters and hyphens";
              }
              return true;
            }, "validate")
          });
          const projectName = await askForProjectName();
          tell("Continuing...");
          const [res, orgError] = await request.post("/organizations/default", {
            uid: user.uid,
            name: orgName,
            projectName
          });
          if (orgError) {
            spinner.fail(orgError.message);
            await user.delete();
            return;
          }
          await user.reload();
          spinner.succeed(`You're ready to deploy ${projectName}`);
          console.log(
            box(
              `Deploy ${projectName}`,
              `To deploy: npx serverize deploy -p ${projectName}`,
              `To set secrets: npx serverize secrets set-file .env -p ${projectName}`
            )
          );
        } catch (error) {
          await auth.currentUser?.delete().catch(() => {
          });
          spinner.fail(error.message);
          process.exit(1);
        }
      }
      break;
  }
});
var signout = new Command2("signout").alias("logout").action(async () => {
  const user = await initialise();
  if (!user) {
    tell("Not authenticated");
    return;
  }
  const yes = await confirm2({
    message: "Are you sure you want to sign out?",
    default: false
  });
  if (yes) {
    await signOut(auth);
    tell("Signed out");
  }
});
var whoami = new Command2("whoami").action(async () => {
  const user = await initialise();
  if (user) {
    console.log(
      `Signed in as ${user.displayName || user.email || user.phoneNumber}`
    );
  } else {
    console.log("Not authenticated");
  }
});
var auth_default = new Command2("auth").description("Authenticate with serverize (signin, signup, signout)").addCommand(signin).addCommand(signup).addCommand(signout).addCommand(whoami);

// libs/remote/src/lib/instance.ts
import os from "os";
import {
  Observable,
  Subject,
  defer,
  from,
  map,
  merge,
  mergeMap,
  switchMap,
  tap as tap2
} from "rxjs";
import { PassThrough } from "stream";
import tarStream from "tar-stream";
var ContainerNotFoundError = class _ContainerNotFoundError extends Error {
  constructor(containerId) {
    super(`Container ${containerId} not found`);
    this.containerId = containerId;
    Error.captureStackTrace(this, _ContainerNotFoundError);
  }
  static {
    __name(this, "ContainerNotFoundError");
  }
};
var INTERNAL_PORT = 3e3;
function listenToDockerEvents(options) {
  const abortController = new AbortController();
  return new Observable((subscriber) => {
    const events = docker.getEvents({
      abortSignal: abortController.signal,
      ...options
    });
    from(events).pipe(
      switchMap((x) => x),
      map((buffer) => {
        return buffer.toString("utf-8").split("\n").map((it) => it.trim()).filter(Boolean).map((event) => {
          try {
            return JSON.parse(event);
          } catch (error) {
            console.error(
              "Failed to parse event:",
              event,
              "$$$chunk$$",
              buffer.toString("utf-8")
            );
            if (process.env["NODE_ENV"] === "development") {
              throw error;
            }
            return {};
          }
        });
      })
    ).subscribe(subscriber);
    return () => {
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
__name(listenToDockerEvents, "listenToDockerEvents");
function timestampParser(text) {
  if (!text.includes("Z")) {
    return { timestamp: "", rest: text };
  }
  let timestamp = "";
  do {
    timestamp += text.slice(0, 1);
    text = text.slice(1);
  } while (text.slice(0, 1) !== "Z");
  timestamp += text.slice(0, 1);
  text = text.slice(1);
  return {
    timestamp,
    rest: text
  };
}
__name(timestampParser, "timestampParser");
function containerLogs(containerName) {
  return new Observable((subscriber) => {
    const abortController = new AbortController();
    const container$ = defer(async () => {
      const container = await getContainer({ name: containerName });
      if (!container) {
        throw new ContainerNotFoundError(containerName);
      }
      return container;
    });
    const stream$ = container$.pipe(
      tap2((container) => {
        console.log(
          "Listening to logs for container:",
          containerName,
          ` (${container.id})`
        );
      }),
      switchMap(
        (container) => from(
          container.logs({
            // TODO: emit only from the start of the day
            follow: true,
            stdout: true,
            stderr: true,
            timestamps: true,
            details: true,
            abortSignal: abortController.signal
          })
        ).pipe(
          mergeMap((stream) => {
            const subject = new Subject();
            const write$ = new PassThrough({
              write(chunk, encoding, callback) {
                const output = chunk.toString();
                const lines = output.split("\n").map(timestampParser);
                lines.forEach(
                  (entry) => subject.next({ timestamp: entry.timestamp, log: entry.rest })
                );
                callback();
              }
            });
            container.modem.demuxStream(stream, write$, write$);
            return subject;
          })
        )
      )
    );
    stream$.subscribe(subscriber);
    return () => {
      console.log("ABORTING");
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
__name(containerLogs, "containerLogs");
function containerLogsRaw(containerName) {
  return new Observable((subscriber) => {
    const abortController = new AbortController();
    const container$ = defer(async () => {
      const container = await getContainer({ name: containerName });
      if (!container) {
        throw new ContainerNotFoundError(containerName);
      }
      return container;
    });
    const stream$ = container$.pipe(
      tap2((container) => {
        console.log(
          "Listening to logs for container:",
          containerName,
          ` (${container.id})`
        );
      }),
      switchMap(
        (container) => from(
          container.logs({
            // TODO: emit only from the start of the day
            follow: true,
            stdout: true,
            stderr: true,
            timestamps: false,
            details: true,
            abortSignal: abortController.signal
          })
        ).pipe(
          mergeMap((stream) => {
            const stdout = new PassThrough();
            const stderr = new PassThrough();
            const pass = merge(stdout, stderr);
            container.modem.demuxStream(stream, stdout, stderr);
            return pass;
          })
        )
      )
    );
    stream$.subscribe(subscriber);
    return () => {
      console.log("ABORTING");
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
__name(containerLogsRaw, "containerLogsRaw");
function calculateNContainerPerMachine(memoryPerContainerMB = 96) {
  const totalMemoryMB = os.totalmem() / (1024 * 1024);
  const totalCPUs = os.cpus().length;
  const numberOfContainers = Math.floor(totalMemoryMB / memoryPerContainerMB);
  const cpuPeriod = 1e5;
  const cpuQuota = Math.floor(cpuPeriod * totalCPUs / numberOfContainers);
  console.log({
    totalMemoryMB,
    totalCPUs,
    memoryPerContainerMB,
    numberOfContainers,
    cpuPeriod,
    cpuQuota
  });
  console.log({
    Memory: memoryPerContainerMB * 1024 * 1024,
    // Convert MB to bytes
    MemorySwap: memoryPerContainerMB * 4 * 1024 * 1024,
    // Four times the memory
    CpuPeriod: cpuPeriod,
    CpuQuota: cpuQuota
  });
}
__name(calculateNContainerPerMachine, "calculateNContainerPerMachine");
function createTar(files) {
  const pack = tarStream.pack();
  for (const { path, content } of files) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
__name(createTar, "createTar");

// libs/remote/src/lib/manager.ts
import { tmpdir as tmpdir3 } from "os";
import { join as join13 } from "path";
Error.stackTraceLimit = Infinity;
(async () => {
  await upsertNetwork("traefik-network");
})();
async function createRemoteServer(config2, processImage, env = {}, signal, instructions) {
  const recorder = createRecorder({
    label: `createClientServer:${config2.domainPrefix}`,
    verbose: true
  });
  const runnerContainerName = makeRunningContainerName(config2.domainPrefix);
  recorder.record("processImage");
  const runnerImageTag = await processImage();
  recorder.recordEnd("processImage");
  {
    recorder.record("removeContainer");
    await removeContainer(runnerContainerName).catch(() => {
    });
    recorder.recordEnd("removeContainer");
  }
  {
    recorder.record("startContainer");
    try {
      const container = await createRemoteContainer(
        runnerContainerName,
        runnerImageTag,
        signal,
        instructions,
        env
      );
      await container.start();
    } catch (error) {
      console.error(error);
      {
        recorder.record("removingErroredContainer");
        await removeContainer(runnerContainerName).catch(() => {
        });
        recorder.recordEnd("removingErroredContainer");
      }
      throw error;
    }
    recorder.recordEnd("startContainer");
  }
  recorder.end();
  return runnerContainerName;
}
__name(createRemoteServer, "createRemoteServer");
async function liveness(projectUrl) {
  const recorder = createRecorder({
    label: "isContainerAlive",
    verbose: true
  });
  recorder.record("healthCheck");
  await retryPromise(async () => {
    const res = await fetch(projectUrl);
    if (!res.ok) {
      throw new Error("Failed to fetch");
    }
  });
  recorder.recordEnd("healthCheck");
  recorder.end();
}
__name(liveness, "liveness");
async function createRemoteContainer(containerName, imageTag, signal, instructions, env = {}) {
  const mapPort = instructions.hostPort ? [{ HostPort: instructions.hostPort }] : [];
  const healthcheck = instructions.Healthcheck ? instructions.Healthcheck : void 0;
  if (healthcheck) {
    const cmd = healthcheck.Test.split(" ");
    const removeExit = cmd.findIndex((it) => it.toLowerCase() === "exit");
    let exit = [];
    if (removeExit !== -1) {
      exit = cmd.splice(removeExit - 1);
    }
    let healthCheckEndpoint = cmd.pop();
    healthCheckEndpoint = safeFail(
      () => JSON.parse(healthCheckEndpoint),
      healthCheckEndpoint
    );
    if (URL.canParse(healthCheckEndpoint)) {
      const url2 = new URL(healthCheckEndpoint);
      healthCheckEndpoint = url2.pathname;
    }
    healthCheckEndpoint = join13("/", healthCheckEndpoint);
    const url = `http://${containerName}:${instructions.internalPort ?? INTERNAL_PORT}${healthCheckEndpoint}`;
    healthcheck.Test = [
      ...cmd,
      url
      // exit.slice(0, 1), exit.slice(1).join(' ')
    ].flat().filter(Boolean);
  }
  const defaultRamReservePerContainerMb = 32;
  const defaultRamLimitPerContainerMb = 128;
  const defaultSwapPerContainerMb = defaultRamLimitPerContainerMb * 4;
  const container = await docker.createContainer({
    name: containerName,
    Image: imageTag,
    abortSignal: signal,
    Env: [
      // FIXME: keeping this for now till we generate debug database for each project
      // 'CONNECTION_STRING=postgresql://january-test_owner:U17cOgTaYXIm@ep-holy-flower-a5lkn70o.us-east-2.aws.neon.tech/january-test?sslmode=require',
      // 'NODE_ENV=development',
      // `PORT=${ports.internalPort}`,
      ...Object.entries(env).map(([key, value]) => `${key}=${value}`)
    ],
    Labels: {
      "traefik.enable": "true",
      [`traefik.http.routers.${containerName}.rule`]: `Host(\`${containerName}.beta.january.sh\`)`,
      [`traefik.http.routers.${containerName}.tls`]: "true",
      [`traefik.http.routers.${containerName}.tls.certresolver`]: "myresolver",
      [`traefik.http.services.${containerName}.loadbalancer.server.port`]: String(instructions.internalPort)
    },
    ExposedPorts: {
      [`${instructions.internalPort}/tcp`]: {}
      // '9229/tcp': {},
    },
    // NetworkingConfig: {
    //   EndpointsConfig: {
    //     'traefik-network': {},
    //   },
    // },
    platform: process.env["NODE_ENV"] === "production" ? "linux/amd64" : void 0,
    HostConfig: {
      // named volume to that has node_modules
      // Binds: [`node_modules:/app/node_modules`],
      NetworkMode: "traefik-network",
      // Instruct Docker to dynamically bind an available host port to container's port
      PortBindings: {
        [`${instructions.internalPort}/tcp`]: mapPort
      },
      Memory: defaultRamLimitPerContainerMb * 1024 * 1024,
      MemorySwap: defaultSwapPerContainerMb * 1024 * 1024,
      MemoryReservation: defaultRamReservePerContainerMb === defaultRamLimitPerContainerMb ? void 0 : defaultRamReservePerContainerMb * 1024 * 1024,
      RestartPolicy: {
        Name: "on-failure",
        MaximumRetryCount: 2
      },
      CpuPercent: 5
    },
    Healthcheck: healthcheck
  });
  return container;
}
__name(createRemoteContainer, "createRemoteContainer");
function makeProjectPath(projectId) {
  return join13(tmpdir3(), "client-server", projectId);
}
__name(makeProjectPath, "makeProjectPath");
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
__name(makeRunningImageName, "makeRunningImageName");
function makeRunningContainerName(projectId) {
  return projectId;
}
__name(makeRunningContainerName, "makeRunningContainerName");

// libs/remote/src/view-logs.ts
import debug3 from "debug";
import EventSource from "eventsource";
import { Observable as Observable2 } from "rxjs";
import { WebSocket } from "ws";
var logger2 = debug3("serverize");
function followLogs2(release2, next) {
  const ws = new WebSocket(`${serverizeWs}?apiKey=${release2.domainPrefix}`);
  ws.on("open", () => {
    logger2("Connected to runner server");
    ws.send(
      JSON.stringify({
        command: "logs",
        payload: {
          next: next ?? true
        }
      })
    );
  });
  ws.on("message", (data) => {
    logger2("Received message from runner server");
    console.log(data.toString());
  });
  ws.on("close", () => {
    logger2("Disconnected from source server");
    process.exit(0);
  });
}
__name(followLogs2, "followLogs");
function toBase64(data) {
  return Buffer.from(JSON.stringify(data)).toString("base64");
}
__name(toBase64, "toBase64");
function sse(ast, tarLocation, config2, token) {
  return new Observable2((subscriber) => {
    const eventSource = new EventSource(`${serverizeUrl}/progress`, {
      headers: {
        Authorization: token,
        "x-release": toBase64(config2),
        "x-docker": toBase64({
          port: parseInt(ast.expose || "3000", 10),
          Healthcheck: ast.healthCheckOptions || defaultHealthCheck
        }),
        "x-docker-tar": tarLocation
      }
    });
    eventSource.onmessage = (event) => {
      const payload = safeFail(() => JSON.parse(event.data), { message: "" });
      if (payload.type === "error") {
        subscriber.error(payload.message);
      } else if (payload.type === "complete") {
        subscriber.next(payload.message);
        subscriber.complete();
        eventSource.close();
      } else if (payload.type === "logs") {
        process.stdout.write(payload.message);
      } else {
        subscriber.next(payload.message);
      }
    };
    eventSource.onerror = (error) => {
      console.log(error);
      subscriber.error(error.data);
    };
    return () => {
      eventSource.close();
    };
  });
}
__name(sse, "sse");

// libs/remote/src/deploy.ts
import { AsyncLocalStorage as AsyncLocalStorage2 } from "async_hooks";
import { spawn } from "child_process";
import { watch } from "chokidar";
import { Command as Command3 } from "commander";
import { writeFileSync } from "fs";
import { readFile as readFile7 } from "fs/promises";
import { join as join14 } from "path";
import {
  Observable as Observable3,
  debounceTime,
  exhaustMap,
  finalize,
  from as from2,
  mergeMap as mergeMap2,
  switchMap as switchMap2,
  tap as tap3
} from "rxjs";
import { Upload } from "tus-js-client";
var als = new AsyncLocalStorage2();
var PROTOCOL = process.env.USE_PROTOCOL || "tus";
var deployPreviewCommand = new Command3("preview").option(
  "-pr, --preview [NAME]",
  "Preview deployment name"
);
var deploy_default = new Command3("deploy").usage("npx serverize deploy -p <projectName>").option("-w, --watch", "Watch for changes", false).option(
  "-f, --file [dockerfilepath]",
  'Name of the Dockerfile (default:"$(pwd)/Dockerfile")',
  "Dockerfile"
).option("-o, --output [file]", "Write output to a file").addOption(channelOption).addOption(releaseOption).addOption(projectOption).action(
  async ({
    watch: watch2,
    project: projectName,
    file: file2,
    channel,
    release: release2,
    output: outputFile
  }) => {
    spinner.start();
    const currentProject = await getCurrentProject(projectName);
    if (!currentProject) {
      return;
    }
    spinner.info(`Deploying (${currentProject.projectName})...`);
    const ast = await toAst2(file2);
    const domainPrefix = [
      currentProject.projectName,
      channel,
      release2 === "latest" ? "" : release2
      // createHash('sha1').digest('hex'),
    ].filter(Boolean).join("-");
    const releaseInfo = {
      channel,
      release: release2,
      projectId: currentProject.projectId,
      projectName: currentProject.projectName,
      image: makeRunningImageName(domainPrefix),
      domainPrefix
    };
    als.run({ ast, project: currentProject.projectName, releaseInfo }, () => {
      if (watch2) {
        logger("using watch mode");
        followLogs2(releaseInfo);
        watchFiles().pipe(
          exhaustMap((x) => sendImage()),
          tap3({
            next: tell,
            error: /* @__PURE__ */ __name((error) => {
              spinner.fail("Failed to push the image");
              console.error(error);
            }, "error")
          }),
          switchMap2(
            (tarLocation) => sse(ast, tarLocation, releaseInfo, currentProject.token).pipe(
              finalize(() => {
                spinner.info("Deployed. Waiting for changes...");
                spinner.info(
                  `Accessible at https://${releaseInfo.domainPrefix}.beta.january.sh`
                );
              })
            )
          )
        ).subscribe({
          next: tell,
          error: /* @__PURE__ */ __name((error) => {
            const message = safeFail(
              () => (typeof error === "string" ? error : error.message).trim(),
              ""
            );
            if (message) {
              spinner.fail(`Failed to process image: ${message}`);
            } else {
              spinner.fail(`Failed to process image`);
              console.error(error);
            }
          }, "error")
        });
      } else {
        from2(sendImage()).pipe(
          tap3({
            next: tell,
            error: /* @__PURE__ */ __name((error) => {
              spinner.fail("Failed to push the image");
              console.error(error);
              process.exit(1);
            }, "error")
          }),
          mergeMap2(
            (tarLocation) => sse(ast, tarLocation, releaseInfo, currentProject.token)
          )
        ).subscribe({
          next: tell,
          error: /* @__PURE__ */ __name((error) => {
            const message = safeFail(
              () => (typeof error === "string" ? error : error.message).trim(),
              ""
            );
            if (message) {
              spinner.fail(`Failed to process image: ${message}`);
            } else {
              spinner.fail(`Failed to process image`);
              console.error(error);
            }
            process.exit(1);
          }, "error"),
          complete: /* @__PURE__ */ __name(() => {
            const url = `https://${releaseInfo.domainPrefix}.beta.january.sh`;
            spinner.succeed("Deployed successfully");
            box.print(
              `${currentProject.projectName} Deployed`,
              `Accessible at ${url}`,
              `Logs: npx serverize logs -a ${currentProject.projectName}`,
              `Stuck? Join us at https://discord.gg/aj9bRtrmNt`
            );
            if (outputFile) {
              writeFileSync(
                outputFile,
                JSON.stringify({
                  project: currentProject.projectName,
                  url
                }),
                "utf-8"
              );
            }
          }, "complete")
        });
      }
    });
  }
);
function createWatcher(files) {
  return new Observable3((subscriber) => {
    const watcher = watch(files, {
      cwd: process.cwd(),
      persistent: true
    });
    watcher.on("all", async (event, path) => {
      subscriber.next(path);
    });
    watcher.on("error", (error) => {
      subscriber.error(error);
    });
    return () => {
      watcher.close();
    };
  });
}
__name(createWatcher, "createWatcher");
function readFiles(files) {
  return Promise.all(
    files.map(async (file2) => ({
      path: file2,
      content: await readFile7(join14(process.cwd(), file2), "utf-8"),
      // FIXME: we should use the file size to determine if the file has changed
      // or we should use the file hash to determine if the file has changed
      hasChanged: true
    }))
  );
}
__name(readFiles, "readFiles");
function getAst() {
  const value = als.getStore();
  if (!value) {
    throw new Error(
      `Couldn't parse the Dockerfile. This is most likely a bug. Please report it.`
    );
  }
  return value.ast;
}
__name(getAst, "getAst");
function getReleaseInfo() {
  const value = als.getStore();
  if (!value) {
    throw new Error(
      `Couldn't get project name. This is most likely a bug. Please report it.`
    );
  }
  return value.releaseInfo;
}
__name(getReleaseInfo, "getReleaseInfo");
function getProject() {
  const value = als.getStore();
  if (!value) {
    throw new Error(
      `Couldn't get project name. This is most likely a bug. Please report it.`
    );
  }
  return value.project;
}
__name(getProject, "getProject");
function watchFiles() {
  const ast = getAst();
  logger(`Watching files 
${ast.paths.join(", ")}
`);
  return createWatcher(ast.paths).pipe(debounceTime(1e3));
}
__name(watchFiles, "watchFiles");
async function sendImage(quiet = false) {
  const ast = getAst();
  if (!ast.expose) {
    spinner.warn("No exposed port found, use 3000 as default");
  }
  if (!ast.healthCheckOptions) {
    spinner.warn(`No health check options found, using default health check`);
  }
  switch (PROTOCOL) {
    case "tus":
      return useTus(quiet);
    default:
      return useHttp(quiet);
  }
}
__name(sendImage, "sendImage");
async function useHttp(quiet = false) {
  const tar = await saveImage(quiet);
  tell("Pushing the image...");
  const response = await fetch(`${serverizeUrl}/upload`, {
    method: "POST",
    duplex: "half",
    body: tar,
    headers: {
      "x-release": toBase64(getReleaseInfo()),
      "Content-Type": "application/x-tar",
      Authorization: process.env.SERVERIZE_API_TOKEN || await auth.currentUser?.getIdToken()
    }
  });
  if (!response.ok) {
    const error = await response.text();
    throw {
      status: response.statusText,
      message: error
    };
  }
  return response.text();
}
__name(useHttp, "useHttp");
async function useTus(quiet = false) {
  const tar = await saveImage(quiet);
  const releaseInfo = getReleaseInfo();
  tell("Pushing the image...");
  const bytes = /* @__PURE__ */ __name((mb) => mb * 1024 * 1024, "bytes");
  const chunkSize = bytes(50);
  return new Promise((resolve2, reject) => {
    const upload = new Upload(tar, {
      endpoint: `${serverizeUrl}/uploads`,
      // 50MB chunk size
      chunkSize,
      uploadLengthDeferred: true,
      metadata: {
        filename: releaseInfo.image,
        filetype: "application/x-tar"
      },
      onError: reject,
      onSuccess() {
        resolve2(upload.url.replace(this.endpoint, ""));
      }
    });
    upload.start();
  });
}
__name(useTus, "useTus");
async function saveImage(quiet = false) {
  const releaseInfo = getReleaseInfo();
  await buildImage(quiet);
  printDivider();
  console.log("\n");
  return docker.getImage(releaseInfo.image).get();
}
__name(saveImage, "saveImage");
function buildImage(quiet = false) {
  const ast = getAst();
  const releaseInfo = getReleaseInfo();
  return new Promise((resolve2, reject) => {
    const platforms = ["linux/amd64"];
    const options = [
      "--pull",
      "--rm",
      "-t",
      releaseInfo.image,
      "-f",
      ast.dockerfile,
      "--platform",
      platforms.join(","),
      "."
    ];
    if (quiet) {
      options.push("--quiet");
    }
    console.log("\n");
    printDivider();
    const ls = spawn("docker", ["build", ...options], {
      cwd: process.cwd(),
      stdio: "inherit",
      env: {
        ...process.env,
        DOCKER_CLI_HINTS: "false",
        DOCKER_BUILDKIT: "1"
      }
    });
    ls.on("close", (code) => {
      if (code === 0) {
        resolve2();
      } else {
        reject();
      }
    });
  });
}
__name(buildImage, "buildImage");
var getStreamSize = /* @__PURE__ */ __name((stream) => {
  return new Promise((resolve2, reject) => {
    let size = 0;
    stream.on("data", (chunk) => {
      size += chunk.length;
    });
    stream.on("end", () => {
      resolve2(size);
    });
    stream.on("error", (err) => {
      reject(err);
    });
  });
}, "getStreamSize");

// libs/remote/src/logs.ts
import { Command as Command4 } from "commander";
var logs_default = new Command4("logs").usage("npx serverize logs -p <projectName>").addOption(projectOption).action(({ project: project2 }) => {
  followLogs2(project2, false);
});

// libs/remote/src/project.ts
import { Command as Command5 } from "commander";
var create = new Command5("create").argument("[name]", "Name of the project").action(async (name) => {
  const user = await ensureUser();
  if (!user) return;
  name ??= await askForProjectName();
  const [res, error] = await request.post(`/projects`, {
    name,
    workspaceId: user.claims.workspaceId
  });
  if (error) {
    spinner.fail(error.message);
    process.exit(1);
  }
  spinner.succeed(`Project ${name} created`);
});
var list = new Command5("list").action(async (name) => {
  const user = await ensureUser();
  if (!user) return;
  const [projects = { records: [] }, error] = await fetchProjects();
  if (error) {
    spinner.fail(error.message);
    process.exit(1);
  }
  if (projects.records.length === 0) {
    box.print(
      "No projects found",
      "Create a project by running:",
      "$ npx serverize projects create <project-name>"
    );
    return;
  }
  console.table(projects.records, ["id", "name"]);
});
var project_default = new Command5("projects").description("Manage your projects").addCommand(create).addCommand(list);

// libs/remote/src/releases.ts
import { Command as Command6 } from "commander";
var list2 = new Command6("list").addOption(projectOption.makeOptionMandatory(false)).action(async ({ project: project2 }) => {
  const currentProject = await getCurrentProject(project2);
  if (!currentProject) return;
  const [releases = { records: [] }] = await fetchReleases({
    projectId: currentProject.projectId
  });
  if (!releases) return;
  if (releases.records.length === 0) {
    box.print(
      "No releases found",
      "Create a release by running:",
      "$ npx serverize deploy -p <project-name>"
    );
    return;
  }
  console.table(
    releases.records.map((release2) => ({
      // ID: token.id,
      Project: release2.project.name,
      "Created At": release2.createdAt,
      Status: release2.status,
      Conclusion: release2.conclusion,
      Name: release2.name,
      Channel: release2.channel
    }))
  );
});
var stop = new Command6("stop").addOption(channelOption.makeOptionMandatory(true)).addOption(releaseOption).addOption(projectOption).action(async ({ project: projectName, channel, release: release2 }) => {
  const currentProject = await getCurrentProject(projectName);
  if (!currentProject) return;
  const [releases = { records: [] }, error] = await fetchReleases({
    channel,
    projectId: currentProject.projectId,
    name: release2,
    status: "completed",
    conclusion: "success"
  });
  if (error) {
    spinner.fail(error.message);
    return;
  }
  const releaseData = releases.records[0];
  await request.remove(
    "/terminate",
    {},
    {
      baseUrl: serverizeUrl,
      withAuth: false,
      headers: {
        Authorization: `Bearer ${currentProject.token}`,
        "x-release": toBase64({
          id: releaseData.id,
          containerName: releaseData.containerName
        })
      }
    }
  );
  if (error) {
    spinner.fail(error.message);
    return;
  }
  const [, stoppingReleaseError] = await stopRelease(releaseData.id);
  if (stoppingReleaseError) {
    spinner.fail(stoppingReleaseError.message);
    return;
  }
  spinner.succeed(
    `Release ${releaseData.name} of ${channel} stopped successfully`
  );
});
var releases_default = new Command6("releases").addCommand(list2).addCommand(stop);

// libs/remote/src/secrets.ts
import { Command as Command7 } from "commander";
import { parse as parse5 } from "dotenv";
import { readFile as readFile8 } from "fs/promises";
import { join as join15 } from "path";
var setCommand = new Command7("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in format NAME=VALUE").addOption(projectOption).action(async (secretsList, { project: project2 }) => {
  const currentProject = await getCurrentProject(project2);
  if (!currentProject) {
    return;
  }
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error(`Secret "${secret}" must be in the format NAME=VALUE`);
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await setSecret({
      projectId: currentProject.projectId,
      secretLabel: name,
      secretValue: value
    });
  }
  spinner.succeed("Secrets set successfully");
});
var setFileCommand = new Command7("set-file").usage("[options] .env").argument("<envFile>", "Path to the file with secrets").addOption(projectOption).action(async (file2, { project: project2 }) => {
  const currentProject = await getCurrentProject(project2);
  if (!currentProject) {
    return;
  }
  const secrets = Object.entries(
    parse5(await readFile8(join15(process.cwd(), file2), "utf-8"))
  );
  for (const [name, value] of secrets) {
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await setSecret({
      projectId: currentProject.projectId,
      secretLabel: name,
      secretValue: value
    });
  }
  spinner.succeed("Secrets set successfully");
});
var secrets_default = new Command7("secrets").description("Manage project secrets").addCommand(setCommand).addCommand(setFileCommand);

// libs/remote/src/tokens.ts
import chalk3 from "chalk";
import { Command as Command8 } from "commander";
var create2 = new Command8("create").addOption(projectOption.makeOptionMandatory(false)).action(async ({ name }) => {
  const user = await ensureUser();
  if (!user) return;
  const [projects = { records: [] }] = await fetchProjects();
  if (projects.records.length === 0) {
    box.print(
      "No projects found",
      "$ npx serverize projects create <project-name>"
    );
    return;
  }
  let projectId = projects.records.length === 1 ? projects.records[0].id : "";
  if (name) {
    const [project2] = projects.records.filter(
      (project3) => project3.name === name
    );
    if (!project2) {
      spinner.fail(`Project ${chalk3.red(name)} not found`);
      return;
    }
    projectId = project2.id;
  }
  projectId ??= await dropdown({
    title: "Select a project",
    choices: projects.records.map(({ name: name2, id }) => ({ name: name2, value: id }))
  });
  const [data, error] = await request.post("/tokens", { projectId });
  if (error || !data) return;
  box.print("Save it in secure place", data);
});
var revoke = new Command8("revoke").action(async () => {
  const user = await ensureUser();
  if (!user) return;
  await request.remove("/tokens", {});
});
var list3 = new Command8("list").action(async () => {
  const user = await ensureUser();
  if (!user) return;
  const [tokens] = await fetchTokens();
  if (!tokens) return;
  if (tokens.length === 0) {
    box.print(
      "No tokens found",
      "$ npx serverize tokens create <project-name>"
    );
    return;
  }
  console.table(
    tokens.map((token) => ({
      Project: token.project.name,
      "Created At": token.createdAt
    }))
  );
});
var tokens_default = new Command8("tokens").addCommand(create2).addCommand(list3).addCommand(revoke);

// libs/remote/src/cli.ts
cli.action(async () => {
  box.print(
    "Welcome!",
    "",
    "Serverize makes it effortless to deploy your project to the cloud and have it running in seconds.",
    "",
    "Get started in three simple steps:",
    "",
    "1. Sign in or create an account.",
    "	 - To log in: $ npx serverize auth signin",
    "	 - To sign up: $ npx serverize auth signup",
    "2. Containerize your project.",
    "	 - $ npx serverize setup [nextjs|nuxtjs|vite|..etc]",
    `	 - ${renderMD(
      "You can find list of frameworks in the [Integrations section](https://serverize.sh/#integrations-section)."
    )}`,
    "3. Once logged in, setup ready, run the deploy command",
    "	 - To deploy: $ npx serverize deploy -p <project-name>",
    "",
    "For more commands, run $ npx serverize --help"
  );
}).addCommand(deploy_default).addCommand(secrets_default).addCommand(logs_default).addCommand(auth_default).addCommand(project_default).addCommand(tokens_default).addCommand(releases_default).addCommand(setup_default).parse(process.argv);
//# sourceMappingURL=cli.js.map
