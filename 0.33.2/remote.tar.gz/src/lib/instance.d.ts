import type { GetEventsOptions } from 'dockerode';
import { Observable } from 'rxjs';
import tarStream from 'tar-stream';
import type { BundableFile } from '@january/generator/bundler';
export declare class ContainerNotFoundError extends Error {
    containerId: string;
    constructor(containerId: string);
}
export declare const INTERNAL_PORT = 3000;
export declare function listenToDockerEvents(options: Omit<GetEventsOptions, 'abortSignal'>): Observable<any[]>;
export interface LogEntry {
    timestamp: string;
    log: string;
}
export declare function containerLogs(containerName: string): Observable<LogEntry>;
export declare function containerLogsRaw(containerName: string): Observable<any>;
export declare function createTar(files: BundableFile[]): tarStream.Pack;
