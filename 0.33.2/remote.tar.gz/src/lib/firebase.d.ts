export declare const auth: import("@firebase/auth").Auth;
