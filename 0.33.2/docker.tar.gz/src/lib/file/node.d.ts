import { type PackageManager } from './utils';
export declare const node: {
    (config: {
        packageManager?: PackageManager;
        shouldBuild?: boolean;
        entrypoint: string;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
