import { type PackageManager } from './utils';
export type RemixOutputMode = 'ssr' | 'spa';
export declare const remix: {
    (config: {
        packageManager?: PackageManager;
        mode: RemixOutputMode;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
