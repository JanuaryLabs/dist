import type { Extension } from '../extension';
export interface Database extends Extension {
    id: string;
    options: Record<string, any>;
}
