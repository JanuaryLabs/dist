interface Requirement {
    type: 'requirement' | 'package' | 'url';
    file?: string | null;
    package?: string | null;
    version?: string | null;
    specifier?: string | null;
    envMarker?: string | null;
    extras?: string[] | null;
    url?: string | null;
}
export declare function parseRequirements(content: string): Promise<Requirement[]>;
export {};
