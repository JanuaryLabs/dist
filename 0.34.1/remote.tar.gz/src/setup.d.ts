import { Command } from 'commander';
declare const _default: Command;
export default _default;
