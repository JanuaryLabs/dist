export declare function output(returnStr: string): string;
export declare namespace output {
    var forbidden: () => string;
    var empty: () => string;
}
