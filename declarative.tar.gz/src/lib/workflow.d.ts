import { refineExecute } from './utils';
export type MapObj<T> = T extends {
    value: infer Value;
} ? Value : T;
export type InferTriggerProps<T> = T extends TriggerDefinition<infer TriggerProps, infer MappedProps, infer TriggerConfig> ? TriggerProps extends unknown[] ? TriggerProps : never : never;
export interface WorkflowDefinition<Trigger extends TriggerDefinition<unknown, unknown>> {
    name: string;
    trigger: Trigger;
    execute: any;
    tag: string;
    raw?: boolean;
}
export interface TriggerDefinition<RT, Mapper, Config = Record<string, unknown>> {
    type: string;
    config: Config;
    policies?: string[];
    inputs?: Record<string, {
        value: string;
    }>;
    refineExecute: (execute: any) => ReturnType<typeof refineExecute>;
}
export interface ActionDefinition<Output = unknown> {
    type: string;
    config: Record<string, unknown>;
}
export declare function experimental_wokflow(features: any[]): void;
export declare function workflow<Trigger extends TriggerDefinition<unknown, unknown>>(name: string, config: WorkflowConfig<Trigger>): WorkflowDefinition<Trigger>;
export type WorkflowConfig<Trigger extends TriggerDefinition<unknown, unknown>> = {
    tag: string;
    trigger: Trigger;
    execute: (...args: InferTriggerProps<Trigger>) => unknown;
};
export declare namespace trigger {
    function schedule(config: {
        pattern: string;
        immediate?: boolean;
    }): TriggerDefinition<never, never>;
}
export declare namespace trigger { }
export declare namespace policy { }
export declare namespace trigger {
    namespace http {
        interface created {
            (value: Record<string, any>): void;
            (uri: string | URL, value?: Record<string, any>): void;
        }
        interface redirect {
            (uri: string | URL): void;
            (uri: string | URL, statusCode: 300 | 301 | 302 | 303 | 304): void;
        }
        interface nocontent {
            (): void;
        }
        interface ok {
            (): void;
            (value: Record<string, any>): void;
        }
        interface raw {
            (value: any): void;
        }
        export interface output {
            created: created;
            redirect: redirect;
            ok: ok;
            raw: raw;
            nocontent: nocontent;
        }
        export interface outputWithFinalizer extends output {
            finalize: () => Response;
        }
        export {};
    }
}
