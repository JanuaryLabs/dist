import type { refineExecute } from '@january/generator';
export type MapObj<T> = T extends {
    value: infer Value;
} ? Value : T;
export type InferTriggerProps<T> = T extends TriggerDefinition<infer TriggerProps> ? TriggerProps extends unknown[] ? TriggerProps : never : never;
export interface WorkflowDefinition<Trigger extends TriggerDefinition<unknown>> {
    name: string;
    trigger: Trigger;
    execute: any;
    tag: string;
    raw?: boolean;
}
export interface TriggerDefinition<RT> {
    type: string;
    config: Record<string, unknown>;
    policies?: string[];
    inputs?: Record<string, {
        value: string;
    }>;
    refineExecute: (execute: any) => ReturnType<typeof refineExecute>;
}
export interface ActionDefinition<Output = unknown> {
    type: string;
    config: Record<string, unknown>;
}
export declare function experimental_wokflow(features: any[]): void;
export declare function workflow<Result extends any, Trigger extends TriggerDefinition<unknown>>(name: string, config: WorkflowConfig<Trigger, Result>): {
    name: string;
    trigger: Trigger;
    raw: boolean;
    execute: {
        structures: import("ts-morph").ImportDeclarationStructure[];
        code: string;
        inputs: Record<string, {
            value: string;
            input: string;
            type?: string;
            static?: boolean;
            data?: Record<string, any>;
        }>;
    };
    tag: string;
};
export type WorkflowConfig<Trigger extends TriggerDefinition<unknown>, R> = {
    tag: string;
    trigger: Trigger;
    execute: (...args: InferTriggerProps<Trigger>) => R;
};
export declare namespace trigger { }
export declare namespace policy { }
export declare namespace trigger {
    namespace http {
        interface created {
            (value: Record<string, any>): void;
            (uri: string | URL, value?: Record<string, any>): void;
        }
        interface redirect {
            (uri: string | URL): void;
            (uri: string | URL, statusCode: 300 | 301 | 302 | 303 | 304): void;
        }
        interface nocontent {
            (): void;
        }
        interface ok {
            (): void;
            (value: any): void;
        }
        interface raw {
            (value: any): void;
        }
        export interface output {
            created: created;
            redirect: redirect;
            ok: ok;
            raw: raw;
            nocontent: nocontent;
        }
        export interface outputWithFinalizer extends output {
            finalize: () => Response;
        }
        export {};
    }
}
