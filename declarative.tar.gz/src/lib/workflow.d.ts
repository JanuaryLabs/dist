import type { EmitterWebhookEvent, EmitterWebhookEventName } from '@octokit/webhooks';
import type { Server } from '@tus/server';
import type { IncomingMessage } from 'http';
import type z from 'zod';
import type { Policy } from './feature';
import { refineExecute } from './utils';
export type MapObj<T> = T extends {
    value: infer Value;
} ? Value : T;
type InferZodProp<T> = T extends {
    against: infer Against;
} ? Against extends z.ZodType<any, any, any> ? z.infer<Against> : never : T;
type Input<T> = {
    [K in keyof T]: InferZodProp<T[K]>;
};
export type InferTriggerProps<T> = T extends TriggerDefinition<infer TriggerProps, infer MappedProps, infer TriggerConfig> ? TriggerProps extends unknown[] ? TriggerProps : never : never;
export interface WorkflowDefinition<Trigger extends TriggerDefinition<unknown, unknown>> {
    name: string;
    trigger: Trigger;
    execute: any;
    tag: string;
    raw?: boolean;
}
export interface TriggerDefinition<RT, Mapper, Config = Record<string, unknown>> {
    type: string;
    config: Config;
    policies?: string[];
    inputs?: Record<string, {
        value: string;
    }>;
    refineExecute: (execute: any) => ReturnType<typeof refineExecute>;
}
export interface ActionDefinition<Output = unknown> {
    type: string;
    config: Record<string, unknown>;
}
export declare function experimental_wokflow(features: any[]): void;
export declare function workflow<Trigger extends TriggerDefinition<unknown, unknown>>(name: string, config: WorkflowConfig<Trigger>): WorkflowDefinition<Trigger>;
export type WorkflowConfig<Trigger extends TriggerDefinition<unknown, unknown>> = {
    tag: string;
    trigger: Trigger;
    execute: (...args: InferTriggerProps<Trigger>) => unknown;
};
export declare namespace trigger {
    function fromConfig(type: string, ...args: unknown[]): TriggerDefinition<unknown, unknown>;
}
export declare namespace trigger {
    function schedule(config: {
        pattern: string;
        immediate?: boolean;
    }): TriggerDefinition<never, never>;
}
export declare namespace trigger {
    export interface HttpTrigger {
        body: Record<string, any>;
        query: Record<string, string>;
        headers: Record<string, string>;
        path: Record<string, string>;
    }
    export type HttpTriggerConfig<M> = {
        path: string;
        method: string;
        policies?: string[];
        input?: (trigger: HttpTrigger) => M;
    };
    interface created {
        (value: Record<string, any>): void;
        (uri: string | URL, value?: Record<string, any>): void;
    }
    interface redirect {
        (uri: string | URL): void;
        (uri: string | URL, statusCode: 300 | 301 | 302 | 303 | 304): void;
    }
    interface ok {
        (): void;
        (value: Record<string, any>): void;
    }
    export function http<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[
        {
            trigger: HttpTrigger;
            input: Input<M>;
            output: http.output;
        },
        IncomingMessage
    ], M>;
    export namespace http {
        interface output {
            created: created;
            redirect: redirect;
            ok: ok;
        }
        interface outputWithFinalizer extends output {
            finalize: () => Response;
        }
    }
    export const httpConfigSchema: import("ajv/dist/types/json-schema").PartialSchema<HttpTriggerConfig<any>>;
    export {};
}
export declare namespace trigger {
    interface SSETrigger {
        body: Record<string, any>;
        query: Record<string, string>;
        headers: Record<string, string>;
        path: Record<string, string>;
    }
    function sse(config: {
        path: string;
        policies?: string[];
    }): TriggerDefinition<[{
        trigger: HttpTrigger;
    }, IncomingMessage], unknown>;
    function websocket(config: {
        topic: string;
        policies?: string[];
    }): TriggerDefinition<[SSETrigger, IncomingMessage], unknown>;
    function stream<M>(config: HttpTriggerConfig<M>): TriggerDefinition<[HttpTrigger, IncomingMessage], M>;
}
export declare namespace trigger {
    function github<EventName extends EmitterWebhookEventName, Y>(config: {
        event: EventName;
        policies?: string[];
    }): TriggerDefinition<[EmitterWebhookEvent<EventName>], Y>;
}
export declare namespace trigger {
    /**
     * expermintal
     */
    function tus(config: Omit<ConstructorParameters<typeof Server>[0], 'allowedCredentials' | 'allowedHeaders' | 'allowedMethods' | 'allowedOrigins' | 'respectForwardedHeaders' | 'relativeLocation'> & {
        policies?: string[];
    }): TriggerDefinition<[
        {
            id: string;
            mimeType: string;
            size: string;
        },
        IncomingMessage
    ], unknown>;
}
export declare namespace trigger {
    function file(config: {
        path: string;
        root?: string;
        rewrite?: (path: string) => string;
        policies?: string[];
    }): TriggerDefinition<[string], string>;
}
export declare function policy(rule: string): string;
export declare namespace policy {
    var unstable_country: (country: string) => string;
}
export declare namespace policy {
    function fromConfig(type: string, ...args: unknown[]): Policy;
    function authenticated(): Policy;
    function github<EventName extends EmitterWebhookEventName>(config: {
        events?: EventName[];
        guard?: (event: EmitterWebhookEvent<EventName>) => boolean | undefined;
    }): Policy;
}
export {};
