export interface ValidationDefinition {
    name: string;
    details: Record<string, unknown>;
}
export declare function mandatory(config?: {
    message?: string;
}): ValidationDefinition;
export declare const required: typeof mandatory;
export declare function unique(config?: {
    message?: string;
}): ValidationDefinition[];
export declare namespace validation {
    function fromConfig(type: string, ...args: unknown[]): ValidationDefinition[];
}
