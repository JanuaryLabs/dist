import type { Command } from '@faslh/isomorphic';
import type { ProjectDefinition } from './project';
export interface TableDefinition<Fields extends Record<string, FieldDefinition> = Record<string, FieldDefinition>> {
    fields: Fields;
    constraints: Constraint[];
}
export interface FieldDefinition {
    type: string;
    details: Record<string, unknown>;
    validations: (ValidationDefinition | ValidationDefinition[])[];
}
export interface ValidationDefinition {
    name: string;
    details: Record<string, unknown>;
}
export interface InputDefinition {
    input: string;
    data?: Record<string, unknown>;
}
export declare function table<Fields extends Record<string, FieldDefinition>>(config: {
    fields: Fields;
    constraints?: Constraint[];
    unique?: Constraint;
}): TableDefinition<Fields>;
export declare namespace table {
    var unique: (...fields: UseField[]) => Constraint;
    var index: (...fields: UseField[]) => Constraint;
    var use: typeof useTable;
}
export type UseTable = Command<{
    name: string;
}, ProjectDefinition>;
export declare function useTable(name: string): UseTable;
export declare function field(config: {
    type: string;
    validations?: (ValidationDefinition | ValidationDefinition[])[];
    metadata?: Record<string, unknown>;
}): FieldDefinition;
export declare namespace field {
    var _a: (config: {
        values: string[];
        defaultValue?: string;
    }) => FieldDefinition;
    export { _a as enum };
}
export declare namespace field {
    function fromConfig(type: string, ...args: unknown[]): FieldDefinition;
    function primary(config: {
        type: 'uuid' | 'number' | 'string';
        generated?: boolean;
    }): FieldDefinition;
    function shortText(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function longText(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function datetime(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        nativeType?: 'utc' | 'local';
    }): {
        type: string;
        details: {
            defaultValue?: string;
            nativeType?: "utc" | "local";
        };
        validations: (ValidationDefinition | ValidationDefinition[])[];
    };
    function url(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function integer(): FieldDefinition;
    function decimal(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        precision?: number;
        scale?: number;
    }): FieldDefinition;
    function price(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        precision?: number;
        scale?: number;
    }): FieldDefinition;
    function relation(config: {
        references: UseTable;
        relationship: 'one-to-one' | 'many-to-one' | 'many-to-many';
        validations?: (ValidationDefinition | ValidationDefinition[])[];
    }): FieldDefinition;
}
export type UseField = {
    input: string | Command<{
        name: string;
    }, ProjectDefinition>;
    name?: string | Command<{
        name: string;
    }, ProjectDefinition>;
    data?: Record<string, unknown>;
};
export interface Constraint {
    type: string;
    details: unknown;
}
export declare function useField(name: string, value?: string | number | boolean | null): UseField;
export declare namespace useField {
    var increment: (name: string, value: string | number) => UseField;
    var decrement: (name: string, value: string | number) => UseField;
}
export declare function index(...fields: UseField[]): Constraint;
