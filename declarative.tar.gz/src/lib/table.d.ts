import { type ValidationDefinition } from './validation';
export interface TableDefinition<Fields extends Record<string, FieldDefinition> = Record<string, FieldDefinition>> {
    fields: Fields;
    constraints: Constraint[];
}
export interface FieldDefinition {
    type: string;
    details: Record<string, unknown>;
    validations: (ValidationDefinition | ValidationDefinition[])[];
}
export interface InputDefinition {
    input: string;
    data?: Record<string, unknown>;
}
export declare function table<Fields extends Record<string, FieldDefinition>>(config: {
    fields: Fields;
    constraints?: Constraint[];
    unique?: Constraint;
}): TableDefinition<Fields>;
export declare namespace table {
    function fromConfig(type: string, ...args: unknown[]): TableDefinition;
    function link(config: {
        table1: any;
        table2: any;
        fields?: Record<string, FieldDefinition>;
        constraints?: Constraint[];
    }): TableDefinition;
}
export declare function field(config: {
    type: string;
    validations?: (ValidationDefinition | ValidationDefinition[])[];
    metadata?: Record<string, unknown>;
}): FieldDefinition;
export declare namespace field {
    var _a: (config: {
        values: readonly string[];
        defaultValue?: string;
        validations?: (ValidationDefinition | ValidationDefinition[])[];
    }) => FieldDefinition;
    export { _a as enum };
}
export declare namespace field {
    function fromConfig(type: string, ...args: unknown[]): FieldDefinition;
    function primary(config: {
        type: 'uuid' | 'number' | 'string';
        generated?: boolean;
    }): FieldDefinition;
    function shortText(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function longText(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function datetime(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        nativeType?: 'utc' | 'local';
    }): {
        type: string;
        details: {
            defaultValue?: string;
            nativeType?: "utc" | "local";
        };
        validations: (ValidationDefinition | ValidationDefinition[])[];
    };
    function url(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        length?: number;
    }): FieldDefinition;
    function integer(): FieldDefinition;
    function decimal(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        precision?: number;
        scale?: number;
    }): FieldDefinition;
    function price(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
        precision?: number;
        scale?: number;
    }): FieldDefinition;
    function boolean(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: boolean;
    }): FieldDefinition;
    function bytes(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
    }): FieldDefinition;
    function email(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
    }): FieldDefinition;
    function json(config?: {
        validations?: (ValidationDefinition | ValidationDefinition[])[];
        defaultValue?: string;
    }): FieldDefinition;
    function relation(config: {
        references: any;
        relationship: 'one-to-one' | 'many-to-one' | 'many-to-many';
        validations?: (ValidationDefinition | ValidationDefinition[])[];
    }): FieldDefinition;
}
export interface Constraint {
    type: string;
    details: unknown;
}
export declare function index(...fields: string[]): Constraint;
