import type { GenericQueryCondition, GroupQueryCondition, PeriodData, QueryColumn, QuerySelect, SemanticOperators, WithoutInverse } from '@january/compiler/transpilers';
type FeatureKind = 'column' | 'query' | 'group' | 'sort' | 'condition' | 'select' | 'limit';
export type Feature = SelectFeature | LimitFeature | SortFeature | GroupFeature | ConditionFeature;
export interface SelectFeature {
    kind: 'select';
    implementation: QueryColumn;
}
export interface LimitFeature {
    kind: 'limit';
    implementation: unknown;
}
export interface SortRule {
    id: string;
    input: string;
}
export interface SortFeature {
    kind: 'sort';
    implementation: SortRule;
}
export interface GroupFeature {
    kind: 'group';
    implementation: GroupQueryCondition<unknown>;
}
export interface ConditionFeature {
    kind: 'condition';
    implementation: GenericQueryCondition<unknown>;
}
export declare function where(column: string, operator: 'is', value: null | true | false | ''): ConditionFeature;
export declare function where(column: string, operator: 'after' | 'before', value: WithoutInverse<PeriodData>): ConditionFeature;
export declare function where(column: string, operator: Exclude<SemanticOperators, 'after' | 'before' | 'after_on' | 'before_on'>, value: string): ConditionFeature;
export declare function where(column: string, operator: SemanticOperators, value: string | number | WithoutInverse<PeriodData>): ConditionFeature;
export declare function sort(name: string, input: string | 'desc' | 'DESC' | 'asc' | 'ASC'): SortFeature;
export declare function isKind<T>(kind: FeatureKind): (feature: any) => feature is T;
export declare function isKind<T>(feature: any, kind: FeatureKind): feature is T;
export interface SqlQuery {
    whereBy?: QuerySelect;
    sortBy?: SortRule[];
    limit?: number;
}
export type HasQuery<A, T extends Feature[]> = T extends [infer F, ...infer R] ? F extends A ? true : HasQuery<A, R extends Feature[] ? R : never> : false;
export declare function query<T extends Feature[]>(...features: T): SqlQuery;
export declare namespace query {
    var sql: (sql: string) => void;
}
export declare function select(name: string): SelectFeature;
export declare function and(...features: ConditionFeature[]): GroupFeature;
export declare function or(...features: ConditionFeature[]): GroupFeature;
export declare namespace date {
    namespace after {
        function startOfThisWeek(): WithoutInverse<PeriodData>;
        function weekAgo(): WithoutInverse<PeriodData>;
        function weeksAgo(amount: number, relativeTo?: string): WithoutInverse<PeriodData>;
        function startOfThisMonth(): WithoutInverse<PeriodData>;
        function monthAgo(): WithoutInverse<PeriodData>;
        function monthsAgo(amount: number): WithoutInverse<PeriodData>;
        function startOfThisYear(): WithoutInverse<PeriodData>;
        function yearAgo(): WithoutInverse<PeriodData>;
        function yearsAgo(amount: number): WithoutInverse<PeriodData>;
    }
}
export declare function limit(upTo: number): LimitFeature;
export {};
