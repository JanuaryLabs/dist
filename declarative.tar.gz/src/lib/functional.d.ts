import type { InputDefinition } from './table';
export declare function input(value: string | number | boolean | null): InputDefinition;
export declare namespace input {
    function primitive(value: string | number | boolean | null): InputDefinition;
    function workflow(path: string): InputDefinition;
    function trigger(path: string): InputDefinition;
    function field(name: string): InputDefinition;
}
