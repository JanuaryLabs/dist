import type { Checker, diagnostic } from '@january/sdk/parser';
import type { FeatureDefinition } from './feature';
import type { TriggerDefinition, WorkflowDefinition } from './workflow';
export interface ProjectDefinition {
    name: string;
    features: FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown, unknown>>[]>[];
    extensions: Record<string, ExtensionDefinition>;
    imports: Checker.ProjectImport[];
}
export type EmptyProject<T extends TriggerDefinition<unknown, unknown> = TriggerDefinition<unknown, unknown>> = ProjectDefinition;
export type ExtensionDefinition = Record<string, unknown>;
export declare function current_Project(name: string, config: {
    extensions: Record<string, ExtensionDefinition>;
    modules: FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown, unknown>>[]>[];
    imports?: Checker.ProjectImport[];
}): ProjectDefinition;
export declare function project<WorkflowsTuple>(...features: FeatureDefinition<WorkflowsTuple>[]): FeatureDefinition<WorkflowsTuple>[];
export declare namespace project {
    var rule: ({ node }: {
        parent: unknown;
        node: unknown;
    }, service: import("@january/evaluator").RuleService) => diagnostic.Diagnostic[];
}
