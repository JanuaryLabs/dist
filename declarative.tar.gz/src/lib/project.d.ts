import type { Checker } from '@january/sdk/parser';
import type { FeatureDefinition } from './feature';
import type { TriggerDefinition, WorkflowDefinition } from './workflow';
export interface ProjectDefinition {
    features: FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown, unknown>>[]>[];
    imports: Checker.ProjectImport[];
}
export type EmptyProject<T extends TriggerDefinition<unknown, unknown> = TriggerDefinition<unknown, unknown>> = ProjectDefinition;
