import type { ImportDeclarationStructure } from 'ts-morph';
export declare function getErrors(fn: () => void): unknown[];
export declare function coerceString(value?: string | boolean | number | null | string[]): string | number | boolean | null | undefined;
export declare function refineExecute(transferable: (...args: any[]) => void, options: {
    replaceKey: (key: string) => string;
    setOutput?: (arg?: any) => string;
}): {
    structures: ImportDeclarationStructure[];
    code: string;
    inputs: Record<string, {
        value: string;
        input: string;
        static?: boolean;
        data?: Record<string, any>;
    }>;
};
