import type { PartialSchema } from 'ajv/dist/types/json-schema';
export declare function createSchema<T>(properties: Record<keyof T, PartialSchema<any> & {
    required?: boolean;
}>): PartialSchema<T>;
/**
 * Validate input against schema
 *
 * @param schema ajv augmented json-schema
 * @param input input to validate
 * @returns
 */
export declare function validateInput<T>(schema: PartialSchema<T>, input: Record<keyof T, unknown>): asserts input is T;
