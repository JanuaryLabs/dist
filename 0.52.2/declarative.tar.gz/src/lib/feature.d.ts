import type { Checker } from '@january/parser';
import type { TableDefinition } from './table';
import type { TriggerDefinition, WorkflowDefinition } from './workflow';
export type UnknownFeature = FeatureDefinition<WorkflowDefinition<TriggerDefinition<unknown>>[]>;
export interface PolicyDefinition {
    name: string;
    rule: string;
}
export interface FeatureDefinition<W> {
    name: string;
    workflows: W;
    tables: Record<string, TableDefinition>;
    policies?: Record<string, string>;
    imports: Checker.Import[];
}
interface FeatureConfig {
    tables?: Record<string, TableDefinition>;
    policies?: Record<string, Policy>;
    workflows?: WorkflowDefinition<TriggerDefinition<unknown>>[];
}
export type Policy = (name: string) => string;
export declare function feature(config?: FeatureConfig): {
    name: string;
    tables: Record<string, TableDefinition<Record<string, import("./table").FieldDefinition>>>;
    workflows: WorkflowDefinition<TriggerDefinition<unknown>>[];
    imports: never[];
    policies: Record<string, string>;
};
export {};
