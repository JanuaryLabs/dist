var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/bundler/src/virtual.ts
import esbuild from "esbuild";
import { dirname, relative, resolve } from "path";
var nodeExternalsPlugin = /* @__PURE__ */ __name((packageJsonV) => {
  const packageJson = JSON.parse(packageJsonV);
  const keys = [
    "dependencies",
    "devDependencies",
    "peerDependencies",
    "optionalDependencies"
  ];
  const nodeModules = keys.map((key) => Object.keys(packageJson[key] || {})).flat();
  return {
    name: "node-externals",
    setup(build) {
      build.onResolve(
        {
          namespace: "virtual",
          filter: /.*/
        },
        (args) => {
          let moduleName = args.path.split("/")[0];
          if (args.path.startsWith("@")) {
            const split = args.path.split("/");
            moduleName = `${split[0]}/${split[1]}`;
          }
          if (nodeModules.includes(moduleName)) {
            return { path: args.path, external: true };
          }
          return null;
        }
      );
    }
  };
}, "nodeExternalsPlugin");
function virtualBundle(options) {
  const getFile = /* @__PURE__ */ __name((name) => {
    const file = options.files.find((file2) => file2.path.endsWith(name));
    if (!file) {
      return null;
    }
    return file;
  }, "getFile");
  const packageJsonFile = getFile("package.json");
  const configJson = getFile("tsconfig.json");
  const filesMap = Object.fromEntries(
    options.files.map((file) => [file.path, file.content])
  );
  return esbuild.build({
    entryPoints: [options.src],
    write: false,
    platform: "node",
    treeShaking: true,
    minify: true,
    format: "esm",
    outfile: options.dist,
    keepNames: true,
    bundle: true,
    assetNames: "[name]",
    loader: {
      ".json": "file"
    },
    tsconfigRaw: configJson ? JSON.parse(configJson.content) : void 0,
    plugins: [
      packageJsonFile ? nodeExternalsPlugin(packageJsonFile.content) : {
        name: "node-externals",
        setup(build) {
        }
      },
      {
        name: "virtual-files",
        setup(build) {
          build.onResolve({ filter: /.*/ }, (args) => {
            const path = relative(
              process.cwd(),
              resolve(dirname(args.importer), args.path)
            );
            const attempts = [path, `${path}.ts`, `${path}/index.ts`];
            for (const attempt of attempts) {
              if (attempt in filesMap) {
                return {
                  path: attempt,
                  namespace: "virtual"
                };
              }
            }
            return null;
          });
          build.onLoad(
            {
              filter: /.*/,
              namespace: "virtual"
            },
            (args) => {
              return {
                contents: filesMap[args.path],
                loader: "default"
              };
            }
          );
        }
      }
    ]
  });
}
__name(virtualBundle, "virtualBundle");

// libs/bundler/src/bundler.ts
import esbuild2 from "esbuild";
import { nodeExternalsPlugin as nodeExternalsPlugin2 } from "esbuild-node-externals";
import { readFile } from "fs/promises";
import { join } from "path";
async function bundle(options) {
  const tsconfig = JSON.parse(
    await readFile(join(options.projectRoot, "tsconfig.json"), "utf-8")
  );
  const paths = tsconfig.compilerOptions.paths;
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    },
    plugins: [
      nodeExternalsPlugin2({
        packagePath: [join(options.projectRoot, "package.json")],
        allowList: Object.keys(paths)
      })
    ],
    assetNames: "[name]",
    loader: {
      ".swagger.json": "file"
    }
  });
}
__name(bundle, "bundle");
async function fileBundler(options) {
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: false,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: false,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    }
  }).then((x) => x.outputFiles?.[0]?.text);
}
__name(fileBundler, "fileBundler");
export {
  bundle,
  fileBundler,
  virtualBundle
};
