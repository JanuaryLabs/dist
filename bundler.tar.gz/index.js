// libs/bundler/src/virtual.ts
import esbuild from "esbuild";
import { dirname, relative, resolve } from "node:path";
var nodeExternalsPlugin = (packageJsonV) => {
  const packageJson = JSON.parse(packageJsonV);
  const keys = [
    "dependencies",
    "devDependencies",
    "peerDependencies",
    "optionalDependencies"
  ];
  const nodeModules = keys.map((key) => Object.keys(packageJson[key] || {})).flat();
  return {
    name: "node-externals",
    setup(build) {
      build.onResolve(
        {
          namespace: "virtual",
          filter: /.*/
        },
        (args) => {
          let moduleName = args.path.split("/")[0];
          if (args.path.startsWith("@")) {
            const split = args.path.split("/");
            moduleName = `${split[0]}/${split[1]}`;
          }
          if (nodeModules.includes(moduleName)) {
            return { path: args.path, external: true };
          }
          return null;
        }
      );
    }
  };
};
function virtualBundle(options) {
  const getFile = (name) => {
    const file = options.files.find((file2) => file2.path.endsWith(name));
    if (!file) {
      return null;
    }
    return file;
  };
  const packageJsonFile = getFile("package.json");
  const configJson = getFile("tsconfig.json");
  const filesMap = Object.fromEntries(
    options.files.map((file) => [file.path, file.content])
  );
  return esbuild.build({
    entryPoints: [options.src],
    write: false,
    platform: "node",
    treeShaking: true,
    minify: true,
    format: "esm",
    outfile: options.dist,
    keepNames: true,
    bundle: true,
    assetNames: "[name]",
    loader: {
      ".json": "file"
    },
    tsconfigRaw: configJson ? JSON.parse(configJson.content) : void 0,
    plugins: [
      packageJsonFile ? nodeExternalsPlugin(packageJsonFile.content) : {
        name: "node-externals",
        setup(build) {
        }
      },
      {
        name: "virtual-files",
        setup(build) {
          build.onResolve({ filter: /.*/ }, (args) => {
            const path = relative(
              process.cwd(),
              resolve(dirname(args.importer), args.path)
            );
            const attempts = [path, `${path}.ts`, `${path}/index.ts`];
            for (const attempt of attempts) {
              if (attempt in filesMap) {
                return {
                  path: attempt,
                  namespace: "virtual"
                };
              }
            }
            return null;
          });
          build.onLoad(
            {
              filter: /.*/,
              namespace: "virtual"
            },
            (args) => {
              return {
                contents: filesMap[args.path],
                loader: "default"
              };
            }
          );
        }
      }
    ]
  });
}

// libs/bundler/src/bundler.ts
import esbuild2 from "esbuild";
import { join, relative as relative2 } from "node:path";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/file-system.ts
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
async function exist(file) {
  return stat(file).then(() => true).catch(() => false);
}

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/bundler/src/bundler.ts
async function bundle(options) {
  const packages = [];
  const jumps = ["/", ...relative2(options.cwd, options.projectRoot).split("/")];
  while (jumps.length) {
    const path = join(options.cwd, jumps.join("/"), "package.json");
    if (await exist(path)) {
      packages.push(path);
    }
    jumps.pop();
  }
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);"
    },
    packages: "external",
    assetNames: "[name]",
    loader: {
      "swagger.json": "file"
    }
  });
}
async function fileBundler(options) {
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: false,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: false,
    banner: {
      js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);"
    }
  }).then((x) => x.outputFiles?.[0]?.text);
}
export {
  bundle,
  fileBundler,
  virtualBundle
};
