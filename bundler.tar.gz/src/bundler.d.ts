import esbuild from 'esbuild';
export declare function bundle(options: {
    projectRoot: string;
    entry: string;
    out: string;
}): Promise<esbuild.BuildResult<{
    entryPoints: string[];
    platform: "node";
    treeShaking: true;
    minify: false;
    keepNames: true;
    minifyIdentifiers: false;
    minifySyntax: false;
    minifyWhitespace: false;
    format: "esm";
    outfile: string;
    bundle: true;
    banner: {
        js: string;
    };
    plugins: esbuild.Plugin[];
    assetNames: string;
    loader: {
        '.swagger.json': "file";
    };
}>>;
export declare function fileBundler(options: {
    entry: string;
    out: string;
}): Promise<string | undefined>;
