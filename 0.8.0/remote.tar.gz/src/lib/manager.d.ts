import type { Readable } from 'stream';
export declare function createRemoteServer(projectId: string, tar: Readable, env?: Record<string, string>, restartContainer?: boolean): Promise<string>;
export declare function liveness(projectUrl: string): Promise<void>;
