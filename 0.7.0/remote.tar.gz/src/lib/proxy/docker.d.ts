import type { CodeRunnerConfig } from '@faslh/isomorphic';
export declare function getContainerPort(containerId: string | {
    name: string;
}): Promise<string>;
export declare function createRemoteContainer(name: string, imageTag: string, ports?: {
    internalPort: number;
    hostPort?: number;
}, env?: Record<string, string>): Promise<import("dockerode").Container>;
export declare function imagesExists(...tags: string[]): Promise<boolean>;
export declare function containerExists(containerId: string | {
    name: string;
}): Promise<boolean>;
export declare const needsNewRunnerImage: (config: CodeRunnerConfig) => Promise<boolean>;
export declare const canProcced: (config: CodeRunnerConfig) => Promise<boolean>;
export declare function createClientServer(options: {
    getConfig: () => CodeRunnerConfig;
    setConfig: (config: Omit<CodeRunnerConfig, 'projectId'>) => Promise<void>;
    getDist: () => Promise<string>;
}): Promise<string | undefined>;
