import type { Readable } from 'stream';
import tarStream from 'tar-stream';
import type { BundableFile } from '@january/generator/bundler';
export declare function buildRunnerImage(distDir: string, baseTag: string, runTag: string): Promise<unknown>;
export declare function createTar(baseTag: string, files: BundableFile[]): tarStream.Pack;
export declare function buildRunnerImageStream(tar: Readable, runTag: string): Promise<NodeJS.ReadableStream>;
export declare function getRunnerDockerfile(imageName: string): string;
