import type { Extension } from '../../extension';
export declare const auth: Extension;
