import type { Extension } from '../extension';
export interface Database extends Extension {
    options: Record<string, any>;
}
