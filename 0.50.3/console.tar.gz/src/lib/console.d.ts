export declare const colors: {
    green: (message: string) => string;
    blue: (message: string) => string;
    magenta: (message: string) => string;
};
export declare function box(title: string, ...lines: string[]): string;
export declare namespace box {
    var print: (title: string, ...lines: string[]) => void;
}
declare function network(port?: string | number | undefined): void;
export declare const pretty: {
    network: typeof network;
    box: typeof box;
    swagger: (pattern: string, cwd?: string) => Promise<void>;
};
export {};
