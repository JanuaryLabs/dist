// libs/sdk/evaluator/src/lib/evaluate.ts
import { get } from "lodash-es";
import { randomBytes } from "node:crypto";

// libs/sdk/declarative/src/lib/feature.ts
function feature(config = {}) {
  return {
    name: "",
    tables: config.tables ?? {},
    workflows: config.workflows ?? [],
    imports: [],
    policies: Object.entries(config.policies ?? {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config.message
    }
  };
}
var required = mandatory;
function unique(config = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config.message
      }
    }
  ];
}
function defineValidation(config) {
  return {
    name: config.name,
    config
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config) {
  const additionalFields = {};
  const idField = Object.values(config.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config.fields,
      ...additionalFields
    },
    constraints: config.constraints || []
  };
}
function field(config) {
  const { type, validations = [], metadata = {}, ...rest } = config;
  return {
    type: config.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config = {}) {
    const { validations, ...metadata } = config;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config = {}) {
    const { validations = [], ...metadata } = config;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config) {
    const [, relatedTableName, ...rest] = config.references.split(".");
    if (rest.length) {
      throw new Error(
        `Wrong relation reference: ${config.references}. Did you mean tables.${relatedTableName}`
      );
    }
    return field2({
      type: "relation",
      metadata: { ...config, references: relatedTableName },
      validations: config.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
field.enum = (config) => {
  return field({
    type: "single-select",
    validations: config.validations,
    metadata: {
      style: "enum",
      values: config.values,
      defaultValue: config.defaultValue
    }
  });
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(name, config) {
  const execute = config.trigger.refineExecute(config.execute);
  return {
    name,
    trigger: config.trigger,
    raw: !Object.keys(config.trigger.inputs ?? {}).length,
    execute,
    tag: config.tag
  };
}

// libs/parser/src/index.ts
import { readFileSync } from "node:fs";
var checker;
((checker2) => {
  function isCallExpression(node, name) {
    if (!node) {
      return false;
    }
    const isCallExpr = node.type === "CallExpression";
    if (!isCallExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    if (node.callee.type === "MemberExpression") {
      return node.callee.property.type === "Identifier" && node.callee.property.value === name;
    }
    return node.callee.type === "Identifier" && node.callee.value === name;
  }
  checker2.isCallExpression = isCallExpression;
  function isObjectExpression(node) {
    return node.type === "ObjectExpression";
  }
  checker2.isObjectExpression = isObjectExpression;
  function isKeyValueProperty(node, valueType, keyName) {
    if (node.type !== "KeyValueProperty") {
      return false;
    }
    if (!valueType) {
      return true;
    }
    const sameType = node.value.type === valueType;
    if (!sameType) {
      return false;
    }
    if (!keyName) {
      return true;
    }
    return isIdentifier(node.key, keyName);
  }
  checker2.isKeyValueProperty = isKeyValueProperty;
  function isNullLiteral(node) {
    return node.type === "NullLiteral";
  }
  checker2.isNullLiteral = isNullLiteral;
  function isPrimitive(node) {
    if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
      return true;
    }
    return false;
  }
  checker2.isPrimitive = isPrimitive;
  function isIdentifier(node, name) {
    if (!node) {
      return false;
    }
    const isIdentifier2 = node.type === "Identifier";
    if (!isIdentifier2) {
      return false;
    }
    if (!name) {
      return true;
    }
    return node.value === name;
  }
  checker2.isIdentifier = isIdentifier;
  function isMemberExpression(node, name) {
    if (!node) {
      return false;
    }
    const isMemberExpr = node.type === "MemberExpression";
    if (!isMemberExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    return isIdentifier(node.property, name);
  }
  checker2.isMemberExpression = isMemberExpression;
  function isArrayExpression(node) {
    return node.type === "ArrayExpression";
  }
  checker2.isArrayExpression = isArrayExpression;
})(checker || (checker = {}));
var Checker;
((Checker2) => {
  function isPrimitive(value) {
    return value !== Object(value);
  }
  Checker2.isPrimitive = isPrimitive;
  function isCallExpression(value) {
    return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
  }
  Checker2.isCallExpression = isCallExpression;
  function isObjectExpression(value) {
    return !isCallExpression(value) && value !== null && typeof value === "object";
  }
  Checker2.isObjectExpression = isObjectExpression;
  function isArrayExpression(value) {
    return Array.isArray(value);
  }
  Checker2.isArrayExpression = isArrayExpression;
})(Checker || (Checker = {}));
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  globalThis.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveDefaultExpr(defaultExpr, code)
  };
}
function resolveDefaultExpr(defaultExpr, code) {
  if (checker.isCallExpression(defaultExpr.expression)) {
    return resolveCallExpression(defaultExpr.expression, code);
  }
  if (checker.isObjectExpression(defaultExpr.expression)) {
    return resolveObjectExpression(defaultExpr.expression, code);
  }
  return null;
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      list.push(resolveMemberExpression(arg.expression, []).join("."));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}

// libs/sdk/evaluator/src/lib/evaluate.ts
var defaultPrimitiveCallers = {
  table,
  feature,
  workflow,
  field: field.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  index
  // z: {
  //   object(...args: any[]) {
  //     logMe({ 'z.objectile': args });
  //     return args;
  //   },
  //   uuid() {
  //     return 'uuid';
  //   },
  //   int(...args: any[]) {
  //     logMe({ 'z.int': args });
  //     return 'int';
  //   },
  //   number(...args: any[]) {
  //     logMe({ 'z.number': args });
  //     return 'number';
  //   },
  //   string() {
  //     return 'string';
  //   },
  //   array(...args: any[]) {
  //     logMe({ 'z.array': args });
  //     return {
  //       type: 'array',
  //     };
  //   },
  // } as any,
  // z(...args: any[]) {
  //   logMe({ z: args });
  //   return args;
  // },
  // object(...args: any[]) {
  //   logMe({ 'z.object': args });
  //   return 'object';
  // },
  // uuid() {
  //   return 'uuid';
  // },
  // int() {
  //   return 'int';
  // },
  // number() {
  //   return 'string';
  // },
  // string() {
  //   return 'string';
  // },
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers, node, hooks = {}) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    let callerImpl = callers[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node.arguments.map((it) => staticEval(callers, it, hooks));
    if (typeof callerImpl === "function") {
      if (type.length) {
        args.unshift(type.join("."));
      }
      return callerImpl(...args);
    }
    callerImpl = get(callerImpl, type);
    if (!callerImpl) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => staticEval(callers, it, hooks));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      obj[key] = staticEval(callers, value, hooks);
    }
    return obj;
  }
  return node;
}
async function defensiveEvaluate(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  const features = staticEval(
    defaultPrimitiveCallers,
    ast.project
  );
  const service = {
    getFeature(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "feature") {
          return features.find(
            (feature2) => feature2.name === parent.node.arguments[0]
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    getWorkflow(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "workflow") {
          const feature2 = this.getFeature(parent);
          const [workflowName] = parent.node.arguments;
          return feature2?.workflows.find(
            (workflow2) => workflow2.name === workflowName
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    duplicateWorkflowTriggerConfig: (relatedWorkflow, check) => {
      for (const feature2 of features) {
        for (const workflow2 of feature2.workflows) {
          if (workflow2 === relatedWorkflow) {
            continue;
          }
          if (check(workflow2, feature2)) {
            return true;
          }
        }
      }
      return false;
    },
    hasField: (name) => features.some(
      (feature2) => Object.keys(feature2.tables ?? {}).some(
        (table2) => Object.keys(feature2.tables[table2].fields).includes(name)
      )
    ),
    hasTable: (name) => features.some((feature2) => {
      return (feature2.tables ?? {})[name];
    }),
    inUniqueFeature: (name) => {
      let count = 0;
      for (const feature2 of features) {
        if (feature2.name === name) {
          count++;
        }
      }
      return count === 1;
    },
    isUniqueWorkflow: (name) => {
      for (const feature2 of features) {
        let count = 0;
        for (const workflow2 of feature2.workflows) {
          if (workflow2.name === name) {
            count++;
          }
        }
        if (count > 1) {
          return false;
        }
      }
      return true;
    },
    validateName(name, context) {
      const errors = [];
      if (typeof name !== "string") {
        errors.push(`${context} must be a string`);
      } else if (name.trim().length === 0) {
        errors.push(`${context} must not be empty`);
      }
      return errors;
    }
  };
  return {
    reports: [],
    definition: {
      features,
      imports: ast.imports
    }
  };
}
async function evaluate(code, callers) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    block: staticEval(callers, ast.project),
    imports: ast.imports
  };
}
async function compare(a, b) {
  const removeSpans = (node) => {
    if (!node) return "";
    return JSON.stringify(node, (key, value) => {
      if (key === "span") {
        return void 0;
      }
      return value;
    });
  };
  return removeSpans((await legacy_parse(a))?.project ?? null) === removeSpans((await legacy_parse(a))?.project ?? null);
}
export {
  EVAL_ERRORS,
  compare,
  defaultPrimitiveCallers,
  defensiveEvaluate,
  evaluate,
  staticEval
};
