export declare function createRemoteServer(projectId: string, processImage: () => Promise<void>, env?: Record<string, string>, restartContainer?: boolean, port?: number): Promise<string>;
export declare function liveness(projectUrl: string): Promise<void>;
