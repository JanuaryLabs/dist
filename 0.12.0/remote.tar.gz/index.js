import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// libs/remote/src/index.ts
import { parse } from "dotenv";

// libs/remote/src/lib/instance.ts
import {
  Observable,
  Subject,
  defer,
  from,
  map,
  merge,
  mergeMap,
  switchMap,
  tap
} from "rxjs";
import { PassThrough as PassThrough2 } from "stream";

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
var colors = {
  green: (message) => `\x1B[32m${message}\x1B[0m`,
  blue: (message) => `\x1B[34m${message}\x1B[0m`,
  magenta: (message) => `\x1B[35m${message}\x1B[0m`
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: (label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    },
    recordEnd: (label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    },
    end: () => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }
  };
}
function retryPromise(promise) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
function followProgress(stream, logger = console) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger.log(obj);
        }
      }
    );
  });
}
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
async function removeContainer(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    await container.stop({ t: 0 }).catch(console.error);
  }
  await container.remove({ f: true }).catch(console.error);
}
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
function makeRunningContainerName(projectId) {
  return `${projectId}-container`;
}
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/lib/instance.ts
var ContainerNotFoundError = class _ContainerNotFoundError extends Error {
  constructor(containerId) {
    super(`Container ${containerId} not found`);
    this.containerId = containerId;
    Error.captureStackTrace(this, _ContainerNotFoundError);
  }
};
if (!process.env["DOCKER_HOST"]) {
  console.warn("DOCKER_HOST environment variable is not set.");
} else {
  console.log("ensure ssh-add private-key");
}
var INTERNAL_PORT = 3e3;
function listenToDockerEvents(options) {
  const abortController = new AbortController();
  return new Observable((subscriber) => {
    const events = docker.getEvents({
      abortSignal: abortController.signal,
      ...options
    });
    from(events).pipe(
      switchMap((x) => x),
      map((buffer) => {
        return buffer.toString("utf-8").split("\n").map((it) => it.trim()).filter(Boolean).map((event) => {
          try {
            return JSON.parse(event);
          } catch (error) {
            console.error(
              "Failed to parse event:",
              event,
              "$$$chunk$$",
              buffer.toString("utf-8")
            );
            if (process.env["NODE_ENV"] === "development") {
              throw error;
            }
            return {};
          }
        });
      })
    ).subscribe(subscriber);
    return () => {
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
function timestampParser(text) {
  if (!text.includes("Z")) {
    return { timestamp: "", rest: text };
  }
  let timestamp = "";
  do {
    timestamp += text.slice(0, 1);
    text = text.slice(1);
  } while (text.slice(0, 1) !== "Z");
  timestamp += text.slice(0, 1);
  text = text.slice(1);
  return {
    timestamp,
    rest: text
  };
}
function containerLogs(containerName) {
  return new Observable((subscriber) => {
    const abortController = new AbortController();
    const container$ = defer(async () => {
      const container = await getContainer({ name: containerName });
      if (!container) {
        throw new ContainerNotFoundError(containerName);
      }
      return container;
    });
    const stream$ = container$.pipe(
      tap((container) => {
        console.log(
          "Listening to logs for container:",
          containerName,
          ` (${container.id})`
        );
      }),
      switchMap(
        (container) => from(
          container.logs({
            // TODO: emit only from the start of the day
            follow: true,
            stdout: true,
            stderr: true,
            timestamps: true,
            details: true,
            abortSignal: abortController.signal
          })
        ).pipe(
          mergeMap((stream) => {
            const subject = new Subject();
            const write$ = new PassThrough2({
              write(chunk, encoding, callback) {
                const output = chunk.toString();
                const lines = output.split("\n").map(timestampParser);
                lines.forEach(
                  (entry) => subject.next({ timestamp: entry.timestamp, log: entry.rest })
                );
                callback();
              }
            });
            container.modem.demuxStream(stream, write$, write$);
            return subject;
          })
        )
      )
    );
    stream$.subscribe(subscriber);
    return () => {
      console.log("ABORTING");
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}
function containerLogsRaw(containerName) {
  return new Observable((subscriber) => {
    const abortController = new AbortController();
    const container$ = defer(async () => {
      const container = await getContainer({ name: containerName });
      if (!container) {
        throw new ContainerNotFoundError(containerName);
      }
      return container;
    });
    const stream$ = container$.pipe(
      tap((container) => {
        console.log(
          "Listening to logs for container:",
          containerName,
          ` (${container.id})`
        );
      }),
      switchMap(
        (container) => from(
          container.logs({
            // TODO: emit only from the start of the day
            follow: true,
            stdout: true,
            stderr: true,
            timestamps: false,
            details: true,
            abortSignal: abortController.signal
          })
        ).pipe(
          mergeMap((stream) => {
            const stdout = new PassThrough2();
            const stderr = new PassThrough2();
            const pass = merge(stdout, stderr);
            container.modem.demuxStream(stream, stdout, stderr);
            return pass;
          })
        )
      )
    );
    stream$.subscribe(subscriber);
    return () => {
      console.log("ABORTING");
      abortController.abort();
      subscriber.unsubscribe();
    };
  });
}

// libs/remote/src/lib/proxy/docker.ts
async function createRemoteContainer(containerName, imageTag, ports = { internalPort: INTERNAL_PORT }, env = {}) {
  const mapPort = ports.hostPort ? [{ HostPort: ports.hostPort }] : [];
  const url = await getProjectServerURL(containerName);
  const container = await docker.createContainer({
    name: containerName,
    Image: imageTag,
    Env: [
      // FIXME: keeping this for now till we generate debug database for each project
      // 'CONNECTION_STRING=postgresql://january-test_owner:U17cOgTaYXIm@ep-holy-flower-a5lkn70o.us-east-2.aws.neon.tech/january-test?sslmode=require',
      // 'NODE_ENV=development',
      // `PORT=${ports.internalPort}`,
      ...Object.entries(env).map(([key, value]) => `${key}=${value}`)
    ],
    Labels: {
      "traefik.enable": "true",
      [`traefik.http.routers.${containerName}.rule`]: "Host(`" + containerName + ".january.sh`)",
      [`traefik.http.routers.${containerName}.tls`]: "true",
      [`traefik.http.routers.${containerName}.tls.certresolver`]: "myresolver",
      [`traefik.http.services.${containerName}.loadbalancer.server.port`]: String(ports.internalPort)
    },
    ExposedPorts: {
      [`${ports.internalPort}/tcp`]: {}
      // '9229/tcp': {},
    },
    // NetworkingConfig: {
    //   EndpointsConfig: {
    //     'traefik-network': {},
    //   },
    // },
    platform: process.env["NODE_ENV"] === "production" ? "linux/amd64" : void 0,
    HostConfig: {
      // named volume to that has node_modules
      // Binds: [`node_modules:/app/node_modules`],
      NetworkMode: "traefik-network",
      // Instruct Docker to dynamically bind an available host port to container's port
      PortBindings: {
        [`${ports.internalPort}/tcp`]: mapPort
      },
      // FIXME: we need to allow only 64MB of memory
      Memory: 96 * 1024 * 1024,
      RestartPolicy: {
        Name: "on-failure",
        MaximumRetryCount: 3
      },
      // allow only 0.10 of the CPU
      CpuPercent: 5
    },
    Healthcheck: {
      Test: [
        "CMD",
        "wget",
        "--no-verbose",
        "--tries=1",
        "--spider",
        "-q",
        `${url}/health`
      ],
      Interval: 60 * 1e9,
      // 60 seconds
      Timeout: 10 * 1e9,
      // 10 seconds
      Retries: 3,
      StartPeriod: 60 * 1e9
      // 60 seconds
    }
  });
  return container;
}
async function imagesExists(...tags) {
  const images = await docker.listImages({
    all: true
  });
  const imageTags = images.flatMap((image) => image.RepoTags);
  return tags.every((tag) => {
    return imageTags.includes(tag.includes(":") ? tag : `${tag}:latest`);
  });
}
async function containerExists(containerId) {
  if (typeof containerId === "string") {
    const container2 = docker.getContainer(containerId);
    return container2.inspect().then(
      () => true,
      () => false
    );
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  return !!container;
}
var needsNewRunnerImage = async (config) => {
  const runnerImageTag = `${config.projectId}-run`;
  console.log({
    [`${config.projectId}-run`]: await imagesExists(runnerImageTag)
  });
  return config.depsChanges || config.codeChanges || !await imagesExists(runnerImageTag);
};
async function getProjectServerURL(containerName) {
  return process.env["NODE_ENV"] !== "development" ? `http://${containerName}:${INTERNAL_PORT}` : await retryPromise(
    () => getContainerExternalPort(INTERNAL_PORT, { name: containerName })
  ).then((port) => `http://localhost:${port}`);
}

// libs/remote/src/lib/manager.ts
Error.stackTraceLimit = Infinity;
(async () => {
  await upsertNetwork("traefik-network");
})();
async function createRemoteServer(projectId, processImage, env = {}, restartContainer = true, port = INTERNAL_PORT) {
  const recorder = createRecorder({
    label: "createClientServer",
    verbose: true
  });
  const runnerImageTag = makeRunningImageName(projectId);
  const runnerContainerName = makeRunningContainerName(projectId);
  const forceRestart = await isContainerRunning(runnerContainerName).then((container) => !container).catch(() => true);
  console.log(`Restart container: ${restartContainer}`);
  if (forceRestart) {
    console.warn(
      `Container doesn't exists. ignore restart flag ${restartContainer}`
    );
    restartContainer ||= forceRestart;
  }
  if (restartContainer) {
    await processImage();
    {
      recorder.record("removeContainer");
      await removeContainer(runnerContainerName).catch(() => {
      });
      recorder.recordEnd("removeContainer");
    }
    {
      recorder.record("startContainer");
      try {
        const container = await createRemoteContainer(
          runnerContainerName,
          runnerImageTag,
          { internalPort: port },
          env
        );
        await container.start();
      } catch {
        {
          recorder.record("removingErroredContainer");
          await removeContainer(runnerContainerName).catch(() => {
          });
          recorder.recordEnd("removingErroredContainer");
        }
      }
      recorder.recordEnd("startContainer");
    }
  }
  recorder.end();
  return runnerContainerName;
}
async function liveness(projectUrl) {
  const recorder = createRecorder({
    label: "isContainerAlive",
    verbose: true
  });
  recorder.record("healthCheck");
  await retryPromise(async () => {
    const res = await fetch(projectUrl);
    if (!res.ok) {
      throw new Error("Failed to fetch");
    }
  });
  recorder.recordEnd("healthCheck");
  recorder.end();
}

// libs/remote/src/lib/proxy/docker.runner.ts
import { writeFileSync } from "fs";
import { join } from "path";
import tar from "tar";
import tarStream2 from "tar-stream";
async function buildRunnerImage(distDir, baseTag, runTag) {
  const dockerfile = getRunnerDockerfile(baseTag);
  writeFileSync(join(distDir, "Dockerfile"), dockerfile);
  const tarStream3 = tar.create(
    {
      gzip: false,
      cwd: distDir
    },
    ["."]
  );
  const buildStream = await docker.buildImage(tarStream3, {
    t: runTag
  });
  return followProgress(buildStream);
}
function createTar(files) {
  const pack = tarStream2.pack();
  for (const { path, content } of files) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
function getRunnerDockerfile(imageName) {
  return `
FROM ${imageName} as deps

WORKDIR /app

# FROM node:lts as base
# WORKDIR /app
COPY ./package.json /app/package.json
COPY . /app/build/
# COPY --from=deps /app/node_modules /app/node_modules

# it'll make install dynamic dependencies faster
# COPY --from=deps /app/package-lock.json /app/package-lock.json

# RUN npm ci --omit=dev --no-audit --no-fund --prefer-offline

# CMD tail -f /dev/null

CMD [ "npm", "start" ]
`;
}
export {
  ContainerNotFoundError,
  INTERNAL_PORT,
  buildRunnerImage,
  containerExists,
  containerLogs,
  containerLogsRaw,
  createRemoteContainer,
  createRemoteServer,
  createTar,
  getProjectServerURL,
  getRunnerDockerfile,
  imagesExists,
  listenToDockerEvents,
  liveness,
  needsNewRunnerImage
};
//# sourceMappingURL=index.js.map
