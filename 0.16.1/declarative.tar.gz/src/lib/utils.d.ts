export declare function createPathProxy(path?: string): any;
export declare function createEnvProxy(): NodeJS.ProcessEnv;
export declare function getErrors(fn: () => void): unknown[];
export declare function coerceString(value?: string | boolean | number | null | string[]): string | number | boolean | null | undefined;
export declare function refineExecute(transferable: (...args: any[]) => void, options: {
    replaceKey: (key: string) => string;
}): import("./workflow").ActionDefinition<unknown>;
