// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { get } from "lodash";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
async function extractError(fn) {
  try {
    return {
      value: await fn(),
      error: void 0
    };
  } catch (error) {
    return { error };
  }
}

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
import crypto from "crypto";
import { createReadStream, existsSync } from "fs";
import { mkdir, readFile, rm, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { basename, dirname, join } from "path";
function followProgress(stream, logger = console) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger.log(obj);
        }
      }
    );
  });
}
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
async function removeContainer(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    await container.stop({ t: 0 }).catch(console.error);
  }
  await container.remove({ force: true }).catch(console.error);
}
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
function computeChecksum(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("md5");
    const stream = typeof filePath === "string" ? createReadStream(filePath) : filePath;
    stream.on("data", (data) => hash.update(data));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", (err) => reject(err));
  });
}
async function fileChanged(filePath, discrminator) {
  const checksumDirPath = join(tmpdir(), discrminator);
  await mkdir(checksumDirPath, { recursive: true });
  const checksumFilePath = join(checksumDirPath, basename(filePath));
  const currentChecksum = await computeChecksum(filePath);
  const flush = async () => {
    await rm(checksumFilePath, { force: true });
  };
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
async function contentChanged(content, fileName, discrminator) {
  const checksumFilePath = join(tmpdir(), discrminator, fileName);
  await mkdir(dirname(checksumFilePath), { recursive: true });
  const filePath = join(tmpdir(), "check", discrminator, fileName);
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, "utf-8");
  const currentChecksum = await computeChecksum(filePath);
  const flush = async () => {
    await rm(checksumFilePath, { force: true });
  };
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
function makeProjectPath(projectId) {
  return join(tmpdir(), "client-server", projectId);
}
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
function makeRunningContainerName(projectId) {
  return `${projectId}-container`;
}
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}
async function startContainer(name, createContainer) {
  let container = null;
  if (typeof name === "string") {
    container = await getContainer({ name });
  } else {
    container = name;
  }
  if (!container) {
    if (!createContainer) {
      throw new Error(`Cannot initialize server for project: ${name}`);
    }
    container = await createContainer();
  }
  const running = await isContainerRunning(container);
  if (!running) {
    await container.start().catch((error) => {
      if (error.statusCode === 304) {
        return;
      }
      throw error;
    });
  }
  return container;
}
async function getContainerNet(containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings;
}
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}
async function pushImage(repo, tag = "latest") {
  const image = docker.getImage(repo);
  const stream = await image.push({
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    },
    tag
  });
  await followProgress(stream);
  return image;
}
async function pullImage(image, tag = "latest") {
  const stream = await docker.createImage({
    fromImage: image,
    tag,
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    }
  });
  await followProgress(stream);
  return image;
}

// libs/docker/src/compose.ts
function compose(services) {
  const dockerCompose = {
    volumes: {},
    networks: {},
    services: {}
  };
  const appEnvironment = {};
  for (const [serviceName, it] of Object.entries(services)) {
    const depends_on = it.dependsOn(services);
    Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
    delete it.composeService.appEnvironment;
    dockerCompose.services[serviceName] = {
      ...it.composeService,
      environment: Object.keys(it.composeService.environment).length ? it.composeService.environment : void 0,
      depends_on: depends_on.length ? depends_on : void 0
    };
    dockerCompose.volumes = {
      ...dockerCompose.volumes,
      ...it.volumes.filter((it2) => it2.isNamedVolume).reduce(
        (acc, it2) => ({
          ...acc,
          [it2.src]: {}
        }),
        {}
      )
    };
    dockerCompose.networks = {
      ...dockerCompose.networks,
      ...it.networks.reduce(
        (acc, it2) => ({
          ...acc,
          [it2]: {}
        }),
        {}
      )
    };
  }
  return {
    dockerCompose,
    environment: appEnvironment
  };
}
function service(serviceLike) {
  const ports = (serviceLike.ports ?? []).map((it) => {
    const [host, internal] = it.split(":");
    return {
      host,
      internal
    };
  });
  const volumes = (serviceLike.volumes ?? []).map((it) => {
    const [src, dest] = it.split(":");
    return {
      src,
      dest,
      isNamedVolume: !(src.startsWith("/") || src.startsWith("./"))
    };
  });
  return {
    composeService: serviceLike,
    ports,
    volumes,
    networks: serviceLike.networks ?? [],
    dependsOn: (services) => {
      const depends_on = [];
      for (const dependencie of serviceLike.depends_on ?? []) {
        for (const [serviceName, serviceLike2] of Object.entries(services)) {
          if (serviceLike2.composeService === dependencie) {
            depends_on.push(serviceName);
          }
        }
      }
      return depends_on;
    }
  };
}
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}

// libs/docker/src/index.ts
function createPack(content) {
  const pack = tarStream.pack();
  const entry = pack.entry({ name: "package.json" }, content, () => {
    pack.finalize();
  });
  entry.end();
  return new Promise((resolve, reject) => {
    entry.on("finish", () => {
      resolve(pack);
    });
    entry.on("error", reject);
  });
}
function createExtract(onEntry) {
  const extract = tarStream.extract();
  extract.on("entry", (header, stream, next) => {
    onEntry(header.name, stream);
    stream.on("end", next);
    stream.resume();
  });
  extract.on("finish", () => {
    console.log("File extraction complete");
  });
  return extract;
}
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}
async function execCommand(container, cmd) {
  const exec = await container.exec({
    AttachStdout: true,
    AttachStderr: true,
    Cmd: cmd,
    Tty: false,
    Privileged: false
  });
  const stream = await exec.start({});
  const outStream = new PassThrough();
  const errStream = new PassThrough();
  container.modem.demuxStream(stream, outStream, errStream);
  let out = "";
  let err = "";
  outStream.on("data", (chunk) => {
    out += chunk.toString();
  });
  errStream.on("data", (chunk) => {
    err += chunk.toString();
  });
  return new Promise((resolve, reject) => {
    stream.on("end", async () => {
      try {
        console.log(`Command ${cmd.join(" ")}`);
        const a = await exec.inspect();
        if (a.ExitCode !== 0) {
          const error = new Error(err);
          error.cause = a;
          reject(error);
        } else if (err) {
          const error = new Error(err);
          error.cause = a;
          return reject(error);
        } else {
          resolve(out);
        }
      } catch (e) {
        reject(e);
      }
    });
  });
}
async function getDependencyInstaller() {
  const container = await startContainer(
    "dependency-installer",
    () => docker.createContainer({
      name: "dependency-installer",
      Image: "node:lts",
      WorkingDir: "/app",
      Cmd: ["tail", "-f", "/dev/null"],
      HostConfig: {
        Binds: [`node_modules:/app/node_modules`],
        CapDrop: ["ALL"],
        Privileged: false
      }
    })
  );
  await followLogs(container);
  return container;
}
async function installPackage(sourceData) {
  const container = await getDependencyInstaller();
  await execCommand(container, [
    "sh",
    "-c",
    `echo '${JSON.stringify({
      version: "0.0.0",
      main: "./build/server.js",
      type: "module",
      dependencies: {
        "ua-parser-js": "^1.0.37",
        "request-ip": "^3.3.0",
        "rfc-7807-problem-details": "^1.1.0",
        ajv: "8.12.0",
        "ajv-formats": "2.1.1",
        "ajv-errors": "3.0.0",
        "ajv-keywords": "5.1.0",
        validator: "13.9.0",
        "lodash-es": "^4.17.21",
        "http-status-codes": "2.2.0",
        hono: "^4.4.0",
        "@hono/node-server": "^1.11.1",
        "@scalar/hono-api-reference": "^0.5.145",
        typeorm: "0.3.20",
        pg: "8.11.5",
        "sql-template-tag": "5.2.1",
        resend: "1.0.0",
        "@octokit/webhooks": "^13.2.7",
        "node-cron": "^3.0.3",
        [sourceData.package]: sourceData.version
      },
      devDependencies: {
        "@types/ua-parser-js": "^0.7.39",
        "@types/request-ip": "^0.0.41",
        "@types/lodash-es": "^4.17.12",
        "@types/node": "^20.11.26",
        typescript: "^4.9.4",
        "@types/validator": "13.7.17",
        "@types/node-cron": "^3.0.11",
        prettier: "3.3.2"
      }
    })}' > package.json`
  ]);
  await execCommand(container, [
    "sh",
    "-c",
    "npm install",
    "--no-audit",
    "--no-fund"
  ]);
  return container;
}
async function installPackageJson(content, projectId) {
  const containerName = `${projectId}-install-deps`;
  const volumeName = "node_modules";
  const depsImage = "node:lts";
  const pack = await createPack(content);
  const { value: container, error } = await extractError(
    () => docker.createContainer({
      Image: depsImage,
      WorkingDir: "/app",
      name: containerName,
      Cmd: ["sh", "-c", "npm install", "--no-audit", "--no-fund"],
      HostConfig: {
        // Binds: [`${volumeName}:/app/node_modules`],
        AutoRemove: true,
        // ReadonlyRootfs: true,
        CapDrop: ["ALL"]
      }
    })
  );
  if (error) {
    const { statusCode, message } = error;
    switch (statusCode) {
      case 409:
        await removeContainer(containerName).catch(() => {
        });
        await installPackageJson(content, projectId);
        break;
      case 404:
        console.log(`Image not found: ${depsImage}`);
        console.error(error);
        break;
      default:
        console.error(error);
        break;
    }
    return;
  }
  try {
    await container.putArchive(pack, {
      path: "/app"
    });
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      logs: true
    });
    stream.pipe(process.stdout);
    await container.start();
    await container.wait({
      condition: "removed"
    });
    console.log("Dependencies installed");
  } finally {
    await removeContainer(containerName).catch(() => {
    });
  }
}
export {
  compose,
  computeChecksum,
  contentChanged,
  createExtract,
  createPack,
  docker,
  execCommand,
  fileChanged,
  followLogs,
  followProgress,
  getContainer,
  getContainerExternalPort,
  getContainerNet,
  getDependencyInstaller,
  installPackage,
  installPackageJson,
  isContainerRunning,
  makeProjectPath,
  makeRunningContainerName,
  makeRunningImageName,
  pullImage,
  pushImage,
  removeContainer,
  service,
  startContainer,
  toKevValEnv,
  upsertNetwork,
  upsertVolume
};
