var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 0.85,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
__name(box, "box");
box.print = function(title, ...lines) {
  console.log(box(title, ...lines.map((it) => it.trimEnd())));
};
function network(port = process.env["PORT"]) {
  console.log(
    box(
      "Server",
      `\u2139 Localhost: http://localhost:${port}`,
      `\u2714 Network IP: http://${ip.address()}:${port}`,
      `\u26A0 Note: Ensure the requesting device connected on the same network`
    )
  );
}
__name(network, "network");
var pretty = {
  network,
  box,
  swagger: /* @__PURE__ */ __name(async (pattern, cwd = import.meta.dirname) => {
    const swaggerFiles = await glob(pattern, {
      cwd
    });
    const swaggerEndpoints = swaggerFiles.map((x) => x.split(".swagger.json").shift()).map((it) => `/${it}/swagger`);
    console.log(box("Swagger Docs", ...swaggerEndpoints));
  }, "swagger")
};
export {
  box,
  colors,
  pretty
};
