export declare function generateTypes(code: string, dir: string): Promise<string>;
