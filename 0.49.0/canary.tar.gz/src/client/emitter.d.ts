export declare function toInterface(contents: Record<string, Record<string, Record<string | symbol, any>>>, serializeSymbol: symbol): Record<string, string>;
