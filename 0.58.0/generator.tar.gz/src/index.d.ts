import { type ImportDeclarationStructure } from 'ts-morph';
export * from './emitter';
export * from './lib/project-fs';
export declare function getArrowFnBody(arrowFn: string | ((...args: any[]) => any)): string | undefined;
export interface Input {
    value: string;
    input?: string;
    type?: string;
    static?: boolean;
    data?: Record<string, any>;
    structure?: any[];
}
export declare function refineExecute(transferable: (...args: any[]) => void, options: {
    replaceKey: (key: string) => string;
    setOutput?: (arg?: any) => string;
    inputs?: Record<string, Input | ((parameters: any[], subjectUsed: boolean) => Input | null)>;
}): {
    structures: ImportDeclarationStructure[];
    code: string;
    inputs: {
        [k: string]: Input;
    };
};
