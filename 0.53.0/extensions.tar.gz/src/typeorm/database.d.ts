import type { OnFeatureR } from '@january/generator';
import type { Extension } from '../extension';
import type { TableVM } from './database-def';
import type { TypeORMCodeWriter } from './typeorm.writer';
export interface Database extends Extension {
    id: string;
    options: Record<string, any>;
    type: string;
    writeTables(tables: TableVM[], config: {
        writer: TypeORMCodeWriter;
    }): Promise<OnFeatureR>;
}
