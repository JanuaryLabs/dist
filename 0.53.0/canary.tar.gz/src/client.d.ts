import { type FeatureSpec, type SdkConfig } from './client/sdk';
declare const _default: ({ client, features, fs, }: {
    fs: {
        features: string;
        extensions: string;
        tsconfig: string;
    };
    client: SdkConfig;
    features: FeatureSpec[];
}) => Promise<void>;
export default _default;
