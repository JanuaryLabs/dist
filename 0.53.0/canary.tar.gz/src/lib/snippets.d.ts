declare const _default: {
    'HTTP Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Schedule Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'WebSocket Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'SSE Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'GitHub Webhook Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Create Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'List Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Get Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Update Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Delete Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Replace Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
    'Exists Workflow': {
        prefix: string;
        body: string[];
        description: string;
    };
};
export default _default;
