#!/usr/bin/env node
import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);

// libs/canary/src/cli.ts
import { input } from "@inquirer/prompts";
import { Octokit } from "@octokit/core";
import { execSync } from "child_process";
import { differenceInMinutes } from "date-fns";
import latestVersion from "latest-version";
import { readFile as readFile2, rm, writeFile as writeFile2 } from "node:fs/promises";
import { join as join2 } from "node:path";
import { tmpdir } from "os";
import semver from "semver";
import simpleGit from "simple-git";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 0.85,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
box.print = function(title, ...lines) {
  console.log(box(title, ...lines.map((it) => it.trimEnd())));
};

// libs/modern/src/index.ts
import {
  cp,
  mkdir,
  readFile,
  readdir,
  stat,
  writeFile
} from "node:fs/promises";
import { basename, dirname, isAbsolute, join } from "node:path";
import { tap } from "rxjs/operators";

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
async function writeFiles(dir, contents, format = true) {
  return Promise.all(
    Object.entries(contents).map(async ([file, content]) => {
      const filePath = isAbsolute(file) ? file : join(dir, file);
      await mkdir(dirname(filePath), { recursive: true });
      if (typeof content === "string") {
        await writeFile(
          filePath,
          format ? await formatCode(content, getExt(file)) : content,
          "utf-8"
        );
      } else {
        if (content.ignoreIfExists) {
          if (!await exist(filePath)) {
            await writeFile(
              filePath,
              format ? await formatCode(content.content, getExt(file)) : content.content,
              "utf-8"
            );
          }
        }
      }
    })
  );
}
async function exist(file) {
  return stat(file).then(() => true).catch(() => false);
}
async function readPackageJson(dir) {
  const packageJsonPath = join(dir, "package.json");
  const content = JSON.parse(
    await readFile(packageJsonPath, "utf-8")
  );
  return {
    content,
    write: (value = content) => writeFile(packageJsonPath, JSON.stringify(value, null, 2), "utf-8")
  };
}

// libs/canary/src/lib/examples.ts
var tasks = `import {
	feature,
	field,
	table,
	trigger,
	workflow,
} from '@january/declarative';
import {
	createQueryBuilder,
	deferredJoinPagination,
	execute,
	patchEntity,
	saveEntity,
} from '@workspace/extensions/sqlite';
import z from 'zod';
import { tables } from '@workspace/entities';

export default feature({
	tables: {
		categories: table({
			fields: {
				name: field.shortText(),
			},
		}),
		tasks: table({
			fields: {
				title: field.shortText(),
				description: field.longText(),
				category: field.relation({
					references: tables.categories,
					relationship: 'many-to-one',
				}),
			},
		}),
	},
	workflows: [
		workflow('AddCategory', {
			tag: 'category',
			trigger: trigger.http({
				method: 'post',
				path: '/',
				input: (trigger) => ({
					name: {
						select: trigger.body.name,
						against: z.string().trim().min(1),
					},
				}),
			}),
			execute: async ({ input }) => {
				const { id } = await saveEntity(tables.categories, {
					name: input.name,
				});
				return { id };
			},
		}),
		workflow('AddTask', {
			tag: 'tasks',
			trigger: trigger.http({
				method: 'post',
				path: '/',
				input: (trigger) => ({
					title: {
						select: trigger.body.title,
						against: z.string().trim().min(1),
					},
					description: {
						select: trigger.body.description,
						against: z.string().trim(),
					},
					categoryId: {
						select: trigger.body.categoryId,
						against: z.string().uuid(),
					},
				}),
			}),
			execute: async ({ input }) => {
				const { id } = await saveEntity(tables.tasks, {
					title: input.title,
					description: input.description,
					categoryId: input.categoryId,
				});
				return { id };
			},
		}),
		workflow('UpdateTask', {
			tag: 'tasks',
			trigger: trigger.http({
				method: 'put',
				path: '/',
				input: (trigger) => ({
					id: {
						select: trigger.body.id,
						against: z.string().uuid(),
					},
					title: {
						select: trigger.body.title,
						against: z.string().trim().min(1),
					},
					description: {
						select: trigger.body.description,
						against: z.string().trim(),
					},
					categoryId: {
						select: trigger.body.categoryId,
						against: z.string().uuid(),
					},
				}),
			}),
			execute: async ({ input }) => {
				const qb = createQueryBuilder(tables.tasks, 'tasks').where(
					'tasks.id = :id',
					{ id: input.id }
				);
				await patchEntity(qb, {
					title: input.title,
					description: input.description,
					categoryId: input.categoryId,
				});
				return { id: input.id };
			},
		}),
		workflow('ListTasks', {
			tag: 'tasks',
			trigger: trigger.http({
				method: 'get',
				path: '/',
				input: (trigger) => ({
					pageSize: {
						select: trigger.query.pageSize,
						against: z.number().min(1).max(100),
					},
					pageNo: {
						select: trigger.query.pageNo,
						against: z.number().min(1),
					},
				}),
			}),
			execute: async ({ input }) => {
				const qb = createQueryBuilder(tables.tasks, 'tasks');
				const paginationMetadata = deferredJoinPagination(qb, {
					pageSize: input.pageSize,
					pageNo: input.pageNo,
					count: await qb.getCount(),
				});
				const records = await execute(qb);
				return {
					meta: paginationMetadata(records),
					records: records,
				};
			},
		}),
	],
});
`;
var root = `import { feature, trigger, workflow } from '@january/declarative';
import { dataSource } from '@workspace/extensions/sqlite';

export default feature({
	tables: {},
	workflows: [
		workflow('EmptyFavicon', {
			tag: 'root',
			trigger: trigger.http({
				method: 'get',
				path: '/favicon.ico',
			}),
			execute: async ({ output }) => {
				return output.nocontent();
			},
		}),
		workflow('SayHi', {
			tag: 'root',
			trigger: trigger.http({
				method: 'get',
				path: '/',
			}),
			execute: async () => {
				return {
					status: 'UP',
				};
			},
		}),
		workflow('HealthCheck', {
			tag: 'root',
			trigger: trigger.http({
				method: 'get',
				path: '/health',
			}),
			execute: async () => {
				await dataSource.query('SELECT 1');
				return {
					status: 'UP',
				};
			},
		}),
	],
});
`;
var startup = `
import { initialize } from '@workspace/extensions/sqlite';
import { parse } from '@workspace/validation';
import z from 'zod';

const env = z.object({
	...(await import('@workspace/extensions/sqlite')).env,
	NODE_ENV: z.enum(['development', 'test', 'production']),
});

const [data, errors] = parse(env, process.env);
if (errors) {
	console.error(
		'Environment Variable Validation Error:',
		JSON.stringify(errors, null, 2)
	);
	console.error(
		'Please check that all required environment variables are correctly set.'
	);
	process.exit(1);
} else {
	console.log('Environment Variable Validation Passed');
}

process.env = Object.assign({}, process.env, data);

declare global {
	namespace NodeJS {
		// Extend the ProcessEnv interface with the parsed environment variables
		// @ts-ignore
		interface ProcessEnv extends z.infer<typeof env> {}
	}
}

// Block the event loop until the database is initialized
// It's esspecially important in serverless environment and machines where
// they listen to server binding events to know when the server is ready (e.g. fly.io)
// Otherwise, the server will start listening and accepting requests before the database is initialized
await initialize()
	.then(() => {
		console.log('Database initialized');
	})
	.catch((error) => {
		console.error(error);
		process.exit(1);
	});
`;

// libs/canary/src/lib/snippets.ts
var snippets_default = {
  "HTTP Workflow": {
    prefix: "httpworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.http({
    method: '$3',
    path: '$4',
  }),
  execute: async (trigger, request) => {
  const url = new URL(request.url);
  return {
      path: url.pathname,
      method: request.method,
    }
  },
}),
      `
    ],
    description: "Creates a generic HTTP workflow with customizable method and path"
  },
  "Schedule Workflow": {
    prefix: "cronworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.schedule({
    pattern: '$3',
  }),
  execute: async ({ trigger }) => {
    // Scheduled task logic here
  },
}),
      `
    ],
    description: "Creates a generic Cron schedule workflow"
  },
  "WebSocket Workflow": {
    prefix: "websocketworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.websocket({
    topic: '$3',
  }),
  execute: async ({ trigger }) => {
    return trigger.channel; // WebSocket response logic here
  },
}),
      `
    ],
    description: "Creates a generic WebSocket workflow"
  },
  "SSE Workflow": {
    prefix: "sseworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.sse({
    path: '$3',
  }),
  execute: async ({ trigger }) => {
    const stream = new PassThrough();
    setInterval(() => {
    stream.push('data: $4\\n\\n');
    }, 1000);
    return stream;
  },
}),
      `
    ],
    description: "Creates a generic Server-Sent Events (SSE) workflow"
  },
  "GitHub Webhook Workflow": {
    prefix: "githubworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.github({
    event: '$3',
  }),
  execute: async ({ trigger }) => {
    // Webhook logic here
  },
}),
      `
    ],
    description: "Creates a generic GitHub Webhook workflow"
  },
  "Create Workflow": {
    prefix: "createworkflow",
    body: [
      `workflow('Create$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'post',
    path: '/$3',
  }),
  execute: async ({ trigger }) => {
    const record = await saveEntity(tables.$4, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for inserting a new entity and returns the record's ID"
  },
  "List Workflow": {
    prefix: "listworkflow",
    body: [
      `workflow('List$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4');
    const paginationMetadata = limitOffsetPagination(qb, {
      pageSize: trigger.query.pageSize,
      pageNo: trigger.query.pageNo,
      count: await qb.getCount(),
    }),
    const records = await execute(qb);
    return {
      meta: paginationMetadata(records),
      records: records,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for listing multiple entities with pagination"
  },
  "Get Workflow": {
    prefix: "getworkflow",
    body: [
      `workflow('Get$1ById', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await execute(qb);
    return record;
  },
}),
      `
    ],
    description: "Creates a workflow for reading a single entity by ID"
  },
  "Update Workflow": {
    prefix: "updateworkflow",
    body: [
      `workflow('Update$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'patch',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(ttables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for updating an entity by ID and returns the record's ID"
  },
  "Delete Workflow": {
    prefix: "deleteworkflow",
    body: [
      `workflow('Delete$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'delete',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    await removeEntity(qb);
    return {
      id: trigger.path.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for deleting an entity by ID and returns the deleted ID"
  },
  "Replace Workflow": {
    prefix: "replaceworkflow",
    body: [
      `workflow('Replace$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'put',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for replacing an entity and returns the updated ID"
  },
  "Exists Workflow": {
    prefix: "existsworkflow",
    body: [
      `workflow('Exists$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'head',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const doesExist = await exists(qb);
    return {
      exists: doesExist,
    };
  },
}),
      `
    ],
    description: "Creates a workflow to check if an entity exists by ID"
  }
};

// libs/canary/src/program.ts
import cliSpinners from "cli-spinners";
import { program } from "commander";
import ora from "ora";
import { platform } from "os";
var cli = program.name("january").version("1.0.0").description("January").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command");
var SPINNER_TYPE = platform() === "win32" ? cliSpinners.material : cliSpinners.pipe;
var spinner = ora({
  spinner: SPINNER_TYPE,
  prefixText: "\u2500 Serverize"
});

// libs/canary/src/cli.ts
var parentDir = process.cwd();
var toolsFiles = {
  "tools/january.config.js": `import { defineConfig } from '@january/canary';
import { serverize } from '@january/extensions/serverize';
import { hono } from '@january/extensions/hono';
import { identity } from '@january/extensions/identity';
import { sqlite, typeorm } from '@january/extensions/typeorm';

export default defineConfig({
  formatGeneratedCode: true,
  extensions: [
    identity,
    hono(),
    serverize(),
    typeorm({
      database: sqlite(),
    }),
  ],
});
`,
  "tools/tsconfig.json": toJson({
    include: ["./**/*.js", "./**/*.ts"],
    exclude: ["vite.config.ts", "src/**/*.spec.ts", "src/**/*.test.ts"],
    compilerOptions: {
      target: "ESNext",
      moduleResolution: "Bundler",
      module: "ESNext",
      types: ["node"],
      allowJs: true,
      checkJs: true,
      noEmit: true
    }
  }),
  "tools/compose.js": `
import packageJson from '../package.json' assert { type: 'json' };

import {
	compose,
	nodeServer,
	postgres,
	service,
} from 'serverize/dockercompose';

await compose({
	database: service(postgres),
	server: service({
		...nodeServer({
			image: \`\${packageJson.name}:\${packageJson.version}\`,
			dockerfile: 'Dockerfile.serverize',
		}),
		depends_on: [postgres],
	}),
}).write();

`,
  "tools/link-client.js": `import { execSync } from 'child_process';
import { join } from 'node:path';

export function linkPackage(name, source, target) {
	execSync('npm link', {
		cwd: source,
	});
	execSync(\`npm link \${name}\`, {
		cwd: target,
	});
}

linkPackage(
	'your-client-name',
	join(process.cwd(), 'client'),
	'/path/to/project'
	// Path to the project that uses the client
);

// Run this script to link the client package to the project
// node ./tools/link-client.js

`
};
cli.command("init", { isDefault: true }).argument("[name]", "Project name").action(async (name) => {
  name ||= await input({ message: "Project name" });
  spinner.start(`Scaffolding project ${name}`);
  const projectDir = join2(parentDir, name);
  await writeFiles(projectDir, {
    // TODO: add prettier
    ".npmrc": [
      "legacy-peer-deps=true",
      "node-options=--disable-warning=ExperimentalWarning"
    ].join("\n"),
    ".vscode/january.code-snippets": toJson(snippets_default),
    ".vscode/settings.json": toJson({
      "editor.snippets.codeActions.enabled": true,
      "editor.suggest.showSnippets": true,
      "editor.suggest.snippetsPreventQuickSuggestions": false,
      "editor.snippetSuggestions": "bottom",
      "typescript.preferences.importModuleSpecifier": "non-relative",
      "files.autoSave": "afterDelay",
      "files.autoSaveWhenNoErrors": false,
      "files.refactoring.autoSave": true,
      "files.autoSaveDelay": 500,
      "explorer.fileNesting.enabled": true,
      "explorer.fileNesting.expand": true,
      "explorer.fileNesting.patterns": {
        "package.json": "package*.json",
        "tsconfig.json": "tsconfig*.json, .prettier*, .gitignore",
        ".env.": "*.env.",
        Dockerfile: "Dockerfile*, *.toml, compose.*, docker-compose.*, .dockerignore"
      }
    }),
    "package.json": toJson({
      name,
      version: "1.0.0",
      type: "module",
      private: true,
      main: "./dist/server.js",
      scripts: {
        start: "node --env-file-if-exists .env dist/server.js",
        "start:watch": "node --env-file-if-exists .env --watch dist/server.js",
        build: "node tools/january.config.js",
        "build:watch": "node --watch-path src/january --watch-path tools tools/january.config.js",
        bundle: "node esbuild.js",
        "bundle:watch": "node esbuild.js --watch",
        dev: 'npx concurrently -k -t "HH:mm:ss" -p "[{name}]" -n "server,generator,bundler" -c "green.bold,yellow.bold,blue.bold" "npm run start:watch" "npm run build:watch" "npm run bundle:watch" '
      },
      dependencies: {},
      devDependencies: {
        "@january/extensions": "https://github.com/JanuaryLabs/dist/raw/main/extensions.tar.gz",
        "@january/declarative": "https://github.com/JanuaryLabs/dist/raw/main/declarative.tar.gz",
        "@january/canary": "https://github.com/JanuaryLabs/dist/raw/main/canary.tar.gz",
        serverize: await latestVersion("serverize")
      }
    }),
    "tsconfig.base.json": toJson({
      compilerOptions: {
        jsx: "preserve",
        target: "ESNext",
        module: "ESNext",
        lib: ["ESNext"],
        moduleResolution: "Bundler",
        rootDir: ".",
        strict: true,
        allowSyntheticDefaultImports: true,
        esModuleInterop: true,
        experimentalDecorators: true,
        emitDecoratorMetadata: true,
        skipLibCheck: true,
        skipDefaultLibCheck: true,
        noEmit: true,
        allowImportingTsExtensions: true,
        paths: {
          "@workspace/extensions/*": [
            "src/january/extensions/*",
            "src/app/extensions/*"
          ],
          "@workspace/entities/*": ["src/app/entities/*"],
          "@workspace/entities": ["src/app/features/entities.ts"],
          "@workspace/identity": ["src/app/extensions/identity/index.ts"],
          "@workspace/utils": ["src/app/core/utils.ts"],
          "@workspace/validation": ["src/app/core/validation.ts"]
        }
      },
      files: [],
      include: []
    }),
    "src/january/tsconfig.json": toJson({
      extends: "../../tsconfig.base.json",
      include: ["**/*.ts", "**/*.tsx", "../../references.d.ts"],
      exclude: ["**/*.spec.ts", "**/*.test.ts"],
      compilerOptions: {
        module: "ESNext",
        types: ["node"]
      }
    }),
    "src/app/tsconfig.json": toJson({
      extends: "../../tsconfig.base.json",
      include: ["**/*.ts", "**/*.tsx"],
      exclude: ["**/*.spec.ts", "**/*.test.ts"],
      compilerOptions: {
        module: "ESNext",
        types: ["node"]
      }
    }),
    ".env": toKevValEnv({
      NODE_ENV: "development",
      ORM_LOGGING: "false",
      ORM_SYNCHRONIZE: "false",
      ORM_MIGRATIONS_RUN: "true",
      CONNECTION_STRING: "hello.sqlite"
    }),
    ".gitignore": await fetch(
      "https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore"
    ).then((res) => res.text()),
    "esbuild.js": `import esbuild from 'esbuild';
import { join } from 'node:path';

const production = process.argv.includes('--production');
const watch = process.argv.includes('--watch');

const ctx = await esbuild.context({
	entryPoints: [join(process.cwd(), 'src/app/server.ts')],
	platform: 'node',
	format: 'esm',
	treeShaking: true,
	minify: production,
	sourcemap: !production,
	keepNames: true,
	minifyIdentifiers: false,
	minifySyntax: false,
	minifyWhitespace: false,
	packages: 'external',
	outdir: join(process.cwd(), 'dist'),
	bundle: true,
	banner: {
		js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);",
	},
	assetNames: '[name]',
	loader: {
		'.swagger.json': 'file',
	},
});

if (watch) {
	await ctx.watch();
	console.log('Watching for changes...');
} else {
	await ctx.rebuild();
	await ctx.dispose();
	console.log('Build complete!');
}
`,
    "src/january/features/task-manager.ts": tasks,
    "src/january/features/root.ts": root,
    "src/january/extensions/user/index.ts": "",
    "src/app/startup.ts": startup,
    ...toolsFiles
  });
  spinner.info("Initializing git repo");
  const git = simpleGit(projectDir);
  await git.init().catch(() => {
    console.error(
      'Failed to initialize git repo. Please initialize the git repo "git init".'
    );
  });
  spinner.info("Installing dependencies");
  installDeps(projectDir);
  spinner.info("Running first build");
  execSync("node ./tools/january.config.js", {
    cwd: projectDir,
    encoding: "utf-8",
    stdio: "inherit"
  });
  spinner.info("Installing output dependencies");
  installDeps(projectDir);
  box(
    `Project ${name} scaffolded successfully`,
    `Directory: ${projectDir}`,
    `cd ${name}`,
    `Run the project in watch mode using 'npm run build'`,
    `Start the server 'npm run dev'`
  );
  const lines = [
    // '🌟 Star January on GitHub: https://github.com/januarylabs/january',
    // '📢 Stay up to date: https://discord.gg/aj9bRtrmNt',
    "\u{1F4AC} Discuss January on Discord: https://discord.gg/aj9bRtrmNt"
  ];
  lines.forEach((line) => console.log(line));
});
function installDeps(cwd) {
  execSync("npm install --no-audit --no-fund", {
    cwd,
    encoding: "utf-8",
    stdio: "inherit"
  });
}
cli.command("migrate").usage("Migrate the project to the latest version").option("--no-install", "Do not run npm install", true).action(async ({ install }) => {
  spinner.start(`Starting migration`);
  const projectDir = process.cwd();
  await updateJanuaryPackages(projectDir).catch((error) => {
    console.error("Failed to check for new version");
    console.error(error);
  });
  const oldComposePath = join2(projectDir, "compose.ts");
  if (await exist(oldComposePath)) {
    await rm(oldComposePath, { force: true, recursive: true });
  }
  if (!await exist(join2(projectDir, "tools"))) {
    await writeFiles(projectDir, toolsFiles);
  }
  await rm(join2(projectDir, "extensions.json"), { force: true });
  await rm(join2(projectDir, "tools", "extensions.json"), { force: true });
  const projectPackageJson = await readPackageJson(projectDir);
  projectPackageJson.content.type = "module";
  Object.assign(projectPackageJson.content.scripts, {
    start: "node --env-file .env ./output",
    "start:watch": "node --env-file .env --watch-path ./output/build ./output",
    build: "node ./tools/january.config.js",
    "build:watch": "node --watch-path ./src --watch-path ./tools ./tools/january.config.js",
    dev: 'npx concurrently -k -t "HH:mm:ss" -p "[{name}]" -n "server,build" -c "blue.bold,green.bold" "npm run start:watch" "npm run build:watch" '
  });
  await projectPackageJson.write();
  if (install) {
    execSync(`npm install --no-audit --no-fund`, {
      cwd: projectDir,
      encoding: "utf-8",
      stdio: "inherit"
    });
  }
  execSync("node ./tools/january.config.js", {
    cwd: projectDir,
    encoding: "utf-8",
    stdio: "inherit"
  });
});
cli.parse(process.argv);
async function getLatestVersion() {
  const octokit = new Octokit();
  const fullName = "JanuaryLabs/dist";
  const [owner, repo] = fullName.split("/");
  const { data: files } = await octokit.request(
    "GET /repos/{owner}/{repo}/contents",
    {
      owner,
      repo,
      path: "",
      ref: "main"
    }
  );
  const semvers = files.filter((it) => it.type === "dir").map((it) => it.name);
  return semver.maxSatisfying(semvers, "*");
}
async function updateJanuaryPackages(projectDir) {
  const januaryUpdateFile = join2(tmpdir(), "january-update.txt");
  const lastUpdate = await readFile2(januaryUpdateFile, "utf-8").catch(
    () => null
  );
  if (lastUpdate && differenceInMinutes(/* @__PURE__ */ new Date(), new Date(lastUpdate)) < 60) {
    return;
  }
  const canaryPackageJson = await readPackageJson(
    join2(projectDir, "node_modules", "@january/canary")
  );
  const projectPackageJson = await readPackageJson(projectDir);
  const latestVersion2 = await getLatestVersion();
  if (semver.gt(latestVersion2, canaryPackageJson.content.version)) {
    console.log(`New version ${latestVersion2} available. Upgrading...`);
    const packages = [
      "canary",
      "docker",
      "declarative",
      "extensions",
      "console"
    ];
    const packagesLinks = packages.map(
      (it) => `https://github.com/JanuaryLabs/dist/raw/main/${latestVersion2}/${it}.tar.gz`
    );
    projectPackageJson.content.dependencies = packages.reduce(
      (acc, it, i) => ({
        ...acc,
        [`@january/${it}`]: packagesLinks[i]
      }),
      projectPackageJson.content.dependencies ?? {}
    );
    await projectPackageJson.write();
    await writeFile2(januaryUpdateFile, (/* @__PURE__ */ new Date()).toISOString());
  }
}
//# sourceMappingURL=cli.js.map
