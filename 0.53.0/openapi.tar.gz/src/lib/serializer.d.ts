import ts from 'typescript';
export declare function parseTsConfig(tsconfigPath: string): ts.ParsedCommandLine;
export declare const serializeSymbol: unique symbol;
export declare function serialize(tsconfigPath: string, features: {
    name: string;
    path: string;
}[]): Record<string, Record<string, string>>;
export type Serialized = ReturnType<typeof serialize>;
export declare function flattenSerialized(serialized: Serialized): Record<string, string>;
