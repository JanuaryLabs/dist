export interface VirtualFile {
    isFolder: boolean;
    name: string;
    path: string;
    content: string;
    extension: string;
}
export interface VirtualFileNode {
    id: string;
    name: string;
    path?: string;
    children?: VirtualFileNode[];
    metadata?: Record<string, any>;
}
export declare function toVirtualFile(it: {
    path: string;
    content: string;
}): {
    isFolder: boolean;
    name: string;
    path: string;
    extension: string;
    content: string;
    metadata: {
        path: string;
    };
};
export declare function mapFilesToTree(files: VirtualFile[]): {};
export declare function mapFilesToTreeNodes(files: VirtualFile[]): VirtualFileNode[];
export declare function getFile(list: VirtualFile[], path: string): VirtualFile;
export declare function emptyFile(file?: Partial<VirtualFile>): VirtualFile;
