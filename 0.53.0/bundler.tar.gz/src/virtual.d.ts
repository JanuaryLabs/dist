import type { Plugin } from 'esbuild';
import esbuild from 'esbuild';
export interface BundableFile {
    content: string;
    path: string;
}
export declare function virtualBundle(options: {
    src: string;
    dist: string;
    files: BundableFile[];
}): Promise<esbuild.BuildResult<{
    entryPoints: string[];
    write: false;
    platform: "node";
    treeShaking: true;
    minify: true;
    format: "esm";
    outfile: string;
    keepNames: true;
    bundle: true;
    assetNames: string;
    loader: {
        '.json': "file";
    };
    tsconfigRaw: any;
    plugins: Plugin[];
}>>;
