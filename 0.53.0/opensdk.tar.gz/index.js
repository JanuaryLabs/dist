import{get as J,merge as ce}from"lodash";import{camelcase as B,cramcase as Ke,dotcase as Xe,pascalcase as E,sentencecase as Ye,snakecase as et,spinalcase as tt,titlecase as U}from"stringcase";import{v4 as De}from"uuid";import ye from"retry";import{snakecase as ge,spinalcase as xe}from"stringcase";function O(e,t=r=>r){return`{${Object.keys(e).map(r=>`${r}: ${t(e[r])}`).join(", ")}}`}function S(e,t){return[...new Map(e.map(r=>[t(r),r])).values()]}import{get as ee}from"lodash";function q(e){return e.replace(/^#\//,"")}function A(e,t){let r=q(t).split("/"),s=ee(e,r);return s&&"$ref"in s?A(e,s.$ref):s}function y(e,t,r=!1,s){if("$ref"in t){let u=q(t.$ref).split("/").pop();return s(u,y(e,A(e,t.$ref),r,s)),u}if(t.allOf&&Array.isArray(t.allOf))return`z.intersection(${t.allOf.map(p=>y(e,p,!0,s)).join(", ")})`;if(t.anyOf&&Array.isArray(t.anyOf))return`z.union([${t.anyOf.map(p=>y(e,p,!1,s)).join(", ")}])${m(r)}`;if(t.oneOf&&Array.isArray(t.oneOf))return`z.union([${t.oneOf.map(p=>y(e,p,!1,s)).join(", ")}])${m(r)}`;if(t.enum&&Array.isArray(t.enum))return`z.enum([${t.enum.map(p=>JSON.stringify(p)).join(", ")}])${m(r)}`;let i=Array.isArray(t.type)?t.type:t.type?[t.type]:[];if(!i.length)return`z.unknown()${m(r)}`;if(i.length>1){let u=i.filter(a=>a!=="null");return u.length===1&&i.includes("null")?`${P(u[0],t,e,!1,s)}.nullable()${m(r)}`:`z.union([${i.map(a=>P(a,t,e,!1,s)).join(", ")}])${m(r)}`}return P(i[0],t,e,r,s)}function P(e,t,r,s=!1,i){switch(e){case"string":return te(t,s);case"number":case"integer":return re(t,s);case"boolean":return`z.boolean()${F(t.default)}${m(s)}`;case"object":return ne(t,r,s,i);case"array":return se(t,r,s,i);case"null":return`z.null()${m(s)}`;default:return`z.unknown()${m(s)}`}}function te(e,t){let r="z.string()";switch(e.format){case"date-time":case"datetime":r="z.coerce.date()";break;case"date":r="z.coerce.date() /* or z.string() if you want raw date strings */";break;case"time":r="z.string() /* optionally add .regex(...) for HH:MM:SS format */";break;case"email":r="z.string().email()";break;case"uuid":r="z.string().uuid()";break;case"url":case"uri":r="z.string().url()";break;case"ipv4":r='z.string().ip({version: "v4"})';break;case"ipv6":r='z.string().ip({version: "v6"})';break;case"phone":r="z.string() /* or add .regex(...) for phone formats */";break;case"byte":case"binary":r="z.instanceof(Blob) /* consider base64 check if needed */";break;case"int64":r="z.string() /* or z.bigint() if your app can handle it */";break;default:break}return`${r}${F(e.default)}${m(t)}`}function re(e,t){let r=e.default!==void 0?`.default(${e.default})`:"",s="z.number()";return e.format==="int64"&&(s="z.bigint()",e.default!==void 0&&(r=`.default(BigInt(${e.default}))`)),e.format==="int32"&&(s+=".int()"),typeof e.exclusiveMinimum=="number"&&(s+=`.gt(${e.exclusiveMinimum})`),typeof e.exclusiveMaximum=="number"&&(s+=`.lt(${e.exclusiveMaximum})`),typeof e.minimum=="number"&&(s+=e.format==="int64"?`.min(BigInt(${e.minimum}))`:`.min(${e.minimum})`),typeof e.maximum=="number"&&(s+=e.format==="int64"?`.max(BigInt(${e.maximum}))`:`.max(${e.maximum})`),typeof e.multipleOf=="number"&&(s+=`.refine((val) => Number.isInteger(val / ${e.multipleOf}), "Must be a multiple of ${e.multipleOf}")`),`${s}${r}${m(t)}`}function ne(e,t,r=!1,s){let i=e.properties||{},u=Object.entries(i).map(([h,c])=>{let o=(e.required??[]).includes(h),T=y(t,c,o,s);return`'${h}': ${T}`}),p="";return e.additionalProperties&&(typeof e.additionalProperties=="object"?p=`.catchall(${y(t,e.additionalProperties,!0,s)})`:e.additionalProperties===!0&&(p=".catchall(z.unknown())")),`${`z.object({${u.join(", ")}})${p}`}${m(r)}`}function se(e,t,r=!1,s){let{items:i}=e;return i?Array.isArray(i)?`${`z.tuple([${i.map(h=>y(t,h,!0,s)).join(", ")}])`}${m(r)}`:`z.array(${y(t,i,!0,s)})${m(r)}`:`z.array(z.unknown())${m(r)}`}function m(e){return e?"":".optional()"}function F(e){return e!==void 0?`.default(${JSON.stringify(e)})`:""}var M=`import { parse } from 'fast-content-type-parse';

import type { Endpoints } from './endpoints';

export interface RequestInterface<D extends object = object> {
  /**
   * Sends a request based on endpoint options
   *
   * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'
   * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.
   */
  <R extends keyof Endpoints>(
    route: R,
    options?: Endpoints[R]['input'],
  ): Promise<Endpoints[R]['output']>;
}

export async function handleError(response: Response) {
  try {
    if (response.status >= 400 && response.status < 500) {
      const body = (await response.json()) as Record<string, any>;
      return {
        status: response.status,
        body: body,
      };
    }
    return new Error(
      \`An error occurred while fetching the data. Status: \${response.status}\`,
    );
  } catch (error) {
    return error as any;
  }
}

async function handleChunkedResponse(response: Response, contentType: string) {
  const { type } = parse(contentType);

  switch (type) {
    case 'application/json': {
      let buffer = '';
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
      }
      return JSON.parse(buffer);
    }
    case 'text/html':
    case 'text/plain': {
      let buffer = '';
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
      }
      return buffer;
    }
    default:
      return response.body;
  }
}

export async function parseResponse(response: Response) {
  const contentType = response.headers.get('Content-Type');
  if (!contentType) {
    throw new Error('Content-Type header is missing');
  }

  if (response.status === 204) {
    return null;
  }
  const isChunked = response.headers.get('Transfer-Encoding') === 'chunked';
  if (isChunked) {
    return response.body;
    // return handleChunkedResponse(response, contentType);
  }

  const { type } = parse(contentType);
  switch (type) {
    case 'application/json':
      return response.json();
    case 'text/plain':
      return response.text();
    case 'text/html':
      return response.text();
    case 'text/xml':
    case 'application/xml':
      return response.text();
    case 'application/x-www-form-urlencoded':
      const text = await response.text();
      return Object.fromEntries(new URLSearchParams(text));
    case 'multipart/form-data':
      return response.formData();
    default:
      throw new Error(\`Unsupported content type: \${contentType}\`);
  }
}
`;var D=`import { z } from 'zod';

export type ParseError<T extends z.ZodType<any, any, any>> = {
  kind: 'parse';
} & z.inferFlattenedErrors<T>;

export function parse<T extends z.ZodType>(
  schema: T,
  input: unknown,
) {
  const result = schema.safeParse(input);
  if (!result.success) {
    const errors = result.error.flatten((issue) => issue);
    return [null, errors];
  }
  return [result.data as z.infer<T>, null];
}
`;var H=`import { BodyInit } from 'undici-types'; // for node
type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type ContentType = 'xml' | 'json' | 'urlencoded' | 'multipart';
type Endpoint = \`\${ContentType} \${Method} \${string}\` | \`\${Method} \${string}\`;

export function createUrl(base: string, path: string, query: URLSearchParams) {
  const url = new URL(path, base);
  url.search = query.toString();
  return url;
}
function template(
  templateString: string,
  templateVariables: Record<string, any>,
): string {
  const nargs = /{([0-9a-zA-Z_]+)}/g;
  return templateString.replace(nargs, (match, key: string, index: number) => {
    // Handle escaped double braces
    if (
      templateString[index - 1] === '{' &&
      templateString[index + match.length] === '}'
    ) {
      return key;
    }

    const result = key in templateVariables ? templateVariables[key] : null;
    return result === null || result === undefined ? '' : String(result);
  });
}

interface ToRequest {
  <T extends Endpoint>(
    endpoint: T,
    input: Record<string, any>,
    props: {
      inputHeaders: string[];
      inputQuery: string[];
      inputBody: string[];
      inputParams: string[];
    },
    defaults: {
      baseUrl: string;
      headers?: Record<string, string>;
    },
  ): Request;
  urlencoded: <T extends Endpoint>(
    endpoint: T,
    input: Record<string, any>,
    props: {
      inputHeaders: string[];
      inputQuery: string[];
      inputBody: string[];
      inputParams: string[];
    },
    defaults: {
      baseUrl: string;
      headers?: Record<string, string>;
    },
  ) => Request;
}

function _json(
  input: Record<string, any>,
  props: {
    inputHeaders: string[];
    inputQuery: string[];
    inputBody: string[];
    inputParams: string[];
  },
) {
  const headers = new Headers({});
  for (const header of props.inputHeaders) {
    headers.set(header, input[header]);
  }

  const body: Record<string, any> = {};
  for (const prop of props.inputBody) {
    body[prop] = input[prop];
  }

  const query = new URLSearchParams();
  for (const key of props.inputQuery) {
    const value = input[key];
    if (value !== undefined) {
      query.set(key, String(value));
    }
  }

  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
    acc[key] = input[key];
    return acc;
  }, {});

  return {
    body: JSON.stringify(body),
    query,
    params,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
  };
}

type Input = Record<string, any>;
type Props = {
  inputHeaders: string[];
  inputQuery: string[];
  inputBody: string[];
  inputParams: string[];
};

abstract class Serializer {
  constructor(
    protected input: Input,
    protected props: Props,
  ) {}
  abstract getBody(): BodyInit | null;
  abstract getHeaders(): Record<string, string>;
  serialize(): Serialized {
    const headers = new Headers({});
    for (const header of this.props.inputHeaders) {
      headers.set(header, this.input[header]);
    }

    const query = new URLSearchParams();
    for (const key of this.props.inputQuery) {
      const value = this.input[key];
      if (value !== undefined) {
        query.set(key, String(value));
      }
    }

    const params = this.props.inputParams.reduce<Record<string, any>>(
      (acc, key) => {
        acc[key] = this.input[key];
        return acc;
      },
      {},
    );

    return {
      body: this.getBody(),
      query,
      params,
      headers: this.getHeaders(),
    };
  }
}

interface Serialized {
  body: BodyInit | null;
  query: URLSearchParams;
  params: Record<string, any>;
  headers: Record<string, string>;
}

class JsonSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body: Record<string, any> = {};
    for (const prop of this.props.inputBody) {
      body[prop] = this.input[prop];
    }
    return JSON.stringify(body);
  }
  getHeaders(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }
}

class UrlencodedSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body = new URLSearchParams();
    for (const prop of this.props.inputBody) {
      body.set(prop, this.input[prop]);
    }
    return body;
  }
  getHeaders(): Record<string, string> {
    return {};
  }
}

class FormDataSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body = new FormData();
    for (const prop of this.props.inputBody) {
      body.append(prop, this.input[prop]);
    }
    return body;
  }
  getHeaders(): Record<string, string> {
    return {};
  }
}

export function json(input: Input, props: Props) {
  return new JsonSerializer(input, props).serialize();
}
export function urlencoded(input: Input, props: Props) {
  return new UrlencodedSerializer(input, props).serialize();
}
export function formdata(input: Input, props: Props) {
  return new FormDataSerializer(input, props).serialize();
}

export function _urlencoded(
  input: Record<string, any>,
  props: {
    inputHeaders: string[];
    inputQuery: string[];
    inputBody: string[];
    inputParams: string[];
  },
) {
  const headers = new Headers({});
  for (const header of props.inputHeaders) {
    headers.set(header, input[header]);
  }

  const body = new URLSearchParams();
  for (const prop of props.inputBody) {
    body.set(prop, input[prop]);
  }

  const query = new URLSearchParams();
  for (const key of props.inputQuery) {
    const value = input[key];
    if (value !== undefined) {
      query.set(key, String(value));
    }
  }

  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
    acc[key] = input[key];
    return acc;
  }, {});

  return {
    body,
    query,
    params,
    headers: {},
  };
}

export function toRequest<T extends Endpoint>(
  endpoint: T,
  input: Serialized,
  defaults: {
    baseUrl: string;
    headers?: Record<string, string>;
  },
): Request {
  const [method, path] = endpoint.split(' ');

  const headers = new Headers({
    ...defaults?.headers,
    ...input.headers,
  });
  const pathVariable = template(path, input.params);

  const url = createUrl(defaults.baseUrl, pathVariable, input.query);
  return new Request(url, {
    method: method,
    headers: headers,
    body: method === 'GET' ? undefined : input.body,
  });
}
`;var V=`export interface ApiResponse<Status extends number, Body extends unknown> {
  kind: 'response';
  status: Status;
  body: Body;
}

// 4xx Client Errors
export type BadRequest = ApiResponse<400, { message: string }>;
export type Unauthorized = ApiResponse<401, { message: string }>;
export type PaymentRequired = ApiResponse<402, { message: string }>;
export type Forbidden = ApiResponse<403, { message: string }>;
export type NotFound = ApiResponse<404, { message: string }>;
export type MethodNotAllowed = ApiResponse<405, { message: string }>;
export type NotAcceptable = ApiResponse<406, { message: string }>;
export type Conflict = ApiResponse<409, { message: string }>;
export type Gone = ApiResponse<410, { message: string }>;
export type UnprocessableEntity = ApiResponse<422, { message: string; errors?: Record<string, string[]> }>;
export type TooManyRequests = ApiResponse<429, { message: string; retryAfter?: string }>;
export type PayloadTooLarge = ApiResponse<413, { message: string; }>;
export type UnsupportedMediaType = ApiResponse<415, { message: string; }>;

// 5xx Server Errors
export type InternalServerError = ApiResponse<500, { message: string }>;
export type NotImplemented = ApiResponse<501, { message: string }>;
export type BadGateway = ApiResponse<502, { message: string }>;
export type ServiceUnavailable = ApiResponse<503, { message: string; retryAfter?: string }>;
export type GatewayTimeout = ApiResponse<504, { message: string }>;

export type ClientError =
  | BadRequest
  | Unauthorized
  | PaymentRequired
  | Forbidden
  | NotFound
  | MethodNotAllowed
  | NotAcceptable
  | Conflict
  | Gone
  | UnprocessableEntity
  | TooManyRequests;

export type ServerError =
  | InternalServerError
  | NotImplemented
  | BadGateway
  | ServiceUnavailable
  | GatewayTimeout;

export type ProblematicResponse = ClientError | ServerError;
`;import{camelcase as _}from"stringcase";var G=e=>{let t={...e.options??{},fetch:{schema:"z.function().args(z.instanceof(Request)).returns(z.promise(z.instanceof(Response))).optional()"},baseUrl:{schema:"z.string().url()"}};e.securityScheme&&(t.token={schema:"z.string().optional()"});let r=e.securityScheme?`{Authorization: \`${U(e.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}`:"{}";return`

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { parse } from './parser';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${O(t,s=>s.schema)});
      type ${e.name}Options = z.infer<typeof optionsSchema>;
    export class ${e.name} {

      constructor(public options: ${e.name}Options) {}

  async request<E extends keyof Endpoints>(
    endpoint: E,
    input: Endpoints[E]['input'],
  ): Promise<readonly [Endpoints[E]['output'], Endpoints[E]['error'] | null]> {
      const route = schemas[endpoint];
      const [parsedInput, parseError] = parse(route.schema, input);
      if (parseError) {
        return [
          null as never,
          { ...parseError, kind: 'parse' } as never,
        ] as const;
      }
      const request = route.toRequest(parsedInput as never, {
        headers: this.defaultHeaders,
        baseUrl: this.options.baseUrl,
      });
      const response = await (this.options.fetch ?? fetch)(request);
      if (response.ok) {
        const data = await parseResponse(response);
        return [data as Endpoints[E]['output'], null] as const;
      }
      const error = await handleError(response);
      return [null as never, { ...error, kind: 'response' }] as const;
  }

      get defaultHeaders() {
        return ${r}
      }

  setOptions(options: Partial<${e.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${e.name}Options)[]) {
      if (validated[key] !== undefined) {
        (this.options[key] as typeof validated[typeof key]) = validated[key]!;
      }
    }
  }
}`};var N=class{#e=["import z from 'zod';",'import type { Endpoints } from "./endpoints";','import type { StreamEndpoints } from "./stream-endpoints";',"import { toRequest, json, urlencoded, formdata, createUrl } from './request';","import type { ParseError } from './parser';"];#t=[];addEndpoint(t,r){this.#t.push(`  "${t}": ${r},`)}addImport(t){this.#e.push(t)}complete(){return`${this.#e.join(`
`)}
export default {
${this.#t.join(`
`)}
}`}},j=class{imports=["import z from 'zod';","import type { ParseError } from './parser';"];endpoints=[];addEndpoint(t,r){this.endpoints.push(`  "${t}": ${r};`)}addImport(t){this.imports.push(t)}complete(){return`${this.imports.join(`
`)}
export interface Endpoints {
${this.endpoints.join(`
`)}
}`}},z=class extends j{complete(){return`${this.imports.join(`
`)}
export interface StreamEndpoints {
${this.endpoints.join(`
`)}
}`}};function vt(e){let t=new j,r=new z,s={},i=[],u=new N,p=[];for(let[a,h]of Object.entries(e.groups)){let c=_(a);s[c]=["import z from 'zod';"],t.addImport(`import * as ${c} from './inputs/${c}';`),r.addImport(`import * as ${c} from './inputs/${c}';`),u.addImport(`import * as ${c} from './inputs/${c}';`);for(let o of h){let T=_(`${o.name} schema`),v=`export const ${T} = ${Object.keys(o.schemas).length===1?Object.values(o.schemas)[0]:O(o.schemas)};`;s[c].push(v),i.push(...o.imports.map(d=>(d.namedImports??[]).map(n=>n.name)).flat());let g=`${c}.${T}`,$=o.formatOutput(),I=[],x=[],k=[],R=[];for(let[d,n]of Object.entries(o.inputs))if(n.source==="headers"||n.source==="header")I.push(`"${d}"`);else if(n.source==="query")x.push(`"${d}"`);else if(n.source==="body")k.push(`"${d}"`);else if(n.source==="path")R.push(`"${d}"`);else{if(n.source==="internal")continue;throw new Error(`Unknown source ${n.source} in ${d} ${JSON.stringify(n)} in ${o.name}`)}if(o.type==="sse"){let d=`z.infer<typeof ${g}>`,n=`${o.trigger.method.toUpperCase()} ${o.trigger.path}`;r.addImport(`import {${E(o.name)}} from './outputs/${o.name}';`),r.addEndpoint(n,`{input: ${d}, output: ${$.use}}`),u.addEndpoint(n,`{
        schema: ${g},
        toRequest(input: StreamEndpoints['${n}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${n}';
            return toRequest(endpoint, json(input, {
            inputHeaders: [${I}],
            inputQuery: [${x}],
            inputBody: [${k}],
            inputParams: [${R}],
          }), init);
          },
        }`)}else{t.addImport(`import {${$.import}} from './outputs/${o.name}';`),p.push(...o.errors??[]);let d=Object.keys(o.schemas).length>1;for(let n in o.schemas??{}){let f="";d&&n!=="json"&&(f=`${n} `);let b=`typeof ${g}${d?`.${n}`:""}`,l=`${f}${o.trigger.method.toUpperCase()} ${o.trigger.path}`;t.addEndpoint(l,`{input: z.infer<${b}>; output: ${$.use}; error: ${(o.errors??["ServerError"]).concat(`ParseError<${b}>`).join("|")}}`),u.addEndpoint(l,`{
          schema: ${g}${d?`.${n}`:""},
          toRequest(input: Endpoints['${l}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
            const endpoint = '${l}';
              return toRequest(endpoint, ${o.contentType||"json"}(input, {
              inputHeaders: [${I}],
              inputQuery: [${x}],
              inputBody: [${k}],
              inputParams: [${R}],
            }), init);
            },
          }`)}}}}return t.addImport(`import type { ${S(p,a=>a).join(", ")} } from './response';`),{...Object.fromEntries(Object.entries(s).map(([a,h])=>[`inputs/${a}.ts`,[i.length?`import {${S(i,c=>c)}} from '../zod';`:"",...h].join(`
`)])),"backend.ts":G(e),"parser.ts":D,"client.ts":M,"request.ts":H,"schemas.ts":u.complete(),"endpoints.ts":t.complete(),"stream-endpoints.ts":r.complete(),"response.ts":V}}function C(e){return"$ref"in e}var ue={400:"BadRequest",401:"Unauthorized",402:"PaymentRequired",403:"Forbidden",404:"NotFound",405:"MethodNotAllowed",406:"NotAcceptable",409:"Conflict",413:"PayloadTooLarge",410:"Gone",422:"UnprocessableEntity",429:"TooManyRequests",500:"InternalServerError",501:"NotImplemented",502:"BadGateway",503:"ServiceUnavailable",504:"GatewayTimeout"},de={target:"javascript",style:"github",operationId:(e,t,r)=>e.operationId?e.operationId:e.operationId||B(`${r} ${t.replace(/\//g," ")}`)};function Rt(e){let t={},r={},s={};for(let[i,u]of Object.entries(e.spec.paths??{}))for(let[p,a]of Object.entries(u)){let c=(e.operationId??de.operationId)(a,i,p);console.log(`Processing ${p} ${i}`);let o=(a.tags??["default"])[0];t[o]??=[];let T={},v=[],g=[];for(let n of a.parameters??[]){if(C(n))throw new Error(`Found reference in parameter ${n.$ref}`);if(!n.schema)throw new Error(`Schema not found for parameter ${n.name}`);T[n.name]={source:n.in,schema:""},g.push(n)}let $={},I={"application/json":"json","application/x-www-form-urlencoded":"urlencoded","multipart/form-data":"formdata","application/xml":"xml","text/plain":"text"},x;if(a.requestBody&&Object.keys(a.requestBody).length){let n=C(a.requestBody)?J(A(e.spec,a.requestBody.$ref),["content"]):a.requestBody.content;for(let f in n){let b=C(n[f].schema)?A(e.spec,n[f].schema.$ref):n[f].schema;$[I[f]]=y(e.spec,ce(b,{required:g.filter(l=>l.required).map(l=>l.name),properties:g.reduce((l,w)=>({...l,[w.name]:w.schema}),{})}),!0,(l,w)=>{r[l]=w,v.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"../zod",namedImports:[{isTypeOnly:!1,name:l}],namespaceImport:void 0})})}n["application/json"]?x="json":n["application/x-www-form-urlencoded"]?x="urlencoded":n["multipart/form-data"]?x="formdata":x="json"}else $[I["application/json"]]=y(e.spec,{type:"object",required:g.filter(n=>n.required).map(n=>n.name),properties:g.reduce((n,f)=>({...n,[f.name]:f.schema}),{})},!0,(n,f)=>{r[n]=f,v.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"./zod",namedImports:[{isTypeOnly:!1,name:n}],namespaceImport:void 0})});let k=[];a.responses??={};let R=!1,d=["import z from 'zod';"];for(let n in a.responses){let f=a.responses[n],b=+n;if(b>=400&&k.push(ue[n]??"ProblematicResponse"),b>=200&&b<300){R=!0;let l=J(f,["content"]),Z=l&&l["application/json"]?y(e.spec,l["application/json"].schema,!0,(L,W)=>{r[L]=W,v.push({defaultImport:void 0,isTypeOnly:!1,moduleSpecifier:"../zod",namedImports:[{isTypeOnly:!1,name:L}],namespaceImport:void 0})}):"z.instanceof(ReadableStream)";d.push(le(Q(Object.values(v).flat())).join(`
`)),d.push(`export const ${E(c+" output")} = ${Z}`)}}R||d.push(`export const ${E(c+" output")} = z.void()`),s[`${c}.ts`]=d.join(`
`),t[o].push({name:c,type:"http",imports:Q(Object.values(v).flat()),inputs:T,errors:k.length?k:["ServerError"],contentType:x,schemas:$,formatOutput:()=>({import:E(c+" output"),use:`z.infer<typeof ${E(c+" output")}>`}),trigger:{path:i,method:p}})}return{groups:t,commonSchemas:r,outputs:s}}function Q(e){let t={};for(let r of e)t[r.moduleSpecifier]=t[r.moduleSpecifier]??{moduleSpecifier:r.moduleSpecifier,defaultImport:r.defaultImport,namespaceImport:r.namespaceImport,namedImports:[]},r.namedImports&&t[r.moduleSpecifier].namedImports.push(...r.namedImports);return Object.values(t)}function le(e){return e.map(t=>{if(t.defaultImport)return`import ${t.defaultImport} from '${t.moduleSpecifier}'`;if(t.namespaceImport)return`import * as ${t.namespaceImport} from '${t.moduleSpecifier}'`;if(t.namedImports)return`import {${S(t.namedImports,r=>r.name).map(r=>r.name).join(", ")}} from '${t.moduleSpecifier}'`;throw new Error(`Invalid import ${JSON.stringify(t)}`)})}export{de as defaults,Rt as generate,vt as generateClientSdk};
