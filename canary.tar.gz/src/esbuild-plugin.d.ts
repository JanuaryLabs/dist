import type { Plugin } from 'esbuild';
import { type JanuaryConfig } from '.';
interface PluginOptions extends Omit<JanuaryConfig, 'formatGeneratedCode' | 'bundle'> {
    formatter: () => void | Promise<void>;
}
export declare function esbuildPlugin(options: PluginOptions): Plugin;
export {};
