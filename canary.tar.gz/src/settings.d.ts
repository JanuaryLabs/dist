import type { Contracts } from '@faslh/compiler/contracts';
export interface WorkspaceSettings {
    features: string;
    runtime: string;
    cwd: string;
    /**
     * The directory where the output files will be generated relative to the cwd
     */
    outputDir: string;
    userExtDir: string;
    /**
     * If true, the generated code will be formatted using prettier
     */
    formatGeneratedCode?: boolean;
}
export declare function createWorkflowSchema(workflow: Contracts.Workflow): Record<string, any>;
