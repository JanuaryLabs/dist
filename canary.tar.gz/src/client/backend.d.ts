import type { Spec } from './sdk';
declare const _default: (spec: Spec) => string;
export default _default;
