import type { Checker } from '@january/sdk/parser';
export interface FeatureSpec {
    featureName: string;
    workflows: {
        type: string;
        tag: string;
        schemaName: string;
        imports: Checker.ProjectImport[];
        trigger: Record<string, any>;
        inputs: Record<string, {
            source: string;
            schema: string;
        }>;
    }[];
}
export declare function generateClientSdk(specs: FeatureSpec[]): {
    'index.ts': string;
    'validator.ts': string;
    'client.ts': string;
    'request.ts': string;
    'schemas.ts': string;
    'endpoints.ts': string;
};
