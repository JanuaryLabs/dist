import type { Command } from '@faslh/isomorphic';
import type { Feature } from '@january/declarative';
import type { Changes } from './changes.projection';
export declare function toChanges(projectDefinition: Feature[]): Promise<Changes>;
export declare function isRequest<T extends Record<string, unknown>>(request: any): request is Command<T>;
