import type { Command } from '@faslh/isomorphic';
import type { UnknownFeature } from '@january/declarative';
import type { Changes } from './changes.projection';
export declare function toChanges(projectDefinition: UnknownFeature[]): Promise<Changes>;
export declare function isRequest<T extends Record<string, unknown>>(request: any): request is Command<T>;
