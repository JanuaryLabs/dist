import type { Command } from '@faslh/isomorphic';
import type { EmptyFeature } from '@january/declarative';
import type { Checker } from '@january/parser';
import type { Changes } from './changes.projection';
export interface PreChanges {
    features: EmptyFeature[];
    imports: Checker.ProjectImport[];
}
export declare function toChanges(projectDefinition: PreChanges): Promise<Changes>;
export declare function isRequest<T extends Record<string, unknown>>(request: any): request is Command<T>;
