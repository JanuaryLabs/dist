import type { Checker } from '@january/parser';
export interface WorkflowVM {
    displayName: string;
    featureName: string;
    trigger: IWorkflowTriggerVM;
    tag: string;
    code: string;
    structures: any;
    params: any;
    imports: Checker.Import[];
    output: Record<string, any>;
}
export interface IWorkflowTriggerVM {
    metadata: Record<string, any>;
    sourceId: string;
    details: Record<string, any>;
}
export interface IWorkflowActionVM {
    id: string;
    sourceId: string;
    details: Record<string, any>;
    outputName: string;
    displayName: string;
}
export interface PolicyVM {
    displayName: string;
    rule: string;
    imports: Checker.Import[];
}
export interface ExtensionVM {
    id: string;
    name: string;
    main?: string;
    details: Record<string, any>;
}
export interface FeatureVM {
    displayName: string;
}
export interface Changes {
    features: FeatureVM[];
    workflows: WorkflowVM[];
}
