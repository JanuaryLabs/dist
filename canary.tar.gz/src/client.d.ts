import type { Contracts } from '@faslh/compiler/contracts';
import { type SdkConfig } from './client/sdk';
import { type WorkspaceSettings } from './settings';
declare const _default: ({ client, features, settings, }: {
    settings: WorkspaceSettings;
    client: SdkConfig;
    features: Contracts.FeatureContract[];
}) => Promise<void>;
export default _default;
