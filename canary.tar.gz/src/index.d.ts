import type { FeatureContract } from '@faslh/compiler/contracts';
import type { Extension, WorkspaceSettings } from '@january/extensions';
export interface JanuaryConfig {
    formatGeneratedCode?: boolean;
    tsconfigName?: string;
    bundle?: boolean;
    fs?: {
        cwd?: string;
        output?: string;
    };
    extensions: Extension[];
}
export declare function defineConfig(config: JanuaryConfig): Promise<{
    features: FeatureContract[];
}>;
export declare function generate(settings: WorkspaceSettings, extensions?: Extension[]): Promise<{
    concreteStructure: {
        features: FeatureContract[];
    };
    references: string;
}>;
export * from './esbuild-plugin';
