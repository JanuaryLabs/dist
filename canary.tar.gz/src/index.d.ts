import * as morph from 'ts-morph';
import type { Contracts } from '@faslh/compiler/contracts';
import type { Extension } from '@january/extensions';
import { type SecurityScheme } from './client/sdk';
import { type WorkspaceSettings } from './settings';
export declare function defineConfig(config: {
    formatGeneratedCode?: boolean;
    client?: {
        /**
         * The name of the sdk client
         * @default 'Client'
         */
        name?: string;
        options?: Record<string, any>;
        securityScheme?: SecurityScheme;
        emptyBodyAsNull?: boolean;
        stripBodyFromGetAndHead?: boolean;
    };
    extensions: Extension[];
}): Promise<{
    imports: string[];
    policies: {
        filePath: string;
        structure: (string | {
            kind: morph.StructureKind;
            isTypeOnly: boolean;
            moduleSpecifier: string;
            defaultImport: string | undefined;
            namedImports: import("@january/sdk/parser").Checker.NamedImport[];
            namespaceImport: string | undefined;
        })[];
    }[];
    features: Contracts.FeatureContract[];
}>;
export declare function generate(settings: WorkspaceSettings, extensions?: Extension[]): Promise<{
    imports: string[];
    policies: {
        filePath: string;
        structure: (string | {
            kind: morph.StructureKind;
            isTypeOnly: boolean;
            moduleSpecifier: string;
            defaultImport: string | undefined;
            namedImports: import("@january/sdk/parser").Checker.NamedImport[];
            namespaceImport: string | undefined;
        })[];
    }[];
    features: Contracts.FeatureContract[];
}>;
