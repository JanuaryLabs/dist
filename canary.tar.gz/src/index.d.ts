import './lib/setup';
import type { Extension } from '@january/extensions';
export interface WorkspaceSettings {
    runtime: string;
    cwd: string;
    /**
     * The directory where the output files will be generated relative to the cwd
     */
    outputDir: string;
}
export declare function defineConfig(config: {
    extensions: Extension[];
}): Promise<void>;
export declare function generate(settings: WorkspaceSettings, extensions?: Extension[]): Promise<{
    path: import("@ts-morph/common").StandardizedFilePath;
    content: string;
}[]>;
