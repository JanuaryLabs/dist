import * as morph from 'ts-morph';
import type { FeatureContract } from '@faslh/compiler/contracts';
import type { Extension, WorkspaceSettings } from '@january/extensions';
export declare function defineConfig(config: {
    formatGeneratedCode?: boolean;
    tsconfigName?: string;
    bundle?: boolean;
    fs?: {
        cwd?: string;
        output?: string;
    };
    extensions: Extension[];
}): Promise<{
    policies: {
        displayName: string;
        fileName: string;
        readonly filePath: string;
        structure: (string | {
            kind: morph.StructureKind;
            isTypeOnly: boolean;
            moduleSpecifier: string;
            defaultImport: string | undefined;
            namedImports: import("@january/parser").Checker.NamedImport[];
            namespaceImport: string | undefined;
        })[];
    }[];
    features: FeatureContract[];
}>;
export declare function generate(settings: WorkspaceSettings, extensions?: Extension[]): Promise<{
    concreteStructure: {
        policies: {
            displayName: string;
            fileName: string;
            readonly filePath: string;
            structure: (string | {
                kind: morph.StructureKind;
                isTypeOnly: boolean;
                moduleSpecifier: string;
                defaultImport: string | undefined;
                namedImports: import("@january/parser").Checker.NamedImport[];
                namespaceImport: string | undefined;
            })[];
        }[];
        features: FeatureContract[];
    };
    references: string;
}>;
