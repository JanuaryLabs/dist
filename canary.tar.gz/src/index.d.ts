import type { Contracts } from '@faslh/compiler/contracts';
import type { Extension } from '@january/extensions';
export interface WorkspaceSettings {
    runtime: string;
    cwd: string;
    /**
     * The directory where the output files will be generated relative to the cwd
     */
    outputDir: string;
    userExtDir: string;
    /**
     * If true, the generated code will be formatted using prettier
     */
    formatGeneratedCode?: boolean;
}
export declare function defineConfig(config: {
    formatGeneratedCode?: boolean;
    extensions: Extension[];
}): Promise<{
    imports: string[];
    policies: {
        filePath: string;
        structure: string[];
    }[];
    features: Contracts.FeatureContract[];
}>;
export declare function generate(settings: WorkspaceSettings, extensions?: Extension[]): Promise<{
    imports: string[];
    policies: {
        filePath: string;
        structure: string[];
    }[];
    features: Contracts.FeatureContract[];
}>;
