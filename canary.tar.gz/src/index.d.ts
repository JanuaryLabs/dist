import './lib/setup';
import type { Extension } from '@january/extensions';
export declare const BASIC_EXTENSIONS: {
    core: {};
    hono: {};
    postgresql: {};
};
export interface JanuaryConfig {
    runtime: string;
    cwd: string;
    /**
     * The directory where the output files will be generated relative to the cwd
     */
    outputDir: string;
}
export declare function defineConfig(config: {
    extensions: Extension[];
}): Promise<void>;
export declare function generate(config: JanuaryConfig): Promise<{
    path: import("@ts-morph/common").StandardizedFilePath;
    content: string;
}[]>;
