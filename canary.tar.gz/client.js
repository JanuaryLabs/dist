import { createRequire } from 'module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// libs/sdk/parser/src/index.ts
var src_exports = {};
__export(src_exports, {
  Checker: () => Checker,
  checker: () => checker,
  getExports: () => getExports,
  legacy_parse: () => legacy_parse,
  parse: () => parse,
  parseCode: () => parseCode,
  resolveCallExpression: () => resolveCallExpression
});
import { readFileSync } from "fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
async function getExports(code) {
  const ast = await parseCode(code);
  if (!ast) {
    return [];
  }
  return ast.body.filter(isExportItem);
}
var checker, Checker, isWorker, exportTypes;
var init_src = __esm({
  "libs/sdk/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression2(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression2;
      __name(isCallExpression2, "isCallExpression");
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      __name(isKeyValueProperty, "isKeyValueProperty");
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      __name(isNullLiteral, "isNullLiteral");
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      __name(isIdentifier, "isIdentifier");
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      __name(isMemberExpression, "isMemberExpression");
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isCallExpression2(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression2;
      __name(isCallExpression2, "isCallExpression");
      function isObjectExpression(value) {
        return !isCallExpression2(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(Checker || (Checker = {}));
    isWorker = /* @__PURE__ */ __name(() => {
      return typeof global.importScripts === "function";
    }, "isWorker");
    __name(isRecord, "isRecord");
    __name(isSpan, "isSpan");
    __name(adjustOffsetOfAst, "adjustOffsetOfAst");
    __name(parseCode, "parseCode");
    __name(legacy_parse, "legacy_parse");
    __name(parse, "parse");
    __name(getImports, "getImports");
    __name(resolveAsExpression, "resolveAsExpression");
    __name(resolveCallExpression, "resolveCallExpression");
    __name(resolveUnaryExpression, "resolveUnaryExpression");
    __name(resolveArrayExpression, "resolveArrayExpression");
    __name(resolveObjectExpression, "resolveObjectExpression");
    __name(resolveMemberExpression, "resolveMemberExpression");
    exportTypes = [
      "ExportAllDeclaration",
      "ExportDeclaration",
      "ExportDefaultDeclaration",
      "ExportDefaultExpression",
      "ExportNamedDeclaration",
      "ImportDeclaration"
    ];
    __name(isExportItem, "isExportItem");
    __name(getExports, "getExports");
  }
});

// libs/utils/src/lib/utils.ts
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        const canRetry = operation.retry(error);
        if (!canRetry) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config.accessor(item)]: config.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && !Array.isArray(obj) && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
function msToNs(ms) {
  return ms * 1e6;
}
__name(msToNs, "msToNs");
function nsToMs(nano) {
  return parseInt(typeof nano === "number" ? String(nano) : nano, 10) / 1e6;
}
__name(nsToMs, "nsToMs");
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input, sub) {
  const index = input.indexOf(sub);
  if (index === -1) {
    return input;
  }
  return input.slice(sub.length);
}
__name(substring, "substring");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor2) {
    return visitor2.visitArg(this);
  }
  toLiteral(visitor2) {
    return `${this.name.toLiteral(visitor2)}: ${this.value.toLiteral(visitor2)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor2) {
    return visitor2.visitCall(this);
  }
  toLiteral(visitor2) {
    return `${this.name.toLiteral(visitor2)}(${this.args.map((arg) => arg.toLiteral(visitor2)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor2) {
    return visitor2.visitPropertyAccess(this);
  }
  toLiteral(visitor2) {
    return `${this.name.toLiteral(visitor2)}.${this.expression.toLiteral(
      visitor2
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor2) {
    return visitor2.visitBinary(this);
  }
  toLiteral(visitor2) {
    return `${this.left.toLiteral(visitor2)} ${this.operator.toLiteral(
      visitor2
    )} ${this.right.toLiteral(visitor2)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor2) {
    return visitor2.visitNamespace(this);
  }
  toLiteral(visitor2) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor2)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor2) {
    return visitor2.visitIdentifier(this);
  }
  toLiteral(visitor2) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor2) {
    return visitor2.visitStringLiteral(this);
  }
  toLiteral(visitor2) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor2 = new SqliteVisitor();
  return visitor2.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor2 = new TypeormVisitor();
  return visitor2.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor2 = new SimpleVisitor();
  return visitor2.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor2 = new RuleDecomposerVisitor();
  return visitor2.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  __name(whatIsParserImport, "whatIsParserImport");
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}
__name(formatCode, "formatCode");

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";
var BrowserLookupFs = class {
  static {
    __name(this, "BrowserLookupFs");
  }
  #lookupModules = /* @__PURE__ */ new Set();
  exists(path) {
    return localforage.getItem(path).then((item) => !!item).catch(() => false);
  }
  moduleExists(sourceData) {
    return this.exists(`package:${sourceData.package}`);
  }
  getFiles(sourceData) {
    return localforage.getItem(`files:${sourceData.package}`).then((files) => files || []).catch(() => []);
  }
  getFileContent(path) {
    return localforage.getItem(path).then((item) => item);
  }
  getPackageJson(sourceData) {
    return localforage.getItem(`package:${sourceData.package}`).then((item) => item);
  }
  mapFiles(files) {
    return files.map((file) => ({
      originalFile: file,
      relativeFile: file
    }));
  }
  lock(source) {
    this.#lookupModules.add(source);
  }
  isLocked(source) {
    return this.#lookupModules.has(source);
  }
};

// libs/playground/package-installer/src/lib/parser.ts
import { dirname, join as join2 } from "path";
function coercePackageJson(packageJson) {
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.peerDependencies = packageJson.peerDependencies || {};
  return packageJson;
}
__name(coercePackageJson, "coercePackageJson");
function makeFileUri(specifier, fileName) {
  return `file:///node_modules/${specifier}/${fileName}`;
}
__name(makeFileUri, "makeFileUri");
function parseSpecifer(specifier) {
  const [moduleName, version] = specifier.split("@").filter(Boolean);
  return {
    moduleName,
    version: version === "*" ? "latest" : version
  };
}
__name(parseSpecifer, "parseSpecifer");
function normalizeImport(typesUrl, relativeImport) {
  const url = new URL(typesUrl);
  const relativeImportPathname = join2(dirname(url.pathname), relativeImport);
  return new URL(relativeImportPathname, url.origin).href;
}
__name(normalizeImport, "normalizeImport");
function cleanText(text) {
  return text.replace("export {}", "").replaceAll("export function", "export declare function").replaceAll("export const", "export declare const");
}
__name(cleanText, "cleanText");
async function fetchDts(typesUrl) {
  const result = {
    error: false,
    loaded: false,
    text: ""
  };
  try {
    const response = await fetch(typesUrl);
    if (response.ok) {
      const text = await response.text();
      if (text.includes("[Package Error]")) {
        throw new Error("Package Error");
      }
      result.text = cleanText(text);
      result.loaded = true;
    } else {
      result.error = true;
    }
  } catch (error) {
    result.error = true;
    result.loaded = false;
  }
  return result;
}
__name(fetchDts, "fetchDts");
function parseSource(source) {
  let index = 0;
  const tokens = [];
  while (index < source.length) {
    switch (source[index]) {
      case "@":
        {
          let subindex = index + 1;
          while (subindex < source.length && source[subindex] !== "/") {
            subindex++;
          }
          tokens.push({
            type: "at",
            value: source.slice(index + 1, subindex)
          });
          index = subindex;
        }
        break;
      default:
        {
          let lastToken = tokens[tokens.length - 1];
          if (!lastToken || lastToken.type !== "string") {
            lastToken = {
              type: "string",
              value: ""
            };
            tokens.push(lastToken);
          }
          lastToken.value += source[index];
          index++;
        }
        break;
    }
  }
  if (tokens[0].type === "at") {
    tokens[0].type = "scope";
    tokens[1].type = "package";
    if (tokens[2]) {
      tokens[2].type = "version";
    }
  }
  if (tokens[0].type === "string") {
    tokens[0].type = "package";
    if (tokens[1]) {
      tokens[1].type = "version";
    }
  }
  const moduleName = (tokens.find((x) => x.type === "package")?.value || "").replace("/", "");
  const version = tokens.find((x) => x.type === "version")?.value || "latest";
  const scope = tokens.find((x) => x.type === "scope")?.value;
  const file = tokens.find((x) => x.type === "string")?.value;
  return {
    moduleName,
    version,
    scope,
    package: `${scope ? `@${scope}/` : ""}${moduleName}`,
    full: `${scope ? `@${scope}/` : ""}${moduleName}@${version}`,
    file
  };
}
__name(parseSource, "parseSource");
function sourceDataToString(source) {
  return `${source.scope ? `${source.scope}/` : ""}${source.moduleName}@${source.version}`;
}
__name(sourceDataToString, "sourceDataToString");

// libs/playground/package-installer/src/lib/deps-install-manager.ts
import { basename, dirname as dirname2, extname, join as join3, relative } from "path";
var PackageExports = class {
  constructor(pkg) {
    this.pkg = pkg;
  }
  static {
    __name(this, "PackageExports");
  }
  #extractTypes(exportConfig) {
    if (Array.isArray(exportConfig)) {
      return this.#extractTypes(
        exportConfig.filter((it) => typeof it === "string")[0]
      );
    }
    if (typeof exportConfig === "object") {
      if (typeof exportConfig?.types === "string") {
        return this.#extractTypes(exportConfig.types);
      }
      if (typeof exportConfig?.default === "string") {
        return this.#extractTypes(exportConfig?.default);
      }
    }
    if (typeof exportConfig === "string") {
      return fixTypeExportName(exportConfig);
    }
    return null;
  }
  #correctEndpoint(endpoint) {
    if (typeof endpoint === "string") {
      return fixTypeExportName(endpoint);
    }
    return this.#extractTypes(endpoint);
  }
  #tryFiles(index) {
    if (!index.endsWith("index.d.ts")) {
      return this.pkg.files?.find((it) => it.endsWith("index.d.ts")) || index;
    }
    return index;
  }
  formatExports() {
    const exports = this.mainExport();
    const deleteKeys = [
      (it) => it.includes("*"),
      (it) => it.includes("production"),
      (it) => it.includes("development"),
      (it) => it.includes("package.json"),
      (it) => it.includes("default"),
      (it) => it.includes("require"),
      (it) => it.includes("import"),
      (it) => it === ".",
      (it) => it === "./",
      (it) => it === "/"
    ];
    const cleanedExports = Object.fromEntries(
      Object.entries(this.pkg.exports).filter(
        ([endpoint]) => !deleteKeys.some((x) => x(endpoint))
      )
    );
    const formattedEndpoints = Object.fromEntries(
      Object.entries(cleanedExports).map(([endpoint, exports2]) => [
        endpoint,
        {
          types: this.#correctEndpoint(exports2) || // use the endpoint as the type as last resort
          fixTypeExportName(endpoint)
        }
      ])
    );
    return {
      ...exports,
      ...formattedEndpoints
    };
  }
  mainExport() {
    if (!this.pkg.exports) {
      return {
        ".": {
          types: this.#tryFiles(
            fixTypeExportName(
              this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
            )
          )
        }
      };
    }
    if (typeof this.pkg.exports === "string") {
      return {
        ".": {
          types: this.#tryFiles(fixTypeExportName(this.pkg.exports))
        }
      };
    }
    return {
      ".": {
        types: this.#correctEndpoint(this.pkg.exports["."]) || this.#tryFiles(
          fixTypeExportName(
            this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
          )
        )
      }
    };
  }
};
var nodeTypes = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
var Resolver = class {
  constructor(pkgKeeper, keeper, registries) {
    this.pkgKeeper = pkgKeeper;
    this.keeper = keeper;
    this.registries = registries;
  }
  static {
    __name(this, "Resolver");
  }
  async resolve(source) {
    if (nodeTypes.includes(source) || nodeTypes.some((it) => `node:${it}` === source) || nodeTypes.includes(`node:${source}`) || source.startsWith("@extensions")) {
      return null;
    }
    console.log("Resolving => ", source);
    const info = {
      deps: []
    };
    const resolutions$ = [];
    const pkg = await this.#packageJson(source).catch((error) => null);
    if (pkg === null) {
      console.log(`Resolution stopped: package.json not found for ${source}`);
      return null;
    }
    if (!pkg) {
      console.log(`Resolution stopped: missing package.json for ${source}`);
      return null;
    }
    const sourceData = parseSource(source);
    if (sourceData.version === "latest") {
      source = sourceDataToString({
        ...sourceData,
        version: pkg.version
      });
    }
    const recorder = createRecorder({ label: source });
    for (const [specifier, version] of [
      ...Object.entries(pkg.dependencies ?? {}),
      ...Object.entries(pkg.peerDependencies ?? {})
    ]) {
      const source2 = `${specifier}@${version}`;
      resolutions$.push(async () => {
        info.deps.push(await this.resolve(source2));
      });
    }
    const endpoints = [];
    for (const [secondaryEndpoint, exportedModule] of Object.entries(
      pkg.exports
    )) {
      resolutions$.push(async () => {
        const secondaryEndpointSource = join3(source, secondaryEndpoint);
        console.log("Resolving secondary", secondaryEndpointSource);
        await this.#fetch(
          secondaryEndpointSource,
          join3(source, exportedModule.types)
        ).then((r) => {
          if (secondaryEndpoint === "." && r.loaded) {
            info.resolved = true;
          }
        });
        endpoints.push({
          source: secondaryEndpointSource,
          typePath: exportedModule.types,
          typeSource: join3(source, exportedModule.types),
          name: secondaryEndpoint
        });
      });
    }
    info.source = source;
    info.endpoints = endpoints;
    await Promise.all(
      resolutions$.map(
        (it) => it()
        //   .catch((error) => {
        //   console.error(error);
        //   throw error;
        // }),
        //   .catch((error) => {
        //   console.log(`Failed to resolve ${source} due to`);
        //   console.error(error);
        // }),
      )
    );
    recorder.end();
    console.log("Resolved", source);
    return info;
  }
  async #resolveRelativeImports(fileContent, source) {
    const exports = await getFileExports(
      fileContent.replaceAll("export const", "declare const")
    );
    const types$ = exports.map(async (exportSepecifier) => {
      const maybeDeps = !exportSepecifier.startsWith(".");
      if (maybeDeps) {
        console.log("Resolving relative deps", exportSepecifier);
        const isDeps = await this.resolve(exportSepecifier).catch(() => null);
        if (isDeps?.resolved) {
          return null;
        }
      }
      console.log("Resolving relative file", exportSepecifier);
      const relativeExportSource = join3(source, exportSepecifier);
      const relativeExportTypeExport = fixTypeExportName(relativeExportSource);
      const entry = await this.#entry(relativeExportSource);
      entry.path = exportSepecifier;
      if (entry.loaded) {
        return null;
      }
      if (entry.error || entry.loading) {
        return null;
      }
      return this.#fetch(relativeExportSource, relativeExportTypeExport);
    });
    return Promise.all(types$);
  }
  async #fetch(source, typeExport) {
    const entry = await this.#entry(source);
    if (entry.loaded) {
      console.log(`Already loaded ${source}`);
      return entry;
    }
    if (entry.error) {
      console.log(`Already errored ${source}`);
      return entry;
    }
    if (entry.loading) {
      console.log(`Already loading ${source}`);
      return entry;
    }
    entry.loading = true;
    entry.loaded = false;
    const registries = this.registries.slice(0);
    while (!entry.loaded) {
      const registry = registries.shift();
      if (!registry) {
        break;
      }
      const result = await registry.resolve(typeExport);
      if (result.loaded) {
        entry.loaded = true;
        entry.text = result.text;
        await this.keeper.set(source, entry);
        break;
      }
    }
    entry.typeExport = typeExport;
    entry.loading = false;
    if (entry.loaded) {
      const entries = await this.#resolveRelativeImports(
        entry.text,
        dirname2(typeExport)
      );
      entry.related = entries.filter(notNullOrUndefined);
    }
    entry.error = entry.loaded === false;
    return entry;
  }
  async #packageJson(source) {
    let pkg = await this.pkgKeeper.get(source).catch((error) => {
      console.error(error);
      return null;
    });
    if (pkg === null) {
      console.log(`Using cached package ${source}`);
      return pkg;
    }
    if (!pkg) {
      const registries = this.registries.slice(0);
      while (!pkg) {
        const registry = registries.shift();
        if (!registry) {
          break;
        }
        pkg = await registry.packageJson(source).catch(() => null);
      }
      await this.pkgKeeper.set(source, pkg || null);
    }
    if (!pkg) {
      throw new Error(`Failed to resolve package ${source}`);
    }
    pkg.dependencies = pkg.dependencies || {};
    pkg.devDependencies = pkg.devDependencies || {};
    pkg.peerDependencies = pkg.peerDependencies || {};
    const packageExports = new PackageExports(pkg);
    pkg.exports = packageExports.formatExports();
    pkg.dependencies = Object.fromEntries(
      Object.entries(pkg.dependencies).map(([specifier, version]) => {
        if (pkg.devDependencies && pkg.devDependencies[`@types/${specifier}`]) {
          return [
            `@types/${specifier}`,
            pkg.devDependencies[`@types/${specifier}`]
          ];
        }
        return [specifier, version];
      })
    );
    return pkg;
  }
  async #entry(source) {
    const inCache = await this.keeper.get(source);
    if (inCache) {
      return inCache;
    }
    const entry = {
      loaded: false,
      source,
      text: "",
      loading: false,
      typeExport: "",
      related: [],
      path: ""
    };
    return entry;
  }
  async #flatEntry(entry, basePath, seed) {
    for (const endpointEntry of (await this.#entry(entry.source)).related) {
      if (!endpointEntry.loaded) {
        continue;
      }
      seed.push({
        path: join3(
          dirname2(
            join3(
              basePath,
              relative(dirname2(entry.typeSource), endpointEntry.source)
            )
          ),
          basename(endpointEntry.typeExport)
        ),
        content: endpointEntry.text,
        loaded: endpointEntry.loaded
      });
      for (const nestedEntry of endpointEntry.related) {
        seed.push({
          path: join3(
            dirname2(
              join3(
                basePath,
                relative(dirname2(entry.typeSource), nestedEntry.source)
              )
            ),
            basename(nestedEntry.typeExport)
          ),
          content: nestedEntry.text,
          loaded: nestedEntry.loaded
        });
        await this.#flatEntry(
          {
            source: nestedEntry.source,
            typeSource: nestedEntry.typeExport
          },
          join3(basePath, nestedEntry.path),
          seed
        );
      }
    }
  }
  async flatten(info, basePath, seed) {
    for (const endpoint of info.endpoints) {
      const secondaryPath = join3(basePath, endpoint.name);
      await this.#flatEntry(endpoint, secondaryPath, seed);
      const entry = await this.#entry(endpoint.source);
      seed.push({
        path: join3(secondaryPath, basename(endpoint.typePath)),
        content: entry.text,
        loaded: entry.loaded
      });
    }
    for (const deps of info.deps) {
      if (!deps) {
        continue;
      }
      const depsSourceData = parseSource(deps.source);
      await this.flatten(
        deps,
        join3(basePath, "node_modules", depsSourceData.package),
        seed
      );
    }
  }
};
async function getFileExports(content) {
  const isNodejs = typeof process !== "undefined";
  const exports = isNodejs ? await Promise.resolve().then(() => (init_src(), src_exports)).then(
    ({ getExports: getExports2 }) => getExports2(content)
  ) : await runWorker("/morph/parser.worker.js", {
    type: "getExports",
    payload: content
  });
  return removeDuplicates(
    exports.filter(
      (it) => it.type === "ExportAllDeclaration" || it.type === "ExportNamedDeclaration" || it.type === "ImportDeclaration"
    ).map((it) => it.source?.value).filter(notNullOrUndefined),
    (it) => it
  );
}
__name(getFileExports, "getFileExports");
function fixTypeExportName(name) {
  if (extname(name)) {
    name = name.replace(".d.ts", "").replace(".ts", "").replace(".js", "");
  }
  return `${name}.d.ts`;
}
__name(fixTypeExportName, "fixTypeExportName");

// libs/modern/src/lib/module-lookup.ts
var nodeTypes2 = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
async function lookupModule(source, fs, options) {
  const sourceData = parseSource(source);
  if (nodeTypes2.includes(sourceData.package) || nodeTypes2.some((it) => `node:${it}` === sourceData.package) || nodeTypes2.includes(`node:${sourceData.package}`) || source.startsWith("@extensions")) {
    console.log(`Source ${source} is a node type`);
    return;
  }
  if (fs.isLocked(source)) {
    return;
  }
  fs.lock(source);
  if (!await fs.moduleExists(sourceData)) {
    console.log(`Source ${source} not found`);
    const installed = await options.onMissingPackage(source, sourceData);
    if (!installed) {
      return;
    }
  }
  const packageJson = await fs.getPackageJson(sourceData);
  const files = await fs.getFiles(sourceData);
  await options.onFiles(sourceData, packageJson, files);
  await options.onPackageJson(sourceData, packageJson);
  await lookupPackage(packageJson, fs, options);
}
__name(lookupModule, "lookupModule");
async function lookupPackage(packageJson, fs, options) {
  coercePackageJson(packageJson);
  for (const depKey of ["dependencies", "peerDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      await lookupModule(depsName, fs, options);
    }
  }
  for (const depKey of ["devDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      if (depsName.startsWith("@types/")) {
        await lookupModule(depsName, fs, options);
      }
    }
  }
}
__name(lookupPackage, "lookupPackage");

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";
var octokit = /* @__PURE__ */ __name((token) => import("@octokit/core").then(({ Octokit }) => new Octokit({ auth: token })), "octokit");
async function createEmptySecret(token, repositoryName, name) {
  const [owner, repo] = repositoryName.split("/");
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  try {
    await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
      owner,
      repo,
      secret_name: name
    });
    return;
  } catch (error) {
    const _error = error;
    if ("documentation_url" in _error) {
      if (_error.status !== 404) {
        throw error;
      }
    }
  }
  const key = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/public-key", {
    owner,
    repo
  });
  const binkey = sodium.from_base64(
    key.data.key,
    sodium.base64_variants.ORIGINAL
  );
  const binsec = sodium.from_string(" ");
  const encBytes = sodium.crypto_box_seal(binsec, binkey);
  const output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  await (await octokit(token)).request("PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
    owner,
    repo,
    secret_name: name,
    encrypted_value: output,
    key_id: key.data.key_id
  });
}
__name(createEmptySecret, "createEmptySecret");
async function createRepoistory(token, repositoryName, organizationId, workspaceId, projectId) {
  try {
    const result = await (await octokit(token)).request("POST /user/repos", {
      name: repositoryName,
      description: "January generated repository.",
      gitignore_template: "Node",
      private: true,
      auto_init: false,
      request: {
        projectId
      },
      homepage: "https://january.sh"
      // TODO: it should be user server or user local development server (january ones)
    });
    return {
      id: result.data.id,
      name: result.data.full_name
    };
  } catch (error) {
    if (error?.response?.data) {
      const _error = error.response;
      const [firstError] = _error.errors ?? [];
      if (firstError && firstError.code === "custom" && firstError.field === "name") {
        throw new Error(
          "Repository already exists on this account. Please change the project name and try again."
        );
      }
    }
    throw error;
  }
}
__name(createRepoistory, "createRepoistory");
async function triggerDeploy(token, repositoryName, inputs = {}) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request(
    "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
    {
      owner,
      repo,
      // TODO: we should get the installed hosting extension and get the workflow id from it
      workflow_id: "deploy.yml",
      ref: "main",
      inputs
    }
  );
}
__name(triggerDeploy, "triggerDeploy");
async function deleteRepository(token, repositoryName) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request("DELETE /repos/{owner}/{repo}", {
    owner,
    repo
  });
}
__name(deleteRepository, "deleteRepository");
async function listWorkflows(token, repositoryName, workflowFileName) {
  const [owner, repo] = repositoryName.split("/");
  const client = await octokit(token);
  const workflow = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  const run = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  return { workflow, run };
}
__name(listWorkflows, "listWorkflows");
async function getWorkflowRun(token, repositoryName, workflowFileName, sha) {
  const [owner, repo] = repositoryName.split("/");
  const result = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs", {
    owner,
    repo,
    workflow_id: workflowFileName,
    head_sha: sha,
    branch: "main",
    exclude_pull_requests: true
  });
  const run = result.data.workflow_runs[0];
  if (!run) {
    return {
      run: {
        status: "queued",
        conclusion: null
      },
      jobs: []
    };
  }
  const runJobs = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs", {
    owner,
    repo,
    run_id: run.id
  });
  return {
    run,
    jobs: runJobs.data.jobs.map((it) => ({
      id: it.id,
      name: it.name,
      status: it.status,
      conclusion: it.conclusion,
      steps: (it.steps ?? []).map((step) => ({
        id: `${step.name}-${step.number}-${step.completed_at ?? 0}`,
        name: step.name,
        status: step.status,
        conclusion: step.conclusion,
        elapsed: step.completed_at && step.started_at ? differenceInSeconds(
          new Date(step.completed_at),
          new Date(step.started_at)
        ) : null
      }))
    }))
  };
}
__name(getWorkflowRun, "getWorkflowRun");

// libs/modern/src/index.ts
import { existsSync } from "fs";
import { mkdir, readFile, readdir, writeFile } from "fs/promises";
import { dirname as dirname3, isAbsolute, join as join4 } from "path";
import { tap } from "rxjs/operators";
function debug(tag, enabled = true) {
  const header = /* @__PURE__ */ __name((value, error) => typeof tag === "string" ? tag : tag(value, error), "header");
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}
__name(debug, "debug");
async function writeFiles(dir, contents, format = true) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join4(dir, file);
    await mkdir(dirname3(filePath), { recursive: true });
    const stringContent = typeof content === "string" ? content : JSON.stringify(content);
    await writeFile(
      filePath,
      format ? await formatCode(stringContent, getExt(file)) : stringContent,
      "utf-8"
    );
  }
}
__name(writeFiles, "writeFiles");
function readFolder(path) {
  return existsSync(path) ? readdir(path) : [];
}
__name(readFolder, "readFolder");
async function readPackageJson(dir) {
  const packageJsonPath = join4(dir, "package.json");
  const content = JSON.parse(
    await readFile(packageJsonPath, "utf-8")
  );
  return {
    content,
    write: /* @__PURE__ */ __name((value = content) => writeFile(packageJsonPath, JSON.stringify(value, null, 2), "utf-8"), "write")
  };
}
__name(readPackageJson, "readPackageJson");
function getFile(filePath) {
  return existsSync(filePath) ? readFile(filePath, "utf-8") : Promise.resolve(null);
}
__name(getFile, "getFile");

// libs/canary/src/client/client.txt
var client_default = "import { parse } from 'fast-content-type-parse';\nimport type { Endpoints } from './endpoints';\nimport schemas from './schemas';\nimport { validateOrThrow, ServerError } from './validator';\n\nexport interface RequestInterface<D extends object = object> {\n	/**\n	 * Sends a request based on endpoint options\n	 *\n	 * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'\n	 * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.\n	 */\n	<R extends keyof Endpoints>(\n		route: R,\n		options?: Endpoints[R]['input']\n	): Promise<Endpoints[R]['output']>;\n}\n\nexport async function handleError(response: Response) {\n	try {\n		if (response.status >= 400 && response.status < 500) {\n			const body = (await response.json()) as Record<string, any>;\n			return new ServerError(body.title || body.detail, response.status, body.errors ?? {});\n		}\n		return new Error(\n			`An error occurred while fetching the data. Status: ${response.status}`\n		);\n	} catch (error) {\n		// in case the response is not a json\n		// this is a workaround but we should change\n		// it from the server to always return json\n\n		return error as Error;\n	}\n}\n\nexport async function parseResponse(response: Response) {\n	const contentType = response.headers.get('Content-Type');\n	if (!contentType) {\n		throw new Error('Content-Type header is missing');\n	}\n\n	if (response.status === 204) {\n		return null;\n	}\n\n	const { type } = parse(contentType);\n	switch (type) {\n		case 'application/json':\n			return response.json();\n		case 'text/plain':\n			return response.text();\n		default:\n			throw new Error(`Unsupported content type: ${contentType}`);\n	}\n}";

// libs/canary/src/client/request.txt
var request_default = "type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';\ntype Endpoint = `${Method} ${string}`;\n\nexport function createUrl(base: string, path: string, query: URLSearchParams) {\n	const url = new URL(path, base);\n	url.search = query.toString();\n	return url;\n}\nfunction template(\n	templateString: string,\n	templateVariables: Record<string, any>\n): string {\n	const nargs = /{([0-9a-zA-Z_]+)}/g;\n	return templateString.replace(nargs, (match, key: string, index: number) => {\n		// Handle escaped double braces\n		if (\n			templateString[index - 1] === '{' &&\n			templateString[index + match.length] === '}'\n		) {\n			return key;\n		}\n\n		const result = key in templateVariables ? templateVariables[key] : null;\n		return result === null || result === undefined ? '' : String(result);\n	});\n}\nexport function toRequest<T extends Endpoint>(\n	endpoint: T,\n	input: Record<string, any>,\n	props: {\n		inputHeaders: string[];\n		inputQuery: string[];\n		inputBody: string[];\n		inputParams: string[];\n	},\n	defaults: {\n		baseUrl: string;\n		headers?: Record<string, string>;\n	}\n) {\n	const [method, path] = endpoint.split(' ');\n\n	const headers = new Headers({\n		...defaults?.headers,\n		'Content-Type': 'application/json',\n		Accept: 'application/json',\n	});\n\n	for (const header of props.inputHeaders) {\n		headers.set(header, input[header]);\n	}\n\n	const query = new URLSearchParams();\n	for (const key of props.inputQuery) {\n		const value = input[key];\n		if (value !== undefined) {\n			query.set(key, String(value));\n		}\n	}\n\n	const body = props.inputBody.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const init = {\n		path: template(path, params),\n		method,\n		headers,\n		query,\n		body: JSON.stringify(body),\n	};\n\n	const url = createUrl(defaults.baseUrl, init.path, init.query);\n	return new Request(url, {\n		method: init.method,\n		headers: init.headers,\n		body: method === 'GET' ? undefined : JSON.stringify(body),\n	});\n}\n";

// libs/canary/src/client/validator.txt
var validator_default = "import { z } from 'zod';\n\nexport function validate<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n) {\n	const result = schema.safeParse(input);\n	if (!result.success) {\n		return result.error.flatten((issue) => ({\n			message: issue.message,\n			code: issue.code,\n			fatel: issue.fatal,\n			path: issue.path.join('.'),\n		})).fieldErrors;\n	}\n	return null;\n}\n\nexport class ValidationError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ValidationError';\n		Error.captureStackTrace(this, ValidationError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport class ServerError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public status: number,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ServerError';\n		Error.captureStackTrace(this, ServerError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport function validateOrThrow<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n): asserts input is z.infer<z.ZodObject<T>> {\n	const errors = validate(schema, input);\n	if (errors) {\n		throw new ValidationError('Validation failed', errors);\n	}\n}\n";

// libs/canary/src/client/sdk.ts
import { camelcase as camelcase2 } from "stringcase";
var SchemaEndpoint = class {
  static {
    __name(this, "SchemaEndpoint");
  }
  #imports = [
    `import z from 'zod';`,
    'import type { Endpoints } from "./endpoints";',
    `import { toRequest, createUrl } from './request';`
  ];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation},`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export default {
${this.#endpoints.join("\n")}
}`;
  }
};
var Emitter = class {
  static {
    __name(this, "Emitter");
  }
  #imports = [`import z from 'zod';`];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation};`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export interface Endpoints {
${this.#endpoints.join("\n")}
}`;
  }
};
function generateClientSdk(spec) {
  const emitter = new Emitter();
  const schemas = {};
  const schemasImports = [];
  const schemaEndpoint = new SchemaEndpoint();
  for (const feature of spec.features) {
    const featureSchemaFileName = camelcase2(feature.featureName);
    schemas[featureSchemaFileName] = [`import z from 'zod';`];
    emitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    schemaEndpoint.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    for (const workflow of feature.workflows) {
      const schema = `export const ${workflow.schemaName} = z.object(${toLitObject(
        workflow.inputs,
        (x) => x.schema
      )});`;
      schemas[featureSchemaFileName].push(schema);
      schemasImports.push(
        ...workflow.imports.filter((it) => it.moduleSpecifier === "@extensions/zod").map((it) => (it.namedImports ?? []).map((it2) => it2.name).join(", "))
      );
      const workflowPath = normalizeWorkflowPath({
        // featureName: feature.featureName,
        featureName: "/",
        workflowTag: workflow.tag,
        workflowPath: workflow.trigger.path
      });
      const endpoint = `${workflow.trigger.method.toUpperCase()} ${workflowPath}`;
      const schemaRef = `${featureSchemaFileName}.${workflow.schemaName}`;
      const input = `z.infer<typeof ${schemaRef}>`;
      const output = pascalcase(workflow.name);
      emitter.addImport(
        `import {${output}} from './outputs/${workflow.name}';`
      );
      emitter.addEndpoint(endpoint, `{input: ${input}, output: ${output}}`);
      const inputHeaders = [];
      const inputQuery = [];
      const inputBody = [];
      const inputParams = [];
      for (const [name, prop] of Object.entries(workflow.inputs)) {
        if (prop.source === "headers") {
          inputHeaders.push(`"${name}"`);
        } else if (prop.source === "query") {
          inputQuery.push(`"${name}"`);
        } else if (prop.source === "body") {
          inputBody.push(`"${name}"`);
        } else if (prop.source === "path") {
          inputParams.push(`"${name}"`);
        } else if (prop.source === "internal") {
          continue;
        } else {
          throw new Error(
            `Unknown source ${prop.source} in ${name} ${JSON.stringify(
              prop
            )} in ${workflow.name}`
          );
        }
      }
      schemaEndpoint.addEndpoint(
        endpoint,
        `{
      schema: ${schemaRef},
      toRequest(input: Endpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
        const endpoint = '${endpoint}';
          return toRequest(endpoint, input, {
          inputHeaders: [${inputHeaders}],
          inputQuery: [${inputQuery}],
          inputBody: [${inputBody}],
          inputParams: [${inputParams}],
        }, init);
        },
      }`
      );
    }
  }
  const specOptions = {
    ...spec.options ?? {},
    baseUrl: { schema: "z.string().url()" }
  };
  const clientName = `${spec.name ?? "Client"}`;
  const defaultHeaders = spec.securityScheme ? `{Authorization: \`${titlecase(spec.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}` : {};
  return {
    ...Object.fromEntries(
      Object.entries(schemas).map(([key, value]) => [
        `inputs/${key}.ts`,
        [
          schemasImports.length ? `import {${removeDuplicates(schemasImports, (it) => it)}} from '../zod';` : "",
          ...value
        ].join("\n")
      ])
    ),
    "index.ts": `
export * from './endpoints';
export * from './request';
export * from './schemas';
export * from './client';
export * from './validator';
export * from './sdk';
`,
    "sdk.ts": `
import z from 'zod';
import type { Endpoints } from './endpoints';
import schemas from './schemas';
import { validateOrThrow } from './validator';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${toLitObject(specOptions, (x) => x.schema)});
      type ${clientName}Options = z.infer<typeof optionsSchema>;
    export class ${clientName} {

      constructor(public options: ${clientName}Options) {}

async request<E extends keyof Endpoints>(
		endpoint: E,
		input: Endpoints[E]['input']
	): Promise<readonly [Endpoints[E]['output'], Error | null]> {
		try {
			const route = schemas[endpoint];
			validateOrThrow(route.schema, input);
			const response = await fetch(
				route.toRequest(input as never, {
					headers: this.defaultHeaders,
					baseUrl: this.options.baseUrl,
				})
			);

			if (response.ok) {
				const data = await parseResponse(response);
				return [data as Endpoints[E]['output'], null] as const;
			}
			const error = await handleError(response);
			return [null, error] as const;
		} catch (error) {
			return [null, error as Error] as const;
		}
	}

      get defaultHeaders() {
        return ${defaultHeaders}
      }

  setOptions(options: Partial<ServerizeOptions>) {
		for (const key in this.options) {
			if (
				key in options &&
				options[key as keyof ServerizeOptions] !== undefined
			) {
				this.options[key as keyof ServerizeOptions] =
					options[key as keyof ServerizeOptions]!;
			}
		}
	}
    }`,
    "validator.ts": validator_default,
    "client.ts": client_default,
    "request.ts": request_default,
    "schemas.ts": schemaEndpoint.complete(),
    "endpoints.ts": emitter.complete()
  };
}
__name(generateClientSdk, "generateClientSdk");

// libs/canary/src/client/emitter.ts
var typeMappings = {
  DateConstructor: "Date"
};
function deserializeTypes(data) {
  const tokens = [];
  for (const type of data.types) {
    if (type === null || type === void 0) {
      tokens.push("any");
    } else if (typeof type === "string") {
      tokens.push(
        `${typeMappings[type] || type}${data.kind === "array" ? "[]" : ""}`
      );
    } else if ("types" in type) {
      tokens.push(deserializeTypes(type));
    }
  }
  return tokens.join(" | ");
}
__name(deserializeTypes, "deserializeTypes");
function toInterface(contents, serializeSymbol2) {
  const contentMap = {};
  for (const [filePath, models] of Object.entries(contents)) {
    for (const [key, value] of Object.entries(models)) {
      const props = [];
      const isTypeAlias = value[serializeSymbol2];
      if (isTypeAlias) {
        contentMap[filePath] = {
          exports: [key],
          content: `export type ${key} = ${deserializeTypes(value)};`
        };
      } else {
        for (const [prop, data] of Object.entries(value)) {
          const tokens = [prop];
          if (data.optional) {
            tokens.push("?");
          }
          tokens.push(": ");
          tokens.push(deserializeTypes(data));
          props.push(tokens.join(""));
        }
        contentMap[filePath] = {
          exports: [key],
          content: `export interface ${key} {${props.join("\n")}}`
        };
      }
    }
  }
  const imports = Object.values(contentMap).flatMap((it) => it.exports);
  const emits = {};
  for (const [filePath, { content, exports }] of Object.entries(contentMap)) {
    const allButCurrentExports = imports.filter((it) => !exports.includes(it)).map((it) => `import { ${it} } from './${it}';`);
    const fileContent = `${allButCurrentExports.join("\n")}
${content}`;
    emits[filePath] = fileContent;
  }
  return emits;
}
__name(toInterface, "toInterface");

// libs/canary/src/client/serializer.ts
import { dirname as dirname4 } from "path";
import ts from "typescript";
function parseTsConfig(tsconfigPath) {
  const configContent = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
  if (configContent.error) {
    console.error(
      `Failed to read tsconfig file:`,
      ts.formatDiagnosticsWithColorAndContext([configContent.error], {
        getCanonicalFileName: /* @__PURE__ */ __name((path) => path, "getCanonicalFileName"),
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: /* @__PURE__ */ __name(() => ts.sys.newLine, "getNewLine")
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  const parsed = ts.parseJsonConfigFileContent(
    configContent.config,
    ts.sys,
    dirname4(tsconfigPath)
  );
  if (parsed.errors.length > 0) {
    console.error(
      `Errors found in tsconfig.json:`,
      ts.formatDiagnosticsWithColorAndContext(parsed.errors, {
        getCanonicalFileName: /* @__PURE__ */ __name((path) => path, "getCanonicalFileName"),
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: /* @__PURE__ */ __name(() => ts.sys.newLine, "getNewLine")
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  return parsed;
}
__name(parseTsConfig, "parseTsConfig");
var visitor = /* @__PURE__ */ __name((on) => {
  return (node) => {
    if (ts.isReturnStatement(node) && node.expression) {
      if (ts.isCallExpression(node.expression) && node.expression.expression && ts.isPropertyAccessExpression(node.expression.expression)) {
        const propAccess = node.expression.expression;
        if (ts.isIdentifier(propAccess.expression) && propAccess.expression.text === "output") {
          const [ole] = node.expression.arguments;
          if (!ole) {
            return;
          }
          on(ole);
        }
      } else {
        on(node.expression);
      }
    }
    return ts.forEachChild(node, visitor(on));
  };
}, "visitor");
function searchInBlock(name, node, serializer) {
  const contents = {};
  let found = false;
  node.forEachChild((child) => {
    if (ts.isReturnStatement(child) && child.expression && ts.isCallExpression(child.expression) && child.expression.expression && ts.isPropertyAccessExpression(child.expression.expression)) {
      const propAccess = child.expression.expression;
      if (ts.isIdentifier(propAccess.expression) && propAccess.expression.text === "output") {
        const [ole] = child.expression.arguments;
        if (!ole) {
          return;
        }
        found = true;
        contents[name] = serializer.serializeNode(ole);
      }
    }
  });
  return found ? contents : null;
}
__name(searchInBlock, "searchInBlock");
function searchInCommand(sourceFile, serializer) {
  sourceFile.forEachChild((node) => {
    if (ts.isFunctionDeclaration(node) && node.name?.text === "listProjects") {
      node.forEachChild((child) => {
        if (ts.isBlock(child)) {
          const contents = {};
          let found = false;
          visitor((node2) => {
            found = true;
            contents["ListProjectsOutput"] = serializer.serializeNode(node2);
          })(child);
        }
      });
    }
  });
}
__name(searchInCommand, "searchInCommand");
function isCallExpression(node, name) {
  return ts.isCallExpression(node) && node.expression && ts.isIdentifier(node.expression) && node.expression.text === name;
}
__name(isCallExpression, "isCallExpression");
function getPropertyAssignment(node, name) {
  if (ts.isObjectLiteralExpression(node)) {
    return node.properties.filter((prop) => ts.isPropertyAssignment(prop)).find((prop) => prop.name.getText() === name);
  }
  return void 0;
}
__name(getPropertyAssignment, "getPropertyAssignment");
function searchInFeature(sourceFile, serializer) {
  const results = [];
  sourceFile.forEachChild((node) => {
    if (ts.isExportAssignment(node) && isCallExpression(node.expression, "feature")) {
      const [configArg] = node.expression.arguments;
      if (ts.isObjectLiteralExpression(configArg)) {
        const workflows = getPropertyAssignment(configArg, "workflows");
        if (!workflows) {
          return;
        }
        if (ts.isArrayLiteralExpression(workflows.initializer)) {
          workflows.initializer.forEachChild((workflow) => {
            if (isCallExpression(workflow, "workflow")) {
              const [workflowNameArg, workflowConfigArg] = workflow.arguments;
              const name = ts.isStringLiteral(workflowNameArg) ? workflowNameArg.text : "";
              if (!name) {
                return;
              }
              if (ts.isObjectLiteralExpression(workflowConfigArg)) {
                const execute = getPropertyAssignment(
                  workflowConfigArg,
                  "execute"
                );
                if (execute?.initializer) {
                  if (ts.isArrowFunction(execute.initializer)) {
                    if (ts.isBlock(execute.initializer.body)) {
                      const contents = {
                        [name]: {
                          [serializeSymbol]: true,
                          optional: false,
                          types: ["void"]
                        }
                      };
                      visitor((node2) => {
                        contents[name] = serializer.serializeNode(node2);
                      })(execute.initializer.body);
                      results.push(contents);
                    }
                  }
                }
              }
            }
          });
        }
      }
    }
  });
  return results;
}
__name(searchInFeature, "searchInFeature");
var serializeSymbol = Symbol.for("serialize");
function isInterfaceType(type) {
  if (type.isClassOrInterface()) {
    return !!(type.symbol.flags & ts.SymbolFlags.Interface);
  }
  return false;
}
__name(isInterfaceType, "isInterfaceType");
var Serializer = class {
  constructor(program) {
    this.program = program;
    this.checker = program.getTypeChecker();
  }
  static {
    __name(this, "Serializer");
  }
  collector = {};
  checker;
  serializeType(type) {
    if (type.isUnion() || type.isIntersection()) {
      let optional;
      const types = [];
      for (const unionType of type.types) {
        if (optional === void 0) {
          optional = (unionType.flags & ts.TypeFlags.Undefined) !== 0;
          continue;
        }
        types.push(this.serializeType(unionType));
      }
      return {
        [serializeSymbol]: true,
        optional,
        types
      };
    }
    if (this.checker.isArrayLikeType(type)) {
      const [argType] = this.checker.getTypeArguments(type);
      if (!argType) {
        console.warn(
          `No argument type found for ${type.symbol?.name} of ${this.checker.typeToString(type)}`
        );
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: ["any"]
        };
      }
      const typeSymbol = argType.getSymbol();
      if (!typeSymbol) {
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: [this.checker.typeToString(argType)]
        };
      }
      const declaration = typeSymbol.valueDeclaration;
      if (!declaration) {
        return null;
      }
      return {
        kind: "array",
        ...this.serializeNode(declaration)
      };
    }
    if (type.isClass()) {
      const declaration = type.symbol?.valueDeclaration;
      if (!declaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(declaration);
    }
    if (isInterfaceType(type)) {
      const valueDeclaration = type.symbol.valueDeclaration ?? type.symbol.declarations?.[0];
      if (!valueDeclaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(valueDeclaration);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: [this.checker.typeToString(type)]
    };
  }
  serializeNode(node) {
    if (ts.isObjectLiteralExpression(node)) {
      const symbolType = this.checker.getTypeAtLocation(node);
      const props = {};
      for (const symbol of symbolType.getProperties()) {
        const type = this.checker.getTypeOfSymbol(symbol);
        props[symbol.name] = this.serializeType(type);
      }
      return props;
    }
    if (ts.isPropertySignature(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isPropertyDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isInterfaceDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Interface has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertySignature)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isClassDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Class has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertyDeclaration)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isVariableDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      if (!node.type) {
        return "any";
      }
      const type = this.checker.getTypeFromTypeNode(node.type);
      return this.serializeType(type);
    }
    if (ts.isIdentifier(node)) {
      const symbol = this.checker.getSymbolAtLocation(node);
      if (!symbol) {
        console.warn(`No symbol found for ${node.getText()}`);
        return null;
      }
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    if (ts.isAwaitExpression(node)) {
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: ["any"]
    };
  }
};
function serialize(tsconfigPath, features) {
  const tsConfigParseResult = parseTsConfig(tsconfigPath);
  const program = ts.createProgram({
    options: tsConfigParseResult.options,
    rootNames: tsConfigParseResult.fileNames,
    projectReferences: tsConfigParseResult.projectReferences,
    configFileParsingDiagnostics: tsConfigParseResult.errors
  });
  const serializer = new Serializer(program);
  const emits = {};
  for (const feature of features) {
    const sourceFile = program.getSourceFile(feature.path);
    if (!sourceFile) {
      throw new Error(`File not found: ${feature.name}`);
    }
    const result = searchInFeature(sourceFile, serializer);
    const collector = { ...serializer.collector };
    for (const workflow of result) {
      for (const [key, value] of Object.entries(workflow)) {
        collector[key] = value;
      }
    }
    const contents = Object.entries(collector).reduce(
      (acc, [key, value]) => {
        acc[key] = { [key]: value };
        return acc;
      },
      {}
    );
    emits[feature.name] = toInterface(contents, serializeSymbol);
  }
  return emits;
}
__name(serialize, "serialize");
function flattenSerialized(serialized) {
  const outputs = {};
  for (const [featureName, content] of Object.entries(serialized)) {
    for (const [fileName, fileContent] of Object.entries(content)) {
      outputs[
        // join(
        //   basename(featureName).replace(extname(featureName), ''),
        //   `${fileName}.ts`,
        // )
        `${fileName}.ts`
      ] = fileContent;
    }
  }
  return outputs;
}
__name(flattenSerialized, "flattenSerialized");

// libs/canary/src/settings.ts
function createWorkflowSchema(workflow) {
  return Object.entries(workflow.inputs).filter(([key, prop]) => !prop.data?.["standalone"]).reduce(
    (acc, [key, prop]) => ({
      ...acc,
      [key]: {
        schema: prop.data?.["zod"] || "z.any()",
        source: prop.data?.["source"]
      }
    }),
    {}
  );
}
__name(createWorkflowSchema, "createWorkflowSchema");

// libs/canary/src/client.ts
import { join as join5 } from "path";
var client_default2 = /* @__PURE__ */ __name(async ({
  client,
  features,
  settings
}) => {
  const spec = {
    name: client.name,
    options: client.options,
    securityScheme: client.securityScheme,
    features: features.map((feature) => ({
      featureName: feature.displayName,
      workflows: feature.workflows.filter((it) => ["http", "stream"].includes(it.trigger.sourceId)).map((workflow) => ({
        name: workflow.displayName,
        type: workflow.trigger.sourceId,
        imports: workflow.imports,
        schemaName: workflow.schemaName,
        tag: workflow.tag,
        trigger: workflow.trigger.details,
        inputs: createWorkflowSchema(workflow)
      }))
    }))
  };
  await writeFiles(
    join5(settings.outputDir, "client"),
    {
      "package.json": {
        name: spinalcase2(`${spec.name}-api`),
        version: "0.0.0",
        type: "module",
        dependencies: {
          validator: "^13.12.0",
          zod: "^3.23.8",
          "fast-content-type-parse": "^2.0.0"
        },
        exports: {
          ".": "./index.ts",
          "./package.json": "./package.json"
        }
      },
      "zod.ts": await getFile(join5(settings.userExtDir, "zod", "index.ts")),
      ...generateClientSdk(spec)
    },
    false
  );
  const featurePaths = await readFolder(settings.features);
  const serialized = serialize(
    join5(settings.cwd, "tsconfig.json"),
    featurePaths.map((it) => ({
      name: it,
      path: join5(settings.features, it)
    }))
  );
  await writeFiles(
    join5(settings.outputDir, "client", "outputs"),
    flattenSerialized(serialized),
    false
  );
}, "default");
export {
  client_default2 as default
};
//# sourceMappingURL=client.js.map
