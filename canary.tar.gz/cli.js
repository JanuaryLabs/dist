#!/usr/bin/env node
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// node_modules/semver/internal/constants.js
var require_constants = __commonJS({
  "node_modules/semver/internal/constants.js"(exports, module) {
    "use strict";
    var SEMVER_SPEC_VERSION = "2.0.0";
    var MAX_LENGTH = 256;
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || /* istanbul ignore next */
    9007199254740991;
    var MAX_SAFE_COMPONENT_LENGTH = 16;
    var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
    var RELEASE_TYPES = [
      "major",
      "premajor",
      "minor",
      "preminor",
      "patch",
      "prepatch",
      "prerelease"
    ];
    module.exports = {
      MAX_LENGTH,
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_SAFE_INTEGER,
      RELEASE_TYPES,
      SEMVER_SPEC_VERSION,
      FLAG_INCLUDE_PRERELEASE: 1,
      FLAG_LOOSE: 2
    };
  }
});

// node_modules/semver/internal/debug.js
var require_debug = __commonJS({
  "node_modules/semver/internal/debug.js"(exports, module) {
    "use strict";
    var debug3 = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
    };
    module.exports = debug3;
  }
});

// node_modules/semver/internal/re.js
var require_re = __commonJS({
  "node_modules/semver/internal/re.js"(exports, module) {
    "use strict";
    var {
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_LENGTH
    } = require_constants();
    var debug3 = require_debug();
    exports = module.exports = {};
    var re = exports.re = [];
    var safeRe = exports.safeRe = [];
    var src = exports.src = [];
    var t = exports.t = {};
    var R = 0;
    var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
    var safeRegexReplacements = [
      ["\\s", 1],
      ["\\d", MAX_LENGTH],
      [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
    ];
    var makeSafeRegex = /* @__PURE__ */ __name((value) => {
      for (const [token, max] of safeRegexReplacements) {
        value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
      }
      return value;
    }, "makeSafeRegex");
    var createToken = /* @__PURE__ */ __name((name, value, isGlobal) => {
      const safe = makeSafeRegex(value);
      const index = R++;
      debug3(name, index, value);
      t[name] = index;
      src[index] = value;
      re[index] = new RegExp(value, isGlobal ? "g" : void 0);
      safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
    }, "createToken");
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
    createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NUMERICIDENTIFIER]}|${src[t.NONNUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NUMERICIDENTIFIERLOOSE]}|${src[t.NONNUMERICIDENTIFIER]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
    createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
    createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("COERCERTLFULL", src[t.COERCEFULL], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  }
});

// node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS({
  "node_modules/semver/internal/parse-options.js"(exports, module) {
    "use strict";
    var looseOption = Object.freeze({ loose: true });
    var emptyOpts = Object.freeze({});
    var parseOptions = /* @__PURE__ */ __name((options) => {
      if (!options) {
        return emptyOpts;
      }
      if (typeof options !== "object") {
        return looseOption;
      }
      return options;
    }, "parseOptions");
    module.exports = parseOptions;
  }
});

// node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS({
  "node_modules/semver/internal/identifiers.js"(exports, module) {
    "use strict";
    var numeric = /^[0-9]+$/;
    var compareIdentifiers = /* @__PURE__ */ __name((a, b) => {
      const anum = numeric.test(a);
      const bnum = numeric.test(b);
      if (anum && bnum) {
        a = +a;
        b = +b;
      }
      return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
    }, "compareIdentifiers");
    var rcompareIdentifiers = /* @__PURE__ */ __name((a, b) => compareIdentifiers(b, a), "rcompareIdentifiers");
    module.exports = {
      compareIdentifiers,
      rcompareIdentifiers
    };
  }
});

// node_modules/semver/classes/semver.js
var require_semver = __commonJS({
  "node_modules/semver/classes/semver.js"(exports, module) {
    "use strict";
    var debug3 = require_debug();
    var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
    var { safeRe: re, t } = require_re();
    var parseOptions = require_parse_options();
    var { compareIdentifiers } = require_identifiers();
    var SemVer = class _SemVer {
      static {
        __name(this, "SemVer");
      }
      constructor(version, options) {
        options = parseOptions(options);
        if (version instanceof _SemVer) {
          if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
            return version;
          } else {
            version = version.version;
          }
        } else if (typeof version !== "string") {
          throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
        }
        if (version.length > MAX_LENGTH) {
          throw new TypeError(
            `version is longer than ${MAX_LENGTH} characters`
          );
        }
        debug3("SemVer", version, options);
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
        if (!m) {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        this.raw = version;
        this.major = +m[1];
        this.minor = +m[2];
        this.patch = +m[3];
        if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
          throw new TypeError("Invalid major version");
        }
        if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
          throw new TypeError("Invalid minor version");
        }
        if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
          throw new TypeError("Invalid patch version");
        }
        if (!m[4]) {
          this.prerelease = [];
        } else {
          this.prerelease = m[4].split(".").map((id) => {
            if (/^[0-9]+$/.test(id)) {
              const num = +id;
              if (num >= 0 && num < MAX_SAFE_INTEGER) {
                return num;
              }
            }
            return id;
          });
        }
        this.build = m[5] ? m[5].split(".") : [];
        this.format();
      }
      format() {
        this.version = `${this.major}.${this.minor}.${this.patch}`;
        if (this.prerelease.length) {
          this.version += `-${this.prerelease.join(".")}`;
        }
        return this.version;
      }
      toString() {
        return this.version;
      }
      compare(other) {
        debug3("SemVer.compare", this.version, this.options, other);
        if (!(other instanceof _SemVer)) {
          if (typeof other === "string" && other === this.version) {
            return 0;
          }
          other = new _SemVer(other, this.options);
        }
        if (other.version === this.version) {
          return 0;
        }
        return this.compareMain(other) || this.comparePre(other);
      }
      compareMain(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        return compareIdentifiers(this.major, other.major) || compareIdentifiers(this.minor, other.minor) || compareIdentifiers(this.patch, other.patch);
      }
      comparePre(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.prerelease.length && !other.prerelease.length) {
          return -1;
        } else if (!this.prerelease.length && other.prerelease.length) {
          return 1;
        } else if (!this.prerelease.length && !other.prerelease.length) {
          return 0;
        }
        let i = 0;
        do {
          const a = this.prerelease[i];
          const b = other.prerelease[i];
          debug3("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      compareBuild(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        let i = 0;
        do {
          const a = this.build[i];
          const b = other.build[i];
          debug3("build compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      // preminor will bump the version up to the next minor release, and immediately
      // down to pre-release. premajor and prepatch work the same way.
      inc(release, identifier, identifierBase) {
        switch (release) {
          case "premajor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor = 0;
            this.major++;
            this.inc("pre", identifier, identifierBase);
            break;
          case "preminor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor++;
            this.inc("pre", identifier, identifierBase);
            break;
          case "prepatch":
            this.prerelease.length = 0;
            this.inc("patch", identifier, identifierBase);
            this.inc("pre", identifier, identifierBase);
            break;
          case "prerelease":
            if (this.prerelease.length === 0) {
              this.inc("patch", identifier, identifierBase);
            }
            this.inc("pre", identifier, identifierBase);
            break;
          case "major":
            if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
              this.major++;
            }
            this.minor = 0;
            this.patch = 0;
            this.prerelease = [];
            break;
          case "minor":
            if (this.patch !== 0 || this.prerelease.length === 0) {
              this.minor++;
            }
            this.patch = 0;
            this.prerelease = [];
            break;
          case "patch":
            if (this.prerelease.length === 0) {
              this.patch++;
            }
            this.prerelease = [];
            break;
          case "pre": {
            const base = Number(identifierBase) ? 1 : 0;
            if (!identifier && identifierBase === false) {
              throw new Error("invalid increment argument: identifier is empty");
            }
            if (this.prerelease.length === 0) {
              this.prerelease = [base];
            } else {
              let i = this.prerelease.length;
              while (--i >= 0) {
                if (typeof this.prerelease[i] === "number") {
                  this.prerelease[i]++;
                  i = -2;
                }
              }
              if (i === -1) {
                if (identifier === this.prerelease.join(".") && identifierBase === false) {
                  throw new Error("invalid increment argument: identifier already exists");
                }
                this.prerelease.push(base);
              }
            }
            if (identifier) {
              let prerelease = [identifier, base];
              if (identifierBase === false) {
                prerelease = [identifier];
              }
              if (compareIdentifiers(this.prerelease[0], identifier) === 0) {
                if (isNaN(this.prerelease[1])) {
                  this.prerelease = prerelease;
                }
              } else {
                this.prerelease = prerelease;
              }
            }
            break;
          }
          default:
            throw new Error(`invalid increment argument: ${release}`);
        }
        this.raw = this.format();
        if (this.build.length) {
          this.raw += `+${this.build.join(".")}`;
        }
        return this;
      }
    };
    module.exports = SemVer;
  }
});

// node_modules/semver/functions/parse.js
var require_parse = __commonJS({
  "node_modules/semver/functions/parse.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse = /* @__PURE__ */ __name((version, options, throwErrors = false) => {
      if (version instanceof SemVer) {
        return version;
      }
      try {
        return new SemVer(version, options);
      } catch (er) {
        if (!throwErrors) {
          return null;
        }
        throw er;
      }
    }, "parse");
    module.exports = parse;
  }
});

// node_modules/semver/functions/valid.js
var require_valid = __commonJS({
  "node_modules/semver/functions/valid.js"(exports, module) {
    "use strict";
    var parse = require_parse();
    var valid = /* @__PURE__ */ __name((version, options) => {
      const v = parse(version, options);
      return v ? v.version : null;
    }, "valid");
    module.exports = valid;
  }
});

// node_modules/semver/functions/clean.js
var require_clean = __commonJS({
  "node_modules/semver/functions/clean.js"(exports, module) {
    "use strict";
    var parse = require_parse();
    var clean = /* @__PURE__ */ __name((version, options) => {
      const s = parse(version.trim().replace(/^[=v]+/, ""), options);
      return s ? s.version : null;
    }, "clean");
    module.exports = clean;
  }
});

// node_modules/semver/functions/inc.js
var require_inc = __commonJS({
  "node_modules/semver/functions/inc.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var inc = /* @__PURE__ */ __name((version, release, options, identifier, identifierBase) => {
      if (typeof options === "string") {
        identifierBase = identifier;
        identifier = options;
        options = void 0;
      }
      try {
        return new SemVer(
          version instanceof SemVer ? version.version : version,
          options
        ).inc(release, identifier, identifierBase).version;
      } catch (er) {
        return null;
      }
    }, "inc");
    module.exports = inc;
  }
});

// node_modules/semver/functions/diff.js
var require_diff = __commonJS({
  "node_modules/semver/functions/diff.js"(exports, module) {
    "use strict";
    var parse = require_parse();
    var diff = /* @__PURE__ */ __name((version1, version2) => {
      const v1 = parse(version1, null, true);
      const v2 = parse(version2, null, true);
      const comparison = v1.compare(v2);
      if (comparison === 0) {
        return null;
      }
      const v1Higher = comparison > 0;
      const highVersion = v1Higher ? v1 : v2;
      const lowVersion = v1Higher ? v2 : v1;
      const highHasPre = !!highVersion.prerelease.length;
      const lowHasPre = !!lowVersion.prerelease.length;
      if (lowHasPre && !highHasPre) {
        if (!lowVersion.patch && !lowVersion.minor) {
          return "major";
        }
        if (highVersion.patch) {
          return "patch";
        }
        if (highVersion.minor) {
          return "minor";
        }
        return "major";
      }
      const prefix = highHasPre ? "pre" : "";
      if (v1.major !== v2.major) {
        return prefix + "major";
      }
      if (v1.minor !== v2.minor) {
        return prefix + "minor";
      }
      if (v1.patch !== v2.patch) {
        return prefix + "patch";
      }
      return "prerelease";
    }, "diff");
    module.exports = diff;
  }
});

// node_modules/semver/functions/major.js
var require_major = __commonJS({
  "node_modules/semver/functions/major.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var major = /* @__PURE__ */ __name((a, loose) => new SemVer(a, loose).major, "major");
    module.exports = major;
  }
});

// node_modules/semver/functions/minor.js
var require_minor = __commonJS({
  "node_modules/semver/functions/minor.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var minor = /* @__PURE__ */ __name((a, loose) => new SemVer(a, loose).minor, "minor");
    module.exports = minor;
  }
});

// node_modules/semver/functions/patch.js
var require_patch = __commonJS({
  "node_modules/semver/functions/patch.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var patch = /* @__PURE__ */ __name((a, loose) => new SemVer(a, loose).patch, "patch");
    module.exports = patch;
  }
});

// node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS({
  "node_modules/semver/functions/prerelease.js"(exports, module) {
    "use strict";
    var parse = require_parse();
    var prerelease = /* @__PURE__ */ __name((version, options) => {
      const parsed = parse(version, options);
      return parsed && parsed.prerelease.length ? parsed.prerelease : null;
    }, "prerelease");
    module.exports = prerelease;
  }
});

// node_modules/semver/functions/compare.js
var require_compare = __commonJS({
  "node_modules/semver/functions/compare.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compare = /* @__PURE__ */ __name((a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose)), "compare");
    module.exports = compare;
  }
});

// node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS({
  "node_modules/semver/functions/rcompare.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var rcompare = /* @__PURE__ */ __name((a, b, loose) => compare(b, a, loose), "rcompare");
    module.exports = rcompare;
  }
});

// node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS({
  "node_modules/semver/functions/compare-loose.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var compareLoose = /* @__PURE__ */ __name((a, b) => compare(a, b, true), "compareLoose");
    module.exports = compareLoose;
  }
});

// node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS({
  "node_modules/semver/functions/compare-build.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compareBuild = /* @__PURE__ */ __name((a, b, loose) => {
      const versionA = new SemVer(a, loose);
      const versionB = new SemVer(b, loose);
      return versionA.compare(versionB) || versionA.compareBuild(versionB);
    }, "compareBuild");
    module.exports = compareBuild;
  }
});

// node_modules/semver/functions/sort.js
var require_sort = __commonJS({
  "node_modules/semver/functions/sort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var sort = /* @__PURE__ */ __name((list, loose) => list.sort((a, b) => compareBuild(a, b, loose)), "sort");
    module.exports = sort;
  }
});

// node_modules/semver/functions/rsort.js
var require_rsort = __commonJS({
  "node_modules/semver/functions/rsort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var rsort = /* @__PURE__ */ __name((list, loose) => list.sort((a, b) => compareBuild(b, a, loose)), "rsort");
    module.exports = rsort;
  }
});

// node_modules/semver/functions/gt.js
var require_gt = __commonJS({
  "node_modules/semver/functions/gt.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var gt = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) > 0, "gt");
    module.exports = gt;
  }
});

// node_modules/semver/functions/lt.js
var require_lt = __commonJS({
  "node_modules/semver/functions/lt.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var lt = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) < 0, "lt");
    module.exports = lt;
  }
});

// node_modules/semver/functions/eq.js
var require_eq = __commonJS({
  "node_modules/semver/functions/eq.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var eq = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) === 0, "eq");
    module.exports = eq;
  }
});

// node_modules/semver/functions/neq.js
var require_neq = __commonJS({
  "node_modules/semver/functions/neq.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var neq = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) !== 0, "neq");
    module.exports = neq;
  }
});

// node_modules/semver/functions/gte.js
var require_gte = __commonJS({
  "node_modules/semver/functions/gte.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var gte = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) >= 0, "gte");
    module.exports = gte;
  }
});

// node_modules/semver/functions/lte.js
var require_lte = __commonJS({
  "node_modules/semver/functions/lte.js"(exports, module) {
    "use strict";
    var compare = require_compare();
    var lte = /* @__PURE__ */ __name((a, b, loose) => compare(a, b, loose) <= 0, "lte");
    module.exports = lte;
  }
});

// node_modules/semver/functions/cmp.js
var require_cmp = __commonJS({
  "node_modules/semver/functions/cmp.js"(exports, module) {
    "use strict";
    var eq = require_eq();
    var neq = require_neq();
    var gt = require_gt();
    var gte = require_gte();
    var lt = require_lt();
    var lte = require_lte();
    var cmp = /* @__PURE__ */ __name((a, op, b, loose) => {
      switch (op) {
        case "===":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a === b;
        case "!==":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a !== b;
        case "":
        case "=":
        case "==":
          return eq(a, b, loose);
        case "!=":
          return neq(a, b, loose);
        case ">":
          return gt(a, b, loose);
        case ">=":
          return gte(a, b, loose);
        case "<":
          return lt(a, b, loose);
        case "<=":
          return lte(a, b, loose);
        default:
          throw new TypeError(`Invalid operator: ${op}`);
      }
    }, "cmp");
    module.exports = cmp;
  }
});

// node_modules/semver/functions/coerce.js
var require_coerce = __commonJS({
  "node_modules/semver/functions/coerce.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse = require_parse();
    var { safeRe: re, t } = require_re();
    var coerce = /* @__PURE__ */ __name((version, options) => {
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version === "number") {
        version = String(version);
      }
      if (typeof version !== "string") {
        return null;
      }
      options = options || {};
      let match = null;
      if (!options.rtl) {
        match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
      } else {
        const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
        let next;
        while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
          if (!match || next.index + next[0].length !== match.index + match[0].length) {
            match = next;
          }
          coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
        }
        coerceRtlRegex.lastIndex = -1;
      }
      if (match === null) {
        return null;
      }
      const major = match[2];
      const minor = match[3] || "0";
      const patch = match[4] || "0";
      const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
      const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
      return parse(`${major}.${minor}.${patch}${prerelease}${build}`, options);
    }, "coerce");
    module.exports = coerce;
  }
});

// node_modules/semver/internal/lrucache.js
var require_lrucache = __commonJS({
  "node_modules/semver/internal/lrucache.js"(exports, module) {
    "use strict";
    var LRUCache = class {
      static {
        __name(this, "LRUCache");
      }
      constructor() {
        this.max = 1e3;
        this.map = /* @__PURE__ */ new Map();
      }
      get(key) {
        const value = this.map.get(key);
        if (value === void 0) {
          return void 0;
        } else {
          this.map.delete(key);
          this.map.set(key, value);
          return value;
        }
      }
      delete(key) {
        return this.map.delete(key);
      }
      set(key, value) {
        const deleted = this.delete(key);
        if (!deleted && value !== void 0) {
          if (this.map.size >= this.max) {
            const firstKey = this.map.keys().next().value;
            this.delete(firstKey);
          }
          this.map.set(key, value);
        }
        return this;
      }
    };
    module.exports = LRUCache;
  }
});

// node_modules/semver/classes/range.js
var require_range = __commonJS({
  "node_modules/semver/classes/range.js"(exports, module) {
    "use strict";
    var SPACE_CHARACTERS = /\s+/g;
    var Range = class _Range {
      static {
        __name(this, "Range");
      }
      constructor(range, options) {
        options = parseOptions(options);
        if (range instanceof _Range) {
          if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
            return range;
          } else {
            return new _Range(range.raw, options);
          }
        }
        if (range instanceof Comparator) {
          this.raw = range.value;
          this.set = [[range]];
          this.formatted = void 0;
          return this;
        }
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        this.raw = range.trim().replace(SPACE_CHARACTERS, " ");
        this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
        if (!this.set.length) {
          throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
        }
        if (this.set.length > 1) {
          const first2 = this.set[0];
          this.set = this.set.filter((c) => !isNullSet(c[0]));
          if (this.set.length === 0) {
            this.set = [first2];
          } else if (this.set.length > 1) {
            for (const c of this.set) {
              if (c.length === 1 && isAny(c[0])) {
                this.set = [c];
                break;
              }
            }
          }
        }
        this.formatted = void 0;
      }
      get range() {
        if (this.formatted === void 0) {
          this.formatted = "";
          for (let i = 0; i < this.set.length; i++) {
            if (i > 0) {
              this.formatted += "||";
            }
            const comps = this.set[i];
            for (let k = 0; k < comps.length; k++) {
              if (k > 0) {
                this.formatted += " ";
              }
              this.formatted += comps[k].toString().trim();
            }
          }
        }
        return this.formatted;
      }
      format() {
        return this.range;
      }
      toString() {
        return this.range;
      }
      parseRange(range) {
        const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
        const memoKey = memoOpts + ":" + range;
        const cached = cache2.get(memoKey);
        if (cached) {
          return cached;
        }
        const loose = this.options.loose;
        const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
        range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
        debug3("hyphen replace", range);
        range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
        debug3("comparator trim", range);
        range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
        debug3("tilde trim", range);
        range = range.replace(re[t.CARETTRIM], caretTrimReplace);
        debug3("caret trim", range);
        let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
        if (loose) {
          rangeList = rangeList.filter((comp) => {
            debug3("loose invalid filter", comp, this.options);
            return !!comp.match(re[t.COMPARATORLOOSE]);
          });
        }
        debug3("range list", rangeList);
        const rangeMap = /* @__PURE__ */ new Map();
        const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
        for (const comp of comparators) {
          if (isNullSet(comp)) {
            return [comp];
          }
          rangeMap.set(comp.value, comp);
        }
        if (rangeMap.size > 1 && rangeMap.has("")) {
          rangeMap.delete("");
        }
        const result = [...rangeMap.values()];
        cache2.set(memoKey, result);
        return result;
      }
      intersects(range, options) {
        if (!(range instanceof _Range)) {
          throw new TypeError("a Range is required");
        }
        return this.set.some((thisComparators) => {
          return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
            return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options);
              });
            });
          });
        });
      }
      // if ANY of the sets match ALL of its comparators, then pass
      test(version) {
        if (!version) {
          return false;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        for (let i = 0; i < this.set.length; i++) {
          if (testSet(this.set[i], version, this.options)) {
            return true;
          }
        }
        return false;
      }
    };
    module.exports = Range;
    var LRU = require_lrucache();
    var cache2 = new LRU();
    var parseOptions = require_parse_options();
    var Comparator = require_comparator();
    var debug3 = require_debug();
    var SemVer = require_semver();
    var {
      safeRe: re,
      t,
      comparatorTrimReplace,
      tildeTrimReplace,
      caretTrimReplace
    } = require_re();
    var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
    var isNullSet = /* @__PURE__ */ __name((c) => c.value === "<0.0.0-0", "isNullSet");
    var isAny = /* @__PURE__ */ __name((c) => c.value === "", "isAny");
    var isSatisfiable = /* @__PURE__ */ __name((comparators, options) => {
      let result = true;
      const remainingComparators = comparators.slice();
      let testComparator = remainingComparators.pop();
      while (result && remainingComparators.length) {
        result = remainingComparators.every((otherComparator) => {
          return testComparator.intersects(otherComparator, options);
        });
        testComparator = remainingComparators.pop();
      }
      return result;
    }, "isSatisfiable");
    var parseComparator = /* @__PURE__ */ __name((comp, options) => {
      debug3("comp", comp, options);
      comp = replaceCarets(comp, options);
      debug3("caret", comp);
      comp = replaceTildes(comp, options);
      debug3("tildes", comp);
      comp = replaceXRanges(comp, options);
      debug3("xrange", comp);
      comp = replaceStars(comp, options);
      debug3("stars", comp);
      return comp;
    }, "parseComparator");
    var isX = /* @__PURE__ */ __name((id) => !id || id.toLowerCase() === "x" || id === "*", "isX");
    var replaceTildes = /* @__PURE__ */ __name((comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
    }, "replaceTildes");
    var replaceTilde = /* @__PURE__ */ __name((comp, options) => {
      const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
      return comp.replace(r, (_, M, m, p, pr) => {
        debug3("tilde", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
        } else if (pr) {
          debug3("replaceTilde pr", pr);
          ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
        }
        debug3("tilde return", ret);
        return ret;
      });
    }, "replaceTilde");
    var replaceCarets = /* @__PURE__ */ __name((comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
    }, "replaceCarets");
    var replaceCaret = /* @__PURE__ */ __name((comp, options) => {
      debug3("caret", comp, options);
      const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug3("caret", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          if (M === "0") {
            ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
          }
        } else if (pr) {
          debug3("replaceCaret pr", pr);
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
          }
        } else {
          debug3("no pr");
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
          }
        }
        debug3("caret return", ret);
        return ret;
      });
    }, "replaceCaret");
    var replaceXRanges = /* @__PURE__ */ __name((comp, options) => {
      debug3("replaceXRanges", comp, options);
      return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
    }, "replaceXRanges");
    var replaceXRange = /* @__PURE__ */ __name((comp, options) => {
      comp = comp.trim();
      const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
      return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
        debug3("xRange", comp, ret, gtlt, M, m, p, pr);
        const xM = isX(M);
        const xm = xM || isX(m);
        const xp = xm || isX(p);
        const anyX = xp;
        if (gtlt === "=" && anyX) {
          gtlt = "";
        }
        pr = options.includePrerelease ? "-0" : "";
        if (xM) {
          if (gtlt === ">" || gtlt === "<") {
            ret = "<0.0.0-0";
          } else {
            ret = "*";
          }
        } else if (gtlt && anyX) {
          if (xm) {
            m = 0;
          }
          p = 0;
          if (gtlt === ">") {
            gtlt = ">=";
            if (xm) {
              M = +M + 1;
              m = 0;
              p = 0;
            } else {
              m = +m + 1;
              p = 0;
            }
          } else if (gtlt === "<=") {
            gtlt = "<";
            if (xm) {
              M = +M + 1;
            } else {
              m = +m + 1;
            }
          }
          if (gtlt === "<") {
            pr = "-0";
          }
          ret = `${gtlt + M}.${m}.${p}${pr}`;
        } else if (xm) {
          ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
        } else if (xp) {
          ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
        }
        debug3("xRange return", ret);
        return ret;
      });
    }, "replaceXRange");
    var replaceStars = /* @__PURE__ */ __name((comp, options) => {
      debug3("replaceStars", comp, options);
      return comp.trim().replace(re[t.STAR], "");
    }, "replaceStars");
    var replaceGTE0 = /* @__PURE__ */ __name((comp, options) => {
      debug3("replaceGTE0", comp, options);
      return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
    }, "replaceGTE0");
    var hyphenReplace = /* @__PURE__ */ __name((incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
      if (isX(fM)) {
        from = "";
      } else if (isX(fm)) {
        from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
      } else if (isX(fp)) {
        from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
      } else if (fpr) {
        from = `>=${from}`;
      } else {
        from = `>=${from}${incPr ? "-0" : ""}`;
      }
      if (isX(tM)) {
        to = "";
      } else if (isX(tm)) {
        to = `<${+tM + 1}.0.0-0`;
      } else if (isX(tp)) {
        to = `<${tM}.${+tm + 1}.0-0`;
      } else if (tpr) {
        to = `<=${tM}.${tm}.${tp}-${tpr}`;
      } else if (incPr) {
        to = `<${tM}.${tm}.${+tp + 1}-0`;
      } else {
        to = `<=${to}`;
      }
      return `${from} ${to}`.trim();
    }, "hyphenReplace");
    var testSet = /* @__PURE__ */ __name((set, version, options) => {
      for (let i = 0; i < set.length; i++) {
        if (!set[i].test(version)) {
          return false;
        }
      }
      if (version.prerelease.length && !options.includePrerelease) {
        for (let i = 0; i < set.length; i++) {
          debug3(set[i].semver);
          if (set[i].semver === Comparator.ANY) {
            continue;
          }
          if (set[i].semver.prerelease.length > 0) {
            const allowed = set[i].semver;
            if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
              return true;
            }
          }
        }
        return false;
      }
      return true;
    }, "testSet");
  }
});

// node_modules/semver/classes/comparator.js
var require_comparator = __commonJS({
  "node_modules/semver/classes/comparator.js"(exports, module) {
    "use strict";
    var ANY = Symbol("SemVer ANY");
    var Comparator = class _Comparator {
      static {
        __name(this, "Comparator");
      }
      static get ANY() {
        return ANY;
      }
      constructor(comp, options) {
        options = parseOptions(options);
        if (comp instanceof _Comparator) {
          if (comp.loose === !!options.loose) {
            return comp;
          } else {
            comp = comp.value;
          }
        }
        comp = comp.trim().split(/\s+/).join(" ");
        debug3("comparator", comp, options);
        this.options = options;
        this.loose = !!options.loose;
        this.parse(comp);
        if (this.semver === ANY) {
          this.value = "";
        } else {
          this.value = this.operator + this.semver.version;
        }
        debug3("comp", this);
      }
      parse(comp) {
        const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
        const m = comp.match(r);
        if (!m) {
          throw new TypeError(`Invalid comparator: ${comp}`);
        }
        this.operator = m[1] !== void 0 ? m[1] : "";
        if (this.operator === "=") {
          this.operator = "";
        }
        if (!m[2]) {
          this.semver = ANY;
        } else {
          this.semver = new SemVer(m[2], this.options.loose);
        }
      }
      toString() {
        return this.value;
      }
      test(version) {
        debug3("Comparator.test", version, this.options.loose);
        if (this.semver === ANY || version === ANY) {
          return true;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        return cmp(version, this.operator, this.semver, this.options);
      }
      intersects(comp, options) {
        if (!(comp instanceof _Comparator)) {
          throw new TypeError("a Comparator is required");
        }
        if (this.operator === "") {
          if (this.value === "") {
            return true;
          }
          return new Range(comp.value, options).test(this.value);
        } else if (comp.operator === "") {
          if (comp.value === "") {
            return true;
          }
          return new Range(this.value, options).test(comp.semver);
        }
        options = parseOptions(options);
        if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
          return false;
        }
        if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
          return false;
        }
        if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
          return true;
        }
        if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
          return true;
        }
        if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
          return true;
        }
        if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
          return true;
        }
        if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
          return true;
        }
        return false;
      }
    };
    module.exports = Comparator;
    var parseOptions = require_parse_options();
    var { safeRe: re, t } = require_re();
    var cmp = require_cmp();
    var debug3 = require_debug();
    var SemVer = require_semver();
    var Range = require_range();
  }
});

// node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS({
  "node_modules/semver/functions/satisfies.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var satisfies = /* @__PURE__ */ __name((version, range, options) => {
      try {
        range = new Range(range, options);
      } catch (er) {
        return false;
      }
      return range.test(version);
    }, "satisfies");
    module.exports = satisfies;
  }
});

// node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS({
  "node_modules/semver/ranges/to-comparators.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var toComparators = /* @__PURE__ */ __name((range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" ")), "toComparators");
    module.exports = toComparators;
  }
});

// node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS({
  "node_modules/semver/ranges/max-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var maxSatisfying = /* @__PURE__ */ __name((versions, range, options) => {
      let max = null;
      let maxSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!max || maxSV.compare(v) === -1) {
            max = v;
            maxSV = new SemVer(max, options);
          }
        }
      });
      return max;
    }, "maxSatisfying");
    module.exports = maxSatisfying;
  }
});

// node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS({
  "node_modules/semver/ranges/min-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var minSatisfying = /* @__PURE__ */ __name((versions, range, options) => {
      let min = null;
      let minSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!min || minSV.compare(v) === 1) {
            min = v;
            minSV = new SemVer(min, options);
          }
        }
      });
      return min;
    }, "minSatisfying");
    module.exports = minSatisfying;
  }
});

// node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS({
  "node_modules/semver/ranges/min-version.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var gt = require_gt();
    var minVersion = /* @__PURE__ */ __name((range, loose) => {
      range = new Range(range, loose);
      let minver = new SemVer("0.0.0");
      if (range.test(minver)) {
        return minver;
      }
      minver = new SemVer("0.0.0-0");
      if (range.test(minver)) {
        return minver;
      }
      minver = null;
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let setMin = null;
        comparators.forEach((comparator) => {
          const compver = new SemVer(comparator.semver.version);
          switch (comparator.operator) {
            case ">":
              if (compver.prerelease.length === 0) {
                compver.patch++;
              } else {
                compver.prerelease.push(0);
              }
              compver.raw = compver.format();
            case "":
            case ">=":
              if (!setMin || gt(compver, setMin)) {
                setMin = compver;
              }
              break;
            case "<":
            case "<=":
              break;
            default:
              throw new Error(`Unexpected operation: ${comparator.operator}`);
          }
        });
        if (setMin && (!minver || gt(minver, setMin))) {
          minver = setMin;
        }
      }
      if (minver && range.test(minver)) {
        return minver;
      }
      return null;
    }, "minVersion");
    module.exports = minVersion;
  }
});

// node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS({
  "node_modules/semver/ranges/valid.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var validRange = /* @__PURE__ */ __name((range, options) => {
      try {
        return new Range(range, options).range || "*";
      } catch (er) {
        return null;
      }
    }, "validRange");
    module.exports = validRange;
  }
});

// node_modules/semver/ranges/outside.js
var require_outside = __commonJS({
  "node_modules/semver/ranges/outside.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var Range = require_range();
    var satisfies = require_satisfies();
    var gt = require_gt();
    var lt = require_lt();
    var lte = require_lte();
    var gte = require_gte();
    var outside = /* @__PURE__ */ __name((version, range, hilo, options) => {
      version = new SemVer(version, options);
      range = new Range(range, options);
      let gtfn, ltefn, ltfn, comp, ecomp;
      switch (hilo) {
        case ">":
          gtfn = gt;
          ltefn = lte;
          ltfn = lt;
          comp = ">";
          ecomp = ">=";
          break;
        case "<":
          gtfn = lt;
          ltefn = gte;
          ltfn = gt;
          comp = "<";
          ecomp = "<=";
          break;
        default:
          throw new TypeError('Must provide a hilo val of "<" or ">"');
      }
      if (satisfies(version, range, options)) {
        return false;
      }
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let high = null;
        let low = null;
        comparators.forEach((comparator) => {
          if (comparator.semver === ANY) {
            comparator = new Comparator(">=0.0.0");
          }
          high = high || comparator;
          low = low || comparator;
          if (gtfn(comparator.semver, high.semver, options)) {
            high = comparator;
          } else if (ltfn(comparator.semver, low.semver, options)) {
            low = comparator;
          }
        });
        if (high.operator === comp || high.operator === ecomp) {
          return false;
        }
        if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
          return false;
        } else if (low.operator === ecomp && ltfn(version, low.semver)) {
          return false;
        }
      }
      return true;
    }, "outside");
    module.exports = outside;
  }
});

// node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS({
  "node_modules/semver/ranges/gtr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var gtr = /* @__PURE__ */ __name((version, range, options) => outside(version, range, ">", options), "gtr");
    module.exports = gtr;
  }
});

// node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS({
  "node_modules/semver/ranges/ltr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var ltr = /* @__PURE__ */ __name((version, range, options) => outside(version, range, "<", options), "ltr");
    module.exports = ltr;
  }
});

// node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS({
  "node_modules/semver/ranges/intersects.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var intersects = /* @__PURE__ */ __name((r1, r2, options) => {
      r1 = new Range(r1, options);
      r2 = new Range(r2, options);
      return r1.intersects(r2, options);
    }, "intersects");
    module.exports = intersects;
  }
});

// node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS({
  "node_modules/semver/ranges/simplify.js"(exports, module) {
    "use strict";
    var satisfies = require_satisfies();
    var compare = require_compare();
    module.exports = (versions, range, options) => {
      const set = [];
      let first2 = null;
      let prev = null;
      const v = versions.sort((a, b) => compare(a, b, options));
      for (const version of v) {
        const included = satisfies(version, range, options);
        if (included) {
          prev = version;
          if (!first2) {
            first2 = version;
          }
        } else {
          if (prev) {
            set.push([first2, prev]);
          }
          prev = null;
          first2 = null;
        }
      }
      if (first2) {
        set.push([first2, null]);
      }
      const ranges = [];
      for (const [min, max] of set) {
        if (min === max) {
          ranges.push(min);
        } else if (!max && min === v[0]) {
          ranges.push("*");
        } else if (!max) {
          ranges.push(`>=${min}`);
        } else if (min === v[0]) {
          ranges.push(`<=${max}`);
        } else {
          ranges.push(`${min} - ${max}`);
        }
      }
      const simplified = ranges.join(" || ");
      const original = typeof range.raw === "string" ? range.raw : String(range);
      return simplified.length < original.length ? simplified : range;
    };
  }
});

// node_modules/semver/ranges/subset.js
var require_subset = __commonJS({
  "node_modules/semver/ranges/subset.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var satisfies = require_satisfies();
    var compare = require_compare();
    var subset = /* @__PURE__ */ __name((sub, dom, options = {}) => {
      if (sub === dom) {
        return true;
      }
      sub = new Range(sub, options);
      dom = new Range(dom, options);
      let sawNonNull = false;
      OUTER: for (const simpleSub of sub.set) {
        for (const simpleDom of dom.set) {
          const isSub = simpleSubset(simpleSub, simpleDom, options);
          sawNonNull = sawNonNull || isSub !== null;
          if (isSub) {
            continue OUTER;
          }
        }
        if (sawNonNull) {
          return false;
        }
      }
      return true;
    }, "subset");
    var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
    var minimumVersion = [new Comparator(">=0.0.0")];
    var simpleSubset = /* @__PURE__ */ __name((sub, dom, options) => {
      if (sub === dom) {
        return true;
      }
      if (sub.length === 1 && sub[0].semver === ANY) {
        if (dom.length === 1 && dom[0].semver === ANY) {
          return true;
        } else if (options.includePrerelease) {
          sub = minimumVersionWithPreRelease;
        } else {
          sub = minimumVersion;
        }
      }
      if (dom.length === 1 && dom[0].semver === ANY) {
        if (options.includePrerelease) {
          return true;
        } else {
          dom = minimumVersion;
        }
      }
      const eqSet = /* @__PURE__ */ new Set();
      let gt, lt;
      for (const c of sub) {
        if (c.operator === ">" || c.operator === ">=") {
          gt = higherGT(gt, c, options);
        } else if (c.operator === "<" || c.operator === "<=") {
          lt = lowerLT(lt, c, options);
        } else {
          eqSet.add(c.semver);
        }
      }
      if (eqSet.size > 1) {
        return null;
      }
      let gtltComp;
      if (gt && lt) {
        gtltComp = compare(gt.semver, lt.semver, options);
        if (gtltComp > 0) {
          return null;
        } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
          return null;
        }
      }
      for (const eq of eqSet) {
        if (gt && !satisfies(eq, String(gt), options)) {
          return null;
        }
        if (lt && !satisfies(eq, String(lt), options)) {
          return null;
        }
        for (const c of dom) {
          if (!satisfies(eq, String(c), options)) {
            return false;
          }
        }
        return true;
      }
      let higher, lower;
      let hasDomLT, hasDomGT;
      let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
      let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
      if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
        needDomLTPre = false;
      }
      for (const c of dom) {
        hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
        hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
        if (gt) {
          if (needDomGTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
              needDomGTPre = false;
            }
          }
          if (c.operator === ">" || c.operator === ">=") {
            higher = higherGT(gt, c, options);
            if (higher === c && higher !== gt) {
              return false;
            }
          } else if (gt.operator === ">=" && !satisfies(gt.semver, String(c), options)) {
            return false;
          }
        }
        if (lt) {
          if (needDomLTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
              needDomLTPre = false;
            }
          }
          if (c.operator === "<" || c.operator === "<=") {
            lower = lowerLT(lt, c, options);
            if (lower === c && lower !== lt) {
              return false;
            }
          } else if (lt.operator === "<=" && !satisfies(lt.semver, String(c), options)) {
            return false;
          }
        }
        if (!c.operator && (lt || gt) && gtltComp !== 0) {
          return false;
        }
      }
      if (gt && hasDomLT && !lt && gtltComp !== 0) {
        return false;
      }
      if (lt && hasDomGT && !gt && gtltComp !== 0) {
        return false;
      }
      if (needDomGTPre || needDomLTPre) {
        return false;
      }
      return true;
    }, "simpleSubset");
    var higherGT = /* @__PURE__ */ __name((a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
    }, "higherGT");
    var lowerLT = /* @__PURE__ */ __name((a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
    }, "lowerLT");
    module.exports = subset;
  }
});

// node_modules/semver/index.js
var require_semver2 = __commonJS({
  "node_modules/semver/index.js"(exports, module) {
    "use strict";
    var internalRe = require_re();
    var constants = require_constants();
    var SemVer = require_semver();
    var identifiers = require_identifiers();
    var parse = require_parse();
    var valid = require_valid();
    var clean = require_clean();
    var inc = require_inc();
    var diff = require_diff();
    var major = require_major();
    var minor = require_minor();
    var patch = require_patch();
    var prerelease = require_prerelease();
    var compare = require_compare();
    var rcompare = require_rcompare();
    var compareLoose = require_compare_loose();
    var compareBuild = require_compare_build();
    var sort = require_sort();
    var rsort = require_rsort();
    var gt = require_gt();
    var lt = require_lt();
    var eq = require_eq();
    var neq = require_neq();
    var gte = require_gte();
    var lte = require_lte();
    var cmp = require_cmp();
    var coerce = require_coerce();
    var Comparator = require_comparator();
    var Range = require_range();
    var satisfies = require_satisfies();
    var toComparators = require_to_comparators();
    var maxSatisfying = require_max_satisfying();
    var minSatisfying = require_min_satisfying();
    var minVersion = require_min_version();
    var validRange = require_valid2();
    var outside = require_outside();
    var gtr = require_gtr();
    var ltr = require_ltr();
    var intersects = require_intersects();
    var simplifyRange = require_simplify();
    var subset = require_subset();
    module.exports = {
      parse,
      valid,
      clean,
      inc,
      diff,
      major,
      minor,
      patch,
      prerelease,
      compare,
      rcompare,
      compareLoose,
      compareBuild,
      sort,
      rsort,
      gt,
      lt,
      eq,
      neq,
      gte,
      lte,
      cmp,
      coerce,
      Comparator,
      Range,
      satisfies,
      toComparators,
      maxSatisfying,
      minSatisfying,
      minVersion,
      validRange,
      outside,
      gtr,
      ltr,
      intersects,
      simplifyRange,
      subset,
      SemVer,
      re: internalRe.re,
      src: internalRe.src,
      tokens: internalRe.t,
      SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
      RELEASE_TYPES: constants.RELEASE_TYPES,
      compareIdentifiers: identifiers.compareIdentifiers,
      rcompareIdentifiers: identifiers.rcompareIdentifiers
    };
  }
});

// node_modules/debug/node_modules/ms/index.js
var require_ms = __commonJS({
  "node_modules/debug/node_modules/ms/index.js"(exports, module) {
    "use strict";
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var w = d * 7;
    var y = d * 365.25;
    module.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse(val);
      } else if (type === "number" && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error(
        "val is not a non-empty string or a valid number. val=" + JSON.stringify(val)
      );
    };
    function parse(str) {
      str = String(str);
      if (str.length > 100) {
        return;
      }
      var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
        str
      );
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "weeks":
        case "week":
        case "w":
          return n * w;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    __name(parse, "parse");
    function fmtShort(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return Math.round(ms / d) + "d";
      }
      if (msAbs >= h) {
        return Math.round(ms / h) + "h";
      }
      if (msAbs >= m) {
        return Math.round(ms / m) + "m";
      }
      if (msAbs >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    __name(fmtShort, "fmtShort");
    function fmtLong(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return plural(ms, msAbs, d, "day");
      }
      if (msAbs >= h) {
        return plural(ms, msAbs, h, "hour");
      }
      if (msAbs >= m) {
        return plural(ms, msAbs, m, "minute");
      }
      if (msAbs >= s) {
        return plural(ms, msAbs, s, "second");
      }
      return ms + " ms";
    }
    __name(fmtLong, "fmtLong");
    function plural(ms, msAbs, n, name) {
      var isPlural = msAbs >= n * 1.5;
      return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
    }
    __name(plural, "plural");
  }
});

// node_modules/debug/src/common.js
var require_common = __commonJS({
  "node_modules/debug/src/common.js"(exports, module) {
    "use strict";
    function setup(env) {
      createDebug.debug = createDebug;
      createDebug.default = createDebug;
      createDebug.coerce = coerce;
      createDebug.disable = disable;
      createDebug.enable = enable;
      createDebug.enabled = enabled;
      createDebug.humanize = require_ms();
      createDebug.destroy = destroy;
      Object.keys(env).forEach((key) => {
        createDebug[key] = env[key];
      });
      createDebug.names = [];
      createDebug.skips = [];
      createDebug.formatters = {};
      function selectColor(namespace) {
        let hash = 0;
        for (let i = 0; i < namespace.length; i++) {
          hash = (hash << 5) - hash + namespace.charCodeAt(i);
          hash |= 0;
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
      }
      __name(selectColor, "selectColor");
      createDebug.selectColor = selectColor;
      function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug3(...args) {
          if (!debug3.enabled) {
            return;
          }
          const self = debug3;
          const curr = Number(/* @__PURE__ */ new Date());
          const ms = curr - (prevTime || curr);
          self.diff = ms;
          self.prev = prevTime;
          self.curr = curr;
          prevTime = curr;
          args[0] = createDebug.coerce(args[0]);
          if (typeof args[0] !== "string") {
            args.unshift("%O");
          }
          let index = 0;
          args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
            if (match === "%%") {
              return "%";
            }
            index++;
            const formatter = createDebug.formatters[format];
            if (typeof formatter === "function") {
              const val = args[index];
              match = formatter.call(self, val);
              args.splice(index, 1);
              index--;
            }
            return match;
          });
          createDebug.formatArgs.call(self, args);
          const logFn = self.log || createDebug.log;
          logFn.apply(self, args);
        }
        __name(debug3, "debug");
        debug3.namespace = namespace;
        debug3.useColors = createDebug.useColors();
        debug3.color = createDebug.selectColor(namespace);
        debug3.extend = extend;
        debug3.destroy = createDebug.destroy;
        Object.defineProperty(debug3, "enabled", {
          enumerable: true,
          configurable: false,
          get: /* @__PURE__ */ __name(() => {
            if (enableOverride !== null) {
              return enableOverride;
            }
            if (namespacesCache !== createDebug.namespaces) {
              namespacesCache = createDebug.namespaces;
              enabledCache = createDebug.enabled(namespace);
            }
            return enabledCache;
          }, "get"),
          set: /* @__PURE__ */ __name((v) => {
            enableOverride = v;
          }, "set")
        });
        if (typeof createDebug.init === "function") {
          createDebug.init(debug3);
        }
        return debug3;
      }
      __name(createDebug, "createDebug");
      function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
      }
      __name(extend, "extend");
      function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        let i;
        const split = (typeof namespaces === "string" ? namespaces : "").split(/[\s,]+/);
        const len = split.length;
        for (i = 0; i < len; i++) {
          if (!split[i]) {
            continue;
          }
          namespaces = split[i].replace(/\*/g, ".*?");
          if (namespaces[0] === "-") {
            createDebug.skips.push(new RegExp("^" + namespaces.slice(1) + "$"));
          } else {
            createDebug.names.push(new RegExp("^" + namespaces + "$"));
          }
        }
      }
      __name(enable, "enable");
      function disable() {
        const namespaces = [
          ...createDebug.names.map(toNamespace),
          ...createDebug.skips.map(toNamespace).map((namespace) => "-" + namespace)
        ].join(",");
        createDebug.enable("");
        return namespaces;
      }
      __name(disable, "disable");
      function enabled(name) {
        if (name[name.length - 1] === "*") {
          return true;
        }
        let i;
        let len;
        for (i = 0, len = createDebug.skips.length; i < len; i++) {
          if (createDebug.skips[i].test(name)) {
            return false;
          }
        }
        for (i = 0, len = createDebug.names.length; i < len; i++) {
          if (createDebug.names[i].test(name)) {
            return true;
          }
        }
        return false;
      }
      __name(enabled, "enabled");
      function toNamespace(regexp) {
        return regexp.toString().substring(2, regexp.toString().length - 2).replace(/\.\*\?$/, "*");
      }
      __name(toNamespace, "toNamespace");
      function coerce(val) {
        if (val instanceof Error) {
          return val.stack || val.message;
        }
        return val;
      }
      __name(coerce, "coerce");
      function destroy() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      __name(destroy, "destroy");
      createDebug.enable(createDebug.load());
      return createDebug;
    }
    __name(setup, "setup");
    module.exports = setup;
  }
});

// node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "node_modules/debug/src/browser.js"(exports, module) {
    "use strict";
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.storage = localstorage();
    exports.destroy = /* @__PURE__ */ (() => {
      let warned = false;
      return () => {
        if (!warned) {
          warned = true;
          console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
        }
      };
    })();
    exports.colors = [
      "#0000CC",
      "#0000FF",
      "#0033CC",
      "#0033FF",
      "#0066CC",
      "#0066FF",
      "#0099CC",
      "#0099FF",
      "#00CC00",
      "#00CC33",
      "#00CC66",
      "#00CC99",
      "#00CCCC",
      "#00CCFF",
      "#3300CC",
      "#3300FF",
      "#3333CC",
      "#3333FF",
      "#3366CC",
      "#3366FF",
      "#3399CC",
      "#3399FF",
      "#33CC00",
      "#33CC33",
      "#33CC66",
      "#33CC99",
      "#33CCCC",
      "#33CCFF",
      "#6600CC",
      "#6600FF",
      "#6633CC",
      "#6633FF",
      "#66CC00",
      "#66CC33",
      "#9900CC",
      "#9900FF",
      "#9933CC",
      "#9933FF",
      "#99CC00",
      "#99CC33",
      "#CC0000",
      "#CC0033",
      "#CC0066",
      "#CC0099",
      "#CC00CC",
      "#CC00FF",
      "#CC3300",
      "#CC3333",
      "#CC3366",
      "#CC3399",
      "#CC33CC",
      "#CC33FF",
      "#CC6600",
      "#CC6633",
      "#CC9900",
      "#CC9933",
      "#CCCC00",
      "#CCCC33",
      "#FF0000",
      "#FF0033",
      "#FF0066",
      "#FF0099",
      "#FF00CC",
      "#FF00FF",
      "#FF3300",
      "#FF3333",
      "#FF3366",
      "#FF3399",
      "#FF33CC",
      "#FF33FF",
      "#FF6600",
      "#FF6633",
      "#FF9900",
      "#FF9933",
      "#FFCC00",
      "#FFCC33"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) {
        return true;
      }
      if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
      }
      let m;
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || // Is firebug? http://stackoverflow.com/a/398120/376773
      typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || // Is firefox >= v31?
      // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
      typeof navigator !== "undefined" && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || // Double check webkit in userAgent just in case we are in a worker
      typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    __name(useColors, "useColors");
    function formatArgs(args) {
      args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
      if (!this.useColors) {
        return;
      }
      const c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      let index = 0;
      let lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, (match) => {
        if (match === "%%") {
          return;
        }
        index++;
        if (match === "%c") {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    __name(formatArgs, "formatArgs");
    exports.log = console.debug || console.log || (() => {
    });
    function save(namespaces) {
      try {
        if (namespaces) {
          exports.storage.setItem("debug", namespaces);
        } else {
          exports.storage.removeItem("debug");
        }
      } catch (error) {
      }
    }
    __name(save, "save");
    function load() {
      let r;
      try {
        r = exports.storage.getItem("debug");
      } catch (error) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    __name(load, "load");
    function localstorage() {
      try {
        return localStorage;
      } catch (error) {
      }
    }
    __name(localstorage, "localstorage");
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (error) {
        return "[UnexpectedJSONParseError]: " + error.message;
      }
    };
  }
});

// node_modules/has-flag/index.js
var require_has_flag = __commonJS({
  "node_modules/has-flag/index.js"(exports, module) {
    "use strict";
    module.exports = (flag, argv) => {
      argv = argv || process.argv;
      const prefix = flag.startsWith("-") ? "" : flag.length === 1 ? "-" : "--";
      const pos = argv.indexOf(prefix + flag);
      const terminatorPos = argv.indexOf("--");
      return pos !== -1 && (terminatorPos === -1 ? true : pos < terminatorPos);
    };
  }
});

// node_modules/supports-color/index.js
var require_supports_color = __commonJS({
  "node_modules/supports-color/index.js"(exports, module) {
    "use strict";
    var os = __require("os");
    var hasFlag = require_has_flag();
    var env = process.env;
    var forceColor;
    if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false")) {
      forceColor = false;
    } else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
      forceColor = true;
    }
    if ("FORCE_COLOR" in env) {
      forceColor = env.FORCE_COLOR.length === 0 || parseInt(env.FORCE_COLOR, 10) !== 0;
    }
    function translateLevel(level) {
      if (level === 0) {
        return false;
      }
      return {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
      };
    }
    __name(translateLevel, "translateLevel");
    function supportsColor(stream) {
      if (forceColor === false) {
        return 0;
      }
      if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
        return 3;
      }
      if (hasFlag("color=256")) {
        return 2;
      }
      if (stream && !stream.isTTY && forceColor !== true) {
        return 0;
      }
      const min = forceColor ? 1 : 0;
      if (process.platform === "win32") {
        const osRelease = os.release().split(".");
        if (Number(process.versions.node.split(".")[0]) >= 8 && Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
          return Number(osRelease[2]) >= 14931 ? 3 : 2;
        }
        return 1;
      }
      if ("CI" in env) {
        if (["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI"].some((sign) => sign in env) || env.CI_NAME === "codeship") {
          return 1;
        }
        return min;
      }
      if ("TEAMCITY_VERSION" in env) {
        return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
      }
      if (env.COLORTERM === "truecolor") {
        return 3;
      }
      if ("TERM_PROGRAM" in env) {
        const version = parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
        switch (env.TERM_PROGRAM) {
          case "iTerm.app":
            return version >= 3 ? 3 : 2;
          case "Apple_Terminal":
            return 2;
        }
      }
      if (/-256(color)?$/i.test(env.TERM)) {
        return 2;
      }
      if (/^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
        return 1;
      }
      if ("COLORTERM" in env) {
        return 1;
      }
      if (env.TERM === "dumb") {
        return min;
      }
      return min;
    }
    __name(supportsColor, "supportsColor");
    function getSupportLevel(stream) {
      const level = supportsColor(stream);
      return translateLevel(level);
    }
    __name(getSupportLevel, "getSupportLevel");
    module.exports = {
      supportsColor: getSupportLevel,
      stdout: getSupportLevel(process.stdout),
      stderr: getSupportLevel(process.stderr)
    };
  }
});

// node_modules/debug/src/node.js
var require_node = __commonJS({
  "node_modules/debug/src/node.js"(exports, module) {
    "use strict";
    var tty = __require("tty");
    var util = __require("util");
    exports.init = init;
    exports.log = log;
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.destroy = util.deprecate(
      () => {
      },
      "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."
    );
    exports.colors = [6, 2, 3, 4, 5, 1];
    try {
      const supportsColor = require_supports_color();
      if (supportsColor && (supportsColor.stderr || supportsColor).level >= 2) {
        exports.colors = [
          20,
          21,
          26,
          27,
          32,
          33,
          38,
          39,
          40,
          41,
          42,
          43,
          44,
          45,
          56,
          57,
          62,
          63,
          68,
          69,
          74,
          75,
          76,
          77,
          78,
          79,
          80,
          81,
          92,
          93,
          98,
          99,
          112,
          113,
          128,
          129,
          134,
          135,
          148,
          149,
          160,
          161,
          162,
          163,
          164,
          165,
          166,
          167,
          168,
          169,
          170,
          171,
          172,
          173,
          178,
          179,
          184,
          185,
          196,
          197,
          198,
          199,
          200,
          201,
          202,
          203,
          204,
          205,
          206,
          207,
          208,
          209,
          214,
          215,
          220,
          221
        ];
      }
    } catch (error) {
    }
    exports.inspectOpts = Object.keys(process.env).filter((key) => {
      return /^debug_/i.test(key);
    }).reduce((obj, key) => {
      const prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, (_, k) => {
        return k.toUpperCase();
      });
      let val = process.env[key];
      if (/^(yes|on|true|enabled)$/i.test(val)) {
        val = true;
      } else if (/^(no|off|false|disabled)$/i.test(val)) {
        val = false;
      } else if (val === "null") {
        val = null;
      } else {
        val = Number(val);
      }
      obj[prop] = val;
      return obj;
    }, {});
    function useColors() {
      return "colors" in exports.inspectOpts ? Boolean(exports.inspectOpts.colors) : tty.isatty(process.stderr.fd);
    }
    __name(useColors, "useColors");
    function formatArgs(args) {
      const { namespace: name, useColors: useColors2 } = this;
      if (useColors2) {
        const c = this.color;
        const colorCode = "\x1B[3" + (c < 8 ? c : "8;5;" + c);
        const prefix = `  ${colorCode};1m${name} \x1B[0m`;
        args[0] = prefix + args[0].split("\n").join("\n" + prefix);
        args.push(colorCode + "m+" + module.exports.humanize(this.diff) + "\x1B[0m");
      } else {
        args[0] = getDate() + name + " " + args[0];
      }
    }
    __name(formatArgs, "formatArgs");
    function getDate() {
      if (exports.inspectOpts.hideDate) {
        return "";
      }
      return (/* @__PURE__ */ new Date()).toISOString() + " ";
    }
    __name(getDate, "getDate");
    function log(...args) {
      return process.stderr.write(util.formatWithOptions(exports.inspectOpts, ...args) + "\n");
    }
    __name(log, "log");
    function save(namespaces) {
      if (namespaces) {
        process.env.DEBUG = namespaces;
      } else {
        delete process.env.DEBUG;
      }
    }
    __name(save, "save");
    function load() {
      return process.env.DEBUG;
    }
    __name(load, "load");
    function init(debug3) {
      debug3.inspectOpts = {};
      const keys = Object.keys(exports.inspectOpts);
      for (let i = 0; i < keys.length; i++) {
        debug3.inspectOpts[keys[i]] = exports.inspectOpts[keys[i]];
      }
    }
    __name(init, "init");
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.o = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts).split("\n").map((str) => str.trim()).join(" ");
    };
    formatters.O = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts);
    };
  }
});

// node_modules/debug/src/index.js
var require_src = __commonJS({
  "node_modules/debug/src/index.js"(exports, module) {
    "use strict";
    if (typeof process === "undefined" || process.type === "renderer" || process.browser === true || process.__nwjs) {
      module.exports = require_browser();
    } else {
      module.exports = require_node();
    }
  }
});

// node_modules/@kwsites/file-exists/dist/src/index.js
var require_src2 = __commonJS({
  "node_modules/@kwsites/file-exists/dist/src/index.js"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    var fs_1 = __require("fs");
    var debug_1 = __importDefault(require_src());
    var log = debug_1.default("@kwsites/file-exists");
    function check(path, isFile, isDirectory) {
      log(`checking %s`, path);
      try {
        const stat = fs_1.statSync(path);
        if (stat.isFile() && isFile) {
          log(`[OK] path represents a file`);
          return true;
        }
        if (stat.isDirectory() && isDirectory) {
          log(`[OK] path represents a directory`);
          return true;
        }
        log(`[FAIL] path represents something other than a file or directory`);
        return false;
      } catch (e) {
        if (e.code === "ENOENT") {
          log(`[FAIL] path is not accessible: %o`, e);
          return false;
        }
        log(`[FATAL] %o`, e);
        throw e;
      }
    }
    __name(check, "check");
    function exists2(path, type = exports.READABLE) {
      return check(path, (type & exports.FILE) > 0, (type & exports.FOLDER) > 0);
    }
    __name(exists2, "exists");
    exports.exists = exists2;
    exports.FILE = 1;
    exports.FOLDER = 2;
    exports.READABLE = exports.FILE + exports.FOLDER;
  }
});

// node_modules/@kwsites/file-exists/dist/index.js
var require_dist = __commonJS({
  "node_modules/@kwsites/file-exists/dist/index.js"(exports) {
    "use strict";
    function __export3(m) {
      for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }
    __name(__export3, "__export");
    Object.defineProperty(exports, "__esModule", { value: true });
    __export3(require_src2());
  }
});

// node_modules/@kwsites/promise-deferred/dist/index.js
var require_dist2 = __commonJS({
  "node_modules/@kwsites/promise-deferred/dist/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.createDeferred = exports.deferred = void 0;
    function deferred2() {
      let done;
      let fail;
      let status = "pending";
      const promise = new Promise((_done, _fail) => {
        done = _done;
        fail = _fail;
      });
      return {
        promise,
        done(result) {
          if (status === "pending") {
            status = "resolved";
            done(result);
          }
        },
        fail(error) {
          if (status === "pending") {
            status = "rejected";
            fail(error);
          }
        },
        get fulfilled() {
          return status !== "pending";
        },
        get status() {
          return status;
        }
      };
    }
    __name(deferred2, "deferred");
    exports.deferred = deferred2;
    exports.createDeferred = deferred2;
    exports.default = deferred2;
  }
});

// libs/sdk/parser/src/index.ts
var src_exports = {};
__export(src_exports, {
  Checker: () => Checker,
  getExports: () => getExports,
  parseDeclarative: () => parseDeclarative
});
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  await initSync(
    "https://cdn.jsdelivr.net/npm/@swc/wasm-web@1.7.3/wasm_bg.wasm"
  );
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function parseDeclarative(code) {
  sourceCode = code;
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const importStmt = val.body.filter((it) => it.type === "ImportDeclaration");
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: importStmt.filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
      (it) => ({
        isTypeOnly: it.typeOnly,
        moduleSpecifier: it.source.value,
        defaultImport: it.specifiers.find(
          (sp) => sp.type === "ImportDefaultSpecifier"
        )?.local.value,
        namespaceImport: it.specifiers.find(
          (sp) => sp.type === "ImportNamespaceSpecifier"
        )?.local.value,
        namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
          (sp) => ({
            name: sp.imported ? sp.imported.value : sp.local.value,
            alias: sp.imported ? sp.local.value : void 0,
            isTypeOnly: sp.isTypeOnly
          })
        )
      })
    ),
    project: resolveCallExpression(projectExpr.expression)
  };
}
function resolveAsExpression(node) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression));
  }
  return args;
}
function resolveCallExpression(node) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression));
    }
  }
  return list;
}
function resolveObjectExpression(node, key) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
async function getExports(code) {
  const ast = await parseCode(code);
  if (!ast) {
    return [];
  }
  return ast.body.filter(isExportItem);
}
var checker, Checker, isWorker, sourceCode, exportTypes;
var init_src = __esm({
  "libs/sdk/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      __name(isKeyValueProperty, "isKeyValueProperty");
      function isStringLiteral(node) {
        return node.type === "StringLiteral";
      }
      checker2.isStringLiteral = isStringLiteral;
      __name(isStringLiteral, "isStringLiteral");
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      __name(isNullLiteral, "isNullLiteral");
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      __name(isIdentifier, "isIdentifier");
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      __name(isMemberExpression, "isMemberExpression");
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(Checker || (Checker = {}));
    isWorker = /* @__PURE__ */ __name(() => {
      return typeof global.importScripts === "function";
    }, "isWorker");
    __name(isRecord, "isRecord");
    __name(isSpan, "isSpan");
    __name(adjustOffsetOfAst, "adjustOffsetOfAst");
    __name(parseCode, "parseCode");
    __name(parseDeclarative, "parseDeclarative");
    __name(resolveAsExpression, "resolveAsExpression");
    __name(resolveCallExpression, "resolveCallExpression");
    __name(resolveUnaryExpression, "resolveUnaryExpression");
    __name(resolveArrayExpression, "resolveArrayExpression");
    __name(resolveObjectExpression, "resolveObjectExpression");
    __name(resolveMemberExpression, "resolveMemberExpression");
    exportTypes = [
      "ExportAllDeclaration",
      "ExportDeclaration",
      "ExportDefaultDeclaration",
      "ExportDefaultExpression",
      "ExportNamedDeclaration",
      "ImportDeclaration"
    ];
    __name(isExportItem, "isExportItem");
    __name(getExports, "getExports");
  }
});

// node_modules/simple-git/dist/esm/index.js
var import_file_exists = __toESM(require_dist(), 1);
var import_debug = __toESM(require_src(), 1);
var import_promise_deferred = __toESM(require_dist2(), 1);
var import_promise_deferred2 = __toESM(require_dist2(), 1);
var __defProp2 = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = /* @__PURE__ */ __name((obj, key, value) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value, "__defNormalProp");
var __spreadValues = /* @__PURE__ */ __name((a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp2.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
}, "__spreadValues");
var __spreadProps = /* @__PURE__ */ __name((a, b) => __defProps(a, __getOwnPropDescs(b)), "__spreadProps");
var __esm2 = /* @__PURE__ */ __name((fn, res) => /* @__PURE__ */ __name(function __init() {
  return fn && (res = (0, fn[__getOwnPropNames2(fn)[0]])(fn = 0)), res;
}, "__init"), "__esm");
var __commonJS2 = /* @__PURE__ */ __name((cb, mod) => /* @__PURE__ */ __name(function __require2() {
  return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
}, "__require"), "__commonJS");
var __export2 = /* @__PURE__ */ __name((target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
}, "__export");
var __copyProps2 = /* @__PURE__ */ __name((to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp2.call(to, key) && key !== except)
        __defProp2(to, key, { get: /* @__PURE__ */ __name(() => from[key], "get"), enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
  }
  return to;
}, "__copyProps");
var __toCommonJS = /* @__PURE__ */ __name((mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod), "__toCommonJS");
var __async = /* @__PURE__ */ __name((__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = /* @__PURE__ */ __name((value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }, "fulfilled");
    var rejected = /* @__PURE__ */ __name((value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    }, "rejected");
    var step = /* @__PURE__ */ __name((x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected), "step");
    step((generator = generator.apply(__this, __arguments)).next());
  });
}, "__async");
function pathspec(...paths) {
  const key = new String(paths);
  cache.set(key, paths);
  return key;
}
__name(pathspec, "pathspec");
function isPathSpec(path) {
  return path instanceof String && cache.has(path);
}
__name(isPathSpec, "isPathSpec");
function toPaths(pathSpec) {
  return cache.get(pathSpec) || [];
}
__name(toPaths, "toPaths");
var cache;
var init_pathspec = __esm2({
  "src/lib/args/pathspec.ts"() {
    "use strict";
    cache = /* @__PURE__ */ new WeakMap();
  }
});
var GitError;
var init_git_error = __esm2({
  "src/lib/errors/git-error.ts"() {
    "use strict";
    GitError = class extends Error {
      static {
        __name(this, "GitError");
      }
      constructor(task, message) {
        super(message);
        this.task = task;
        Object.setPrototypeOf(this, new.target.prototype);
      }
    };
  }
});
var GitResponseError;
var init_git_response_error = __esm2({
  "src/lib/errors/git-response-error.ts"() {
    "use strict";
    init_git_error();
    GitResponseError = class extends GitError {
      static {
        __name(this, "GitResponseError");
      }
      constructor(git, message) {
        super(void 0, message || String(git));
        this.git = git;
      }
    };
  }
});
var TaskConfigurationError;
var init_task_configuration_error = __esm2({
  "src/lib/errors/task-configuration-error.ts"() {
    "use strict";
    init_git_error();
    TaskConfigurationError = class extends GitError {
      static {
        __name(this, "TaskConfigurationError");
      }
      constructor(message) {
        super(void 0, message);
      }
    };
  }
});
function asFunction(source) {
  return typeof source === "function" ? source : NOOP;
}
__name(asFunction, "asFunction");
function isUserFunction(source) {
  return typeof source === "function" && source !== NOOP;
}
__name(isUserFunction, "isUserFunction");
function splitOn(input, char) {
  const index = input.indexOf(char);
  if (index <= 0) {
    return [input, ""];
  }
  return [input.substr(0, index), input.substr(index + 1)];
}
__name(splitOn, "splitOn");
function first(input, offset = 0) {
  return isArrayLike(input) && input.length > offset ? input[offset] : void 0;
}
__name(first, "first");
function last(input, offset = 0) {
  if (isArrayLike(input) && input.length > offset) {
    return input[input.length - 1 - offset];
  }
}
__name(last, "last");
function isArrayLike(input) {
  return !!(input && typeof input.length === "number");
}
__name(isArrayLike, "isArrayLike");
function toLinesWithContent(input = "", trimmed2 = true, separator = "\n") {
  return input.split(separator).reduce((output, line) => {
    const lineContent = trimmed2 ? line.trim() : line;
    if (lineContent) {
      output.push(lineContent);
    }
    return output;
  }, []);
}
__name(toLinesWithContent, "toLinesWithContent");
function forEachLineWithContent(input, callback) {
  return toLinesWithContent(input, true).map((line) => callback(line));
}
__name(forEachLineWithContent, "forEachLineWithContent");
function folderExists(path) {
  return (0, import_file_exists.exists)(path, import_file_exists.FOLDER);
}
__name(folderExists, "folderExists");
function append(target, item) {
  if (Array.isArray(target)) {
    if (!target.includes(item)) {
      target.push(item);
    }
  } else {
    target.add(item);
  }
  return item;
}
__name(append, "append");
function including(target, item) {
  if (Array.isArray(target) && !target.includes(item)) {
    target.push(item);
  }
  return target;
}
__name(including, "including");
function remove(target, item) {
  if (Array.isArray(target)) {
    const index = target.indexOf(item);
    if (index >= 0) {
      target.splice(index, 1);
    }
  } else {
    target.delete(item);
  }
  return item;
}
__name(remove, "remove");
function asArray(source) {
  return Array.isArray(source) ? source : [source];
}
__name(asArray, "asArray");
function asCamelCase(str) {
  return str.replace(/[\s-]+(.)/g, (_all, chr) => {
    return chr.toUpperCase();
  });
}
__name(asCamelCase, "asCamelCase");
function asStringArray(source) {
  return asArray(source).map(String);
}
__name(asStringArray, "asStringArray");
function asNumber(source, onNaN = 0) {
  if (source == null) {
    return onNaN;
  }
  const num = parseInt(source, 10);
  return isNaN(num) ? onNaN : num;
}
__name(asNumber, "asNumber");
function prefixedArray(input, prefix) {
  const output = [];
  for (let i = 0, max = input.length; i < max; i++) {
    output.push(prefix, input[i]);
  }
  return output;
}
__name(prefixedArray, "prefixedArray");
function bufferToString(input) {
  return (Array.isArray(input) ? Buffer.concat(input) : input).toString("utf-8");
}
__name(bufferToString, "bufferToString");
function pick(source, properties) {
  return Object.assign(
    {},
    ...properties.map((property) => property in source ? { [property]: source[property] } : {})
  );
}
__name(pick, "pick");
function delay(duration = 0) {
  return new Promise((done) => setTimeout(done, duration));
}
__name(delay, "delay");
function orVoid(input) {
  if (input === false) {
    return void 0;
  }
  return input;
}
__name(orVoid, "orVoid");
var NULL, NOOP, objectToString;
var init_util = __esm2({
  "src/lib/utils/util.ts"() {
    "use strict";
    NULL = "\0";
    NOOP = /* @__PURE__ */ __name(() => {
    }, "NOOP");
    objectToString = Object.prototype.toString.call.bind(Object.prototype.toString);
  }
});
function filterType(input, filter, def) {
  if (filter(input)) {
    return input;
  }
  return arguments.length > 2 ? def : void 0;
}
__name(filterType, "filterType");
function filterPrimitives(input, omit) {
  const type = isPathSpec(input) ? "string" : typeof input;
  return /number|string|boolean/.test(type) && (!omit || !omit.includes(type));
}
__name(filterPrimitives, "filterPrimitives");
function filterPlainObject(input) {
  return !!input && objectToString(input) === "[object Object]";
}
__name(filterPlainObject, "filterPlainObject");
function filterFunction(input) {
  return typeof input === "function";
}
__name(filterFunction, "filterFunction");
var filterArray, filterString, filterStringArray, filterStringOrStringArray, filterHasLength;
var init_argument_filters = __esm2({
  "src/lib/utils/argument-filters.ts"() {
    "use strict";
    init_util();
    init_pathspec();
    filterArray = /* @__PURE__ */ __name((input) => {
      return Array.isArray(input);
    }, "filterArray");
    filterString = /* @__PURE__ */ __name((input) => {
      return typeof input === "string";
    }, "filterString");
    filterStringArray = /* @__PURE__ */ __name((input) => {
      return Array.isArray(input) && input.every(filterString);
    }, "filterStringArray");
    filterStringOrStringArray = /* @__PURE__ */ __name((input) => {
      return filterString(input) || Array.isArray(input) && input.every(filterString);
    }, "filterStringOrStringArray");
    filterHasLength = /* @__PURE__ */ __name((input) => {
      if (input == null || "number|boolean|function".includes(typeof input)) {
        return false;
      }
      return Array.isArray(input) || typeof input === "string" || typeof input.length === "number";
    }, "filterHasLength");
  }
});
var ExitCodes;
var init_exit_codes = __esm2({
  "src/lib/utils/exit-codes.ts"() {
    "use strict";
    ExitCodes = /* @__PURE__ */ ((ExitCodes2) => {
      ExitCodes2[ExitCodes2["SUCCESS"] = 0] = "SUCCESS";
      ExitCodes2[ExitCodes2["ERROR"] = 1] = "ERROR";
      ExitCodes2[ExitCodes2["NOT_FOUND"] = -2] = "NOT_FOUND";
      ExitCodes2[ExitCodes2["UNCLEAN"] = 128] = "UNCLEAN";
      return ExitCodes2;
    })(ExitCodes || {});
  }
});
var GitOutputStreams;
var init_git_output_streams = __esm2({
  "src/lib/utils/git-output-streams.ts"() {
    "use strict";
    GitOutputStreams = class {
      static {
        __name(this, "GitOutputStreams");
      }
      constructor(stdOut, stdErr) {
        this.stdOut = stdOut;
        this.stdErr = stdErr;
      }
      asStrings() {
        return new GitOutputStreams(this.stdOut.toString("utf8"), this.stdErr.toString("utf8"));
      }
    };
  }
});
var LineParser, RemoteLineParser;
var init_line_parser = __esm2({
  "src/lib/utils/line-parser.ts"() {
    "use strict";
    LineParser = class {
      static {
        __name(this, "LineParser");
      }
      constructor(regExp, useMatches) {
        this.matches = [];
        this.parse = (line, target) => {
          this.resetMatches();
          if (!this._regExp.every((reg, index) => this.addMatch(reg, index, line(index)))) {
            return false;
          }
          return this.useMatches(target, this.prepareMatches()) !== false;
        };
        this._regExp = Array.isArray(regExp) ? regExp : [regExp];
        if (useMatches) {
          this.useMatches = useMatches;
        }
      }
      useMatches(target, match) {
        throw new Error(`LineParser:useMatches not implemented`);
      }
      resetMatches() {
        this.matches.length = 0;
      }
      prepareMatches() {
        return this.matches;
      }
      addMatch(reg, index, line) {
        const matched = line && reg.exec(line);
        if (matched) {
          this.pushMatch(index, matched);
        }
        return !!matched;
      }
      pushMatch(_index, matched) {
        this.matches.push(...matched.slice(1));
      }
    };
    RemoteLineParser = class extends LineParser {
      static {
        __name(this, "RemoteLineParser");
      }
      addMatch(reg, index, line) {
        return /^remote:\s/.test(String(line)) && super.addMatch(reg, index, line);
      }
      pushMatch(index, matched) {
        if (index > 0 || matched.length > 1) {
          super.pushMatch(index, matched);
        }
      }
    };
  }
});
function createInstanceConfig(...options) {
  const baseDir = process.cwd();
  const config = Object.assign(
    __spreadValues({ baseDir }, defaultOptions),
    ...options.filter((o) => typeof o === "object" && o)
  );
  config.baseDir = config.baseDir || baseDir;
  config.trimmed = config.trimmed === true;
  return config;
}
__name(createInstanceConfig, "createInstanceConfig");
var defaultOptions;
var init_simple_git_options = __esm2({
  "src/lib/utils/simple-git-options.ts"() {
    "use strict";
    defaultOptions = {
      binary: "git",
      maxConcurrentProcesses: 5,
      config: [],
      trimmed: false
    };
  }
});
function appendTaskOptions(options, commands = []) {
  if (!filterPlainObject(options)) {
    return commands;
  }
  return Object.keys(options).reduce((commands2, key) => {
    const value = options[key];
    if (isPathSpec(value)) {
      commands2.push(value);
    } else if (filterPrimitives(value, ["boolean"])) {
      commands2.push(key + "=" + value);
    } else {
      commands2.push(key);
    }
    return commands2;
  }, commands);
}
__name(appendTaskOptions, "appendTaskOptions");
function getTrailingOptions(args, initialPrimitive = 0, objectOnly = false) {
  const command = [];
  for (let i = 0, max = initialPrimitive < 0 ? args.length : initialPrimitive; i < max; i++) {
    if ("string|number".includes(typeof args[i])) {
      command.push(String(args[i]));
    }
  }
  appendTaskOptions(trailingOptionsArgument(args), command);
  if (!objectOnly) {
    command.push(...trailingArrayArgument(args));
  }
  return command;
}
__name(getTrailingOptions, "getTrailingOptions");
function trailingArrayArgument(args) {
  const hasTrailingCallback = typeof last(args) === "function";
  return filterType(last(args, hasTrailingCallback ? 1 : 0), filterArray, []);
}
__name(trailingArrayArgument, "trailingArrayArgument");
function trailingOptionsArgument(args) {
  const hasTrailingCallback = filterFunction(last(args));
  return filterType(last(args, hasTrailingCallback ? 1 : 0), filterPlainObject);
}
__name(trailingOptionsArgument, "trailingOptionsArgument");
function trailingFunctionArgument(args, includeNoop = true) {
  const callback = asFunction(last(args));
  return includeNoop || isUserFunction(callback) ? callback : void 0;
}
__name(trailingFunctionArgument, "trailingFunctionArgument");
var init_task_options = __esm2({
  "src/lib/utils/task-options.ts"() {
    "use strict";
    init_argument_filters();
    init_util();
    init_pathspec();
  }
});
function callTaskParser(parser4, streams) {
  return parser4(streams.stdOut, streams.stdErr);
}
__name(callTaskParser, "callTaskParser");
function parseStringResponse(result, parsers12, texts, trim = true) {
  asArray(texts).forEach((text) => {
    for (let lines = toLinesWithContent(text, trim), i = 0, max = lines.length; i < max; i++) {
      const line = /* @__PURE__ */ __name((offset = 0) => {
        if (i + offset >= max) {
          return;
        }
        return lines[i + offset];
      }, "line");
      parsers12.some(({ parse }) => parse(line, result));
    }
  });
  return result;
}
__name(parseStringResponse, "parseStringResponse");
var init_task_parser = __esm2({
  "src/lib/utils/task-parser.ts"() {
    "use strict";
    init_util();
  }
});
var utils_exports = {};
__export2(utils_exports, {
  ExitCodes: /* @__PURE__ */ __name(() => ExitCodes, "ExitCodes"),
  GitOutputStreams: /* @__PURE__ */ __name(() => GitOutputStreams, "GitOutputStreams"),
  LineParser: /* @__PURE__ */ __name(() => LineParser, "LineParser"),
  NOOP: /* @__PURE__ */ __name(() => NOOP, "NOOP"),
  NULL: /* @__PURE__ */ __name(() => NULL, "NULL"),
  RemoteLineParser: /* @__PURE__ */ __name(() => RemoteLineParser, "RemoteLineParser"),
  append: /* @__PURE__ */ __name(() => append, "append"),
  appendTaskOptions: /* @__PURE__ */ __name(() => appendTaskOptions, "appendTaskOptions"),
  asArray: /* @__PURE__ */ __name(() => asArray, "asArray"),
  asCamelCase: /* @__PURE__ */ __name(() => asCamelCase, "asCamelCase"),
  asFunction: /* @__PURE__ */ __name(() => asFunction, "asFunction"),
  asNumber: /* @__PURE__ */ __name(() => asNumber, "asNumber"),
  asStringArray: /* @__PURE__ */ __name(() => asStringArray, "asStringArray"),
  bufferToString: /* @__PURE__ */ __name(() => bufferToString, "bufferToString"),
  callTaskParser: /* @__PURE__ */ __name(() => callTaskParser, "callTaskParser"),
  createInstanceConfig: /* @__PURE__ */ __name(() => createInstanceConfig, "createInstanceConfig"),
  delay: /* @__PURE__ */ __name(() => delay, "delay"),
  filterArray: /* @__PURE__ */ __name(() => filterArray, "filterArray"),
  filterFunction: /* @__PURE__ */ __name(() => filterFunction, "filterFunction"),
  filterHasLength: /* @__PURE__ */ __name(() => filterHasLength, "filterHasLength"),
  filterPlainObject: /* @__PURE__ */ __name(() => filterPlainObject, "filterPlainObject"),
  filterPrimitives: /* @__PURE__ */ __name(() => filterPrimitives, "filterPrimitives"),
  filterString: /* @__PURE__ */ __name(() => filterString, "filterString"),
  filterStringArray: /* @__PURE__ */ __name(() => filterStringArray, "filterStringArray"),
  filterStringOrStringArray: /* @__PURE__ */ __name(() => filterStringOrStringArray, "filterStringOrStringArray"),
  filterType: /* @__PURE__ */ __name(() => filterType, "filterType"),
  first: /* @__PURE__ */ __name(() => first, "first"),
  folderExists: /* @__PURE__ */ __name(() => folderExists, "folderExists"),
  forEachLineWithContent: /* @__PURE__ */ __name(() => forEachLineWithContent, "forEachLineWithContent"),
  getTrailingOptions: /* @__PURE__ */ __name(() => getTrailingOptions, "getTrailingOptions"),
  including: /* @__PURE__ */ __name(() => including, "including"),
  isUserFunction: /* @__PURE__ */ __name(() => isUserFunction, "isUserFunction"),
  last: /* @__PURE__ */ __name(() => last, "last"),
  objectToString: /* @__PURE__ */ __name(() => objectToString, "objectToString"),
  orVoid: /* @__PURE__ */ __name(() => orVoid, "orVoid"),
  parseStringResponse: /* @__PURE__ */ __name(() => parseStringResponse, "parseStringResponse"),
  pick: /* @__PURE__ */ __name(() => pick, "pick"),
  prefixedArray: /* @__PURE__ */ __name(() => prefixedArray, "prefixedArray"),
  remove: /* @__PURE__ */ __name(() => remove, "remove"),
  splitOn: /* @__PURE__ */ __name(() => splitOn, "splitOn"),
  toLinesWithContent: /* @__PURE__ */ __name(() => toLinesWithContent, "toLinesWithContent"),
  trailingFunctionArgument: /* @__PURE__ */ __name(() => trailingFunctionArgument, "trailingFunctionArgument"),
  trailingOptionsArgument: /* @__PURE__ */ __name(() => trailingOptionsArgument, "trailingOptionsArgument")
});
var init_utils = __esm2({
  "src/lib/utils/index.ts"() {
    "use strict";
    init_argument_filters();
    init_exit_codes();
    init_git_output_streams();
    init_line_parser();
    init_simple_git_options();
    init_task_options();
    init_task_parser();
    init_util();
  }
});
var check_is_repo_exports = {};
__export2(check_is_repo_exports, {
  CheckRepoActions: /* @__PURE__ */ __name(() => CheckRepoActions, "CheckRepoActions"),
  checkIsBareRepoTask: /* @__PURE__ */ __name(() => checkIsBareRepoTask, "checkIsBareRepoTask"),
  checkIsRepoRootTask: /* @__PURE__ */ __name(() => checkIsRepoRootTask, "checkIsRepoRootTask"),
  checkIsRepoTask: /* @__PURE__ */ __name(() => checkIsRepoTask, "checkIsRepoTask")
});
function checkIsRepoTask(action) {
  switch (action) {
    case "bare":
      return checkIsBareRepoTask();
    case "root":
      return checkIsRepoRootTask();
  }
  const commands = ["rev-parse", "--is-inside-work-tree"];
  return {
    commands,
    format: "utf-8",
    onError,
    parser
  };
}
__name(checkIsRepoTask, "checkIsRepoTask");
function checkIsRepoRootTask() {
  const commands = ["rev-parse", "--git-dir"];
  return {
    commands,
    format: "utf-8",
    onError,
    parser(path) {
      return /^\.(git)?$/.test(path.trim());
    }
  };
}
__name(checkIsRepoRootTask, "checkIsRepoRootTask");
function checkIsBareRepoTask() {
  const commands = ["rev-parse", "--is-bare-repository"];
  return {
    commands,
    format: "utf-8",
    onError,
    parser
  };
}
__name(checkIsBareRepoTask, "checkIsBareRepoTask");
function isNotRepoMessage(error) {
  return /(Not a git repository|Kein Git-Repository)/i.test(String(error));
}
__name(isNotRepoMessage, "isNotRepoMessage");
var CheckRepoActions, onError, parser;
var init_check_is_repo = __esm2({
  "src/lib/tasks/check-is-repo.ts"() {
    "use strict";
    init_utils();
    CheckRepoActions = /* @__PURE__ */ ((CheckRepoActions2) => {
      CheckRepoActions2["BARE"] = "bare";
      CheckRepoActions2["IN_TREE"] = "tree";
      CheckRepoActions2["IS_REPO_ROOT"] = "root";
      return CheckRepoActions2;
    })(CheckRepoActions || {});
    onError = /* @__PURE__ */ __name(({ exitCode }, error, done, fail) => {
      if (exitCode === 128 && isNotRepoMessage(error)) {
        return done(Buffer.from("false"));
      }
      fail(error);
    }, "onError");
    parser = /* @__PURE__ */ __name((text) => {
      return text.trim() === "true";
    }, "parser");
  }
});
function cleanSummaryParser(dryRun, text) {
  const summary = new CleanResponse(dryRun);
  const regexp = dryRun ? dryRunRemovalRegexp : removalRegexp;
  toLinesWithContent(text).forEach((line) => {
    const removed = line.replace(regexp, "");
    summary.paths.push(removed);
    (isFolderRegexp.test(removed) ? summary.folders : summary.files).push(removed);
  });
  return summary;
}
__name(cleanSummaryParser, "cleanSummaryParser");
var CleanResponse, removalRegexp, dryRunRemovalRegexp, isFolderRegexp;
var init_CleanSummary = __esm2({
  "src/lib/responses/CleanSummary.ts"() {
    "use strict";
    init_utils();
    CleanResponse = class {
      static {
        __name(this, "CleanResponse");
      }
      constructor(dryRun) {
        this.dryRun = dryRun;
        this.paths = [];
        this.files = [];
        this.folders = [];
      }
    };
    removalRegexp = /^[a-z]+\s*/i;
    dryRunRemovalRegexp = /^[a-z]+\s+[a-z]+\s*/i;
    isFolderRegexp = /\/$/;
  }
});
var task_exports = {};
__export2(task_exports, {
  EMPTY_COMMANDS: /* @__PURE__ */ __name(() => EMPTY_COMMANDS, "EMPTY_COMMANDS"),
  adhocExecTask: /* @__PURE__ */ __name(() => adhocExecTask, "adhocExecTask"),
  configurationErrorTask: /* @__PURE__ */ __name(() => configurationErrorTask, "configurationErrorTask"),
  isBufferTask: /* @__PURE__ */ __name(() => isBufferTask, "isBufferTask"),
  isEmptyTask: /* @__PURE__ */ __name(() => isEmptyTask, "isEmptyTask"),
  straightThroughBufferTask: /* @__PURE__ */ __name(() => straightThroughBufferTask, "straightThroughBufferTask"),
  straightThroughStringTask: /* @__PURE__ */ __name(() => straightThroughStringTask, "straightThroughStringTask")
});
function adhocExecTask(parser4) {
  return {
    commands: EMPTY_COMMANDS,
    format: "empty",
    parser: parser4
  };
}
__name(adhocExecTask, "adhocExecTask");
function configurationErrorTask(error) {
  return {
    commands: EMPTY_COMMANDS,
    format: "empty",
    parser() {
      throw typeof error === "string" ? new TaskConfigurationError(error) : error;
    }
  };
}
__name(configurationErrorTask, "configurationErrorTask");
function straightThroughStringTask(commands, trimmed2 = false) {
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return trimmed2 ? String(text).trim() : text;
    }
  };
}
__name(straightThroughStringTask, "straightThroughStringTask");
function straightThroughBufferTask(commands) {
  return {
    commands,
    format: "buffer",
    parser(buffer) {
      return buffer;
    }
  };
}
__name(straightThroughBufferTask, "straightThroughBufferTask");
function isBufferTask(task) {
  return task.format === "buffer";
}
__name(isBufferTask, "isBufferTask");
function isEmptyTask(task) {
  return task.format === "empty" || !task.commands.length;
}
__name(isEmptyTask, "isEmptyTask");
var EMPTY_COMMANDS;
var init_task = __esm2({
  "src/lib/tasks/task.ts"() {
    "use strict";
    init_task_configuration_error();
    EMPTY_COMMANDS = [];
  }
});
var clean_exports = {};
__export2(clean_exports, {
  CONFIG_ERROR_INTERACTIVE_MODE: /* @__PURE__ */ __name(() => CONFIG_ERROR_INTERACTIVE_MODE, "CONFIG_ERROR_INTERACTIVE_MODE"),
  CONFIG_ERROR_MODE_REQUIRED: /* @__PURE__ */ __name(() => CONFIG_ERROR_MODE_REQUIRED, "CONFIG_ERROR_MODE_REQUIRED"),
  CONFIG_ERROR_UNKNOWN_OPTION: /* @__PURE__ */ __name(() => CONFIG_ERROR_UNKNOWN_OPTION, "CONFIG_ERROR_UNKNOWN_OPTION"),
  CleanOptions: /* @__PURE__ */ __name(() => CleanOptions, "CleanOptions"),
  cleanTask: /* @__PURE__ */ __name(() => cleanTask, "cleanTask"),
  cleanWithOptionsTask: /* @__PURE__ */ __name(() => cleanWithOptionsTask, "cleanWithOptionsTask"),
  isCleanOptionsArray: /* @__PURE__ */ __name(() => isCleanOptionsArray, "isCleanOptionsArray")
});
function cleanWithOptionsTask(mode, customArgs) {
  const { cleanMode, options, valid } = getCleanOptions(mode);
  if (!cleanMode) {
    return configurationErrorTask(CONFIG_ERROR_MODE_REQUIRED);
  }
  if (!valid.options) {
    return configurationErrorTask(CONFIG_ERROR_UNKNOWN_OPTION + JSON.stringify(mode));
  }
  options.push(...customArgs);
  if (options.some(isInteractiveMode)) {
    return configurationErrorTask(CONFIG_ERROR_INTERACTIVE_MODE);
  }
  return cleanTask(cleanMode, options);
}
__name(cleanWithOptionsTask, "cleanWithOptionsTask");
function cleanTask(mode, customArgs) {
  const commands = ["clean", `-${mode}`, ...customArgs];
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return cleanSummaryParser(mode === "n", text);
    }
  };
}
__name(cleanTask, "cleanTask");
function isCleanOptionsArray(input) {
  return Array.isArray(input) && input.every((test) => CleanOptionValues.has(test));
}
__name(isCleanOptionsArray, "isCleanOptionsArray");
function getCleanOptions(input) {
  let cleanMode;
  let options = [];
  let valid = { cleanMode: false, options: true };
  input.replace(/[^a-z]i/g, "").split("").forEach((char) => {
    if (isCleanMode(char)) {
      cleanMode = char;
      valid.cleanMode = true;
    } else {
      valid.options = valid.options && isKnownOption(options[options.length] = `-${char}`);
    }
  });
  return {
    cleanMode,
    options,
    valid
  };
}
__name(getCleanOptions, "getCleanOptions");
function isCleanMode(cleanMode) {
  return cleanMode === "f" || cleanMode === "n";
}
__name(isCleanMode, "isCleanMode");
function isKnownOption(option) {
  return /^-[a-z]$/i.test(option) && CleanOptionValues.has(option.charAt(1));
}
__name(isKnownOption, "isKnownOption");
function isInteractiveMode(option) {
  if (/^-[^\-]/.test(option)) {
    return option.indexOf("i") > 0;
  }
  return option === "--interactive";
}
__name(isInteractiveMode, "isInteractiveMode");
var CONFIG_ERROR_INTERACTIVE_MODE, CONFIG_ERROR_MODE_REQUIRED, CONFIG_ERROR_UNKNOWN_OPTION, CleanOptions, CleanOptionValues;
var init_clean = __esm2({
  "src/lib/tasks/clean.ts"() {
    "use strict";
    init_CleanSummary();
    init_utils();
    init_task();
    CONFIG_ERROR_INTERACTIVE_MODE = "Git clean interactive mode is not supported";
    CONFIG_ERROR_MODE_REQUIRED = 'Git clean mode parameter ("n" or "f") is required';
    CONFIG_ERROR_UNKNOWN_OPTION = "Git clean unknown option found in: ";
    CleanOptions = /* @__PURE__ */ ((CleanOptions2) => {
      CleanOptions2["DRY_RUN"] = "n";
      CleanOptions2["FORCE"] = "f";
      CleanOptions2["IGNORED_INCLUDED"] = "x";
      CleanOptions2["IGNORED_ONLY"] = "X";
      CleanOptions2["EXCLUDING"] = "e";
      CleanOptions2["QUIET"] = "q";
      CleanOptions2["RECURSIVE"] = "d";
      return CleanOptions2;
    })(CleanOptions || {});
    CleanOptionValues = /* @__PURE__ */ new Set([
      "i",
      ...asStringArray(Object.values(CleanOptions))
    ]);
  }
});
function configListParser(text) {
  const config = new ConfigList();
  for (const item of configParser(text)) {
    config.addValue(item.file, String(item.key), item.value);
  }
  return config;
}
__name(configListParser, "configListParser");
function configGetParser(text, key) {
  let value = null;
  const values = [];
  const scopes = /* @__PURE__ */ new Map();
  for (const item of configParser(text, key)) {
    if (item.key !== key) {
      continue;
    }
    values.push(value = item.value);
    if (!scopes.has(item.file)) {
      scopes.set(item.file, []);
    }
    scopes.get(item.file).push(value);
  }
  return {
    key,
    paths: Array.from(scopes.keys()),
    scopes,
    value,
    values
  };
}
__name(configGetParser, "configGetParser");
function configFilePath(filePath) {
  return filePath.replace(/^(file):/, "");
}
__name(configFilePath, "configFilePath");
function* configParser(text, requestedKey = null) {
  const lines = text.split("\0");
  for (let i = 0, max = lines.length - 1; i < max; ) {
    const file = configFilePath(lines[i++]);
    let value = lines[i++];
    let key = requestedKey;
    if (value.includes("\n")) {
      const line = splitOn(value, "\n");
      key = line[0];
      value = line[1];
    }
    yield { file, key, value };
  }
}
__name(configParser, "configParser");
var ConfigList;
var init_ConfigList = __esm2({
  "src/lib/responses/ConfigList.ts"() {
    "use strict";
    init_utils();
    ConfigList = class {
      static {
        __name(this, "ConfigList");
      }
      constructor() {
        this.files = [];
        this.values = /* @__PURE__ */ Object.create(null);
      }
      get all() {
        if (!this._all) {
          this._all = this.files.reduce((all, file) => {
            return Object.assign(all, this.values[file]);
          }, {});
        }
        return this._all;
      }
      addFile(file) {
        if (!(file in this.values)) {
          const latest = last(this.files);
          this.values[file] = latest ? Object.create(this.values[latest]) : {};
          this.files.push(file);
        }
        return this.values[file];
      }
      addValue(file, key, value) {
        const values = this.addFile(file);
        if (!values.hasOwnProperty(key)) {
          values[key] = value;
        } else if (Array.isArray(values[key])) {
          values[key].push(value);
        } else {
          values[key] = [values[key], value];
        }
        this._all = void 0;
      }
    };
  }
});
function asConfigScope(scope, fallback) {
  if (typeof scope === "string" && GitConfigScope.hasOwnProperty(scope)) {
    return scope;
  }
  return fallback;
}
__name(asConfigScope, "asConfigScope");
function addConfigTask(key, value, append2, scope) {
  const commands = ["config", `--${scope}`];
  if (append2) {
    commands.push("--add");
  }
  commands.push(key, value);
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return text;
    }
  };
}
__name(addConfigTask, "addConfigTask");
function getConfigTask(key, scope) {
  const commands = ["config", "--null", "--show-origin", "--get-all", key];
  if (scope) {
    commands.splice(1, 0, `--${scope}`);
  }
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return configGetParser(text, key);
    }
  };
}
__name(getConfigTask, "getConfigTask");
function listConfigTask(scope) {
  const commands = ["config", "--list", "--show-origin", "--null"];
  if (scope) {
    commands.push(`--${scope}`);
  }
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return configListParser(text);
    }
  };
}
__name(listConfigTask, "listConfigTask");
function config_default() {
  return {
    addConfig(key, value, ...rest) {
      return this._runTask(
        addConfigTask(
          key,
          value,
          rest[0] === true,
          asConfigScope(
            rest[1],
            "local"
            /* local */
          )
        ),
        trailingFunctionArgument(arguments)
      );
    },
    getConfig(key, scope) {
      return this._runTask(
        getConfigTask(key, asConfigScope(scope, void 0)),
        trailingFunctionArgument(arguments)
      );
    },
    listConfig(...rest) {
      return this._runTask(
        listConfigTask(asConfigScope(rest[0], void 0)),
        trailingFunctionArgument(arguments)
      );
    }
  };
}
__name(config_default, "config_default");
var GitConfigScope;
var init_config = __esm2({
  "src/lib/tasks/config.ts"() {
    "use strict";
    init_ConfigList();
    init_utils();
    GitConfigScope = /* @__PURE__ */ ((GitConfigScope2) => {
      GitConfigScope2["system"] = "system";
      GitConfigScope2["global"] = "global";
      GitConfigScope2["local"] = "local";
      GitConfigScope2["worktree"] = "worktree";
      return GitConfigScope2;
    })(GitConfigScope || {});
  }
});
function isDiffNameStatus(input) {
  return diffNameStatus.has(input);
}
__name(isDiffNameStatus, "isDiffNameStatus");
var DiffNameStatus, diffNameStatus;
var init_diff_name_status = __esm2({
  "src/lib/tasks/diff-name-status.ts"() {
    "use strict";
    DiffNameStatus = /* @__PURE__ */ ((DiffNameStatus2) => {
      DiffNameStatus2["ADDED"] = "A";
      DiffNameStatus2["COPIED"] = "C";
      DiffNameStatus2["DELETED"] = "D";
      DiffNameStatus2["MODIFIED"] = "M";
      DiffNameStatus2["RENAMED"] = "R";
      DiffNameStatus2["CHANGED"] = "T";
      DiffNameStatus2["UNMERGED"] = "U";
      DiffNameStatus2["UNKNOWN"] = "X";
      DiffNameStatus2["BROKEN"] = "B";
      return DiffNameStatus2;
    })(DiffNameStatus || {});
    diffNameStatus = new Set(Object.values(DiffNameStatus));
  }
});
function grepQueryBuilder(...params) {
  return new GrepQuery().param(...params);
}
__name(grepQueryBuilder, "grepQueryBuilder");
function parseGrep(grep) {
  const paths = /* @__PURE__ */ new Set();
  const results = {};
  forEachLineWithContent(grep, (input) => {
    const [path, line, preview] = input.split(NULL);
    paths.add(path);
    (results[path] = results[path] || []).push({
      line: asNumber(line),
      path,
      preview
    });
  });
  return {
    paths,
    results
  };
}
__name(parseGrep, "parseGrep");
function grep_default() {
  return {
    grep(searchTerm) {
      const then = trailingFunctionArgument(arguments);
      const options = getTrailingOptions(arguments);
      for (const option of disallowedOptions) {
        if (options.includes(option)) {
          return this._runTask(
            configurationErrorTask(`git.grep: use of "${option}" is not supported.`),
            then
          );
        }
      }
      if (typeof searchTerm === "string") {
        searchTerm = grepQueryBuilder().param(searchTerm);
      }
      const commands = ["grep", "--null", "-n", "--full-name", ...options, ...searchTerm];
      return this._runTask(
        {
          commands,
          format: "utf-8",
          parser(stdOut) {
            return parseGrep(stdOut);
          }
        },
        then
      );
    }
  };
}
__name(grep_default, "grep_default");
var disallowedOptions, Query, _a, GrepQuery;
var init_grep = __esm2({
  "src/lib/tasks/grep.ts"() {
    "use strict";
    init_utils();
    init_task();
    disallowedOptions = ["-h"];
    Query = Symbol("grepQuery");
    GrepQuery = class {
      static {
        __name(this, "GrepQuery");
      }
      constructor() {
        this[_a] = [];
      }
      *[(_a = Query, Symbol.iterator)]() {
        for (const query of this[Query]) {
          yield query;
        }
      }
      and(...and) {
        and.length && this[Query].push("--and", "(", ...prefixedArray(and, "-e"), ")");
        return this;
      }
      param(...param) {
        this[Query].push(...prefixedArray(param, "-e"));
        return this;
      }
    };
  }
});
var reset_exports = {};
__export2(reset_exports, {
  ResetMode: /* @__PURE__ */ __name(() => ResetMode, "ResetMode"),
  getResetMode: /* @__PURE__ */ __name(() => getResetMode, "getResetMode"),
  resetTask: /* @__PURE__ */ __name(() => resetTask, "resetTask")
});
function resetTask(mode, customArgs) {
  const commands = ["reset"];
  if (isValidResetMode(mode)) {
    commands.push(`--${mode}`);
  }
  commands.push(...customArgs);
  return straightThroughStringTask(commands);
}
__name(resetTask, "resetTask");
function getResetMode(mode) {
  if (isValidResetMode(mode)) {
    return mode;
  }
  switch (typeof mode) {
    case "string":
    case "undefined":
      return "soft";
  }
  return;
}
__name(getResetMode, "getResetMode");
function isValidResetMode(mode) {
  return ResetModes.includes(mode);
}
__name(isValidResetMode, "isValidResetMode");
var ResetMode, ResetModes;
var init_reset = __esm2({
  "src/lib/tasks/reset.ts"() {
    "use strict";
    init_task();
    ResetMode = /* @__PURE__ */ ((ResetMode2) => {
      ResetMode2["MIXED"] = "mixed";
      ResetMode2["SOFT"] = "soft";
      ResetMode2["HARD"] = "hard";
      ResetMode2["MERGE"] = "merge";
      ResetMode2["KEEP"] = "keep";
      return ResetMode2;
    })(ResetMode || {});
    ResetModes = Array.from(Object.values(ResetMode));
  }
});
function createLog() {
  return (0, import_debug.default)("simple-git");
}
__name(createLog, "createLog");
function prefixedLogger(to, prefix, forward) {
  if (!prefix || !String(prefix).replace(/\s*/, "")) {
    return !forward ? to : (message, ...args) => {
      to(message, ...args);
      forward(message, ...args);
    };
  }
  return (message, ...args) => {
    to(`%s ${message}`, prefix, ...args);
    if (forward) {
      forward(message, ...args);
    }
  };
}
__name(prefixedLogger, "prefixedLogger");
function childLoggerName(name, childDebugger, { namespace: parentNamespace }) {
  if (typeof name === "string") {
    return name;
  }
  const childNamespace = childDebugger && childDebugger.namespace || "";
  if (childNamespace.startsWith(parentNamespace)) {
    return childNamespace.substr(parentNamespace.length + 1);
  }
  return childNamespace || parentNamespace;
}
__name(childLoggerName, "childLoggerName");
function createLogger(label, verbose, initialStep, infoDebugger = createLog()) {
  const labelPrefix = label && `[${label}]` || "";
  const spawned = [];
  const debugDebugger = typeof verbose === "string" ? infoDebugger.extend(verbose) : verbose;
  const key = childLoggerName(filterType(verbose, filterString), debugDebugger, infoDebugger);
  return step(initialStep);
  function sibling(name, initial) {
    return append(
      spawned,
      createLogger(label, key.replace(/^[^:]+/, name), initial, infoDebugger)
    );
  }
  __name(sibling, "sibling");
  function step(phase) {
    const stepPrefix = phase && `[${phase}]` || "";
    const debug22 = debugDebugger && prefixedLogger(debugDebugger, stepPrefix) || NOOP;
    const info = prefixedLogger(infoDebugger, `${labelPrefix} ${stepPrefix}`, debug22);
    return Object.assign(debugDebugger ? debug22 : info, {
      label,
      sibling,
      info,
      step
    });
  }
  __name(step, "step");
}
__name(createLogger, "createLogger");
var init_git_logger = __esm2({
  "src/lib/git-logger.ts"() {
    "use strict";
    init_utils();
    import_debug.default.formatters.L = (value) => String(filterHasLength(value) ? value.length : "-");
    import_debug.default.formatters.B = (value) => {
      if (Buffer.isBuffer(value)) {
        return value.toString("utf8");
      }
      return objectToString(value);
    };
  }
});
var _TasksPendingQueue, TasksPendingQueue;
var init_tasks_pending_queue = __esm2({
  "src/lib/runners/tasks-pending-queue.ts"() {
    "use strict";
    init_git_error();
    init_git_logger();
    _TasksPendingQueue = class {
      static {
        __name(this, "_TasksPendingQueue");
      }
      constructor(logLabel = "GitExecutor") {
        this.logLabel = logLabel;
        this._queue = /* @__PURE__ */ new Map();
      }
      withProgress(task) {
        return this._queue.get(task);
      }
      createProgress(task) {
        const name = _TasksPendingQueue.getName(task.commands[0]);
        const logger = createLogger(this.logLabel, name);
        return {
          task,
          logger,
          name
        };
      }
      push(task) {
        const progress = this.createProgress(task);
        progress.logger("Adding task to the queue, commands = %o", task.commands);
        this._queue.set(task, progress);
        return progress;
      }
      fatal(err) {
        for (const [task, { logger }] of Array.from(this._queue.entries())) {
          if (task === err.task) {
            logger.info(`Failed %o`, err);
            logger(
              `Fatal exception, any as-yet un-started tasks run through this executor will not be attempted`
            );
          } else {
            logger.info(
              `A fatal exception occurred in a previous task, the queue has been purged: %o`,
              err.message
            );
          }
          this.complete(task);
        }
        if (this._queue.size !== 0) {
          throw new Error(`Queue size should be zero after fatal: ${this._queue.size}`);
        }
      }
      complete(task) {
        const progress = this.withProgress(task);
        if (progress) {
          this._queue.delete(task);
        }
      }
      attempt(task) {
        const progress = this.withProgress(task);
        if (!progress) {
          throw new GitError(void 0, "TasksPendingQueue: attempt called for an unknown task");
        }
        progress.logger("Starting task");
        return progress;
      }
      static getName(name = "empty") {
        return `task:${name}:${++_TasksPendingQueue.counter}`;
      }
    };
    TasksPendingQueue = _TasksPendingQueue;
    TasksPendingQueue.counter = 0;
  }
});
import { spawn } from "child_process";
function pluginContext(task, commands) {
  return {
    method: first(task.commands) || "",
    commands
  };
}
__name(pluginContext, "pluginContext");
function onErrorReceived(target, logger) {
  return (err) => {
    logger(`[ERROR] child process exception %o`, err);
    target.push(Buffer.from(String(err.stack), "ascii"));
  };
}
__name(onErrorReceived, "onErrorReceived");
function onDataReceived(target, name, logger, output) {
  return (buffer) => {
    logger(`%s received %L bytes`, name, buffer);
    output(`%B`, buffer);
    target.push(buffer);
  };
}
__name(onDataReceived, "onDataReceived");
var GitExecutorChain;
var init_git_executor_chain = __esm2({
  "src/lib/runners/git-executor-chain.ts"() {
    "use strict";
    init_git_error();
    init_task();
    init_utils();
    init_tasks_pending_queue();
    GitExecutorChain = class {
      static {
        __name(this, "GitExecutorChain");
      }
      constructor(_executor, _scheduler, _plugins) {
        this._executor = _executor;
        this._scheduler = _scheduler;
        this._plugins = _plugins;
        this._chain = Promise.resolve();
        this._queue = new TasksPendingQueue();
      }
      get cwd() {
        return this._cwd || this._executor.cwd;
      }
      set cwd(cwd) {
        this._cwd = cwd;
      }
      get env() {
        return this._executor.env;
      }
      get outputHandler() {
        return this._executor.outputHandler;
      }
      chain() {
        return this;
      }
      push(task) {
        this._queue.push(task);
        return this._chain = this._chain.then(() => this.attemptTask(task));
      }
      attemptTask(task) {
        return __async(this, null, function* () {
          const onScheduleComplete = yield this._scheduler.next();
          const onQueueComplete = /* @__PURE__ */ __name(() => this._queue.complete(task), "onQueueComplete");
          try {
            const { logger } = this._queue.attempt(task);
            return yield isEmptyTask(task) ? this.attemptEmptyTask(task, logger) : this.attemptRemoteTask(task, logger);
          } catch (e) {
            throw this.onFatalException(task, e);
          } finally {
            onQueueComplete();
            onScheduleComplete();
          }
        });
      }
      onFatalException(task, e) {
        const gitError = e instanceof GitError ? Object.assign(e, { task }) : new GitError(task, e && String(e));
        this._chain = Promise.resolve();
        this._queue.fatal(gitError);
        return gitError;
      }
      attemptRemoteTask(task, logger) {
        return __async(this, null, function* () {
          const binary = this._plugins.exec("spawn.binary", "", pluginContext(task, task.commands));
          const args = this._plugins.exec(
            "spawn.args",
            [...task.commands],
            pluginContext(task, task.commands)
          );
          const raw = yield this.gitResponse(
            task,
            binary,
            args,
            this.outputHandler,
            logger.step("SPAWN")
          );
          const outputStreams = yield this.handleTaskData(task, args, raw, logger.step("HANDLE"));
          logger(`passing response to task's parser as a %s`, task.format);
          if (isBufferTask(task)) {
            return callTaskParser(task.parser, outputStreams);
          }
          return callTaskParser(task.parser, outputStreams.asStrings());
        });
      }
      attemptEmptyTask(task, logger) {
        return __async(this, null, function* () {
          logger(`empty task bypassing child process to call to task's parser`);
          return task.parser(this);
        });
      }
      handleTaskData(task, args, result, logger) {
        const { exitCode, rejection, stdOut, stdErr } = result;
        return new Promise((done, fail) => {
          logger(`Preparing to handle process response exitCode=%d stdOut=`, exitCode);
          const { error } = this._plugins.exec(
            "task.error",
            { error: rejection },
            __spreadValues(__spreadValues({}, pluginContext(task, args)), result)
          );
          if (error && task.onError) {
            logger.info(`exitCode=%s handling with custom error handler`);
            return task.onError(
              result,
              error,
              (newStdOut) => {
                logger.info(`custom error handler treated as success`);
                logger(`custom error returned a %s`, objectToString(newStdOut));
                done(
                  new GitOutputStreams(
                    Array.isArray(newStdOut) ? Buffer.concat(newStdOut) : newStdOut,
                    Buffer.concat(stdErr)
                  )
                );
              },
              fail
            );
          }
          if (error) {
            logger.info(
              `handling as error: exitCode=%s stdErr=%s rejection=%o`,
              exitCode,
              stdErr.length,
              rejection
            );
            return fail(error);
          }
          logger.info(`retrieving task output complete`);
          done(new GitOutputStreams(Buffer.concat(stdOut), Buffer.concat(stdErr)));
        });
      }
      gitResponse(task, command, args, outputHandler, logger) {
        return __async(this, null, function* () {
          const outputLogger = logger.sibling("output");
          const spawnOptions = this._plugins.exec(
            "spawn.options",
            {
              cwd: this.cwd,
              env: this.env,
              windowsHide: true
            },
            pluginContext(task, task.commands)
          );
          return new Promise((done) => {
            const stdOut = [];
            const stdErr = [];
            logger.info(`%s %o`, command, args);
            logger("%O", spawnOptions);
            let rejection = this._beforeSpawn(task, args);
            if (rejection) {
              return done({
                stdOut,
                stdErr,
                exitCode: 9901,
                rejection
              });
            }
            this._plugins.exec("spawn.before", void 0, __spreadProps(__spreadValues({}, pluginContext(task, args)), {
              kill(reason) {
                rejection = reason || rejection;
              }
            }));
            const spawned = spawn(command, args, spawnOptions);
            spawned.stdout.on(
              "data",
              onDataReceived(stdOut, "stdOut", logger, outputLogger.step("stdOut"))
            );
            spawned.stderr.on(
              "data",
              onDataReceived(stdErr, "stdErr", logger, outputLogger.step("stdErr"))
            );
            spawned.on("error", onErrorReceived(stdErr, logger));
            if (outputHandler) {
              logger(`Passing child process stdOut/stdErr to custom outputHandler`);
              outputHandler(command, spawned.stdout, spawned.stderr, [...args]);
            }
            this._plugins.exec("spawn.after", void 0, __spreadProps(__spreadValues({}, pluginContext(task, args)), {
              spawned,
              close(exitCode, reason) {
                done({
                  stdOut,
                  stdErr,
                  exitCode,
                  rejection: rejection || reason
                });
              },
              kill(reason) {
                if (spawned.killed) {
                  return;
                }
                rejection = reason;
                spawned.kill("SIGINT");
              }
            }));
          });
        });
      }
      _beforeSpawn(task, args) {
        let rejection;
        this._plugins.exec("spawn.before", void 0, __spreadProps(__spreadValues({}, pluginContext(task, args)), {
          kill(reason) {
            rejection = reason || rejection;
          }
        }));
        return rejection;
      }
    };
  }
});
var git_executor_exports = {};
__export2(git_executor_exports, {
  GitExecutor: /* @__PURE__ */ __name(() => GitExecutor, "GitExecutor")
});
var GitExecutor;
var init_git_executor = __esm2({
  "src/lib/runners/git-executor.ts"() {
    "use strict";
    init_git_executor_chain();
    GitExecutor = class {
      static {
        __name(this, "GitExecutor");
      }
      constructor(cwd, _scheduler, _plugins) {
        this.cwd = cwd;
        this._scheduler = _scheduler;
        this._plugins = _plugins;
        this._chain = new GitExecutorChain(this, this._scheduler, this._plugins);
      }
      chain() {
        return new GitExecutorChain(this, this._scheduler, this._plugins);
      }
      push(task) {
        return this._chain.push(task);
      }
    };
  }
});
function taskCallback(task, response, callback = NOOP) {
  const onSuccess = /* @__PURE__ */ __name((data) => {
    callback(null, data);
  }, "onSuccess");
  const onError2 = /* @__PURE__ */ __name((err) => {
    if ((err == null ? void 0 : err.task) === task) {
      callback(
        err instanceof GitResponseError ? addDeprecationNoticeToError(err) : err,
        void 0
      );
    }
  }, "onError2");
  response.then(onSuccess, onError2);
}
__name(taskCallback, "taskCallback");
function addDeprecationNoticeToError(err) {
  let log = /* @__PURE__ */ __name((name) => {
    console.warn(
      `simple-git deprecation notice: accessing GitResponseError.${name} should be GitResponseError.git.${name}, this will no longer be available in version 3`
    );
    log = NOOP;
  }, "log");
  return Object.create(err, Object.getOwnPropertyNames(err.git).reduce(descriptorReducer, {}));
  function descriptorReducer(all, name) {
    if (name in err) {
      return all;
    }
    all[name] = {
      enumerable: false,
      configurable: false,
      get() {
        log(name);
        return err.git[name];
      }
    };
    return all;
  }
  __name(descriptorReducer, "descriptorReducer");
}
__name(addDeprecationNoticeToError, "addDeprecationNoticeToError");
var init_task_callback = __esm2({
  "src/lib/task-callback.ts"() {
    "use strict";
    init_git_response_error();
    init_utils();
  }
});
function changeWorkingDirectoryTask(directory, root) {
  return adhocExecTask((instance) => {
    if (!folderExists(directory)) {
      throw new Error(`Git.cwd: cannot change to non-directory "${directory}"`);
    }
    return (root || instance).cwd = directory;
  });
}
__name(changeWorkingDirectoryTask, "changeWorkingDirectoryTask");
var init_change_working_directory = __esm2({
  "src/lib/tasks/change-working-directory.ts"() {
    "use strict";
    init_utils();
    init_task();
  }
});
function checkoutTask(args) {
  const commands = ["checkout", ...args];
  if (commands[1] === "-b" && commands.includes("-B")) {
    commands[1] = remove(commands, "-B");
  }
  return straightThroughStringTask(commands);
}
__name(checkoutTask, "checkoutTask");
function checkout_default() {
  return {
    checkout() {
      return this._runTask(
        checkoutTask(getTrailingOptions(arguments, 1)),
        trailingFunctionArgument(arguments)
      );
    },
    checkoutBranch(branchName, startPoint) {
      return this._runTask(
        checkoutTask(["-b", branchName, startPoint, ...getTrailingOptions(arguments)]),
        trailingFunctionArgument(arguments)
      );
    },
    checkoutLocalBranch(branchName) {
      return this._runTask(
        checkoutTask(["-b", branchName, ...getTrailingOptions(arguments)]),
        trailingFunctionArgument(arguments)
      );
    }
  };
}
__name(checkout_default, "checkout_default");
var init_checkout = __esm2({
  "src/lib/tasks/checkout.ts"() {
    "use strict";
    init_utils();
    init_task();
  }
});
function countObjectsResponse() {
  return {
    count: 0,
    garbage: 0,
    inPack: 0,
    packs: 0,
    prunePackable: 0,
    size: 0,
    sizeGarbage: 0,
    sizePack: 0
  };
}
__name(countObjectsResponse, "countObjectsResponse");
function count_objects_default() {
  return {
    countObjects() {
      return this._runTask({
        commands: ["count-objects", "--verbose"],
        format: "utf-8",
        parser(stdOut) {
          return parseStringResponse(countObjectsResponse(), [parser2], stdOut);
        }
      });
    }
  };
}
__name(count_objects_default, "count_objects_default");
var parser2;
var init_count_objects = __esm2({
  "src/lib/tasks/count-objects.ts"() {
    "use strict";
    init_utils();
    parser2 = new LineParser(
      /([a-z-]+): (\d+)$/,
      (result, [key, value]) => {
        const property = asCamelCase(key);
        if (result.hasOwnProperty(property)) {
          result[property] = asNumber(value);
        }
      }
    );
  }
});
function parseCommitResult(stdOut) {
  const result = {
    author: null,
    branch: "",
    commit: "",
    root: false,
    summary: {
      changes: 0,
      insertions: 0,
      deletions: 0
    }
  };
  return parseStringResponse(result, parsers, stdOut);
}
__name(parseCommitResult, "parseCommitResult");
var parsers;
var init_parse_commit = __esm2({
  "src/lib/parsers/parse-commit.ts"() {
    "use strict";
    init_utils();
    parsers = [
      new LineParser(/^\[([^\s]+)( \([^)]+\))? ([^\]]+)/, (result, [branch, root, commit]) => {
        result.branch = branch;
        result.commit = commit;
        result.root = !!root;
      }),
      new LineParser(/\s*Author:\s(.+)/i, (result, [author]) => {
        const parts = author.split("<");
        const email = parts.pop();
        if (!email || !email.includes("@")) {
          return;
        }
        result.author = {
          email: email.substr(0, email.length - 1),
          name: parts.join("<").trim()
        };
      }),
      new LineParser(
        /(\d+)[^,]*(?:,\s*(\d+)[^,]*)(?:,\s*(\d+))/g,
        (result, [changes, insertions, deletions]) => {
          result.summary.changes = parseInt(changes, 10) || 0;
          result.summary.insertions = parseInt(insertions, 10) || 0;
          result.summary.deletions = parseInt(deletions, 10) || 0;
        }
      ),
      new LineParser(
        /^(\d+)[^,]*(?:,\s*(\d+)[^(]+\(([+-]))?/,
        (result, [changes, lines, direction]) => {
          result.summary.changes = parseInt(changes, 10) || 0;
          const count = parseInt(lines, 10) || 0;
          if (direction === "-") {
            result.summary.deletions = count;
          } else if (direction === "+") {
            result.summary.insertions = count;
          }
        }
      )
    ];
  }
});
function commitTask(message, files, customArgs) {
  const commands = [
    "-c",
    "core.abbrev=40",
    "commit",
    ...prefixedArray(message, "-m"),
    ...files,
    ...customArgs
  ];
  return {
    commands,
    format: "utf-8",
    parser: parseCommitResult
  };
}
__name(commitTask, "commitTask");
function commit_default() {
  return {
    commit(message, ...rest) {
      const next = trailingFunctionArgument(arguments);
      const task = rejectDeprecatedSignatures(message) || commitTask(
        asArray(message),
        asArray(filterType(rest[0], filterStringOrStringArray, [])),
        [...filterType(rest[1], filterArray, []), ...getTrailingOptions(arguments, 0, true)]
      );
      return this._runTask(task, next);
    }
  };
  function rejectDeprecatedSignatures(message) {
    return !filterStringOrStringArray(message) && configurationErrorTask(
      `git.commit: requires the commit message to be supplied as a string/string[]`
    );
  }
  __name(rejectDeprecatedSignatures, "rejectDeprecatedSignatures");
}
__name(commit_default, "commit_default");
var init_commit = __esm2({
  "src/lib/tasks/commit.ts"() {
    "use strict";
    init_parse_commit();
    init_utils();
    init_task();
  }
});
function first_commit_default() {
  return {
    firstCommit() {
      return this._runTask(
        straightThroughStringTask(["rev-list", "--max-parents=0", "HEAD"], true),
        trailingFunctionArgument(arguments)
      );
    }
  };
}
__name(first_commit_default, "first_commit_default");
var init_first_commit = __esm2({
  "src/lib/tasks/first-commit.ts"() {
    "use strict";
    init_utils();
    init_task();
  }
});
function hashObjectTask(filePath, write) {
  const commands = ["hash-object", filePath];
  if (write) {
    commands.push("-w");
  }
  return straightThroughStringTask(commands, true);
}
__name(hashObjectTask, "hashObjectTask");
var init_hash_object = __esm2({
  "src/lib/tasks/hash-object.ts"() {
    "use strict";
    init_task();
  }
});
function parseInit(bare, path, text) {
  const response = String(text).trim();
  let result;
  if (result = initResponseRegex.exec(response)) {
    return new InitSummary(bare, path, false, result[1]);
  }
  if (result = reInitResponseRegex.exec(response)) {
    return new InitSummary(bare, path, true, result[1]);
  }
  let gitDir = "";
  const tokens = response.split(" ");
  while (tokens.length) {
    const token = tokens.shift();
    if (token === "in") {
      gitDir = tokens.join(" ");
      break;
    }
  }
  return new InitSummary(bare, path, /^re/i.test(response), gitDir);
}
__name(parseInit, "parseInit");
var InitSummary, initResponseRegex, reInitResponseRegex;
var init_InitSummary = __esm2({
  "src/lib/responses/InitSummary.ts"() {
    "use strict";
    InitSummary = class {
      static {
        __name(this, "InitSummary");
      }
      constructor(bare, path, existing, gitDir) {
        this.bare = bare;
        this.path = path;
        this.existing = existing;
        this.gitDir = gitDir;
      }
    };
    initResponseRegex = /^Init.+ repository in (.+)$/;
    reInitResponseRegex = /^Rein.+ in (.+)$/;
  }
});
function hasBareCommand(command) {
  return command.includes(bareCommand);
}
__name(hasBareCommand, "hasBareCommand");
function initTask(bare = false, path, customArgs) {
  const commands = ["init", ...customArgs];
  if (bare && !hasBareCommand(commands)) {
    commands.splice(1, 0, bareCommand);
  }
  return {
    commands,
    format: "utf-8",
    parser(text) {
      return parseInit(commands.includes("--bare"), path, text);
    }
  };
}
__name(initTask, "initTask");
var bareCommand;
var init_init = __esm2({
  "src/lib/tasks/init.ts"() {
    "use strict";
    init_InitSummary();
    bareCommand = "--bare";
  }
});
function logFormatFromCommand(customArgs) {
  for (let i = 0; i < customArgs.length; i++) {
    const format = logFormatRegex.exec(customArgs[i]);
    if (format) {
      return `--${format[1]}`;
    }
  }
  return "";
}
__name(logFormatFromCommand, "logFormatFromCommand");
function isLogFormat(customArg) {
  return logFormatRegex.test(customArg);
}
__name(isLogFormat, "isLogFormat");
var logFormatRegex;
var init_log_format = __esm2({
  "src/lib/args/log-format.ts"() {
    "use strict";
    logFormatRegex = /^--(stat|numstat|name-only|name-status)(=|$)/;
  }
});
var DiffSummary;
var init_DiffSummary = __esm2({
  "src/lib/responses/DiffSummary.ts"() {
    "use strict";
    DiffSummary = class {
      static {
        __name(this, "DiffSummary");
      }
      constructor() {
        this.changed = 0;
        this.deletions = 0;
        this.insertions = 0;
        this.files = [];
      }
    };
  }
});
function getDiffParser(format = "") {
  const parser4 = diffSummaryParsers[format];
  return (stdOut) => parseStringResponse(new DiffSummary(), parser4, stdOut, false);
}
__name(getDiffParser, "getDiffParser");
var statParser, numStatParser, nameOnlyParser, nameStatusParser, diffSummaryParsers;
var init_parse_diff_summary = __esm2({
  "src/lib/parsers/parse-diff-summary.ts"() {
    "use strict";
    init_log_format();
    init_DiffSummary();
    init_diff_name_status();
    init_utils();
    statParser = [
      new LineParser(
        /^(.+)\s+\|\s+(\d+)(\s+[+\-]+)?$/,
        (result, [file, changes, alterations = ""]) => {
          result.files.push({
            file: file.trim(),
            changes: asNumber(changes),
            insertions: alterations.replace(/[^+]/g, "").length,
            deletions: alterations.replace(/[^-]/g, "").length,
            binary: false
          });
        }
      ),
      new LineParser(
        /^(.+) \|\s+Bin ([0-9.]+) -> ([0-9.]+) ([a-z]+)/,
        (result, [file, before, after]) => {
          result.files.push({
            file: file.trim(),
            before: asNumber(before),
            after: asNumber(after),
            binary: true
          });
        }
      ),
      new LineParser(
        /(\d+) files? changed\s*((?:, \d+ [^,]+){0,2})/,
        (result, [changed, summary]) => {
          const inserted = /(\d+) i/.exec(summary);
          const deleted = /(\d+) d/.exec(summary);
          result.changed = asNumber(changed);
          result.insertions = asNumber(inserted == null ? void 0 : inserted[1]);
          result.deletions = asNumber(deleted == null ? void 0 : deleted[1]);
        }
      )
    ];
    numStatParser = [
      new LineParser(
        /(\d+)\t(\d+)\t(.+)$/,
        (result, [changesInsert, changesDelete, file]) => {
          const insertions = asNumber(changesInsert);
          const deletions = asNumber(changesDelete);
          result.changed++;
          result.insertions += insertions;
          result.deletions += deletions;
          result.files.push({
            file,
            changes: insertions + deletions,
            insertions,
            deletions,
            binary: false
          });
        }
      ),
      new LineParser(/-\t-\t(.+)$/, (result, [file]) => {
        result.changed++;
        result.files.push({
          file,
          after: 0,
          before: 0,
          binary: true
        });
      })
    ];
    nameOnlyParser = [
      new LineParser(/(.+)$/, (result, [file]) => {
        result.changed++;
        result.files.push({
          file,
          changes: 0,
          insertions: 0,
          deletions: 0,
          binary: false
        });
      })
    ];
    nameStatusParser = [
      new LineParser(
        /([ACDMRTUXB])([0-9]{0,3})\t(.[^\t]*)(\t(.[^\t]*))?$/,
        (result, [status, similarity, from, _to, to]) => {
          result.changed++;
          result.files.push({
            file: to != null ? to : from,
            changes: 0,
            insertions: 0,
            deletions: 0,
            binary: false,
            status: orVoid(isDiffNameStatus(status) && status),
            from: orVoid(!!to && from !== to && from),
            similarity: asNumber(similarity)
          });
        }
      )
    ];
    diffSummaryParsers = {
      [
        ""
        /* NONE */
      ]: statParser,
      [
        "--stat"
        /* STAT */
      ]: statParser,
      [
        "--numstat"
        /* NUM_STAT */
      ]: numStatParser,
      [
        "--name-status"
        /* NAME_STATUS */
      ]: nameStatusParser,
      [
        "--name-only"
        /* NAME_ONLY */
      ]: nameOnlyParser
    };
  }
});
function lineBuilder(tokens, fields) {
  return fields.reduce(
    (line, field, index) => {
      line[field] = tokens[index] || "";
      return line;
    },
    /* @__PURE__ */ Object.create({ diff: null })
  );
}
__name(lineBuilder, "lineBuilder");
function createListLogSummaryParser(splitter = SPLITTER, fields = defaultFieldNames, logFormat = "") {
  const parseDiffResult = getDiffParser(logFormat);
  return function(stdOut) {
    const all = toLinesWithContent(
      stdOut.trim(),
      false,
      START_BOUNDARY
    ).map(function(item) {
      const lineDetail = item.split(COMMIT_BOUNDARY);
      const listLogLine = lineBuilder(lineDetail[0].split(splitter), fields);
      if (lineDetail.length > 1 && !!lineDetail[1].trim()) {
        listLogLine.diff = parseDiffResult(lineDetail[1]);
      }
      return listLogLine;
    });
    return {
      all,
      latest: all.length && all[0] || null,
      total: all.length
    };
  };
}
__name(createListLogSummaryParser, "createListLogSummaryParser");
var START_BOUNDARY, COMMIT_BOUNDARY, SPLITTER, defaultFieldNames;
var init_parse_list_log_summary = __esm2({
  "src/lib/parsers/parse-list-log-summary.ts"() {
    "use strict";
    init_utils();
    init_parse_diff_summary();
    init_log_format();
    START_BOUNDARY = "\xF2\xF2\xF2\xF2\xF2\xF2 ";
    COMMIT_BOUNDARY = " \xF2\xF2";
    SPLITTER = " \xF2 ";
    defaultFieldNames = ["hash", "date", "message", "refs", "author_name", "author_email"];
  }
});
var diff_exports = {};
__export2(diff_exports, {
  diffSummaryTask: /* @__PURE__ */ __name(() => diffSummaryTask, "diffSummaryTask"),
  validateLogFormatConfig: /* @__PURE__ */ __name(() => validateLogFormatConfig, "validateLogFormatConfig")
});
function diffSummaryTask(customArgs) {
  let logFormat = logFormatFromCommand(customArgs);
  const commands = ["diff"];
  if (logFormat === "") {
    logFormat = "--stat";
    commands.push("--stat=4096");
  }
  commands.push(...customArgs);
  return validateLogFormatConfig(commands) || {
    commands,
    format: "utf-8",
    parser: getDiffParser(logFormat)
  };
}
__name(diffSummaryTask, "diffSummaryTask");
function validateLogFormatConfig(customArgs) {
  const flags = customArgs.filter(isLogFormat);
  if (flags.length > 1) {
    return configurationErrorTask(
      `Summary flags are mutually exclusive - pick one of ${flags.join(",")}`
    );
  }
  if (flags.length && customArgs.includes("-z")) {
    return configurationErrorTask(
      `Summary flag ${flags} parsing is not compatible with null termination option '-z'`
    );
  }
}
__name(validateLogFormatConfig, "validateLogFormatConfig");
var init_diff = __esm2({
  "src/lib/tasks/diff.ts"() {
    "use strict";
    init_log_format();
    init_parse_diff_summary();
    init_task();
  }
});
function prettyFormat(format, splitter) {
  const fields = [];
  const formatStr = [];
  Object.keys(format).forEach((field) => {
    fields.push(field);
    formatStr.push(String(format[field]));
  });
  return [fields, formatStr.join(splitter)];
}
__name(prettyFormat, "prettyFormat");
function userOptions(input) {
  return Object.keys(input).reduce((out, key) => {
    if (!(key in excludeOptions)) {
      out[key] = input[key];
    }
    return out;
  }, {});
}
__name(userOptions, "userOptions");
function parseLogOptions(opt = {}, customArgs = []) {
  const splitter = filterType(opt.splitter, filterString, SPLITTER);
  const format = !filterPrimitives(opt.format) && opt.format ? opt.format : {
    hash: "%H",
    date: opt.strictDate === false ? "%ai" : "%aI",
    message: "%s",
    refs: "%D",
    body: opt.multiLine ? "%B" : "%b",
    author_name: opt.mailMap !== false ? "%aN" : "%an",
    author_email: opt.mailMap !== false ? "%aE" : "%ae"
  };
  const [fields, formatStr] = prettyFormat(format, splitter);
  const suffix = [];
  const command = [
    `--pretty=format:${START_BOUNDARY}${formatStr}${COMMIT_BOUNDARY}`,
    ...customArgs
  ];
  const maxCount = opt.n || opt["max-count"] || opt.maxCount;
  if (maxCount) {
    command.push(`--max-count=${maxCount}`);
  }
  if (opt.from || opt.to) {
    const rangeOperator = opt.symmetric !== false ? "..." : "..";
    suffix.push(`${opt.from || ""}${rangeOperator}${opt.to || ""}`);
  }
  if (filterString(opt.file)) {
    command.push("--follow", pathspec(opt.file));
  }
  appendTaskOptions(userOptions(opt), command);
  return {
    fields,
    splitter,
    commands: [...command, ...suffix]
  };
}
__name(parseLogOptions, "parseLogOptions");
function logTask(splitter, fields, customArgs) {
  const parser4 = createListLogSummaryParser(splitter, fields, logFormatFromCommand(customArgs));
  return {
    commands: ["log", ...customArgs],
    format: "utf-8",
    parser: parser4
  };
}
__name(logTask, "logTask");
function log_default() {
  return {
    log(...rest) {
      const next = trailingFunctionArgument(arguments);
      const options = parseLogOptions(
        trailingOptionsArgument(arguments),
        filterType(arguments[0], filterArray)
      );
      const task = rejectDeprecatedSignatures(...rest) || validateLogFormatConfig(options.commands) || createLogTask(options);
      return this._runTask(task, next);
    }
  };
  function createLogTask(options) {
    return logTask(options.splitter, options.fields, options.commands);
  }
  __name(createLogTask, "createLogTask");
  function rejectDeprecatedSignatures(from, to) {
    return filterString(from) && filterString(to) && configurationErrorTask(
      `git.log(string, string) should be replaced with git.log({ from: string, to: string })`
    );
  }
  __name(rejectDeprecatedSignatures, "rejectDeprecatedSignatures");
}
__name(log_default, "log_default");
var excludeOptions;
var init_log = __esm2({
  "src/lib/tasks/log.ts"() {
    "use strict";
    init_log_format();
    init_pathspec();
    init_parse_list_log_summary();
    init_utils();
    init_task();
    init_diff();
    excludeOptions = /* @__PURE__ */ ((excludeOptions2) => {
      excludeOptions2[excludeOptions2["--pretty"] = 0] = "--pretty";
      excludeOptions2[excludeOptions2["max-count"] = 1] = "max-count";
      excludeOptions2[excludeOptions2["maxCount"] = 2] = "maxCount";
      excludeOptions2[excludeOptions2["n"] = 3] = "n";
      excludeOptions2[excludeOptions2["file"] = 4] = "file";
      excludeOptions2[excludeOptions2["format"] = 5] = "format";
      excludeOptions2[excludeOptions2["from"] = 6] = "from";
      excludeOptions2[excludeOptions2["to"] = 7] = "to";
      excludeOptions2[excludeOptions2["splitter"] = 8] = "splitter";
      excludeOptions2[excludeOptions2["symmetric"] = 9] = "symmetric";
      excludeOptions2[excludeOptions2["mailMap"] = 10] = "mailMap";
      excludeOptions2[excludeOptions2["multiLine"] = 11] = "multiLine";
      excludeOptions2[excludeOptions2["strictDate"] = 12] = "strictDate";
      return excludeOptions2;
    })(excludeOptions || {});
  }
});
var MergeSummaryConflict, MergeSummaryDetail;
var init_MergeSummary = __esm2({
  "src/lib/responses/MergeSummary.ts"() {
    "use strict";
    MergeSummaryConflict = class {
      static {
        __name(this, "MergeSummaryConflict");
      }
      constructor(reason, file = null, meta) {
        this.reason = reason;
        this.file = file;
        this.meta = meta;
      }
      toString() {
        return `${this.file}:${this.reason}`;
      }
    };
    MergeSummaryDetail = class {
      static {
        __name(this, "MergeSummaryDetail");
      }
      constructor() {
        this.conflicts = [];
        this.merges = [];
        this.result = "success";
      }
      get failed() {
        return this.conflicts.length > 0;
      }
      get reason() {
        return this.result;
      }
      toString() {
        if (this.conflicts.length) {
          return `CONFLICTS: ${this.conflicts.join(", ")}`;
        }
        return "OK";
      }
    };
  }
});
var PullSummary, PullFailedSummary;
var init_PullSummary = __esm2({
  "src/lib/responses/PullSummary.ts"() {
    "use strict";
    PullSummary = class {
      static {
        __name(this, "PullSummary");
      }
      constructor() {
        this.remoteMessages = {
          all: []
        };
        this.created = [];
        this.deleted = [];
        this.files = [];
        this.deletions = {};
        this.insertions = {};
        this.summary = {
          changes: 0,
          deletions: 0,
          insertions: 0
        };
      }
    };
    PullFailedSummary = class {
      static {
        __name(this, "PullFailedSummary");
      }
      constructor() {
        this.remote = "";
        this.hash = {
          local: "",
          remote: ""
        };
        this.branch = {
          local: "",
          remote: ""
        };
        this.message = "";
      }
      toString() {
        return this.message;
      }
    };
  }
});
function objectEnumerationResult(remoteMessages) {
  return remoteMessages.objects = remoteMessages.objects || {
    compressing: 0,
    counting: 0,
    enumerating: 0,
    packReused: 0,
    reused: { count: 0, delta: 0 },
    total: { count: 0, delta: 0 }
  };
}
__name(objectEnumerationResult, "objectEnumerationResult");
function asObjectCount(source) {
  const count = /^\s*(\d+)/.exec(source);
  const delta = /delta (\d+)/i.exec(source);
  return {
    count: asNumber(count && count[1] || "0"),
    delta: asNumber(delta && delta[1] || "0")
  };
}
__name(asObjectCount, "asObjectCount");
var remoteMessagesObjectParsers;
var init_parse_remote_objects = __esm2({
  "src/lib/parsers/parse-remote-objects.ts"() {
    "use strict";
    init_utils();
    remoteMessagesObjectParsers = [
      new RemoteLineParser(
        /^remote:\s*(enumerating|counting|compressing) objects: (\d+),/i,
        (result, [action, count]) => {
          const key = action.toLowerCase();
          const enumeration = objectEnumerationResult(result.remoteMessages);
          Object.assign(enumeration, { [key]: asNumber(count) });
        }
      ),
      new RemoteLineParser(
        /^remote:\s*(enumerating|counting|compressing) objects: \d+% \(\d+\/(\d+)\),/i,
        (result, [action, count]) => {
          const key = action.toLowerCase();
          const enumeration = objectEnumerationResult(result.remoteMessages);
          Object.assign(enumeration, { [key]: asNumber(count) });
        }
      ),
      new RemoteLineParser(
        /total ([^,]+), reused ([^,]+), pack-reused (\d+)/i,
        (result, [total, reused, packReused]) => {
          const objects = objectEnumerationResult(result.remoteMessages);
          objects.total = asObjectCount(total);
          objects.reused = asObjectCount(reused);
          objects.packReused = asNumber(packReused);
        }
      )
    ];
  }
});
function parseRemoteMessages(_stdOut, stdErr) {
  return parseStringResponse({ remoteMessages: new RemoteMessageSummary() }, parsers2, stdErr);
}
__name(parseRemoteMessages, "parseRemoteMessages");
var parsers2, RemoteMessageSummary;
var init_parse_remote_messages = __esm2({
  "src/lib/parsers/parse-remote-messages.ts"() {
    "use strict";
    init_utils();
    init_parse_remote_objects();
    parsers2 = [
      new RemoteLineParser(/^remote:\s*(.+)$/, (result, [text]) => {
        result.remoteMessages.all.push(text.trim());
        return false;
      }),
      ...remoteMessagesObjectParsers,
      new RemoteLineParser(
        [/create a (?:pull|merge) request/i, /\s(https?:\/\/\S+)$/],
        (result, [pullRequestUrl]) => {
          result.remoteMessages.pullRequestUrl = pullRequestUrl;
        }
      ),
      new RemoteLineParser(
        [/found (\d+) vulnerabilities.+\(([^)]+)\)/i, /\s(https?:\/\/\S+)$/],
        (result, [count, summary, url]) => {
          result.remoteMessages.vulnerabilities = {
            count: asNumber(count),
            summary,
            url
          };
        }
      )
    ];
    RemoteMessageSummary = class {
      static {
        __name(this, "RemoteMessageSummary");
      }
      constructor() {
        this.all = [];
      }
    };
  }
});
function parsePullErrorResult(stdOut, stdErr) {
  const pullError = parseStringResponse(new PullFailedSummary(), errorParsers, [stdOut, stdErr]);
  return pullError.message && pullError;
}
__name(parsePullErrorResult, "parsePullErrorResult");
var FILE_UPDATE_REGEX, SUMMARY_REGEX, ACTION_REGEX, parsers3, errorParsers, parsePullDetail, parsePullResult;
var init_parse_pull = __esm2({
  "src/lib/parsers/parse-pull.ts"() {
    "use strict";
    init_PullSummary();
    init_utils();
    init_parse_remote_messages();
    FILE_UPDATE_REGEX = /^\s*(.+?)\s+\|\s+\d+\s*(\+*)(-*)/;
    SUMMARY_REGEX = /(\d+)\D+((\d+)\D+\(\+\))?(\D+(\d+)\D+\(-\))?/;
    ACTION_REGEX = /^(create|delete) mode \d+ (.+)/;
    parsers3 = [
      new LineParser(FILE_UPDATE_REGEX, (result, [file, insertions, deletions]) => {
        result.files.push(file);
        if (insertions) {
          result.insertions[file] = insertions.length;
        }
        if (deletions) {
          result.deletions[file] = deletions.length;
        }
      }),
      new LineParser(SUMMARY_REGEX, (result, [changes, , insertions, , deletions]) => {
        if (insertions !== void 0 || deletions !== void 0) {
          result.summary.changes = +changes || 0;
          result.summary.insertions = +insertions || 0;
          result.summary.deletions = +deletions || 0;
          return true;
        }
        return false;
      }),
      new LineParser(ACTION_REGEX, (result, [action, file]) => {
        append(result.files, file);
        append(action === "create" ? result.created : result.deleted, file);
      })
    ];
    errorParsers = [
      new LineParser(/^from\s(.+)$/i, (result, [remote]) => void (result.remote = remote)),
      new LineParser(/^fatal:\s(.+)$/, (result, [message]) => void (result.message = message)),
      new LineParser(
        /([a-z0-9]+)\.\.([a-z0-9]+)\s+(\S+)\s+->\s+(\S+)$/,
        (result, [hashLocal, hashRemote, branchLocal, branchRemote]) => {
          result.branch.local = branchLocal;
          result.hash.local = hashLocal;
          result.branch.remote = branchRemote;
          result.hash.remote = hashRemote;
        }
      )
    ];
    parsePullDetail = /* @__PURE__ */ __name((stdOut, stdErr) => {
      return parseStringResponse(new PullSummary(), parsers3, [stdOut, stdErr]);
    }, "parsePullDetail");
    parsePullResult = /* @__PURE__ */ __name((stdOut, stdErr) => {
      return Object.assign(
        new PullSummary(),
        parsePullDetail(stdOut, stdErr),
        parseRemoteMessages(stdOut, stdErr)
      );
    }, "parsePullResult");
  }
});
var parsers4, parseMergeResult, parseMergeDetail;
var init_parse_merge = __esm2({
  "src/lib/parsers/parse-merge.ts"() {
    "use strict";
    init_MergeSummary();
    init_utils();
    init_parse_pull();
    parsers4 = [
      new LineParser(/^Auto-merging\s+(.+)$/, (summary, [autoMerge]) => {
        summary.merges.push(autoMerge);
      }),
      new LineParser(/^CONFLICT\s+\((.+)\): Merge conflict in (.+)$/, (summary, [reason, file]) => {
        summary.conflicts.push(new MergeSummaryConflict(reason, file));
      }),
      new LineParser(
        /^CONFLICT\s+\((.+\/delete)\): (.+) deleted in (.+) and/,
        (summary, [reason, file, deleteRef]) => {
          summary.conflicts.push(new MergeSummaryConflict(reason, file, { deleteRef }));
        }
      ),
      new LineParser(/^CONFLICT\s+\((.+)\):/, (summary, [reason]) => {
        summary.conflicts.push(new MergeSummaryConflict(reason, null));
      }),
      new LineParser(/^Automatic merge failed;\s+(.+)$/, (summary, [result]) => {
        summary.result = result;
      })
    ];
    parseMergeResult = /* @__PURE__ */ __name((stdOut, stdErr) => {
      return Object.assign(parseMergeDetail(stdOut, stdErr), parsePullResult(stdOut, stdErr));
    }, "parseMergeResult");
    parseMergeDetail = /* @__PURE__ */ __name((stdOut) => {
      return parseStringResponse(new MergeSummaryDetail(), parsers4, stdOut);
    }, "parseMergeDetail");
  }
});
function mergeTask(customArgs) {
  if (!customArgs.length) {
    return configurationErrorTask("Git.merge requires at least one option");
  }
  return {
    commands: ["merge", ...customArgs],
    format: "utf-8",
    parser(stdOut, stdErr) {
      const merge = parseMergeResult(stdOut, stdErr);
      if (merge.failed) {
        throw new GitResponseError(merge);
      }
      return merge;
    }
  };
}
__name(mergeTask, "mergeTask");
var init_merge = __esm2({
  "src/lib/tasks/merge.ts"() {
    "use strict";
    init_git_response_error();
    init_parse_merge();
    init_task();
  }
});
function pushResultPushedItem(local, remote, status) {
  const deleted = status.includes("deleted");
  const tag = status.includes("tag") || /^refs\/tags/.test(local);
  const alreadyUpdated = !status.includes("new");
  return {
    deleted,
    tag,
    branch: !tag,
    new: !alreadyUpdated,
    alreadyUpdated,
    local,
    remote
  };
}
__name(pushResultPushedItem, "pushResultPushedItem");
var parsers5, parsePushResult, parsePushDetail;
var init_parse_push = __esm2({
  "src/lib/parsers/parse-push.ts"() {
    "use strict";
    init_utils();
    init_parse_remote_messages();
    parsers5 = [
      new LineParser(/^Pushing to (.+)$/, (result, [repo]) => {
        result.repo = repo;
      }),
      new LineParser(/^updating local tracking ref '(.+)'/, (result, [local]) => {
        result.ref = __spreadProps(__spreadValues({}, result.ref || {}), {
          local
        });
      }),
      new LineParser(/^[=*-]\s+([^:]+):(\S+)\s+\[(.+)]$/, (result, [local, remote, type]) => {
        result.pushed.push(pushResultPushedItem(local, remote, type));
      }),
      new LineParser(
        /^Branch '([^']+)' set up to track remote branch '([^']+)' from '([^']+)'/,
        (result, [local, remote, remoteName]) => {
          result.branch = __spreadProps(__spreadValues({}, result.branch || {}), {
            local,
            remote,
            remoteName
          });
        }
      ),
      new LineParser(
        /^([^:]+):(\S+)\s+([a-z0-9]+)\.\.([a-z0-9]+)$/,
        (result, [local, remote, from, to]) => {
          result.update = {
            head: {
              local,
              remote
            },
            hash: {
              from,
              to
            }
          };
        }
      )
    ];
    parsePushResult = /* @__PURE__ */ __name((stdOut, stdErr) => {
      const pushDetail = parsePushDetail(stdOut, stdErr);
      const responseDetail = parseRemoteMessages(stdOut, stdErr);
      return __spreadValues(__spreadValues({}, pushDetail), responseDetail);
    }, "parsePushResult");
    parsePushDetail = /* @__PURE__ */ __name((stdOut, stdErr) => {
      return parseStringResponse({ pushed: [] }, parsers5, [stdOut, stdErr]);
    }, "parsePushDetail");
  }
});
var push_exports = {};
__export2(push_exports, {
  pushTagsTask: /* @__PURE__ */ __name(() => pushTagsTask, "pushTagsTask"),
  pushTask: /* @__PURE__ */ __name(() => pushTask, "pushTask")
});
function pushTagsTask(ref = {}, customArgs) {
  append(customArgs, "--tags");
  return pushTask(ref, customArgs);
}
__name(pushTagsTask, "pushTagsTask");
function pushTask(ref = {}, customArgs) {
  const commands = ["push", ...customArgs];
  if (ref.branch) {
    commands.splice(1, 0, ref.branch);
  }
  if (ref.remote) {
    commands.splice(1, 0, ref.remote);
  }
  remove(commands, "-v");
  append(commands, "--verbose");
  append(commands, "--porcelain");
  return {
    commands,
    format: "utf-8",
    parser: parsePushResult
  };
}
__name(pushTask, "pushTask");
var init_push = __esm2({
  "src/lib/tasks/push.ts"() {
    "use strict";
    init_parse_push();
    init_utils();
  }
});
function show_default() {
  return {
    showBuffer() {
      const commands = ["show", ...getTrailingOptions(arguments, 1)];
      if (!commands.includes("--binary")) {
        commands.splice(1, 0, "--binary");
      }
      return this._runTask(
        straightThroughBufferTask(commands),
        trailingFunctionArgument(arguments)
      );
    },
    show() {
      const commands = ["show", ...getTrailingOptions(arguments, 1)];
      return this._runTask(
        straightThroughStringTask(commands),
        trailingFunctionArgument(arguments)
      );
    }
  };
}
__name(show_default, "show_default");
var init_show = __esm2({
  "src/lib/tasks/show.ts"() {
    "use strict";
    init_utils();
    init_task();
  }
});
var fromPathRegex, FileStatusSummary;
var init_FileStatusSummary = __esm2({
  "src/lib/responses/FileStatusSummary.ts"() {
    "use strict";
    fromPathRegex = /^(.+)\0(.+)$/;
    FileStatusSummary = class {
      static {
        __name(this, "FileStatusSummary");
      }
      constructor(path, index, working_dir) {
        this.path = path;
        this.index = index;
        this.working_dir = working_dir;
        if (index === "R" || working_dir === "R") {
          const detail = fromPathRegex.exec(path) || [null, path, path];
          this.from = detail[2] || "";
          this.path = detail[1] || "";
        }
      }
    };
  }
});
function renamedFile(line) {
  const [to, from] = line.split(NULL);
  return {
    from: from || to,
    to
  };
}
__name(renamedFile, "renamedFile");
function parser3(indexX, indexY, handler) {
  return [`${indexX}${indexY}`, handler];
}
__name(parser3, "parser3");
function conflicts(indexX, ...indexY) {
  return indexY.map((y) => parser3(indexX, y, (result, file) => append(result.conflicted, file)));
}
__name(conflicts, "conflicts");
function splitLine(result, lineStr) {
  const trimmed2 = lineStr.trim();
  switch (" ") {
    case trimmed2.charAt(2):
      return data(trimmed2.charAt(0), trimmed2.charAt(1), trimmed2.substr(3));
    case trimmed2.charAt(1):
      return data(" ", trimmed2.charAt(0), trimmed2.substr(2));
    default:
      return;
  }
  function data(index, workingDir, path) {
    const raw = `${index}${workingDir}`;
    const handler = parsers6.get(raw);
    if (handler) {
      handler(result, path);
    }
    if (raw !== "##" && raw !== "!!") {
      result.files.push(new FileStatusSummary(path, index, workingDir));
    }
  }
  __name(data, "data");
}
__name(splitLine, "splitLine");
var StatusSummary, parsers6, parseStatusSummary;
var init_StatusSummary = __esm2({
  "src/lib/responses/StatusSummary.ts"() {
    "use strict";
    init_utils();
    init_FileStatusSummary();
    StatusSummary = class {
      static {
        __name(this, "StatusSummary");
      }
      constructor() {
        this.not_added = [];
        this.conflicted = [];
        this.created = [];
        this.deleted = [];
        this.ignored = void 0;
        this.modified = [];
        this.renamed = [];
        this.files = [];
        this.staged = [];
        this.ahead = 0;
        this.behind = 0;
        this.current = null;
        this.tracking = null;
        this.detached = false;
        this.isClean = () => {
          return !this.files.length;
        };
      }
    };
    parsers6 = new Map([
      parser3(
        " ",
        "A",
        (result, file) => append(result.created, file)
      ),
      parser3(
        " ",
        "D",
        (result, file) => append(result.deleted, file)
      ),
      parser3(
        " ",
        "M",
        (result, file) => append(result.modified, file)
      ),
      parser3(
        "A",
        " ",
        (result, file) => append(result.created, file) && append(result.staged, file)
      ),
      parser3(
        "A",
        "M",
        (result, file) => append(result.created, file) && append(result.staged, file) && append(result.modified, file)
      ),
      parser3(
        "D",
        " ",
        (result, file) => append(result.deleted, file) && append(result.staged, file)
      ),
      parser3(
        "M",
        " ",
        (result, file) => append(result.modified, file) && append(result.staged, file)
      ),
      parser3(
        "M",
        "M",
        (result, file) => append(result.modified, file) && append(result.staged, file)
      ),
      parser3("R", " ", (result, file) => {
        append(result.renamed, renamedFile(file));
      }),
      parser3("R", "M", (result, file) => {
        const renamed = renamedFile(file);
        append(result.renamed, renamed);
        append(result.modified, renamed.to);
      }),
      parser3("!", "!", (_result, _file) => {
        append(_result.ignored = _result.ignored || [], _file);
      }),
      parser3(
        "?",
        "?",
        (result, file) => append(result.not_added, file)
      ),
      ...conflicts(
        "A",
        "A",
        "U"
        /* UNMERGED */
      ),
      ...conflicts(
        "D",
        "D",
        "U"
        /* UNMERGED */
      ),
      ...conflicts(
        "U",
        "A",
        "D",
        "U"
        /* UNMERGED */
      ),
      [
        "##",
        (result, line) => {
          const aheadReg = /ahead (\d+)/;
          const behindReg = /behind (\d+)/;
          const currentReg = /^(.+?(?=(?:\.{3}|\s|$)))/;
          const trackingReg = /\.{3}(\S*)/;
          const onEmptyBranchReg = /\son\s([\S]+)$/;
          let regexResult;
          regexResult = aheadReg.exec(line);
          result.ahead = regexResult && +regexResult[1] || 0;
          regexResult = behindReg.exec(line);
          result.behind = regexResult && +regexResult[1] || 0;
          regexResult = currentReg.exec(line);
          result.current = regexResult && regexResult[1];
          regexResult = trackingReg.exec(line);
          result.tracking = regexResult && regexResult[1];
          regexResult = onEmptyBranchReg.exec(line);
          result.current = regexResult && regexResult[1] || result.current;
          result.detached = /\(no branch\)/.test(line);
        }
      ]
    ]);
    parseStatusSummary = /* @__PURE__ */ __name(function(text) {
      const lines = text.split(NULL);
      const status = new StatusSummary();
      for (let i = 0, l = lines.length; i < l; ) {
        let line = lines[i++].trim();
        if (!line) {
          continue;
        }
        if (line.charAt(0) === "R") {
          line += NULL + (lines[i++] || "");
        }
        splitLine(status, line);
      }
      return status;
    }, "parseStatusSummary");
  }
});
function statusTask(customArgs) {
  const commands = [
    "status",
    "--porcelain",
    "-b",
    "-u",
    "--null",
    ...customArgs.filter((arg) => !ignoredOptions.includes(arg))
  ];
  return {
    format: "utf-8",
    commands,
    parser(text) {
      return parseStatusSummary(text);
    }
  };
}
__name(statusTask, "statusTask");
var ignoredOptions;
var init_status = __esm2({
  "src/lib/tasks/status.ts"() {
    "use strict";
    init_StatusSummary();
    ignoredOptions = ["--null", "-z"];
  }
});
function versionResponse(major = 0, minor = 0, patch = 0, agent = "", installed = true) {
  return Object.defineProperty(
    {
      major,
      minor,
      patch,
      agent,
      installed
    },
    "toString",
    {
      value() {
        return `${this.major}.${this.minor}.${this.patch}`;
      },
      configurable: false,
      enumerable: false
    }
  );
}
__name(versionResponse, "versionResponse");
function notInstalledResponse() {
  return versionResponse(0, 0, 0, "", false);
}
__name(notInstalledResponse, "notInstalledResponse");
function version_default() {
  return {
    version() {
      return this._runTask({
        commands: ["--version"],
        format: "utf-8",
        parser: versionParser,
        onError(result, error, done, fail) {
          if (result.exitCode === -2) {
            return done(Buffer.from(NOT_INSTALLED));
          }
          fail(error);
        }
      });
    }
  };
}
__name(version_default, "version_default");
function versionParser(stdOut) {
  if (stdOut === NOT_INSTALLED) {
    return notInstalledResponse();
  }
  return parseStringResponse(versionResponse(0, 0, 0, stdOut), parsers7, stdOut);
}
__name(versionParser, "versionParser");
var NOT_INSTALLED, parsers7;
var init_version = __esm2({
  "src/lib/tasks/version.ts"() {
    "use strict";
    init_utils();
    NOT_INSTALLED = "installed=false";
    parsers7 = [
      new LineParser(
        /version (\d+)\.(\d+)\.(\d+)(?:\s*\((.+)\))?/,
        (result, [major, minor, patch, agent = ""]) => {
          Object.assign(
            result,
            versionResponse(asNumber(major), asNumber(minor), asNumber(patch), agent)
          );
        }
      ),
      new LineParser(
        /version (\d+)\.(\d+)\.(\D+)(.+)?$/,
        (result, [major, minor, patch, agent = ""]) => {
          Object.assign(result, versionResponse(asNumber(major), asNumber(minor), patch, agent));
        }
      )
    ];
  }
});
var simple_git_api_exports = {};
__export2(simple_git_api_exports, {
  SimpleGitApi: /* @__PURE__ */ __name(() => SimpleGitApi, "SimpleGitApi")
});
var SimpleGitApi;
var init_simple_git_api = __esm2({
  "src/lib/simple-git-api.ts"() {
    "use strict";
    init_task_callback();
    init_change_working_directory();
    init_checkout();
    init_count_objects();
    init_commit();
    init_config();
    init_first_commit();
    init_grep();
    init_hash_object();
    init_init();
    init_log();
    init_merge();
    init_push();
    init_show();
    init_status();
    init_task();
    init_version();
    init_utils();
    SimpleGitApi = class {
      static {
        __name(this, "SimpleGitApi");
      }
      constructor(_executor) {
        this._executor = _executor;
      }
      _runTask(task, then) {
        const chain = this._executor.chain();
        const promise = chain.push(task);
        if (then) {
          taskCallback(task, promise, then);
        }
        return Object.create(this, {
          then: { value: promise.then.bind(promise) },
          catch: { value: promise.catch.bind(promise) },
          _executor: { value: chain }
        });
      }
      add(files) {
        return this._runTask(
          straightThroughStringTask(["add", ...asArray(files)]),
          trailingFunctionArgument(arguments)
        );
      }
      cwd(directory) {
        const next = trailingFunctionArgument(arguments);
        if (typeof directory === "string") {
          return this._runTask(changeWorkingDirectoryTask(directory, this._executor), next);
        }
        if (typeof (directory == null ? void 0 : directory.path) === "string") {
          return this._runTask(
            changeWorkingDirectoryTask(
              directory.path,
              directory.root && this._executor || void 0
            ),
            next
          );
        }
        return this._runTask(
          configurationErrorTask("Git.cwd: workingDirectory must be supplied as a string"),
          next
        );
      }
      hashObject(path, write) {
        return this._runTask(
          hashObjectTask(path, write === true),
          trailingFunctionArgument(arguments)
        );
      }
      init(bare) {
        return this._runTask(
          initTask(bare === true, this._executor.cwd, getTrailingOptions(arguments)),
          trailingFunctionArgument(arguments)
        );
      }
      merge() {
        return this._runTask(
          mergeTask(getTrailingOptions(arguments)),
          trailingFunctionArgument(arguments)
        );
      }
      mergeFromTo(remote, branch) {
        if (!(filterString(remote) && filterString(branch))) {
          return this._runTask(
            configurationErrorTask(
              `Git.mergeFromTo requires that the 'remote' and 'branch' arguments are supplied as strings`
            )
          );
        }
        return this._runTask(
          mergeTask([remote, branch, ...getTrailingOptions(arguments)]),
          trailingFunctionArgument(arguments, false)
        );
      }
      outputHandler(handler) {
        this._executor.outputHandler = handler;
        return this;
      }
      push() {
        const task = pushTask(
          {
            remote: filterType(arguments[0], filterString),
            branch: filterType(arguments[1], filterString)
          },
          getTrailingOptions(arguments)
        );
        return this._runTask(task, trailingFunctionArgument(arguments));
      }
      stash() {
        return this._runTask(
          straightThroughStringTask(["stash", ...getTrailingOptions(arguments)]),
          trailingFunctionArgument(arguments)
        );
      }
      status() {
        return this._runTask(
          statusTask(getTrailingOptions(arguments)),
          trailingFunctionArgument(arguments)
        );
      }
    };
    Object.assign(
      SimpleGitApi.prototype,
      checkout_default(),
      commit_default(),
      config_default(),
      count_objects_default(),
      first_commit_default(),
      grep_default(),
      log_default(),
      show_default(),
      version_default()
    );
  }
});
var scheduler_exports = {};
__export2(scheduler_exports, {
  Scheduler: /* @__PURE__ */ __name(() => Scheduler, "Scheduler")
});
var createScheduledTask, Scheduler;
var init_scheduler = __esm2({
  "src/lib/runners/scheduler.ts"() {
    "use strict";
    init_utils();
    init_git_logger();
    createScheduledTask = /* @__PURE__ */ (() => {
      let id = 0;
      return () => {
        id++;
        const { promise, done } = (0, import_promise_deferred.createDeferred)();
        return {
          promise,
          done,
          id
        };
      };
    })();
    Scheduler = class {
      static {
        __name(this, "Scheduler");
      }
      constructor(concurrency = 2) {
        this.concurrency = concurrency;
        this.logger = createLogger("", "scheduler");
        this.pending = [];
        this.running = [];
        this.logger(`Constructed, concurrency=%s`, concurrency);
      }
      schedule() {
        if (!this.pending.length || this.running.length >= this.concurrency) {
          this.logger(
            `Schedule attempt ignored, pending=%s running=%s concurrency=%s`,
            this.pending.length,
            this.running.length,
            this.concurrency
          );
          return;
        }
        const task = append(this.running, this.pending.shift());
        this.logger(`Attempting id=%s`, task.id);
        task.done(() => {
          this.logger(`Completing id=`, task.id);
          remove(this.running, task);
          this.schedule();
        });
      }
      next() {
        const { promise, id } = append(this.pending, createScheduledTask());
        this.logger(`Scheduling id=%s`, id);
        this.schedule();
        return promise;
      }
    };
  }
});
var apply_patch_exports = {};
__export2(apply_patch_exports, {
  applyPatchTask: /* @__PURE__ */ __name(() => applyPatchTask, "applyPatchTask")
});
function applyPatchTask(patches, customArgs) {
  return straightThroughStringTask(["apply", ...customArgs, ...patches]);
}
__name(applyPatchTask, "applyPatchTask");
var init_apply_patch = __esm2({
  "src/lib/tasks/apply-patch.ts"() {
    "use strict";
    init_task();
  }
});
function branchDeletionSuccess(branch, hash) {
  return {
    branch,
    hash,
    success: true
  };
}
__name(branchDeletionSuccess, "branchDeletionSuccess");
function branchDeletionFailure(branch) {
  return {
    branch,
    hash: null,
    success: false
  };
}
__name(branchDeletionFailure, "branchDeletionFailure");
var BranchDeletionBatch;
var init_BranchDeleteSummary = __esm2({
  "src/lib/responses/BranchDeleteSummary.ts"() {
    "use strict";
    BranchDeletionBatch = class {
      static {
        __name(this, "BranchDeletionBatch");
      }
      constructor() {
        this.all = [];
        this.branches = {};
        this.errors = [];
      }
      get success() {
        return !this.errors.length;
      }
    };
  }
});
function hasBranchDeletionError(data, processExitCode) {
  return processExitCode === 1 && deleteErrorRegex.test(data);
}
__name(hasBranchDeletionError, "hasBranchDeletionError");
var deleteSuccessRegex, deleteErrorRegex, parsers8, parseBranchDeletions;
var init_parse_branch_delete = __esm2({
  "src/lib/parsers/parse-branch-delete.ts"() {
    "use strict";
    init_BranchDeleteSummary();
    init_utils();
    deleteSuccessRegex = /(\S+)\s+\(\S+\s([^)]+)\)/;
    deleteErrorRegex = /^error[^']+'([^']+)'/m;
    parsers8 = [
      new LineParser(deleteSuccessRegex, (result, [branch, hash]) => {
        const deletion = branchDeletionSuccess(branch, hash);
        result.all.push(deletion);
        result.branches[branch] = deletion;
      }),
      new LineParser(deleteErrorRegex, (result, [branch]) => {
        const deletion = branchDeletionFailure(branch);
        result.errors.push(deletion);
        result.all.push(deletion);
        result.branches[branch] = deletion;
      })
    ];
    parseBranchDeletions = /* @__PURE__ */ __name((stdOut, stdErr) => {
      return parseStringResponse(new BranchDeletionBatch(), parsers8, [stdOut, stdErr]);
    }, "parseBranchDeletions");
  }
});
var BranchSummaryResult;
var init_BranchSummary = __esm2({
  "src/lib/responses/BranchSummary.ts"() {
    "use strict";
    BranchSummaryResult = class {
      static {
        __name(this, "BranchSummaryResult");
      }
      constructor() {
        this.all = [];
        this.branches = {};
        this.current = "";
        this.detached = false;
      }
      push(status, detached, name, commit, label) {
        if (status === "*") {
          this.detached = detached;
          this.current = name;
        }
        this.all.push(name);
        this.branches[name] = {
          current: status === "*",
          linkedWorkTree: status === "+",
          name,
          commit,
          label
        };
      }
    };
  }
});
function branchStatus(input) {
  return input ? input.charAt(0) : "";
}
__name(branchStatus, "branchStatus");
function parseBranchSummary(stdOut) {
  return parseStringResponse(new BranchSummaryResult(), parsers9, stdOut);
}
__name(parseBranchSummary, "parseBranchSummary");
var parsers9;
var init_parse_branch = __esm2({
  "src/lib/parsers/parse-branch.ts"() {
    "use strict";
    init_BranchSummary();
    init_utils();
    parsers9 = [
      new LineParser(
        /^([*+]\s)?\((?:HEAD )?detached (?:from|at) (\S+)\)\s+([a-z0-9]+)\s(.*)$/,
        (result, [current, name, commit, label]) => {
          result.push(branchStatus(current), true, name, commit, label);
        }
      ),
      new LineParser(
        new RegExp("^([*+]\\s)?(\\S+)\\s+([a-z0-9]+)\\s?(.*)$", "s"),
        (result, [current, name, commit, label]) => {
          result.push(branchStatus(current), false, name, commit, label);
        }
      )
    ];
  }
});
var branch_exports = {};
__export2(branch_exports, {
  branchLocalTask: /* @__PURE__ */ __name(() => branchLocalTask, "branchLocalTask"),
  branchTask: /* @__PURE__ */ __name(() => branchTask, "branchTask"),
  containsDeleteBranchCommand: /* @__PURE__ */ __name(() => containsDeleteBranchCommand, "containsDeleteBranchCommand"),
  deleteBranchTask: /* @__PURE__ */ __name(() => deleteBranchTask, "deleteBranchTask"),
  deleteBranchesTask: /* @__PURE__ */ __name(() => deleteBranchesTask, "deleteBranchesTask")
});
function containsDeleteBranchCommand(commands) {
  const deleteCommands = ["-d", "-D", "--delete"];
  return commands.some((command) => deleteCommands.includes(command));
}
__name(containsDeleteBranchCommand, "containsDeleteBranchCommand");
function branchTask(customArgs) {
  const isDelete = containsDeleteBranchCommand(customArgs);
  const commands = ["branch", ...customArgs];
  if (commands.length === 1) {
    commands.push("-a");
  }
  if (!commands.includes("-v")) {
    commands.splice(1, 0, "-v");
  }
  return {
    format: "utf-8",
    commands,
    parser(stdOut, stdErr) {
      if (isDelete) {
        return parseBranchDeletions(stdOut, stdErr).all[0];
      }
      return parseBranchSummary(stdOut);
    }
  };
}
__name(branchTask, "branchTask");
function branchLocalTask() {
  const parser4 = parseBranchSummary;
  return {
    format: "utf-8",
    commands: ["branch", "-v"],
    parser: parser4
  };
}
__name(branchLocalTask, "branchLocalTask");
function deleteBranchesTask(branches, forceDelete = false) {
  return {
    format: "utf-8",
    commands: ["branch", "-v", forceDelete ? "-D" : "-d", ...branches],
    parser(stdOut, stdErr) {
      return parseBranchDeletions(stdOut, stdErr);
    },
    onError({ exitCode, stdOut }, error, done, fail) {
      if (!hasBranchDeletionError(String(error), exitCode)) {
        return fail(error);
      }
      done(stdOut);
    }
  };
}
__name(deleteBranchesTask, "deleteBranchesTask");
function deleteBranchTask(branch, forceDelete = false) {
  const task = {
    format: "utf-8",
    commands: ["branch", "-v", forceDelete ? "-D" : "-d", branch],
    parser(stdOut, stdErr) {
      return parseBranchDeletions(stdOut, stdErr).branches[branch];
    },
    onError({ exitCode, stdErr, stdOut }, error, _, fail) {
      if (!hasBranchDeletionError(String(error), exitCode)) {
        return fail(error);
      }
      throw new GitResponseError(
        task.parser(bufferToString(stdOut), bufferToString(stdErr)),
        String(error)
      );
    }
  };
  return task;
}
__name(deleteBranchTask, "deleteBranchTask");
var init_branch = __esm2({
  "src/lib/tasks/branch.ts"() {
    "use strict";
    init_git_response_error();
    init_parse_branch_delete();
    init_parse_branch();
    init_utils();
  }
});
var parseCheckIgnore;
var init_CheckIgnore = __esm2({
  "src/lib/responses/CheckIgnore.ts"() {
    "use strict";
    parseCheckIgnore = /* @__PURE__ */ __name((text) => {
      return text.split(/\n/g).map((line) => line.trim()).filter((file) => !!file);
    }, "parseCheckIgnore");
  }
});
var check_ignore_exports = {};
__export2(check_ignore_exports, {
  checkIgnoreTask: /* @__PURE__ */ __name(() => checkIgnoreTask, "checkIgnoreTask")
});
function checkIgnoreTask(paths) {
  return {
    commands: ["check-ignore", ...paths],
    format: "utf-8",
    parser: parseCheckIgnore
  };
}
__name(checkIgnoreTask, "checkIgnoreTask");
var init_check_ignore = __esm2({
  "src/lib/tasks/check-ignore.ts"() {
    "use strict";
    init_CheckIgnore();
  }
});
var clone_exports = {};
__export2(clone_exports, {
  cloneMirrorTask: /* @__PURE__ */ __name(() => cloneMirrorTask, "cloneMirrorTask"),
  cloneTask: /* @__PURE__ */ __name(() => cloneTask, "cloneTask")
});
function disallowedCommand(command) {
  return /^--upload-pack(=|$)/.test(command);
}
__name(disallowedCommand, "disallowedCommand");
function cloneTask(repo, directory, customArgs) {
  const commands = ["clone", ...customArgs];
  filterString(repo) && commands.push(repo);
  filterString(directory) && commands.push(directory);
  const banned = commands.find(disallowedCommand);
  if (banned) {
    return configurationErrorTask(`git.fetch: potential exploit argument blocked.`);
  }
  return straightThroughStringTask(commands);
}
__name(cloneTask, "cloneTask");
function cloneMirrorTask(repo, directory, customArgs) {
  append(customArgs, "--mirror");
  return cloneTask(repo, directory, customArgs);
}
__name(cloneMirrorTask, "cloneMirrorTask");
var init_clone = __esm2({
  "src/lib/tasks/clone.ts"() {
    "use strict";
    init_task();
    init_utils();
  }
});
function parseFetchResult(stdOut, stdErr) {
  const result = {
    raw: stdOut,
    remote: null,
    branches: [],
    tags: [],
    updated: [],
    deleted: []
  };
  return parseStringResponse(result, parsers10, [stdOut, stdErr]);
}
__name(parseFetchResult, "parseFetchResult");
var parsers10;
var init_parse_fetch = __esm2({
  "src/lib/parsers/parse-fetch.ts"() {
    "use strict";
    init_utils();
    parsers10 = [
      new LineParser(/From (.+)$/, (result, [remote]) => {
        result.remote = remote;
      }),
      new LineParser(/\* \[new branch]\s+(\S+)\s*-> (.+)$/, (result, [name, tracking]) => {
        result.branches.push({
          name,
          tracking
        });
      }),
      new LineParser(/\* \[new tag]\s+(\S+)\s*-> (.+)$/, (result, [name, tracking]) => {
        result.tags.push({
          name,
          tracking
        });
      }),
      new LineParser(/- \[deleted]\s+\S+\s*-> (.+)$/, (result, [tracking]) => {
        result.deleted.push({
          tracking
        });
      }),
      new LineParser(
        /\s*([^.]+)\.\.(\S+)\s+(\S+)\s*-> (.+)$/,
        (result, [from, to, name, tracking]) => {
          result.updated.push({
            name,
            tracking,
            to,
            from
          });
        }
      )
    ];
  }
});
var fetch_exports = {};
__export2(fetch_exports, {
  fetchTask: /* @__PURE__ */ __name(() => fetchTask, "fetchTask")
});
function disallowedCommand2(command) {
  return /^--upload-pack(=|$)/.test(command);
}
__name(disallowedCommand2, "disallowedCommand2");
function fetchTask(remote, branch, customArgs) {
  const commands = ["fetch", ...customArgs];
  if (remote && branch) {
    commands.push(remote, branch);
  }
  const banned = commands.find(disallowedCommand2);
  if (banned) {
    return configurationErrorTask(`git.fetch: potential exploit argument blocked.`);
  }
  return {
    commands,
    format: "utf-8",
    parser: parseFetchResult
  };
}
__name(fetchTask, "fetchTask");
var init_fetch = __esm2({
  "src/lib/tasks/fetch.ts"() {
    "use strict";
    init_parse_fetch();
    init_task();
  }
});
function parseMoveResult(stdOut) {
  return parseStringResponse({ moves: [] }, parsers11, stdOut);
}
__name(parseMoveResult, "parseMoveResult");
var parsers11;
var init_parse_move = __esm2({
  "src/lib/parsers/parse-move.ts"() {
    "use strict";
    init_utils();
    parsers11 = [
      new LineParser(/^Renaming (.+) to (.+)$/, (result, [from, to]) => {
        result.moves.push({ from, to });
      })
    ];
  }
});
var move_exports = {};
__export2(move_exports, {
  moveTask: /* @__PURE__ */ __name(() => moveTask, "moveTask")
});
function moveTask(from, to) {
  return {
    commands: ["mv", "-v", ...asArray(from), to],
    format: "utf-8",
    parser: parseMoveResult
  };
}
__name(moveTask, "moveTask");
var init_move = __esm2({
  "src/lib/tasks/move.ts"() {
    "use strict";
    init_parse_move();
    init_utils();
  }
});
var pull_exports = {};
__export2(pull_exports, {
  pullTask: /* @__PURE__ */ __name(() => pullTask, "pullTask")
});
function pullTask(remote, branch, customArgs) {
  const commands = ["pull", ...customArgs];
  if (remote && branch) {
    commands.splice(1, 0, remote, branch);
  }
  return {
    commands,
    format: "utf-8",
    parser(stdOut, stdErr) {
      return parsePullResult(stdOut, stdErr);
    },
    onError(result, _error, _done, fail) {
      const pullError = parsePullErrorResult(
        bufferToString(result.stdOut),
        bufferToString(result.stdErr)
      );
      if (pullError) {
        return fail(new GitResponseError(pullError));
      }
      fail(_error);
    }
  };
}
__name(pullTask, "pullTask");
var init_pull = __esm2({
  "src/lib/tasks/pull.ts"() {
    "use strict";
    init_git_response_error();
    init_parse_pull();
    init_utils();
  }
});
function parseGetRemotes(text) {
  const remotes = {};
  forEach(text, ([name]) => remotes[name] = { name });
  return Object.values(remotes);
}
__name(parseGetRemotes, "parseGetRemotes");
function parseGetRemotesVerbose(text) {
  const remotes = {};
  forEach(text, ([name, url, purpose]) => {
    if (!remotes.hasOwnProperty(name)) {
      remotes[name] = {
        name,
        refs: { fetch: "", push: "" }
      };
    }
    if (purpose && url) {
      remotes[name].refs[purpose.replace(/[^a-z]/g, "")] = url;
    }
  });
  return Object.values(remotes);
}
__name(parseGetRemotesVerbose, "parseGetRemotesVerbose");
function forEach(text, handler) {
  forEachLineWithContent(text, (line) => handler(line.split(/\s+/)));
}
__name(forEach, "forEach");
var init_GetRemoteSummary = __esm2({
  "src/lib/responses/GetRemoteSummary.ts"() {
    "use strict";
    init_utils();
  }
});
var remote_exports = {};
__export2(remote_exports, {
  addRemoteTask: /* @__PURE__ */ __name(() => addRemoteTask, "addRemoteTask"),
  getRemotesTask: /* @__PURE__ */ __name(() => getRemotesTask, "getRemotesTask"),
  listRemotesTask: /* @__PURE__ */ __name(() => listRemotesTask, "listRemotesTask"),
  remoteTask: /* @__PURE__ */ __name(() => remoteTask, "remoteTask"),
  removeRemoteTask: /* @__PURE__ */ __name(() => removeRemoteTask, "removeRemoteTask")
});
function addRemoteTask(remoteName, remoteRepo, customArgs) {
  return straightThroughStringTask(["remote", "add", ...customArgs, remoteName, remoteRepo]);
}
__name(addRemoteTask, "addRemoteTask");
function getRemotesTask(verbose) {
  const commands = ["remote"];
  if (verbose) {
    commands.push("-v");
  }
  return {
    commands,
    format: "utf-8",
    parser: verbose ? parseGetRemotesVerbose : parseGetRemotes
  };
}
__name(getRemotesTask, "getRemotesTask");
function listRemotesTask(customArgs) {
  const commands = [...customArgs];
  if (commands[0] !== "ls-remote") {
    commands.unshift("ls-remote");
  }
  return straightThroughStringTask(commands);
}
__name(listRemotesTask, "listRemotesTask");
function remoteTask(customArgs) {
  const commands = [...customArgs];
  if (commands[0] !== "remote") {
    commands.unshift("remote");
  }
  return straightThroughStringTask(commands);
}
__name(remoteTask, "remoteTask");
function removeRemoteTask(remoteName) {
  return straightThroughStringTask(["remote", "remove", remoteName]);
}
__name(removeRemoteTask, "removeRemoteTask");
var init_remote = __esm2({
  "src/lib/tasks/remote.ts"() {
    "use strict";
    init_GetRemoteSummary();
    init_task();
  }
});
var stash_list_exports = {};
__export2(stash_list_exports, {
  stashListTask: /* @__PURE__ */ __name(() => stashListTask, "stashListTask")
});
function stashListTask(opt = {}, customArgs) {
  const options = parseLogOptions(opt);
  const commands = ["stash", "list", ...options.commands, ...customArgs];
  const parser4 = createListLogSummaryParser(
    options.splitter,
    options.fields,
    logFormatFromCommand(commands)
  );
  return validateLogFormatConfig(commands) || {
    commands,
    format: "utf-8",
    parser: parser4
  };
}
__name(stashListTask, "stashListTask");
var init_stash_list = __esm2({
  "src/lib/tasks/stash-list.ts"() {
    "use strict";
    init_log_format();
    init_parse_list_log_summary();
    init_diff();
    init_log();
  }
});
var sub_module_exports = {};
__export2(sub_module_exports, {
  addSubModuleTask: /* @__PURE__ */ __name(() => addSubModuleTask, "addSubModuleTask"),
  initSubModuleTask: /* @__PURE__ */ __name(() => initSubModuleTask, "initSubModuleTask"),
  subModuleTask: /* @__PURE__ */ __name(() => subModuleTask, "subModuleTask"),
  updateSubModuleTask: /* @__PURE__ */ __name(() => updateSubModuleTask, "updateSubModuleTask")
});
function addSubModuleTask(repo, path) {
  return subModuleTask(["add", repo, path]);
}
__name(addSubModuleTask, "addSubModuleTask");
function initSubModuleTask(customArgs) {
  return subModuleTask(["init", ...customArgs]);
}
__name(initSubModuleTask, "initSubModuleTask");
function subModuleTask(customArgs) {
  const commands = [...customArgs];
  if (commands[0] !== "submodule") {
    commands.unshift("submodule");
  }
  return straightThroughStringTask(commands);
}
__name(subModuleTask, "subModuleTask");
function updateSubModuleTask(customArgs) {
  return subModuleTask(["update", ...customArgs]);
}
__name(updateSubModuleTask, "updateSubModuleTask");
var init_sub_module = __esm2({
  "src/lib/tasks/sub-module.ts"() {
    "use strict";
    init_task();
  }
});
function singleSorted(a, b) {
  const aIsNum = isNaN(a);
  const bIsNum = isNaN(b);
  if (aIsNum !== bIsNum) {
    return aIsNum ? 1 : -1;
  }
  return aIsNum ? sorted(a, b) : 0;
}
__name(singleSorted, "singleSorted");
function sorted(a, b) {
  return a === b ? 0 : a > b ? 1 : -1;
}
__name(sorted, "sorted");
function trimmed(input) {
  return input.trim();
}
__name(trimmed, "trimmed");
function toNumber(input) {
  if (typeof input === "string") {
    return parseInt(input.replace(/^\D+/g, ""), 10) || 0;
  }
  return 0;
}
__name(toNumber, "toNumber");
var TagList, parseTagList;
var init_TagList = __esm2({
  "src/lib/responses/TagList.ts"() {
    "use strict";
    TagList = class {
      static {
        __name(this, "TagList");
      }
      constructor(all, latest) {
        this.all = all;
        this.latest = latest;
      }
    };
    parseTagList = /* @__PURE__ */ __name(function(data, customSort = false) {
      const tags = data.split("\n").map(trimmed).filter(Boolean);
      if (!customSort) {
        tags.sort(function(tagA, tagB) {
          const partsA = tagA.split(".");
          const partsB = tagB.split(".");
          if (partsA.length === 1 || partsB.length === 1) {
            return singleSorted(toNumber(partsA[0]), toNumber(partsB[0]));
          }
          for (let i = 0, l = Math.max(partsA.length, partsB.length); i < l; i++) {
            const diff = sorted(toNumber(partsA[i]), toNumber(partsB[i]));
            if (diff) {
              return diff;
            }
          }
          return 0;
        });
      }
      const latest = customSort ? tags[0] : [...tags].reverse().find((tag) => tag.indexOf(".") >= 0);
      return new TagList(tags, latest);
    }, "parseTagList");
  }
});
var tag_exports = {};
__export2(tag_exports, {
  addAnnotatedTagTask: /* @__PURE__ */ __name(() => addAnnotatedTagTask, "addAnnotatedTagTask"),
  addTagTask: /* @__PURE__ */ __name(() => addTagTask, "addTagTask"),
  tagListTask: /* @__PURE__ */ __name(() => tagListTask, "tagListTask")
});
function tagListTask(customArgs = []) {
  const hasCustomSort = customArgs.some((option) => /^--sort=/.test(option));
  return {
    format: "utf-8",
    commands: ["tag", "-l", ...customArgs],
    parser(text) {
      return parseTagList(text, hasCustomSort);
    }
  };
}
__name(tagListTask, "tagListTask");
function addTagTask(name) {
  return {
    format: "utf-8",
    commands: ["tag", name],
    parser() {
      return { name };
    }
  };
}
__name(addTagTask, "addTagTask");
function addAnnotatedTagTask(name, tagMessage) {
  return {
    format: "utf-8",
    commands: ["tag", "-a", "-m", tagMessage, name],
    parser() {
      return { name };
    }
  };
}
__name(addAnnotatedTagTask, "addAnnotatedTagTask");
var init_tag = __esm2({
  "src/lib/tasks/tag.ts"() {
    "use strict";
    init_TagList();
  }
});
var require_git = __commonJS2({
  "src/git.js"(exports, module) {
    "use strict";
    var { GitExecutor: GitExecutor2 } = (init_git_executor(), __toCommonJS(git_executor_exports));
    var { SimpleGitApi: SimpleGitApi2 } = (init_simple_git_api(), __toCommonJS(simple_git_api_exports));
    var { Scheduler: Scheduler2 } = (init_scheduler(), __toCommonJS(scheduler_exports));
    var { configurationErrorTask: configurationErrorTask2 } = (init_task(), __toCommonJS(task_exports));
    var {
      asArray: asArray2,
      filterArray: filterArray2,
      filterPrimitives: filterPrimitives2,
      filterString: filterString2,
      filterStringOrStringArray: filterStringOrStringArray2,
      filterType: filterType2,
      getTrailingOptions: getTrailingOptions2,
      trailingFunctionArgument: trailingFunctionArgument2,
      trailingOptionsArgument: trailingOptionsArgument2
    } = (init_utils(), __toCommonJS(utils_exports));
    var { applyPatchTask: applyPatchTask2 } = (init_apply_patch(), __toCommonJS(apply_patch_exports));
    var {
      branchTask: branchTask2,
      branchLocalTask: branchLocalTask2,
      deleteBranchesTask: deleteBranchesTask2,
      deleteBranchTask: deleteBranchTask2
    } = (init_branch(), __toCommonJS(branch_exports));
    var { checkIgnoreTask: checkIgnoreTask2 } = (init_check_ignore(), __toCommonJS(check_ignore_exports));
    var { checkIsRepoTask: checkIsRepoTask2 } = (init_check_is_repo(), __toCommonJS(check_is_repo_exports));
    var { cloneTask: cloneTask2, cloneMirrorTask: cloneMirrorTask2 } = (init_clone(), __toCommonJS(clone_exports));
    var { cleanWithOptionsTask: cleanWithOptionsTask2, isCleanOptionsArray: isCleanOptionsArray2 } = (init_clean(), __toCommonJS(clean_exports));
    var { diffSummaryTask: diffSummaryTask2 } = (init_diff(), __toCommonJS(diff_exports));
    var { fetchTask: fetchTask2 } = (init_fetch(), __toCommonJS(fetch_exports));
    var { moveTask: moveTask2 } = (init_move(), __toCommonJS(move_exports));
    var { pullTask: pullTask2 } = (init_pull(), __toCommonJS(pull_exports));
    var { pushTagsTask: pushTagsTask2 } = (init_push(), __toCommonJS(push_exports));
    var {
      addRemoteTask: addRemoteTask2,
      getRemotesTask: getRemotesTask2,
      listRemotesTask: listRemotesTask2,
      remoteTask: remoteTask2,
      removeRemoteTask: removeRemoteTask2
    } = (init_remote(), __toCommonJS(remote_exports));
    var { getResetMode: getResetMode2, resetTask: resetTask2 } = (init_reset(), __toCommonJS(reset_exports));
    var { stashListTask: stashListTask2 } = (init_stash_list(), __toCommonJS(stash_list_exports));
    var {
      addSubModuleTask: addSubModuleTask2,
      initSubModuleTask: initSubModuleTask2,
      subModuleTask: subModuleTask2,
      updateSubModuleTask: updateSubModuleTask2
    } = (init_sub_module(), __toCommonJS(sub_module_exports));
    var { addAnnotatedTagTask: addAnnotatedTagTask2, addTagTask: addTagTask2, tagListTask: tagListTask2 } = (init_tag(), __toCommonJS(tag_exports));
    var { straightThroughBufferTask: straightThroughBufferTask2, straightThroughStringTask: straightThroughStringTask2 } = (init_task(), __toCommonJS(task_exports));
    function Git2(options, plugins) {
      this._plugins = plugins;
      this._executor = new GitExecutor2(
        options.baseDir,
        new Scheduler2(options.maxConcurrentProcesses),
        plugins
      );
      this._trimmed = options.trimmed;
    }
    __name(Git2, "Git2");
    (Git2.prototype = Object.create(SimpleGitApi2.prototype)).constructor = Git2;
    Git2.prototype.customBinary = function(command) {
      this._plugins.reconfigure("binary", command);
      return this;
    };
    Git2.prototype.env = function(name, value) {
      if (arguments.length === 1 && typeof name === "object") {
        this._executor.env = name;
      } else {
        (this._executor.env = this._executor.env || {})[name] = value;
      }
      return this;
    };
    Git2.prototype.stashList = function(options) {
      return this._runTask(
        stashListTask2(
          trailingOptionsArgument2(arguments) || {},
          filterArray2(options) && options || []
        ),
        trailingFunctionArgument2(arguments)
      );
    };
    function createCloneTask(api, task, repoPath, localPath) {
      if (typeof repoPath !== "string") {
        return configurationErrorTask2(`git.${api}() requires a string 'repoPath'`);
      }
      return task(repoPath, filterType2(localPath, filterString2), getTrailingOptions2(arguments));
    }
    __name(createCloneTask, "createCloneTask");
    Git2.prototype.clone = function() {
      return this._runTask(
        createCloneTask("clone", cloneTask2, ...arguments),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.mirror = function() {
      return this._runTask(
        createCloneTask("mirror", cloneMirrorTask2, ...arguments),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.mv = function(from, to) {
      return this._runTask(moveTask2(from, to), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.checkoutLatestTag = function(then) {
      var git = this;
      return this.pull(function() {
        git.tags(function(err, tags) {
          git.checkout(tags.latest, then);
        });
      });
    };
    Git2.prototype.pull = function(remote, branch, options, then) {
      return this._runTask(
        pullTask2(
          filterType2(remote, filterString2),
          filterType2(branch, filterString2),
          getTrailingOptions2(arguments)
        ),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.fetch = function(remote, branch) {
      return this._runTask(
        fetchTask2(
          filterType2(remote, filterString2),
          filterType2(branch, filterString2),
          getTrailingOptions2(arguments)
        ),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.silent = function(silence) {
      console.warn(
        "simple-git deprecation notice: git.silent: logging should be configured using the `debug` library / `DEBUG` environment variable, this will be an error in version 3"
      );
      return this;
    };
    Git2.prototype.tags = function(options, then) {
      return this._runTask(
        tagListTask2(getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.rebase = function() {
      return this._runTask(
        straightThroughStringTask2(["rebase", ...getTrailingOptions2(arguments)]),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.reset = function(mode) {
      return this._runTask(
        resetTask2(getResetMode2(mode), getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.revert = function(commit) {
      const next = trailingFunctionArgument2(arguments);
      if (typeof commit !== "string") {
        return this._runTask(configurationErrorTask2("Commit must be a string"), next);
      }
      return this._runTask(
        straightThroughStringTask2(["revert", ...getTrailingOptions2(arguments, 0, true), commit]),
        next
      );
    };
    Git2.prototype.addTag = function(name) {
      const task = typeof name === "string" ? addTagTask2(name) : configurationErrorTask2("Git.addTag requires a tag name");
      return this._runTask(task, trailingFunctionArgument2(arguments));
    };
    Git2.prototype.addAnnotatedTag = function(tagName, tagMessage) {
      return this._runTask(
        addAnnotatedTagTask2(tagName, tagMessage),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.deleteLocalBranch = function(branchName, forceDelete, then) {
      return this._runTask(
        deleteBranchTask2(branchName, typeof forceDelete === "boolean" ? forceDelete : false),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.deleteLocalBranches = function(branchNames, forceDelete, then) {
      return this._runTask(
        deleteBranchesTask2(branchNames, typeof forceDelete === "boolean" ? forceDelete : false),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.branch = function(options, then) {
      return this._runTask(
        branchTask2(getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.branchLocal = function(then) {
      return this._runTask(branchLocalTask2(), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.raw = function(commands) {
      const createRestCommands = !Array.isArray(commands);
      const command = [].slice.call(createRestCommands ? arguments : commands, 0);
      for (let i = 0; i < command.length && createRestCommands; i++) {
        if (!filterPrimitives2(command[i])) {
          command.splice(i, command.length - i);
          break;
        }
      }
      command.push(...getTrailingOptions2(arguments, 0, true));
      var next = trailingFunctionArgument2(arguments);
      if (!command.length) {
        return this._runTask(
          configurationErrorTask2("Raw: must supply one or more command to execute"),
          next
        );
      }
      return this._runTask(straightThroughStringTask2(command, this._trimmed), next);
    };
    Git2.prototype.submoduleAdd = function(repo, path, then) {
      return this._runTask(addSubModuleTask2(repo, path), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.submoduleUpdate = function(args, then) {
      return this._runTask(
        updateSubModuleTask2(getTrailingOptions2(arguments, true)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.submoduleInit = function(args, then) {
      return this._runTask(
        initSubModuleTask2(getTrailingOptions2(arguments, true)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.subModule = function(options, then) {
      return this._runTask(
        subModuleTask2(getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.listRemote = function() {
      return this._runTask(
        listRemotesTask2(getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.addRemote = function(remoteName, remoteRepo, then) {
      return this._runTask(
        addRemoteTask2(remoteName, remoteRepo, getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.removeRemote = function(remoteName, then) {
      return this._runTask(removeRemoteTask2(remoteName), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.getRemotes = function(verbose, then) {
      return this._runTask(getRemotesTask2(verbose === true), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.remote = function(options, then) {
      return this._runTask(
        remoteTask2(getTrailingOptions2(arguments)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.tag = function(options, then) {
      const command = getTrailingOptions2(arguments);
      if (command[0] !== "tag") {
        command.unshift("tag");
      }
      return this._runTask(straightThroughStringTask2(command), trailingFunctionArgument2(arguments));
    };
    Git2.prototype.updateServerInfo = function(then) {
      return this._runTask(
        straightThroughStringTask2(["update-server-info"]),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.pushTags = function(remote, then) {
      const task = pushTagsTask2(
        { remote: filterType2(remote, filterString2) },
        getTrailingOptions2(arguments)
      );
      return this._runTask(task, trailingFunctionArgument2(arguments));
    };
    Git2.prototype.rm = function(files) {
      return this._runTask(
        straightThroughStringTask2(["rm", "-f", ...asArray2(files)]),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.rmKeepLocal = function(files) {
      return this._runTask(
        straightThroughStringTask2(["rm", "--cached", ...asArray2(files)]),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.catFile = function(options, then) {
      return this._catFile("utf-8", arguments);
    };
    Git2.prototype.binaryCatFile = function() {
      return this._catFile("buffer", arguments);
    };
    Git2.prototype._catFile = function(format, args) {
      var handler = trailingFunctionArgument2(args);
      var command = ["cat-file"];
      var options = args[0];
      if (typeof options === "string") {
        return this._runTask(
          configurationErrorTask2("Git.catFile: options must be supplied as an array of strings"),
          handler
        );
      }
      if (Array.isArray(options)) {
        command.push.apply(command, options);
      }
      const task = format === "buffer" ? straightThroughBufferTask2(command) : straightThroughStringTask2(command);
      return this._runTask(task, handler);
    };
    Git2.prototype.diff = function(options, then) {
      const task = filterString2(options) ? configurationErrorTask2(
        "git.diff: supplying options as a single string is no longer supported, switch to an array of strings"
      ) : straightThroughStringTask2(["diff", ...getTrailingOptions2(arguments)]);
      return this._runTask(task, trailingFunctionArgument2(arguments));
    };
    Git2.prototype.diffSummary = function() {
      return this._runTask(
        diffSummaryTask2(getTrailingOptions2(arguments, 1)),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.applyPatch = function(patches) {
      const task = !filterStringOrStringArray2(patches) ? configurationErrorTask2(
        `git.applyPatch requires one or more string patches as the first argument`
      ) : applyPatchTask2(asArray2(patches), getTrailingOptions2([].slice.call(arguments, 1)));
      return this._runTask(task, trailingFunctionArgument2(arguments));
    };
    Git2.prototype.revparse = function() {
      const commands = ["rev-parse", ...getTrailingOptions2(arguments, true)];
      return this._runTask(
        straightThroughStringTask2(commands, true),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.clean = function(mode, options, then) {
      const usingCleanOptionsArray = isCleanOptionsArray2(mode);
      const cleanMode = usingCleanOptionsArray && mode.join("") || filterType2(mode, filterString2) || "";
      const customArgs = getTrailingOptions2([].slice.call(arguments, usingCleanOptionsArray ? 1 : 0));
      return this._runTask(
        cleanWithOptionsTask2(cleanMode, customArgs),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.exec = function(then) {
      const task = {
        commands: [],
        format: "utf-8",
        parser() {
          if (typeof then === "function") {
            then();
          }
        }
      };
      return this._runTask(task);
    };
    Git2.prototype.clearQueue = function() {
      return this;
    };
    Git2.prototype.checkIgnore = function(pathnames, then) {
      return this._runTask(
        checkIgnoreTask2(asArray2(filterType2(pathnames, filterStringOrStringArray2, []))),
        trailingFunctionArgument2(arguments)
      );
    };
    Git2.prototype.checkIsRepo = function(checkType, then) {
      return this._runTask(
        checkIsRepoTask2(filterType2(checkType, filterString2)),
        trailingFunctionArgument2(arguments)
      );
    };
    module.exports = Git2;
  }
});
init_pathspec();
init_git_error();
var GitConstructError = class extends GitError {
  static {
    __name(this, "GitConstructError");
  }
  constructor(config, message) {
    super(void 0, message);
    this.config = config;
  }
};
init_git_error();
init_git_error();
var GitPluginError = class extends GitError {
  static {
    __name(this, "GitPluginError");
  }
  constructor(task, plugin, message) {
    super(task, message);
    this.task = task;
    this.plugin = plugin;
    Object.setPrototypeOf(this, new.target.prototype);
  }
};
init_git_response_error();
init_task_configuration_error();
init_check_is_repo();
init_clean();
init_config();
init_diff_name_status();
init_grep();
init_reset();
function abortPlugin(signal) {
  if (!signal) {
    return;
  }
  const onSpawnAfter = {
    type: "spawn.after",
    action(_data, context) {
      function kill() {
        context.kill(new GitPluginError(void 0, "abort", "Abort signal received"));
      }
      __name(kill, "kill");
      signal.addEventListener("abort", kill);
      context.spawned.on("close", () => signal.removeEventListener("abort", kill));
    }
  };
  const onSpawnBefore = {
    type: "spawn.before",
    action(_data, context) {
      if (signal.aborted) {
        context.kill(new GitPluginError(void 0, "abort", "Abort already signaled"));
      }
    }
  };
  return [onSpawnBefore, onSpawnAfter];
}
__name(abortPlugin, "abortPlugin");
function isConfigSwitch(arg) {
  return typeof arg === "string" && arg.trim().toLowerCase() === "-c";
}
__name(isConfigSwitch, "isConfigSwitch");
function preventProtocolOverride(arg, next) {
  if (!isConfigSwitch(arg)) {
    return;
  }
  if (!/^\s*protocol(.[a-z]+)?.allow/.test(next)) {
    return;
  }
  throw new GitPluginError(
    void 0,
    "unsafe",
    "Configuring protocol.allow is not permitted without enabling allowUnsafeExtProtocol"
  );
}
__name(preventProtocolOverride, "preventProtocolOverride");
function preventUploadPack(arg, method) {
  if (/^\s*--(upload|receive)-pack/.test(arg)) {
    throw new GitPluginError(
      void 0,
      "unsafe",
      `Use of --upload-pack or --receive-pack is not permitted without enabling allowUnsafePack`
    );
  }
  if (method === "clone" && /^\s*-u\b/.test(arg)) {
    throw new GitPluginError(
      void 0,
      "unsafe",
      `Use of clone with option -u is not permitted without enabling allowUnsafePack`
    );
  }
  if (method === "push" && /^\s*--exec\b/.test(arg)) {
    throw new GitPluginError(
      void 0,
      "unsafe",
      `Use of push with option --exec is not permitted without enabling allowUnsafePack`
    );
  }
}
__name(preventUploadPack, "preventUploadPack");
function blockUnsafeOperationsPlugin({
  allowUnsafeProtocolOverride = false,
  allowUnsafePack = false
} = {}) {
  return {
    type: "spawn.args",
    action(args, context) {
      args.forEach((current, index) => {
        const next = index < args.length ? args[index + 1] : "";
        allowUnsafeProtocolOverride || preventProtocolOverride(current, next);
        allowUnsafePack || preventUploadPack(current, context.method);
      });
      return args;
    }
  };
}
__name(blockUnsafeOperationsPlugin, "blockUnsafeOperationsPlugin");
init_utils();
function commandConfigPrefixingPlugin(configuration) {
  const prefix = prefixedArray(configuration, "-c");
  return {
    type: "spawn.args",
    action(data) {
      return [...prefix, ...data];
    }
  };
}
__name(commandConfigPrefixingPlugin, "commandConfigPrefixingPlugin");
init_utils();
var never = (0, import_promise_deferred2.deferred)().promise;
function completionDetectionPlugin({
  onClose = true,
  onExit = 50
} = {}) {
  function createEvents() {
    let exitCode = -1;
    const events = {
      close: (0, import_promise_deferred2.deferred)(),
      closeTimeout: (0, import_promise_deferred2.deferred)(),
      exit: (0, import_promise_deferred2.deferred)(),
      exitTimeout: (0, import_promise_deferred2.deferred)()
    };
    const result = Promise.race([
      onClose === false ? never : events.closeTimeout.promise,
      onExit === false ? never : events.exitTimeout.promise
    ]);
    configureTimeout(onClose, events.close, events.closeTimeout);
    configureTimeout(onExit, events.exit, events.exitTimeout);
    return {
      close(code) {
        exitCode = code;
        events.close.done();
      },
      exit(code) {
        exitCode = code;
        events.exit.done();
      },
      get exitCode() {
        return exitCode;
      },
      result
    };
  }
  __name(createEvents, "createEvents");
  function configureTimeout(flag, event, timeout) {
    if (flag === false) {
      return;
    }
    (flag === true ? event.promise : event.promise.then(() => delay(flag))).then(timeout.done);
  }
  __name(configureTimeout, "configureTimeout");
  return {
    type: "spawn.after",
    action(_0, _1) {
      return __async(this, arguments, function* (_data, { spawned, close }) {
        var _a3, _b;
        const events = createEvents();
        let deferClose = true;
        let quickClose = /* @__PURE__ */ __name(() => void (deferClose = false), "quickClose");
        (_a3 = spawned.stdout) == null ? void 0 : _a3.on("data", quickClose);
        (_b = spawned.stderr) == null ? void 0 : _b.on("data", quickClose);
        spawned.on("error", quickClose);
        spawned.on("close", (code) => events.close(code));
        spawned.on("exit", (code) => events.exit(code));
        try {
          yield events.result;
          if (deferClose) {
            yield delay(50);
          }
          close(events.exitCode);
        } catch (err) {
          close(events.exitCode, err);
        }
      });
    }
  };
}
__name(completionDetectionPlugin, "completionDetectionPlugin");
init_utils();
var WRONG_NUMBER_ERR = `Invalid value supplied for custom binary, requires a single string or an array containing either one or two strings`;
var WRONG_CHARS_ERR = `Invalid value supplied for custom binary, restricted characters must be removed or supply the unsafe.allowUnsafeCustomBinary option`;
function isBadArgument(arg) {
  return !arg || !/^([a-z]:)?([a-z0-9/.\\_-]+)$/i.test(arg);
}
__name(isBadArgument, "isBadArgument");
function toBinaryConfig(input, allowUnsafe) {
  if (input.length < 1 || input.length > 2) {
    throw new GitPluginError(void 0, "binary", WRONG_NUMBER_ERR);
  }
  const isBad = input.some(isBadArgument);
  if (isBad) {
    if (allowUnsafe) {
      console.warn(WRONG_CHARS_ERR);
    } else {
      throw new GitPluginError(void 0, "binary", WRONG_CHARS_ERR);
    }
  }
  const [binary, prefix] = input;
  return {
    binary,
    prefix
  };
}
__name(toBinaryConfig, "toBinaryConfig");
function customBinaryPlugin(plugins, input = ["git"], allowUnsafe = false) {
  let config = toBinaryConfig(asArray(input), allowUnsafe);
  plugins.on("binary", (input2) => {
    config = toBinaryConfig(asArray(input2), allowUnsafe);
  });
  plugins.append("spawn.binary", () => {
    return config.binary;
  });
  plugins.append("spawn.args", (data) => {
    return config.prefix ? [config.prefix, ...data] : data;
  });
}
__name(customBinaryPlugin, "customBinaryPlugin");
init_git_error();
function isTaskError(result) {
  return !!(result.exitCode && result.stdErr.length);
}
__name(isTaskError, "isTaskError");
function getErrorMessage(result) {
  return Buffer.concat([...result.stdOut, ...result.stdErr]);
}
__name(getErrorMessage, "getErrorMessage");
function errorDetectionHandler(overwrite = false, isError = isTaskError, errorMessage = getErrorMessage) {
  return (error, result) => {
    if (!overwrite && error || !isError(result)) {
      return error;
    }
    return errorMessage(result);
  };
}
__name(errorDetectionHandler, "errorDetectionHandler");
function errorDetectionPlugin(config) {
  return {
    type: "task.error",
    action(data, context) {
      const error = config(data.error, {
        stdErr: context.stdErr,
        stdOut: context.stdOut,
        exitCode: context.exitCode
      });
      if (Buffer.isBuffer(error)) {
        return { error: new GitError(void 0, error.toString("utf-8")) };
      }
      return {
        error
      };
    }
  };
}
__name(errorDetectionPlugin, "errorDetectionPlugin");
init_utils();
import { EventEmitter } from "node:events";
var PluginStore = class {
  static {
    __name(this, "PluginStore");
  }
  constructor() {
    this.plugins = /* @__PURE__ */ new Set();
    this.events = new EventEmitter();
  }
  on(type, listener) {
    this.events.on(type, listener);
  }
  reconfigure(type, data) {
    this.events.emit(type, data);
  }
  append(type, action) {
    const plugin = append(this.plugins, { type, action });
    return () => this.plugins.delete(plugin);
  }
  add(plugin) {
    const plugins = [];
    asArray(plugin).forEach((plugin2) => plugin2 && this.plugins.add(append(plugins, plugin2)));
    return () => {
      plugins.forEach((plugin2) => this.plugins.delete(plugin2));
    };
  }
  exec(type, data, context) {
    let output = data;
    const contextual = Object.freeze(Object.create(context));
    for (const plugin of this.plugins) {
      if (plugin.type === type) {
        output = plugin.action(output, contextual);
      }
    }
    return output;
  }
};
init_utils();
function progressMonitorPlugin(progress) {
  const progressCommand = "--progress";
  const progressMethods = ["checkout", "clone", "fetch", "pull", "push"];
  const onProgress = {
    type: "spawn.after",
    action(_data, context) {
      var _a2;
      if (!context.commands.includes(progressCommand)) {
        return;
      }
      (_a2 = context.spawned.stderr) == null ? void 0 : _a2.on("data", (chunk) => {
        const message = /^([\s\S]+?):\s*(\d+)% \((\d+)\/(\d+)\)/.exec(chunk.toString("utf8"));
        if (!message) {
          return;
        }
        progress({
          method: context.method,
          stage: progressEventStage(message[1]),
          progress: asNumber(message[2]),
          processed: asNumber(message[3]),
          total: asNumber(message[4])
        });
      });
    }
  };
  const onArgs = {
    type: "spawn.args",
    action(args, context) {
      if (!progressMethods.includes(context.method)) {
        return args;
      }
      return including(args, progressCommand);
    }
  };
  return [onArgs, onProgress];
}
__name(progressMonitorPlugin, "progressMonitorPlugin");
function progressEventStage(input) {
  return String(input.toLowerCase().split(" ", 1)) || "unknown";
}
__name(progressEventStage, "progressEventStage");
init_utils();
function spawnOptionsPlugin(spawnOptions) {
  const options = pick(spawnOptions, ["uid", "gid"]);
  return {
    type: "spawn.options",
    action(data) {
      return __spreadValues(__spreadValues({}, options), data);
    }
  };
}
__name(spawnOptionsPlugin, "spawnOptionsPlugin");
function timeoutPlugin({
  block,
  stdErr = true,
  stdOut = true
}) {
  if (block > 0) {
    return {
      type: "spawn.after",
      action(_data, context) {
        var _a2, _b;
        let timeout;
        function wait() {
          timeout && clearTimeout(timeout);
          timeout = setTimeout(kill, block);
        }
        __name(wait, "wait");
        function stop() {
          var _a3, _b2;
          (_a3 = context.spawned.stdout) == null ? void 0 : _a3.off("data", wait);
          (_b2 = context.spawned.stderr) == null ? void 0 : _b2.off("data", wait);
          context.spawned.off("exit", stop);
          context.spawned.off("close", stop);
          timeout && clearTimeout(timeout);
        }
        __name(stop, "stop");
        function kill() {
          stop();
          context.kill(new GitPluginError(void 0, "timeout", `block timeout reached`));
        }
        __name(kill, "kill");
        stdOut && ((_a2 = context.spawned.stdout) == null ? void 0 : _a2.on("data", wait));
        stdErr && ((_b = context.spawned.stderr) == null ? void 0 : _b.on("data", wait));
        context.spawned.on("exit", stop);
        context.spawned.on("close", stop);
        wait();
      }
    };
  }
}
__name(timeoutPlugin, "timeoutPlugin");
init_pathspec();
function suffixPathsPlugin() {
  return {
    type: "spawn.args",
    action(data) {
      const prefix = [];
      let suffix;
      function append2(args) {
        (suffix = suffix || []).push(...args);
      }
      __name(append2, "append2");
      for (let i = 0; i < data.length; i++) {
        const param = data[i];
        if (isPathSpec(param)) {
          append2(toPaths(param));
          continue;
        }
        if (param === "--") {
          append2(
            data.slice(i + 1).flatMap((item) => isPathSpec(item) && toPaths(item) || item)
          );
          break;
        }
        prefix.push(param);
      }
      return !suffix ? prefix : [...prefix, "--", ...suffix.map(String)];
    }
  };
}
__name(suffixPathsPlugin, "suffixPathsPlugin");
init_utils();
var Git = require_git();
function gitInstanceFactory(baseDir, options) {
  var _a2;
  const plugins = new PluginStore();
  const config = createInstanceConfig(
    baseDir && (typeof baseDir === "string" ? { baseDir } : baseDir) || {},
    options
  );
  if (!folderExists(config.baseDir)) {
    throw new GitConstructError(
      config,
      `Cannot use simple-git on a directory that does not exist`
    );
  }
  if (Array.isArray(config.config)) {
    plugins.add(commandConfigPrefixingPlugin(config.config));
  }
  plugins.add(blockUnsafeOperationsPlugin(config.unsafe));
  plugins.add(suffixPathsPlugin());
  plugins.add(completionDetectionPlugin(config.completion));
  config.abort && plugins.add(abortPlugin(config.abort));
  config.progress && plugins.add(progressMonitorPlugin(config.progress));
  config.timeout && plugins.add(timeoutPlugin(config.timeout));
  config.spawnOptions && plugins.add(spawnOptionsPlugin(config.spawnOptions));
  plugins.add(errorDetectionPlugin(errorDetectionHandler(true)));
  config.errors && plugins.add(errorDetectionPlugin(config.errors));
  customBinaryPlugin(plugins, config.binary, (_a2 = config.unsafe) == null ? void 0 : _a2.allowUnsafeCustomBinary);
  return new Git(config, plugins);
}
__name(gitInstanceFactory, "gitInstanceFactory");
init_git_response_error();
var functionNamesBuilderApi = ["customBinary", "env", "outputHandler", "silent"];
var functionNamesPromiseApi = [
  "add",
  "addAnnotatedTag",
  "addConfig",
  "addRemote",
  "addTag",
  "applyPatch",
  "binaryCatFile",
  "branch",
  "branchLocal",
  "catFile",
  "checkIgnore",
  "checkIsRepo",
  "checkout",
  "checkoutBranch",
  "checkoutLatestTag",
  "checkoutLocalBranch",
  "clean",
  "clone",
  "commit",
  "cwd",
  "deleteLocalBranch",
  "deleteLocalBranches",
  "diff",
  "diffSummary",
  "exec",
  "fetch",
  "getRemotes",
  "init",
  "listConfig",
  "listRemote",
  "log",
  "merge",
  "mergeFromTo",
  "mirror",
  "mv",
  "pull",
  "push",
  "pushTags",
  "raw",
  "rebase",
  "remote",
  "removeRemote",
  "reset",
  "revert",
  "revparse",
  "rm",
  "rmKeepLocal",
  "show",
  "stash",
  "stashList",
  "status",
  "subModule",
  "submoduleAdd",
  "submoduleInit",
  "submoduleUpdate",
  "tag",
  "tags",
  "updateServerInfo"
];
function gitP(...args) {
  let git;
  let chain = Promise.resolve();
  try {
    git = gitInstanceFactory(...args);
  } catch (e) {
    chain = Promise.reject(e);
  }
  function builderReturn() {
    return promiseApi;
  }
  __name(builderReturn, "builderReturn");
  function chainReturn() {
    return chain;
  }
  __name(chainReturn, "chainReturn");
  const promiseApi = [...functionNamesBuilderApi, ...functionNamesPromiseApi].reduce(
    (api, name) => {
      const isAsync = functionNamesPromiseApi.includes(name);
      const valid = isAsync ? asyncWrapper(name, git) : syncWrapper(name, git, api);
      const alternative = isAsync ? chainReturn : builderReturn;
      Object.defineProperty(api, name, {
        enumerable: false,
        configurable: false,
        value: git ? valid : alternative
      });
      return api;
    },
    {}
  );
  return promiseApi;
  function asyncWrapper(fn, git2) {
    return function(...args2) {
      if (typeof args2[args2.length] === "function") {
        throw new TypeError(
          "Promise interface requires that handlers are not supplied inline, trailing function not allowed in call to " + fn
        );
      }
      return chain.then(function() {
        return new Promise(function(resolve, reject) {
          const callback = /* @__PURE__ */ __name((err, result) => {
            if (err) {
              return reject(toError(err));
            }
            resolve(result);
          }, "callback");
          args2.push(callback);
          git2[fn].apply(git2, args2);
        });
      });
    };
  }
  __name(asyncWrapper, "asyncWrapper");
  function syncWrapper(fn, git2, api) {
    return (...args2) => {
      git2[fn](...args2);
      return api;
    };
  }
  __name(syncWrapper, "syncWrapper");
}
__name(gitP, "gitP");
function toError(error) {
  if (error instanceof Error) {
    return error;
  }
  if (typeof error === "string") {
    return new Error(error);
  }
  return new GitResponseError(error);
}
__name(toError, "toError");
var simpleGit = gitInstanceFactory;
var esm_default = gitInstanceFactory;

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlash(path) {
  return path.replace(/\/$/, "");
}
__name(removeTrialingSlash, "removeTrialingSlash");
function retryPromise(promise) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config.accessor(item)]: config.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return {
      value: await fn(),
      error: void 0
    };
  } catch (error) {
    return { error };
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlash(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser4 = new parserType(this.slice());
    const { expression, index } = parser4.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser4 = new DSLParser(input);
  return parser4.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/compiler/sdk/devkit/src/lib/data/actions.json
var actions_default = [
  {
    id: "077b1325-0ade-4f63-8f66-ced39cef38ba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Atomic",
    name: "atomic",
    visible: true,
    multi: true,
    allowedActions: [],
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "9c858969-f48b-4b72-8282-bfe82654ae9a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Delete Record",
    name: "delete-record",
    visible: true,
    output: {
      displayName: "deletedRecord",
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    },
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      cascade: {
        displayName: "Cascade",
        type: "boolean",
        defaultValue: true,
        required: true,
        visible: false
      }
    }
  },
  {
    id: "b036bc50-9292-486a-9714-1f551fee5dc4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Record Exist",
    name: "check-record-existance",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "recordExists",
      source: [
        {
          id: "recordExists",
          primitiveType: "boolean",
          displayName: "recordExists"
        }
      ]
    }
  },
  {
    id: "83ce1e80-0117-4ebc-86ac-3bdad3b32796",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Insert Record",
    name: "insert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      columns: {
        displayName: "Payload",
        type: "columns-list",
        required: false,
        source: {
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ],
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "2bb630dd-7ba3-4cda-95a7-f65ee22116ee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Raw SQL Query",
    name: "raw-sql-query",
    metadata: {
      query: {
        displayName: "Query",
        type: "string",
        required: true
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "62e55ba2-9a81-4f88-995e-2093ca3fc067",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Upsert Record",
    name: "upsert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select"
      },
      columns: {
        displayName: "Payload",
        type: "columns-list"
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "a8ded515-b99e-4fca-9654-7d2c12624a7a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "increment-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "b5a5e901-9ef8-4d2c-86f2-39263ca8ebee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "decrement-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    output: {
      type: "context.tableId",
      displayName: "updatedRecord",
      source: []
    },
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Set Fields",
    name: "set-fields",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      columns: {
        displayName: "Field",
        type: "columns-list",
        required: true,
        source: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          },
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ]
        }
      }
    }
  },
  {
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    displayName: "With i18n",
    name: "i18n"
  },
  {
    id: "3c40908c-1c69-4222-a936-7a569a1198b5",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "Upload file to google storage",
    name: "upload-file",
    output: {
      displayName: "uploadedFile",
      source: []
    },
    metadata: {
      multiple: {
        displayName: "Can upload multiple files",
        type: "boolean",
        required: false,
        defaultValue: "@fixed:false"
      },
      maxFileCount: {
        displayName: "Maximum file count",
        type: "number",
        required: false,
        defaultValue: "@fixed:1",
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxTotalSize: {
        displayName: "Maximum total size",
        type: "number",
        required: false,
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxFileSize: {
        displayName: "Maximum file size",
        type: "number",
        required: false
      }
    }
  },
  {
    id: "c4ec127b-e167-4a30-8544-732c55d1bd24",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "List Records",
    name: "list-records",
    metadata: {
      localizable: {
        displayName: "Localizable",
        type: "boolean",
        required: false,
        fieldset: "first",
        visible: false,
        defaultValue: "false"
      },
      pagination: {
        displayName: "Pagination",
        type: "single-select",
        required: true,
        fieldset: "pagination",
        defaultValue: "deferred_joins",
        source: [
          {
            id: "none",
            displayName: "None"
          },
          {
            id: "limit_offset",
            displayName: "Limit & Offset"
          },
          {
            id: "deferred_joins",
            displayName: "Deferred Joins"
          },
          {
            id: "cursor",
            displayName: "Cursor"
          }
        ]
      },
      tableId: {
        displayName: "Table",
        type: "single-select",
        fieldset: "first",
        required: true,
        source: {
          url: "/tables"
        }
      },
      limit: {
        displayName: "Limit",
        type: "number",
        required: false,
        fieldset: "pagination",
        defaultValue: 50
      },
      query: {
        displayName: "Query",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      source: {
        input: "context.pagination",
        operator: "equal",
        value: "none",
        then: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        },
        else: [
          {
            id: "records",
            displayName: "records",
            primitiveType: {
              input: "context.limit",
              operator: "equal",
              value: 1,
              then: "object",
              else: "array"
            },
            typeName: {
              url: "/tables/:id",
              binding: {
                id: "context.tableId"
              },
              use: "displayName"
            },
            interface: {
              url: "/tables/:id/fields",
              binding: {
                id: "context.tableId"
              }
            },
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          },
          {
            id: "meta",
            displayName: "meta",
            typeName: "Meta",
            primitiveType: "object",
            interface: [
              {
                id: "hasNextPage",
                displayName: "hasNextPage",
                primitiveType: "boolean"
              },
              {
                id: "hasPreviousPage",
                displayName: "hasPreviousPage",
                primitiveType: "boolean"
              },
              {
                id: "pageSize",
                displayName: "pageSize",
                primitiveType: "number"
              },
              {
                id: "currentPage",
                displayName: "currentPage",
                primitiveType: "number"
              },
              {
                id: "totalCount",
                displayName: "totalCount",
                primitiveType: "number"
              },
              {
                id: "totalPages",
                displayName: "totalPages",
                primitiveType: "number"
              }
            ],
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          }
        ]
      }
    }
  },
  {
    id: "89ad4cdb-2ed1-4c42-84bd-4986648bbfe2",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "List Files",
    name: "list-files",
    output: {
      displayName: "files",
      source: []
    },
    metadata: {
      prefix: {
        displayName: "Prefix",
        type: "string",
        required: false,
        fieldset: "first"
      },
      flat: {
        displayName: "Flat",
        type: "boolean",
        required: false,
        fieldset: "first"
      }
    }
  },
  {
    id: "43ea3f72-f3b0-419f-abef-f1bd4b5e9b22",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Custom Code",
    name: "custom-code",
    output: {
      source: []
    },
    metadata: {
      code: {
        displayName: "Code",
        type: "code-editor",
        required: true,
        extras: {
          language: "typescript"
        }
      }
    }
  },
  {
    id: "e0c60892-6b26-417e-8140-8e8d31f64ab2",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Branch",
    name: "branch",
    type: "branch",
    multi: true,
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "89e16a38-25f1-444e-bcf7-96e6455c3707",
    extensionId: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    displayName: "Send Email",
    name: "send-email",
    output: {
      outputName: "sentEmail",
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        required: true,
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        required: true,
        fieldset: "email"
      },
      replayTo: {
        displayName: "Replay To",
        type: "string",
        required: false
      },
      subject: {
        displayName: "Subject",
        type: "string",
        required: true,
        fieldset: "content"
      },
      templateId: {
        displayName: "Template",
        type: "string",
        fieldset: "content",
        required: true
      }
    }
  },
  {
    id: "69a01ada-a83a-451f-a3fe-fb486e08ffa9",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Send Email",
    name: "resend-send-email",
    output: {
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      subject: {
        displayName: "Subject",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "content"
      },
      text: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      html: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "c292a9d7-1f66-47b9-b366-e25f3faff840",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Create Contact",
    name: "resend-create-contact",
    output: {
      source: []
    },
    metadata: {
      firstName: {
        displayName: "First name",
        type: "string",
        fieldset: "general"
      },
      lastName: {
        displayName: "Last name",
        type: "string",
        required: false,
        fieldset: "general"
      },
      email: {
        displayName: "Email",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      unsubscribed: {
        displayName: "Unsubscribed",
        type: "string",
        required: false,
        fieldset: "email"
      },
      audienceId: {
        displayName: "Audience id",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b",
    extensionId: "389d81cd-5b58-4ade-b815-add468c48e37",
    displayName: "Ajax",
    name: "ajax",
    output: {
      source: []
    },
    metadata: {
      url: {
        displayName: "URL",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      method: {
        displayName: "Method",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      body: {
        displayName: "Body",
        type: "json",
        required: false
      }
    }
  },
  {
    id: "7a9d9a29-7079-4aa8-bdc0-d93a713a2440",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger",
    metadata: {
      path: {
        fieldset: "config",
        type: "string",
        displayName: "Path",
        required: true,
        pattern: "^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"
      },
      method: {
        fieldset: "config",
        displayName: "Method",
        type: "single-select",
        source: [
          {
            id: "get",
            displayName: "GET"
          },
          {
            id: "post",
            displayName: "POST"
          },
          {
            id: "put",
            displayName: "PUT"
          },
          {
            id: "patch",
            displayName: "PATCH"
          },
          {
            id: "delete",
            displayName: "DELETE"
          },
          {
            id: "head",
            displayName: "HEAD"
          }
        ],
        required: true
      },
      contentType: {
        visible: false,
        fieldset: "optional",
        type: "single-select",
        displayName: "Content Type",
        required: false,
        source: [
          {
            id: "application/json",
            displayName: "application/json"
          },
          {
            id: "application/x-www-form-urlencoded",
            displayName: "application/x-www-form-urlencoded"
          },
          {
            id: "multipart/form-data",
            displayName: "multipart/form-data"
          }
        ]
      },
      summary: {
        fieldset: "optional",
        type: "string",
        displayName: "Summary",
        required: false,
        visible: false
      }
    }
  },
  {
    id: "0aec7685-5c19-43eb-bc2c-93597b5cecfc",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    id: "6432f258-6511-4d8a-86a6-628db3f333e7",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    id: "7b1696e9-9c89-4ba7-abc0-e1448b287772",
    extensionId: "9c034274-069e-4567-ab33-bab8f31f874c",
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    id: "0bd0b432-5f7a-447a-afab-6db83d8976b1",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    id: "cd76caa3-e9f0-49b8-bf7a-0ebed83bd486",
    extensionId: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/extensions.json
var extensions_default = [
  {
    id: "e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b",
    visible: false,
    name: "soft-delete",
    categories: ["soft-delete"],
    title: "",
    subtitle: "Support Soft Delete functionality in any table.",
    description: "Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.",
    tableMetadata: {
      tableId: {
        displayName: "Support Soft Delete",
        required: false,
        visible: false,
        type: "single-select",
        source: [
          {
            id: "none",
            displayName: "No soft delete"
          },
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag"
          },
          {
            id: "trash",
            displayName: "Using trash table"
          }
        ]
      }
    },
    metadata: {}
  },
  {
    id: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    visible: true,
    name: "core",
    categories: ["misc"],
    title: "Core",
    main: "src/core/validation.ts",
    subtitle: "Core functionality",
    metadata: {},
    description: "Essential functionality that is required for all projects."
  },
  {
    id: "977a059f-ddda-4677-b785-4d1b04a7c201",
    visible: true,
    name: "prettier",
    categories: ["misc"],
    title: "Prettier",
    subtitle: "An opinionated code formatter",
    description: "Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.",
    logo: "assets/prettier.png",
    metadata: {}
  },
  {
    id: "e81b26bb-051b-4b30-a94d-e34ad615504c",
    visible: true,
    name: "identity",
    categories: ["misc"],
    title: "identity",
    subtitle: "identity",
    description: "",
    metadata: {}
  },
  {
    id: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "postgresql",
    categories: ["database"],
    main: "src/extensions/postgresql/index.ts",
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "PostgreSQL",
    subtitle: "A free and open-source relational database management system emphasizing extensibility and SQL compliance.",
    description: "PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "71c97a1c-3efe-4712-b35b-56714dafa02f",
    name: "mysql",
    categories: ["database"],
    disabled: true,
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "MySQL",
    description: "MySQL is an open-source relational database management system.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    name: "firebase-functions",
    categories: ["hosting"],
    disabled: true,
    logo: "assets/firebase-functions.png",
    svg: "SiFirebase",
    title: "Firebase Functions",
    subtitle: "Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code",
    description: "Firebase Functions is a serverless framework that lets you automatically run backend code.",
    metadata: {
      FIREBASE_FUNCTION_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"
      }
    }
  },
  {
    id: "d9e83836-e41d-4ae2-aa93-229a0ef27069",
    name: "firebase-auth",
    categories: ["identity"],
    disabled: false,
    main: "firebase.ts",
    metadata: {
      FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"
      }
    },
    title: "Firebase Authentication",
    description: "Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.",
    subtitle: "Authenticate users with Firebase"
  },
  {
    id: "34d9ec05-de0d-4d79-ae2a-9a06200d20dd",
    name: "fly",
    categories: ["hosting"],
    logo: "assets/fly.png",
    title: "Fly",
    description: "Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.",
    metadata: {
      FLY_API_TOKEN: {
        displayName: "Deploy Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_API_TOKEN",
        description: "The token to deploy the app"
      },
      FLY_APP_NAME: {
        displayName: "App Name",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_APP_NAME",
        description: "The name of the app"
      }
    }
  },
  {
    name: "vercel",
    id: "4c82c872-1a2f-4849-98a6-bd7017498191",
    categories: ["hosting"],
    title: "Vercel",
    description: "Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.",
    metadata: {
      VERCEL_ORG_ID: {
        displayName: "Org ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_ORG_ID"
      },
      VERCEL_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_PROJECT_ID"
      },
      VERCEL_API_TOKEN: {
        displayName: "API Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_API_TOKEN"
      }
    }
  },
  {
    id: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    name: "hono",
    categories: ["routing"],
    title: "Hono.dev",
    main: "src/extensions/tus/index.ts",
    description: "Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.",
    metadata: {}
  },
  {
    id: "109aa1af-f9d0-4d31-bbc6-c4603be5b7b0",
    name: "koajs",
    disabled: true,
    categories: ["routing"],
    title: "Koa.js",
    description: "Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.",
    logo: "assets/http.svg",
    metadata: {},
    svg: "SiKoa",
    packages: [
      {
        name: "koa",
        version: "latest"
      },
      {
        name: "koa-static",
        version: "latest"
      },
      {
        name: "@types/koa-static",
        version: "latest"
      },
      {
        name: "@koa/router",
        version: "latest"
      },
      {
        name: "koa-body",
        version: "latest"
      },
      {
        name: "koa-bodyparser",
        version: "latest"
      },
      {
        name: "koa-logger",
        version: "latest"
      },
      {
        name: "koa-qs",
        version: "latest"
      },
      {
        name: "@koa/cors",
        version: "latest"
      },
      {
        name: "@types/koa-logger",
        version: "latest"
      },
      {
        name: "@types/koa__cors",
        version: "^3.3.0"
      },
      {
        name: "@types/koa__router",
        version: "^12.0.0"
      },
      {
        name: "@types/koa-bodyparser",
        version: "^4.3.10"
      },
      {
        name: "@types/koa-qs",
        version: "^2.0.0"
      },
      {
        name: "swagger-ui-dist",
        version: "latest"
      },
      {
        name: "@types/swagger-ui-dist",
        version: "latest"
      }
    ]
  },
  {
    id: "3633c476-c120-4f9f-893b-b6b03f67b9e9",
    name: "expressjs",
    svg: "SiExpress",
    disabled: true,
    categories: ["routing"],
    title: "Express.js",
    description: "Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
    logo: "assets/http.svg",
    metadata: {},
    packages: [
      {
        name: "express",
        version: "latest"
      },
      {
        name: "body-parser",
        version: "latest"
      },
      {
        name: "morgan",
        version: "latest"
      },
      {
        name: "cors",
        version: "latest"
      },
      {
        name: "@types/express",
        version: "latest",
        dev: true
      },
      {
        name: "@types/body-parser",
        version: "latest",
        dev: true
      },
      {
        name: "@types/cors",
        version: "latest",
        dev: true
      },
      {
        name: "@types/morgan",
        version: "latest",
        dev: true
      }
    ]
  },
  {
    id: "3e184f8b-d2dc-4592-9507-979d649277f5",
    visible: true,
    name: "gcs",
    categories: ["file-storage"],
    logo: "assets/cloud-storage.svg",
    title: "Google Cloud Storage",
    description: "Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google's cloud with advanced security and sharing capabilities.",
    main: "src/extensions/gcs/index.ts",
    metadata: {
      BUCKET_NAME: {
        _comment: "// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won't work",
        displayName: "Bucket Name",
        type: "string",
        required: true,
        description: "The name of the bucket"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        type: "json",
        description: "The service account key to access the bucket",
        required: true
      }
    }
  },
  {
    id: "9c034274-069e-4567-ab33-bab8f31f874c",
    visible: true,
    name: "github",
    categories: [],
    title: "GitHub Webhooks",
    description: "GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com",
    metadata: {
      WEBHOOK_SECRET: {
        displayName: "Webhook Secret",
        defaultValue: "@process:env.WEBHOOK_SECRET",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    visible: true,
    name: "node-cron",
    categories: ["schedulers"],
    title: "Node Cron",
    description: "A simple cron-like job scheduler for Node.js",
    metadata: {},
    packages: [
      {
        name: "@types/node-cron",
        version: "^3.0.11",
        dev: true
      },
      {
        name: "node-cron",
        version: "^3.0.3"
      }
    ]
  },
  {
    id: "389d81cd-5b58-4ade-b815-add468c48e37",
    visible: true,
    disabled: true,
    name: "ajax",
    categories: ["misc"],
    logo: "assets/ajax.png",
    title: "Ajax",
    description: "Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.",
    metadata: {},
    svg: "SiAjax"
  },
  {
    id: "8c438fcd-b8c0-444e-9100-24abd93a6bcb",
    visible: true,
    disabled: true,
    name: "sqlite",
    categories: ["database"],
    main: "src/extensions/sqlite/index.ts",
    title: "Sqlite",
    description: "Sqlite is a relational database management system.",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/operators.json
var operators_default = [
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Equal To",
    name: "equals",
    metadata: {}
  },
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Not Equal To",
    name: "not_equals",
    metadata: {}
  },
  {
    id: "f3d3c1af-0066-4884-8533-917ec2c71fd1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "One Of",
    name: "one_of",
    metadata: {}
  },
  {
    id: "f56f9948-7745-4203-928f-e75c481d13d8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Between",
    name: "between",
    metadata: {}
  },
  {
    id: "c2e22f65-ce15-42cc-a99f-7e5bca84b69f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "63ec8fb7-357f-403a-b753-6df8a3f25737",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "More Than",
    name: "more_than",
    metadata: {}
  },
  {
    id: "162eedc3-3ace-48c2-8a38-0c1db9058d8a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    name: "contains",
    metadata: {}
  },
  {
    id: "60e18406-a4a7-44a4-8b91-2481710fb4e8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    name: "starts_with",
    metadata: {}
  },
  {
    id: "d3b7f462-d154-4bfa-8645-3f74a958bed6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    name: "ends_with",
    metadata: {}
  },
  {
    id: "d1a02de2-8928-4517-884d-502bdb8d8409",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "fa2b1831-9ceb-4808-984e-1f834a723c56",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Greater Than",
    name: "greater-than",
    metadata: {}
  },
  {
    id: "a2c10af5-c9dd-401c-b28c-59bb48c85345",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Not Empty",
    name: "is_not_empty",
    metadata: {}
  },
  {
    id: "8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Empty",
    name: "is_empty",
    metadata: {}
  },
  {
    id: "73963f47-092a-4bf2-a38a-50dca50ca5e6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before",
    name: "before",
    metadata: {}
  },
  {
    id: "a830cb78-e9f2-4259-9753-d6259bea1bed",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before On",
    name: "before_on",
    metadata: {}
  },
  {
    id: "d23be707-a71d-44bd-8b61-9489e84f1a2d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After On",
    name: "after_on",
    metadata: {}
  },
  {
    id: "8648374e-f78a-4322-ac67-67467d4fbff5",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After",
    name: "after",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var DevKit = class {
  getDeps() {
    const exts = this.extensions();
    const dependencies = exts.map((it) => it.packages ?? []).flat();
    const possibleDeps = [
      {
        name: "discord.js",
        version: "^14.15.3",
        dev: false
      }
    ];
    return [...dependencies, ...possibleDeps].reduce((acc, it) => {
      return {
        ...acc,
        [it.name]: it.version
      };
    }, {});
  }
  getExtensionActions(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return actions_default.filter((it) => it.extensionId === id);
  }
  actions() {
    return actions_default;
  }
  async getExtensionTriggers(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return (await this.triggers()).filter((it) => it.extensionId === id);
  }
  async triggers() {
    return (await this.actions()).filter((it) => it.type === "trigger");
  }
  extensions() {
    return extensions_default;
  }
  toJson(obj) {
    return JSON.stringify(obj, null, 2);
  }
  async getValidationsByIds(ids) {
    const validations = await this.validations();
    const list = [];
    for (const id of ids) {
      const validation = validations.find((it) => it.id === id);
      if (!validation) {
        throw new Error(`Validation with id ${id} not found`);
      }
      list.push(validation);
    }
    return list;
  }
  async getValidationsByNames(names) {
    const validations = await this.validations();
    const list = [];
    for (const name of names) {
      const validation = validations.find((it) => it.name === name);
      if (!validation) {
        throw new Error(`Validation with name ${name} not found`);
      }
      list.push(validation);
    }
    return list;
  }
  async getFieldsByExtension() {
    return await this.fields();
  }
  fields() {
    return fields_default;
  }
  validations() {
    return validations_default;
  }
  operators() {
    return operators_default;
  }
};
__name(DevKit, "DevKit");
DevKit = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], DevKit);
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input, sub) {
  const index = input.indexOf(sub);
  if (index === -1) {
    return input;
  }
  return input.slice(sub.length);
}
__name(substring, "substring");
function getSourceActionById(id) {
  const action = actions_default.find((it) => it.id === id);
  if (!action) {
    throw new Error(`Action with id ${id} not found`);
  }
  return action;
}
__name(getSourceActionById, "getSourceActionById");
function getExtensionById(id) {
  const item = extensions_default.find((it) => it.id === id);
  if (!item) {
    throw new Error(`Extension with id ${id} not found`);
  }
  return item;
}
__name(getExtensionById, "getExtensionById");
function getValidationByName(name) {
  const validation = validations_default.find((a) => a.name === name);
  if (!validation) {
    throw new Error(`Validation with name ${name} not found`);
  }
  return validation;
}
__name(getValidationByName, "getValidationByName");
function getSourceFieldById(id) {
  const field = fields_default.find((it) => it.id === id);
  if (!field) {
    throw new Error(`Field with id ${id} not found`);
  }
  return field;
}
__name(getSourceFieldById, "getSourceFieldById");
function getSourceFieldByName(name) {
  const field = fields_default.find((it) => it.name === name);
  if (!field) {
    throw new Error(`Field with name ${name} not found`);
  }
  return field;
}
__name(getSourceFieldByName, "getSourceFieldByName");
function assignDefaults(metadata, details) {
  Object.entries(metadata ?? {}).forEach(([name, config]) => {
    if (details[name] === void 0 && config.defaultValue !== void 0) {
      details[name] = config.defaultValue;
    }
  });
  return details;
}
__name(assignDefaults, "assignDefaults");
function getTriggerByName(name) {
  const trigger = actions_default.find(
    (it) => it.type === "trigger" && it.name === name
  );
  if (!trigger) {
    throw new Error(`Trigger with name ${name} not found`);
  }
  return trigger;
}
__name(getTriggerByName, "getTriggerByName");
function getValidationById(id) {
  const validation = validations_default.find((it) => it.id === id);
  if (!validation) {
    throw new Error(`Validation with id ${id} not found`);
  }
  return validation;
}
__name(getValidationById, "getValidationById");
function getSourceActionByName(name) {
  if (isNullOrUndefined(name)) {
    throw new Error(
      "getSourceActionByName:name is required. received: " + name
    );
  }
  const action = actions_default.find((it) => it.name === name);
  if (!action) {
    throw new Error(`Action with name ${name} not found`);
  }
  return action;
}
__name(getSourceActionByName, "getSourceActionByName");
function getExtensionByName(name) {
  const item = extensions_default.find((it) => it.name === name);
  if (!item) {
    throw new Error(`Extension with name ${name} not found`);
  }
  return item;
}
__name(getExtensionByName, "getExtensionByName");

// libs/compiler/sdk/devkit/src/lib/project-config.ts
var _config;
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config
    });
  }
};
_config = new WeakMap();
__name(ProjectConfig, "ProjectConfig");
ProjectConfig = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable3, Injector, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
var ProjectFS = class {
  _projectConfig = Injector.GetRequiredService(ProjectConfig);
  routersGlob() {
    return this._projectConfig.getConfig().features + "/**/*.router.ts";
  }
  listenersGlob() {
    return this._projectConfig.getConfig().features + "/**/*.github.ts";
  }
  cronsGlob() {
    return this._projectConfig.getConfig().features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return this._projectConfig.getConfig().features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = /* @__PURE__ */ __name((importPath) => {
    return join2(
      "#{relative}",
      this._projectConfig.getConfig().basePath,
      importPath
    );
  }, "makeCoreImportSpecifier");
  makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  }, "makeEntityImportSpecifier");
  makeFeaturePath = /* @__PURE__ */ __name((fileName) => join2(this._projectConfig.getConfig().features, fileName), "makeFeaturePath");
  makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(featureName),
    fileName
  ), "makeFeatureFile");
  makeCorePath = /* @__PURE__ */ __name((fileName) => join2(this._projectConfig.getConfig().basePath, "core", fileName), "makeCorePath");
  makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(this._projectConfig.getConfig().basePath, "identity", fileName), "makeIdentityPath");
  makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(this._projectConfig.getConfig().basePath, fileName), "makeSrcPath");
  makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
    this._projectConfig.getConfig().basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  ), "makeWorkspacePath");
  makeRootPath = /* @__PURE__ */ __name((fileName) => join2(this._projectConfig.getConfig().basePath, "../", fileName), "makeRootPath");
  makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  ), "makeCommandPath");
  makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
  makeControllerPath = /* @__PURE__ */ __name((featureName, suffix) => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  ), "makeControllerPath");
  makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  ), "makeControllerRoutePath");
  makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  ), "makeListenerRoutePath");
  makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  ), "makeJobRoutePath");
  makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  ), "makeEntityPath");
  makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
    this._projectConfig.getConfig().features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  ), "makeQueryPath");
  makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
};
__name(ProjectFS, "ProjectFS");
ProjectFS = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], ProjectFS);
var makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
  return join2("#{entity}", pascalcase(tableName));
}, "makeEntityImportSpecifier");
var makeControllerPath = /* @__PURE__ */ __name((featureName, suffix) => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
), "makeControllerPath");
var makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2("features", spinalcase2(featureName), fileName), "makeFeatureFile");
var makeFeaturePath = /* @__PURE__ */ __name((fileName) => join2("features", fileName), "makeFeaturePath");
var makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2("identity", fileName), "makeIdentityPath");

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  __name(whatIsParserImport, "whatIsParserImport");
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}
__name(formatCode, "formatCode");

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
import crypto from "crypto";
import { createReadStream, existsSync } from "fs";
import { mkdir, readFile, rm, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { basename, dirname, join as join3 } from "path";
function followProgress(stream, logger = console) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger.log(obj);
        }
      }
    );
  });
}
__name(followProgress, "followProgress");
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
__name(upsertVolume, "upsertVolume");
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
__name(upsertNetwork, "upsertNetwork");
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
__name(getContainer, "getContainer");
async function removeContainer(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    await container.stop({ t: 0 }).catch(console.error);
  }
  await container.remove({ force: true }).catch(console.error);
}
__name(removeContainer, "removeContainer");
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
__name(isContainerRunning, "isContainerRunning");
function computeChecksum(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("md5");
    const stream = typeof filePath === "string" ? createReadStream(filePath) : filePath;
    stream.on("data", (data) => hash.update(data));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", (err) => reject(err));
  });
}
__name(computeChecksum, "computeChecksum");
async function fileChanged(filePath, discrminator) {
  const checksumDirPath = join3(tmpdir(), discrminator);
  await mkdir(checksumDirPath, { recursive: true });
  const checksumFilePath = join3(checksumDirPath, basename(filePath));
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(fileChanged, "fileChanged");
async function contentChanged(content, fileName, discrminator) {
  const checksumFilePath = join3(tmpdir(), discrminator, fileName);
  await mkdir(dirname(checksumFilePath), { recursive: true });
  const filePath = join3(tmpdir(), "check", discrminator, fileName);
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, "utf-8");
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(contentChanged, "contentChanged");
function makeProjectPath(projectId) {
  return join3(tmpdir(), "client-server", projectId);
}
__name(makeProjectPath, "makeProjectPath");
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
__name(makeRunningImageName, "makeRunningImageName");
function makeRunningContainerName(projectId) {
  return `${projectId}-container`;
}
__name(makeRunningContainerName, "makeRunningContainerName");
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}
__name(followLogs, "followLogs");
async function startContainer(name, createContainer) {
  let container = null;
  if (typeof name === "string") {
    container = await getContainer({ name });
  } else {
    container = name;
  }
  if (!container) {
    if (!createContainer) {
      throw new Error(`Cannot initialize server for project: ${name}`);
    }
    container = await createContainer();
  }
  const running = await isContainerRunning(container);
  if (!running) {
    await container.start().catch((error) => {
      if (error.statusCode === 304) {
        return;
      }
      throw error;
    });
  }
  return container;
}
__name(startContainer, "startContainer");
async function getContainerNet(containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings;
}
__name(getContainerNet, "getContainerNet");
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}
__name(getContainerExternalPort, "getContainerExternalPort");
async function pushImage(repo, tag = "latest") {
  const image = docker.getImage(repo);
  const stream = await image.push({
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    },
    tag
  });
  await followProgress(stream);
  return image;
}
__name(pushImage, "pushImage");
async function pullImage(image, tag = "latest") {
  const stream = await docker.createImage({
    fromImage: image,
    tag,
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    }
  });
  await followProgress(stream);
  return image;
}
__name(pullImage, "pullImage");

// libs/compiler/generator/utils/src/index.ts
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toVirtualFile(it) {
  const parts = it.path.split("/").filter(Boolean);
  const fileName = parts.at(-1);
  return {
    isFolder: false,
    name: it.path.split("/").pop() || "unknown",
    path: parts.join("/"),
    extension: getExt(fileName),
    content: it.content,
    metadata: {
      path: it.path
    }
  };
}
__name(toVirtualFile, "toVirtualFile");
function mapFilesToTree(files) {
  function toTree(parts, tree, content) {
    const [part, ...rest] = parts;
    if (rest.length === 0) {
      return {
        ...tree,
        [part]: content
      };
    }
    return {
      ...tree,
      [part]: toTree(rest, tree[part] || {}, content)
    };
  }
  __name(toTree, "toTree");
  return files.reduce((acc, it) => {
    const parts = it.path.split("/").filter(Boolean);
    return toTree(parts, acc, it.content);
  }, {});
}
__name(mapFilesToTree, "mapFilesToTree");
function mapFilesToTreeNodes(files) {
  const tree = mapFilesToTree(files);
  function toTreeNodes(tree2, path = []) {
    return Object.entries(tree2).map(([name, value]) => {
      const newPath = [...path, name];
      if (typeof value === "string") {
        return {
          id: newPath.join("/"),
          name,
          path: newPath.join("/"),
          metadata: {
            path: newPath.join("/")
          }
        };
      }
      return {
        id: newPath.join("/"),
        name,
        children: toTreeNodes(value, newPath),
        metadata: {
          path: newPath.join("/")
        }
      };
    }).sort((a, b) => "children" in a ? -1 : 1);
  }
  __name(toTreeNodes, "toTreeNodes");
  return toTreeNodes(tree);
}
__name(mapFilesToTreeNodes, "mapFilesToTreeNodes");
function getFile(list, path) {
  const file = list.find(
    (it) => JSON.stringify(it.path.split("/").filter(Boolean)) === JSON.stringify(path.split("/").filter(Boolean))
  );
  if (!file) {
    throw new Error(`File not found: ${path}`);
  }
  return file;
}
__name(getFile, "getFile");
function emptyFile(file = {}) {
  return {
    isFolder: false,
    name: "unknown",
    extension: "",
    content: "",
    path: "",
    ...file
  };
}
__name(emptyFile, "emptyFile");

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";
var BrowserLookupFs = class {
  static {
    __name(this, "BrowserLookupFs");
  }
  #lookupModules = /* @__PURE__ */ new Set();
  exists(path) {
    return localforage.getItem(path).then((item) => !!item).catch(() => false);
  }
  moduleExists(sourceData) {
    return this.exists(`package:${sourceData.package}`);
  }
  getFiles(sourceData) {
    return localforage.getItem(`files:${sourceData.package}`).then((files) => files || []).catch(() => []);
  }
  getFileContent(path) {
    return localforage.getItem(path).then((item) => item);
  }
  getPackageJson(sourceData) {
    return localforage.getItem(`package:${sourceData.package}`).then((item) => item);
  }
  mapFiles(files) {
    return files.map((file) => ({
      originalFile: file,
      relativeFile: file
    }));
  }
  lock(source) {
    this.#lookupModules.add(source);
  }
  isLocked(source) {
    return this.#lookupModules.has(source);
  }
};

// libs/playground/package-installer/src/lib/parser.ts
import { dirname as dirname2, join as join4 } from "path";
function coercePackageJson(packageJson) {
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.peerDependencies = packageJson.peerDependencies || {};
  return packageJson;
}
__name(coercePackageJson, "coercePackageJson");
function makeFileUri(specifier, fileName) {
  return `file:///node_modules/${specifier}/${fileName}`;
}
__name(makeFileUri, "makeFileUri");
function parseSpecifer(specifier) {
  const [moduleName, version] = specifier.split("@").filter(Boolean);
  return {
    moduleName,
    version: version === "*" ? "latest" : version
  };
}
__name(parseSpecifer, "parseSpecifer");
function normalizeImport(typesUrl, relativeImport) {
  const url = new URL(typesUrl);
  const relativeImportPathname = join4(dirname2(url.pathname), relativeImport);
  return new URL(relativeImportPathname, url.origin).href;
}
__name(normalizeImport, "normalizeImport");
function cleanText(text) {
  return text.replace("export {}", "").replaceAll("export function", "export declare function").replaceAll("export const", "export declare const");
}
__name(cleanText, "cleanText");
async function fetchDts(typesUrl) {
  const result = {
    error: false,
    loaded: false,
    text: ""
  };
  try {
    const response = await fetch(typesUrl);
    if (response.ok) {
      const text = await response.text();
      if (text.includes("[Package Error]")) {
        throw new Error("Package Error");
      }
      result.text = cleanText(text);
      result.loaded = true;
    } else {
      result.error = true;
    }
  } catch (error) {
    result.error = true;
    result.loaded = false;
  }
  return result;
}
__name(fetchDts, "fetchDts");
function parseSource(source) {
  let index = 0;
  const tokens = [];
  while (index < source.length) {
    switch (source[index]) {
      case "@":
        {
          let subindex = index + 1;
          while (subindex < source.length && source[subindex] !== "/") {
            subindex++;
          }
          tokens.push({
            type: "at",
            value: source.slice(index + 1, subindex)
          });
          index = subindex;
        }
        break;
      default:
        {
          let lastToken = tokens[tokens.length - 1];
          if (!lastToken || lastToken.type !== "string") {
            lastToken = {
              type: "string",
              value: ""
            };
            tokens.push(lastToken);
          }
          lastToken.value += source[index];
          index++;
        }
        break;
    }
  }
  if (tokens[0].type === "at") {
    tokens[0].type = "scope";
    tokens[1].type = "package";
    if (tokens[2]) {
      tokens[2].type = "version";
    }
  }
  if (tokens[0].type === "string") {
    tokens[0].type = "package";
    if (tokens[1]) {
      tokens[1].type = "version";
    }
  }
  const moduleName = (tokens.find((x) => x.type === "package")?.value || "").replace("/", "");
  const version = tokens.find((x) => x.type === "version")?.value || "latest";
  const scope = tokens.find((x) => x.type === "scope")?.value;
  const file = tokens.find((x) => x.type === "string")?.value;
  return {
    moduleName,
    version,
    scope,
    package: `${scope ? `@${scope}/` : ""}${moduleName}`,
    full: `${scope ? `@${scope}/` : ""}${moduleName}@${version}`,
    file
  };
}
__name(parseSource, "parseSource");
function sourceDataToString(source) {
  return `${source.scope ? `${source.scope}/` : ""}${source.moduleName}@${source.version}`;
}
__name(sourceDataToString, "sourceDataToString");

// libs/playground/package-installer/src/lib/deps-install-manager.ts
import { basename as basename2, dirname as dirname3, extname, join as join5, relative } from "path";
var PackageExports = class {
  constructor(pkg) {
    this.pkg = pkg;
  }
  static {
    __name(this, "PackageExports");
  }
  #extractTypes(exportConfig) {
    if (Array.isArray(exportConfig)) {
      return this.#extractTypes(
        exportConfig.filter((it) => typeof it === "string")[0]
      );
    }
    if (typeof exportConfig === "object") {
      if (typeof exportConfig?.types === "string") {
        return this.#extractTypes(exportConfig.types);
      }
      if (typeof exportConfig?.default === "string") {
        return this.#extractTypes(exportConfig?.default);
      }
    }
    if (typeof exportConfig === "string") {
      return fixTypeExportName(exportConfig);
    }
    return null;
  }
  #correctEndpoint(endpoint) {
    if (typeof endpoint === "string") {
      return fixTypeExportName(endpoint);
    }
    return this.#extractTypes(endpoint);
  }
  #tryFiles(index) {
    if (!index.endsWith("index.d.ts")) {
      return this.pkg.files?.find((it) => it.endsWith("index.d.ts")) || index;
    }
    return index;
  }
  formatExports() {
    const exports = this.mainExport();
    const deleteKeys = [
      (it) => it.includes("*"),
      (it) => it.includes("production"),
      (it) => it.includes("development"),
      (it) => it.includes("package.json"),
      (it) => it.includes("default"),
      (it) => it.includes("require"),
      (it) => it.includes("import"),
      (it) => it === ".",
      (it) => it === "./",
      (it) => it === "/"
    ];
    const cleanedExports = Object.fromEntries(
      Object.entries(this.pkg.exports).filter(
        ([endpoint]) => !deleteKeys.some((x) => x(endpoint))
      )
    );
    const formattedEndpoints = Object.fromEntries(
      Object.entries(cleanedExports).map(([endpoint, exports2]) => [
        endpoint,
        {
          types: this.#correctEndpoint(exports2) || // use the endpoint as the type as last resort
          fixTypeExportName(endpoint)
        }
      ])
    );
    return {
      ...exports,
      ...formattedEndpoints
    };
  }
  mainExport() {
    if (!this.pkg.exports) {
      return {
        ".": {
          types: this.#tryFiles(
            fixTypeExportName(
              this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
            )
          )
        }
      };
    }
    if (typeof this.pkg.exports === "string") {
      return {
        ".": {
          types: this.#tryFiles(fixTypeExportName(this.pkg.exports))
        }
      };
    }
    return {
      ".": {
        types: this.#correctEndpoint(this.pkg.exports["."]) || this.#tryFiles(
          fixTypeExportName(
            this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
          )
        )
      }
    };
  }
};
var nodeTypes = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
var Resolver = class {
  constructor(pkgKeeper, keeper, registries) {
    this.pkgKeeper = pkgKeeper;
    this.keeper = keeper;
    this.registries = registries;
  }
  static {
    __name(this, "Resolver");
  }
  async resolve(source) {
    if (nodeTypes.includes(source) || nodeTypes.some((it) => `node:${it}` === source) || nodeTypes.includes(`node:${source}`) || source.startsWith("@extensions")) {
      return null;
    }
    console.log("Resolving => ", source);
    const info = {
      deps: []
    };
    const resolutions$ = [];
    const pkg = await this.#packageJson(source).catch((error) => null);
    if (pkg === null) {
      console.log(`Resolution stopped: package.json not found for ${source}`);
      return null;
    }
    if (!pkg) {
      console.log(`Resolution stopped: missing package.json for ${source}`);
      return null;
    }
    const sourceData = parseSource(source);
    if (sourceData.version === "latest") {
      source = sourceDataToString({
        ...sourceData,
        version: pkg.version
      });
    }
    const recorder = createRecorder({ label: source });
    for (const [specifier, version] of [
      ...Object.entries(pkg.dependencies ?? {}),
      ...Object.entries(pkg.peerDependencies ?? {})
    ]) {
      const source2 = `${specifier}@${version}`;
      resolutions$.push(async () => {
        info.deps.push(await this.resolve(source2));
      });
    }
    const endpoints = [];
    for (const [secondaryEndpoint, exportedModule] of Object.entries(
      pkg.exports
    )) {
      resolutions$.push(async () => {
        const secondaryEndpointSource = join5(source, secondaryEndpoint);
        console.log("Resolving secondary", secondaryEndpointSource);
        await this.#fetch(
          secondaryEndpointSource,
          join5(source, exportedModule.types)
        ).then((r) => {
          if (secondaryEndpoint === "." && r.loaded) {
            info.resolved = true;
          }
        });
        endpoints.push({
          source: secondaryEndpointSource,
          typePath: exportedModule.types,
          typeSource: join5(source, exportedModule.types),
          name: secondaryEndpoint
        });
      });
    }
    info.source = source;
    info.endpoints = endpoints;
    await Promise.all(
      resolutions$.map(
        (it) => it()
        //   .catch((error) => {
        //   console.error(error);
        //   throw error;
        // }),
        //   .catch((error) => {
        //   console.log(`Failed to resolve ${source} due to`);
        //   // logMe(pkg);
        //   console.error(error);
        // }),
      )
    );
    recorder.end();
    console.log("Resolved", source);
    return info;
  }
  async #resolveRelativeImports(fileContent, source) {
    const exports = await getFileExports(
      fileContent.replaceAll("export const", "declare const")
    );
    const types$ = exports.map(async (exportSepecifier) => {
      const maybeDeps = !exportSepecifier.startsWith(".");
      if (maybeDeps) {
        console.log("Resolving relative deps", exportSepecifier);
        const isDeps = await this.resolve(exportSepecifier).catch(() => null);
        if (isDeps?.resolved) {
          return null;
        }
      }
      console.log("Resolving relative file", exportSepecifier);
      const relativeExportSource = join5(source, exportSepecifier);
      const relativeExportTypeExport = fixTypeExportName(relativeExportSource);
      const entry = await this.#entry(relativeExportSource);
      entry.path = exportSepecifier;
      if (entry.loaded) {
        return null;
      }
      if (entry.error || entry.loading) {
        return null;
      }
      return this.#fetch(relativeExportSource, relativeExportTypeExport);
    });
    return Promise.all(types$);
  }
  async #fetch(source, typeExport) {
    const entry = await this.#entry(source);
    if (entry.loaded) {
      console.log(`Already loaded ${source}`);
      return entry;
    }
    if (entry.error) {
      console.log(`Already errored ${source}`);
      return entry;
    }
    if (entry.loading) {
      console.log(`Already loading ${source}`);
      return entry;
    }
    entry.loading = true;
    entry.loaded = false;
    const registries = this.registries.slice(0);
    while (!entry.loaded) {
      const registry = registries.shift();
      if (!registry) {
        break;
      }
      const result = await registry.resolve(typeExport);
      if (result.loaded) {
        entry.loaded = true;
        entry.text = result.text;
        await this.keeper.set(source, entry);
        break;
      }
    }
    entry.typeExport = typeExport;
    entry.loading = false;
    if (entry.loaded) {
      const entries = await this.#resolveRelativeImports(
        entry.text,
        dirname3(typeExport)
      );
      entry.related = entries.filter(notNullOrUndefined);
    }
    entry.error = entry.loaded === false;
    return entry;
  }
  async #packageJson(source) {
    let pkg = await this.pkgKeeper.get(source).catch((error) => {
      console.error(error);
      return null;
    });
    if (pkg === null) {
      console.log(`Using cached package ${source}`);
      return pkg;
    }
    if (!pkg) {
      const registries = this.registries.slice(0);
      while (!pkg) {
        const registry = registries.shift();
        if (!registry) {
          break;
        }
        pkg = await registry.packageJson(source).catch(() => null);
      }
      await this.pkgKeeper.set(source, pkg || null);
    }
    if (!pkg) {
      throw new Error(`Failed to resolve package ${source}`);
    }
    pkg.dependencies = pkg.dependencies || {};
    pkg.devDependencies = pkg.devDependencies || {};
    pkg.peerDependencies = pkg.peerDependencies || {};
    const packageExports = new PackageExports(pkg);
    pkg.exports = packageExports.formatExports();
    pkg.dependencies = Object.fromEntries(
      Object.entries(pkg.dependencies).map(([specifier, version]) => {
        if (pkg.devDependencies && pkg.devDependencies[`@types/${specifier}`]) {
          return [
            `@types/${specifier}`,
            pkg.devDependencies[`@types/${specifier}`]
          ];
        }
        return [specifier, version];
      })
    );
    return pkg;
  }
  async #entry(source) {
    const inCache = await this.keeper.get(source);
    if (inCache) {
      return inCache;
    }
    const entry = {
      loaded: false,
      source,
      text: "",
      loading: false,
      typeExport: "",
      related: [],
      path: ""
    };
    return entry;
  }
  async #flatEntry(entry, basePath, seed) {
    for (const endpointEntry of (await this.#entry(entry.source)).related) {
      if (!endpointEntry.loaded) {
        continue;
      }
      seed.push({
        path: join5(
          dirname3(
            join5(
              basePath,
              relative(dirname3(entry.typeSource), endpointEntry.source)
            )
          ),
          basename2(endpointEntry.typeExport)
        ),
        content: endpointEntry.text,
        loaded: endpointEntry.loaded
      });
      for (const nestedEntry of endpointEntry.related) {
        seed.push({
          path: join5(
            dirname3(
              join5(
                basePath,
                relative(dirname3(entry.typeSource), nestedEntry.source)
              )
            ),
            basename2(nestedEntry.typeExport)
          ),
          content: nestedEntry.text,
          loaded: nestedEntry.loaded
        });
        await this.#flatEntry(
          {
            source: nestedEntry.source,
            typeSource: nestedEntry.typeExport
          },
          join5(basePath, nestedEntry.path),
          seed
        );
      }
    }
  }
  async flatten(info, basePath, seed) {
    for (const endpoint of info.endpoints) {
      const secondaryPath = join5(basePath, endpoint.name);
      await this.#flatEntry(endpoint, secondaryPath, seed);
      const entry = await this.#entry(endpoint.source);
      seed.push({
        path: join5(secondaryPath, basename2(endpoint.typePath)),
        content: entry.text,
        loaded: entry.loaded
      });
    }
    for (const deps of info.deps) {
      if (!deps) {
        continue;
      }
      const depsSourceData = parseSource(deps.source);
      await this.flatten(
        deps,
        join5(basePath, "node_modules", depsSourceData.package),
        seed
      );
    }
  }
};
async function getFileExports(content) {
  const isNodejs = typeof process !== "undefined";
  const exports = isNodejs ? await Promise.resolve().then(() => (init_src(), src_exports)).then(
    ({ getExports: getExports2 }) => getExports2(content)
  ) : await runWorker("/morph/parser.worker.js", {
    type: "getExports",
    payload: content
  });
  return removeDuplicates(
    exports.filter(
      (it) => it.type === "ExportAllDeclaration" || it.type === "ExportNamedDeclaration" || it.type === "ImportDeclaration"
    ).map((it) => it.source?.value).filter(notNullOrUndefined),
    (it) => it
  );
}
__name(getFileExports, "getFileExports");
function fixTypeExportName(name) {
  if (extname(name)) {
    name = name.replace(".d.ts", "").replace(".ts", "").replace(".js", "");
  }
  return `${name}.d.ts`;
}
__name(fixTypeExportName, "fixTypeExportName");

// libs/modern/src/lib/module-lookup.ts
var nodeTypes2 = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
async function lookupModule(source, fs, options) {
  const sourceData = parseSource(source);
  if (nodeTypes2.includes(sourceData.package) || nodeTypes2.some((it) => `node:${it}` === sourceData.package) || nodeTypes2.includes(`node:${sourceData.package}`) || source.startsWith("@extensions")) {
    console.log(`Source ${source} is a node type`);
    return;
  }
  if (fs.isLocked(source)) {
    return;
  }
  fs.lock(source);
  if (!await fs.moduleExists(sourceData)) {
    console.log(`Source ${source} not found`);
    const installed = await options.onMissingPackage(source, sourceData);
    if (!installed) {
      return;
    }
  }
  const packageJson = await fs.getPackageJson(sourceData);
  const files = await fs.getFiles(sourceData);
  await options.onFiles(sourceData, packageJson, files);
  await options.onPackageJson(sourceData, packageJson);
  await lookupPackage(packageJson, fs, options);
}
__name(lookupModule, "lookupModule");
async function lookupPackage(packageJson, fs, options) {
  coercePackageJson(packageJson);
  for (const depKey of ["dependencies", "peerDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      await lookupModule(depsName, fs, options);
    }
  }
  for (const depKey of ["devDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      if (depsName.startsWith("@types/")) {
        await lookupModule(depsName, fs, options);
      }
    }
  }
}
__name(lookupPackage, "lookupPackage");

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";
var octokit = /* @__PURE__ */ __name((token) => import("@octokit/core").then(({ Octokit: Octokit2 }) => new Octokit2({ auth: token })), "octokit");
async function generateKey() {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.crypto_secretbox_keygen();
}
__name(generateKey, "generateKey");
async function encrypt(key, plain) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const secret = sodium.crypto_secretbox_easy(
    plain,
    nonce,
    new Uint8Array(key)
  );
  return {
    secret,
    nonce
  };
}
__name(encrypt, "encrypt");
async function decrypt(secret, nonce, key) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.to_string(
    sodium.crypto_secretbox_open_easy(secret, nonce, key)
  );
}
__name(decrypt, "decrypt");
async function createEmptySecret(token, repositoryName, name) {
  const [owner, repo] = repositoryName.split("/");
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  try {
    await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
      owner,
      repo,
      secret_name: name
    });
    return;
  } catch (error) {
    const _error = error;
    if ("documentation_url" in _error) {
      if (_error.status !== 404) {
        throw error;
      }
    }
  }
  const key = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/public-key", {
    owner,
    repo
  });
  const binkey = sodium.from_base64(
    key.data.key,
    sodium.base64_variants.ORIGINAL
  );
  const binsec = sodium.from_string(" ");
  const encBytes = sodium.crypto_box_seal(binsec, binkey);
  const output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  await (await octokit(token)).request("PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
    owner,
    repo,
    secret_name: name,
    encrypted_value: output,
    key_id: key.data.key_id
  });
}
__name(createEmptySecret, "createEmptySecret");
async function createRepoistory(token, repositoryName, organizationId, workspaceId, projectId) {
  try {
    const result = await (await octokit(token)).request("POST /user/repos", {
      name: repositoryName,
      description: "January generated repository.",
      gitignore_template: "Node",
      private: true,
      auto_init: false,
      request: {
        projectId
      },
      homepage: "https://january.sh"
      // TODO: it should be user server or user local development server (january ones)
    });
    return {
      id: result.data.id,
      name: result.data.full_name
    };
  } catch (error) {
    if (error?.response?.data) {
      const _error = error.response;
      const [firstError] = _error.errors ?? [];
      if (firstError && firstError.code === "custom" && firstError.field === "name") {
        throw new Error(
          "Repository already exists on this account. Please change the project name and try again."
        );
      }
    }
    throw error;
  }
}
__name(createRepoistory, "createRepoistory");
async function triggerDeploy(token, repositoryName, inputs = {}) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request(
    "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
    {
      owner,
      repo,
      // TODO: we should get the installed hosting extension and get the workflow id from it
      workflow_id: "deploy.yml",
      ref: "main",
      inputs
    }
  );
}
__name(triggerDeploy, "triggerDeploy");
async function deleteRepository(token, repositoryName) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request("DELETE /repos/{owner}/{repo}", {
    owner,
    repo
  });
}
__name(deleteRepository, "deleteRepository");
async function listWorkflows(token, repositoryName, workflowFileName) {
  const [owner, repo] = repositoryName.split("/");
  const client = await octokit(token);
  const workflow = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  const run = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  return { workflow, run };
}
__name(listWorkflows, "listWorkflows");
async function getWorkflowRun(token, repositoryName, workflowFileName, sha) {
  const [owner, repo] = repositoryName.split("/");
  const result = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs", {
    owner,
    repo,
    workflow_id: workflowFileName,
    head_sha: sha,
    branch: "main",
    exclude_pull_requests: true
  });
  const run = result.data.workflow_runs[0];
  if (!run) {
    return {
      run: {
        status: "queued",
        conclusion: null
      },
      jobs: []
    };
  }
  const runJobs = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs", {
    owner,
    repo,
    run_id: run.id
  });
  return {
    run,
    jobs: runJobs.data.jobs.map((it) => ({
      id: it.id,
      name: it.name,
      status: it.status,
      conclusion: it.conclusion,
      steps: (it.steps ?? []).map((step) => ({
        id: `${step.name}-${step.number}-${step.completed_at ?? 0}`,
        name: step.name,
        status: step.status,
        conclusion: step.conclusion,
        elapsed: step.completed_at && step.started_at ? differenceInSeconds(
          new Date(step.completed_at),
          new Date(step.started_at)
        ) : null
      }))
    }))
  };
}
__name(getWorkflowRun, "getWorkflowRun");

// libs/modern/src/index.ts
import { mkdir as mkdir2, writeFile as writeFile2 } from "fs/promises";
import { dirname as dirname4, isAbsolute, join as join6 } from "path";
import { tap } from "rxjs/operators";
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug2(tag, enabled = true) {
  const header = /* @__PURE__ */ __name((value, error) => typeof tag === "string" ? tag : tag(value, error), "header");
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}
__name(debug2, "debug");
async function writeFiles(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join6(dir, file);
    await mkdir2(dirname4(filePath), { recursive: true });
    await writeFile2(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}
__name(writeFiles, "writeFiles");

// libs/docker/src/compose.ts
import yaml from "js-yaml";
function compose(services) {
  const dockerCompose = {
    volumes: {},
    networks: {},
    services: {}
  };
  const appEnvironment = {};
  for (const [serviceName, it] of Object.entries(services)) {
    const depends_on = it.dependsOn(services);
    Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
    delete it.composeService.appEnvironment;
    dockerCompose.services[serviceName] = {
      ...it.composeService,
      environment: Object.keys(it.composeService.environment).length ? it.composeService.environment : void 0,
      depends_on: depends_on.length ? depends_on : void 0
    };
    dockerCompose.volumes = {
      ...dockerCompose.volumes,
      ...it.volumes.filter((it2) => it2.isNamedVolume).reduce(
        (acc, it2) => ({
          ...acc,
          [it2.src]: {}
        }),
        {}
      )
    };
    dockerCompose.networks = {
      ...dockerCompose.networks,
      ...it.networks.reduce(
        (acc, it2) => ({
          ...acc,
          [it2]: {}
        }),
        {}
      )
    };
  }
  return {
    dockerCompose,
    environment: appEnvironment
  };
}
__name(compose, "compose");
function service(serviceLike) {
  const ports = (serviceLike.ports ?? []).map((it) => {
    const [host, internal] = it.split(":");
    return {
      host,
      internal
    };
  });
  const volumes = (serviceLike.volumes ?? []).map((it) => {
    const [src, dest] = it.split(":");
    return {
      src,
      dest,
      isNamedVolume: !(src.startsWith("/") || src.startsWith("./"))
    };
  });
  return {
    composeService: serviceLike,
    ports,
    volumes,
    networks: serviceLike.networks ?? [],
    dependsOn: /* @__PURE__ */ __name((services) => {
      const depends_on = [];
      for (const dependencie of serviceLike.depends_on ?? []) {
        for (const [serviceName, serviceLike2] of Object.entries(services)) {
          if (serviceLike2.composeService === dependencie) {
            depends_on.push(serviceName);
          }
        }
      }
      return depends_on;
    }, "dependsOn")
  };
}
__name(service, "service");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
var postgres = {
  image: "postgres:16",
  ports: ["5432:5432"],
  volumes: ["postgres_data:/var/lib/postgresql/data"],
  networks: ["development"],
  environment: {
    POSTGRES_PASSWORD: "yourpassword",
    POSTGRES_USER: "youruser",
    POSTGRES_DB: "yourdatabase"
  },
  get appEnvironment() {
    const {
      POSTGRES_PASSWORD: password,
      POSTGRES_USER: user,
      POSTGRES_DB: db
    } = this.environment;
    const [host, internal] = (this.ports ?? [])[0].split(":");
    return {
      CONNECTION_STRING: `postgresql://${user}:${password}@database:${host}/${db}`
    };
  }
};
var pgadmin = {
  image: "dpage/pgadmin4",
  ports: ["8080:8080"],
  networks: ["development"],
  environment: {
    PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
    PGADMIN_DEFAULT_PASSWORD: "password"
  }
};
var localServer = /* @__PURE__ */ __name((options = {
  port: "3000"
}) => {
  options.port ??= "3000";
  return {
    image: "node:lts",
    build: {
      context: ".",
      dockerfile: "Dockerfile"
    },
    networks: ["development"],
    restart: "unless-stopped",
    command: "node --watch /app/build/server.js",
    develop: {
      watch: [
        {
          action: "sync",
          path: "./output/build/server.js",
          target: "/app/build/server.js",
          ignore: ["node_modules/"]
        },
        {
          action: "rebuild",
          path: "./output/package.json"
        },
        {
          action: "rebuild",
          path: "./package.json"
        }
      ]
    },
    ports: [`${options.port}:${options.port}`, "9229:9229"],
    environment: {
      NODE_ENV: "development",
      PORT: options.port
    },
    env_file: [".env.compose", ".env", ...options.env_file ?? []]
  };
}, "localServer");
function writeCompose({
  dockerCompose,
  environment
}) {
  return writeFiles(process.cwd(), {
    "compose.dev.yml": yaml.dump(dockerCompose, {
      skipInvalid: false,
      noRefs: true,
      forceQuotes: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }),
    ".env.compose": toKevValEnv(environment)
  });
}
__name(writeCompose, "writeCompose");

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";
function createPack(content) {
  const pack = tarStream.pack();
  const entry = pack.entry({ name: "package.json" }, content, () => {
    pack.finalize();
  });
  entry.end();
  return new Promise((resolve, reject) => {
    entry.on("finish", () => {
      resolve(pack);
    });
    entry.on("error", reject);
  });
}
__name(createPack, "createPack");
function createExtract(onEntry) {
  const extract = tarStream.extract();
  extract.on("entry", (header, stream, next) => {
    onEntry(header.name, stream);
    stream.on("end", next);
    stream.resume();
  });
  extract.on("finish", () => {
    console.log("File extraction complete");
  });
  return extract;
}
__name(createExtract, "createExtract");
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}
async function execCommand(container, cmd) {
  const exec = await container.exec({
    AttachStdout: true,
    AttachStderr: true,
    Cmd: cmd,
    Tty: false,
    Privileged: false
  });
  const stream = await exec.start({});
  const outStream = new PassThrough();
  const errStream = new PassThrough();
  container.modem.demuxStream(stream, outStream, errStream);
  let out = "";
  let err = "";
  outStream.on("data", (chunk) => {
    out += chunk.toString();
  });
  errStream.on("data", (chunk) => {
    err += chunk.toString();
  });
  return new Promise((resolve, reject) => {
    stream.on("end", async () => {
      try {
        console.log(`Command ${cmd.join(" ")}`);
        const a = await exec.inspect();
        if (a.ExitCode !== 0) {
          const error = new Error(err);
          error.cause = a;
          reject(error);
        } else if (err) {
          const error = new Error(err);
          error.cause = a;
          return reject(error);
        } else {
          resolve(out);
        }
      } catch (e) {
        reject(e);
      }
    });
  });
}
__name(execCommand, "execCommand");
async function getDependencyInstaller() {
  const container = await startContainer(
    "dependency-installer",
    () => docker.createContainer({
      name: "dependency-installer",
      Image: "node:lts",
      WorkingDir: "/app",
      Cmd: ["tail", "-f", "/dev/null"],
      HostConfig: {
        Binds: [`node_modules:/app/node_modules`],
        CapDrop: ["ALL"],
        Privileged: false
      }
    })
  );
  await followLogs(container);
  return container;
}
__name(getDependencyInstaller, "getDependencyInstaller");
async function installPackage(sourceData) {
  const container = await getDependencyInstaller();
  await execCommand(container, [
    "sh",
    "-c",
    `echo '${JSON.stringify({
      version: "0.0.0",
      main: "./build/server.js",
      type: "module",
      dependencies: {
        "ua-parser-js": "^1.0.37",
        "request-ip": "^3.3.0",
        "rfc-7807-problem-details": "^1.1.0",
        ajv: "8.12.0",
        "ajv-formats": "2.1.1",
        "ajv-errors": "3.0.0",
        "ajv-keywords": "5.1.0",
        validator: "13.9.0",
        "lodash-es": "^4.17.21",
        "http-status-codes": "2.2.0",
        hono: "^4.4.0",
        "@hono/node-server": "^1.11.1",
        "@scalar/hono-api-reference": "^0.5.145",
        typeorm: "0.3.20",
        pg: "8.11.5",
        "sql-template-tag": "5.2.1",
        resend: "1.0.0",
        "@octokit/webhooks": "^13.2.7",
        "node-cron": "^3.0.3",
        [sourceData.package]: sourceData.version
      },
      devDependencies: {
        "@types/ua-parser-js": "^0.7.39",
        "@types/request-ip": "^0.0.41",
        "@types/lodash-es": "^4.17.12",
        "@types/node": "^20.11.26",
        typescript: "^4.9.4",
        "@types/validator": "13.7.17",
        "@types/node-cron": "^3.0.11",
        prettier: "3.3.2"
      }
    })}' > package.json`
  ]);
  await execCommand(container, [
    "sh",
    "-c",
    "npm install",
    "--no-audit",
    "--no-fund"
  ]);
  return container;
}
__name(installPackage, "installPackage");
async function installPackageJson(content, projectId) {
  const containerName = `${projectId}-install-deps`;
  const volumeName = "node_modules";
  const depsImage = "node:lts";
  const pack = await createPack(content);
  const { value: container, error } = await extractError(
    () => docker.createContainer({
      Image: depsImage,
      WorkingDir: "/app",
      name: containerName,
      Cmd: ["sh", "-c", "npm install", "--no-audit", "--no-fund"],
      HostConfig: {
        // Binds: [`${volumeName}:/app/node_modules`],
        AutoRemove: true,
        // ReadonlyRootfs: true,
        CapDrop: ["ALL"]
      }
    })
  );
  if (error) {
    const { statusCode, message } = error;
    switch (statusCode) {
      case 409:
        await removeContainer(containerName).catch(() => {
        });
        await installPackageJson(content, projectId);
        break;
      case 404:
        console.log(`Image not found: ${depsImage}`);
        console.error(error);
        break;
      default:
        console.error(error);
        break;
    }
    return;
  }
  try {
    await container.putArchive(pack, {
      path: "/app"
    });
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      logs: true
    });
    stream.pipe(process.stdout);
    await container.start();
    await container.wait({
      condition: "removed"
    });
    console.log("Dependencies installed");
  } finally {
    await removeContainer(containerName).catch(() => {
    });
  }
}
__name(installPackageJson, "installPackageJson");

// libs/canary/src/lib/snippets.ts
var snippets_default = {
  "HTTP Workflow": {
    prefix: "httpworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.http({
    method: '$3',
    path: '$4',
  }),
  execute: async (trigger, request) => {
  const url = new URL(request.url);
  return {
      path: url.pathname,
      method: request.method,
    }
  },
}),
      `
    ],
    description: "Creates a generic HTTP workflow with customizable method and path"
  },
  "Schedule Workflow": {
    prefix: "cronworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.schedule({
    pattern: '$3',
  }),
  execute: async ({ trigger }) => {
    // Scheduled task logic here
  },
}),
      `
    ],
    description: "Creates a generic Cron schedule workflow"
  },
  "WebSocket Workflow": {
    prefix: "websocketworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.websocket({
    topic: '$3',
  }),
  execute: async ({ trigger }) => {
    return trigger.channel; // WebSocket response logic here
  },
}),
      `
    ],
    description: "Creates a generic WebSocket workflow"
  },
  "SSE Workflow": {
    prefix: "sseworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.sse({
    path: '$3',
  }),
  execute: async ({ trigger }) => {
    const stream = new PassThrough();
    setInterval(() => {
    stream.push('data: $4\\n\\n');
    }, 1000);
    return stream;
  },
}),
      `
    ],
    description: "Creates a generic Server-Sent Events (SSE) workflow"
  },
  "GitHub Webhook Workflow": {
    prefix: "githubworkflow",
    body: [
      `workflow('$1', {
  tag: '$2',
  trigger: trigger.github({
    event: '$3',
  }),
  execute: async ({ trigger }) => {
    // Webhook logic here
  },
}),
      `
    ],
    description: "Creates a generic GitHub Webhook workflow"
  },
  "Create Workflow": {
    prefix: "createworkflow",
    body: [
      `workflow('Create$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'post',
    path: '/$3',
  }),
  execute: async ({ trigger }) => {
    const record = await saveEntity(tables.$4, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for inserting a new entity and returns the record's ID"
  },
  "List Workflow": {
    prefix: "listworkflow",
    body: [
      `workflow('List$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4');
    const paginationMetadata = limitOffsetPagination(qb, {
      pageSize: trigger.query.pageSize,
      pageNo: trigger.query.pageNo,
      count: await qb.getCount(),
    }),
    const records = await execute(qb);
    return {
      meta: paginationMetadata(records),
      records: records,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for listing multiple entities with pagination"
  },
  "Get Workflow": {
    prefix: "getworkflow",
    body: [
      `workflow('Get$1ById', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await execute(qb);
    return record;
  },
}),
      `
    ],
    description: "Creates a workflow for reading a single entity by ID"
  },
  "Update Workflow": {
    prefix: "updateworkflow",
    body: [
      `workflow('Update$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'patch',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(ttables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for updating an entity by ID and returns the record's ID"
  },
  "Delete Workflow": {
    prefix: "deleteworkflow",
    body: [
      `workflow('Delete$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'delete',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    await removeEntity(qb);
    return {
      id: trigger.path.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for deleting an entity by ID and returns the deleted ID"
  },
  "Replace Workflow": {
    prefix: "replaceworkflow",
    body: [
      `workflow('Replace$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'put',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    }),
    return {
      id: record.id,
    };
  },
}),
      `
    ],
    description: "Creates a workflow for replacing an entity and returns the updated ID"
  },
  "Exists Workflow": {
    prefix: "existsworkflow",
    body: [
      `workflow('Exists$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'head',
    path: '/$3/:id',
  }),
  execute: async ({ trigger }) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id }),
    const doesExist = await exists(qb);
    return {
      exists: doesExist,
    };
  },
}),
      `
    ],
    description: "Creates a workflow to check if an entity exists by ID"
  }
};

// libs/canary/src/program.ts
import { program } from "commander";
var cli = program.name("january").version("1.0.0").description("January").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command");

// libs/canary/src/cli.ts
var import_semver = __toESM(require_semver2(), 1);
import { Octokit } from "@octokit/core";
import { execSync } from "child_process";
import { differenceInMinutes } from "date-fns";
import { existsSync as existsSync2 } from "fs";
import { mkdir as mkdir3, readFile as readFile2, rename, rm as rm2, writeFile as writeFile3 } from "fs/promises";
import { tmpdir as tmpdir2 } from "os";
import { dirname as dirname5, isAbsolute as isAbsolute2, join as join7 } from "path";
var parentDir = process.cwd();
var toolsFiles = {
  "tools/extensions.json": toJson({}),
  "tools/january.config.js": `import { defineConfig } from '@january/canary';
import { fly } from '@january/extensions/fly';
import { hono } from '@january/extensions/hono';
import { identity } from '@january/extensions/identity';
import { postgresql, typeorm } from '@january/extensions/typeorm';

export default defineConfig({
  extensions: [
    identity,
    hono,
    fly,
    typeorm({
      database: postgresql(),
    }),
  ],
});
`,
  "tools/tsconfig.json": toJson({
    include: ["./**/*.js", "./**/*.ts"],
    exclude: ["vite.config.ts", "src/**/*.spec.ts", "src/**/*.test.ts"],
    compilerOptions: {
      moduleResolution: "Bundler",
      module: "ESNext",
      types: ["node"],
      allowJs: true,
      checkJs: true,
      noEmit: true
    }
  }),
  "tools/compose.js": `
      import {
  compose,
  localServer,
  pgadmin,
  postgres,
  service,
  writeCompose,
} from '@january/docker';

writeCompose(
  compose({
    database: service(postgres),
    pgadmin: service(pgadmin),
    server: service({
      ...localServer(),
      depends_on: [postgres],
    }),
  }),
);
`
};
cli.command("init", { isDefault: true }).argument("<name>", "Project name").action(async (name) => {
  const projectDir = join7(parentDir, name);
  const initialProjectCode = `import {  feature,  field,  mandatory,  policy,  project,  table,  trigger,  useTable,  workflow,} from '@january/declarative';

export default project();`;
  await writeFiles2(projectDir, {
    ".vscode/january.code-snippets": JSON.stringify(snippets_default),
    ".vscode/settings.json": {
      "editor.snippets.codeActions.enabled": true,
      "editor.suggest.showSnippets": true,
      "editor.suggest.snippetsPreventQuickSuggestions": false,
      "editor.snippetSuggestions": "bottom",
      "typescript.preferences.importModuleSpecifier": "non-relative",
      "files.autoSave": "afterDelay",
      "files.autoSaveWhenNoErrors": false,
      "files.refactoring.autoSave": true,
      "files.autoSaveDelay": 500,
      "explorer.fileNesting.enabled": true,
      "explorer.fileNesting.expand": true,
      "explorer.fileNesting.patterns": {
        "package.json": "package*.json",
        "tsconfig.json": "tsconfig*.json, .prettier*, .gitignore",
        ".env.": "*.env.",
        Dockerfile: "Dockerfile*, *.toml, compose.*, docker-compose.*, .dockerignore"
      }
    },
    "package.json": {
      name,
      version: "1.0.0",
      type: "module",
      private: true,
      workspaces: ["output"],
      scripts: {
        dev: "node --env-file .env ./output",
        build: "node --watch-path ./src --watch ./tools/january.config.js"
      },
      dependencies: {
        "@january/declarative": "https://github.com/JanuaryLabs/dist/raw/main/declarative.tar.gz",
        "@january/extensions": "https://github.com/JanuaryLabs/dist/raw/main/extensions.tar.gz",
        "@january/canary": "https://github.com/JanuaryLabs/dist/raw/main/canary.tar.gz",
        "@january/docker": "https://github.com/JanuaryLabs/dist/raw/main/docker.tar.gz"
      }
    },
    "tsconfig.json": {
      extends: "./output/tsconfig.json",
      include: ["src/**/*.ts"],
      exclude: ["vite.config.ts", "src/**/*.spec.ts", "src/**/*.test.ts"],
      compilerOptions: {
        rootDir: ".",
        moduleResolution: "Bundler",
        module: "ESNext"
      }
    },
    ".env": toKevValEnv({
      NODE_ENV: "development"
    }),
    ".gitignore": await fetch(
      "https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore"
    ).then((res) => res.text()).then((it) => it + "\noutput/"),
    "src/project.ts": initialProjectCode,
    "src/extensions/user/index.ts": "",
    ...toolsFiles
  });
  const git = esm_default(projectDir);
  await git.init().catch(() => {
    console.error(
      'Failed to initialize git repo. Please initialize the git repo "git init".'
    );
  });
  execSync("npm install --no-audit --no-fund", {
    cwd: projectDir,
    encoding: "utf-8",
    stdio: "inherit"
  });
  execSync("node ./tools/january.config.js", {
    cwd: projectDir,
    encoding: "utf-8",
    stdio: "inherit"
  });
});
cli.command("migrate").usage("Migrate the project to the latest version").option("--no-install", "Do not run npm install", true).action(async ({ install }) => {
  const projectDir = process.cwd();
  await updateJanuaryPackages(projectDir).catch((error) => {
    console.error("Failed to check for new version");
    console.error(error);
  });
  const oldComposePath = join7(projectDir, "compose.ts");
  if (existsSync2(oldComposePath)) {
    await rm2(oldComposePath, { force: true, recursive: true });
  }
  if (!existsSync2(join7(projectDir, "tools"))) {
    await writeFiles2(projectDir, toolsFiles);
  }
  if (existsSync2(join7(projectDir, "extensions.json"))) {
    await rename(
      join7(projectDir, "extensions.json"),
      join7(projectDir, "tools/extensions.json")
    );
  }
  const projectPackageJson = await readPackageJson(projectDir);
  projectPackageJson.content.type = "module";
  Object.assign(projectPackageJson.content.scripts, {
    dev: "node --env-file .env ./output",
    build: "node --watch-path ./src --watch ./tools/january.config.js"
  });
  await projectPackageJson.write();
  execSync("node ./tools/january.config.js", {
    cwd: projectDir,
    encoding: "utf-8",
    stdio: "inherit"
  });
  if (install) {
    execSync(`npm install --no-audit --no-fund`, {
      cwd: projectDir,
      encoding: "utf-8",
      stdio: "inherit"
    });
  }
});
cli.parse(process.argv);
async function writeFiles2(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute2(file) ? file : join7(dir, file);
    await mkdir3(dirname5(filePath), { recursive: true });
    await writeFile3(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}
__name(writeFiles2, "writeFiles");
async function getLatestVersion() {
  const octokit2 = new Octokit();
  const fullName = "JanuaryLabs/dist";
  const [owner, repo] = fullName.split("/");
  const { data: files } = await octokit2.request(
    "GET /repos/{owner}/{repo}/contents",
    {
      owner,
      repo,
      path: "",
      ref: "main"
    }
  );
  const semvers = files.filter((it) => it.type === "dir").map((it) => it.name);
  return import_semver.default.maxSatisfying(semvers, "*");
}
__name(getLatestVersion, "getLatestVersion");
async function updateJanuaryPackages(projectDir) {
  const januaryUpdateFile = join7(tmpdir2(), "january-update.txt");
  const lastUpdate = await readFile2(januaryUpdateFile, "utf-8").catch(
    () => null
  );
  if (lastUpdate && differenceInMinutes(/* @__PURE__ */ new Date(), new Date(lastUpdate)) < 60) {
    return;
  }
  const canaryPackageJson = await readPackageJson(
    join7(projectDir, "node_modules", "@january/canary")
  );
  const projectPackageJson = await readPackageJson(projectDir);
  const latestVersion = await getLatestVersion();
  if (import_semver.default.gt(latestVersion, canaryPackageJson.content.version)) {
    console.log(`New version ${latestVersion} available. Upgrading...`);
    const packages = ["canary", "docker", "declarative", "extensions"];
    const packagesLinks = packages.map(
      (it) => `https://github.com/JanuaryLabs/dist/raw/main/${latestVersion}/${it}.tar.gz`
    );
    projectPackageJson.content.dependencies = packages.reduce(
      (acc, it, i) => ({
        ...acc,
        [`@january/${it}`]: packagesLinks[i]
      }),
      projectPackageJson.content.dependencies ?? {}
    );
    await projectPackageJson.write();
    await writeFile3(januaryUpdateFile, (/* @__PURE__ */ new Date()).toISOString());
  }
}
__name(updateJanuaryPackages, "updateJanuaryPackages");
async function readPackageJson(dir) {
  const packageJsonPath = join7(dir, "package.json");
  const content = JSON.parse(
    await readFile2(packageJsonPath, "utf-8")
  );
  return {
    content,
    write: /* @__PURE__ */ __name((value = content) => writeFile3(packageJsonPath, JSON.stringify(value, null, 2), "utf-8"), "write")
  };
}
__name(readPackageJson, "readPackageJson");
async function timeSinceLastRun(name) {
  const file = join7(tmpdir2(), `${name}.lastrun`);
  if (!existsSync2(file)) {
    return 0;
  }
  const lastRun = new Date(await readFile2(file, "utf-8"));
  return {
    minutes: differenceInMinutes(/* @__PURE__ */ new Date(), lastRun),
    update: /* @__PURE__ */ __name(() => writeFile3(file, (/* @__PURE__ */ new Date()).toISOString()), "update")
  };
}
__name(timeSinceLastRun, "timeSinceLastRun");
//# sourceMappingURL=cli.js.map
