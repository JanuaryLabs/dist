#!/usr/bin/env node
"use strict";
exports.id = 1;
exports.ids = [1];
exports.modules = {

/***/ 5:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  generate: () => (/* binding */ generate)
});

// EXTERNAL MODULE: external "better-sqlite3"
var external_better_sqlite3_ = __webpack_require__(6);
var external_better_sqlite3_default = /*#__PURE__*/__webpack_require__.n(external_better_sqlite3_);
// EXTERNAL MODULE: external "dedent"
var external_dedent_ = __webpack_require__(7);
var external_dedent_default = /*#__PURE__*/__webpack_require__.n(external_dedent_);
// EXTERNAL MODULE: external "os"
var external_os_ = __webpack_require__(8);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(2);
// EXTERNAL MODULE: external "tiny-injector"
var external_tiny_injector_ = __webpack_require__(9);
// EXTERNAL MODULE: external "uuid"
var external_uuid_ = __webpack_require__(10);
;// CONCATENATED MODULE: ../api/infrastructure/src/lib/aggregate-root.ts
class AggregateRoot {
    id;
    #ongoingEvents = [];
    #markupEvents = [];
    static streamName;
    empty = false;
    version;
    constructor(id) {
        this.id = id;
    }
    getUncommittedChanges() {
        return this.#ongoingEvents;
    }
    markChangesAsCommitted() {
        this.#ongoingEvents = [];
    }
    loadFromHistory(history) {
        // FIXME: Catch apply error and replay the failed events after each successful apply
        // which would make order-stateless (same as the tree)
        history.forEach((event) => this.apply(event));
    }
    replayEvents(history) {
        // A synonomous method for loadsFromHistory, to better explain the terms.
        this.loadFromHistory(history);
    }
    applyChanges(event, markupEvent = false) {
        if (markupEvent) {
            this.#markupEvents.push(event);
        }
        else {
            this.#ongoingEvents.push(event);
        }
        this.apply(event);
        this.empty = false;
    }
}
class NotRelatedEvent extends Error {
    constructor(eventType) {
        super(`Event type ${eventType} is not related to the aggregate root. Please check the event type.`);
    }
}

// EXTERNAL MODULE: external "tslib"
var external_tslib_ = __webpack_require__(11);
// EXTERNAL MODULE: external "@automapper/classes"
var classes_ = __webpack_require__(12);
// EXTERNAL MODULE: external "@automapper/core"
var core_ = __webpack_require__(13);
// EXTERNAL MODULE: external "stringcase"
var external_stringcase_ = __webpack_require__(14);
// EXTERNAL MODULE: external "class-validator"
var external_class_validator_ = __webpack_require__(15);
;// CONCATENATED MODULE: ../isomorphic/src/lib/mapper.ts


const mapper = (0,core_.createMapper)({
    strategyInitializer: (0,classes_.classes)(),
    namingConventions: new core_.CamelCaseNamingConvention(),
});
function AutoMapHost() {
    return function (target) {
        (0,core_.createMap)(mapper, target, target);
    };
}

;// CONCATENATED MODULE: ../isomorphic/src/lib/field-documentation.ts



class FieldDocumentation {
    displayName;
    visibility;
}
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], FieldDocumentation.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => String),
    (0,external_class_validator_.IsOptional)(),
    (0,external_class_validator_.IsIn)(['both', 'readonly', 'writeonly', 'none']),
    (0,external_tslib_.__metadata)("design:type", String)
], FieldDocumentation.prototype, "visibility", void 0);

;// CONCATENATED MODULE: ../isomorphic/src/lib/field-validation.ts
var _a;




let FieldValidation = class FieldValidation {
    details;
    sourceId;
    name;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", typeof (_a = typeof Record !== "undefined" && Record) === "function" ? _a : Object)
], FieldValidation.prototype, "details", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], FieldValidation.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], FieldValidation.prototype, "name", void 0);
FieldValidation = (0,external_tslib_.__decorate)([
    AutoMapHost()
], FieldValidation);


;// CONCATENATED MODULE: ../isomorphic/src/lib/linear-tree/tree.ts
class LinearTree {
    line = [];
    orphans = [];
    constructor(root) {
        this.line.push({
            self: root,
            source: undefined,
            target: undefined,
            paths: [],
            type: 'root',
        });
    }
    #findParent(node) {
        if (!node.parentSequence) {
            return this.line;
        }
        const stack = [...this.line];
        while (stack.length) {
            const subtree = stack.pop();
            if (node.parentSequence === subtree.self.sequence) {
                return subtree.paths;
            }
            stack.push(...subtree.paths);
        }
        return null;
    }
    addNode(node) {
        const parent = this.#findParent(node);
        switch (true) {
            case !parent:
                this.orphans.push(node);
                return;
            case parent?.length === 0:
                parent.push({
                    self: node,
                    source: undefined,
                    target: undefined,
                    paths: [],
                    type: 'leaf',
                });
                this.#tryAddOrphans();
                return;
            case !node.siblingSequence:
                // at this point we know that the parent is not empty
                // and the node has no sibling
                parent.push({
                    self: node,
                    source: undefined,
                    target: undefined,
                    paths: [],
                    type: 'leaf',
                });
                this.#tryAddOrphans();
                return;
        }
        for (const branch of parent) {
            if (node.siblingSequence === branch.self.sequence) {
                // sibiling found, good. now need to add it after the sibiling
                const index = parent.findIndex((it) => it.source?.sequence === branch.source?.sequence);
                const sourceSibiling = parent[index];
                const targetSibiling = parent[index + 1];
                sourceSibiling.target = node;
                // NOTE: if the node have same sequance sibling, it'll conflict
                parent.splice(index + 1, 0, {
                    self: node,
                    source: sourceSibiling.self,
                    target: targetSibiling?.self,
                    paths: [],
                    type: 'leaf',
                });
                this.#tryAddOrphans();
                return;
            }
            if (node.sequence === branch.self.siblingSequence) {
                // sibiling found, good. now need to add it before the sibiling
                const index = parent.findIndex((it) => it.source?.sequence === branch.source?.sequence);
                const sibiling = parent[index];
                sibiling.target = node;
                parent.splice(index - 1, 0, {
                    self: node,
                    source: sibiling.self,
                    target: undefined,
                    paths: [],
                    type: 'leaf',
                });
                this.#tryAddOrphans();
                return;
            }
        }
        this.orphans.push(node);
    }
    #tryAddOrphans() {
        // check if there are orphans that can be added
        const clone = [...this.orphans];
        this.orphans = [];
        clone.forEach((orphan) => this.addNode(orphan));
    }
    connect(source, target) {
        //
    }
    toJson() {
        //
    }
    toEdges(stack = [...this.line], path = false) {
        const edges = [];
        while (stack.length) {
            const subtreeTarget = stack.pop();
            if (!subtreeTarget || !subtreeTarget.source) {
                continue;
            }
            const subtreeSource = stack.at(-1);
            edges.push({
                source: subtreeSource.self,
                target: subtreeTarget.self,
                path: path,
            });
            if (subtreeTarget.paths) {
                const vnodes = subtreeTarget.paths
                    .map((it) => [
                    {
                        ...subtreeTarget,
                        source: undefined, // remove the source as this acts as root to its paths
                    },
                    { ...it, source: subtreeTarget.self },
                ])
                    .flat();
                edges.push(...this.toEdges(vnodes, true));
            }
        }
        return edges;
    }
    pretty() {
        for (const orphan of this.orphans) {
            const parent = this.#findParent(orphan) ?? [...this.line];
            parent.push({
                self: orphan,
                source: undefined,
                target: undefined,
                paths: [],
                type: 'leaf',
                orphan: true,
            });
        }
        return this.line;
    }
}
class BetterTree {
    start;
    line = [];
    orphans = [];
    constructor(start) {
        this.start = start;
        this.start.nodes.forEach((node) => this.addNode(node));
    }
    #findParent(node) {
        const stack = [...this.line];
        while (stack.length) {
            const subtree = stack.pop();
            if (node.source === subtree.id) {
                return subtree;
            }
            stack.push(...subtree.children);
        }
        return null;
    }
    #tryAddOrphans() {
        // check if there are orphans that can be added
        const clone = [...this.orphans];
        this.orphans = [];
        clone.forEach((orphan) => this.addNode(orphan));
    }
    addNode(node) {
        const [root] = this.line;
        if (!root) {
            const maybeRoot = this.start.source === node.source ? node : null;
            if (maybeRoot) {
                this.line.push({
                    id: node.source,
                    children: [],
                    data: node.data,
                });
                this.line.push({
                    id: node.target,
                    children: [],
                    data: node.data,
                });
                this.#tryAddOrphans();
                return;
            }
            else {
                this.orphans.push(node);
                return;
            }
        }
        if (node.data?.['child']) {
            const parent = this.#findParent(node);
            if (parent) {
                parent.children.push({
                    id: node.target,
                    children: [],
                    data: node.data,
                });
                this.#tryAddOrphans();
            }
            else {
                this.orphans.push(node);
            }
            return;
        }
        else {
            const last = this.line.at(-1);
            if (!last) {
                throw new Error(`No parent found for ${node.source}`);
            }
            if (last.id === node.source) {
                this.line.push({
                    id: node.target,
                    children: [],
                    data: node.data,
                });
                this.#tryAddOrphans();
            }
            else {
                this.orphans.push(node);
            }
        }
    }
    map(mapFn, array = [...this.line]) {
        const list = [];
        while (array.length) {
            const node = array.shift();
            list.push({
                ...node,
                ...mapFn(node.id),
                children: this.map(mapFn, [...node.children]),
                data: node.data,
            });
        }
        return list;
    }
}
// const tree = new BetterTree<SourceTarget>({
//   source: '7986d237-e6e1-4ae4-8b34-fd677e63028a',
//   nodes,
// });
// console.dir(tree.line, {
//   showHidden: false,
//   depth: Infinity,
//   maxArrayLength: Infinity,
//   colors: true,
// });

;// CONCATENATED MODULE: ../isomorphic/src/index.ts









let WithProjectId = class WithProjectId {
    projectId;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], WithProjectId.prototype, "projectId", void 0);
WithProjectId = (0,external_tslib_.__decorate)([
    AutoMapHost()
], WithProjectId);


// EXTERNAL MODULE: external "@faslh/tiny-mediatr"
var tiny_mediatr_ = __webpack_require__(16);
;// CONCATENATED MODULE: ../api/infrastructure/src/lib/domain.event.ts




// importing utils breaks esbuild



class DomainEventMetadata {
    causationId; // What caused the event?
    correlationId; // To what this event is relate
    userIp;
    userAgent;
    platformVersion;
    organizationId;
    workspaceId;
    projectId;
    userId;
}
class DomainEventData {
    toJson() {
        return { ...this };
    }
}
class DomainEvent extends tiny_mediatr_.INotification {
    id = (0,external_uuid_.v4)();
    // @AutoMap(() => Object)
    // public readonly aggregateVersion = FieldValue.increment(1);
    timestamp;
    aggregateId;
    streamName;
    entityId;
    metadata;
    toJson() {
        return {
            id: this.id,
            streamName: this.streamName,
            eventType: this.eventType,
            aggregateId: this.aggregateId,
            entityId: this.entityId ?? (0,external_uuid_.v4)(),
            metadata: this.metadata,
            timestamp: this.timestamp,
            // aggregateVersion: this.aggregateVersion,
            data: this.data.toJson ? this.data.toJson() : this.data,
        };
    }
}
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => String),
    (0,external_tslib_.__metadata)("design:type", Object)
], DomainEvent.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Object)
], DomainEvent.prototype, "timestamp", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DomainEvent.prototype, "aggregateId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DomainEvent.prototype, "streamName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DomainEvent.prototype, "entityId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Object)
], DomainEvent.prototype, "metadata", void 0);
function createEvent(eventName) {
    const temp = {
        [(0,external_stringcase_.pascalcase)(eventName)]: class extends DomainEvent {
            eventType = eventName;
            static eventType = eventName;
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            // public static override name = pascalcase(eventName);
            data;
        },
    };
    (0,core_.createMap)(mapper, temp[(0,external_stringcase_.pascalcase)(eventName)]);
    return temp[(0,external_stringcase_.pascalcase)(eventName)];
}

;// CONCATENATED MODULE: ../api/infrastructure/src/lib/environment.token.ts

const ENVIRONMENT = new external_tiny_injector_.InjectionToken('Environment token');

// EXTERNAL MODULE: external "tslog"
var external_tslog_ = __webpack_require__(17);
;// CONCATENATED MODULE: ../api/infrastructure/src/lib/logger.ts

// const stream = createStream('tslog.log', {
//   size: '1M', // rotate every 10 MegaBytes written
//   interval: '1d', // rotate daily
//   compress: 'gzip', // compress rotated files
// });
const logger = new external_tslog_.Logger({ type: 'pretty' });
logger.attachTransport((logObject) => {
    if (process.env['NODE_ENV'] === 'development') {
        // stream.write(JSON.stringify(logObject, null, 4) + '\n');
    }
});


;// CONCATENATED MODULE: ../api/infrastructure/src/index.ts






// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(18);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(19);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ../utils/src/lib/issue-tracker.ts

function reportException(title, error) {
    let data = error;
    const production = process.env['NODE_ENV'] === 'production';
    if ('toJSON' in error) {
        data = error.toJSON();
    }
    else if ('message' in error) {
        data = error.message + '\n' + error.stack;
    }
    if (!production) {
        return Promise.resolve();
    }
    const webhookURL = 'https://chat.googleapis.com/v1/spaces/AAAALeS7bIE/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=ha36EtuZyTeZaVLMvIvnX2V3mZd6OSYckpx6BI0kZug%3D';
    return external_axios_default().post(webhookURL, {
        text: JSON.stringify({
            title,
            data,
        }),
    }, {
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
    });
}

// EXTERNAL MODULE: external "retry"
var external_retry_ = __webpack_require__(20);
var external_retry_default = /*#__PURE__*/__webpack_require__.n(external_retry_);
;// CONCATENATED MODULE: ../utils/src/lib/utils.ts





function orThrow(fn, message) {
    const result = fn();
    if ([undefined, null].includes(result)) {
        const error = new Error(message);
        Error.captureStackTrace(error, orThrow);
        throw error;
    }
    return result;
}
function isNullOrUndefined(value) {
    return value === undefined || value === null;
}
function notNullOrUndefined(value) {
    return !isNullOrUndefined(value);
}
function isNotEmptyString(value) {
    return (0,external_class_validator_.isNotEmpty)(value) && (0,external_class_validator_.isString)(value);
}
function upsert(array, id, insert) {
    const [index, item] = byId(array, id);
    if (item) {
        array[index] = insert(item, false);
        return array;
    }
    else {
        return [...array, insert({ id }, true)];
    }
}
async function upsertAsync(array, id, insert) {
    const [index, item] = byId(array, id);
    if (item) {
        array[index] = await insert(item);
        return array;
    }
    else {
        return [...array, await insert({ id })];
    }
}
function byId(array, id) {
    const index = array.findIndex((it) => it.id === id);
    return [index, array[index]];
}
const removeEmpty = (obj) => {
    const newObj = {};
    Object.keys(obj).forEach((key) => {
        if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
            newObj[key] = removeEmpty(obj[key]);
        else if (obj[key] !== undefined)
            newObj[key] = obj[key];
    });
    return newObj;
};
function partition(array, by) {
    const result = {};
    for (const item of array) {
        const splitBy = by(item);
        if (!result[splitBy]) {
            result[splitBy] = [];
        }
        result[splitBy].push(item);
    }
    return result;
}
function assertNotNullOrUndefined(value, debugLabel) {
    if (value === null || value === undefined) {
        throw new Error(`${debugLabel} is undefined or null.`);
    }
}
async function profile({ label, seconds = false, }, fn) {
    const startTime = performance.now();
    try {
        return await fn(); // Await the function if it's a promise
    }
    finally {
        const endTime = performance.now();
        const time = endTime - startTime;
        const formattedTime = seconds ? (time / 1000).toFixed(6) : time.toFixed(6);
        const timeUnit = seconds ? 'seconds' : 'milliseconds';
        console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
    }
}
const colors = {
    green: (message) => `\x1b[32m${message}\x1b[0m`,
    blue: (message) => `\x1b[34m${message}\x1b[0m`,
    magenta: (message) => `\x1b[35m${message}\x1b[0m`,
};
function createRecorder(options = { seconds: false }) {
    const startedAt = performance.now();
    function log(...args) {
        if (!process.env['RECORD_OFF']) {
            console.log(...args);
        }
    }
    log(colors.green(`Recording started => [${options.label}]`));
    const operations = new Map();
    return {
        record: (label) => {
            operations.set(label, performance.now());
            if (options.verbose) {
                log(colors.blue(`Recording => [${options.label ? `${options.label} => ` : ''}${label}]
        `));
            }
        },
        recordEnd: (label, result) => {
            const endTime = performance.now();
            const time = endTime - operations.get(label);
            const formattedTime = options.seconds
                ? (time / 1000).toFixed(6)
                : time.toFixed(6);
            const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
            log(colors.blue(`Execution time => [${options.label ? `${options.label} => ` : ''}${label}]: ${formattedTime} ${timeUnit}`), ...[result].filter((item) => typeof item !== 'undefined'));
            operations.delete(label);
        },
        end: () => {
            const endTime = performance.now();
            const time = endTime - startedAt;
            const lastEntry = Array.from(operations.entries()).at(-1);
            if (lastEntry) {
                // log missing end
                const [label, start] = lastEntry;
                const time = performance.now() - start;
                const formattedTime = options.seconds
                    ? (time / 1000).toFixed(6)
                    : time.toFixed(6);
                const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
                log(colors.magenta(`Recording Total time => [${options.label ? `${options.label} => ` : ''}${label}]: ${formattedTime} ${timeUnit}`));
                operations.delete(label);
            }
            const formattedTime = options.seconds
                ? (time / 1000).toFixed(6)
                : time.toFixed(6);
            const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
            log(colors.magenta(`Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`));
        },
    };
}
function applyCondition(condition, context) {
    const input = resolveContextKey(condition.input, context);
    switch (condition.operator) {
        case 'equal':
            return input === condition.value ? condition.then : condition.else;
        case 'not_equal':
            return input !== condition.value ? condition.then : condition.else;
        default:
            throw new Error(`Unknown operator ${condition.operator}`);
    }
}
function resolveContextKey(key, details) {
    const [source, path] = key.split('.');
    if (source === 'self') {
        return (0,external_lodash_.get)(details.self, path);
    }
    else if (source === 'context') {
        return (0,external_lodash_.get)(details.context, path);
    }
    return key;
}
function buildUrl(url, details, binding) {
    {
        const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(':'));
        // no variables in url
        if (!variables.length || !details) {
            return { url, params: [] };
        }
        const params = variables.reduce((acc, variable) => {
            const key = variable.slice(1);
            return {
                ...acc,
                [key]: resolveContextKey(binding[key], details),
            };
        }, {});
        return {
            url: url,
            params: Object.values(params),
        };
    }
}
function isResolvable(maybeResolvable) {
    if (!maybeResolvable) {
        return false;
    }
    if (Array.isArray(maybeResolvable)) {
        return true;
    }
    if (maybeResolvable.url) {
        return true;
    }
    return false;
}
function isCondition(obj) {
    if (!obj || typeof obj === 'string' || Array.isArray(obj))
        return false;
    if ('input' in obj && 'operator' in obj && 'value' in obj) {
        return true;
    }
    return false;
}
function parseDetails(details, path) {
    const parsed = JSON.parse(details ?? '{}');
    return path ? (0,external_lodash_.get)(parsed, path, {}) : parsed;
}
const logMe = (object) => console.dir(object, {
    showHidden: false,
    depth: Infinity,
    maxArrayLength: Infinity,
    colors: true,
});
function toLiteralObject(obj, accessor = (value) => value) {
    return `{${Object.keys(obj)
        .map((key) => `${key}: ${accessor(obj[key])}`)
        .join(', ')}}`;
}
function addLeadingSlash(path) {
    return (0,external_path_.normalize)((0,external_path_.join)('/', path));
}
function removeTrialingSlash(path) {
    return path.replace(/\/$/, '');
}
function retryPromise(promise) {
    return new Promise((resolve, reject) => {
        const operation = external_retry_default().operation({
            factor: 2,
            randomize: true,
            minTimeout: 1000,
            maxTimeout: 2000,
        });
        operation.attempt(async (currentAttempt) => {
            try {
                const result = await promise();
                resolve(result);
            }
            catch (error) {
                if (!operation.retry(error)) {
                    reject(error);
                }
            }
        });
    });
}
function uniquify(data, accessor) {
    return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
function toRecord(array, config) {
    return array.reduce((acc, item) => {
        return {
            ...acc,
            [config.accessor(item)]: config.map(item),
        };
    }, {});
}
function hasProperty(obj, key) {
    if (typeof obj !== 'object') {
        return false;
    }
    return key in obj;
}
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
function safeFail(fn, defaultValue) {
    try {
        return fn();
    }
    catch (error) {
        return defaultValue;
    }
}
async function extractError(fn) {
    try {
        return {
            value: await fn(),
            error: undefined,
        };
    }
    catch (error) {
        return { error };
    }
}
function toCurlyBraces(path) {
    return path
        .replace(':', '$:')
        .split('$')
        .map((it) => {
        if (!it.startsWith(':')) {
            return it.split('/').filter(Boolean).join('/');
        }
        const [param, ...rest] = it.split('/');
        return [`{${param.slice(1)}}`, ...rest].join('/');
    })
        .join('/');
}
function normalizeWorkflowPath(config) {
    const path = removeTrialingSlash(addLeadingSlash((0,external_path_.join)((0,external_stringcase_.spinalcase)(config.featureName), (0,external_stringcase_.snakecase)(config.workflowTag), toCurlyBraces(config.workflowPath))));
    return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
const pool = {};
function runWorker(publicPath, message, options = {
    type: 'module',
    terminateImmediately: false,
}) {
    let worker;
    if (options.terminateImmediately) {
        worker = new Worker(publicPath, options);
    }
    else {
        worker = pool[publicPath] ??= new Worker(publicPath, options);
    }
    // const worker =
    //   process.env['NODE_ENV'] === 'development'
    //     ? new Worker(publicPath, options)
    //     : pool[publicPath];
    const defer = new Promise((resolve, reject) => {
        worker.onmessage = (e) => {
            if (options.terminateImmediately) {
                worker.terminate();
            }
            if ('error' in e.data) {
                reject(e.data.error);
                console.error(e.data.error);
            }
            else {
                resolve(e.data.data);
            }
        };
        worker.onerror = (e) => {
            if (options.terminateImmediately) {
                worker.terminate();
            }
            reject(e.error);
        };
    });
    worker.postMessage(message);
    return defer;
}
function removeDuplicates(data, accessor) {
    return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
function scan(array, accumulator) {
    const scanned = [];
    for (let i = 0; i < array.length; i++) {
        const element = array[i];
        const acc = [];
        for (let j = i - 1; j >= 0; j--) {
            acc.unshift(array[j]);
        }
        scanned.push(accumulator(element, acc));
    }
    return scanned;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/token.ts
class Expression {
    parent;
}
class Arg extends Expression {
    name;
    value;
    type = 'arg';
    constructor(name, value) {
        super();
        this.name = name;
        this.value = value;
        this.name.parent = this;
        this.value.parent = this;
    }
    accept(visitor) {
        return visitor.visitArg(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
    }
}
class Call extends Expression {
    name;
    args;
    type = 'call';
    constructor(name, args = []) {
        super();
        this.name = name;
        this.args = args;
        this.name.parent = this;
        this.args.forEach((arg) => (arg.parent = this));
    }
    accept(visitor) {
        return visitor.visitCall(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}(${this.args
            .map((arg) => arg.toLiteral(visitor))
            .join(', ')})`;
    }
}
class PropertyAccess extends Expression {
    name;
    expression;
    type = 'propertyAccess';
    constructor(name, expression) {
        super();
        this.name = name;
        this.expression = expression;
        this.name.parent = this;
        this.expression.parent = this;
    }
    accept(visitor) {
        return visitor.visitPropertyAccess(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(visitor)}`;
    }
}
class Binary extends Expression {
    operator;
    left;
    right;
    type = 'propertyAccess';
    constructor(operator, left, right) {
        super();
        this.operator = operator;
        this.left = left;
        this.right = right;
        this.operator.parent = this;
        this.left.parent = this;
        this.right.parent = this;
    }
    accept(visitor) {
        return visitor.visitBinary(this);
    }
    toLiteral(visitor) {
        return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(visitor)} ${this.right.toLiteral(visitor)}`;
    }
}
class Namespace extends Expression {
    name;
    expression;
    type = 'namespace';
    constructor(name, expression) {
        super();
        this.name = name;
        this.expression = expression;
        this.name.parent = this;
        this.expression.parent = this;
    }
    accept(visitor) {
        return visitor.visitNamespace(this);
    }
    toLiteral(visitor) {
        return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
    }
}
class Identifier extends Expression {
    value;
    type = 'identifier';
    constructor(value) {
        super();
        this.value = value;
    }
    accept(visitor) {
        return visitor.visitIdentifier(this);
    }
    toLiteral(visitor) {
        return this.value;
    }
}
class StringLiteral extends Expression {
    value;
    type = 'string';
    constructor(value) {
        super();
        this.value = value;
    }
    accept(visitor) {
        return visitor.visitStringLiteral(this);
    }
    toLiteral(visitor) {
        return `'${this.value}'`;
    }
}
const typeChecker = {
    isCall(expression) {
        return expression.type === 'call';
    },
    isNamespace(expression) {
        return expression.type === 'namespace';
    },
    isPropertyAccess(expression) {
        return expression.type === 'propertyAccess';
    },
    isIdentifier(expression) {
        return expression.type === 'identifier';
    },
};
class Visitor {
}
class AsyncVisitor {
}
class StringVisitor extends Visitor {
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
class StringAsyncVisitor extends AsyncVisitor {
    async visitIdentifier(node) {
        return node.value;
    }
    async visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/sqlite.visitor.ts



class SqliteVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        const where = node.args.map((arg) => arg.accept(this)).join(', ');
        return `${node.name.accept(this)} WHERE id = ${where}`;
    }
    visitNamespace(node) {
        if (node.name.value === 'tables') {
            return `SELECT ${node.expression.accept(this)}`;
        }
        return `'${node.toLiteral(this)}'`;
    }
    visitPropertyAccess(node) {
        return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toSqlite(input) {
    const visitor = new SqliteVisitor();
    return visitor.visit(parseDsl(input));
}
class TypeormVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        const where = node.args.reduce((acc, current) => {
            return {
                ...acc,
                // static to id till we support multiple args
                id: current.accept(this),
            };
        }, {});
        const tableName = node.name.accept(this);
        return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLiteralObject(where, (value) => value)})`;
    }
    visitPropertyAccess(node) {
        return `.select('${node.expression.accept(this)}')${node.name.accept(this)}`;
    }
    visitNamespace(node) {
        if (node.name.value === 'tables') {
            return `qb${node.expression.accept(this)}`;
        }
        return `'${node.toLiteral(this)}'`;
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toTypeorm(input) {
    const visitor = new TypeormVisitor();
    return visitor.visit(parseDsl(input));
}
class SimpleVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.value,
            value: node.expression.accept(this),
        };
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toSimple(input) {
    const visitor = new SimpleVisitor();
    return visitor.visit(parseDsl(input));
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
    let index = 0;
    const tokens = [];
    let lexeme = '';
    while (index < input.length) {
        const char = input[index];
        switch (char) {
            case '=':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'EQUALS',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case '!':
                if (input[index + 1] === '=') {
                    if (lexeme) {
                        tokens.push({
                            type: 'IDENTIFIER',
                            value: lexeme,
                            column: index,
                        });
                        lexeme = '';
                    }
                    tokens.push({
                        type: 'NOT_EQUALS',
                        value: '!=',
                        column: index,
                    });
                    index += 2;
                }
                else {
                    lexeme += char;
                    index++;
                }
                break;
            case '.':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'DOT',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ',':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'COMMA',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case '@':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'AT',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ':':
                tokens.push({
                    type: 'IDENTIFIER',
                    value: lexeme,
                    column: index,
                });
                lexeme = '';
                tokens.push({
                    type: 'COLON',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case "'":
            case '"':
                {
                    index++;
                    while (input[index] !== "'" && input[index] !== '"') {
                        lexeme += input[index];
                        index++;
                    }
                    index++;
                    const column = index;
                    if (input[index] === ']') {
                        lexeme += input[index];
                        index++;
                    }
                    tokens.push({
                        type: 'STRING',
                        value: lexeme,
                        column: column,
                    });
                    lexeme = '';
                }
                break;
            case '(':
                tokens.push({
                    type: 'IDENTIFIER',
                    value: lexeme,
                    column: index,
                });
                lexeme = '';
                tokens.push({
                    type: 'OPEN_PAREN',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ')':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                lexeme = '';
                tokens.push({
                    type: 'CLOSE_PAREN',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ' ':
            case '\r':
            case '\t':
                // Ignore whitespace.
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                index++;
                break;
            default:
                // assume string
                lexeme += char;
                index++;
                break;
        }
    }
    if (lexeme)
        tokens.push({ type: 'IDENTIFIER', value: lexeme });
    tokens.push({ type: 'EOF', value: '' });
    return tokens;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/input-parser.ts



const grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
    return toSimple(input);
}
class ParserTokens {
    currentIdx = 0;
    tokens = [];
    constructor(tokens) {
        this.tokens = tokens;
    }
    get peek() {
        return this.tokens[this.currentIdx];
    }
    get lookahead() {
        return this.tokens[this.currentIdx + 1];
    }
    get lookbehind() {
        return this.tokens[this.currentIdx - 1];
    }
    isAtEnd() {
        return this.check('EOF');
    }
    match(...types) {
        if (this.isAtEnd())
            return false;
        if (this.check(...types)) {
            this.advance();
            return true;
        }
        return false;
    }
    consume(type, message) {
        if (this.check(type)) {
            return this.advance();
        }
        const error = new Error(`${message} at ${this.currentIdx} Found ${this.peek.type}`);
        Error.captureStackTrace(error, this.consume);
        throw error;
    }
    check(...tokens) {
        return tokens.includes(this.peek.type);
    }
    advance() {
        return this.tokens[++this.currentIdx];
    }
    retreat() {
        return this.tokens[--this.currentIdx];
    }
    reset() {
        this.currentIdx = 0;
    }
    slice() {
        return this.tokens.slice(this.currentIdx);
    }
}
class DSLParser extends ParserTokens {
    input;
    constructor(input) {
        super(tokeniser(input));
        this.input = input;
    }
    subparsing(parserType) {
        const parser = new parserType(this.slice());
        const { expression, index } = parser.subparse();
        this.currentIdx += index;
        return expression;
    }
    #equal() {
        const expression = this.subparsing(NamespaceParser);
        if (this.match('EQUALS') || this.match('NOT_EQUALS')) {
            const operator = new Identifier(this.lookbehind.value);
            const right = this.#expression();
            return new Binary(operator, expression, right);
        }
        return expression;
    }
    #expression() {
        const expression = this.#equal();
        return expression;
    }
    parse() {
        const result = this.#expression();
        this.consume('EOF', 'Expecting EOF');
        this.reset();
        return result;
    }
}
function parseDsl(input) {
    const parser = new DSLParser(input);
    return parser.parse();
}
class NamespaceParser extends ParserTokens {
    #primary() {
        if (this.match('STRING')) {
            return new StringLiteral(this.lookbehind.value);
        }
        if (this.match('IDENTIFIER')) {
            return new Identifier(this.lookbehind.value);
        }
        if (this.match('AT')) {
            // const namespace = this.#primary() as Identifier;
            const namespace = new Identifier(this.peek.value);
            this.consume('IDENTIFIER', 'Expecting identifier');
            this.consume('COLON', 'Expecting :');
            return new Namespace(namespace, this.#expression());
        }
        const token = this.peek;
        const error = new Error(`Unexpected token ${token.value}`);
        // Error.captureStackTrace(error, this.#primary);
        throw error;
    }
    #call() {
        // FIXME: throw error if function is not an identifier
        const expression = this.#primary();
        if (this.match('OPEN_PAREN')) {
            const args = [];
            do {
                const name = this.#primary();
                this.consume('COLON', 'Expecting :');
                const value = this.#expression();
                args.push(new Arg(name, value));
            } while (this.match('COMMA'));
            this.consume('CLOSE_PAREN', 'Expecting )');
            return new Call(expression, args);
        }
        return expression;
    }
    #propertyAccess() {
        let expression = this.#call();
        while (this.match('DOT')) {
            const primary = this.#primary();
            expression = new PropertyAccess(expression, primary);
        }
        return expression;
    }
    #expression() {
        const expression = this.#propertyAccess();
        return expression;
    }
    subparse() {
        // this.consume('AT', 'Expecting @');
        const result = this.#expression();
        return {
            expression: result,
            index: this.currentIdx,
        };
    }
    parse() {
        // this.consume('AT', 'Expecting @');
        const result = this.#expression();
        this.consume('EOF', 'Expecting EOF');
        this.reset();
        return result;
    }
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/prompt-parser.ts

class PromptParser {
    prompt;
    tokens = [];
    objectives = ['extension', 'table', 'feature', 'workflow'];
    constructor(prompt) {
        this.prompt = prompt;
        this.tokens = tokeniser(this.prompt);
    }
    firstObjective() {
        const idx = this.tokens.findIndex((token, index) => {
            if (token.type === 'AT') {
                const nextToken = this.tokens[index + 1];
                if (nextToken && this.objectives.includes(nextToken.value)) {
                    return true;
                }
            }
            return false;
        });
        const objectiveTokens = [];
        for (let i = idx; i < this.tokens.length; i++) {
            objectiveTokens.push(this.tokens[i]);
            if (this.tokens[i].type === 'STRING')
                break;
        }
        if (objectiveTokens.length === 0) {
            throw new Error(`No namespace found in prompt: ${this.prompt}`);
        }
        const guessComplete = objectiveTokens.some((obj) => obj.type == 'COLON');
        if (!guessComplete) {
            throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
        }
        return {
            name: objectiveTokens[1].value,
            value: objectiveTokens.at(-1).value,
        };
    }
    stripObjective() {
        const start = this.tokens.findIndex((token, index) => {
            if (token.type === 'AT') {
                const nextToken = this.tokens[index + 1];
                if (nextToken && this.objectives.includes(nextToken.value)) {
                    return true;
                }
            }
            return false;
        });
        const end = this.tokens
            .slice(start)
            .findIndex((token) => token.type === 'STRING');
        const toks = [...this.tokens];
        toks.splice(start, end + 1);
        return toks.map((token) => token.value).join('');
    }
    nearestLexeme(index) {
        const lexeme = this.tokens.findLast((token) => {
            return token.column < index;
        });
        return lexeme;
    }
    replaceLexeme(index, value) {
        const lexeme = this.nearestLexeme(index);
        console.log({ lexeme, index });
        if (lexeme) {
            lexeme.value = value;
        }
        return this;
    }
    format() {
        return this.tokens.map((token) => token.value).join('');
    }
}
function tokenisePrompt(prompt) {
    // prompt: "install @extension:postgresql and set connection string to @process.env:CONNECTION_STRING"
    let index = 0;
    const lexemes = [];
    while (index < prompt.length) {
        const char = prompt[index];
        switch (char) {
            case '@':
                lexemes.push({
                    type: 'IDENTIFIER',
                    value: prompt[index++],
                    column: index,
                });
                break;
            case ' ':
                lexemes.push({
                    type: 'WHITESPACE',
                    value: prompt[index++],
                    column: index,
                });
                break;
            default:
                {
                    const token = lexemes.at(-1) ?? {
                        type: 'IDENTIFIER',
                        value: '',
                        column: index,
                    };
                    token.value += char;
                    index++;
                    lexemes[lexemes.length - 1] = token;
                }
                break;
        }
    }
    return lexemes;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/index.ts
// @subject:user.id = @tables:posts(@trigger:path.id).userId







class RuleDecomposerVisitor extends Visitor {
    visitArg(node) {
        const name = node.name.accept(this);
        if (typeChecker.isNamespace(node.value)) {
            const value = node.value.accept(this);
            return `${name}: ${value.id}`;
        }
        const value = node.value.accept(this);
        return `${name}: ${value.id}`;
    }
    namespaces = {};
    visitBinary(node) {
        const left = node.left.accept(this);
        const right = node.right.accept(this);
    }
    visitCall(node) {
        const name = node.name.accept(this);
        const args = node.args.map((arg) => {
            return arg.accept(this);
        });
        return `${name}(${args.join(', ')})`;
    }
    visitPropertyAccess(node) {
        return `${node.name.accept(this)}.${node.expression.accept(this)}`;
    }
    visitNamespace(node) {
        const id = (0,external_uuid_.v4)();
        const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
        this.namespaces = {
            ...this.namespaces,
            [id]: name,
        };
        return { id, name };
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        node.accept(this);
        return this.namespaces;
    }
}
function decomposeVisitor(input) {
    const visitor = new RuleDecomposerVisitor();
    return visitor.visit(parseDsl(input));
}

;// CONCATENATED MODULE: ../utils/src/index.ts






// EXTERNAL MODULE: external "request-ip"
var external_request_ip_ = __webpack_require__(21);
;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/event_utils.ts
var event_utils_a;



const JWT_TOKEN = new external_tiny_injector_.InjectionToken('Token for the JWT');
const CLAIMS_TOKEN = new external_tiny_injector_.InjectionToken('Claims Token');
const CORRELATION_ID_TOKEN = new external_tiny_injector_.InjectionToken('Token for the correlation id');
let EventUtils = class EventUtils {
    _context;
    _claims;
    correlationId;
    #events = [];
    constructor(_context, _claims, correlationId) {
        this._context = _context;
        this._claims = _claims;
        this.correlationId = correlationId;
    }
    /**
     * Record the event to the context
     *
     * @param event assign an issuer event
     */
    recordEvent(event) {
        this.#events.push(event);
    }
    /**
     * Make the previous event as the issuer event
     */
    dequeue() {
        this.#events.pop();
    }
    /**
     * Get the issuer event
     *
     * @returns the issuer event
     */
    getIssuerEvent() {
        return this.#events[this.#events.length - 1]?.id;
    }
    /**
     * Get the metadata for a new event.
     *
     * @returns the metadata of the event
     */
    getMetadata(metadata) {
        const req = this._context.getExtra('request');
        const userAgent = req ? req.headers['user-agent'] : ''; // FIXME: should be InjectionToken
        const userIp = req ? (0,external_request_ip_.getClientIp)(req) : ''; // FIXME: should be InjectionToken
        return {
            platformVersion: '',
            userAgent: userAgent,
            userIp: userIp,
            userId: this._claims.uid,
            causationId: this.getIssuerEvent() || '',
            correlationId: this.correlationId,
            organizationId: this._claims.organizationId,
            workspaceId: this._claims.workspaceId,
            projectId: metadata?.projectId || this._claims.projectId,
        };
    }
};
EventUtils = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(1, (0,external_tiny_injector_.Inject)(CLAIMS_TOKEN)),
    (0,external_tslib_.__param)(2, (0,external_tiny_injector_.Inject)(CORRELATION_ID_TOKEN)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (event_utils_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? event_utils_a : Object, Object, String])
], EventUtils);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/abstract.store.ts



let AbstractStore = class AbstractStore {
    get basePath() {
        const _claims = external_tiny_injector_.Injector.GetRequiredService(CLAIMS_TOKEN, this.context);
        return [
            'organizations',
            _claims.organizationId,
            'workspaces',
            _claims.workspaceId,
            'projects',
            _claims.projectId,
        ];
    }
};
AbstractStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], AbstractStore);

let AbstractProjectionStore = class AbstractProjectionStore {
};
AbstractProjectionStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], AbstractProjectionStore);

let AbstractEventStore = class AbstractEventStore {
};
AbstractEventStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], AbstractEventStore);

class WebFirestore {
}
class IndexedDBStore {
}

;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/event.store.ts
var event_store_a, _b;







let EventStore = class EventStore {
    _store;
    _eventStore;
    constructor(_store, _eventStore) {
        this._store = _store;
        this._eventStore = _eventStore;
    }
    /**
     * Order events by causationId
     * It doesn't guarantee the order of events that have the same causationId
     */
    _orderByCausationId(events) {
        return events;
        const orderedEvents = [];
        while (events.length > 0) {
            let foundParent = false;
            for (let i = 0; i < events.length; i++) {
                const currentEvent = events[i];
                const parentEventIndex = events.findIndex((it) => it.id === currentEvent.metadata.causationId);
                if (parentEventIndex > -1) {
                    // The parent exists
                    const parentEvent = events[parentEventIndex];
                    orderedEvents.push(parentEvent);
                    events = [
                        ...events.slice(0, parentEventIndex),
                        ...events.slice(parentEventIndex + 1),
                    ];
                    foundParent = true;
                    break;
                }
            }
            if (!foundParent) {
                // No parent found, push the next event and remove it from the events array
                orderedEvents.push(events[0]);
                events = events.slice(1);
            }
        }
        return orderedEvents;
    }
    async save(aggregate) {
        await profile({ label: aggregate.streamName }, () => {
            return this._eventStore.save(aggregate);
        });
    }
    async getEventsForStreamName(streamName, filter) {
        const docs = await this._store.find({
            tableName: 'Events',
            where: {
                streamName: typeof streamName === 'string' ? streamName : streamName.streamName,
                ...filter,
            },
        });
        return this._orderByCausationId([
            ...mapData(docs),
            ...this.getPendingEvents().filter((it) => it.streamName === streamName),
        ]);
    }
    async getEventsForAggregate(id, pendingOnly = false) {
        if (pendingOnly) {
            return this._orderByCausationId(this.getPendingEvents().filter((it) => it.aggregateId === id));
        }
        const docs = await this._store.find({
            tableName: 'Events',
            where: { aggregateId: id },
        });
        return this._orderByCausationId([
            ...mapData(docs),
            ...this.getPendingEvents().filter((it) => it.aggregateId === id),
        ]);
    }
    async getEventsOfEventType(eventType, streamName, filter = {}) {
        eventType = typeof eventType === 'string' ? eventType : eventType.eventType;
        const docs = await this._store.find({
            tableName: 'Events',
            where: {
                eventType,
                streamName: typeof streamName === 'string' ? streamName : streamName?.streamName,
                ...filter,
            },
        });
        return this._orderByCausationId([
            ...mapData(docs),
            ...this.getPendingEvents().filter((it) => it.eventType === eventType),
        ]);
    }
    async getCorrelatedEvents(correlationId) {
        const docs = await this._store.find({
            tableName: 'Events',
            where: { 'metadata.correlationId': correlationId },
        });
        return this._orderByCausationId([
            ...mapData(docs),
            ...this.getPendingEvents().filter((it) => it.metadata.correlationId === correlationId),
        ]);
    }
    async getEvents(filter) {
        const docs = await this._store.find({
            tableName: 'Events',
            ...(filter ?? {}),
        });
        return this._orderByCausationId([
            ...mapData(docs),
            ...this.getPendingEvents(),
        ]);
    }
    getPendingEvents() {
        return this._store
            .getPendingDocs()
            .filter((it) => it instanceof DomainEvent);
    }
    async hyrdateAggregate(aggregateId, aggregateType) {
        const events = (await this.getEventsForAggregate(aggregateId));
        const aggregate = new aggregateType(aggregateId);
        aggregate.empty = events.length === 0;
        aggregate.replayEvents(events);
        return aggregate;
    }
    async listAggregates(aggregateType) {
        const events = await this.getEventsForStreamName(aggregateType.streamName);
        const grouped = (0,external_lodash_.groupBy)(events, 'aggregateId');
        const aggregates = [];
        for (const [aggregateId, events] of Object.entries(grouped)) {
            const aggregate = new aggregateType(aggregateId);
            aggregate.empty = events.length === 0;
            aggregate.replayEvents(events);
            aggregates.push(aggregate);
        }
        return aggregates;
    }
};
EventStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (event_store_a = typeof AbstractStore !== "undefined" && AbstractStore) === "function" ? event_store_a : Object, typeof (_b = typeof AbstractEventStore !== "undefined" && AbstractEventStore) === "function" ? _b : Object])
], EventStore);

function onEvent(config) {
    var _a;
    // we need inject() to make it work with the DI
    for (const eventType of config.events) {
        let FunctionalNotificationHandler = class FunctionalNotificationHandler extends tiny_mediatr_.INotificationHandler {
            _context;
            constructor(_context) {
                super();
                this._context = _context;
            }
            async handle(event) {
                await config.handler(event, this._context);
            }
        };
        FunctionalNotificationHandler = (0,external_tslib_.__decorate)([
            (0,tiny_mediatr_.NotificationHandler)(eventType),
            (0,external_tslib_.__metadata)("design:paramtypes", [typeof (_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? _a : Object])
        ], FunctionalNotificationHandler);
    }
}
function onRequest(config) {
    var _a;
    let FunctionalNotificationHandler = class FunctionalNotificationHandler extends tiny_mediatr_.IRequestHandler {
        _context;
        constructor(_context) {
            super();
            this._context = _context;
        }
        async handle(request) {
            const result = await config.handler(request, this._context);
            return result;
        }
    };
    FunctionalNotificationHandler = (0,external_tslib_.__decorate)([
        (0,tiny_mediatr_.RequestHandler)(config.requestType),
        (0,external_tslib_.__metadata)("design:paramtypes", [typeof (_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? _a : Object])
    ], FunctionalNotificationHandler);
    // we need inject() to make it work with the DI
}
function mapData(docs) {
    return docs.map((it) => {
        if (typeof it.data === 'string') {
            return {
                ...it,
                data: JSON.parse(it.data),
            };
        }
        return {
            ...it,
        };
    });
}

;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/keyvalue/abstract-keyvalue.store.ts

class AbstractKeyValueStore {
}
const KEY_VALUE_TOKEN = new external_tiny_injector_.InjectionToken('KEY_VALUE_TOKEN');

;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/keyvalue/sqlite-keyvalue.ts



let SqliteKeyValueStore = class SqliteKeyValueStore extends AbstractKeyValueStore {
    client;
    constructor(client) {
        super();
        this.client = client;
    }
    async set(key, value) {
        await this.client.execute({
            sql: `
      INSERT INTO keyvalue (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = json_patch(keyvalue.value, excluded.value);
      `,
            args: [key, JSON.stringify(value)],
        });
    }
    async get(key, defaultVal) {
        const result = await this.client.execute({
            sql: 'SELECT value FROM keyvalue WHERE key = ?;',
            args: [key],
        });
        const value = result.rows[0];
        return value?.['value']
            ? JSON.parse(value['value'])
            : defaultVal;
    }
    async delete(key) {
        await this.client.execute({
            sql: 'DELETE FROM keyvalue WHERE key = ?;',
            args: [key],
        });
    }
};
SqliteKeyValueStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(0, (0,external_tiny_injector_.Inject)(KEY_VALUE_TOKEN)),
    (0,external_tslib_.__metadata)("design:paramtypes", [Object])
], SqliteKeyValueStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/mediatr.ts



let EventMediator = class EventMediator extends tiny_mediatr_.Mediator {
    #requests = new Map();
    send(request) {
        this.#requests.set(request.constructor, request);
        return super.send(request);
    }
    async publishCore(handlers, notification) {
        // TODO: try to push the notifications outside of this stack trace.
        await Promise.all(handlers.map((handler) => handler.handle(notification)));
        return void 0;
    }
    getRequest(type) {
        const request = this.#requests.get(type);
        if (!request) {
            throw new Error(`Request not found: ${type.name}`);
        }
        return request;
    }
};
EventMediator = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], EventMediator);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/projection.ts
var projection_a, projection_b;


function buildProjection(initialProjection, events, reducer) {
    return events.reduce((state, event) => reducer(state, event), initialProjection);
}
async function buildProjectionAsync(initialProjection, events, reducer) {
    for (const event of events) {
        initialProjection = await reducer(initialProjection, event);
    }
    return initialProjection;
}
class Projection {
    id;
    createdAt;
    updatedAt;
    appVersion;
    prefix;
    toJson() {
        const json = { ...this };
        if (!json.createdAt) {
            delete json.createdAt;
        }
        return { ...this };
    }
    constructor(id) {
        // FIXME: changes can eieher represent first or last commmit
        this.id = id;
    }
}
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], Projection.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (projection_a = typeof ReturnType !== "undefined" && ReturnType) === "function" ? projection_a : Object)
], Projection.prototype, "createdAt", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (projection_b = typeof ReturnType !== "undefined" && ReturnType) === "function" ? projection_b : Object)
], Projection.prototype, "updatedAt", void 0);
function createOrThrow(key) {
    // FIXME: use proxy over the projection and
    // if a field never been set throw an error
    let value;
    const partialObject = {};
    Object.defineProperty(partialObject, key, {
        // configurable: false,
        // enumerable: true,
        set: (v) => {
            value = v;
        },
        get: () => {
            if (value === undefined) {
                throw new Error(`Value of '${key}' not set yet`);
            }
        },
    });
    return partialObject;
}
function createProjection(state) {
    return Object.assign({}, createOrThrow('createdAt'), createOrThrow('updatedAt'), state);
}
class Projector {
    async foldUp(initialProjection, events) {
        for (const event of events) {
            initialProjection = await this.apply(initialProjection, event);
        }
        return initialProjection;
    }
    async getProjector(id, options = {}) {
        let projection = (await this._projectionStore.getProjection(this.projectionName, id)) ??
            options.defaultState;
        if (!projection) {
            return projection;
        }
        if (projection.appVersion !== 'this._environment.version') {
            const events = await this._eventStore.getEventsForAggregate(id);
            projection = await this.foldUp(projection, [...events]);
        }
        else {
            projection = await this.foldUp(projection, [
                ...(options.events ?? []),
            ]);
        }
        return projection;
    }
    async listProjections() {
        return this._projectionStore.listProjections(this.projectionName);
    }
    saveProjection(id, projection) {
        // this._projectionStore.save(this.projectionName, id, projection);
    }
    async rebuildProjection(id, defaultState) {
        const events = await this._eventStore.getEvents();
        const projection = await this.getProjector(id, {
            defaultState,
            events: [...events],
        });
        this.saveProjection(id, projection);
        return projection;
    }
}

;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/projection.store.ts
var projection_store_a, projection_store_b;




let ProjectionStore = class ProjectionStore {
    _store;
    _projectionStore;
    _environment;
    constructor(_store, _projectionStore, _environment) {
        this._store = _store;
        this._projectionStore = _projectionStore;
        this._environment = _environment;
    }
    save(prefix, id, projection) {
        // this._projectionStore.save({
        //   ...projection,
        //   id: id,
        //   prefix: prefix,
        //   appVersion: this._environment.version,
        // });
    }
    storeDocument(prefix, projection) {
        // this._projectionStore.save({
        //   ...projection,
        //   prefix: prefix,
        //   id: prefix,
        //   appVersion: this._environment.version,
        // });
    }
    /**
     * Returns a document from the projection collection. This method is used
     * to get singelton projection.
     */
    async getSingeltonProjection(prefix) {
        // const doc = this._store.singeltonProjection(prefix);
        // const inHold = this._store.get(doc.path);
        // if (inHold) {
        //   return inHold as T;
        // }
        // const document = await doc.get();
        // return document.data() as T;
        const docs = await this._store.find({
            tableName: 'Projections',
            where: { id: prefix },
        });
        return docs.map((it) => {
            if (typeof it.data === 'string') {
                return JSON.parse(it.data);
            }
            return it.data;
        })[0];
    }
    /**
     * Returns a document from the projection collection. This method is used
     * to get a projection from a list of projections.
     */
    async getProjection(prefix, id) {
        // const doc = this._store.projections(prefix).doc(id);
        // const inHold = this._store.get(doc.path);
        // if (inHold) {
        //   return inHold as T;
        // }
        // const document = await doc.get();
        // return document.data() as T;
        const docs = await this._store.find({
            tableName: 'Projections',
            where: { prefix, id },
        });
        return docs.map((it) => {
            if (typeof it.data === 'string') {
                return JSON.parse(it.data);
            }
            return it.data;
        })[0];
    }
    async listProjections(prefix) {
        // const doc = this._store.projections(prefix);
        // const inHold = this._store.get(doc.path);
        // if (inHold) {
        //   return inHold as T[];
        // }
        // const { docs } = await doc.get();
        // return docs.map((it) => it.data()) as T[];
        // const inHold = this._store.get(
        //   join(...this._store.basePath, `projections;${prefix}`),
        // );
        // if (inHold) {
        //   return inHold as T[];
        // }
        const docs = await this._store.find({
            tableName: 'Projections',
            where: { prefix: prefix },
        });
        return docs.map((it) => {
            if (typeof it.data === 'string') {
                return JSON.parse(it.data);
            }
            return it.data;
        });
    }
};
ProjectionStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(2, (0,external_tiny_injector_.Inject)(ENVIRONMENT)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (projection_store_a = typeof AbstractStore !== "undefined" && AbstractStore) === "function" ? projection_store_a : Object, typeof (projection_store_b = typeof AbstractProjectionStore !== "undefined" && AbstractProjectionStore) === "function" ? projection_store_b : Object, Object])
], ProjectionStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/sqlite/sqlite.token.ts

const SQLITE_TOKEN = new external_tiny_injector_.InjectionToken('SQLITE_TOKEN');

;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/sqlite/sqlite.store.ts
var sqlite_store_a;




let SQLiteStore = class SQLiteStore extends AbstractStore {
    db;
    context;
    _queue = {};
    constructor(db, context) {
        super();
        this.db = db;
        this.context = context;
    }
    async find(filter) {
        let query = `SELECT * FROM ${filter.tableName}`;
        const params = [];
        const where = filter.where;
        if (!where) {
            return await this.db.query({
                sql: query,
                params: params,
            });
        }
        const entries = Object.entries(where);
        if (entries.length) {
            query += ' WHERE ';
            query += entries
                .map(([key, value]) => {
                if (key.includes('.')) {
                    const [part1, part2] = key.split('.'); // metadata.projectId
                    params.push(value);
                    return `json_extract(${part1}, '$.${part2}') = ?`;
                }
                return `${key} = '${value}'`;
            })
                .join(' AND ');
        }
        query += ' ORDER BY timestamp ';
        if (filter.orderBy?.timestamp) {
            query += `${filter.orderBy.timestamp || 'ASC'}`;
        }
        if (filter.limit) {
            query += ` LIMIT ${filter.limit}`;
        }
        return await this.db.query({
            sql: query,
            params: params,
        });
    }
    hold(path, operation, data) {
        this._queue[path] = [operation, data];
    }
    getPendingDocs() {
        return Object.values(this._queue).map(([, doc]) => doc);
    }
    get(path, force = false) {
        const pendingDocument = this._queue[path];
        if (pendingDocument) {
            return pendingDocument;
        }
        return null;
    }
    clearPending() {
        this._queue = {};
    }
    async commit() {
        const pending = Object.values(this._queue);
        if (!pending.length) {
            return Promise.resolve(void 0);
        }
        await this.db.transaction(pending);
        this.clearPending();
    }
};
SQLiteStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)(),
    (0,external_tslib_.__param)(0, (0,external_tiny_injector_.Inject)(SQLITE_TOKEN)),
    (0,external_tslib_.__metadata)("design:paramtypes", [Object, typeof (sqlite_store_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? sqlite_store_a : Object])
], SQLiteStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/sqlite/sqlite.events.ts
var sqlite_events_a, sqlite_events_b, _c;








let SqliteEventStore = class SqliteEventStore extends AbstractEventStore {
    db;
    _mediator;
    _store;
    _eventUtils;
    constructor(db, _mediator, _store, _eventUtils) {
        super();
        this.db = db;
        this._mediator = _mediator;
        this._store = _store;
        this._eventUtils = _eventUtils;
    }
    async save(aggregate) {
        for (const event of aggregate.getUncommittedChanges()) {
            event.streamName = aggregate.streamName;
            this._store.hold((0,external_path_.join)(...this._store.basePath, 'events', event.id), (client) => {
                const it = event.toJson();
                return this._store.db.prepare({
                    sql: `
            INSERT INTO Events (id, eventType, aggregateVersion, aggregateId, entityId, metadata, data, streamName)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `,
                    params: [
                        it.id,
                        it.eventType,
                        /**it.aggregateVersion,**/ 0,
                        it.aggregateId,
                        it.entityId,
                        JSON.stringify(it.metadata),
                        JSON.stringify(it.data),
                        it.streamName,
                    ],
                    txn: true,
                }, client);
            }, event);
            this._eventUtils.recordEvent(event);
            // FIXME: we need to make this asynchronous
            await this._mediator.publish(event);
            this._eventUtils.dequeue();
            // console.log('LOG EVENT: ', event.constructor);
        }
        aggregate.markChangesAsCommitted();
    }
};
SqliteEventStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)(),
    (0,external_tslib_.__param)(0, (0,external_tiny_injector_.Inject)(SQLITE_TOKEN)),
    (0,external_tslib_.__param)(2, (0,external_tiny_injector_.Inject)(AbstractStore)),
    (0,external_tslib_.__metadata)("design:paramtypes", [Object, typeof (sqlite_events_a = typeof tiny_mediatr_.Mediator !== "undefined" && tiny_mediatr_.Mediator) === "function" ? sqlite_events_a : Object, typeof (sqlite_events_b = typeof SQLiteStore !== "undefined" && SQLiteStore) === "function" ? sqlite_events_b : Object, typeof (_c = typeof EventUtils !== "undefined" && EventUtils) === "function" ? _c : Object])
], SqliteEventStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/sqlite/sqlite.projection.ts
var sqlite_projection_a;







let SqliteProjectionStore = class SqliteProjectionStore extends AbstractProjectionStore {
    db;
    _store;
    constructor(db, _store) {
        super();
        this.db = db;
        this._store = _store;
    }
    save(projection) {
        this._store.hold((0,external_path_.join)(...this._store.basePath, 'projections', projection.id), (client) => {
            return this.db.prepare({
                sql: external_dedent_default() `
        INSERT INTO Projections (id, data, prefix)
        VALUES (?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET data = excluded.data;
      `,
                params: [
                    projection.id,
                    JSON.stringify(projection),
                    projection.prefix,
                ],
                txn: true,
            }, client);
        }, projection);
    }
};
SqliteProjectionStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)(),
    (0,external_tslib_.__param)(0, (0,external_tiny_injector_.Inject)(SQLITE_TOKEN)),
    (0,external_tslib_.__param)(1, (0,external_tiny_injector_.Inject)(AbstractStore)),
    (0,external_tslib_.__metadata)("design:paramtypes", [Object, typeof (sqlite_projection_a = typeof SQLiteStore !== "undefined" && SQLiteStore) === "function" ? sqlite_projection_a : Object])
], SqliteProjectionStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/lib/stores/sqlite/turso.store.ts
var turso_store_a;




let TursoStore = class TursoStore extends AbstractStore {
    db;
    context;
    _queue = {};
    constructor(db, context) {
        super();
        this.db = db;
        this.context = context;
    }
    async find(filter) {
        let query = `SELECT * FROM ${filter.tableName}`;
        const params = [];
        const where = filter.where;
        if (!where) {
            return await this.db.query({
                sql: query,
                params: params,
            });
        }
        const entries = Object.entries(where);
        if (entries.length) {
            query += ' WHERE ';
            query += entries
                .map(([key, value]) => {
                if (key.includes('.')) {
                    const [part1, part2] = key.split('.'); // metadata.projectId
                    params.push(value);
                    return `json_extract(${part1}, '$.${part2}') = ?`;
                }
                return `${key} = '${value}'`;
            })
                .join(' AND ');
        }
        query += ' ORDER BY timestamp ';
        if (filter.orderBy?.timestamp) {
            query += `${filter.orderBy.timestamp || 'ASC'}`;
        }
        if (filter.limit) {
            query += ` LIMIT ${filter.limit}`;
        }
        return await this.db.query({
            sql: query,
            params: params,
        });
    }
    hold(path, operation, data) {
        this._queue[path] = [operation, data];
    }
    getPendingDocs() {
        return Object.values(this._queue).map(([, doc]) => doc);
    }
    get(path, force = false) {
        const pendingDocument = this._queue[path];
        if (pendingDocument) {
            return pendingDocument;
        }
        return null;
    }
    clearPending() {
        this._queue = {};
    }
    async commit() {
        const pending = Object.values(this._queue);
        if (!pending.length) {
            return Promise.resolve(void 0);
        }
        await this.db.transaction(pending);
        this.clearPending();
    }
};
TursoStore = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)(),
    (0,external_tslib_.__param)(0, (0,external_tiny_injector_.Inject)(SQLITE_TOKEN)),
    (0,external_tslib_.__metadata)("design:paramtypes", [Object, typeof (turso_store_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? turso_store_a : Object])
], TursoStore);


;// CONCATENATED MODULE: ../api/infrastructure/database/src/index.ts














;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/data/actions.json
const actions_namespaceObject = /*#__PURE__*/JSON.parse('[{"id":"077b1325-0ade-4f63-8f66-ced39cef38ba","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Atomic","name":"atomic","visible":true,"multi":true,"allowedActions":[],"output":{"source":[]},"metadata":{}},{"id":"9c858969-f48b-4b72-8282-bfe82654ae9a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Delete Record","name":"delete-record","visible":true,"output":{"displayName":"deletedRecord","source":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}}},"metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true,"source":{"url":"/tables"}},"query":{"displayName":"Filter","type":"query-builder","required":false,"source":{"url":"/tables/:id","binding":{"id":"context.tableId"}}},"cascade":{"displayName":"Cascade","type":"boolean","defaultValue":true,"required":true,"visible":false}}},{"id":"b036bc50-9292-486a-9714-1f551fee5dc4","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Record Exist","name":"check-record-existance","metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true,"source":{"url":"/tables"}},"query":{"displayName":"Filter","type":"query-builder","required":false,"source":{"url":"/tables/:id","binding":{"id":"context.tableId"}}}},"output":{"displayName":"recordExists","source":[{"id":"recordExists","primitiveType":"boolean","displayName":"recordExists"}]}},{"id":"83ce1e80-0117-4ebc-86ac-3bdad3b32796","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Insert Record","name":"insert-record","metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true,"source":{"url":"/tables"}},"columns":{"displayName":"Payload","type":"columns-list","required":false,"source":{"except":["2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e","6c09acb6-e45a-479f-be05-c391dfbced8e"],"url":"/tables/:id/fields","binding":{"id":"context.tableId"}}}},"output":{"displayName":"inserted","outputName":{"url":"/tables/:id","binding":{"id":"context.tableId"},"format":"new @source.displayName"},"source":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}}}},{"id":"2bb630dd-7ba3-4cda-95a7-f65ee22116ee","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Raw SQL Query","name":"raw-sql-query","metadata":{"query":{"displayName":"Query","type":"string","required":true}},"output":{"displayName":"inserted","outputName":{"url":"/tables/:id","binding":{"id":"context.tableId"},"format":"new @source.displayName"},"source":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}}}},{"id":"62e55ba2-9a81-4f88-995e-2093ca3fc067","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Upsert Record","name":"upsert-record","metadata":{"tableId":{"displayName":"Table","type":"single-select"},"columns":{"displayName":"Payload","type":"columns-list"}},"output":{"displayName":"inserted","outputName":{"url":"/tables/:id","binding":{"id":"context.tableId"},"format":"new @source.displayName"},"source":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}}}},{"id":"a8ded515-b99e-4fca-9654-7d2c12624a7a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Increment Field","name":"increment-field","metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true},"query":{"displayName":"Filter","type":"query-builder","required":true},"column":{"displayName":"Field","type":"string","required":true}}},{"id":"b5a5e901-9ef8-4d2c-86f2-39263ca8ebee","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Increment Field","name":"decrement-field","metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true},"query":{"displayName":"Filter","type":"query-builder","required":true},"column":{"displayName":"Field","type":"string","required":true}}},{"output":{"type":"context.tableId","displayName":"updatedRecord","source":[]},"id":"0eeac945-4dcd-40ff-be62-1ad371406ae4","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Set Fields","name":"set-fields","metadata":{"tableId":{"displayName":"Table","type":"single-select","required":true,"source":{"url":"/tables"}},"query":{"displayName":"Filter","type":"query-builder","required":true,"source":{"url":"/tables/:id","binding":{"id":"context.tableId"}}},"columns":{"displayName":"Field","type":"columns-list","required":true,"source":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"},"except":["2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e","6c09acb6-e45a-479f-be05-c391dfbced8e"]}}}},{"id":"0eeac945-4dcd-40ff-be62-1ad371406ae4","extensionId":"1e8e1778-4be6-4346-aa79-9955f9e422a4","displayName":"With i18n","name":"i18n"},{"id":"3c40908c-1c69-4222-a936-7a569a1198b5","extensionId":"3e184f8b-d2dc-4592-9507-979d649277f5","displayName":"Upload file to google storage","name":"upload-file","output":{"displayName":"uploadedFile","source":[]},"metadata":{"multiple":{"displayName":"Can upload multiple files","type":"boolean","required":false,"defaultValue":"@fixed:false"},"maxFileCount":{"displayName":"Maximum file count","type":"number","required":false,"defaultValue":"@fixed:1","if":{"operator":"equal","input":"context.multiple","value":true}},"maxTotalSize":{"displayName":"Maximum total size","type":"number","required":false,"if":{"operator":"equal","input":"context.multiple","value":true}},"maxFileSize":{"displayName":"Maximum file size","type":"number","required":false}}},{"id":"c4ec127b-e167-4a30-8544-732c55d1bd24","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"List Records","name":"list-records","metadata":{"localizable":{"displayName":"Localizable","type":"boolean","required":false,"fieldset":"first","visible":false,"defaultValue":"false"},"pagination":{"displayName":"Pagination","type":"single-select","required":true,"fieldset":"pagination","defaultValue":"deferred_joins","source":[{"id":"none","displayName":"None"},{"id":"limit_offset","displayName":"Limit & Offset"},{"id":"deferred_joins","displayName":"Deferred Joins"},{"id":"cursor","displayName":"Cursor"}]},"tableId":{"displayName":"Table","type":"single-select","fieldset":"first","required":true,"source":{"url":"/tables"}},"limit":{"displayName":"Limit","type":"number","required":false,"fieldset":"pagination","defaultValue":50},"query":{"displayName":"Query","type":"query-builder","required":true,"source":{"url":"/tables/:id","binding":{"id":"context.tableId"}}}},"output":{"source":{"input":"context.pagination","operator":"equal","value":"none","then":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}},"else":[{"id":"records","displayName":"records","primitiveType":{"input":"context.limit","operator":"equal","value":1,"then":"object","else":"array"},"typeName":{"url":"/tables/:id","binding":{"id":"context.tableId"},"use":"displayName"},"interface":{"url":"/tables/:id/fields","binding":{"id":"context.tableId"}},"if":{"input":"context.pagination","operator":"equal","value":"none","then":true,"else":false}},{"id":"meta","displayName":"meta","typeName":"Meta","primitiveType":"object","interface":[{"id":"hasNextPage","displayName":"hasNextPage","primitiveType":"boolean"},{"id":"hasPreviousPage","displayName":"hasPreviousPage","primitiveType":"boolean"},{"id":"pageSize","displayName":"pageSize","primitiveType":"number"},{"id":"currentPage","displayName":"currentPage","primitiveType":"number"},{"id":"totalCount","displayName":"totalCount","primitiveType":"number"},{"id":"totalPages","displayName":"totalPages","primitiveType":"number"}],"if":{"input":"context.pagination","operator":"equal","value":"none","then":true,"else":false}}]}}},{"id":"89ad4cdb-2ed1-4c42-84bd-4986648bbfe2","extensionId":"3e184f8b-d2dc-4592-9507-979d649277f5","displayName":"List Files","name":"list-files","output":{"displayName":"files","source":[]},"metadata":{"prefix":{"displayName":"Prefix","type":"string","required":false,"fieldset":"first"},"flat":{"displayName":"Flat","type":"boolean","required":false,"fieldset":"first"}}},{"id":"43ea3f72-f3b0-419f-abef-f1bd4b5e9b22","extensionId":"339b60c7-7b1c-49e1-b1dd-716c2e3ab334","displayName":"Custom Code","name":"custom-code","output":{"source":[]},"metadata":{"code":{"displayName":"Code","type":"code-editor","required":true,"extras":{"language":"typescript"}}}},{"id":"e0c60892-6b26-417e-8140-8e8d31f64ab2","extensionId":"339b60c7-7b1c-49e1-b1dd-716c2e3ab334","displayName":"Branch","name":"branch","type":"branch","multi":true,"output":{"source":[]},"metadata":{}},{"id":"89e16a38-25f1-444e-bcf7-96e6455c3707","extensionId":"485654c6-06fc-425e-9ba6-341ec2c9ae07","displayName":"Send Email","name":"send-email","output":{"outputName":"sentEmail","source":[]},"metadata":{"from":{"displayName":"From","type":"string","required":true,"fieldset":"email"},"to":{"displayName":"To","type":"string","required":true,"fieldset":"email"},"replayTo":{"displayName":"Replay To","type":"string","required":false},"subject":{"displayName":"Subject","type":"string","required":true,"fieldset":"content"},"templateId":{"displayName":"Template","type":"string","fieldset":"content","required":true}}},{"id":"69a01ada-a83a-451f-a3fe-fb486e08ffa9","extensionId":"ee5d3a3a-501a-4653-914e-d3665760f7bf","displayName":"Resend: Send Email","name":"resend-send-email","output":{"source":[]},"metadata":{"from":{"displayName":"From","type":"string","validations":[{"name":"mandatory","details":{"value":"true"}}],"fieldset":"email"},"to":{"displayName":"To","type":"string","validations":[{"name":"mandatory","details":{"value":"true"}}],"fieldset":"email"},"subject":{"displayName":"Subject","type":"string","validations":[{"name":"mandatory","details":{"value":"true"}}],"fieldset":"content"},"text":{"displayName":"Text","type":"string","fieldset":"content","validations":[{"name":"mandatory","details":{"value":"true"}}]},"html":{"displayName":"Text","type":"string","fieldset":"content","validations":[{"name":"mandatory","details":{"value":"true"}}]}}},{"id":"c292a9d7-1f66-47b9-b366-e25f3faff840","extensionId":"ee5d3a3a-501a-4653-914e-d3665760f7bf","displayName":"Resend: Create Contact","name":"resend-create-contact","output":{"source":[]},"metadata":{"firstName":{"displayName":"First name","type":"string","fieldset":"general"},"lastName":{"displayName":"Last name","type":"string","required":false,"fieldset":"general"},"email":{"displayName":"Email","type":"string","fieldset":"email","validations":[{"name":"mandatory","details":{"value":"true"}}]},"unsubscribed":{"displayName":"Unsubscribed","type":"string","required":false,"fieldset":"email"},"audienceId":{"displayName":"Audience id","type":"string","fieldset":"email","validations":[{"name":"mandatory","details":{"value":"true"}}]}}},{"id":"b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b","extensionId":"389d81cd-5b58-4ade-b815-add468c48e37","displayName":"Ajax","name":"ajax","output":{"source":[]},"metadata":{"url":{"displayName":"URL","type":"inline","required":true,"fieldset":"first"},"method":{"displayName":"Method","type":"inline","required":true,"fieldset":"first"},"body":{"displayName":"Body","type":"json","required":false}}},{"id":"7a9d9a29-7079-4aa8-bdc0-d93a713a2440","extensionId":"0d9101cf-7c31-4ac5-bcad-620acb566cce","displayName":"HTTP Trigger","name":"http","type":"trigger","metadata":{"path":{"fieldset":"config","type":"string","displayName":"Path","required":true,"pattern":"^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"},"method":{"fieldset":"config","displayName":"Method","type":"single-select","source":[{"id":"get","displayName":"GET"},{"id":"post","displayName":"POST"},{"id":"put","displayName":"PUT"},{"id":"patch","displayName":"PATCH"},{"id":"delete","displayName":"DELETE"},{"id":"head","displayName":"HEAD"}],"required":true},"contentType":{"visible":false,"fieldset":"optional","type":"single-select","displayName":"Content Type","required":false,"source":[{"id":"application/json","displayName":"application/json"},{"id":"application/x-www-form-urlencoded","displayName":"application/x-www-form-urlencoded"},{"id":"multipart/form-data","displayName":"multipart/form-data"}]},"summary":{"fieldset":"optional","type":"string","displayName":"Summary","required":false,"visible":false}}},{"id":"0aec7685-5c19-43eb-bc2c-93597b5cecfc","extensionId":"0d9101cf-7c31-4ac5-bcad-620acb566cce","displayName":"SSE Trigger","name":"sse","type":"trigger"},{"id":"7b1696e9-9c89-4ba7-abc0-e1448b287772","extensionId":"9c034274-069e-4567-ab33-bab8f31f874c","displayName":"Github Trigger","name":"github-trigger","type":"trigger"},{"id":"cd76caa3-e9f0-49b8-bf7a-0ebed83bd486","extensionId":"4320a2a1-bab9-4ca8-bab5-eb56280933c6","displayName":"Scheduler","name":"node-cron-trigger","type":"trigger"}]');
;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/data/extensions.json
const extensions_namespaceObject = /*#__PURE__*/JSON.parse('[{"id":"e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b","visible":false,"name":"soft-delete","categories":["soft-delete"],"title":"","subtitle":"Support Soft Delete functionality in any table.","description":"Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.","tableMetadata":{"tableId":{"displayName":"Support Soft Delete","required":false,"visible":false,"type":"single-select","source":[{"id":"none","displayName":"No soft delete"},{"id":"at","displayName":"Using deletedAt column"},{"id":"flag","displayName":"Using deleted flag"},{"id":"trash","displayName":"Using trash table"}]}},"metadata":{},"packages":[]},{"id":"339b60c7-7b1c-49e1-b1dd-716c2e3ab334","visible":true,"name":"core","categories":["misc"],"title":"Core","subtitle":"Core functionality","metadata":{},"description":"Essential functionality that is required for all projects.","packages":[{"name":"rfc-7807-problem-details","version":"^1.1.0"},{"name":"ajv","version":"8.12.0"},{"name":"ajv-formats","version":"2.1.1"},{"name":"ajv-errors","version":"3.0.0"},{"name":"ajv-keywords","version":"5.1.0"},{"name":"validator","version":"13.9.0"},{"name":"lodash-es","version":"^4.17.21"},{"name":"@types/lodash-es","version":"^4.17.12","dev":true},{"name":"http-status-codes","version":"2.2.0"},{"name":"@types/node","version":"^20.11.26","dev":true},{"name":"typescript","version":"^4.9.4","dev":true},{"name":"@types/validator","version":"13.7.17","dev":true}]},{"id":"977a059f-ddda-4677-b785-4d1b04a7c201","visible":true,"name":"prettier","categories":["misc"],"title":"Prettier","subtitle":"An opinionated code formatter","description":"Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.","logo":"assets/prettier.png","metadata":{},"packages":[{"name":"prettier","version":"3.3.2","dev":true}]},{"id":"e81b26bb-051b-4b30-a94d-e34ad615504c","visible":true,"name":"identity","categories":["misc"],"title":"identity","subtitle":"identity","description":"","metadata":{},"packages":[{"name":"ua-parser-js","version":"^1.0.37"},{"name":"@types/ua-parser-js","version":"^0.7.39","dev":true},{"name":"@types/request-ip","version":"^0.0.41","dev":true},{"name":"request-ip","version":"^3.3.0"}]},{"id":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"postgresql","categories":["database"],"main":"execute.ts","metadata":{"orm":{"displayName":"ORM","type":"inline","defaultValue":"@fixed:typeorm","source":["@fixed:typeorm"],"description":"The ORM to use","required":true},"i18n":{"displayName":"i18n","type":"inline","defaultValue":"@fixed:none","description":"Whether to enable internationalization (i18n) or not","source":[{"displayName":"None","id":"@fixed:none"},{"displayName":"Default","id":"@fixed:default"}],"required":true},"CONNECTION_STRING":{"description":"The connection string to the database","displayName":"Connection String","type":"string","defaultValue":"@process:env.CONNECTION_STRING","required":true}},"tableMetadata":{"softDelete":{"displayName":"Support Soft Delete","required":true,"type":"single-select","visible":false,"defaultValue":"@fixed:at","source":[{"id":"at","displayName":"Using deletedAt column"},{"id":"flag","displayName":"Using deleted flag","visible":false},{"id":"trash","displayName":"Using trash table","visible":false}]}},"svg":"SiPostgresql","title":"PostgreSQL","subtitle":"A free and open-source relational database management system emphasizing extensibility and SQL compliance.","description":"PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.","logo":"assets/postgresql.svg","packages":[{"name":"typeorm","version":"0.3.20"},{"name":"pg","version":"8.11.5"},{"name":"sql-template-tag","version":"5.2.1"}]},{"id":"71c97a1c-3efe-4712-b35b-56714dafa02f","name":"mysql","categories":["database"],"disabled":true,"metadata":{"orm":{"displayName":"ORM","type":"inline","defaultValue":"@fixed:typeorm","source":["@fixed:typeorm"],"description":"The ORM to use","required":true},"i18n":{"displayName":"i18n","type":"inline","defaultValue":"@fixed:none","description":"Whether to enable internationalization (i18n) or not","source":[{"displayName":"None","id":"@fixed:none"},{"displayName":"Default","id":"@fixed:default"}],"required":true},"CONNECTION_STRING":{"description":"The connection string to the database","displayName":"Connection String","type":"string","defaultValue":"@process:env.CONNECTION_STRING","required":true}},"tableMetadata":{"softDelete":{"displayName":"Support Soft Delete","required":true,"type":"single-select","visible":false,"defaultValue":"@fixed:at","source":[{"id":"at","displayName":"Using deletedAt column"},{"id":"flag","displayName":"Using deleted flag","visible":false},{"id":"trash","displayName":"Using trash table","visible":false}]}},"svg":"SiPostgresql","title":"MySQL","description":"MySQL is an open-source relational database management system.","logo":"assets/postgresql.svg"},{"id":"1e8e1778-4be6-4346-aa79-9955f9e422a4","name":"firebase-functions","categories":["hosting"],"disabled":true,"logo":"assets/firebase-functions.png","svg":"SiFirebase","title":"Firebase Functions","subtitle":"Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code","description":"Firebase Functions is a serverless framework that lets you automatically run backend code.","metadata":{"FIREBASE_FUNCTION_PROJECT_ID":{"displayName":"Project ID","required":true,"type":"string","defaultValue":"@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"},"FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY":{"displayName":"Service Account Key (JSON)","required":true,"type":"json","defaultValue":"@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"}},"packages":[{"name":"firebase-functions","version":"^5.0.1"},{"name":"firebase-admin","version":"^12.4.0"}]},{"id":"d9e83836-e41d-4ae2-aa93-229a0ef27069","name":"firebase-auth","categories":["identity"],"disabled":false,"main":"firebase.ts","metadata":{"FIREBASE_AUTH_SERVICE_ACCOUNT_KEY":{"displayName":"Service Account Key (JSON)","required":true,"type":"json","defaultValue":"@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"}},"title":"Firebase Authentication","description":"Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.","subtitle":"Authenticate users with Firebase","packages":[{"name":"firebase-admin","version":"^12.4.0"},{"name":"ua-parser-js","version":"^1.0.37"},{"name":"@types/ua-parser-js","version":"^0.7.39","dev":true},{"name":"@types/request-ip","version":"^0.0.41","dev":true},{"name":"request-ip","version":"^3.3.0"}]},{"id":"34d9ec05-de0d-4d79-ae2a-9a06200d20dd","name":"fly","categories":["hosting"],"logo":"assets/fly.png","title":"Fly","description":"Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.","metadata":{"FLY_API_TOKEN":{"displayName":"Deploy Token","required":true,"type":"string","defaultValue":"@build:secrets.FLY_API_TOKEN","description":"The token to deploy the app"},"FLY_APP_NAME":{"displayName":"App Name","required":true,"type":"string","defaultValue":"@build:secrets.FLY_APP_NAME","description":"The name of the app"}}},{"name":"vercel","id":"4c82c872-1a2f-4849-98a6-bd7017498191","categories":["hosting"],"title":"Vercel","description":"Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.","metadata":{"VERCEL_ORG_ID":{"displayName":"Org ID","required":true,"type":"string","defaultValue":"@build:secrets.VERCEL_ORG_ID"},"VERCEL_PROJECT_ID":{"displayName":"Project ID","required":true,"type":"string","defaultValue":"@build:secrets.VERCEL_PROJECT_ID"},"VERCEL_API_TOKEN":{"displayName":"API Token","required":true,"type":"string","defaultValue":"@build:secrets.VERCEL_API_TOKEN"}}},{"id":"0d9101cf-7c31-4ac5-bcad-620acb566cce","name":"hono","categories":["routing"],"title":"Hono.dev","description":"Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.","metadata":{},"packages":[{"name":"hono","version":"^4.4.0"},{"name":"@hono/node-server","version":"^1.11.1"},{"name":"@scalar/hono-api-reference","version":"^0.5.145"}]},{"id":"109aa1af-f9d0-4d31-bbc6-c4603be5b7b0","name":"koajs","disabled":true,"categories":["routing"],"title":"Koa.js","description":"Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.","logo":"assets/http.svg","metadata":{},"svg":"SiKoa","packages":[{"name":"koa","version":"latest"},{"name":"koa-static","version":"latest"},{"name":"@types/koa-static","version":"latest"},{"name":"@koa/router","version":"latest"},{"name":"koa-body","version":"latest"},{"name":"koa-bodyparser","version":"latest"},{"name":"koa-logger","version":"latest"},{"name":"koa-qs","version":"latest"},{"name":"@koa/cors","version":"latest"},{"name":"@types/koa-logger","version":"latest"},{"name":"@types/koa__cors","version":"^3.3.0"},{"name":"@types/koa__router","version":"^12.0.0"},{"name":"@types/koa-bodyparser","version":"^4.3.10"},{"name":"@types/koa-qs","version":"^2.0.0"},{"name":"swagger-ui-dist","version":"latest"},{"name":"@types/swagger-ui-dist","version":"latest"}]},{"id":"3633c476-c120-4f9f-893b-b6b03f67b9e9","name":"expressjs","svg":"SiExpress","disabled":true,"categories":["routing"],"title":"Express.js","description":"Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.","logo":"assets/http.svg","metadata":{},"packages":[{"name":"express","version":"latest"},{"name":"body-parser","version":"latest"},{"name":"morgan","version":"latest"},{"name":"cors","version":"latest"},{"name":"@types/express","version":"latest","dev":true},{"name":"@types/body-parser","version":"latest","dev":true},{"name":"@types/cors","version":"latest","dev":true},{"name":"@types/morgan","version":"latest","dev":true}]},{"id":"3e184f8b-d2dc-4592-9507-979d649277f5","visible":true,"name":"google-cloud-storage","categories":["file-storage"],"logo":"assets/cloud-storage.svg","title":"Google Cloud Storage","description":"Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google\'s cloud with advanced security and sharing capabilities.","metadata":{"BUCKET_NAME":{"_comment":"// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won\'t work","displayName":"Bucket Name","type":"string","required":true,"description":"The name of the bucket"},"FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY":{"displayName":"Service Account Key (JSON)","type":"json","description":"The service account key to access the bucket","required":true}},"packages":[{"name":"@google-cloud/storage","version":"7.11.2"},{"name":"formidable","version":"3.5.1"},{"name":"@types/formidable","version":"3.4.5","dev":true},{"name":"mime","version":"4.0.3"}]},{"id":"485654c6-06fc-425e-9ba6-341ec2c9ae07","visible":true,"disabled":true,"name":"mailer-send","categories":["mail"],"logo":"assets/mailer-send.svg","title":"Mailer Send","description":"MailerSend is a transactional email API built by the team behind MailerLite. It\'s a scalable, reliable, and easy-to-use way to send emails via SMTP or API.","metadata":{"MAILER_SEND_API_KEY":{"displayName":"API Key","type":"string","required":true}}},{"id":"ee5d3a3a-501a-4653-914e-d3665760f7bf","visible":true,"name":"resend","main":"resend.ts","categories":["mail"],"logo":"assets/resend.jpeg","title":"Resend","description":"The best API to reach humans instead of spam folders. Build, test, and deliver transactional emails at scale.","metadata":{"RESEND_API_KEY":{"displayName":"API Key","defaultValue":"@process:env.RESEND_API_KEY","type":"string","required":true,"description":"The API key to access the service"}},"packages":[{"name":"resend","version":"1.0.0"}]},{"id":"9c034274-069e-4567-ab33-bab8f31f874c","visible":true,"name":"github","categories":[],"title":"GitHub Webhooks","description":"GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com","metadata":{"WEBHOOK_SECRET":{"displayName":"Webhook Secret","defaultValue":"@process:env.WEBHOOK_SECRET","type":"string","required":true}},"packages":[{"name":"@octokit/webhooks","version":"^13.2.7"}]},{"id":"4320a2a1-bab9-4ca8-bab5-eb56280933c6","visible":true,"name":"node-cron","categories":["schedulers"],"title":"Node Cron","description":"A simple cron-like job scheduler for Node.js","metadata":{},"packages":[{"name":"@types/node-cron","version":"^3.0.11","dev":true},{"name":"node-cron","version":"^3.0.3"}]},{"id":"389d81cd-5b58-4ade-b815-add468c48e37","visible":true,"disabled":true,"name":"ajax","categories":["misc"],"logo":"assets/ajax.png","title":"Ajax","description":"Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.","metadata":{},"svg":"SiAjax"}]');
;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/data/fields.json
const fields_namespaceObject = /*#__PURE__*/JSON.parse('[{"id":"87c7ba43-9c31-4080-9e82-453feb763789","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Short Text","description":"Short Text is perfect for short text fields like name, email, phone, etc.","name":"short-text","icon":"text_format","allowedValidations":[{"name":"string","visible":false},{"name":"mandatory"},{"name":"maxlength"},{"name":"minlength"},{"name":"matches"}],"allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"starts_with","details":{}},{"name":"ends_with","details":{}},{"name":"one_of","details":{}}],"categories":["text"],"primitiveType":"string","metadata":{"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"nativeType":{"visible":false,"displayName":"Native Type","required":true,"type":"string","defaultValue":"varchar"},"length":{"visible":true,"displayName":"Length","type":"number","required":true,"defaultValue":255}},"initialValidation":[{"details":{},"name":"string"}]},{"id":"1e39950b-1af8-4721-a6e0-a304b96431f2","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","displayName":"Email","name":"email","icon":"email","primitiveType":"string","allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"starts_with","details":{}},{"name":"ends_with","details":{}},{"name":"one_of","details":{}}],"allowedValidations":["mandatory","maxlength","minlength","matches"],"categories":["text"],"metadata":{"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"nativeType":{"visible":false,"displayName":"Native Type","required":true,"type":"string","defaultValue":"varchar"},"length":{"visible":true,"displayName":"Length","type":"number","required":true,"defaultValue":255}},"initialValidation":[{"details":{},"name":"string"},{"details":{},"name":"email"}]},{"id":"475a740d-da4d-4d15-8752-b98f42f1565d","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Long Text","description":"Long Text is perfect for long text fields like description, address, etc.","name":"long-text","icon":"keyboard","allowedValidations":[{"name":"string","visible":false},{"name":"mandatory"},{"name":"unique"},{"name":"maxlength"},{"name":"minlength"},{"name":"matches"}],"allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"starts_with","details":{}},{"name":"ends_with","details":{}},{"name":"one_of","details":{}}],"categories":["text"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"type":"string","defaultValue":"TEXT"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"string"}]},{"id":"43d892e7-24e6-4390-b92a-b6d3dcfc75ff","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"Local Tel is a field for local telephone numbers","displayName":"Local Tel","allowedValidations":["mandatory","maxlength","minlength","matches","tel"],"name":"local-tel","icon":"call","categories":["text","phone"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"type":"string","defaultValue":"varchar"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"length":{"visible":true,"displayName":"Length","type":"number","required":true,"defaultValue":12}},"initialValidation":[{"details":{},"name":"tel"}]},{"id":"464944c4-c24d-487d-8480-4591fcee4b40","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"International Tel is a field for international/local telephone numbers","displayName":"International Tel","allowedValidations":["mandatory","maxlength","minlength","matches","tel"],"name":"international-tel","icon":"add_call","categories":["text","phone"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"type":"string","defaultValue":"varchar"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"length":{"visible":true,"displayName":"Length","type":"number","required":true,"defaultValue":12}},"initialValidation":[{"details":{},"name":"mandatory"},{"details":{},"name":"tel"}]},{"id":"d7a0f960-f087-4590-b56f-1db86c7b6bec","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Date","name":"date","icon":"today","allowedValidations":["mandatory","date"],"categories":["date/time"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"required":true,"displayName":"Native Type","type":"string","defaultValue":"date"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"date"}],"allowedOperators":[{"name":"between","details":{}},{"name":"after","details":{}},{"name":"before","details":{}},{"name":"after_on","details":{}},{"name":"before_on","details":{}}]},{"id":"b9c5462e-ee19-4f5b-a919-c022a9f45750","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Time (hh:mm:ss)","name":"time","icon":"alarm","allowedValidations":[{"name":"mandatory"},{"name":"unique"},{"name":"time","required":true}],"categories":["date/time"],"primitiveType":"string","metadata":{"nativeType":{"_comment":"We are relying on the timezone validation to figure out the correct native type","visible":false,"required":false,"displayName":"Timezone","type":"single-select","source":[{"id":"time","displayName":"UTC"},{"id":"timetz","displayName":"Local"}]},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{"value":"time"},"name":"time"}],"allowedOperators":[{"name":"between","details":{}},{"name":"after","details":{}},{"name":"before","details":{}},{"name":"after_on","details":{}},{"name":"before_on","details":{}}]},{"id":"cd4a3d74-1592-4ea7-a289-d7e9e731f50f","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","displayName":"DateTime","name":"datetime","icon":"schedule","allowedValidations":[{"name":"mandatory"},{"name":"unique"},{"name":"isBefore"},{"name":"isAfter"},{"name":"datetime","required":true}],"categories":["date/time"],"primitiveType":"string","metadata":{"nativeType":{"_comment":"We are relying on the timezone validation to figure out the correct native type","visible":false,"displayName":"Timezone","required":false,"type":"single-select","source":[{"id":"timestamp","displayName":"UTC"},{"id":"timestamptz","displayName":"Local"}]},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"mandatory"},{"details":{"value":"date-time"},"name":"datetime"}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"between","details":{}},{"name":"before_on","details":{}},{"name":"after_on","details":{}},{"name":"before","details":{}},{"name":"after","details":{}}]},{"extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Single select","icon":"list","name":"single-select","id":"093a4d33-c4b9-4292-9748-645d6261d66e","categories":["text","select"],"primitiveType":"string","allowedValidations":[{"name":"mandatory"},{"name":"oneof","visible":false}],"allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}}],"initialValidation":[{"name":"oneof","details":{"value":"context.values"}}],"metadata":{"style":{"visible":false,"required":true,"displayName":"Style","type":"single-select","defaultValue":"varchar","source":[{"displayName":"Lookup Table","id":"lookup","visible":false,"_comment":"will seed the lookup table with the values provided in the values property"},{"displayName":"Enum","id":"enum","visible":false},{"displayName":"Varchar","id":"varchar"}]},"values":{"visible":true,"required":false,"displayName":"Values","type":"chips"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}}},{"extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","displayName":"Multi select","icon":"list","categories":["select"],"allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"starts_with","details":{}},{"name":"ends_with","details":{}},{"name":"one_of","details":{}}],"name":"multi-select","id":"be52ff83-c6e6-4d62-9f23-48d2589b01b5","allowedValidations":["mandatory"],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"varchar","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"mandatory"}]},{"id":"feff0537-8b05-432e-9aae-ec6284613c85","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"password","displayName":"Password","icon":"lock","categories":["secret"],"allowedValidations":["mandatory"],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"varchar","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"mandatory"}]},{"id":"6e88c2c4-e479-439e-8d68-91f37c25bd60","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"url","displayName":"URL","icon":"http","categories":["text","special-text"],"allowedValidations":["mandatory","maxlength","minlength","matches","url"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"varchar","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"length":{"visible":false,"displayName":"Length","type":"number","required":true,"defaultValue":2083}},"initialValidation":[{"details":{},"name":"url"}],"allowedOperators":[{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}},{"name":"contains","details":{}},{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"starts_with","details":{}},{"name":"ends_with","details":{}},{"name":"one_of","details":{}}]},{"id":"ea25d8ae-6d69-40c0-898c-6a94b18037fa","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"boolean","icon":"toggle_on","displayName":"Boolean","categories":["boolean"],"allowedValidations":["mandatory"],"primitiveType":"boolean","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"boolean","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"initialValidation":[{"details":{},"name":"boolean"}],"allowedOperators":[{"name":"is","details":{"defaultValue":[null,""]}}]},{"id":"f40d6da3-71b0-4739-9698-946843b431d9","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"percentage","displayName":"Percentage","icon":"percent","primitiveType":"string","categories":["decimal"],"allowedValidations":[{"name":"mandatory","details":{}},{"name":"decimal","details":{}}],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"decimal","type":"number"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false},"precision":{"visible":false,"displayName":"Precision","type":"number","required":false,"defaultValue":5},"scale":{"visible":false,"displayName":"Scale","type":"number","required":false,"defaultValue":2}},"initialValidation":[{"name":"decimal","details":{"value":"2"}}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"id":"e2071017-feab-475e-b6eb-055cd7b4e500","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"price","displayName":"Price","icon":"attach_money","categories":["decimal"],"primitiveType":"string","allowedValidations":[{"name":"mandatory","details":{}},{"name":"decimal","details":{}}],"metadata":{"precision":{"visible":false,"displayName":"Precision","required":true,"defaultValue":"8","type":"number"},"scale":{"visible":false,"displayName":"Scale","required":true,"defaultValue":"3","type":"number"},"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"decimal","type":"number"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"number","required":false}},"initialValidation":[{"name":"decimal","details":{"value":"3"}}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"id":"0cb69328-fc62-422b-a3cc-8e8abb9377b8","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"decimal","icon":"houseboat","primitiveType":"number","displayName":"Decimal","categories":["decimal"],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"decimal","type":"number"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"allowedValidations":["mandatory","decimal"],"initialValidation":[{"details":{},"name":"mandatory"},{"details":{},"name":"decimal"}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"categories":["integer"],"id":"2bd6d573-3f3e-43a7-a68b-5aed9b8c397e","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"integer","icon":"numbers","displayName":"Integer","primitiveType":"number","allowedValidations":["mandatory"],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"integer","type":"number"},"defaultValue":{"visible":false,"displayName":"","type":"number","required":false}},"initialValidation":[{"details":{},"name":"number"},{"details":{},"name":"mandatory"}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"allowedValidations":["mandatory","decimal"],"id":"a7931686-886c-463b-9644-515187ea918e","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"latitude","icon":"my_location","categories":["decimal","location"],"displayName":"Latitude","initialValidation":[{"details":{},"name":"mandatory"},{"details":{},"name":"latitude"}],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"decimal","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"id":"8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"longitude","icon":"my_location","displayName":"Longitude","allowedValidations":["mandatory","decimal"],"categories":["decimal","location"],"initialValidation":[{"details":{},"name":"mandatory"},{"name":"longitude","details":{}}],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"decimal","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"string","required":false}},"allowedOperators":[]},{"id":"6024fb09-a6b2-4400-85bd-cb9bed8e93da","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"json","icon":"json","displayName":"JSON","categories":["json","files"],"allowedValidations":["mandatory"],"primitiveType":"string","metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"jsonb","type":"string"},"defaultValue":{"visible":false,"displayName":"Default Value","type":"object","required":false}},"initialValidation":[{"details":{},"name":"mandatory"},{"details":{},"name":"string"}],"allowedOperators":[]},{"categories":["misc"],"id":"b7da5b61-655a-47f7-a18f-d0e38f3ae02a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"relation","icon":"share","displayName":"Relation","allowedValidations":["mandatory"],"primitiveType":{"transformer":"pascalcase","primitiveType":{"input":"context.relationship","operator":"equal","value":"many-to-one","then":"object","else":"array"},"typeName":{"url":"/tables/:id","binding":{"id":"context.references"},"use":"displayName"},"interface":{"url":"/tables/:id/fields","binding":{"id":"context.references"}}},"metadata":{"references":{"visible":true,"displayName":"Related Table","required":true,"type":"single-select","fieldset":"relation","source":{"url":"/tables"}},"joinSide":{"visible":false,"displayName":"Join side","type":"boolean","required":true,"defaultValue":true},"relationship":{"fieldset":"relation","visible":true,"displayName":"Relationship","type":"single-select","required":true,"source":[{"displayName":"Single","id":"one-to-one"},{"displayName":"Multiple","id":"many-to-one"},{"displayName":"Multiple","id":"many-to-many"}]}},"initialValidation":[]},{"categories":["misc"],"id":"17a0ef1e-b51c-4db3-b3a0-073ad874ddfd","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"relation-id","icon":"share","displayName":"Relation Id","allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}}],"allowedValidations":["mandatory"],"metadata":{"references":{"displayName":"Related entity id","visible":true,"required":true,"type":"string"}},"initialValidation":[]},{"id":"0ac2f72b-c6f0-4fca-91b2-e31467540c48","extensionId":"3e184f8b-d2dc-4592-9507-979d649277f5","description":"File Storage connected to a Google Blob Storage","name":"gs-file","icon":"file_upload","categories":["files","blob-based"],"displayName":"File","primitiveType":"string","extends":"38d8dfa1-fa38-41be-a66f-eb3c847129fe","allowedValidations":[{"name":"mandatory"}],"initialValidation":[]},{"id":"14844d66-d729-4ce6-a269-2b4fb44c8ea9","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"uuid","icon":"raw_on","allowedValidations":["mandatory","uuid"],"categories":["uuid"],"displayName":"UUID","primitiveType":"string","initialValidation":[{"details":{"value":true},"name":"mandatory"},{"details":{},"name":"uuid"}],"metadata":{"nativeType":{"visible":false,"displayName":"Native Type","required":true,"defaultValue":"uuid","type":"string"}},"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"is_empty","details":{"defaultValue":[null,""]}},{"name":"is_not_empty","details":{"defaultValue":[null,""]}}]},{"id":"2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","name":"primary-key-uuid","icon":"branding_watermark","allowedValidations":[],"categories":["key"],"displayName":"Primary Key - UUID","primitiveType":"string","initialValidation":[{"name":"uuid","details":{}},{"name":"mandatory","details":{"value":true}}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"is_empty","details":{}},{"name":"is_not_empty","details":{}}]},{"id":"6c09acb6-e45a-479f-be05-c391dfbced8e","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","visible":false,"name":"primary-key-number","icon":"branding_watermark","allowedValidations":[],"categories":["key"],"displayName":"Primary Key - Auto Increment","primitiveType":"number","initialValidation":[{"details":{},"name":"number"},{"name":"mandatory","details":{"value":true}}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"one_of","details":{}},{"name":"between","details":{}},{"name":"less_than","details":{}},{"name":"more_than","details":{}}]},{"id":"e23bca0c-faa5-473a-a9e6-87d65549fd0c","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"","visible":false,"name":"primary-key-custom","icon":"branding_watermark","allowedValidations":[],"categories":["key"],"displayName":"Primary Key - String","primitiveType":"string","initialValidation":[{"details":{},"name":"string"},{"name":"mandatory","details":{"value":true}}],"allowedOperators":[{"name":"equals","details":{}},{"name":"not_equals","details":{}},{"name":"is_empty","details":{}},{"name":"is_not_empty","details":{}}]}]');
;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/data/operators.json
const operators_namespaceObject = /*#__PURE__*/JSON.parse('[{"id":"e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Equal To","name":"equals","metadata":{}},{"id":"e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Not Equal To","name":"not_equals","metadata":{}},{"id":"f3d3c1af-0066-4884-8533-917ec2c71fd1","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"One Of","name":"one_of","metadata":{}},{"id":"f56f9948-7745-4203-928f-e75c481d13d8","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Between","name":"between","metadata":{}},{"id":"c2e22f65-ce15-42cc-a99f-7e5bca84b69f","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Less Than","name":"less_than","metadata":{}},{"id":"63ec8fb7-357f-403a-b753-6df8a3f25737","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"More Than","name":"more_than","metadata":{}},{"id":"162eedc3-3ace-48c2-8a38-0c1db9058d8a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Contains","name":"contains","metadata":{}},{"id":"60e18406-a4a7-44a4-8b91-2481710fb4e8","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Starts With","name":"starts_with","metadata":{}},{"id":"d3b7f462-d154-4bfa-8645-3f74a958bed6","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Ends With","name":"ends_with","metadata":{}},{"id":"d1a02de2-8928-4517-884d-502bdb8d8409","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Less Than","name":"less_than","metadata":{}},{"id":"fa2b1831-9ceb-4808-984e-1f834a723c56","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Greater Than","name":"greater-than","metadata":{}},{"id":"a2c10af5-c9dd-401c-b28c-59bb48c85345","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is Not Empty","name":"is_not_empty","metadata":{}},{"id":"8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is Empty","name":"is_empty","metadata":{}},{"id":"73963f47-092a-4bf2-a38a-50dca50ca5e6","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Before","name":"before","metadata":{}},{"id":"a830cb78-e9f2-4259-9753-d6259bea1bed","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Before On","name":"before_on","metadata":{}},{"id":"d23be707-a71d-44bd-8b61-9489e84f1a2d","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"After On","name":"after_on","metadata":{}},{"id":"8648374e-f78a-4322-ac67-67467d4fbff5","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"After","name":"after","metadata":{}}]');
;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/data/validations.json
const validations_namespaceObject = /*#__PURE__*/JSON.parse('[{"id":"119aaf66-e16a-40ef-9aaa-22ebec809f1a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Max Length","type":"maxlength","name":"maxlength","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Max length","type":"number"}}},{"id":"4d2dfa41-03b9-418d-82f6-cd90b0002133","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Min Length","type":"minlength","name":"minlength","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Min length","type":"number"}}},{"id":"8f092043-adab-49b8-884d-ef911405c52a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Starts With","type":"startswith","name":"startswith","metadata":{"message":{"displayName":"Message","type":"string"},"pattern":{"displayName":"Pattern","type":"string"}}},{"id":"b78350ef-90f7-45be-bff3-adc4b8a4c661","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Ends With","type":"endswith","name":"endswith","metadata":{"message":{"displayName":"Message","type":"string"},"pattern":{"displayName":"Pattern","type":"string"}}},{"id":"de06ff25-e747-4751-8237-717b6e698e0a","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Contains","type":"contains","name":"contains","metadata":{"message":{"displayName":"Message","type":"string"},"pattern":{"displayName":"Pattern","type":"string"}}},{"id":"951455fe-7772-43b6-8528-aca9760d1969","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is UUID","type":"uuid","name":"uuid","metadata":{"message":{"displayName":"Message","type":"string"},"version":{"displayName":"Version","defaultValue":4,"type":"number"}}},{"id":"bbf3e749-62ac-4f2b-aad3-212c6322173b","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","type":"date","name":"date","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Is Date","type":"single-select","source":[{"id":"true","displayName":"Yes"},{"id":"false","displayName":"No"}]}}},{"id":"735bb87a-d35e-4bb9-b040-2a0a3436e680","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is Boolean","type":"boolean","name":"boolean","metadata":{"message":{"displayName":"Message","type":"string"}}},{"id":"0d8ec049-391d-40a2-a0de-16aeae3d94b7","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Mandatory","type":"mandatory","name":"mandatory","metadata":{"value":{"displayName":"Required","type":"single-select","source":[{"id":"true","displayName":"Yes"},{"id":"false","displayName":"No"}]},"message":{"displayName":"Message","type":"string"}}},{"id":"147e7bf1-d716-4606-9e6b-c007d9663060","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Unique","type":"unique","name":"unique","metadata":{"value":{"displayName":"Unique","type":"single-select","source":[{"id":"true","displayName":"Yes"},{"id":"false","displayName":"No"}]},"message":{"displayName":"Message","type":"string"}}},{"id":"987965d1-0240-42b9-acf6-f378d6f06ea7","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Matches","type":"matches","name":"matches","metadata":{"message":{"type":"string","displayName":"Message"},"value":{"type":"string","displayName":"Pattern"}}},{"id":"53b6704f-f02a-4113-8803-c3fa7d629213","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is Email","type":"email","name":"email","metadata":{"message":{"type":"string","displayName":"Message"},"pattern":{"displayName":"Pattern","type":"string","defaultValue":"^[w-.]+@([w-]+.)+[w-]{2,4}$"}}},{"id":"5190a2b4-d7c0-4fa5-82bd-3bae74c564c8","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Is Arabic","type":"matches","name":"arabic","metadata":{"message":{"type":"string","displayName":"Message"},"value":{"type":"string","displayName":"Pattern","defaultValue":"/[؀-ۿݐ-ݿ]/"}}},{"id":"8d4e9579-775c-4b05-ba13-5703b66ab9be","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Decimal","type":"decimal","name":"decimal","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Decimal Places","type":"number"},"precision":{"required":true,"type":"number"}}},{"id":"0ae68509-73f1-4d49-9497-5cd0429371ce","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Latitude","type":"latitude","name":"latitude","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Is Longitude","type":"string"}}},{"id":"c5215c89-94bf-452d-a552-0e08e1a21b8c","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Longitude","type":"longitude","name":"longitude","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Is Longitude","type":"string"}}},{"id":"6f6eea02-58b9-4863-8d8d-63f28bd46dba","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Number","type":"number","name":"number","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Is Number","type":"single-select","_comment":"what about negative and positive","source":[{"id":"true","displayName":"Yes"},{"id":"false","displayName":"No"}]}}},{"id":"237c6189-2860-46a7-a329-281303b1d128","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"String","type":"string","name":"string","metadata":{"message":{"displayName":"Message","type":"string"}}},{"id":"d733d906-3682-4c39-919d-a318b44c5b48","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Tel","type":"tel","name":"tel","metadata":{"message":{"displayName":"Message","type":"string"}}},{"id":"3b5031c1-7ac4-40dd-bdad-156a4da5aa54","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"Url","type":"url","name":"url","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"visible":false,"displayName":"Pattern","type":"string"}}},{"id":"7ecd51dc-b396-422e-a180-a34a00aee7fe","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","displayName":"IP","type":"ip","name":"ip","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Version","type":"single-select","source":[{"id":"ipv4","displayName":"ipv4"},{"id":"ipv6","displayName":"ipv6"}]}}},{"id":"f8603858-4ddc-4ff6-972f-12e3030e3d73","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"isBefore","displayName":"Is Before","type":"isBefore","metadata":{"value":{"type":"datetime","displayName":"Is Before"},"message":{"type":"string","displayName":"Message"}}},{"id":"ed36a909-e554-4125-b916-bf281fcdfb37","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"isAfter","displayName":"Is After","type":"isAfter","metadata":{"value":{"type":"datetime","displayName":"Is After"},"message":{"type":"string","displayName":"Message","visible":false}}},{"id":"d8b0f376-9d34-4ac2-92ad-0e054d88d372","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"isBetween","displayName":"Is Between","type":"isBetween","metadata":{"message":{"type":"string","displayName":"Message"},"value":{"type":"datetime-range","displayName":"Is Between"}}},{"id":"8c8636a4-480a-4b29-bfa0-80a1aae9d913","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"datetime","type":"datetime","metadata":{"value":{"displayName":"Local","type":"single-select","source":[{"id":"date-time","displayName":"Yes"},{"id":"iso-date-time","displayName":"No"}]},"message":{"type":"string","displayName":"Message"}}},{"id":"c6c48353-3095-47cd-8060-a60400972720","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","name":"time","type":"time","metadata":{"value":{"displayName":"Local","type":"single-select","source":[{"id":"time","displayName":"Yes"},{"id":"iso-time","displayName":"No"}]},"message":{"type":"string","displayName":"Message"}}},{"id":"90ff5d13-4846-4c57-9f7b-5e9730582d39","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"Min","displayName":"Min","type":"min","name":"min","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Min","type":"number"}}},{"id":"4c86e4c6-36e2-470d-be82-ae6c65809fa7","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"Max","displayName":"Max","type":"max","name":"max","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Max","type":"number"}}},{"id":"b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b","extensionId":"931799e0-12e0-45d7-86a3-6a46f874576b","description":"Oneof","displayName":"Oneof","type":"oneof","name":"oneof","metadata":{"message":{"displayName":"Message","type":"string"},"value":{"displayName":"Enum","type":"string"}}}]');
;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/devkit.ts








let DevKit = class DevKit {
    typesResolverMap = {
        date: 'Date',
    };
    assignDefaults(metadata, details) {
        Object.entries(metadata ?? {}).forEach(([name, config]) => {
            // only undefined because null might be use to clear the value
            if (details[name] === undefined && config.defaultValue !== undefined) {
                details[name] = config.defaultValue;
            }
        });
        return details;
    }
    getDeps() {
        const exts = this.extensions();
        const dependencies = exts.map((it) => it.packages ?? []).flat();
        const possibleDeps = [
            {
                name: 'discord.js',
                version: '^14.15.3',
                dev: false,
            },
        ];
        return [...dependencies, ...possibleDeps].reduce((acc, it) => {
            return {
                ...acc,
                [it.name]: it.version,
            };
        }, {});
    }
    async getSourceActionByName(name) {
        if (isNullOrUndefined(name)) {
            throw new Error('getSourceActionByName:name is required. received: ' + name);
        }
        const action = (await this.actions()).find((it) => it.name === name);
        if (!action) {
            throw new Error(`Action with name ${name} not found`);
        }
        return action;
    }
    getSourceActionById(id) {
        const action = this.actions().find((it) => it.id === id);
        if (!action) {
            throw new Error(`Action with id ${id} not found`);
        }
        return action;
    }
    getExtensionActions(id) {
        const extension = this.extensions().find((it) => it.id === id);
        if (!extension) {
            throw new Error(`Extension with id ${id} not found`);
        }
        return actions_namespaceObject.filter((it) => it.extensionId === id);
    }
    actions() {
        return actions_namespaceObject;
    }
    async getExtensionTriggers(id) {
        const extension = this.extensions().find((it) => it.id === id);
        if (!extension) {
            throw new Error(`Extension with id ${id} not found`);
        }
        return (await this.triggers()).filter((it) => it.extensionId === id);
    }
    getExtensionById(id) {
        const item = this.extensions().find((it) => it.id === id);
        if (!item) {
            throw new Error(`Extension with id ${id} not found`);
        }
        return item;
    }
    async triggers() {
        return (await this.actions()).filter((it) => it.type === 'trigger');
    }
    extensions() {
        return extensions_namespaceObject;
    }
    getExtensionByName(name) {
        const item = this.extensions().find((it) => it.name === name);
        if (!item) {
            throw new Error(`Extension with name ${name} not found`);
        }
        return item;
    }
    toJson(obj) {
        return JSON.stringify(obj, null, 2);
    }
    async getTriggerById(id) {
        const trigger = (await this.triggers()).find((it) => it.id === id);
        if (!trigger) {
            throw new Error(`Trigger with id ${id} not found`);
        }
        return trigger;
    }
    async getTriggerByName(name) {
        const trigger = (await this.actions()).find((it) => it.type === 'trigger' && it.name === name);
        if (!trigger) {
            throw new Error(`Trigger with name ${name} not found`);
        }
        return trigger;
    }
    async getValidationById(id) {
        const validation = (await this.validations()).find((it) => it.id === id);
        if (!validation) {
            throw new Error(`Validation with id ${id} not found`);
        }
        return validation;
    }
    async getValidationsByIds(ids) {
        const validations = await this.validations();
        const list = [];
        for (const id of ids) {
            const validation = validations.find((it) => it.id === id);
            if (!validation) {
                throw new Error(`Validation with id ${id} not found`);
            }
            list.push(validation);
        }
        return list;
    }
    async getValidationsByNames(names) {
        const validations = await this.validations();
        const list = [];
        for (const name of names) {
            const validation = validations.find((it) => it.name === name);
            if (!validation) {
                throw new Error(`Validation with name ${name} not found`);
            }
            list.push(validation);
        }
        return list;
    }
    async getValidationByName(name) {
        const validation = await this.validations().find((a) => a.name === name);
        if (!validation) {
            throw new Error(`Validation with name ${name} not found`);
        }
        return validation;
    }
    async getSourceFieldById(id) {
        const field = (await this.getFieldsByExtension()).find((it) => it.id === id);
        if (!field) {
            throw new Error(`Field with id ${id} not found`);
        }
        return field;
    }
    async getSourceFieldByName(name) {
        const field = (await this.getFieldsByExtension()).find((it) => it.name === name);
        if (!field) {
            throw new Error(`Field with name ${name} not found`);
        }
        return field;
    }
    async getFieldsByExtension() {
        return await this.fields();
    }
    fields() {
        return fields_namespaceObject;
    }
    validations() {
        return validations_namespaceObject;
    }
    operators() {
        return operators_namespaceObject;
    }
    substring(input, sub) {
        const index = input.indexOf(sub);
        if (index === -1) {
            return input;
        }
        return input.slice(sub.length);
    }
    toLiteralObject(obj) {
        if (Array.isArray(obj)) {
            return toLiteralObject(Object.fromEntries(obj), (value) => {
                try {
                    // @ts-ignore
                    if ('value' in value) {
                        return value.value;
                    }
                }
                catch (e) {
                    return value;
                }
            });
        }
        return toLiteralObject(obj, (value) => {
            try {
                // @ts-ignore
                if ('value' in value) {
                    return value.value;
                }
            }
            catch (e) {
                return value;
            }
        });
    }
};
DevKit = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Singleton,
    })
], DevKit);


;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/project-config.ts


let ProjectConfig = class ProjectConfig {
    #config = {
        basePath: './src',
        features: './src/features',
        tsConfigFilePath: './tsconfig.json',
    };
    getConfig() {
        return this.#config;
    }
    updateConfig(config) {
        const current = this.getConfig();
        this.#config = {
            ...current,
            ...config,
        };
    }
};
ProjectConfig = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Singleton,
    })
], ProjectConfig);


;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/lib/project-fs.ts
var project_fs_a;





let ProjectFS = class ProjectFS {
    _projectConfig;
    constructor(_projectConfig) {
        this._projectConfig = _projectConfig;
    }
    routersGlob() {
        return this._projectConfig.getConfig().features + '/**/*.router.ts';
    }
    listenersGlob() {
        return this._projectConfig.getConfig().features + '/**/*.github.ts';
    }
    cronsGlob() {
        return this._projectConfig.getConfig().features + '/**/*.cron.ts';
    }
    entitiesGlob() {
        return this._projectConfig.getConfig().features + '/**/*.entity.ts';
    }
    makeCoreImportSpecifier = (importPath) => {
        return (0,external_path_.join)('#{relative}', this._projectConfig.getConfig().basePath, importPath);
    };
    makeEntityImportSpecifier = (tableName) => {
        return (0,external_path_.join)('#{entity}', (0,external_stringcase_.pascalcase)(tableName));
    };
    makeFeaturePath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().features, fileName);
    makeFeatureFile = (featureName, fileName) => (0,external_path_.join)(this._projectConfig.getConfig().features, (0,external_stringcase_.spinalcase)(featureName), fileName);
    makeCorePath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().basePath, 'core', fileName);
    makeIdentityPath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().basePath, 'identity', fileName);
    makeSrcPath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().basePath, fileName);
    makeWorkspacePath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().basePath, '../', 
    /** We need this to work with new january cli */ '../', fileName);
    makeRootPath = (fileName) => (0,external_path_.join)(this._projectConfig.getConfig().basePath, '../', fileName);
    makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(featureName, (0,external_path_.join)((0,external_stringcase_.spinalcase)(tagName), `${(0,external_stringcase_.spinalcase)(commandName)}.command.ts`));
    makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, (0,external_path_.join)((0,external_stringcase_.spinalcase)(tagName), `index.ts`));
    makeControllerPath = (featureName, suffix) => this.makeFeatureFile(featureName, `${(0,external_stringcase_.spinalcase)(featureName)}.${(0,external_stringcase_.dotcase)(`${suffix} ts`)}`);
    makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(featureName, (0,external_path_.join)('routes', `${(0,external_stringcase_.spinalcase)(routeName)}.${(0,external_stringcase_.dotcase)(`route ts`)}`));
    makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(featureName, (0,external_path_.join)('listeners', `${(0,external_stringcase_.spinalcase)(routeName)}.${(0,external_stringcase_.dotcase)(`listener ts`)}`));
    makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(featureName, (0,external_path_.join)('jobs', `${(0,external_stringcase_.spinalcase)(routeName)}.${(0,external_stringcase_.dotcase)(`job ts`)}`));
    makeEntityPath = (featureName, tableName, suffix) => (0,external_path_.join)(this._projectConfig.getConfig().features, (0,external_stringcase_.spinalcase)(featureName), `${(0,external_stringcase_.spinalcase)(tableName)}.${(0,external_stringcase_.dotcase)(`${suffix} ts`)}`);
    makeQueryPath = (tableName, queryName) => (0,external_path_.join)(this._projectConfig.getConfig().features, (0,external_stringcase_.spinalcase)(tableName), 'queries', `${(0,external_stringcase_.spinalcase)(queryName)}.query.ts`);
    makeExportPath = (workflowName, suffix) => `./${(0,external_stringcase_.spinalcase)(workflowName)}.${suffix}`;
};
ProjectFS = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Singleton,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (project_fs_a = typeof ProjectConfig !== "undefined" && ProjectConfig) === "function" ? project_fs_a : Object])
], ProjectFS);

const makeEntityImportSpecifier = (tableName) => {
    return (0,external_path_.join)('#{entity}', (0,external_stringcase_.pascalcase)(tableName));
};

;// CONCATENATED MODULE: ../compiler/sdk/devkit/src/index.ts




;// CONCATENATED MODULE: ../compiler/sdk/dynamic-source/src/lib/dynamic-source.ts
var dynamic_source_a;




const DYNAMIC_SOURCE_MAPPER = new external_tiny_injector_.InjectionToken(`a token to hold dynamic source mapper`);
let DynamicSource = class DynamicSource {
    _devKit;
    _mapper;
    constructor(_devKit, _mapper) {
        this._devKit = _devKit;
        this._mapper = _mapper;
    }
    #get(featureId, url, ...args) {
        const fetcher = this._mapper(featureId);
        if (!fetcher) {
            throw new Error(`No mapping found ${url}`);
        }
        const obs = fetcher[url];
        if (!obs) {
            throw new Error(`No matching found for url ${url}`);
        }
        if (typeof obs === 'function') {
            return obs(...args);
        }
        return obs;
    }
    async resolveSource(featureId, source, details) {
        let _source = source;
        if (isCondition(source)) {
            _source = applyCondition(source, details);
        }
        if (!isResolvable(_source)) {
            return _source;
        }
        if (Array.isArray(_source)) {
            return _source;
        }
        const { url, params } = buildUrl(_source.url, details, _source.binding ?? {});
        if (!url)
            return [];
        return this.#get(featureId, url, ...params);
    }
    async resolvePrimitiveType(featureId, primitiveType, context, resolver) {
        if (!primitiveType) {
            return '';
        }
        if (typeof primitiveType === 'string') {
            return this._devKit.typesResolverMap[primitiveType] || primitiveType;
        }
        if (isCondition(primitiveType)) {
            return applyCondition(primitiveType, context);
        }
        const maybeThisWillWork = resolver(primitiveType);
        if (isCondition(maybeThisWillWork)) {
            return applyCondition(maybeThisWillWork, context);
        }
        return this.resolveSource(featureId, maybeThisWillWork, context);
    }
};
DynamicSource = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(1, (0,external_tiny_injector_.Inject)(DYNAMIC_SOURCE_MAPPER)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (dynamic_source_a = typeof DevKit !== "undefined" && DevKit) === "function" ? dynamic_source_a : Object, Function])
], DynamicSource);


;// CONCATENATED MODULE: ../compiler/sdk/dynamic-source/src/index.ts


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-action-to-workflow.command.ts
var add_action_to_workflow_command_a;





let AddActionToWorkflowCommand = class AddActionToWorkflowCommand extends tiny_mediatr_.IRequest {
    // FIXME: shoudn't be here
    featureId;
    workflowId;
    displayName;
    sourceId;
    details;
    outputName;
    id;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)()
    // FIXME: shoudn't be here
    ,
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsString)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (add_action_to_workflow_command_a = typeof Record !== "undefined" && Record) === "function" ? add_action_to_workflow_command_a : Object)
], AddActionToWorkflowCommand.prototype, "details", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsString)(),
    (0,external_class_validator_.IsOptional)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "outputName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddActionToWorkflowCommand.prototype, "id", void 0);
AddActionToWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddActionToWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-feature.command.ts





let AddFeatureCommand = class AddFeatureCommand extends tiny_mediatr_.IRequest {
    id;
    displayName;
    policies;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFeatureCommand.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFeatureCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Array)
], AddFeatureCommand.prototype, "policies", void 0);
AddFeatureCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddFeatureCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-field.command.ts
var add_field_command_a;





let AddFieldCommand = class AddFieldCommand extends tiny_mediatr_.IRequest {
    // @AutoMap()
    // @IsOptional()
    // @IsBoolean()
    // // FIXME: we might introduce new Part named Accessibility or something similar
    // // to mange field visibility and updateability
    // can_be_updated?: boolean;
    displayName;
    sourceId;
    tableId;
    details;
    id;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFieldCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFieldCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFieldCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", typeof (add_field_command_a = typeof Record !== "undefined" && Record) === "function" ? add_field_command_a : Object)
], AddFieldCommand.prototype, "details", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddFieldCommand.prototype, "id", void 0);
AddFieldCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddFieldCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-primary-field.command.ts





let AddPrimaryFieldCommand = class AddPrimaryFieldCommand extends tiny_mediatr_.IRequest {
    displayName;
    tableId;
    sourceId;
    details = {};
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddPrimaryFieldCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddPrimaryFieldCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddPrimaryFieldCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Object)
], AddPrimaryFieldCommand.prototype, "details", void 0);
AddPrimaryFieldCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddPrimaryFieldCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-query.command.ts
var add_query_command_a;





let AddQueryCommand = class AddQueryCommand extends tiny_mediatr_.IRequest {
    single;
    localizable;
    condition;
    //
    displayName;
    featureId;
    sourceId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsBoolean)(),
    (0,external_tslib_.__metadata)("design:type", Boolean)
], AddQueryCommand.prototype, "single", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsBoolean)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", Boolean)
], AddQueryCommand.prototype, "localizable", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Object)
], AddQueryCommand.prototype, "condition", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,external_tslib_.__metadata)("design:type", String)
], AddQueryCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddQueryCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddQueryCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (add_query_command_a = typeof Record !== "undefined" && Record) === "function" ? add_query_command_a : Object)
], AddQueryCommand.prototype, "details", void 0);
AddQueryCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddQueryCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-table.command.ts
var add_table_command_a;





let AddTableCommand = class AddTableCommand extends tiny_mediatr_.IRequest {
    id;
    displayName;
    featureId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTableCommand.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTableCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTableCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", typeof (add_table_command_a = typeof Record !== "undefined" && Record) === "function" ? add_table_command_a : Object)
], AddTableCommand.prototype, "details", void 0);
AddTableCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddTableCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-tag.command.ts





let AddTagCommand = class AddTagCommand extends tiny_mediatr_.IRequest {
    displayName;
    featureId;
    id;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTagCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTagCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddTagCommand.prototype, "id", void 0);
AddTagCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddTagCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/add-workflow.command.ts
var add_workflow_command_a;





let AddWorkflowCommand = class AddWorkflowCommand extends tiny_mediatr_.IRequest {
    displayName;
    featureId;
    sourceId;
    details;
    id;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,external_tslib_.__metadata)("design:type", String)
], AddWorkflowCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddWorkflowCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddWorkflowCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (add_workflow_command_a = typeof Record !== "undefined" && Record) === "function" ? add_workflow_command_a : Object)
], AddWorkflowCommand.prototype, "details", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_class_validator_.IsOptional)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AddWorkflowCommand.prototype, "id", void 0);
AddWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AddWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/adjust-field-validation.command.ts





let AdjustFieldValidationCommand = class AdjustFieldValidationCommand extends tiny_mediatr_.IRequest {
    validations;
    // FIXME: we shouldn't need to specify the table id here
    tableId;
    fieldId;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => [FieldValidation]),
    (0,external_tslib_.__metadata)("design:type", Array)
], AdjustFieldValidationCommand.prototype, "validations", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)()
    // FIXME: we shouldn't need to specify the table id here
    ,
    (0,external_tslib_.__metadata)("design:type", String)
], AdjustFieldValidationCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AdjustFieldValidationCommand.prototype, "fieldId", void 0);
AdjustFieldValidationCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AdjustFieldValidationCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/append-field-to-workflow.command.ts





let AppendFieldToWorkflowCommand = class AppendFieldToWorkflowCommand extends tiny_mediatr_.IRequest {
    displayName;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsString)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AppendFieldToWorkflowCommand.prototype, "displayName", void 0);
AppendFieldToWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AppendFieldToWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/archive-table.command.ts





let ArchiveTableCommand = class ArchiveTableCommand extends tiny_mediatr_.IRequest {
    tableId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ArchiveTableCommand.prototype, "tableId", void 0);
ArchiveTableCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], ArchiveTableCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/assign-policy-to-workflow.command.ts





let AssignPolicyToWorkflowCommand = class AssignPolicyToWorkflowCommand extends tiny_mediatr_.IRequest {
    featureId;
    workflowId;
    policyId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignPolicyToWorkflowCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignPolicyToWorkflowCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignPolicyToWorkflowCommand.prototype, "policyId", void 0);
AssignPolicyToWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AssignPolicyToWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/assign-tag-to-workflow.command.ts





let AssignTagToWorkflowCommand = class AssignTagToWorkflowCommand extends tiny_mediatr_.IRequest {
    featureId;
    workflowId;
    tagId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignTagToWorkflowCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignTagToWorkflowCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], AssignTagToWorkflowCommand.prototype, "tagId", void 0);
AssignTagToWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], AssignTagToWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/change_action_name.ts





let ChangeActionNameCommand = class ChangeActionNameCommand extends tiny_mediatr_.IRequest {
    id;
    workflowId;
    displayName;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeActionNameCommand.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeActionNameCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeActionNameCommand.prototype, "displayName", void 0);
ChangeActionNameCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], ChangeActionNameCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/change_workflow_name.ts





let ChangeWorkflowNameCommand = class ChangeWorkflowNameCommand extends tiny_mediatr_.IRequest {
    workflowId;
    displayName;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeWorkflowNameCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeWorkflowNameCommand.prototype, "displayName", void 0);
ChangeWorkflowNameCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], ChangeWorkflowNameCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/change_workflow_trigger.ts
var change_workflow_trigger_a;





let ChangeWorkflowTriggerCommand = class ChangeWorkflowTriggerCommand extends tiny_mediatr_.IRequest {
    featureId;
    workflowId;
    sourceId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeWorkflowTriggerCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeWorkflowTriggerCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ChangeWorkflowTriggerCommand.prototype, "sourceId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (change_workflow_trigger_a = typeof Record !== "undefined" && Record) === "function" ? change_workflow_trigger_a : Object)
], ChangeWorkflowTriggerCommand.prototype, "details", void 0);
ChangeWorkflowTriggerCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], ChangeWorkflowTriggerCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/connect-action.command.ts





let ConnectAction = class ConnectAction extends tiny_mediatr_.IRequest {
    featureId;
    workflowId;
    id;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ConnectAction.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ConnectAction.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], ConnectAction.prototype, "id", void 0);
ConnectAction = (0,external_tslib_.__decorate)([
    AutoMapHost()
], ConnectAction);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/create-table-index.command.ts





let CreateTableIndexCommand = class CreateTableIndexCommand extends tiny_mediatr_.IRequest {
    tableId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], CreateTableIndexCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", Object)
], CreateTableIndexCommand.prototype, "details", void 0);
CreateTableIndexCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], CreateTableIndexCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/delete-feature.command.ts





let DeleteFeatureCommand = class DeleteFeatureCommand extends tiny_mediatr_.IRequest {
    displayName;
    failSafe;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.Matches)(/^[A-Za-z_ ]+$/),
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DeleteFeatureCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsBoolean)(),
    (0,external_tslib_.__metadata)("design:type", Boolean)
], DeleteFeatureCommand.prototype, "failSafe", void 0);
DeleteFeatureCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], DeleteFeatureCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/delete-field.command.ts



class DeleteFieldCommand {
    displayName;
    tableId;
    tableName;
}
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsString)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DeleteFieldCommand.prototype, "displayName", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsString)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DeleteFieldCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsString)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DeleteFieldCommand.prototype, "tableName", void 0);

;// CONCATENATED MODULE: ../api/table/commands/src/lib/delocalize_field.command.ts





let DelocalizeFieldCommand = class DelocalizeFieldCommand extends tiny_mediatr_.IRequest {
    tableId;
    fieldId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DelocalizeFieldCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DelocalizeFieldCommand.prototype, "fieldId", void 0);
DelocalizeFieldCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], DelocalizeFieldCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/delocalize_query.command.ts





let DelocalizeQueryCommand = class DelocalizeQueryCommand extends tiny_mediatr_.IRequest {
    featureId;
    queryId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DelocalizeQueryCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], DelocalizeQueryCommand.prototype, "queryId", void 0);
DelocalizeQueryCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], DelocalizeQueryCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/localize_field.command.ts





let LocalizeFieldCommand = class LocalizeFieldCommand extends tiny_mediatr_.IRequest {
    tableId;
    fieldId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], LocalizeFieldCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], LocalizeFieldCommand.prototype, "fieldId", void 0);
LocalizeFieldCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], LocalizeFieldCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/localize_query.command.ts





let LocalizeQueryCommand = class LocalizeQueryCommand extends tiny_mediatr_.IRequest {
    featureId;
    queryId;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], LocalizeQueryCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], LocalizeQueryCommand.prototype, "queryId", void 0);
LocalizeQueryCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], LocalizeQueryCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/mutate_query_condition.command.ts





let MutateQueryConditionCommand = class MutateQueryConditionCommand extends tiny_mediatr_.IRequest {
    featureId;
    queryId;
    condition;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], MutateQueryConditionCommand.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], MutateQueryConditionCommand.prototype, "queryId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", Object)
], MutateQueryConditionCommand.prototype, "condition", void 0);
MutateQueryConditionCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], MutateQueryConditionCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/patch-workflow-action-details.ts
var patch_workflow_action_details_a;





let PatchWorkflowActionDetails = class PatchWorkflowActionDetails extends tiny_mediatr_.IRequest {
    featureId;
    workflowId;
    id;
    details;
};
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsUUID)(),
    (0,classes_.AutoMap)(),
    (0,external_tslib_.__metadata)("design:type", String)
], PatchWorkflowActionDetails.prototype, "featureId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], PatchWorkflowActionDetails.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], PatchWorkflowActionDetails.prototype, "id", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (patch_workflow_action_details_a = typeof Record !== "undefined" && Record) === "function" ? patch_workflow_action_details_a : Object)
], PatchWorkflowActionDetails.prototype, "details", void 0);
PatchWorkflowActionDetails = (0,external_tslib_.__decorate)([
    AutoMapHost()
], PatchWorkflowActionDetails);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/patch-workflow-details.ts
var patch_workflow_details_a;





let PatchWorkflowDetails = class PatchWorkflowDetails extends tiny_mediatr_.IRequest {
    workflowId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], PatchWorkflowDetails.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object),
    (0,external_tslib_.__metadata)("design:type", typeof (patch_workflow_details_a = typeof Record !== "undefined" && Record) === "function" ? patch_workflow_details_a : Object)
], PatchWorkflowDetails.prototype, "details", void 0);
PatchWorkflowDetails = (0,external_tslib_.__decorate)([
    AutoMapHost()
], PatchWorkflowDetails);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/patch-workflow-output-details.ts
var patch_workflow_output_details_a;





let PatchWorkflowOutputDetailsCommand = class PatchWorkflowOutputDetailsCommand extends tiny_mediatr_.IRequest {
    workflowId;
    // FIXME: this should be typed
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], PatchWorkflowOutputDetailsCommand.prototype, "workflowId", void 0);
(0,external_tslib_.__decorate)([
    (0,external_class_validator_.IsNotEmpty)(),
    (0,classes_.AutoMap)(() => Object)
    // FIXME: this should be typed
    ,
    (0,external_tslib_.__metadata)("design:type", typeof (patch_workflow_output_details_a = typeof Record !== "undefined" && Record) === "function" ? patch_workflow_output_details_a : Object)
], PatchWorkflowOutputDetailsCommand.prototype, "details", void 0);
PatchWorkflowOutputDetailsCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], PatchWorkflowOutputDetailsCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/remove-workflow.command.ts





let RemoveWorkflowCommand = class RemoveWorkflowCommand extends tiny_mediatr_.IRequest {
    workflowId;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], RemoveWorkflowCommand.prototype, "workflowId", void 0);
RemoveWorkflowCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], RemoveWorkflowCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/lib/update-field-details.command.ts
var update_field_details_command_a;





let UpdateFieldDetailsCommand = class UpdateFieldDetailsCommand extends tiny_mediatr_.IRequest {
    fieldId;
    tableId;
    details;
};
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], UpdateFieldDetailsCommand.prototype, "fieldId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(),
    (0,external_class_validator_.IsUUID)(),
    (0,external_tslib_.__metadata)("design:type", String)
], UpdateFieldDetailsCommand.prototype, "tableId", void 0);
(0,external_tslib_.__decorate)([
    (0,classes_.AutoMap)(() => Object),
    (0,external_class_validator_.IsNotEmpty)(),
    (0,external_tslib_.__metadata)("design:type", typeof (update_field_details_command_a = typeof Record !== "undefined" && Record) === "function" ? update_field_details_command_a : Object)
], UpdateFieldDetailsCommand.prototype, "details", void 0);
UpdateFieldDetailsCommand = (0,external_tslib_.__decorate)([
    AutoMapHost()
], UpdateFieldDetailsCommand);


;// CONCATENATED MODULE: ../api/table/commands/src/index.ts































;// CONCATENATED MODULE: ../compiler/sdk/platform/src/lib/features.sdk.ts
var features_sdk_a, features_sdk_b;





let Features = class Features {
    _mediator;
    _context;
    constructor(_mediator, _context) {
        this._mediator = _mediator;
        this._context = _context;
    }
    list() {
        return this._context.getExtra('changes').features;
    }
    async get(id) {
        const feature = this._context
            .getExtra('changes')
            .features.find((it) => it.id === id);
        if (!feature) {
            throw new Error(`Feature ${id} not found`);
        }
        return feature;
    }
    async addFeature(command) {
        return this._mediator.send(mapper.map(command, AddFeatureCommand));
    }
    async addTag(command) {
        return this._mediator.send(mapper.map(command, AddTagCommand));
    }
};
Features = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(1, (0,external_tiny_injector_.Inject)(external_tiny_injector_.Context)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (features_sdk_a = typeof tiny_mediatr_.Mediator !== "undefined" && tiny_mediatr_.Mediator) === "function" ? features_sdk_a : Object, typeof (features_sdk_b = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? features_sdk_b : Object])
], Features);


;// CONCATENATED MODULE: ../compiler/sdk/platform/src/lib/tables.sdk.ts
var tables_sdk_a, tables_sdk_b, tables_sdk_c, _d;







let Tables = class Tables {
    _mediator;
    _dynamicSource;
    _devKit;
    _context;
    constructor(_mediator, _dynamicSource, _devKit, _context) {
        this._mediator = _mediator;
        this._dynamicSource = _dynamicSource;
        this._devKit = _devKit;
        this._context = _context;
    }
    async get(tableId) {
        const table = this._context
            .getExtra('changes')
            .tables.find((it) => it.id === tableId);
        if (!table) {
            throw new Error(`Table ${tableId} not found`);
        }
        console.log({ table, tableId });
        return table;
    }
    async addTable(command) {
        return this._mediator.send(mapper.map(command, AddTableCommand));
    }
    async addField(command) {
        return this._mediator.send(mapper.map(command, AddFieldCommand));
    }
    async updateFieldDetails(command) {
        return this._mediator.send(mapper.map(command, UpdateFieldDetailsCommand));
    }
    async getTableField(tableId, id) {
        const table = await this.get(tableId);
        const field = table.fields.find((it) => it.id === id);
        if (!field) {
            throw new Error(`Field ${id} not found`);
        }
        return field;
    }
    async resolvePrimitiveType(field, sourceField) {
        sourceField ??= await this._devKit.getSourceFieldById(field.sourceId);
        return await this._dynamicSource.resolvePrimitiveType(undefined, sourceField.primitiveType, {
            context: field.details,
            self: field,
        }, (primitiveType) => primitiveType.primitiveType);
    }
    async adjustFieldValidationCommand(command) {
        return this._mediator.send(mapper.map(command, AdjustFieldValidationCommand));
    }
};
Tables = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(3, (0,external_tiny_injector_.Inject)(external_tiny_injector_.Context)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (tables_sdk_a = typeof tiny_mediatr_.Mediator !== "undefined" && tiny_mediatr_.Mediator) === "function" ? tables_sdk_a : Object, typeof (tables_sdk_b = typeof DynamicSource !== "undefined" && DynamicSource) === "function" ? tables_sdk_b : Object, typeof (tables_sdk_c = typeof DevKit !== "undefined" && DevKit) === "function" ? tables_sdk_c : Object, typeof (_d = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? _d : Object])
], Tables);


;// CONCATENATED MODULE: ../compiler/sdk/platform/src/lib/workflows.sdk.ts
var workflows_sdk_a, workflows_sdk_b;





let Workflows = class Workflows {
    _mediator;
    _context;
    constructor(_mediator, _context) {
        this._mediator = _mediator;
        this._context = _context;
    }
    async list(featureId) {
        return this._context
            .getExtra('changes')
            .workflows.filter((it) => it.featureId === featureId);
    }
    async get(workflowId) {
        return this._context
            .getExtra('changes')
            .workflows.find((it) => it.id === workflowId);
    }
    async getAction(workflowId, sourceId) {
        const workflow = await this.get(workflowId);
        if (!workflow) {
            throw new Error(`Workflow ${workflowId} not found`);
        }
        const action = workflow.actions.find((it) => it.id === sourceId);
        if (!action) {
            throw new Error(`Action ${sourceId} not found`);
        }
        return action;
    }
    addAction(command) {
        return this._mediator.send(mapper.map(command, AddActionToWorkflowCommand));
    }
    connectAction(command) {
        return this._mediator.send(mapper.map(command, ConnectAction));
    }
    async addWorkflow(command, tagId) {
        const workflowId = await this._mediator.send(mapper.map(command, AddWorkflowCommand));
        if (tagId) {
            await this.assignTagToWorkflow({
                workflowId,
                tagId,
                featureId: command.featureId,
            });
        }
        return workflowId;
    }
    async changeWorkflowTrigger(command) {
        const workflowId = await this._mediator.send(mapper.map(command, ChangeWorkflowTriggerCommand));
        return workflowId;
    }
    assignTagToWorkflow(command) {
        return this._mediator.send(mapper.map(command, AssignTagToWorkflowCommand));
    }
    patchWorkflowActionDetails(command) {
        return this._mediator.send(mapper.map(command, PatchWorkflowActionDetails));
    }
    patchWorkflowDetails(command) {
        return this._mediator.send(mapper.map(command, PatchWorkflowDetails));
    }
    patchWorkflowOutputDetails(command) {
        return this._mediator.send(mapper.map(command, PatchWorkflowOutputDetailsCommand));
    }
    async getWorkflowAction(workflowId, sourceId) {
        const workflow = await this.get(workflowId);
        if (!workflow) {
            throw new Error(`Workflow ${workflowId} not found`);
        }
        const action = workflow.actions.find((it) => it.id === sourceId);
        if (!action) {
            throw new Error(`Action ${sourceId} not found`);
        }
        return action;
    }
    async getWorkflowsActions(featureId) {
        const workflows = await this.list(featureId);
        return workflows.map((workflow) => workflow.actions ?? []).flat();
    }
};
Workflows = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(1, (0,external_tiny_injector_.Inject)(external_tiny_injector_.Context)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (workflows_sdk_a = typeof tiny_mediatr_.Mediator !== "undefined" && tiny_mediatr_.Mediator) === "function" ? workflows_sdk_a : Object, typeof (workflows_sdk_b = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? workflows_sdk_b : Object])
], Workflows);


;// CONCATENATED MODULE: ../compiler/sdk/platform/src/lib/sdk.ts
var sdk_a, sdk_b, sdk_c, sdk_d;





let Sdk = class Sdk {
    tables;
    features;
    workflows;
    _context;
    constructor(tables, features, workflows, _context) {
        this.tables = tables;
        this.features = features;
        this.workflows = workflows;
        this._context = _context;
    }
    getInstalledExtensions() {
        return this._context.getExtra('changes').extensions;
    }
    getInstalledExtension(id) {
        return this._context
            .getExtra('changes')
            .extensions.find((it) => it.id === id);
    }
};
Sdk = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__param)(3, (0,external_tiny_injector_.Inject)(external_tiny_injector_.Context)),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (sdk_a = typeof Tables !== "undefined" && Tables) === "function" ? sdk_a : Object, typeof (sdk_b = typeof Features !== "undefined" && Features) === "function" ? sdk_b : Object, typeof (sdk_c = typeof Workflows !== "undefined" && Workflows) === "function" ? sdk_c : Object, typeof (sdk_d = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? sdk_d : Object])
], Sdk);


;// CONCATENATED MODULE: ../compiler/sdk/platform/src/index.ts


;// CONCATENATED MODULE: ./src/lib/setup.ts











Error.stackTraceLimit = Infinity;
external_tiny_injector_.Injector.AddScoped(tiny_mediatr_.Mediator, EventMediator);
external_tiny_injector_.Injector.TryAddScoped(external_tiny_injector_.Context, (c) => c);
const db = new (external_better_sqlite3_default())((0,external_path_.join)((0,external_os_.tmpdir)(), 'events.sqlite'), {
    fileMustExist: false,
});
db.pragma('journal_mode = WAL');
db.prepare(external_dedent_default() `CREATE TABLE IF NOT EXISTS Events (
      id TEXT PRIMARY KEY,
  aggregateVersion INTEGER,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  eventType TEXT,
  aggregateId TEXT,
  streamName TEXT,
  entityId TEXT,
  metadata TEXT,
  data TEXT
    );`).run();
external_tiny_injector_.Injector.AddScoped(SQLITE_TOKEN, () => {
    return {
        transaction: (operations) => {
            try {
                const insertMany = db.transaction((list) => {
                    for (const [operation, data] of list) {
                        operation();
                    }
                });
                insertMany(operations);
            }
            catch (error) {
                if (!db.inTransaction)
                    throw error;
                console.error(error);
            }
        },
        prepare: (op) => {
            db.prepare(op.sql).run(...op.params);
        },
        query: (op) => {
            return db.prepare(op.sql).all(...op.params);
        },
    };
});
external_tiny_injector_.Injector.AddScoped(AbstractStore, TursoStore);
external_tiny_injector_.Injector.AddScoped(AbstractProjectionStore, SqliteProjectionStore);
external_tiny_injector_.Injector.AddScoped(AbstractEventStore, SqliteEventStore);
external_tiny_injector_.Injector.AddScoped(ENVIRONMENT, (context) => ({
    production: process.env.NODE_ENV === 'production',
    version: "1.0.1",
}));
external_tiny_injector_.Injector.AddScoped(CLAIMS_TOKEN, (context) => context.getExtra('claims'));
external_tiny_injector_.Injector.AddScoped(CORRELATION_ID_TOKEN, () => (0,external_uuid_.v4)());
external_tiny_injector_.Injector.AddScoped(DYNAMIC_SOURCE_MAPPER, (context) => (featureId) => {
    const sdk = external_tiny_injector_.Injector.GetRequiredService(Sdk, context);
    return {
        '/tables/:id': (id) => sdk.tables.get(id),
        '/tables/:id/fields': (id) => sdk.tables.get(id).then((it) => (it ? it.fields : [])),
    };
});

// EXTERNAL MODULE: ../utils/formatter/src/lib/format-code.ts
var format_code = __webpack_require__(4);
// EXTERNAL MODULE: external "sql-parser-cst"
var external_sql_parser_cst_ = __webpack_require__(22);
// EXTERNAL MODULE: external "ts-morph"
var external_ts_morph_ = __webpack_require__(23);
;// CONCATENATED MODULE: ../sdk/declarative/src/lib/functional.ts
function input(value) {
    if (typeof value === 'number' ||
        typeof value === 'boolean' ||
        value === null) {
        return input.primitive(value);
    }
    if (value.startsWith('context') || value.startsWith('workflow')) {
        return input.workflow(value.replace('context.', ''));
    }
    if (value.startsWith('trigger')) {
        return input.trigger(value.replace('trigger.', ''));
    }
    if (!value.startsWith('@')) {
        return input.primitive(value);
    }
    return {
        input: value,
    };
}
(function (input) {
    function primitive(value) {
        return {
            input: `@fixed:${typeof value === 'boolean' || typeof value === 'number' || value === null ? value : `'${value}'`}`,
        };
    }
    input.primitive = primitive;
    function workflow(path) {
        return {
            input: `@workflow:${path}`,
        };
    }
    input.workflow = workflow;
    function trigger(path) {
        return {
            input: `@trigger:${path}`,
        };
    }
    input.trigger = trigger;
    function field(name) {
        return {
            input: `@tables:fields.${name}`,
        };
    }
    input.field = field;
})(input || (input = {}));

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/expression.ts
var QueryBuilder;
(function (QueryBuilder) {
    class Expression {
    }
    QueryBuilder.Expression = Expression;
    function createBooleanLiteral(value) {
        return {
            value,
            type: 'boolean',
            accept(visitor, context) {
                return visitor.visitBooleanLiteralExpr(this, {
                    ...context,
                    required: true,
                });
            },
        };
    }
    QueryBuilder.createBooleanLiteral = createBooleanLiteral;
    function createDateLiteral(value) {
        return {
            value,
            type: 'date',
            accept(visitor, context) {
                return visitor.visitDateLiteralExpr(this, {
                    ...context,
                    required: true,
                });
            },
        };
    }
    QueryBuilder.createDateLiteral = createDateLiteral;
    function createStringLiteral(value, defaultContext) {
        return {
            value,
            type: 'string',
            accept(visitor, context = defaultContext) {
                return visitor.visitStringLiteralExpr(this, {
                    ...(context ?? {}),
                    required: true,
                });
            },
        };
    }
    QueryBuilder.createStringLiteral = createStringLiteral;
    function createNumericLiteral(value) {
        return {
            value,
            type: 'numeric',
            accept(visitor, context) {
                return visitor.visitNumericLiteralExpr(this, {
                    ...context,
                    required: true,
                });
            },
        };
    }
    QueryBuilder.createNumericLiteral = createNumericLiteral;
    function createNullLiteral(defaultContext) {
        return {
            type: 'null',
            accept(visitor, context = defaultContext) {
                return visitor.visitNullLiteralExpr(this, {
                    ...(context ?? {}),
                    required: true,
                });
            },
        };
    }
    QueryBuilder.createNullLiteral = createNullLiteral;
    function createIdentifier(value, defaultContext) {
        return {
            value,
            type: 'identifier',
            accept(visitor, context) {
                return visitor.visitIdentifier(this, {
                    ...defaultContext,
                    ...context,
                });
            },
        };
    }
    QueryBuilder.createIdentifier = createIdentifier;
    function createCombinator(operator) {
        return {
            operator,
            type: 'combinator',
            accept(visitor, context) {
                return visitor.visitCombinator(this, context);
            },
        };
    }
    QueryBuilder.createCombinator = createCombinator;
    function createBinaryExpression(left, operator, right, defaultContext) {
        return {
            type: 'binary',
            left,
            operator,
            right,
            accept(visitor, context = defaultContext) {
                return visitor.visitBinaryExpr(this, {
                    ...defaultContext,
                    ...context,
                });
            },
        };
    }
    QueryBuilder.createBinaryExpression = createBinaryExpression;
    function createGroupExpression(list, combinator, defaultContext) {
        return {
            type: 'group',
            combinator,
            value: list,
            accept(visitor, context = defaultContext) {
                return visitor.visitGroupExpr(this, {
                    ...defaultContext,
                    ...context,
                });
            },
        };
    }
    QueryBuilder.createGroupExpression = createGroupExpression;
    function createQuerySelectExpression(groups, defaultContext) {
        return {
            type: 'querySelect',
            value: groups,
            accept(visitor, context = defaultContext) {
                return visitor.visitQuerySelectExpr(this, {
                    ...defaultContext,
                    ...context,
                });
            },
        };
    }
    QueryBuilder.createQuerySelectExpression = createQuerySelectExpression;
    function createListExpression(list, defaultContext) {
        return {
            type: 'list',
            value: list,
            accept(visitor, context = defaultContext) {
                return visitor.visitListExpr(this, {
                    ...defaultContext,
                    ...context,
                });
            },
        };
    }
    QueryBuilder.createListExpression = createListExpression;
})(QueryBuilder || (QueryBuilder = {}));
class expression_Visitor {
}

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/ast.ts


const formatInput = (input) => input.join('.');
function collectJoinsFromGroup(it) {
    const tablesNames = [];
    it.data.forEach((it) => {
        if (it.operator === 'querySelect') {
            // Support for subquery not implemented yet
            throw new Error('querySelect must not be inside a group');
        }
        else if (it.operator === 'group') {
            const groupJoins = collectJoinsFromGroup(it);
            groupJoins.forEach((it) => {
                if (!tablesNames.includes(it)) {
                    tablesNames.push(it);
                }
            });
        }
        else if (it.input.length === 2) {
            const tableOrColumn = it.input[0];
            if (!tablesNames.includes(tableOrColumn) && it.input.length === 2) {
                tablesNames.push(tableOrColumn);
            }
        }
    });
    return tablesNames;
}
function collectJoins(query) {
    const columns = query.input ?? [];
    const groups = query.data;
    const tablesFromSelect = (columns ?? [])
        .map((it) => {
        if (it.name.split('.').length === 2) {
            return it.name.split('.')[0];
        }
        return '';
    })
        .filter((it) => it !== '');
    const tablesNames = [...tablesFromSelect];
    groups.forEach((group) => {
        collectJoinsFromGroup(group).forEach((it) => {
            if (!tablesNames.includes(it)) {
                tablesNames.push(it);
            }
        });
    });
    return tablesNames;
}
function toAst(it) {
    const operator = it.operator;
    if (it.operator === 'querySelect') {
        const columns = it.input ?? [];
        const groups = it.data;
        const groupsAst = [];
        for (const group of groups) {
            const combinator = group.input[0];
            if (combinator !== 'and' && combinator !== 'or') {
                throw new Error(`Invalid combinator ${combinator}`);
            }
            if (!group.data.length) {
                continue;
            }
            const groupAst = [];
            for (const item of group.data) {
                const result = toAst(item);
                if (result)
                    groupAst.push(result);
            }
            groupsAst.push(QueryBuilder.createGroupExpression(groupAst, QueryBuilder.createCombinator(combinator)));
        }
        return QueryBuilder.createQuerySelectExpression(groupsAst, {
            columns: columns ?? [],
            joinsFields: collectJoins(it),
        });
    }
    if (it.operator === 'group') {
        const combinator = it.input[0];
        if (combinator !== 'and' && combinator !== 'or') {
            throw new Error(`Invalid combinator ${combinator}`);
        }
        if (!it.data.length) {
            return null;
        }
        const groupAst = [];
        for (const item of it.data) {
            const result = toAst(item);
            if (result)
                groupAst.push(result);
        }
        return QueryBuilder.createGroupExpression(groupAst, QueryBuilder.createCombinator(combinator));
    }
    if (it.operator === 'equals') {
        if (it.data.static) {
            return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), '===', pickLiteral(it.data), {
                ...it.data,
                required: true,
            });
        }
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), '===', QueryBuilder.createIdentifier(it.input[0]), 
        // QueryBuilder.createIdentifier('WILL_BE_USED_FROM_DESTRUCTURED_INPUT'),
        it.data);
    }
    if (it.operator === 'one_of') {
        const oneOfArr = it.data.value;
        if (it.data.static) {
            return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'in', QueryBuilder.createListExpression(oneOfArr.map((a) => pickLiteral(a))), { ...it.data, required: true });
        }
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'in', QueryBuilder.createListExpression(oneOfArr.map((a) => QueryBuilder.createIdentifier(a))), it.data);
    }
    if (it.operator === 'ends_with' ||
        it.operator === 'contains' ||
        it.operator === 'starts_with') {
        if (it.data.static) {
            return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'like', pickLiteral(it.data), {
                ...it.data,
                required: true,
            });
        }
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'like', QueryBuilder.createIdentifier(it.data.value), it.data);
    }
    if (it.operator === 'is') {
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'is', pickLiteral(it.data), {
            ...it.data,
            required: true,
        });
    }
    if (it.operator === 'is_empty') {
        const combinator = it.data.inverse
            ? QueryBuilder.createCombinator('and')
            : QueryBuilder.createCombinator('or');
        const identifier = QueryBuilder.createIdentifier(formatInput(it.input));
        const nullBnryExpr = QueryBuilder.createBinaryExpression(identifier, 'is', QueryBuilder.createNullLiteral(), {
            inverse: it.data.inverse,
            required: true,
        });
        if (it.data.type === 'string') {
            const stringBnryExpr = QueryBuilder.createBinaryExpression(identifier, 'is', QueryBuilder.createStringLiteral(''), {
                inverse: it.data.inverse,
                required: true,
            });
            return QueryBuilder.createGroupExpression([stringBnryExpr, nullBnryExpr], combinator, {
                inverse: it.data.inverse,
            });
        }
        else {
            return QueryBuilder.createGroupExpression([nullBnryExpr], combinator, {
                inverse: it.data.inverse,
            });
        }
    }
    const comparisonMap = {
        less_than: '<',
        more_than: '>',
        less_than_or_equal: '<=',
        more_than_or_equal: '>=',
    };
    if (comparisonMap[operator]) {
        const sqlOperator = comparisonMap[operator];
        if (it.data.static) {
            return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), sqlOperator, pickLiteral(it.data), {
                ...it.data,
                required: true,
            });
        }
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), sqlOperator, QueryBuilder.createIdentifier(it.data.value), 
        // the ui should validate that the value is string in case of dynamic
        it.data);
    }
    const dateMap = {
        before: '<',
        after: '>',
        before_on: '<=',
        after_on: '>=',
    };
    if (dateMap[operator]) {
        const sqlOperator = dateMap[operator];
        if (it.data.static) {
            return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), sqlOperator, pickLiteral(it.data), {
                ...it.data,
                required: true,
            });
        }
        // else if (it.data.kind === '@period') {
        //   return QueryBuilder.createBinaryExpression(
        //     QueryBuilder.createIdentifier(formatInput(it.input)),
        //     sqlOperator,
        //     pickDateOperation(it.data),
        //     { ...it.data, required: true },
        //   );
        // }
        // return QueryBuilder.createBinaryExpression(
        //   QueryBuilder.createIdentifier(formatInput(it.input)),
        //   sqlOperator,
        //   QueryBuilder.createIdentifier(it.data.value), // the ui should validate that the value is string in case of dynamic
        // );
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), sqlOperator, pickDateOperation(it.data), { ...it.data, required: true });
    }
    if (it.operator === 'between') {
        return QueryBuilder.createBinaryExpression(QueryBuilder.createIdentifier(formatInput(it.input)), 'between', QueryBuilder.createBinaryExpression(it.data.min.kind === '@fixed'
            ? QueryBuilder.createStringLiteral(it.data.min.value)
            : QueryBuilder.createIdentifier(it.data.min.value), 'AND', it.data.max.kind === '@fixed'
            ? QueryBuilder.createStringLiteral(it.data.max.value)
            : QueryBuilder.createIdentifier(it.data.max.value)));
    }
    throw new Error(`Operator is not supported. operator: ${it.operator}`);
}
function pickLiteral(data) {
    switch (data.type) {
        case 'string':
            return QueryBuilder.createStringLiteral(data.value);
        case 'number':
            return QueryBuilder.createNumericLiteral(data.value);
        case 'date':
            return QueryBuilder.createDateLiteral(data.value);
        case 'boolean':
            return QueryBuilder.createBooleanLiteral(data.value);
        case 'null':
            return QueryBuilder.createNullLiteral();
        default:
            if (data.static && data.value === 'null') {
                return QueryBuilder.createNullLiteral();
            }
            throw new Error(`Data Type ${data.type} Not Supported`);
    }
}
function pickDateOperation(data) {
    const { period, relativeTo, amount } = data;
    if (!['day', 'week', 'month', 'quarter', 'year'].includes(period)) {
        throw new Error(`Period ${period} Not Supported`);
    }
    if (!amount) {
        return QueryBuilder.createIdentifier((0,external_stringcase_.camelcase)(`current_${period}()`));
    }
    const args = [];
    //TODO - I need to check if relativeTo is an ISO Date
    if (relativeTo && relativeTo !== 'now') {
        args.push(`date: '${relativeTo}'`);
    }
    args.push(`amount: ${amount}`);
    const argsObjectLiteral = `{ ${args.join(', ')} }`;
    return QueryBuilder.createIdentifier(`${period}(${argsObjectLiteral})`);
}

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/factory.ts
var QueryFactory;
(function (QueryFactory) {
    function createEmptyGroupRule() {
        return {
            data: [],
            operator: 'group',
            input: ['and'],
        };
    }
    QueryFactory.createEmptyGroupRule = createEmptyGroupRule;
    function createGroupRule(combinator, data) {
        return {
            input: [combinator],
            operator: 'group',
            data,
        };
    }
    QueryFactory.createGroupRule = createGroupRule;
    function createSelectRule(groups, columns) {
        return {
            operator: 'querySelect',
            input: columns ?? [],
            data: groups,
        };
    }
    QueryFactory.createSelectRule = createSelectRule;
    function createIsEmptyRule(input, data) {
        return {
            operator: 'is_empty',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createIsEmptyRule = createIsEmptyRule;
    function createIsNotEmptyRule(input, data) {
        return {
            operator: 'is_empty',
            input,
            data: {
                ...data,
                inverse: true,
            },
        };
    }
    QueryFactory.createIsNotEmptyRule = createIsNotEmptyRule;
    function createEqualRule(input, data) {
        return {
            operator: 'equals',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createEqualRule = createEqualRule;
    function createGreaterThanRule(input, data) {
        return {
            operator: 'more_than',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createGreaterThanRule = createGreaterThanRule;
    function createGreaterThanEqualRule(input, data) {
        return {
            operator: 'more_than_or_equal',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createGreaterThanEqualRule = createGreaterThanEqualRule;
    function createLessThanRule(input, data) {
        return {
            operator: 'less_than',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createLessThanRule = createLessThanRule;
    function createLessThanEqualRule(input, data) {
        return {
            operator: 'less_than_or_equal',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createLessThanEqualRule = createLessThanEqualRule;
    function createIsRule(input, data) {
        return {
            operator: 'is',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createIsRule = createIsRule;
    function createIsNotRule(input, data) {
        return {
            operator: 'is',
            input,
            data: {
                ...data,
                inverse: true,
            },
        };
    }
    QueryFactory.createIsNotRule = createIsNotRule;
    function createNotEqualRule(input, data) {
        return {
            operator: 'equals',
            input,
            data: {
                ...data,
                inverse: true,
            },
        };
    }
    QueryFactory.createNotEqualRule = createNotEqualRule;
    function createOneOfRule(input, data) {
        return {
            operator: 'one_of',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createOneOfRule = createOneOfRule;
    function createNotOneOfRule(input, data) {
        return {
            operator: 'one_of',
            input,
            data: {
                ...data,
                inverse: true,
            },
        };
    }
    QueryFactory.createNotOneOfRule = createNotOneOfRule;
    function createBetweenRule(input, data) {
        return {
            operator: 'between',
            input,
            data: {
                ...data,
                inverse: false,
            },
        };
    }
    QueryFactory.createBetweenRule = createBetweenRule;
    function createNotBetweenRule(input, data) {
        return {
            operator: 'between',
            input,
            data: {
                ...data,
                inverse: true,
            },
        };
    }
    QueryFactory.createNotBetweenRule = createNotBetweenRule;
    function createContainRule(input, data) {
        return {
            operator: 'contains',
            input,
            data: {
                ...data,
                inverse: false,
                prefix: '%',
                postfix: '%',
            },
        };
    }
    QueryFactory.createContainRule = createContainRule;
    function createMatchRule(input, data) {
        return {
            operator: 'contains',
            input,
            data: {
                ...data,
                inverse: false,
                prefix: '',
                postfix: '',
            },
        };
    }
    QueryFactory.createMatchRule = createMatchRule;
    function createNotMatchRule(input, data) {
        return {
            operator: 'contains',
            input,
            data: {
                ...data,
                inverse: true,
                prefix: '',
                postfix: '',
            },
        };
    }
    QueryFactory.createNotMatchRule = createNotMatchRule;
    function createNotContainRule(input, data) {
        return {
            operator: 'contains',
            input,
            data: {
                ...data,
                inverse: true,
                prefix: '%',
                postfix: '%',
            },
        };
    }
    QueryFactory.createNotContainRule = createNotContainRule;
    function createStartsWithRule(input, data) {
        return {
            operator: 'starts_with',
            input,
            data: {
                ...data,
                inverse: false,
                prefix: '',
                postfix: '%',
            },
        };
    }
    QueryFactory.createStartsWithRule = createStartsWithRule;
    function createNotStartsWithRule(input, data) {
        return {
            operator: 'starts_with',
            input,
            data: {
                ...data,
                inverse: true,
                prefix: '',
                postfix: '%',
            },
        };
    }
    QueryFactory.createNotStartsWithRule = createNotStartsWithRule;
    function createEndsWithRule(input, data) {
        return {
            operator: 'ends_with',
            input,
            data: {
                ...data,
                inverse: false,
                prefix: '%',
                postfix: '',
            },
        };
    }
    QueryFactory.createEndsWithRule = createEndsWithRule;
    function createNotEndsWithRule(input, data) {
        return {
            operator: 'ends_with',
            input,
            data: {
                ...data,
                inverse: true,
                prefix: '%',
                postfix: '',
            },
        };
    }
    QueryFactory.createNotEndsWithRule = createNotEndsWithRule;
    function createPeriodRule(input, operator, data) {
        return {
            operator,
            input,
            data: {
                ...data,
                input: '',
                inverse: false,
            },
        };
    }
    QueryFactory.createPeriodRule = createPeriodRule;
    function createNotPeriodRule(input, operator, data) {
        return {
            operator,
            input,
            data: {
                ...data,
                input: '',
                inverse: true,
            },
        };
    }
    QueryFactory.createNotPeriodRule = createNotPeriodRule;
})(QueryFactory || (QueryFactory = {}));

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/interfaces.ts
class QueryCondition {
    input;
}

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/utils.ts
function bind(pattern, value) {
    let startIndex = 0;
    let endIndex = 0;
    for (let index = 0; index < pattern.length; index++) {
        const element = pattern[index];
        if (element === '{') {
            startIndex = index;
        }
        if (element === '}') {
            endIndex = index;
        }
    }
    const rest = pattern.split('');
    rest.splice(startIndex, endIndex - startIndex + 1, ...value);
    return rest.join('');
}

;// CONCATENATED MODULE: ../compiler/transpilers/src/lib/visitors/js.visitor.ts

class JsVisitor extends expression_Visitor {
    _rootExpr;
    visitCombinator(expr, context) {
        // const left = expr.left.accept(this, context);
        // const right = expr.right.accept(this, context);
        // switch (expr.operator) {
        //   case 'and':
        //     return `(${left} && ${right})`;
        //   case 'or':
        //     return `(${left} || ${right})`;
        // }
        return '';
    }
    visitListExpr(expr, context) {
        const list = expr.value.map((item) => item.accept(this, context));
        return list.join(',');
    }
    visitQuerySelectExpr(expr, context) {
        return '';
    }
    visitGroupExpr(expr, context) {
        throw new Error('Method not implemented.');
    }
    visitDateLiteralExpr(expr, context = {}) {
        return expr.value;
    }
    constructor(_rootExpr) {
        super();
        this._rootExpr = _rootExpr;
    }
    visitBinaryExpr(expr, context) {
        const left = expr.left.accept(this, context);
        const right = expr.right.accept(this, context);
        switch (expr.operator) {
            case '===':
                return `(${left} === ${right})`;
            case 'like':
                switch (context.pattern) {
                    case '%{}':
                        return `${left}.endsWith(${right})`;
                    case '{}%':
                        return `${left}.startsWith(${right})`;
                    case '%{}%':
                        return `${left}.includes(${right})`;
                    default:
                        throw new Error(`Like operator not supported. pattern: ${context.pattern}`);
                }
                break;
            default:
                throw new Error(`Expression is not supported. operator: ${expr.operator}`);
        }
    }
    visitNumericLiteralExpr(expr) {
        return `${expr.value}`;
    }
    visitNullLiteralExpr(expr) {
        return `${expr.value}`;
    }
    visitBooleanLiteralExpr(expr) {
        return `${expr.value}`;
    }
    visitStringLiteralExpr(expr) {
        return `"${expr.value}"`;
    }
    visitIdentifier(expr) {
        return `${expr.value}`;
    }
    execute() {
        return this.visitGroupExpr(this._rootExpr, {});
    }
}

;// CONCATENATED MODULE: ../compiler/transpilers/src/index.ts







;// CONCATENATED MODULE: ../sdk/declarative/src/lib/utils.ts
function isValidIdentifier(property) {
    const regex = /^[a-zA-Z_$][0-9a-zA-Z_$]*$/;
    return regex.test(property);
}
function createPathProxy(path = '###$$$###') {
    return new Proxy(() => {
        /* noop */
    }, {
        get(target, property) {
            if (property === 'valueOf') {
                return () => path;
            }
            if (property === Symbol.toPrimitive) {
                return (hint) => {
                    if (hint === 'string') {
                        return path;
                    }
                    throw new Error('Invalid hint');
                };
            }
            if (path === '###$$$###') {
                return createPathProxy(`@trigger:` + String(property));
            }
            return createPathProxy(path +
                (typeof property === 'string'
                    ? isValidIdentifier(property)
                        ? `.${property}`
                        : `['${property}']`
                    : `.${String(property)}`));
        },
        apply(target, thisArg, argumentsList) {
            const argsString = argumentsList
                .map((arg) => JSON.stringify(arg))
                .join(', ');
            return createPathProxy(path + `(${argsString})`);
        },
    });
}
function createEnvProxy() {
    return new Proxy(process.env, {
        get(target, property, receiver) {
            if (typeof property === 'string') {
                return `process.env.${property}`;
            }
            return Reflect.get(target, property, receiver);
        },
    });
}
function getErrors(fn) {
    try {
        fn();
        return [];
    }
    catch (e) {
        return [e].flat();
    }
}
function coerceString(value) {
    if (value === undefined || value === null) {
        return value;
    }
    if (typeof value === 'number') {
        return value;
    }
    if (Array.isArray(value)) {
        return value.join('.');
    }
    return value.valueOf();
}

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/query.ts


function where(column, operator, value) {
    const columnName = coerceColumnName(column);
    let condition;
    value = coerceString(value);
    switch (operator) {
        case 'after':
            condition = QueryFactory.createPeriodRule([columnName], 'after', value);
            break;
        case 'before':
            condition = QueryFactory.createPeriodRule([columnName], 'before', value);
            break;
    }
    if (condition) {
        return {
            kind: 'condition',
            implementation: condition,
        };
    }
    if (typeof value !== 'string') {
        throw new Error(`Value ${value} is not supported`);
    }
    const data = {
        type: 'string',
        input: value,
    };
    switch (operator) {
        case 'equals':
            condition = QueryFactory.createEqualRule([columnName], data);
            break;
        case 'not_equals':
            condition = QueryFactory.createNotEqualRule([columnName], data);
            break;
        case 'more_than':
            condition = QueryFactory.createGreaterThanRule([columnName], data);
            break;
        case 'less_than':
            condition = QueryFactory.createLessThanRule([columnName], data);
            break;
        case 'more_than_or_equal':
            condition = QueryFactory.createGreaterThanEqualRule([columnName], data);
            break;
        case 'less_than_or_equal':
            condition = QueryFactory.createLessThanEqualRule([columnName], data);
            break;
        case 'is':
            condition = QueryFactory.createIsRule([columnName], data);
            break;
        case 'is_not_empty':
            condition = QueryFactory.createIsNotEmptyRule([columnName], data);
            break;
        case 'is_empty':
            condition = QueryFactory.createIsEmptyRule([columnName], data);
            break;
        case 'contains':
            condition = QueryFactory.createContainRule([columnName], data);
            break;
        case 'starts_with':
            condition = QueryFactory.createStartsWithRule([columnName], data);
            break;
        case 'ends_with':
            condition = QueryFactory.createEndsWithRule([columnName], data);
            break;
        default:
            throw new Error(`Operator ${operator} is not supported`);
    }
    return {
        kind: 'condition',
        implementation: condition,
    };
}
function sort(name, input) {
    return {
        kind: 'sort',
        implementation: {
            id: coerceColumnName(name),
            input: input.startsWith('@fixed') ? input : `@fixed:${input}`,
        },
    };
}
function isKind(featureOrKind, kind) {
    if (!featureOrKind) {
        return false;
    }
    if (typeof featureOrKind === 'string') {
        return (feature) => feature && feature.kind === featureOrKind;
    }
    return featureOrKind.kind === kind;
}
function assertKind(feature, kind, label) {
    if (!feature || feature.kind !== kind) {
        throw new Error(label ?? `Expected ${kind} feature`);
    }
}
function query(
//   ...features: HasQuery<QueryFeature, T> extends true ? T : never
...features) {
    const sorts = features.filter(isKind('sort'));
    const columns = features
        .filter((f) => f.kind === 'select')
        .map((f) => f.implementation);
    const conditions = features.filter(isKind('condition'));
    const groups = [
        ...features.filter((f) => f.kind === 'group'),
        and(...conditions), // wrap this in an "and" group to simulate implicit "and" condition
    ].map((f) => f.implementation);
    const limit = features.find(isKind('limit'))?.implementation;
    return {
        whereBy: QueryFactory.createSelectRule(groups, columns),
        sortBy: sorts.map((it) => it.implementation),
        limit: limit,
    };
}
query.sql = (sql) => {
    // transform sql to query
};
function query_select(name) {
    return {
        kind: 'select',
        implementation: {
            name,
        },
    };
}
// select.count = (alias: string): SelectFeature => {
//   return {
//     kind: 'select',
//     implementation: {
//       alias: alias,
//       aggregator: 'count',
//       name: '*',
//     },
//   };
// };
// select.count = (...columns: string[]): SelectFeature => {
//   return {
//     kind: 'select',
//     implementation: {
//       count: columns,
//     },
//   };
// };
// export function query(...groups: GroupQueryCondition<unknown>[]): QueryFeature {
//   return {
//     kind: 'query',
//     implementation: QueryFactory.createSelectRule(groups, []),
//   };
// }
function and(...features) {
    const rules = features.map((f) => f.implementation);
    return {
        kind: 'group',
        implementation: QueryFactory.createGroupRule('and', rules),
    };
}
function or(...features) {
    const rules = features.map((f) => f.implementation);
    return {
        kind: 'group',
        implementation: QueryFactory.createGroupRule('or', rules),
    };
}
const coerceColumnName = (column) => {
    if (!column.startsWith('@tables')) {
        return `@tables:fields.${column}`;
    }
    return column;
};
var date;
(function (date) {
    let after;
    (function (after) {
        function startOfThisWeek() {
            return weeksAgo(0);
        }
        after.startOfThisWeek = startOfThisWeek;
        function weekAgo() {
            return weeksAgo(1);
        }
        after.weekAgo = weekAgo;
        // TODO: add relativeTo parameter. if omitted, use 'now'
        function weeksAgo(amount, relativeTo = 'now') {
            return {
                period: 'week',
                amount: -Math.abs(amount),
                relativeTo,
            };
        }
        after.weeksAgo = weeksAgo;
        function weekInYear(n, relativeTo = 'now') {
            // filter records in the nth week of the year
            // now for the current year
            // static date for a specific year
        }
        function monthInYear(n) {
            // same as weekInYear
        }
        function startOfThisMonth() {
            return monthsAgo(0);
        }
        after.startOfThisMonth = startOfThisMonth;
        function monthAgo() {
            return monthsAgo(1);
        }
        after.monthAgo = monthAgo;
        function monthsAgo(amount) {
            return {
                period: 'month',
                amount: -Math.abs(amount),
                relativeTo: 'now',
            };
        }
        after.monthsAgo = monthsAgo;
        function startOfThisYear() {
            return yearsAgo(0);
        }
        after.startOfThisYear = startOfThisYear;
        function yearAgo() {
            return yearsAgo(1);
        }
        after.yearAgo = yearAgo;
        function yearsAgo(amount) {
            return {
                period: 'year',
                amount: -Math.abs(amount),
                relativeTo: 'now',
            };
        }
        after.yearsAgo = yearsAgo;
    })(after = date.after || (date.after = {}));
})(date || (date = {}));
function limit(upTo) {
    return {
        kind: 'limit',
        implementation: upTo,
    };
}

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/database.ts






function defineAction(config) {
    return {
        type: config.type,
        config: config.config,
    };
}
function action(transferable, config) {
    let body = 'return true';
    const guard = transferable.toString();
    const project = new external_ts_morph_.Project({
        useInMemoryFileSystem: true,
    });
    const sourceFile = project.createSourceFile('guard.ts', `const guard = ${guard}`);
    const triggerIdentifierText = 'trigger';
    let guardFunction = sourceFile
        .getVariableDeclarationOrThrow('guard')
        .getInitializerIfKind(external_ts_morph_.SyntaxKind.ArrowFunction);
    if (!guardFunction) {
        guardFunction = sourceFile
            .set({
            statements: [`const guard = ()=>${guard}`],
        })
            .getVariableDeclarationOrThrow('guard')
            .getInitializerIfKindOrThrow(external_ts_morph_.SyntaxKind.ArrowFunction);
    }
    const inputs = [];
    const stepsUses = guardFunction
        .getDescendantsOfKind(external_ts_morph_.SyntaxKind.Identifier)
        .filter((identifier) => identifier.getText() === 'steps');
    const triggerUses = guardFunction
        .getDescendantsOfKind(external_ts_morph_.SyntaxKind.Identifier)
        .filter((identifier) => identifier.getText() === triggerIdentifierText);
    const tablesUsages = guardFunction
        .getDescendantsOfKind(external_ts_morph_.SyntaxKind.PropertyAccessExpression)
        .filter((pae) => {
        return (pae.getExpressionIfKind(external_ts_morph_.SyntaxKind.Identifier)?.getText() === 'tables');
    });
    const tables = [];
    for (const propertyAccess of tablesUsages) {
        const classTableName = (0,external_stringcase_.pascalcase)(propertyAccess.getName());
        tables.push({
            kind: external_ts_morph_.StructureKind.ImportDeclaration,
            moduleSpecifier: makeEntityImportSpecifier(classTableName),
            defaultImport: classTableName,
        });
        propertyAccess.replaceWithText(classTableName);
    }
    for (const stepUse of stepsUses) {
        const parent = stepUse.getParentWhileKind(external_ts_morph_.SyntaxKind.PropertyAccessExpression);
        if (!parent) {
            continue;
        }
        const usageText = parent.getText();
        const [namespace, stepName, ...rest] = usageText.split('.');
        inputs.push(`@workflow:${(0,external_stringcase_.camelcase)(`${stepName}Output`)}.${rest.join('.')}`);
        const key = rest.at(-1);
        parent.replaceWithText(key);
    }
    for (const triggerUse of triggerUses) {
        const parent = triggerUse.getParentWhileKind(external_ts_morph_.SyntaxKind.PropertyAccessExpression);
        if (!parent) {
            continue;
        }
        const usageText = parent.getText();
        const [namespace, ...rest] = usageText.split('.');
        inputs.push(`@${namespace}:${rest.join('.')}`);
        const key = rest.at(-1);
        parent.replaceWithText(`input.${key}`);
    }
    body = guardFunction.getBodyText();
    return defineAction({
        type: 'custom-code',
        config: {
            structures: tables,
            ...(config ?? {}),
            inline: config?.inline ?? false,
            code: body,
            inputs: inputs.reduce((acc, it) => ({
                ...acc,
                [it.split('.').at(-1)]: input(it),
            }), {}),
        },
    });
}
// the intended use of this action is to be used
// as custom return type of an action or within a branch action
// think "return early if post is published"
function actionOutput(config) {
    return defineAction({
        type: 'raw',
        config: config,
    });
}
// FIXME: I think we need to make it array of actions instead of record of actions
// because we don't need to have name all the time. also name can be used as indicator
// to making the action as function (inline: true)
(function (action) {
    let core;
    (function (core) {
        function raw(config) {
            return action(config.code, {
                inline: config.inline,
            });
        }
        core.raw = raw;
        function branch(config) {
            const fallback = {
                id: 'fallback',
                name: 'fallback',
                rule: '',
            };
            const paths = Object.entries(config.paths).map(([name, rule]) => {
                return {
                    id: crypto.randomUUID(),
                    name,
                    rule,
                };
            });
            return defineAction({
                type: 'branch',
                config: {
                    ...config,
                    paths: [fallback, ...paths],
                },
            });
        }
        core.branch = branch;
    })(core = action.core || (action.core = {}));
    let unstable_discord;
    (function (unstable_discord) {
        // this is new version of actions in which we can use the trigger object instead of input dsl
        // input dsl suffers from manipulation.
        function send(config) {
            return action(`
           const webhook = new WebhookClient('${config.webhook}');
           await webhook.send(${JSON.stringify(config.message)});
      `, {
                structures: [
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: 'discord.js',
                        namedImports: ['WebhookClient'],
                    },
                ],
            });
        }
        unstable_discord.send = send;
    })(unstable_discord = action.unstable_discord || (action.unstable_discord = {}));
    let database;
    (function (database) {
        database.list = listRecord;
        database.single = singleRecord;
        database.search = searchRecords;
        database.set = setFields;
        database.remove = deleteRecord;
        database.exists = recordExists;
        database.upsert = upsertRecord;
        database.increment = incrementField;
        database.decrement = decrementField;
        function insert(config) {
            return defineAction({
                type: 'insert-record',
                config: {
                    tableId: config.table,
                    columns: config.columns,
                },
            });
        }
        database.insert = insert;
        function sql(config) {
            const cst = (0,external_sql_parser_cst_.parse)(config.query, {
                dialect: 'sqlite',
                includeSpaces: true,
                includeNewlines: true,
                includeComments: false,
                includeRange: true,
                paramTypes: [],
            });
            const parameters = [];
            // convert all keywords to uppercase
            const toUpper = (0,external_sql_parser_cst_.cstVisitor)({
                string_literal: (str) => {
                    if (str.text.includes('@trigger:')) {
                        parameters.push(input(str.text.replace("'", '').replace("'", '')));
                        str.text = `\${${str.text
                            .replace("'", '')
                            .replace("'", '')
                            .split('.')
                            .at(-1)}}`;
                    }
                },
                keyword: (kw) => {
                    kw.text = kw.text.toUpperCase();
                },
            });
            toUpper(cst);
            return defineAction({
                type: 'raw-sql-query',
                config: {
                    query: (0,external_sql_parser_cst_.show)(cst),
                    parameters,
                },
            });
        }
        database.sql = sql;
        insert.rule = (({ node }, service) => {
            const reports = [];
            return reports;
        });
    })(database = action.database || (action.database = {}));
    function incrementField(config) {
        return defineAction({
            type: 'increment-field',
            config: {
                tableId: config.table,
                field: config.field,
                query: config.query,
            },
        });
    }
    function decrementField(config) {
        return defineAction({
            type: 'decrement-field',
            config: {
                tableId: config.table,
                field: config.field,
                query: config.query,
            },
        });
    }
    function listRecord(config) {
        return defineAction({
            type: 'list-records',
            config: {
                ...config,
                limit: config.limit ?? config.query?.limit,
                tableId: config.table,
                query: config.query ?? query(),
            },
        });
    }
    function searchRecords(config) {
        return action.database.list({
            ...config,
            limit: config.limit ?? 50,
            pagination: config.pagination ?? 'deferred_joins',
            query: query(...config.fields.map((it) => where('name', 'contains', config.queryTerm || '@trigger:query.query'))),
        });
    }
    searchRecords.rule = (() => {
        const reports = [];
        return reports;
    });
    function singleRecord(config) {
        return defineAction({
            type: 'list-records',
            config: {
                limit: 1,
                pagination: 'none',
                tableId: config.table,
                query: config.query,
            },
        });
    }
    singleRecord.rule = (() => {
        const reports = [];
        return reports;
    });
    function upsertRecord(config) {
        return defineAction({
            type: 'upsert-record',
            config: {
                tableId: config.table,
                columns: config.columns,
                conflictFields: config.conflictFields ?? [],
            },
        });
    }
    function setFields(config) {
        return defineAction({
            type: 'set-fields',
            config: {
                tableId: config.table,
                columns: config.columns,
                query: config.query,
            },
        });
    }
    setFields.rule = (() => {
        const reports = [];
        return reports;
    });
    function deleteRecord(config) {
        return defineAction({
            type: 'delete-record',
            config: {
                tableId: config.table,
                query: config.query,
            },
        });
    }
    deleteRecord.rule = (() => {
        const reports = [];
        return reports;
    });
    function recordExists(config) {
        return defineAction({
            type: 'check-record-existance',
            config: {
                tableId: config.table,
                query: config.query,
            },
        });
    }
    recordExists.rule = (() => {
        const reports = [];
        return reports;
    });
})(action || (action = {}));
(function (action) {
    function fromConfig(type, ...args) {
        const parts = type.split('.');
        let impl = parts.length ? action : defineAction;
        while (parts.length) {
            impl = impl[parts.shift()];
        }
        if (impl) {
            return impl(...args);
        }
        if (type.endsWith('.rule')) {
            const reports = [];
            return reports;
        }
        throw new Error(`Unknown action type: ${type}`);
    }
    action.fromConfig = fromConfig;
    let googleCloudStorage;
    (function (googleCloudStorage) {
        function uploadSingle(config) {
            return defineAction({
                type: 'upload-file',
                config: {
                    ...config,
                    // maxFileSize: config.maxFileSize ?? 50 * 1024 * 1024,
                },
            });
        }
        googleCloudStorage.uploadSingle = uploadSingle;
        uploadSingle.rule = (() => {
            const reports = [];
            return reports;
        });
    })(googleCloudStorage = action.googleCloudStorage || (action.googleCloudStorage = {}));
})(action || (action = {}));
(function (action) {
    let resend;
    (function (resend) {
        function sendEmail(config) {
            return defineAction({
                type: 'resend-send-email',
                config: {
                    to: input(config.to),
                    subject: input(config.subject),
                    from: input(config.from),
                    html: input(config.html),
                },
            });
        }
        resend.sendEmail = sendEmail;
        function createContact(config) {
            return defineAction({
                type: 'resend-create-contact',
                config: {
                    email: input(config.email),
                    firstName: input(config.firstName),
                    audienceId: input(config.audienceId),
                },
            });
        }
        resend.createContact = createContact;
        sendEmail.rule = (() => {
            const reports = [];
            return reports;
        });
        createContact.rule = (() => {
            const reports = [];
            return reports;
        });
    })(resend = action.resend || (action.resend = {}));
    function openai() {
        //
    }
    action.openai = openai;
})(action || (action = {}));

;// CONCATENATED MODULE: ../sdk/parser/src/index.ts
var checker;
(function (checker) {
    function isCallExpression(node, name) {
        if (!node) {
            return false;
        }
        const isCallExpr = node.type === 'CallExpression';
        if (!isCallExpr) {
            return false;
        }
        if (!name) {
            return true;
        }
        if (node.callee.type === 'MemberExpression') {
            return (node.callee.property.type === 'Identifier' &&
                node.callee.property.value === name);
        }
        return node.callee.type === 'Identifier' && node.callee.value === name;
    }
    checker.isCallExpression = isCallExpression;
    function isObjectExpression(node) {
        return node.type === 'ObjectExpression';
    }
    checker.isObjectExpression = isObjectExpression;
    function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== 'KeyValueProperty') {
            return false;
        }
        if (!valueType) {
            return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
            return false;
        }
        if (!keyName) {
            return true;
        }
        return isIdentifier(node.key, keyName);
    }
    checker.isKeyValueProperty = isKeyValueProperty;
    function isStringLiteral(node) {
        return node.type === 'StringLiteral';
    }
    checker.isStringLiteral = isStringLiteral;
    function isNullLiteral(node) {
        return node.type === 'NullLiteral';
    }
    checker.isNullLiteral = isNullLiteral;
    function isPrimitive(node) {
        if (node.type === 'StringLiteral' ||
            node.type === 'BooleanLiteral' ||
            node.type === 'NumericLiteral' ||
            node.type === 'BigIntLiteral') {
            return true;
        }
        return false;
    }
    checker.isPrimitive = isPrimitive;
    function isIdentifier(node, name) {
        if (!node) {
            return false;
        }
        const isIdentifier = node.type === 'Identifier';
        if (!isIdentifier) {
            return false;
        }
        if (!name) {
            return true;
        }
        return node.value === name;
    }
    checker.isIdentifier = isIdentifier;
    function isMemberExpression(node, name) {
        if (!node) {
            return false;
        }
        const isMemberExpr = node.type === 'MemberExpression';
        if (!isMemberExpr) {
            return false;
        }
        if (!name) {
            return true;
        }
        return isIdentifier(node.property, name);
    }
    checker.isMemberExpression = isMemberExpression;
    function isArrayExpression(node) {
        return node.type === 'ArrayExpression';
    }
    checker.isArrayExpression = isArrayExpression;
})(checker || (checker = {}));
var Checker;
(function (Checker) {
    function isPrimitive(value) {
        return value !== Object(value);
    }
    Checker.isPrimitive = isPrimitive;
    function isCallExpression(value) {
        return (!isPrimitive(value) &&
            typeof value === 'object' &&
            'caller' in value &&
            'arguments' in value);
    }
    Checker.isCallExpression = isCallExpression;
    function isObjectExpression(value) {
        return (!isCallExpression(value) && value !== null && typeof value === 'object');
    }
    Checker.isObjectExpression = isObjectExpression;
    function isArrayExpression(value) {
        return Array.isArray(value);
    }
    Checker.isArrayExpression = isArrayExpression;
})(Checker || (Checker = {}));
const isWorker = () => {
    return typeof global.importScripts === 'function';
};
let sourceCode;
function isRecord(obj) {
    return typeof obj === 'object' && obj !== null;
}
function isSpan(obj) {
    return (typeof obj === 'object' && obj !== null && 'start' in obj && 'end' in obj);
}
function adjustOffsetOfAst(obj, startOffset) {
    if (Array.isArray(obj)) {
        obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
    }
    else if (isRecord(obj)) {
        Object.entries(obj).forEach(([key, value]) => {
            if (key === 'span' && value && isSpan(value)) {
                const span = value;
                span.start -= startOffset;
                span.end -= startOffset;
            }
            else {
                adjustOffsetOfAst(obj[key], startOffset);
            }
        });
    }
}
async function parseCode(code) {
    const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    '@swc/wasm-web');
    await initSync('https://cdn.jsdelivr.net/npm/@swc/wasm-web@1.7.3/wasm_bg.wasm');
    if (typeof code !== 'string' || !code.trim()) {
        return null;
    }
    const val = parseSync(code, {
        syntax: 'typescript',
        decorators: false,
        comments: false,
        dynamicImport: false,
        script: false,
        tsx: false,
        target: 'es2022',
    });
    {
        // FIXME: let go of this as it's creating more bugs
        // In the editor side just count the whitespaces and and them to the start of span
        // swc doesn't count empty width so it'll always start counting from a non-empty character
        // val.span.start = 1;
        // val.span.end = code.length;
        adjustOffsetOfAst(val, val.span.start);
    }
    return val;
}
async function parseDeclarative(code) {
    sourceCode = code;
    const val = await parseCode(code);
    if (!val) {
        return null;
    }
    const importStmt = val.body.filter((it) => it.type === 'ImportDeclaration');
    const projectExpr = val.body.find((it) => it.type === 'ExportDefaultExpression');
    if (!projectExpr) {
        return null;
    }
    if (!checker.isCallExpression(projectExpr.expression, 'project')) {
        return null;
    }
    return {
        imports: importStmt
            .filter((it) => it.source.value !== '@january/declarative')
            .filter((it) => !it.source.value.endsWith('.g.ts'))
            .map((it) => ({
            isTypeOnly: it.typeOnly,
            moduleSpecifier: it.source.value,
            defaultImport: it.specifiers.find((sp) => sp.type === 'ImportDefaultSpecifier')?.local.value,
            namespaceImport: it.specifiers.find((sp) => sp.type === 'ImportNamespaceSpecifier')?.local.value,
            namedImports: it.specifiers
                .filter((sp) => sp.type === 'ImportSpecifier')
                .map((sp) => ({
                name: sp.imported ? sp.imported.value : sp.local.value,
                alias: sp.imported ? sp.local.value : undefined,
                isTypeOnly: sp.isTypeOnly,
            })),
        })),
        project: resolveCallExpression(projectExpr.expression),
    };
}
function resolveAsExpression(node) {
    const args = [];
    if (checker.isNullLiteral(node.expression)) {
        args.push(null);
    }
    if (checker.isPrimitive(node.expression)) {
        args.push(node.expression.value);
    }
    if (checker.isIdentifier(node.expression)) {
        args.push(node.expression.value);
    }
    if (checker.isObjectExpression(node.expression)) {
        args.push(resolveObjectExpression(node.expression));
    }
    if (checker.isCallExpression(node.expression)) {
        args.push(resolveCallExpression(node.expression));
    }
    if (checker.isMemberExpression(node.expression)) {
        // join the member expression here since it's most likely a path
        args.push(resolveMemberExpression(node.expression, []).join('.'));
    }
    if (node.expression.type === 'TsAsExpression') {
        args.push(resolveAsExpression(node.expression));
    }
    return args;
}
function resolveCallExpression(node) {
    const args = [];
    for (const arg of node.arguments) {
        if (checker.isNullLiteral(arg.expression)) {
            args.push(null);
            continue;
        }
        if (arg.expression.type === 'UnaryExpression') {
            args.push(resolveUnaryExpression(arg.expression));
            continue;
        }
        if (checker.isPrimitive(arg.expression)) {
            args.push(arg.expression.value);
            continue;
        }
        if (checker.isIdentifier(arg.expression)) {
            args.push(arg.expression.value);
        }
        if (checker.isObjectExpression(arg.expression)) {
            args.push(resolveObjectExpression(arg.expression));
        }
        if (checker.isCallExpression(arg.expression)) {
            args.push(resolveCallExpression(arg.expression));
        }
        if (checker.isMemberExpression(arg.expression)) {
            args.push(resolveMemberExpression(arg.expression, []));
        }
        if (arg.expression.type === 'ArrowFunctionExpression') {
            if (sourceCode) {
                args.push(sourceCode.slice(arg.expression.span.start, arg.expression.span.end));
            }
        }
        if (arg.expression.type === 'TsAsExpression') {
            args.push(resolveAsExpression(arg.expression));
        }
    }
    let calleeName = '';
    if (checker.isMemberExpression(node.callee)) {
        // const [, ...actionPath] = resolveMemberExpression(node.callee, []);
        const [...actionPath] = resolveMemberExpression(node.callee, []);
        calleeName = actionPath.join('.');
    }
    if (checker.isIdentifier(node.callee)) {
        calleeName = node.callee.value;
    }
    return {
        caller: calleeName,
        arguments: args,
        span: node.span,
    };
}
function resolveUnaryExpression(node) {
    if (node.argument.type === 'NumericLiteral') {
        return Number(`${node.operator}${node.argument.value}`);
    }
    return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node) {
    const list = [];
    for (const arg of node.elements) {
        if (!arg) {
            continue;
        }
        if (checker.isNullLiteral(arg.expression)) {
            list.push(null);
        }
        if (arg.expression.type === 'UnaryExpression') {
            list.push(resolveUnaryExpression(arg.expression));
            continue;
        }
        if (checker.isPrimitive(arg.expression)) {
            list.push(arg.expression.value);
        }
        if (checker.isObjectExpression(arg.expression)) {
            list.push(resolveObjectExpression(arg.expression));
        }
        if (checker.isCallExpression(arg.expression)) {
            list.push(resolveCallExpression(arg.expression));
        }
    }
    return list;
}
function resolveObjectExpression(node, key) {
    const obj = {};
    for (const prop of node.properties) {
        if (!checker.isKeyValueProperty(prop)) {
            continue;
        }
        if (!checker.isIdentifier(prop.key)) {
            continue;
        }
        if (checker.isNullLiteral(prop.value)) {
            obj[prop.key.value] = null;
            continue;
        }
        if (prop.value.type === 'UnaryExpression') {
            obj[prop.key.value] = resolveUnaryExpression(prop.value);
            continue;
        }
        if (checker.isPrimitive(prop.value)) {
            obj[prop.key.value] = prop.value.value;
            continue;
        }
        if (checker.isKeyValueProperty(prop, 'CallExpression')) {
            obj[prop.key.value] = resolveCallExpression(prop.value);
            continue;
        }
        if (checker.isArrayExpression(prop.value)) {
            obj[prop.key.value] = resolveArrayExpression(prop.value);
            continue;
        }
        if (checker.isObjectExpression(prop.value)) {
            obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
            continue;
        }
        if (prop.value.type === 'ArrowFunctionExpression') {
            if (sourceCode) {
                obj[prop.key.value] = sourceCode.slice(prop.value.span.start, prop.value.span.end);
                // if (key === 'actions') {
                //   if (checker.isCallExpression(prop.value.body)) {
                //     obj[prop.key.value] = resolveCallExpression(prop.value.body);
                //   }
                // }
            }
        }
        // if (checker.isMemberExpression(prop.value)) {
        //   actions[prop.key.value] = resolveMemberExpression(prop.value, []);
        //   continue;
        // }
        // if (prop.value.type === 'TsAsExpression') {
        //   actions[prop.key.value] = resolveAsExpression(prop.value);
        //   continue;
        // }
        //Note: you can use this instead of resolving TsAsExpression and MemberExpression
        // it is needed now because the "as" will be forgotten about
        if (checker.isMemberExpression(prop.value) ||
            prop.value.type === 'TsAsExpression') {
            if (sourceCode) {
                obj[prop.key.value] = sourceCode.slice(prop.value.span.start, prop.value.span.end);
            }
        }
    }
    return obj;
}
function resolveMemberExpression(node, acc) {
    const collection = acc.slice(0);
    if (checker.isIdentifier(node.object)) {
        collection.push(node.object.value);
    }
    if (checker.isMemberExpression(node.object)) {
        collection.push(...resolveMemberExpression(node.object, acc));
    }
    if (checker.isIdentifier(node.property)) {
        collection.push(node.property.value);
    }
    return collection;
}
const exportTypes = [
    'ExportAllDeclaration',
    'ExportDeclaration',
    'ExportDefaultDeclaration',
    'ExportDefaultExpression',
    'ExportNamedDeclaration',
    'ImportDeclaration',
];
function isExportItem(item) {
    return exportTypes.some((x) => {
        return item && item.type === x;
    });
}
async function getExports(code) {
    const ast = await parseCode(code);
    if (!ast) {
        return [];
    }
    return ast.body.filter(isExportItem);
}

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/feature.ts

// // 1 workflow
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
// >(
//   name: string,
//   config: FeatureConfig<[WorkflowDefinition<T1, A1>]>,
// ): FeatureDefinition<unknown>;
// // 2 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [WorkflowDefinition<T1, A1>, WorkflowDefinition<T2, A2>]
//   >,
// ): FeatureDefinition<unknown>;
// // 3 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 4 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 5 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 6 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
//   T6 extends TriggerDefinition<unknown, unknown>,
//   A6 extends Record<string, Action<T6>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//       WorkflowDefinition<T6, A6>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 7 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
//   T6 extends TriggerDefinition<unknown, unknown>,
//   A6 extends Record<string, Action<T6>>,
//   T7 extends TriggerDefinition<unknown, unknown>,
//   A7 extends Record<string, Action<T7>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//       WorkflowDefinition<T6, A6>,
//       WorkflowDefinition<T7, A7>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 8 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
//   T6 extends TriggerDefinition<unknown, unknown>,
//   A6 extends Record<string, Action<T6>>,
//   T7 extends TriggerDefinition<unknown, unknown>,
//   A7 extends Record<string, Action<T7>>,
//   T8 extends TriggerDefinition<unknown, unknown>,
//   A8 extends Record<string, Action<T8>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//       WorkflowDefinition<T6, A6>,
//       WorkflowDefinition<T7, A7>,
//       WorkflowDefinition<T8, A8>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 9 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
//   T6 extends TriggerDefinition<unknown, unknown>,
//   A6 extends Record<string, Action<T6>>,
//   T7 extends TriggerDefinition<unknown, unknown>,
//   A7 extends Record<string, Action<T7>>,
//   T8 extends TriggerDefinition<unknown, unknown>,
//   A8 extends Record<string, Action<T8>>,
//   T9 extends TriggerDefinition<unknown, unknown>,
//   A9 extends Record<string, Action<T9>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//       WorkflowDefinition<T6, A6>,
//       WorkflowDefinition<T7, A7>,
//       WorkflowDefinition<T8, A8>,
//       WorkflowDefinition<T9, A9>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
// // 10 workflows
// export function feature<
//   T1 extends TriggerDefinition<unknown, unknown>,
//   A1 extends Record<string, Action<T1>>,
//   T2 extends TriggerDefinition<unknown, unknown>,
//   A2 extends Record<string, Action<T2>>,
//   T3 extends TriggerDefinition<unknown, unknown>,
//   A3 extends Record<string, Action<T3>>,
//   T4 extends TriggerDefinition<unknown, unknown>,
//   A4 extends Record<string, Action<T4>>,
//   T5 extends TriggerDefinition<unknown, unknown>,
//   A5 extends Record<string, Action<T5>>,
//   T6 extends TriggerDefinition<unknown, unknown>,
//   A6 extends Record<string, Action<T6>>,
//   T7 extends TriggerDefinition<unknown, unknown>,
//   A7 extends Record<string, Action<T7>>,
//   T8 extends TriggerDefinition<unknown, unknown>,
//   A8 extends Record<string, Action<T8>>,
//   T9 extends TriggerDefinition<unknown, unknown>,
//   A9 extends Record<string, Action<T9>>,
//   T10 extends TriggerDefinition<unknown, unknown>,
//   A10 extends Record<string, Action<T10>>,
// >(
//   name: string,
//   config: FeatureConfig<
//     [
//       WorkflowDefinition<T1, A1>,
//       WorkflowDefinition<T2, A2>,
//       WorkflowDefinition<T3, A3>,
//       WorkflowDefinition<T4, A4>,
//       WorkflowDefinition<T5, A5>,
//       WorkflowDefinition<T6, A6>,
//       WorkflowDefinition<T7, A7>,
//       WorkflowDefinition<T8, A8>,
//       WorkflowDefinition<T9, A9>,
//       WorkflowDefinition<T10, A10>,
//     ]
//   >,
// ): FeatureDefinition<unknown>;
function feature(name, config) {
    return {
        name,
        tables: config.tables,
        workflows: config.workflows,
        policies: Object.entries(config.policies || {}).reduce((acc, [key, value]) => {
            const result = value(key);
            if (result) {
                acc[key] = result;
            }
            return acc;
        }, {}),
    };
}
feature.new = (name, config) => {
    // return feature(name, {
    //   ...config,
    //   workflows: Object.entries(config.workflows).map(([key, value]) =>
    //     value(key),
    //   ),
    // });
    throw new Error('Not implemented');
};
feature.rule = (({ node }, service) => {
    const reports = [];
    // TODO: check for workflow name duplication
    if (!Checker.isCallExpression(node)) {
        return reports;
    }
    const [featureName, config] = node.arguments;
    const errors = service.validateName(featureName, 'Feature');
    for (const error of errors) {
        reports.push({
            message: error,
            span: node.span,
            node: node,
            severity: 'error',
        });
    }
    if (errors.length) {
        return reports;
    }
    if (!service.inUniqueFeature(featureName)) {
        reports.push({
            message: `Feature "${featureName}" is already defined`,
            span: node.span,
            node: node,
            severity: 'error',
        });
    }
    if (Checker.isObjectExpression(config)) {
        // will be caught by syntax validation
        if (!('tables' in config)) {
            reports.push({
                message: 'Feature must have tables',
                span: node.span,
                node: node,
                severity: 'error',
            });
        }
    }
    return reports;
});

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/project.ts
function current_Project(name, config) {
    return {
        name,
        features: config.modules,
        extensions: config.extensions,
        imports: config.imports ?? [],
    };
}
function project(...features) {
    return features;
}
project.rule = (({ node }, service) => {
    const reports = [];
    return reports;
});

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/validation.ts
function mandatory(config = {}) {
    return {
        name: 'mandatory',
        details: {
            value: 'true',
            message: config.message,
        },
    };
}
const required = mandatory;
function unique(config = {}) {
    return [
        mandatory(),
        {
            name: 'unique',
            details: {
                value: 'true',
                message: config.message,
            },
        },
    ];
}
function defineValidation(config) {
    return {
        name: config.name,
        config,
    };
}
var validation;
(function (validation) {
    function fromConfig(type, ...args) {
        const parts = type.split('.');
        let impl = parts.length ? validation : defineValidation;
        while (parts.length) {
            impl = impl[parts.shift()];
        }
        if (impl) {
            return impl(...args);
        }
        if (type.endsWith('.rule')) {
            const reports = [];
            return reports;
        }
        throw new Error(`Unknown validation type: ${type}`);
    }
    validation.fromConfig = fromConfig;
})(validation || (validation = {}));

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/table.ts




const CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
const UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
const DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
// function connect(tablea: UseTable, tableb: UseTable) {
//   //
// }
// connect.oneToMany = (tablea: UseTable, tableb: UseTable) => {
//   //
// };
// connect.manyToMany = (tablea: UseTable, tableb: UseTable) => {
//   //
// };
function table(config) {
    const additionalFields = {};
    const idField = Object.values(config.fields).find((def) => 
    // TODO: these types should come from the installed database extension
    ['primary-key-uuid', 'primary-key-number', 'primary-key-custom'].includes(def.type));
    if (!idField) {
        additionalFields['id'] = field.primary({
            type: 'uuid',
            generated: true,
        });
    }
    const createdAtField = Object.keys(config.fields).find((key) => CREATED_AT.test(key));
    const updatedAtField = Object.keys(config.fields).find((key) => UPDATED_AT.test(key));
    const deletedAtField = Object.keys(config.fields).find((key) => DELETED_AT.test(key));
    if (!createdAtField) {
        additionalFields['createdAt'] = field({
            type: 'datetime',
            metadata: {
                system_created_at: true,
                can_be_deleted: false,
                can_be_updated: false,
                system_auto_generated: true,
            },
        });
    }
    if (!updatedAtField) {
        additionalFields['updatedAt'] = field({
            type: 'datetime',
            metadata: {
                can_be_deleted: false,
                can_be_updated: false,
                system_auto_generated: true,
                system_updated_at: true,
            },
        });
    }
    if (!deletedAtField) {
        additionalFields['deletedAt'] = field({
            type: 'datetime',
            metadata: {
                system_deleted_at: true,
                system_auto_generated: true,
                can_be_deleted: false,
                can_be_updated: false,
            },
        });
    }
    return {
        fields: {
            ...config.fields,
            ...additionalFields,
        },
        constraints: config.constraints || [],
    };
}
table.unique = (...fields) => {
    return {
        type: 'unique',
        details: {
            columns: fields,
        },
    };
};
table.index = (...fields) => {
    return {
        type: 'index',
        details: {
            columns: fields,
        },
    };
};
// table.relation = (config: {
//   relationship: 'one-to-many' | 'many-to-many' | 'one-to-one';
//   references: UseTable[];
// }): TableDefinition => {
//   return {
//     type: 'relation',
//     fields: {},
//     constraints: [],
//   };
// };
table.use = useTable;
function useTable(name) {
    return {
        command: 'QueryTable',
        payload: {
            name,
        },
    };
}
useTable.rule = (({ node }, service) => {
    const reports = [];
    if (!Checker.isCallExpression(node)) {
        return reports;
    }
    const [table] = node.arguments;
    if (typeof table !== 'string') {
        reports.push({
            message: 'Table name must be a string literal',
            span: node.span,
            node: node,
            severity: 'error',
        });
    }
    else {
        const exist = service.hasTable(table);
        if (!exist) {
            reports.push({
                message: `Table "${table}" not found`,
                span: node.span,
                node: node,
                severity: 'error',
            });
        }
    }
    return reports;
});
function field(config) {
    const { type, validations = [], metadata = {}, ...rest } = config;
    return {
        type: config.type,
        details: {
            ...metadata,
            ...rest,
        },
        validations,
    };
}
(function (field) {
    function fromConfig(type, ...args) {
        if (typeof type === 'string') {
            const parts = type.split('.');
            let impl = field;
            while (parts.length) {
                impl = impl[parts.shift()];
            }
            if (impl) {
                return impl(...args);
            }
            if (type.endsWith('.rule')) {
                const reports = [];
                return reports;
            }
            throw new Error(`Unknown field type: ${type}`);
        }
        return field(type);
    }
    field.fromConfig = fromConfig;
    function primary(config) {
        const typesMap = {
            uuid: 'primary-key-uuid',
            number: 'primary-key-number',
            string: 'primary-key-custom',
        };
        return {
            type: typesMap[config.type],
            details: {
                system_primary_key: true,
                can_be_deleted: false,
                can_be_updated: false,
                system_auto_generated: config.generated ?? true,
            },
            validations: [mandatory()],
        };
    }
    field.primary = primary;
    function integer() {
        return {
            type: 'integer',
            details: {},
            validations: [],
        };
    }
    field.integer = integer;
    function decimal() {
        return {
            type: 'integer',
            details: {},
            validations: [],
        };
    }
    field.decimal = decimal;
    function relation(config) {
        return field({
            type: 'relation',
            metadata: config,
            validations: config.validations,
        });
    }
    field.relation = relation;
})(field || (field = {}));
field.enum = (config) => {
    return field({
        type: 'single-select',
        metadata: {
            style: 'enum',
            values: config.values,
            defaultValue: config.defaultValue,
        },
    });
};
function useField(name, value) {
    value = coerceString(value);
    if (value === undefined) {
        return {
            input: {
                command: 'QueryFieldName',
                payload: {
                    name: name,
                },
            },
        };
    }
    return {
        ...input(value),
        name: {
            command: 'QueryField',
            payload: {
                name: name,
            },
        },
    };
}
useField.rule = (({ node }, service) => {
    const reports = [];
    if (!Checker.isCallExpression(node)) {
        return reports;
    }
    const [fieldName] = node.arguments;
    if (typeof fieldName !== 'string') {
        reports.push({
            message: 'Field name must be a string literal',
            span: node.span,
            node: node,
            severity: 'error',
        });
    }
    else {
        // TODO: we need table name over here!
        // Perhaps fixing this not important when we move to use the table
        // as argument and not string which will make this error being caught by
        // syntax validation
        const exist = service.hasField(fieldName);
        if (!exist) {
            reports.push({
                message: `Field "${fieldName}" not found`,
                span: node.span,
                node: node,
                severity: 'error',
            });
        }
    }
    return reports;
});
useField.increment = (name, value) => {
    return {
        ...useField(name, value),
        data: {
            increment: true,
        },
    };
};
useField.decrement = (name, value) => {
    return {
        ...useField(name, value),
        data: {
            decrement: true,
        },
    };
};
function index(...fields) {
    return {
        type: 'index',
        details: {
            columns: fields,
        },
    };
}

// EXTERNAL MODULE: external "ajv"
var external_ajv_ = __webpack_require__(24);
// EXTERNAL MODULE: external "ajv-errors"
var external_ajv_errors_ = __webpack_require__(25);
var external_ajv_errors_default = /*#__PURE__*/__webpack_require__.n(external_ajv_errors_);
// EXTERNAL MODULE: external "ajv-formats"
var external_ajv_formats_ = __webpack_require__(26);
var external_ajv_formats_default = /*#__PURE__*/__webpack_require__.n(external_ajv_formats_);
// EXTERNAL MODULE: external "validator"
var external_validator_ = __webpack_require__(27);
var external_validator_default = /*#__PURE__*/__webpack_require__.n(external_validator_);
;// CONCATENATED MODULE: ../sdk/declarative/src/validation.ts




const ajv = new external_ajv_.Ajv({
    allErrors: true,
    useDefaults: 'empty',
    removeAdditional: 'failing',
    coerceTypes: true,
});
external_ajv_errors_default()(ajv);
external_ajv_formats_default()(ajv);
function isBetween(date, startDate, endDate) {
    if (!date) {
        return false;
    }
    if (!startDate) {
        return false;
    }
    if (!endDate) {
        return false;
    }
    return (external_validator_default().isAfter(date, startDate) && external_validator_default().isBefore(date, endDate));
}
const validations = [
    ['isBefore', (external_validator_default()).isBefore],
    ['isAfter', (external_validator_default()).isAfter],
    ['isBoolean', (external_validator_default()).isBoolean],
    ['isDate', (external_validator_default()).isDate],
    ['isNumeric', (external_validator_default()).isNumeric],
    ['isLatLong', (external_validator_default()).isLatLong],
    ['isMobilePhone', (external_validator_default()).isMobilePhone],
    ['isEmpty', (external_validator_default()).isEmpty],
    ['isDecimal', (external_validator_default()).isDecimal],
    ['isURL', (external_validator_default()).isURL],
    ['isEmail', (external_validator_default()).isEmail],
    ['isBetween', isBetween],
];
validations.forEach(([key, value]) => {
    const keyword = key;
    ajv.addKeyword({
        keyword: keyword,
        validate: (schema, data) => {
            if (schema === undefined || schema === null) {
                return false;
            }
            const func = value;
            return func.apply((external_validator_default()), [
                data,
                ...(Array.isArray(schema) ? schema : [schema]),
            ]);
        },
    });
});
function createSchema(properties) {
    const required = [];
    const requiredErrorMessages = {};
    for (const [key, value] of Object.entries(properties)) {
        if (value.required) {
            required.push(key);
        }
        if ('errorMessage' in value && 'required' in value.errorMessage) {
            // move the required error message from the property schema to the root schema
            // as the required keyword is not part of the property schema
            requiredErrorMessages[key] = value.errorMessage.required;
            delete value.errorMessage.required;
        }
    }
    const extendSchema = {};
    if (Object.keys(requiredErrorMessages).length) {
        extendSchema['errorMessage'] = {
            required: requiredErrorMessages,
        };
    }
    const clearProperties = Object.fromEntries(Object.entries(properties).map(([key, value]) => {
        const { required, ...rest } = value;
        return [key, rest];
    }));
    return {
        type: 'object',
        properties: clearProperties,
        required: required,
        additionalProperties: false,
        ...extendSchema,
    };
}
/**
 * Validate input against schema
 *
 * @param schema ajv augmented json-schema
 * @param input input to validate
 * @returns
 */
function validateInput(schema, input) {
    const validate = ajv.compile(schema);
    const valid = validate(input);
    if (!valid && validate.errors) {
        throw formatErrors(validate.errors);
    }
}
function formatErrors(errors, parent) {
    return errors.reduce((acc, it) => {
        if (it.keyword === 'errorMessage') {
            return {
                ...acc,
                ...formatErrors(it.params['errors'], it),
            };
        }
        const property = (it.instancePath || it.params['missingProperty'])
            .replace('.', '')
            .replace('/', '');
        return { ...acc, [property]: parent?.message || it.message || '' };
    }, {});
}

;// CONCATENATED MODULE: ../sdk/declarative/src/lib/workflow.ts






if (typeof process === 'undefined') {
    Object.defineProperty(self, 'process', {
        value: {
            env: {},
        },
    });
}
function experimental_wokflow(features) {
    //
}
// one major flaw is that it is hard to enfore all the required fields unless we created
// languge server that would validate the code
// in any case it's better to wait for users to say whether they like it or not
// experimental_workflow(
//   tag('tasks'),
//   trigger.http({ method: 'get', path: '/' }),
//   trigger.http(method('get'), path('/'), policy('public')),
//   action.search(
//     output('tasks'),
//     config(
//       useTable('tasks'),
//       limit(50),
//       pagination('deferred_joins'),
//       queryTerm('query'),
//     ),
//   ),
// ),
function workflow(name, config) {
    return {
        name,
        trigger: config.trigger,
        actions: {
            execute: action(config.execute, {
                inline: true,
            }),
        },
        tag: config.tag,
    };
}
workflow.rule = (({ node }, service) => {
    const reports = [];
    if (!Checker.isCallExpression(node)) {
        return reports;
    }
    const [name, config] = node.arguments;
    if (typeof name === 'string') {
        if (!name.trim().length) {
            reports.push({
                message: 'Workflow name must not be empty',
                span: node.span,
                node: name,
                severity: 'error',
            });
        }
        if (!service.isUniqueWorkflow(name)) {
            reports.push({
                message: `Workflow name "${name}" is already defined`,
                span: node.span,
                node: node,
                severity: 'error',
            });
        }
    }
    else {
        reports.push({
            message: 'Workflow name must be a string',
            span: node.span,
            node: name,
            severity: 'error',
        });
    }
    if (!Checker.isObjectExpression(config)) {
        reports.push({
            message: 'Workflow config must be an object',
            span: node.span,
            node: config,
            severity: 'error',
        });
    }
    return reports;
});
function defineTrigger(type, config) {
    return {
        type,
        config: config,
    };
}
var trigger;
(function (trigger) {
    function fromConfig(type, ...args) {
        const parts = type.split('.');
        let impl = parts.length ? trigger : defineTrigger;
        while (parts.length) {
            impl = impl[parts.shift()];
        }
        if (impl) {
            return impl(...args);
        }
        throw new Error(`Unknown trigger type: ${type}`);
    }
    trigger.fromConfig = fromConfig;
})(trigger || (trigger = {}));
(function (trigger) {
    function schedule(config) {
        return {
            type: 'node-cron-trigger',
            config: config,
            policies: [],
        };
    }
    trigger.schedule = schedule;
    schedule.rule = (() => {
        const reports = [];
        return reports;
    });
})(trigger || (trigger = {}));
(function (trigger_1) {
    function http(config) {
        const inputs = {};
        if (config.mapper) {
            const guard = config.mapper.toString();
            const project = new external_ts_morph_.Project({
                useInMemoryFileSystem: true,
            });
            const sourceFile = project.createSourceFile('index.ts', `const mapFn = ${guard}`);
            const triggerIdentifierText = 'trigger';
            const guardFunction = sourceFile
                .getVariableDeclarationOrThrow('mapFn')
                .getInitializerIfKindOrThrow(external_ts_morph_.SyntaxKind.ArrowFunction);
            const returnExpr = guardFunction.getFirstChildByKind(external_ts_morph_.SyntaxKind.ParenthesizedExpression) ??
                guardFunction.getFirstDescendantByKindOrThrow(external_ts_morph_.SyntaxKind.ReturnStatement);
            const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(external_ts_morph_.SyntaxKind.ObjectLiteralExpression);
            returnObjExpr.getProperties().forEach((prop) => {
                const propAssignment = prop.asKindOrThrow(external_ts_morph_.SyntaxKind.PropertyAssignment);
                const propName = propAssignment.getName();
                const propValue = propAssignment.getInitializerOrThrow();
                inputs[propName] = {
                    value: propValue
                        .getFullText()
                        .replaceAll(`${triggerIdentifierText}.`, ''),
                };
            });
        }
        return {
            type: 'http',
            config: config,
            policies: config.policies ?? [],
            inputs: inputs,
        };
    }
    trigger_1.http = http;
    trigger_1.httpConfigSchema = createSchema({
        policies: {
            type: 'array',
            items: {
                type: 'string',
            },
        },
        method: {
            type: 'string',
            enum: ['get', 'post', 'put', 'delete', 'patch'],
            required: true,
            errorMessage: {
                enum: 'Method must be one of the following: "get", "post", "put", "delete", "patch"',
                type: 'Method must be one of the following: "get", "post", "put", "delete", "patch"',
                required: 'Missing method',
            },
        },
        path: {
            type: 'string',
            required: true,
            pattern: '^/.*',
            errorMessage: {
                pattern: 'Path must start with "/"',
                required: 'Missing path',
            },
        },
    });
    http.rule = ((ast, service) => {
        const reports = [];
        if (!Checker.isCallExpression(ast.node)) {
            return reports;
        }
        const [config] = ast.node.arguments;
        if (Checker.isObjectExpression(config)) {
            const errors = getErrors(() => validateInput(trigger_1.httpConfigSchema, config)) ?? [];
            Object.values(errors).forEach((message) => {
                reports.push({
                    message,
                    span: ast.node.span,
                    node: ast.node,
                    severity: 'error',
                });
            });
            if (!errors.length) {
                // if config is valid
                const relatedFeature = service.getFeature(ast);
                const relatedWorkflow = service.getWorkflow(ast);
                if (!relatedWorkflow || !relatedFeature) {
                    return [];
                }
                const isDuplicate = service.duplicateWorkflowTriggerConfig(relatedWorkflow, (otherWorkflow, feature) => {
                    if (otherWorkflow.trigger.type !== 'http') {
                        return false;
                    }
                    const dub = normalizeWorkflowPath({
                        featureName: feature.name,
                        workflowTag: otherWorkflow.tag,
                        workflowPath: otherWorkflow.trigger.config['path'],
                        workflowMethod: otherWorkflow.trigger.config['method'],
                    }) ===
                        normalizeWorkflowPath({
                            featureName: relatedFeature.name,
                            workflowTag: relatedWorkflow.tag,
                            workflowPath: config['path'],
                            workflowMethod: config['method'],
                        });
                    return dub;
                });
                if (isDuplicate) {
                    reports.push({
                        message: 'Duplicate trigger config',
                        span: ast.node.span,
                        node: ast.node,
                        severity: 'error',
                    });
                }
            }
        }
        else {
            reports.push({
                message: 'Missing trigger config',
                span: ast.node.span,
                node: ast.node,
                severity: 'error',
            });
        }
        return reports;
    });
})(trigger || (trigger = {}));
(function (trigger) {
    function sse(config) {
        return {
            type: 'sse',
            inputs: {},
            config: config,
            policies: [],
        };
    }
    trigger.sse = sse;
    sse.rule = (() => {
        const reports = [];
        return reports;
    });
    function websocket(config) {
        return {
            type: 'sse',
            inputs: {},
            config: config,
            policies: [],
        };
    }
    trigger.websocket = websocket;
    websocket.rule = (() => {
        const reports = [];
        return reports;
    });
    // normal http streaming
    function stream(config) {
        return {
            type: 'sse',
            inputs: {},
            config: config,
            policies: [],
        };
    }
    trigger.stream = stream;
    stream.stream = (() => {
        const reports = [];
        return reports;
    });
})(trigger || (trigger = {}));
(function (trigger) {
    function github(config) {
        const inputs = {};
        if (config.mapper) {
            const guard = config.mapper.toString();
            const project = new external_ts_morph_.Project({
                useInMemoryFileSystem: true,
            });
            const sourceFile = project.createSourceFile('index.ts', `const mapFn = ${guard}`);
            const triggerIdentifierText = 'trigger';
            const guardFunction = sourceFile
                .getVariableDeclarationOrThrow('mapFn')
                .getInitializerIfKindOrThrow(external_ts_morph_.SyntaxKind.ArrowFunction);
            const returnExpr = guardFunction.getFirstChildByKind(external_ts_morph_.SyntaxKind.ParenthesizedExpression) ??
                guardFunction.getFirstDescendantByKindOrThrow(external_ts_morph_.SyntaxKind.ReturnStatement);
            const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(external_ts_morph_.SyntaxKind.ObjectLiteralExpression);
            returnObjExpr.getProperties().forEach((prop) => {
                const propAssignment = prop.asKindOrThrow(external_ts_morph_.SyntaxKind.PropertyAssignment);
                const propName = propAssignment.getName();
                const propValue = propAssignment.getInitializerOrThrow();
                inputs[propName] = {
                    value: propValue
                        .getFullText()
                        .replaceAll(`${triggerIdentifierText}.`, ''),
                };
            });
        }
        return {
            type: 'github-trigger',
            config: config,
            policies: config.policies ?? [],
            inputs: inputs,
        };
    }
    trigger.github = github;
    github.rule = (() => {
        const reports = [];
        return reports;
    });
})(trigger || (trigger = {}));
// trigger.event = (config: { name: string }): TriggerDefinition => {
//   return {
//     type: 'event',
//     config: config,
//   };
// };
// trigger.queue = (config: { name: string }): TriggerDefinition => {
//   return {
//     type: 'queue',
//     config: config,
//   };
// };
function policy(rule) {
    return rule;
}
function isLiteralObject(obj) {
    return obj !== null && typeof obj === 'object' && obj.constructor === Object;
}
function definePolicy(rule) {
    return (name) => rule;
}
(function (policy) {
    function fromConfig(type, ...args) {
        const parts = type.split('.');
        let impl = parts.length ? policy : definePolicy;
        while (parts.length) {
            impl = impl[parts.shift()];
        }
        if (impl) {
            return impl(...args);
        }
        if (type.endsWith('.rule')) {
            const reports = [];
            return reports;
        }
        throw new Error(`Unknown policy type: ${type}`);
    }
    policy.fromConfig = fromConfig;
    function authenticated() {
        // @trigger:subject.authenticated
        // @trigger:subject.name
        // @trigger:subject.claims
        // @trigger:subject.id
        // @trigger:anonymous
        // @trigger:authenticated
        // TODO: what about making the identity-auth extensions
        // parse this input?
        // return '@subject:authenticated';
        // FIXME: this have hard dependency on hono
        // we need a way to make the trigger return the types or the function signature
        return (name) => `
    import { Context } from 'hono';
    import { verifyToken } from './subject';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
    }
    policy.authenticated = authenticated;
    function http() {
        return () => '';
    }
    function github(config) {
        if (!config.events || !config.events.length || !config.guard) {
            return () => '';
        }
        const project = new external_ts_morph_.Project({
            useInMemoryFileSystem: true,
        });
        let body = 'return true';
        if (config.guard) {
            const guard = config.guard.toString();
            const sourceFile = project.createSourceFile('guard.ts', `const guard = ${guard}`);
            const guardFunction = sourceFile
                .getVariableDeclarationOrThrow('guard')
                .getInitializerOrThrow();
            // this fix allow user to return the value directly
            // or within a block.
            const isBlock = guardFunction.getBody().isKind(external_ts_morph_.SyntaxKind.Block);
            body = isBlock
                ? guardFunction.getBodyText()
                : `return ${guardFunction.getBodyText()}`;
        }
        return (name) => `
    import { EmitterWebhookEvent } from '@octokit/webhooks';
    import { isEventOfType } from '../core/github-webhooks';

    export async function ${name}(event: EmitterWebhookEvent) {
      if(isEventOfType(event, ${(config.events ?? []).map((it) => `'${it}'`).join(', ')})) {
        ${body}
      }
      return false;

  }`;
    }
    policy.github = github;
    github.rule = (() => {
        const reports = [];
        return reports;
    });
})(policy || (policy = {}));
// policy.guest = () => {
//   //
// }
policy.unstable_country = (country) => {
    // FIXME: but how I can still have the same endpoint but with different logic
    // for different countries?
    // using where expression here would be better
    // where('@trigger:context.country', 'equals', country)
    return `@trigger:context.country === '${country}'`;
};

;// CONCATENATED MODULE: ../sdk/declarative/src/index.ts









;// CONCATENATED MODULE: ../sdk/evaluator/src/lib/evaluate.ts


const callers = {
    project: project,
    table: table,
    feature: feature,
    workflow: workflow,
    trigger: trigger.fromConfig,
    action: action.fromConfig,
    field: field.fromConfig,
    policy: policy.fromConfig,
    validation: validation.fromConfig,
    mandatory: mandatory,
    required: required,
    unique: unique,
    useTable: useTable,
    useField: useField,
    query: query,
    select: query_select,
    sort: sort,
    where: where,
    limit: limit,
    and: and,
    or: or,
    input: input,
    index: index,
    withTrigger: (...args) => {
        // replace action.trigger with it just in case we don't replicate the same logic
    },
};
function call(node, parent = null, metadata) {
    if (Checker.isCallExpression(node)) {
        const [implFn, ...type] = node.caller.split('.');
        const callerImpl = callers[implFn];
        if (!callerImpl) {
            throw new Error(`Unknown caller ${node.caller}`);
        }
        const args = node.arguments.map((it) => call(it, node));
        if (type.length) {
            args.unshift(type.join('.'));
        }
        return callerImpl(...args);
    }
    if (Checker.isArrayExpression(node)) {
        return node.map((it) => call(it, node));
    }
    if (Checker.isObjectExpression(node)) {
        const obj = {};
        for (const [key, value] of Object.entries(node)) {
            if (metadata === 'actions') {
                obj[key] = call({
                    caller: 'action.trigger',
                    arguments: [value],
                }, node, key);
            }
            else {
                obj[key] = call(value, node, key);
            }
        }
        return obj;
    }
    return node;
}
function diagnose(service, ast) {
    const reports = [];
    if (Checker.isCallExpression(ast.node)) {
        const [implFn, ...type] = ast.node.caller.split('.');
        const callerImpl = callers[implFn];
        if (!callerImpl) {
            throw new Error(`Unknown caller ${ast.node.caller}`);
        }
        const args = [ast, service];
        reports.push(...ast.node.arguments.map((it) => diagnose(service, {
            parent: ast,
            node: it,
        })));
        if (type.length) {
            args.unshift([...type, 'rule'].join('.'));
            reports.push(...callerImpl(...args));
        }
        else {
            if ('rule' in callerImpl) {
                reports.push(...callerImpl.rule(...args));
            }
        }
        return reports;
    }
    if (Checker.isArrayExpression(ast.node)) {
        return ast.node.map((it) => diagnose(service, {
            parent: ast,
            node: it,
        }));
    }
    if (Checker.isObjectExpression(ast.node)) {
        for (const [key, value] of Object.entries(ast.node)) {
            reports.push(...diagnose(service, {
                parent: ast,
                node: value,
            }));
        }
        return reports;
    }
    return reports;
}
async function evaluate(code) {
    const ast = await parseDeclarative(code);
    if (!ast) {
        throw new Error('Failed to parse the code');
    }
    const features = call(ast.project);
    const service = {
        getFeature(descendantNode) {
            let parent = descendantNode.parent;
            while (parent) {
                if (Checker.isCallExpression(parent.node) &&
                    parent.node.caller === 'feature') {
                    return features.find((feature) => feature.name === parent.node.arguments[0]);
                }
                parent = parent.parent;
            }
            return void 0;
        },
        getWorkflow(descendantNode) {
            let parent = descendantNode.parent;
            while (parent) {
                if (Checker.isCallExpression(parent.node) &&
                    parent.node.caller === 'workflow') {
                    const feature = this.getFeature(parent);
                    const [workflowName] = parent.node.arguments;
                    return feature?.workflows.find((workflow) => workflow.name === workflowName);
                }
                parent = parent.parent;
            }
            return void 0;
        },
        duplicateWorkflowTriggerConfig: (relatedWorkflow, check) => {
            for (const feature of features) {
                for (const workflow of feature.workflows) {
                    if (workflow === relatedWorkflow) {
                        continue;
                    }
                    if (check(workflow, feature)) {
                        return true;
                    }
                }
            }
            return false;
        },
        hasField: (name) => features.some((feature) => Object.keys(feature.tables ?? {}).some((table) => Object.keys(feature.tables[table].fields).includes(name))),
        hasTable: (name) => features.some((feature) => {
            return (feature.tables ?? {})[name];
        }),
        inUniqueFeature: (name) => {
            let count = 0;
            for (const feature of features) {
                if (feature.name === name) {
                    count++;
                }
            }
            return count === 1;
        },
        isUniqueWorkflow: (name) => {
            for (const feature of features) {
                let count = 0;
                for (const workflow of feature.workflows) {
                    if (workflow.name === name) {
                        count++;
                    }
                }
                if (count > 1) {
                    return false;
                }
            }
            return true;
        },
        validateName(name, context) {
            const errors = [];
            // maybe use ajv here?
            if (typeof name !== 'string') {
                errors.push(`${context} must be a string`);
            }
            else if (name.trim().length === 0) {
                errors.push(`${context} must not be empty`);
            }
            return errors;
        },
    };
    const reports = diagnose(service, {
        parent: null,
        node: ast,
    }).flat(Infinity);
    return {
        reports,
        definition: {
            features,
            imports: ast.imports,
            extensions: {},
            name: '',
        },
    };
}
async function compare(a, b) {
    const removeSpans = (node) => {
        if (!node)
            return '';
        return JSON.stringify(node, (key, value) => {
            if (key === 'span') {
                return undefined;
            }
            return value;
        });
    };
    // const astA = await parseDeclarative(code);
    // const astB = call(b) as EmptyProject['features'];
    return (removeSpans((await parseDeclarative(a))?.project ?? null) ===
        removeSpans((await parseDeclarative(a))?.project ?? null));
}

;// CONCATENATED MODULE: ../sdk/evaluator/src/lib/infertype.ts


const noop = () => {
    //
};
const infertype_callers = {
    project: (...args) => {
        const [name, config] = args;
        return args[0];
    },
    feature: (...args) => {
        const [name, config] = args;
        return {
            workflows: config.workflows,
            tables: config.tables,
            featureName: name,
        };
    },
    table: table,
    field: field,
    workflow: workflow,
    trigger: trigger.fromConfig,
    action: action.fromConfig,
    useTable: noop,
    mandatory: noop,
    required: noop,
    unique: noop,
    useField: noop,
    query: noop,
    select: noop,
    sort: noop,
    where: noop,
    limit: noop,
    and: noop,
    or: noop,
    input: noop,
    index: noop,
};
function infertype_call(node, metadata, parent) {
    if (Checker.isCallExpression(node)) {
        const [implFn, ...type] = node.caller.split('.');
        const callerImpl = infertype_callers[implFn];
        if (!callerImpl) {
            throw new Error(`Unknown caller ${node.caller}`);
        }
        const args = node.arguments.map((it) => infertype_call(it));
        if (type.length) {
            args.unshift([...type, 'dts'].join('.'));
        }
        else {
            if ('dts' in callerImpl) {
                return callerImpl.dts(...args, metadata);
            }
        }
        return callerImpl(...args);
    }
    if (Checker.isArrayExpression(node)) {
        return node.map((it) => infertype_call(it));
    }
    if (Checker.isObjectExpression(node)) {
        const obj = {};
        for (const [key, value] of Object.entries(node)) {
            if (metadata === 'actions') {
                obj[key] = infertype_call({
                    caller: 'action.trigger',
                    arguments: [value],
                }, key);
            }
            else {
                obj[key] = infertype_call(value, key, node);
            }
        }
        return obj;
    }
    return node;
}
async function inferType(code) {
    const ast = await parseDeclarative(code);
    if (!ast) {
        return [];
    }
    const result = infertype_call(ast.project);
    return result;
}

;// CONCATENATED MODULE: ../sdk/evaluator/src/index.ts



;// CONCATENATED MODULE: ../compiler/generator/src/lib/output-analyser.ts

function getDefaultExport(code, project = new external_ts_morph_.Project({ useInMemoryFileSystem: true })) {
    const sourceFile = project.createSourceFile('index.ts', code);
    const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
    const exportAssignment = defaultExport.getValueDeclarationOrThrow();
    // assign default export to a variable
    return {
        value: exportAssignment.getExpression().getFullText(),
        sourceFile,
    };
}
function getReturnTypeOfDefaultExport(workflowOutput, project = new external_ts_morph_.Project({ useInMemoryFileSystem: true })) {
    const sourceFile = project.createSourceFile('index.ts', workflowOutput);
    const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
    const exportAssignment = defaultExport.getValueDeclarationOrThrow();
    const fn = exportAssignment.getFirstDescendantByKind(external_ts_morph_.SyntaxKind.ArrowFunction) ??
        exportAssignment.getFirstDescendantByKindOrThrow(external_ts_morph_.SyntaxKind.FunctionDeclaration);
    const returnStatement = fn.getFirstDescendantByKind(external_ts_morph_.SyntaxKind.ReturnStatement);
    const returnType = fn.getReturnType();
    if (!returnStatement) {
        return {
            properties: [],
            returnCode: '',
            returnTypeStr: '',
        };
    }
    const objectLiteral = returnStatement.getFirstChildByKind(external_ts_morph_.SyntaxKind.ObjectLiteralExpression);
    if (!objectLiteral) {
        throw new Error('Return statement should return an object literal');
    }
    return {
        returnTypeStr: returnType.getText(),
        // replace "steps" with "" to get the name of the property
        returnCode: returnStatement.getText().replace(/steps\./g, ''),
        properties: returnType.getProperties().map((it) => ({
            name: it.getName(),
            primitiveType: it.getValueDeclaration()?.getType().getText(),
            parameter: it
                .getValueDeclaration()
                ?.getFirstDescendantByKindOrThrow(external_ts_morph_.SyntaxKind.PropertyAccessExpression)
                ?.getText(),
        })),
    };
}
function assignDefaultExportToVar(code, varName, project = new external_ts_morph_.Project({ useInMemoryFileSystem: true })) {
    const { value, sourceFile } = getDefaultExport(code, project);
    const varStmt = sourceFile.addVariableStatement({
        declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
        declarations: [
            {
                name: varName,
                initializer: value,
            },
        ],
    });
    return varStmt.getFullText();
}

;// CONCATENATED MODULE: ../compiler/generator/src/lib/sourcecode.ts
var sourcecode_a;






// FIXME: should be fetched from the project preferences
const tsConfig = {
    compilerOptions: {
        sourceMap: true,
        target: 'ESNext',
        module: 'esnext',
        moduleResolution: 'node',
        declaration: false,
        types: ['node'],
        removeComments: true,
        strict: true,
        inlineSources: true,
        sourceRoot: '/',
        allowSyntheticDefaultImports: true,
        esModuleInterop: true,
        experimentalDecorators: true,
        emitDecoratorMetadata: true,
        importHelpers: true,
        noEmitHelpers: true,
        resolveJsonModule: true,
        skipLibCheck: true,
        skipDefaultLibCheck: true,
    },
};
function getMorph(generateDir) {
    const options = {
        compilerOptions: {
            ...tsConfig.compilerOptions,
            module: external_ts_morph_.ModuleKind.ESNext,
            moduleResolution: external_ts_morph_.ModuleResolutionKind.NodeJs,
            target: external_ts_morph_.ScriptTarget.ESNext,
        },
        skipFileDependencyResolution: false,
        skipAddingFilesFromTsConfig: true,
        useInMemoryFileSystem: !generateDir,
    };
    return new external_ts_morph_.Project(options);
}
let VirtualProject = class VirtualProject {
    _projectFS;
    #morphProject;
    constructor(_projectFS) {
        this._projectFS = _projectFS;
    }
    #resolveImports() {
        for (const sourceFile of this.#morphProject.getSourceFiles()) {
            const imports = sourceFile.getImportDeclarations();
            for (const it of imports) {
                let moduleSpecifier = it.getModuleSpecifierValue();
                if (!moduleSpecifier.startsWith('#{')) {
                    continue;
                }
                switch (true) {
                    case moduleSpecifier.startsWith('#{relative}'): {
                        const filePath = moduleSpecifier.replace('#{relative}/', '');
                        moduleSpecifier = (0,external_path_.relative)((0,external_path_.dirname)(addLeadingSlash(sourceFile.getFilePath())), addLeadingSlash(filePath));
                        // if file is in the same directory, add ./ to the path
                        if (!moduleSpecifier.startsWith('.')) {
                            moduleSpecifier = './' + moduleSpecifier;
                        }
                        it.setModuleSpecifier(moduleSpecifier);
                        break;
                    }
                    case moduleSpecifier.startsWith('#{entity}'): {
                        const entityName = moduleSpecifier.replace('#{entity}/', '');
                        const files = this.#morphProject.getSourceFiles('/**/src/features/**/*.entity.ts');
                        const filePath = this.#findClassSourceFile(files, entityName);
                        if (!filePath) {
                            throw new Error(`Entity ${entityName} file not found.`);
                        }
                        moduleSpecifier = (0,external_path_.relative)((0,external_path_.dirname)(addLeadingSlash(sourceFile.getFilePath())), addLeadingSlash(filePath));
                        // if file is in the same directory, add ./ to the path
                        if (!moduleSpecifier.startsWith('.')) {
                            moduleSpecifier = './' + moduleSpecifier;
                        }
                        it.setModuleSpecifier(moduleSpecifier);
                        break;
                    }
                }
            }
        }
    }
    #findClassSourceFile(files, className) {
        for (const sourceFile of files) {
            const classDeclaration = sourceFile.getClass(className);
            if (classDeclaration) {
                // remove leading slash and file ext
                const filePath = sourceFile.getFilePath();
                const extName = (0,external_path_.extname)(filePath);
                const noExt = filePath.slice(0, -extName.length);
                return noExt;
            }
        }
        // If the class wasn't found or wasn't imported, return null
        return null;
    }
    #exportRoutes() {
        // look for files that ends with .router
        const routerFiles = this.#morphProject.getSourceFiles(this._projectFS.routersGlob());
        const imports = [];
        const exportDefaults = [];
        for (const routerFile of routerFiles) {
            const fileName = routerFile.getBaseName();
            const defaultImportName = (0,external_stringcase_.camelcase)(fileName.replace('.ts', ''));
            imports.push(`import ${defaultImportName} from './${getLastNParts(routerFile.getFilePath(), 2, false)}'`);
            exportDefaults.push(defaultImportName);
        }
        // create routes.ts file
        this.#morphProject.createSourceFile(this._projectFS.makeFeaturePath('routes.ts'), `import { Hono } from 'hono';\n${imports.join('\n')}\n\nexport default [${exportDefaults.join(', ')}] as [string, Hono][]`, { overwrite: true });
    }
    #exportListeners() {
        // look for files that ends with .router
        const files = this.#morphProject.getSourceFiles(this._projectFS.listenersGlob());
        const imports = [];
        const exportDefaults = [];
        for (const routerFile of files) {
            const fileName = routerFile.getBaseName();
            const defaultImportName = (0,external_stringcase_.camelcase)(fileName.replace('.ts', ''));
            imports.push(`import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`);
            exportDefaults.push(defaultImportName);
        }
        // create listeners.ts file
        this.#morphProject.createSourceFile(this._projectFS.makeFeaturePath('listeners.ts'), `${imports.join('\n')}`, { overwrite: true });
    }
    #exportJobs() {
        // look for files that ends with .job
        const files = this.#morphProject.getSourceFiles(this._projectFS.cronsGlob());
        const imports = [];
        const exportDefaults = [];
        for (const routerFile of files) {
            const fileName = routerFile.getBaseName();
            const defaultImportName = (0,external_stringcase_.camelcase)(fileName.replace('.ts', ''));
            imports.push(`import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`);
            exportDefaults.push(defaultImportName);
        }
        // create crons.ts file
        this.#morphProject.createSourceFile(this._projectFS.makeFeaturePath('crons.ts'), `${imports.join('\n')}`, { overwrite: true });
    }
    #exportEntites() {
        // look for files that ends with .entites
        const routerFiles = this.#morphProject.getSourceFiles(this._projectFS.entitiesGlob());
        const imports = [];
        const exportDefaults = [];
        const tables = [];
        for (const entityFiles of routerFiles) {
            const fileName = entityFiles.getBaseName();
            const defaultImportName = (0,external_stringcase_.camelcase)(fileName.replace('.ts', ''));
            imports.push(`import ${defaultImportName} from './${getLastNParts(entityFiles.getFilePath(), 2, false)}'`);
            exportDefaults.push(defaultImportName);
            tables.push(`${(0,external_stringcase_.camelcase)(fileName.replace('.entity.ts', ''))}: ${defaultImportName}`);
        }
        // create entities.ts file
        this.#morphProject.createSourceFile(this._projectFS.makeFeaturePath('entites.ts'), `
      ${imports.join('\n')}
      const entites= [${exportDefaults.join(', ')}];

export const tables = {
  ${tables.join(',\n')}
} as const;
      export default entites;
      `, { overwrite: true });
    }
    #tuneImports(file) {
        const imports = file.getImportDeclarations();
        const uniqueImports = {};
        const uniqueTypeImports = {};
        for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
            const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
            uniqueTypeImports[moduleSpecifierValue] ??= {
                namedImports: new Map(),
                defaultImport: undefined,
                namespaceImport: undefined,
            };
            uniqueTypeImports[moduleSpecifierValue].defaultImport = importDeclaration
                .getDefaultImport()
                ?.getText();
            uniqueTypeImports[moduleSpecifierValue].namespaceImport =
                importDeclaration.getNamespaceImport()?.getText();
            importDeclaration.getNamedImports().forEach((item) => {
                uniqueTypeImports[moduleSpecifierValue].namedImports.set(item.getName(), item.getStructure());
            });
        }
        for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
            const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
            uniqueImports[moduleSpecifierValue] ??= {
                namedImports: new Map(),
                assertElements: new Map(),
                defaultImport: undefined,
                namespaceImport: undefined,
            };
            uniqueImports[moduleSpecifierValue].defaultImport = importDeclaration
                .getDefaultImport()
                ?.getText();
            uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration
                .getNamespaceImport()
                ?.getText();
            importDeclaration.getNamedImports().forEach((item) => {
                if (item.isTypeOnly()) {
                    uniqueTypeImports[moduleSpecifierValue] ??= {
                        namedImports: new Map(),
                    };
                    uniqueTypeImports[moduleSpecifierValue].namedImports.set(item.getName(), item.getStructure());
                }
                else {
                    uniqueImports[moduleSpecifierValue].namedImports.set(item.getName(), item.getStructure());
                }
            });
            importDeclaration
                .getAssertClause()
                ?.getElements()
                .forEach((item) => {
                uniqueImports[moduleSpecifierValue].assertElements.set(item.getName(), item.getStructure());
            });
        }
        imports.forEach((it) => {
            it.remove();
        });
        Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
            file.addImportDeclaration({
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: moduleSpecifier,
                namedImports: Array.from(it.namedImports.values()),
                assertElements: Array.from(it.assertElements.values()),
                defaultImport: it.defaultImport,
                isTypeOnly: false,
                namespaceImport: it.namespaceImport,
            });
        });
        Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
            file.addImportDeclaration({
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: moduleSpecifier,
                namedImports: Array.from(it.namedImports.values()),
                assertElements: [],
                defaultImport: it.defaultImport,
                isTypeOnly: true,
                namespaceImport: it.namespaceImport,
            });
        });
    }
    #removeUnusedImports(file) {
        const imports = file.getImportDeclarations();
        for (const importDeclaration of imports) {
            const isInjectImport = !importDeclaration.getImportClause();
            const isNamespaceImport = importDeclaration.getNamespaceImport();
            const defaultImport = importDeclaration.getDefaultImport();
            if (isInjectImport || isNamespaceImport || defaultImport) {
                continue;
            }
            const namedImports = importDeclaration.getNamedImports();
            for (const namedImport of namedImports) {
                const importedName = namedImport.getName();
                const isUsed = file
                    .getDescendantsOfKind(external_ts_morph_.SyntaxKind.Identifier)
                    .some((it) => it.getText() === importedName && it.getParent() !== namedImport);
                if (isUsed) {
                    continue;
                }
                namedImport.remove();
            }
            if (!importDeclaration.getNamedImports().length) {
                importDeclaration.remove();
            }
        }
    }
    #moveImportsToTop(file) {
        const imports = file.getImportDeclarations();
        imports.forEach((it, index) => {
            file.insertImportDeclaration(index, {
                moduleSpecifier: it.getModuleSpecifierValue(),
                namespaceImport: it.getNamespaceImport()?.getText(),
                namedImports: it.getNamedImports().map((namedImport) => ({
                    name: namedImport.getName(),
                    alias: namedImport.getAliasNode()?.getText(),
                })),
                defaultImport: it.getDefaultImport()?.getText(),
            });
        });
        imports.forEach((it) => it.remove());
    }
    generate(concreteStructure, generateDir) {
        this.#morphProject = getMorph(generateDir);
        const sourceFiles = {};
        for (const feature of concreteStructure.features) {
            feature.structures.forEach((it) => {
                sourceFiles[it.filePath] ??= this.#morphProject.createSourceFile(it.filePath, '', {
                    overwrite: true,
                });
                const structure = 'actionStructure' in it.structure
                    ? [
                        ...it.structure.actionStructure,
                        ...it.structure.topLevelStructure,
                    ]
                    : it.structure;
                sourceFiles[it.filePath].addStatements(structure);
            });
            for (const table of feature.tables) {
                const entityfile = this.#morphProject.createSourceFile(this._projectFS.makeEntityPath(feature.displayName, table.tableName, 'entity'), '', { overwrite: true });
                entityfile.addStatements(table.entityStructure);
                for (const contract of table.fields) {
                    entityfile
                        .getClassOrThrow(contract.tableName)
                        .addProperty(contract.fieldStructure);
                    entityfile.addStatements(contract.topLevelStructure);
                }
            }
            for (const workflow of feature.workflows ?? []) {
                workflow.forEach((it) => {
                    sourceFiles[it.filePath] ??= this.#morphProject.createSourceFile(it.filePath, '', { overwrite: true });
                    const structure = 'actionStructure' in it.structure
                        ? [
                            ...it.structure.actionStructure,
                            ...it.structure.topLevelStructure,
                        ]
                        : it.structure;
                    sourceFiles[it.filePath].addStatements(structure);
                });
            }
        }
        for (const policy of concreteStructure.policies) {
            policy.forEach((policy) => {
                sourceFiles[policy.filePath] ??= this.#morphProject.createSourceFile(policy.filePath, '', {
                    overwrite: true,
                });
                const structure = 'actionStructure' in policy.structure
                    ? (() => {
                        return [
                            ...policy.structure.actionStructure,
                            ...policy.structure.topLevelStructure,
                        ];
                    })()
                    : policy.structure;
                sourceFiles[policy.filePath].addStatements(structure);
            });
        }
        for (const it of concreteStructure.setup) {
            const sourceFile = this.#morphProject.getSourceFile(it.filePath) ??
                this.#morphProject.createSourceFile(it.filePath, '', {
                    overwrite: true,
                });
            if (it.filePath.endsWith('.ts')) {
                sourceFile.removeStatements([0, sourceFile.getStatements().length]);
            }
            sourceFile.addStatements(it.content);
        }
    }
    getOutput() {
        this.#resolveImports();
        this.#exportEntites();
        this.#exportListeners();
        this.#exportJobs();
        this.#exportRoutes();
        const morphFiles = this.#morphProject.getSourceFiles();
        const files = morphFiles.map((file) => {
            if (file.getFilePath().endsWith('.ts')) {
                this.#tuneImports(file);
                this.#moveImportsToTop(file);
                this.#removeUnusedImports(file);
            }
            // if (file.getFilePath().endsWith('.ts')) {
            //   file.fixMissingImports(); // FIXME: remove this because it's so slow
            // }
            // file.organizeImports();
            // NOTE: SourceFile.formatText() duplicates code so don't user it
            return {
                path: file.getFilePath(),
                content: file.getFullText(),
            };
        });
        return files;
    }
    cleanup() {
        this.#morphProject.getSourceFiles().forEach((file) => {
            file.forget();
        });
    }
    async emit(before) {
        await Promise.all(this.#morphProject.getSourceFiles().map((file) => before?.(file)));
        return this.#morphProject.save();
    }
};
VirtualProject = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (sourcecode_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? sourcecode_a : Object])
], VirtualProject);

function getLastNParts(path, n, withExt = true) {
    const result = path.split(external_path_.sep).slice(-n).join(external_path_.sep);
    return withExt ? result : result.replace((0,external_path_.extname)(result), '');
}
function emitFiles(concreteStructure, projectFS, generateDir) {
    const vProject = new VirtualProject(projectFS);
    vProject.generate(concreteStructure, generateDir);
    return {
        files: vProject.getOutput(),
        save: () => vProject.emit(),
        cleanup: () => vProject.cleanup(),
    };
}
function emitFilesNoConfig(concreteStructure, generateDir) {
    const projectFs = external_tiny_injector_.Injector.GetRequiredService(ProjectFS);
    const projectConfig = external_tiny_injector_.Injector.GetRequiredService(ProjectConfig);
    const vProject = new VirtualProject(projectFs);
    if (generateDir) {
        const config = projectConfig.getConfig();
        projectConfig.updateConfig({
            basePath: (0,external_path_.join)(generateDir, config.basePath),
            features: (0,external_path_.join)(generateDir, config.features),
        });
    }
    vProject.generate(concreteStructure, generateDir);
    return {
        files: vProject.getOutput(),
        save: () => vProject.emit(),
        cleanup: () => vProject.cleanup(),
    };
}

;// CONCATENATED MODULE: ../compiler/generator/src/emitter.ts



// EXTERNAL MODULE: external "fs/promises"
var promises_ = __webpack_require__(1);
;// CONCATENATED MODULE: ../compiler/core/src/lib/registry/abstract-input-parser.ts


let AbstractInputParser = class AbstractInputParser {
};
AbstractInputParser = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], AbstractInputParser);


;// CONCATENATED MODULE: ../compiler/core/src/lib/ajax/ajax.extension.ts
var ajax_extension_a;



let AjaxExtension = class AjaxExtension {
    _devKit;
    constructor(_devKit) {
        this._devKit = _devKit;
    }
    async processAction(action, helpers, inputs, transfer) {
        return {
            inline: false,
            structure: {
                topLevelStructure: [],
                actionStructure: [
                    (writer) => writer.writeLine(`const ${action.output.displayName} = await fetch("${inputs['url'].value}", {
              method: "${inputs['method'].value}",
              body: JSON.stringify(${this._devKit.toLiteralObject(transfer['body'])})
            }).then((res) => res.json())`),
                ],
            },
        };
    }
    handleField(input) {
        throw new Error('Method not implemented.');
    }
    async handleAction(contract) {
        const { body, ...rest } = contract.details;
        return {
            runtimeInputs: {
                ...Object.entries(rest)
                    .map(([name, input]) => ({ [name]: { input } }))
                    .reduce((acc, it) => ({ ...acc, ...it }), {}),
                ...flatJson(JSON.parse(body ?? '{}')),
            },
            transfer: { body: JSON.parse(body ?? '{}') },
        };
    }
    async handleSetup(contract) {
        return [];
    }
};
AjaxExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (ajax_extension_a = typeof DevKit !== "undefined" && DevKit) === "function" ? ajax_extension_a : Object])
], AjaxExtension);

function flatJson(json) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    return Object.entries(json).reduce(
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    (acc, [name, prop]) => {
        if (typeof prop === 'object' && 'input' in prop) {
            return {
                ...acc,
                [name]: prop,
            };
        }
        return {
            ...acc,
            ...flatJson(prop),
        };
    }, {});
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/core/ajv.txt
/* harmony default export */ const core_ajv = ("import type { ErrorObject, JSONSchemaType } from 'ajv';\nimport Ajv from 'ajv';\nimport addErrors from 'ajv-errors';\nimport addFormats from 'ajv-formats';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport validator from 'validator';\n\nconst ajv = new Ajv({\n  allErrors: true,\n  useDefaults: 'empty',\n  removeAdditional: 'failing',\n  coerceTypes: true,\n});\n\naddErrors(ajv);\naddFormats(ajv);\nfunction isBetween(date: string, startDate: string, endDate: string) {\n  if (!date) {\n    return false;\n  }\n  if (!startDate) {\n    return false;\n  }\n  if (!endDate) {\n    return false;\n  }\n\n  return (\n    validator.isAfter(date, startDate) && validator.isBefore(date, endDate)\n  );\n}\ntype Input<T> =\n  T extends Record<infer K, any>\n    ? {\n        [P in K]: unknown;\n      }\n    : never;\nconst validations = [\n  ['isBefore', validator.isBefore],\n  ['isAfter', validator.isAfter],\n  ['isBoolean', validator.isBoolean],\n  ['isDate', validator.isDate],\n  ['isNumeric', validator.isNumeric],\n  ['isLatLong', validator.isLatLong],\n  ['isMobilePhone', validator.isMobilePhone],\n  ['isEmpty', validator.isEmpty],\n  ['isDecimal', validator.isDecimal],\n  ['isURL', validator.isURL],\n  ['isEmail', validator.isEmail],\n  ['isBetween', isBetween],\n];\n\nvalidations.forEach(([key, value]) => {\n  const keyword = key as string;\n  ajv.addKeyword({\n    keyword: keyword,\n    validate: (schema: any, data: any) => {\n      if (schema === undefined || schema === null) {\n        return false;\n      }\n      const func = value as any;\n      return func.apply(validator, [\n        data,\n        ...(Array.isArray(schema) ? schema : [schema]),\n      ]);\n    },\n  });\n});\n\nexport function createSchema<T>(\n  properties: Record<\n    keyof T,\n    JSONSchemaType<any> & {\n      required?: boolean;\n    }\n  >,\n): JSONSchemaType<T> {\n  const required: string[] = [];\n  const requiredErrorMessages: Record<string, string> = {};\n\n  for (const [key, value] of Object.entries(properties) as any[]) {\n    if (value.required) {\n      required.push(key);\n    }\n    if ('errorMessage' in value && value.errorMessage?.required) {\n      // move the required error message from the property schema to the root schema\n      // as the required keyword is not part of the property schema\n      requiredErrorMessages[key] = value.errorMessage.required;\n      delete value.errorMessage.required;\n    }\n  }\n  const extendSchema: Record<string, unknown> = {};\n  if (Object.keys(requiredErrorMessages).length) {\n    extendSchema['errorMessage'] = {\n      required: requiredErrorMessages,\n    };\n  }\n\n  const clearProperties = Object.fromEntries(\n    (Object.entries(properties) as any[]).map(([key, value]) => {\n      const { required, ...rest } = value;\n      return [key, rest];\n    }),\n  );\n\n  return {\n    type: 'object',\n    properties: clearProperties,\n    required: required,\n    additionalProperties: false,\n    ...extendSchema,\n  } as JSONSchemaType<T>;\n}\n\n/**\n * Validate input against schema\n *\n * @param schema ajv augmented json-schema\n * @param input input to validate\n * @returns\n */\nexport function validateInput<T>(\n  schema: JSONSchemaType<T>,\n  input: Record<keyof T, unknown>,\n): asserts input is T {\n  const validate = ajv.compile(schema);\n  const valid = validate(input);\n  if (!valid && validate.errors) {\n    throw formatErrors(validate.errors);\n  }\n}\n\nfunction formatErrors(\n  errors: ErrorObject<string, Record<string, any>, unknown>[],\n  parent?: ErrorObject<string, Record<string, any>, unknown>,\n): ErrorObject<string, Record<string, any>, unknown> {\n  return errors.reduce(\n    (acc, it) => {\n      if (it.keyword === 'errorMessage') {\n        return {\n          ...acc,\n          ...formatErrors(it.params['errors'], it),\n        };\n      }\n\n      const property = (it.instancePath || it.params['missingProperty'])\n        .replace('.', '')\n        .replace('/', '');\n      return { ...acc, [property]: parent?.message || it.message || '' };\n    },\n    {} as ErrorObject<string, Record<string, any>, unknown>,\n  );\n}\n\nexport class ValidationFailedException extends ProblemDetailsException {\n  constructor(errors: Record<string, string>) {\n    super({\n      type: 'validation-failed',\n      status: 400,\n      title: 'Bad Request.',\n      detail: 'Validation failed.',\n    });\n    this.Details.errors = errors;\n  }\n}\n\nexport function validateOrThrow<T>(\n  schema: JSONSchemaType<T>,\n  input: Record<keyof T, unknown>,\n): asserts input is T {\n  try {\n    validateInput(schema, input);\n  } catch (errors: any) {\n    throw new ValidationFailedException(errors);\n  }\n}\n");
;// CONCATENATED MODULE: ../compiler/contracts/src/contract.ts





var Contracts;
(function (Contracts) {
    function fffffff(input) {
        const [namespace, value] = input.split(':');
        return {
            namespace,
            value,
        };
    }
})(Contracts || (Contracts = {}));
function makeSchema(property) {
    const result = {};
    (property.validations ?? [])
        .filter((validation) => validation.type !== 'unique')
        .map((validation) => {
        const validationType = validation.type;
        if (!validationType) {
            throw new Error(`Validation ${validation.id} not found.`);
        }
        if (validation.details['message']) {
            result['errorMessage'] = validation.details['message'];
        }
        switch (validationType) {
            case 'mandatory':
                result['required'] = true;
                if (property.type === 'string') {
                    result['minLength'] ??= 1; // it might already been set by minlength validation
                }
                break;
            case 'string':
                // result.type = 'string';
                break; // FIXME: remove string validation and depends on the primitive type
            case 'number':
                result['type'] = 'number';
                break;
            case 'oneof':
                result['type'] = 'string';
                result['enum'] = validation.details['value'];
                break;
            case 'email':
                result['type'] = 'string';
                result['format'] = 'email';
                result['isEmail'] = [];
                break;
            case 'minlength':
                result['type'] = 'string';
                result['minLength'] = validation.details['value'];
                break;
            case 'maxlength':
                result.type = 'string';
                result.maxLength = validation.details['value'];
                break;
            case 'min':
                result.minLength = undefined;
                result.type = 'number';
                result.minimum = validation.details['value'];
                break;
            case 'max':
                result.type = 'number';
                result.maximum = validation.details['value'];
                break;
            case 'pattern':
                result.type = 'string';
                result.regex = validation.details['value'];
                break;
            case 'url':
                result.type = 'string';
                result.format = 'uri';
                result['isURL'] = [];
                break;
            case 'uuid':
                result.type = 'string';
                result.format = 'uuid';
                break;
            case 'startswith':
                result.type = 'string';
                result.pattern = `^${validation.details['value']}`;
                break;
            case 'endswith':
                result.type = 'string';
                result.pattern = `${validation.details['value']}$`;
                break;
            case 'contains':
                result.type = 'string';
                result.pattern = validation.details['value'];
                break;
            case 'before':
                // TODO: should the format be date-time or date or time? I guess based on the field type it should be decided
                result.type = 'string';
                result['isBefore'] = [validation.details['value']];
                break;
            case 'after':
                // TODO: should the format be date-time or date or time? I guess based on the field type it should be decided
                result.type = 'string';
                result['isAfter'] = [validation.details['value']];
                break;
            case 'boolean':
                result.type = 'boolean';
                break;
            case 'date':
                result.type = 'string';
                result.format = 'date';
                break;
            case 'datetime':
                result.type = 'string';
                result.format = validation.details['value'];
                break;
            case 'time':
                result.type = 'string';
                result.format = validation.details['value'];
                break;
            case 'tel':
                result['isMobilePhone'] = ['any'];
                break;
            case 'longitude':
            case 'latitude':
                result.type = 'string';
                result['isLatLong'] = [];
                break;
            case 'ip':
                result.type = 'string';
                result.format = validation.details['value'];
                break;
            case 'decimal':
                result.type = 'string';
                result.format = 'double';
                result.multipleOf = 1 / Math.pow(10, +validation.details['value']);
                break;
            default:
                throw new Error(`Validation ${validationType} not supported.`);
        }
    });
    return result;
}
function isActionProperty(property) {
    return property.name && property.namespace;
}
function createSwitch(cases, fallback) {
    const project = new external_ts_morph_.Project({
        useInMemoryFileSystem: true,
    });
    const sourceFile = project.createSourceFile('index.ts');
    const fn = sourceFile.addFunction({
        name: 'myFunction',
        parameters: [{ name: 'value', type: 'string' }],
        returnType: 'void',
        isExported: true,
    });
    const [switchStmt] = fn.addStatements((writer) => writer.write(external_dedent_default()(`switch (true) {
        ${cases.map((it) => `case ${it.condition}:`).join('\n')}
        ${fallback ? 'default:' : ''}
        }`)));
    const clauses = switchStmt.getClauses();
    for (let index = 0; index < cases.length; index++) {
        clauses[index].addStatements(Array.isArray(cases[index].logic)
            ? [...cases[index].logic, 'break;']
            : [cases[index].logic, 'break;']);
    }
    if (fallback && fallback.logic) {
        clauses
            .at(-1)
            ?.addStatements(Array.isArray(fallback.logic)
            ? [...fallback.logic, 'break;']
            : [fallback.logic, 'break;']);
    }
    return [switchStmt.getFullText()];
}
function createIfElse(defaultCase, fallback) {
    const project = new external_ts_morph_.Project({
        useInMemoryFileSystem: true,
    });
    const sourceFile = project.createSourceFile('index.ts');
    const fn = sourceFile.addFunction({
        name: 'myFunction',
        parameters: [{ name: 'value', type: 'string' }],
        returnType: 'void',
        isExported: true,
    });
    const [ifStmt] = fn.addStatements((writer) => writer.write(external_dedent_default()(`
        if(${defaultCase.condition}) {}
        ${fallback ? 'else {}' : ''}
      `)));
    ifStmt.getThenStatement().addStatements(defaultCase.logic);
    if (fallback && fallback.logic) {
        ifStmt.getElseStatement().addStatements(fallback.logic);
    }
    return [ifStmt.getFullText()];
}
function createArrowFn(name, params, body) {
    // FIXME: don't use morph here because it can take up huge amount of memory
    // figure out a way to return this as structure.
    const project = new external_ts_morph_.Project({
        useInMemoryFileSystem: true,
    });
    const sourceFile = project.createSourceFile('index.ts');
    const varFnStm = sourceFile.addVariableStatement({
        declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
        declarations: [
            {
                name: name,
                initializer: 'async () => {}',
            },
        ],
    });
    const [declaration] = varFnStm.getDeclarations();
    const arrowFn = declaration.getInitializerOrThrow();
    for (const stmt of body) {
        arrowFn.addStatements(stmt);
        arrowFn.addParameters(params);
    }
    return varFnStm.getFullText();
}
function useInput(parsedInput) {
    if (!parsedInput) {
        return undefined;
    }
    return parsedInput.data?.['parameterName'] ?? parsedInput.value;
}
async function generateValidationContract(validations) {
    const result = [];
    const devKit = external_tiny_injector_.Injector.GetRequiredService(DevKit);
    for (const validation of validations) {
        const sourceValidation = await devKit.getValidationById(validation.sourceId);
        result.push({
            id: validation.sourceId,
            details: validation.details,
            name: sourceValidation.name,
            type: sourceValidation.type,
        });
    }
    return result;
}
function nonStatic(inputs) {
    return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
function signutureInputs(inputs, predicate = ([, prop]) => !prop.data?.['local']) {
    const unique = uniquify(nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])), ([name, prop]) => paramName([name, prop]));
    return unique.map(([name, prop]) => {
        return [paramName([name, prop]), prop];
    });
}
function paramName([name, prop]) {
    return prop.data?.['parameterName'] || name;
}

;// CONCATENATED MODULE: ../compiler/contracts/src/index.ts




;// CONCATENATED MODULE: ../compiler/core/src/lib/core/core.extension.ts
var core_extension_a, core_extension_b, core_extension_c;








let CoreExtension = class CoreExtension {
    _devKit;
    _context;
    _projectFS;
    constructor(_devKit, _context, _projectFS) {
        this._devKit = _devKit;
        this._context = _context;
        this._projectFS = _projectFS;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeCorePath('validation.ts'),
                content: [core_ajv],
            },
        ];
    }
    handleInput(input) {
        const visitor = new core_extension_SimpleVisitor();
        const { namespace, value } = visitor.visit(parseDsl(input));
        return this.handleInputV2({ namespace, value });
    }
    async handleInputV2(detail) {
        const visitor = new CoreInputVisitor();
        switch (true) {
            case detail.namespace.startsWith('process'): {
                const result = await visitor.visit(detail.value);
                return {
                    type: 'string',
                    static: true,
                    value: `process.${result}`,
                };
            }
            case detail.namespace.startsWith('build'): {
                const result = await visitor.visit(detail.value);
                return {
                    type: 'string',
                    static: true,
                    // we might need to introduce "secrets" and "env" wheres
                    // secrets refer to github/gitlab secrets and env refers to
                    // env in workflow scope.
                    value: this._devKit.substring(result, 'secrets.'),
                };
            }
            case detail.namespace.startsWith('fixed'): {
                const result = await visitor.visit(detail.value);
                return {
                    type: 'string',
                    value: result,
                    static: true,
                };
            }
            case detail.namespace.startsWith('path'): {
                const result = await visitor.visit(detail.value);
                return {
                    type: 'string',
                    value: 'result',
                    data: {
                        parameterName: result,
                        local: true,
                    },
                    static: true,
                };
            }
            case detail.namespace.startsWith('workflow'):
                const result = await visitor.visit(detail.value);
                return {
                    // TODO: types should be passed from typer
                    type: 'any',
                    value: result,
                    data: {
                        parameterName: result,
                        local: true,
                    },
                    static: false,
                };
            default:
                return null;
        }
    }
    async extractInputs({ namespace, value, visit, }) {
        return null;
    }
    async #evaulate(paths, action, helpers) {
        const emits = [];
        const visitor = new ContextAwareVisitor(this._context);
        const cases = [];
        const fallbackCase = { condition: '', logic: '' };
        const pathsNames = [];
        for (const path of paths) {
            const realtedAction = action.children.find((it) => it.data['handle'] === path.id);
            const result = realtedAction
                ? helpers.resolveAction(realtedAction.id)
                : '';
            if (path.name === 'fallback') {
                fallbackCase.logic = result || '';
            }
            else {
                const evaluatedRule = await visitor.start(parseDsl(path.rule), {
                    emit: (input) => {
                        emits.push(input);
                    },
                });
                const name = (0,external_stringcase_.camelcase)(path.name.replace(' ', '_'));
                pathsNames.push(`const ${name} = ${evaluatedRule};`);
                cases.push({
                    condition: name,
                    logic: result || '',
                });
            }
        }
        return { emits, cases, fallbackCase, pathsNames };
    }
    async processAction(action, helpers, runtimeInputs, transfer) {
        switch (action.sourceAction.name) {
            case 'branch':
                const { cases, fallbackCase, emits, pathsNames } = await this.#evaulate(transfer['paths'], action, helpers);
                const useSwitch = cases.length > 1;
                return {
                    inline: !useSwitch,
                    structure: {
                        topLevelStructure: emits.flat(),
                        actionStructure: [
                            ...pathsNames,
                            ...(useSwitch
                                ? createSwitch(cases, fallbackCase)
                                : createIfElse(cases[0], fallbackCase)),
                        ],
                    },
                };
            case 'custom-code':
                return {
                    inline: !!transfer['inline'],
                    structure: {
                        topLevelStructure: [...(transfer['structures'] ?? [])],
                        actionStructure: [transfer['code']],
                    },
                };
            default:
                throw new Error(`Action ${action.sourceAction.name} is not supported`);
        }
    }
    async handleAction(contract) {
        switch (contract.sourceAction.name) {
            case 'branch':
                const inputParser = external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
                const paths = contract.details['paths'].filter((it) => it.name !== 'fallback');
                let inputs = {};
                for (const path of paths) {
                    const result = await inputParser.toInputs(path.rule);
                    inputs = {
                        ...inputs,
                        ...result,
                    };
                }
                return {
                    transfer: {
                        ...contract.details,
                    },
                    runtimeInputs: inputs,
                    output: {
                        displayName: '',
                    },
                };
            case 'custom-code':
                return {
                    transfer: {
                        code: contract.details['code'],
                        inline: contract.details['inline'],
                        structures: contract.details['structures'],
                    },
                    runtimeInputs: contract.details['inputs'],
                    output: {
                        displayName: '',
                    },
                };
            default:
                throw new Error(`Action ${contract.sourceAction.name} is not supported`);
        }
    }
    async handleField(input) {
        throw new Error('Method not implemented.');
    }
};
CoreExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (core_extension_a = typeof DevKit !== "undefined" && DevKit) === "function" ? core_extension_a : Object, typeof (core_extension_b = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? core_extension_b : Object, typeof (core_extension_c = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? core_extension_c : Object])
], CoreExtension);

class CoreInputVisitor extends StringAsyncVisitor {
    visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        const accessor = await node.name.accept(this);
        const accessee = await node.expression.accept(this);
        return `${accessor}.${accessee}`;
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visit(node) {
        return node.accept(this);
    }
}
class core_extension_SimpleVisitor extends StringVisitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.accept(this),
            value: node.expression,
        };
    }
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/firebase/auth/firebase-app-setup.txt
/* harmony default export */ const firebase_app_setup = ("import { cert, initializeApp } from 'firebase-admin/app';\nimport type { GoogleServiceAccount } from './service-account';\n\nconst rawServiceAccount = process.env['FIREBASE_AUTH_SERVICE_ACCOUNT_KEY'];\n\nif(!rawServiceAccount) {\n  throw new Error('FIREBASE_AUTH_SERVICE_ACCOUNT_KEY is not set');\n}\n\nconst serviceAccount: GoogleServiceAccount = JSON.parse(Buffer.from(rawServiceAccount, 'base64').toString('ascii'));\n\nexport const firebaseApp = initializeApp({\n  credential: cert({\n    clientEmail: serviceAccount.client_email,\n    privateKey: serviceAccount.private_key,\n    projectId: serviceAccount.project_id,\n  }),\n  projectId: serviceAccount.project_id,\n  serviceAccountId: serviceAccount.client_email,\n});\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/firebase/auth/service-account-interface.txt
/* harmony default export */ const service_account_interface = ("export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/firebase/auth/subject.txt
/* harmony default export */ const subject = ("import { DecodedIdToken, getAuth } from \"firebase-admin/auth\";\nimport { IncomingMessage } from 'http';\nimport { getClientIp } from 'request-ip';\nimport UAParser, { IResult } from 'ua-parser-js';\nimport { firebaseApp } from '../core/firebase';\nimport { ProblemDetails, ProblemDetailsException } from 'rfc-7807-problem-details';\n\nexport interface ClientInfo {\n  ip?: string | null;\n  userAgent?: string | null;\n  userAgentData: IResult;\n}\n\nexport type IdentitySubject = {\n  claims: DecodedIdToken;\n};\n\nfunction isBearerToken(token: string | null | undefined): token is `Bearer ${string}` {\n  if (!token || typeof token !== 'string') {\n    return false;\n  }\n\n  if (!token.startsWith('Bearer ')) {\n    return false;\n  }\n\n  return true;\n}\n\nexport async function verifyToken(token: string | null | undefined): Promise<boolean> {\n  if (!isBearerToken(token)) {\n    throw new ProblemDetailsException(\n      new ProblemDetails('unauthorized', 'Unauthorized',401, 'Authorization header is missing or invalid'),\n    );\n  }\n\n  try {\n    await getAuth(firebaseApp).verifyIdToken(\n      token.replace('Bearer ', '')\n    );\n    return true;\n  } catch (error) {\n    return false;\n  }\n}\n\nexport async function loadSubject(\n  token: string | null | undefined,\n): Promise<IdentitySubject | null> {\n  if (!isBearerToken(token)) {\n    return null;\n  }\n\n  try {\n    const claims = await getAuth(firebaseApp).verifyIdToken(token);\n    return {claims}\n  } catch (error) {\n    return null;\n  }\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/firebase/auth/firebase-auth.extension.ts
var firebase_auth_extension_a;






// FIXME: we need some kind of extension info pulling strategy
// isAuthenicated function needs to know about the trigger context
// so I need the routing extension to tell me that
// hey I have these arguments and this is their types
// or just make adapter for the middleware context to generic web context
// the adapter will be exposed from routing extension
// but how will the adapter be used? I don't want to use
// it directly over the middlewares unless I do it in the "authorize" function
// FIXME: how to make policies return different error responses?
// isPublished policy should return 400
// isAuthenticated policy should return 401
// isEgypt policy should return 403
let FirebaseAuthExtension = class FirebaseAuthExtension {
    _projectFS;
    constructor(_projectFS) {
        this._projectFS = _projectFS;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeCorePath('service-account.ts'),
                content: [service_account_interface],
            },
            {
                filePath: this._projectFS.makeCorePath('firebase.ts'),
                content: [firebase_app_setup],
            },
            {
                filePath: this._projectFS.makeIdentityPath('subject.ts'),
                content: [subject],
            },
        ];
    }
};
FirebaseAuthExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (firebase_auth_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? firebase_auth_extension_a : Object])
], FirebaseAuthExtension);

// Auth level
// over workflow
// over step in workflow
// over field in step (I can't imagine it)

// EXTERNAL MODULE: external "js-yaml"
var external_js_yaml_ = __webpack_require__(28);
var external_js_yaml_default = /*#__PURE__*/__webpack_require__.n(external_js_yaml_);
;// CONCATENATED MODULE: ../compiler/core/src/lib/firebase/firebase-functions/firebase-functions.extension.ts
var firebase_functions_extension_a, firebase_functions_extension_b;




let FirebaseFunctionsExtension = class FirebaseFunctionsExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeWorkspacePath('.github/workflows/deploy.yml'),
                content: [
                    deployContent(contract['FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY'].value, contract['FIREBASE_FUNCTION_PROJECT_ID'].value),
                ],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('firebase.json'),
                content: [
                    this._devKit.toJson({
                        functions: [
                            {
                                ignore: ['**/node_modules/**', '**/src/**', '**/public/**'],
                                codebase: 'faslh',
                                source: 'dist',
                                runtime: 'nodejs16',
                            },
                        ],
                    }),
                ],
            },
            {
                filePath: this._projectFS.makeSrcPath('firebase-functions.ts'),
                content: [
                    `
		import * as functions from 'firebase-functions';
		import application from './main';
		exports.api = functions.https.onRequest(application.callback());
		exports.hello = functions.https.onRequest((req, res) => {
			res.json({ result: 'Hello from Firebase!' });
		});
		`,
                ],
            },
        ];
    }
};
FirebaseFunctionsExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (firebase_functions_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? firebase_functions_extension_a : Object, typeof (firebase_functions_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? firebase_functions_extension_b : Object])
], FirebaseFunctionsExtension);

const deployContent = (serviceAccountKey, projectId) => {
    const sendStatusStep = (steps) => ({
        uses: 'fjogeleit/http-request-action@v1',
        if: '${{ always() }}',
        with: {
            url: '${{ env.FASLH_API_URL }}',
            method: 'POST',
            data: JSON.stringify({
                jobName: '${{ github.job }}',
                correlationId: '${{ github.event.inputs.correlationId }}',
                statuses: steps.map((step) => ({
                    step,
                    status: `\${{ steps.${step}.outcome }}`,
                })),
            }, null, 2),
        },
    });
    return external_js_yaml_default().dump({
        name: 'Deploy To Firebase Functions',
        on: {
            // push: {
            //   branches: ['main'],
            // },
            workflow_dispatch: {
                inputs: {
                    correlationId: {
                        description: '"Correlation Id"',
                        required: true,
                    },
                },
            },
        },
        env: {
            FASLH_API_URL: 'https://us-central1-january-9f554.cloudfunctions.net/ghevents',
            // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
        },
        jobs: {
            deploy_to_firebase_functions: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only --legacy-peer-deps --no-audit --no-fund',
                    },
                    {
                        id: 'cache',
                        name: 'Cache Or Restore Node Modules',
                        uses: 'actions/cache@v3',
                        with: {
                            path: 'node_modules',
                            key: "node-modules-${{ hashFiles('package-lock.json') }}",
                        },
                    },
                    {
                        id: 'install_deps',
                        name: 'Install Deps',
                        run: 'npm install --no-audit --no-fund',
                    },
                    {
                        id: 'build',
                        name: 'Build',
                        run: 'npm run build:prod -- --entry ./src/firebase-functions.ts',
                    },
                    {
                        id: 'deploy',
                        name: 'Deploy to Firebase',
                        uses: 'w9jds/firebase-action@master',
                        with: {
                            args: 'deploy --only functions --debug',
                        },
                        env: {
                            GCP_SA_KEY: `\${{ ${serviceAccountKey} }}`,
                            PROJECT_ID: `\${{ ${projectId} }}`,
                        },
                    },
                    sendStatusStep([
                        'checkout',
                        'install_lockfile',
                        'cache',
                        'install_deps',
                        'build',
                        'deploy',
                    ]),
                ],
            },
        },
    }, {
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};
const deployContent_v1 = (serviceAccountKey, projectId, envionmentVars) => {
    const vars = envionmentVars.reduce((acc, curr) => {
        return {
            ...acc,
            ...{
                [`envkey_${curr}`]: `\${{ secrets.${curr} }}`,
            },
        };
    }, {});
    const sendStatusStep = (steps) => ({
        uses: 'fjogeleit/http-request-action@v1',
        if: '${{ always() }}',
        with: {
            url: '${{ env.FASLH_API_URL }}',
            method: 'POST',
            data: JSON.stringify({
                jobName: '${{ github.job }}',
                correlationId: '${{ github.event.inputs.correlationId }}',
                statuses: steps.map((step) => ({
                    step,
                    status: `\${{ steps.${step}.outcome }}`,
                })),
            }, null, 2),
        },
    });
    return external_js_yaml_default().dump({
        name: 'Deploy To Firebase Functions',
        on: {
            // push: {
            //   branches: ['main'],
            // },
            workflow_dispatch: {
                inputs: {
                    correlationId: {
                        description: '"Correlation Id"',
                        required: true,
                    },
                },
            },
        },
        env: {
            FASLH_API_URL: 'https://us-central1-january-9f554.cloudfunctions.net/ghevents',
            // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
        },
        jobs: {
            deploy_to_firebase_functions: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only --legacy-peer-deps --no-audit --no-fund',
                    },
                    {
                        id: 'cache',
                        name: 'Cache Or Restore Node Modules',
                        uses: 'actions/cache@v3',
                        with: {
                            path: 'node_modules',
                            key: "node-modules-${{ hashFiles('package-lock.json') }}",
                        },
                    },
                    {
                        id: 'install_deps',
                        name: 'Install Deps',
                        run: 'npm install --no-audit --no-fund',
                    },
                    {
                        id: 'build',
                        name: 'Build',
                        run: 'npm run build:prod -- --entry ./src/firebase-functions.ts',
                    },
                    {
                        name: 'Collect Env Variables',
                        uses: 'SpicyPizza/create-envfile@v1.3',
                        with: {
                            ...vars,
                            directory: './',
                            file_name: './dist/.env',
                            fail_on_empty: false,
                        },
                    },
                    {
                        id: 'deploy',
                        name: 'Deploy to Firebase',
                        uses: 'w9jds/firebase-action@master',
                        with: {
                            args: 'deploy --only functions --debug',
                        },
                        env: {
                            GCP_SA_KEY: `\${{ secrets.${serviceAccountKey} }}`,
                            PROJECT_ID: `\${{ secrets.${projectId} }}`,
                        },
                    },
                    sendStatusStep([
                        'checkout',
                        'install_lockfile',
                        'cache',
                        'install_deps',
                        'build',
                        'deploy',
                    ]),
                ],
            },
        },
    }, {
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};

;// CONCATENATED MODULE: ../compiler/core/src/lib/fly/dockerfile.txt
/* harmony default export */ const dockerfile = ("ARG NODE_VERSION=20\n\nFROM node:${NODE_VERSION}-alpine as builder\nLABEL fly_launch_runtime=\"NodeJS\"\nWORKDIR /app\nENV NODE_ENV=production\nCOPY ./output/package*.json ./\nRUN npm install --omit=dev --no-audit --no-fund\n\nFROM node:${NODE_VERSION}-alpine as runner\nWORKDIR /app\nCOPY --from=builder /app/node_modules /app/node_modules\nCOPY ./output/build/ /app/build/\nCOPY ./output/package*.json ./\nCMD [ \"npm\", \"run\", \"start:prod\" ]\nEXPOSE 3000");
;// CONCATENATED MODULE: ../compiler/core/src/lib/fly/fly.extension.ts
var fly_extension_a, fly_extension_b;






let FlyExtension = class FlyExtension {
    _projectFS;
    _context;
    constructor(_projectFS, _context) {
        this._projectFS = _projectFS;
        this._context = _context;
    }
    get _inputParser() {
        return external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
    }
    async handleSetup(inputs) {
        const routingExt = await this._inputParser.routingExtension();
        return [
            {
                filePath: this._projectFS.makeWorkspacePath('.github/workflows/deploy.yml'),
                content: [
                    fly_extension_deployContent(inputs['FLY_API_TOKEN'].value, inputs['FLY_APP_NAME'].value),
                ],
            },
            {
                filePath: this._projectFS.makeSrcPath('server.ts'),
                content: [routingExt.extension.getServerSetup()],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('Dockerfile'),
                content: [dockerfile],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('deploy.toml'),
                content: [
                    `# deploy.toml app configuration file generated for build on 2023-06-18T14:20:13+03:00
#
# See https://fly.io/docs/reference/configuration/ for information about how to use this file.
#

primary_region = "ams"

[env]
  PORT = "3000"

[http_service]
  internal_port = 3000
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 0
`,
                ],
            },
        ];
    }
};
FlyExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (fly_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? fly_extension_a : Object, typeof (fly_extension_b = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? fly_extension_b : Object])
], FlyExtension);

const fly_extension_deployContent_v1 = (envionmentVars, token) => {
    const vars = envionmentVars.reduce((acc, curr) => {
        return {
            ...acc,
            ...{
                [`envkey_${curr}`]: `\${{ secrets.${curr} }}`,
            },
        };
    }, {});
    const sendStatusStep = (steps) => ({
        uses: 'fjogeleit/http-request-action@v1',
        if: '${{ always() }}',
        with: {
            url: '${{ env.FASLH_API_URL }}',
            method: 'POST',
            data: JSON.stringify({
                jobName: '${{ github.job }}',
                correlationId: '${{ github.event.inputs.correlationId }}',
                statuses: steps.map((step) => ({
                    step,
                    status: `\${{ steps.${step}.outcome }}`,
                })),
            }, null, 2),
        },
    });
    return external_js_yaml_default().dump({
        name: 'Deploy To fly.io',
        on: {
            // push: {
            //   branches: ['main'],
            // },
            workflow_dispatch: {
                inputs: {
                    correlationId: {
                        description: '"Correlation Id"',
                        required: true,
                    },
                },
            },
        },
        env: {
            DEMO_TOKEN: 'fo1_GH0M7yvLWYkunojmEAdN8EwILUiNE0HxROsdHY1UX-4',
            FASLH_API_URL: 'https://us-central1-january-9f554.cloudfunctions.net/ghevents',
            // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
        },
        jobs: {
            deploy_to_fly: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only --legacy-peer-deps --no-audit --no-fund',
                    },
                    {
                        id: 'cache',
                        name: 'Cache Or Restore Node Modules',
                        uses: 'actions/cache@v3',
                        with: {
                            path: 'node_modules',
                            key: "node-modules-${{ hashFiles('package-lock.json') }}",
                        },
                    },
                    {
                        id: 'install_deps',
                        name: 'Install Deps',
                        run: 'npm install --no-audit --no-fund',
                    },
                    {
                        id: 'build',
                        name: 'Build',
                        run: 'npm run build:prod -- --entry ./src/server.ts',
                    },
                    {
                        uses: 'superfly/flyctl-actions/setup-flyctl@master',
                    },
                    {
                        name: 'Collect Env Variables',
                        uses: 'SpicyPizza/create-envfile@v1.3',
                        with: {
                            ...vars,
                            directory: './',
                            file_name: './build/.env',
                            fail_on_empty: false,
                        },
                    },
                    {
                        id: 'deploy',
                        name: 'Deploy to Fly.io',
                        run: `flyctl deploy --app \${{ secrets.${token} }} --remote-only --config ./deploy.toml --verbose`,
                        env: {
                            FLY_API_TOKEN: `\${{ secrets.${token} }}`,
                        },
                    },
                    // {
                    //   name: 'Import secrets into Fly',
                    //   run: 'flyctl secrets import < ./build/.env --config ./deploy.toml \nrm -f ./build/.env',
                    //   env: {
                    //     FLY_API_TOKEN: `\${{ secrets.${token} }}`,
                    //   },
                    // },
                    sendStatusStep([
                        'checkout',
                        'install_lockfile',
                        'cache',
                        'install_deps',
                        'build',
                        'deploy',
                    ]),
                ],
            },
        },
    }, {
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};
const deployContent_v2 = (token) => {
    const sendStatusStep = (steps) => ({
        uses: 'fjogeleit/http-request-action@v1',
        if: '${{ always() }}',
        with: {
            url: '${{ env.FASLH_API_URL }}',
            method: 'POST',
            data: JSON.stringify({
                jobName: '${{ github.job }}',
                correlationId: '${{ github.event.inputs.correlationId }}',
                statuses: steps.map((step) => ({
                    step,
                    status: `\${{ steps.${step}.outcome }}`,
                })),
            }, null, 2),
        },
    });
    return external_js_yaml_default().dump({
        name: 'Deploy To fly.io',
        on: {
            // push: {
            //   branches: ['main'],
            // },
            workflow_dispatch: {
                inputs: {
                    correlationId: {
                        description: '"Correlation Id"',
                        required: true,
                    },
                },
            },
        },
        env: {
            DEMO_TOKEN: 'fo1_GH0M7yvLWYkunojmEAdN8EwILUiNE0HxROsdHY1UX-4',
            FASLH_API_URL: 'https://us-central1-january-9f554.cloudfunctions.net/ghevents',
            // 'https://2c12-176-29-107-62.eu.ngrok.io/january-9f554/us-central1/ghevents',
        },
        jobs: {
            deploy_to_fly: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only --legacy-peer-deps --no-audit --no-fund',
                    },
                    {
                        id: 'cache',
                        name: 'Cache Or Restore Node Modules',
                        uses: 'actions/cache@v3',
                        with: {
                            path: 'node_modules',
                            key: "node-modules-${{ hashFiles('package-lock.json') }}",
                        },
                    },
                    {
                        id: 'install_deps',
                        name: 'Install Deps',
                        run: 'npm install --no-audit --no-fund',
                    },
                    {
                        id: 'build',
                        name: 'Build',
                        run: 'npm run build:prod -- --entry ./src/server.ts',
                    },
                    {
                        uses: 'superfly/flyctl-actions/setup-flyctl@master',
                    },
                    {
                        id: 'deploy',
                        name: 'Deploy to Fly.io',
                        run: 'flyctl deploy --remote-only --config ./deploy.toml --verbose',
                        env: {
                            FLY_API_TOKEN: `\${{ secrets.${token} }}`,
                        },
                    },
                    sendStatusStep([
                        'checkout',
                        'install_lockfile',
                        'cache',
                        'install_deps',
                        'build',
                        'deploy',
                    ]),
                ],
            },
        },
    }, {
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};
const fly_extension_deployContent = (appToken, appName) => {
    return external_js_yaml_default().dump({
        name: 'Deploy To fly.io',
        on: {
            push: {
                branches: ['main'],
            },
            workflow_dispatch: {},
        },
        jobs: {
            deploy_to_fly: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    // FIXME: Removing this will give us few seconds back
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only',
                    },
                    {
                        id: 'setup_node',
                        uses: 'actions/setup-node@v3',
                        name: 'Setup Node.js',
                        with: {
                            'node-version': '20',
                            cache: 'npm',
                        },
                    },
                    {
                        id: 'cache_deps',
                        name: 'Cache Or Restore Node Modules.',
                        uses: 'actions/cache@v3',
                        with: {
                            path: 'node_modules',
                            key: "${{ runner.os }}-node-${{ hashFiles('package-lock.json') }}",
                        },
                    },
                    {
                        id: 'install_deps',
                        name: 'Install project dependencies.',
                        run: 'npm install --no-audit --no-fund',
                        if: `steps.cache_deps.outputs.cache-hit != 'true'`,
                    },
                    // {
                    //   FIXME: set this up properly using esbuild
                    //   id: 'build',
                    //   name: 'Build',
                    //   if: false,
                    //   run: 'npm run build:prod',
                    // },
                    {
                        name: 'Setup Fly.io cli.',
                        uses: 'superfly/flyctl-actions/setup-flyctl@master',
                    },
                    {
                        id: 'deploy',
                        name: 'Deploying ...',
                        run: `flyctl deploy --app \${{ secrets.${appName} }} --remote-only --config ./deploy.toml --verbose`,
                        env: {
                            FLY_API_TOKEN: `\${{ secrets.${appToken} }}`,
                        },
                    },
                ],
            },
        },
    }, {
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};
// FlyV1 fm2_lJPECAAAAAAAALalxBC7mgZaHIvz2ywCy5if77sdwrVodHRwczovL2FwaS5mbHkuaW8vdjGWAJLOAAQVkR8Lk7lodHRwczovL2FwaS5mbHkuaW8vYWFhL3YxxDxVK5KjWvSVUoI5coQCYAOrJnm0522oCdh2PrLKl0K3A9Y6N+yknofkaG51Vguh8NbOZwUxjJPtfRC8aVXETlj/9Q4rO2NcFbTzJkc+HchFQe5e0VvbYVILqOhp7j0mOn8kRt1Ic4hAsHZmL6eIH2mGRWoUmd17wkaZHvKK3xvz5gKLlGopo/kW7u/0tw2SlAORgc4ANPPyHwWRgqdidWlsZGVyH6J3Zx8BxCCOgb7J6yyNsvisxUZU4/lrw9ex0awSC7hT99EMI1/Dcw==,fm2_lJPETlj/9Q4rO2NcFbTzJkc+HchFQe5e0VvbYVILqOhp7j0mOn8kRt1Ic4hAsHZmL6eIH2mGRWoUmd17wkaZHvKK3xvz5gKLlGopo/kW7u/0t8QQ55eJa7Wwbxm71rIOPDPescO5aHR0cHM6Ly9hcGkuZmx5LmlvL2FhYS92MZYEks5mUMYuzwAAAAEiSORMCpHOAAPM0QzEEEfs+yQGonDYiPGgDuy0PD/EID9pJNy1PzkRQ1lHiqazrogdu5wNdTcvOP9WQVECPv9h

;// CONCATENATED MODULE: ../compiler/core/src/lib/github/receive-webhook.txt
/* harmony default export */ const receive_webhook = ("import {\n  EmitterWebhookEvent,\n  EmitterWebhookEventName,\n  Webhooks,\n  createNodeMiddleware,\n} from '@octokit/webhooks';\nimport { IncomingMessage, ServerResponse } from 'node:http';\n\nconst webhooks = new Webhooks({\n  secret: '04062d0a92fed0522c47a23e8441300d533a3b1fc1139e0960128abb91728371',\n  log: console,\n});\n\nexport function isEventOfType<T extends EmitterWebhookEventName>(\n  event: EmitterWebhookEvent,\n  ...types: T[]\n): event is EmitterWebhookEvent<T> {\n  const eventName =\n    'action' in event.payload\n      ? `${event.name}.${event.payload.action}`\n      : event.name;\n  return types.includes(eventName as T);\n}\n\n\nexport function onGithubEvent<EventName extends EmitterWebhookEventName>(\n  event: EventName,\n  ...middlewares: ((\n    event: EmitterWebhookEvent<EventName>,\n  ) => boolean | void | Promise<boolean | void>)[]\n) {\n  webhooks.on(event, async (event) => {\n    for (const middleware of middlewares) {\n      let canContinue = await middleware(event);\n      if (canContinue === false) {\n        break;\n      }\n    }\n  });\n}\n\nexport async function receiveGithubEvents(\n  request: IncomingMessage,\n  response: ServerResponse<IncomingMessage>,\n  path: string,\n) {\n  let body = '';\n  let statusCode = 200;\n  let headers = {};\n\n  const orignalEnd = response.end;\n  const originalWriteHead = response.writeHead;\n\n  response.end = function (...args: any[]) {\n    body = args[0];\n    return this;\n  };\n\n  response.writeHead = function (...args: any[]) {\n    statusCode = args[0];\n    headers = args[1];\n    return this;\n  };\n\n  Object.defineProperty(response, 'statusCode', {\n    set: function (value) {\n      statusCode = value;\n    },\n  });\n\n  const handler = createNodeMiddleware(webhooks, {\n    path,\n    log: console,\n  });\n\n  const processed = await handler(request, response);\n\n  response.end = orignalEnd;\n  response.writeHead = originalWriteHead;\n\n  return {\n    processed,\n    body,\n    statusCode,\n    headers,\n  };\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/github/webhook-handler.txt
/* harmony default export */ const webhook_handler = ("import { Hono } from 'hono';\nimport type { StatusCode } from 'hono/utils/http-status';\nimport type { IncomingMessage, ServerResponse } from 'node:http';\nimport { receiveGithubEvents } from '../../core/github-webhooks';\n\nconst router = new Hono();\n\nrouter.post('/github/webhooks', async (context, next) => {\n  const nodeContext = context.env as {\n    incoming: IncomingMessage;\n    outgoing: ServerResponse<IncomingMessage>;\n  };\n\n  const { processed, body, headers, statusCode } = await receiveGithubEvents(\n    nodeContext.incoming,\n    nodeContext.outgoing,\n    '/integrations/github/webhooks',\n  );\n  if (!processed) {\n    // github middleware did not process the request due to\n    // path mismatch which is unlikely to happen given we control the path\n    return context.body('', 400);\n  }\n  return context.body(body, statusCode as StatusCode, headers);\n});\n\nexport default ['/integrations', router] as const;\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/github/github.extension.ts
var github_extension_a, github_extension_b;








let GithubExtension = class GithubExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    triggers = ['7b1696e9-9c89-4ba7-abc0-e1448b287772'];
    async handleSetup(details) {
        return [
            {
                filePath: this._projectFS.makeControllerPath('integrations', 'router'),
                content: [webhook_handler],
            },
            {
                filePath: this._projectFS.makeCorePath('github-webhooks.ts'),
                content: [receive_webhook],
            },
        ];
    }
    async handleInput(input, extras = {}) {
        if (extras['trigger'] === 'github-trigger') {
            if (input.startsWith('@trigger:mapper')) {
                return {
                    static: false,
                    type: 'string',
                    value: input.replace('@trigger:mapper.', ''),
                    data: {
                        fromMapper: true,
                    },
                };
            }
            return {
                static: false,
                type: 'string',
                value: input.replace('@trigger:', '').replace('payload.', ''),
            };
        }
        const visitor = new github_extension_SimpleVisitor();
        const { namespace, value } = visitor.visit(parseDsl(input));
        return this.handleInputV2({ namespace, value });
    }
    async handleInputV2({ namespace, value, }, extras = {}) {
        switch (namespace) {
            case 'trigger': {
                const visitor = new HonoInputVisitor();
                const result = (await visitor.visit(value));
                switch (result.accessor) {
                    case 'issue':
                    case 'pull_request':
                    case 'push':
                    case 'repository':
                    case 'comment':
                        return {
                            // FIXME: don't implement the rest of the cases as we're moving to the new version of CanonLang
                            static: false,
                            type: 'string',
                            value: result.accessee,
                        };
                    default:
                        return null;
                }
            }
            default:
                return null;
        }
    }
    async extractInputs({ namespace, value, visit, }) {
        if (!['trigger'].includes(namespace)) {
            return null;
        }
        const visitor = new InputsExtractor(visit);
        const result = await visitor.visit(value);
        return {
            [result.accessee]: `@${namespace}:${result.accessor}.${result.accessee}`,
        };
    }
    onFeatureContract(contract, addFile) {
        if (contract.workflows.length === 0) {
            return;
        }
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'github'),
            structure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/github-webhooks'),
                    namedImports: ['onGithubEvent'],
                },
                ...contract.workflows
                    .map((it) => it.trigger.policies)
                    .flat()
                    .map((it) => ({
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: `../../identity/${(0,external_stringcase_.spinalcase)(it)}.policy`,
                    namedImports: [(0,external_stringcase_.camelcase)(it)],
                })),
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: `./listeners`,
                    namespaceImport: 'listeners',
                },
                ...contract.workflows.map((contract) => {
                    const displayName = `listeners.${(0,external_stringcase_.camelcase)(contract.trigger.displayName)}`;
                    const authorize = contract.trigger.policies.length
                        ? `,${contract.trigger.policies
                            .map((it) => `${(0,external_stringcase_.camelcase)(it)}`)
                            .join(',')}`
                        : '';
                    // return `${verb}("${path}" ${authorize}, ${displayName})`;
                    return `onGithubEvent(
  '${contract.trigger.details['event']}'
  ${authorize},
  ${displayName},
);
`;
                }),
            ],
        });
    }
    async processTrigger(contract, workflowInputs) {
        const displayName = (0,external_stringcase_.camelcase)(contract.displayName);
        const inputName = (0,external_stringcase_.camelcase)('input');
        const vars = {};
        const externalInputs = Object.entries(contract.details['inputs']);
        const inputParams = signutureInputs({ ...contract.inputs });
        const actionsInputs = [
            ...inputParams.map(([name, prop]) => [
                name,
                {
                    ...prop,
                    value: prop.data?.['fromMapper'] !== true
                        ? `payload.${prop.value}`
                        : prop.value,
                },
            ]),
        ];
        const actionInputsStr = this._devKit.toLiteralObject(actionsInputs);
        const workflowLoneParams = signutureInputs({ ...workflowInputs });
        for (const [name, prop] of workflowLoneParams) {
            vars[name] = `const ${name} = ${prop.value}`;
        }
        const workflowParams = [];
        if (inputParams.length) {
            workflowParams.push(inputName);
        }
        if (workflowLoneParams.length) {
            workflowParams.push(...workflowLoneParams.map(([name]) => name));
        }
        const workflowInputsStructures = Object.values(workflowInputs)
            .map((prop) => prop.structure)
            .filter(Boolean);
        return [
            {
                filePath: this._projectFS.makeIndexFilePath(contract.featureName, 'listeners'),
                structure: [
                    {
                        kind: external_ts_morph_.StructureKind.ExportDeclaration,
                        moduleSpecifier: this._projectFS.makeExportPath(contract.displayName, `listener`),
                    },
                ],
            },
            {
                filePath: this._projectFS.makeListenerRoutePath(contract.featureName, contract.displayName),
                structure: [
                    ...workflowInputsStructures.flat(),
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: `../${(0,external_stringcase_.spinalcase)(contract.tag)}`,
                        namespaceImport: (0,external_stringcase_.camelcase)(contract.tag),
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                        namedImports: ['validateOrThrow'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: '@octokit/webhooks',
                        namedImports: ['EmitterWebhookEvent'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.Function,
                        isAsync: true,
                        isDefaultExport: false,
                        isExported: true,
                        name: displayName,
                        parameters: [
                            {
                                name: '{payload,name}',
                                type: `EmitterWebhookEvent<'${contract.details['event']}'>`,
                            },
                        ],
                        statements: [
                            ...Object.values(vars),
                            (writer) => writer.writeLine("console.log(`${name}.${payload.action}`, 'has been triggered');"),
                            (writer) => writer.conditionalWriteLine(!!inputParams.length, `
                  ${externalInputs
                                .map(([name, prop]) => `const ${name} = ${prop.value}`)
                                .join('\n')}
                  const ${inputName} = ${actionInputsStr}
                  `),
                            (writer) => writer.conditionalWriteLine(!!inputParams.length, `validateOrThrow(${(0,external_stringcase_.camelcase)(contract.tag)}.${contract.schemaName}, ${inputName})`),
                            (writer) => writer.writeLine(`await ${(0,external_stringcase_.camelcase)(contract.tag)}.${(0,external_stringcase_.camelcase)(contract.operationName)}(${workflowParams.join(',')})`),
                        ],
                    },
                ],
            },
        ];
    }
};
GithubExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (github_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? github_extension_a : Object, typeof (github_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? github_extension_b : Object])
], GithubExtension);

class HonoInputVisitor extends AsyncVisitor {
    visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visitIdentifier(node) {
        return node.value;
    }
    async visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visit(node) {
        return node.accept(this);
    }
}
class InputsExtractor extends StringAsyncVisitor {
    _visitor;
    constructor(_visitor) {
        super();
        this._visitor = _visitor;
    }
    async visitArg(node) {
        throw new Error('Method not implemented.');
    }
    async visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    async visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    async visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visit(node) {
        return node.accept(this);
    }
}
class github_extension_SimpleVisitor extends StringVisitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.accept(this),
            value: node.expression,
        };
    }
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/google/file-manager.txt
/* harmony default export */ const file_manager = ("import type {\n  Bucket,\n  CreateWriteStreamOptions,\n  GetFileOptions,\n  GetFilesOptions,\n  GetSignedUrlConfig,\n  SaveOptions\n} from '@google-cloud/storage';\nimport {\n  Storage,\n} from '@google-cloud/storage';\nimport type { Writable } from 'stream';\nimport type { GoogleServiceAccount } from './service-account';\n\ninterface FileStorageAdapter {\n  listSignedLinks(...args: any[]): any;\n  listPublicLinks(...args: any[]): any;\n  list(...args: any[]): any;\n  exists(...args: any[]): Promise<any>;\n  delete(...args: any[]): Promise<any>;\n  create(...args: any[]): Promise<any>;\n  uploadStream(...args: any[]): Writable;\n  filePublicUrl(...args: any[]): any;\n}\n\nconst typeToKindMap: Record<string, Kind> = {\n  png: 'image',\n  jpeg: 'image',\n  pdf: 'document',\n};\n\nfunction getKindByType(value: string) {\n  return typeToKindMap[value] ?? 'other';\n}\n\ntype Kind = 'folder' | 'image' | 'document' | 'other';\ninterface FFile {\n  kind: Kind;\n  name: string;\n  link: string;\n  ext: string;\n  isFolder: boolean;\n  size?: string|number;\n  updatedAt?: string;\n  createdAt?: string;\n}\n\ninterface ServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n}\n\ninterface GoogleCloudStorageAdapterConfig {\n  /**\n   * The service account to use for authentication.\n   * @see https://cloud.google.com/storage/docs/authentication#service_accounts\n   * @see https://cloud.google.com/iam/docs/creating-managing-service-accounts\n   * @see https://cloud.google.com/iam/docs/creating-managing-service-account-keys\n   * @see https://cloud.google.com/iam/docs/understanding-service-accounts\n   */\n  serviceAccount: ServiceAccount;\n\n  /**\n   * The name of the bucket to use. If not provided, the bucket name will be\n   * inferred from the service account.\n   * @default <project-id>.appspot.com\n   * @see https://cloud.google.com/storage/docs/projects\n   * @see https://cloud.google.com/storage/docs/naming-buckets\n   */\n  bucket?: string;\n}\n\nexport class GoogleCloudStorageAdapter implements FileStorageAdapter {\n  private _storage: Storage;\n  private _bucket: Bucket;\n\n  constructor({ bucket, serviceAccount }: GoogleCloudStorageAdapterConfig) {\n    this._storage = new Storage({ credentials: serviceAccount });\n    bucket = bucket || `${serviceAccount.project_id}.appspot.com`;\n    this._bucket = this._storage.bucket(bucket);\n  }\n\n  filePublicUrl(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).publicUrl();\n  }\n\n  uploadStream(options: { fileName: string } & CreateWriteStreamOptions) {\n    return this._bucket\n      .file(options.fileName)\n      .createWriteStream({ resumable: false, ...options });\n  }\n\n  /**\n   * Lists public URLs for the files in the bucket.\n   *\n   * @param options The options to use when listing the files.\n   * @returns A list of public URLs for the files in the bucket.\n   */\n  async listPublicLinks(options?: GetFilesOptions) {\n    const [files] = await this._bucket.getFiles(options);\n    const result: FFile[] = [];\n    for (const file of files) {\n      const link = file.publicUrl();\n      const ext = link.split('.').pop() as string;\n      result.push({\n        ext,\n        link: link,\n        name: file.name,\n        kind: file.name.endsWith('/') ? 'folder' : getKindByType(ext),\n        isFolder: file.name.endsWith('/'),\n        createdAt: file.metadata.timeCreated,\n        updatedAt: file.metadata.updated,\n        size: file.metadata.size,\n      });\n    }\n    return result;\n  }\n\n  /**\n   * Returns a list of signed URLs for the files in the bucket.\n   *\n   * @param signUrlOptions The options to use when generating the signed URLs.\n   * @param options The options to use when listing the files.\n   * @returns A list of signed URLs for the files in the bucket.\n   */\n  async listSignedLinks(\n    signUrlOptions: GetSignedUrlConfig,\n    options?: GetFileOptions\n  ): Promise<FFile[]> {\n    const [files] = await this._bucket.getFiles(options);\n    const result: FFile[] = [];\n    for (const file of files) {\n      const [link] = await file.getSignedUrl(signUrlOptions);\n      const ext = link.split('.').pop() as string;\n      result.push({\n        ext,\n        link: link,\n        kind: file.name.endsWith('/') ? 'folder' : getKindByType(ext),\n        name: file.name,\n        isFolder: file.name.endsWith('/'),\n        createdAt: file.metadata.timeCreated,\n        updatedAt: file.metadata.updated,\n        size: file.metadata.size,\n      });\n    }\n    return result;\n  }\n\n  /**\n   * Lists files in the bucket.\n   *\n   * @param options The options to use when listing the files.\n   * @returns A list of files in the bucket.\n   */\n  list(options?: GetFileOptions) {\n    return this._bucket.getFiles(options);\n  }\n\n  create(options: { fileName: string; content: Buffer } & SaveOptions) {\n    return this._bucket.file(options.fileName).save(options.content, options);\n  }\n\n  delete(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).delete({});\n  }\n\n  exists(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).exists({});\n  }\n}\n\nexport class FileManager<T extends FileStorageAdapter>\n  implements FileStorageAdapter\n{\n  private _adapter: FileStorageAdapter;\n  constructor({ adapter }: { adapter: T }) {\n    this._adapter = adapter;\n  }\n\n  filePublicUrl(\n    ...args: Parameters<T['filePublicUrl']>\n  ): Promise<ReturnType<T['filePublicUrl']>> {\n    return this._adapter.filePublicUrl(...args);\n  }\n\n  exists(...args: Parameters<T['exists']>): Promise<ReturnType<T['exists']>> {\n    return this._adapter.exists(...args);\n  }\n  delete(...args: Parameters<T['delete']>) {\n    return this._adapter.delete(...args);\n  }\n  create(...args: Parameters<T['create']>) {\n    return this._adapter.create(...args);\n  }\n  list(...args: Parameters<T['list']>): ReturnType<T['list']> {\n    return this._adapter.list(...args);\n  }\n  listPublicLinks(\n    ...args: Parameters<T['listPublicLinks']>\n  ): ReturnType<T['listPublicLinks']> {\n    return this._adapter.listPublicLinks(...args);\n  }\n  listSignedLinks(\n    ...args: Parameters<T['listSignedLinks']>\n  ): ReturnType<T['listSignedLinks']> {\n    return this._adapter.listSignedLinks(...args);\n  }\n  uploadStream(...args: Parameters<T['uploadStream']>): Writable {\n    return this._adapter.uploadStream(...args);\n  }\n}\n\n\n\n\nconst serviceAccount: GoogleServiceAccount = JSON.parse(\n  Buffer.from(\n    process.env['GOOGLE_CLOUD_SERVICE_ACCOUNT_KEY']!,\n    'base64',\n  ).toString('ascii'),\n);\n\nexport const fileManager = new FileManager({\n  adapter: new GoogleCloudStorageAdapter({\n    serviceAccount: serviceAccount,\n  }),\n});\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/google/service-account-interface.txt
/* harmony default export */ const google_service_account_interface = ("export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/google/uploader.txt
/* harmony default export */ const uploader = ("import formidable from 'formidable';\nimport VolatileFile from 'formidable/VolatileFile';\nimport { PassThrough } from 'stream';\nimport { fileManager } from './file-manager';\nimport { IncomingMessage } from 'http';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nexport function uploadFile() {\n  const fileLocation = new PassThrough();\n\n  return {\n    fileLocation,\n    uploader: (volatileFile?: VolatileFile) => {\n      if (!volatileFile) {\n        // to make typescript happy\n        throw new Error('No file provided');\n      }\n\n      const { newFilename: fileName, mimetype } = volatileFile.toJSON();\n\n      return fileManager\n        .uploadStream({\n          fileName: fileName,\n          contentType: mimetype ?? undefined,\n        })\n        .on('finish', () => {\n          fileLocation.end(fileManager.filePublicUrl({ fileName }));\n        });\n    },\n  };\n}\n\nexport function createUploader() {\n  const { fileLocation, uploader } = uploadFile();\n  const parser = formidable({\n    keepExtensions: true,\n    maxFiles: 1,\n    maxFields: 1,\n    filename: (name, ext) => `${name}${ext}`,\n    fileWriteStreamHandler: uploader,\n  });\n  return {\n    fileLocation,\n    parser: {\n      ...parser,\n      parse: (req: IncomingMessage) => {\n        return parser.parse(req).catch((error) => {\n          fileLocation.end();\n          throw new ProblemDetailsException({\n            title: 'Failed to parse form data',\n            status: 400,\n            detail: error.message,\n          });\n        });\n      },\n    },\n  };\n}\n\nexport async function streamEnd(stream: NodeJS.ReadableStream) {\n  return new Promise<void>((resolve, reject) => {\n    stream.on('data', (buffer) => resolve(buffer.toString()));\n    stream.on('error', reject);\n  });\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/google/google-storage.extension.ts
var google_storage_extension_a, google_storage_extension_b;

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore








let GoogleStorageExtension = class GoogleStorageExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    async handleSetup(details) {
        return [
            {
                // TODO: extract file manager initialization to be in this extension.
                filePath: this._projectFS.makeCorePath('uploader.ts'),
                content: [uploader],
            },
            {
                filePath: this._projectFS.makeCorePath('service-account.ts'),
                content: [google_service_account_interface],
            },
            {
                // FIXME: file-manager shouldn't be added by a specific storage extension rather it
                // should be imported from a library (we should publish (file-manager or storage-abstraction) as npm package) and
                // only use the implementation of it here
                filePath: this._projectFS.makeCorePath('file-manager.ts'),
                content: [file_manager],
            },
        ];
    }
    async handleAction(input) {
        switch (input.sourceAction.name) {
            case 'list-files':
                return {
                    output: {
                        displayName: input.outputName ?? 'files',
                    },
                    runtimeInputs: {
                        prefix: {
                            input: '@trigger:query.prefix',
                        },
                        flat: {
                            input: '@trigger:query.flat',
                            // FIXME: add boolean validation
                        },
                    },
                };
            case 'upload-file':
                return {
                    output: {
                        displayName: input.outputName ?? 'file',
                    },
                    runtimeInputs: {},
                    workflowInputs: {
                        request: {
                            input: '@trigger:request.raw',
                            type: 'IncomingMessage',
                        },
                    },
                };
            default:
                throw new Error(`action ${input.sourceAction.name} is not supported`);
        }
    }
    async processAction(contract, helpers, inputs) {
        switch (contract.sourceAction.name) {
            case 'list-files':
                return {
                    inline: false,
                    structure: [
                        (writer) => writer.writeLine(external_dedent_default() `
                const ${contract.output.displayName} = await fileManager.listPublicLinks({
                  delimiter: ${inputs['flat']} ? '/' : undefined,
                  prefix: ${inputs['prefix']}
                })`),
                    ],
                };
            case 'upload-file':
                // const uploadOptions:[string] = [];
                // if (inputs['maxFileSize']) {
                //   uploadOptions.push([`maxFileSize`, inputs['maxFileSize']]);
                // }
                const mimeTypes = useInput(inputs['types']);
                return {
                    inline: true,
                    structure: {
                        topLevelStructure: [
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: 'http',
                                namedImports: ['IncomingMessage'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/uploader'),
                                namedImports: ['streamEnd', 'createUploader'],
                            },
                        ],
                        actionStructure: [
                            // TODO: we need move off formidable. essentially we need a way to convert a request files to
                            // stream and pass it throught uploader to make it work with non request streams as well
                            (writer) => writer.writeLine(external_dedent_default() `
                  const { parser, fileLocation } = createUploader();
                  ${contract.output.displayName ? `const [${contract.output.displayName}] = ` : ''} await Promise.all([
                    streamEnd(fileLocation),
                    parser.parse(request),
                  ]);`),
                        ],
                    },
                };
            default:
                throw new Error(`action ${contract.sourceAction.name} is not supported`);
        }
    }
    async handleField(input) {
        return {
            validations: await generateValidationContract(input.validation),
            nativeType: 'varchar',
            mandatory: false,
            unique: false,
        };
    }
};
GoogleStorageExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (google_storage_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? google_storage_extension_a : Object, typeof (google_storage_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? google_storage_extension_b : Object])
], GoogleStorageExtension);

// onEvent({
//   // events: [ExtensionInstalled],
//   events: [],
//   handler: async (event: any, context) => {
//     const devKit = Injector.GetRequiredService(DevKit, context);
//     const sdk = Injector.GetRequiredService(Sdk, context);
//     const sourceExtension = devKit.getExtensionById(event.entityId);
//     if (sourceExtension.name !== 'google-cloud-storage') {
//       return;
//     }
//     const httpTrigger = await devKit.getTriggerByName('http');
//     if (!httpTrigger) {
//       throw new Error(`http trigger not found`);
//     }
//     const uploadAction = await devKit.getSourceActionByName('upload-file');
//     if (!uploadAction) {
//       throw new Error(`upload-file action not found`);
//     }
//     const listFilesAction = await devKit.getSourceActionByName('list-files');
//     if (!listFilesAction) {
//       throw new Error(`list-files action not found`);
//     }
//     const featureId = await sdk.features.addFeature({
//       displayName: 'Google Cloud Storage',
//       policies:[]
//     });
//     const tagId = await sdk.features.addTag({
//       displayName: 'files',
//       featureId: featureId,
//     });
//     const workflowId = await sdk.workflows.addWorkflow(
//       {
//         featureId: featureId,
//         displayName: 'Upload File',
//         sourceId: httpTrigger.id,
//         details: {
//           method: 'post',
//           path: '/upload',
//           contentType: 'multipart/form-data',
//           type: 'workflow',
//         },
//       },
//       tagId,
//     );
//     await sdk.workflows.addAction({
//       displayName: uploadAction.displayName,
//       featureId: featureId,
//       workflowId: workflowId,
//       sourceId: uploadAction.id,
//       outputName: 'file',
//       details: {},
//     });
//     const queryId = await sdk.workflows.addWorkflow(
//       {
//         featureId: featureId,
//         displayName: 'List Files',
//         sourceId: httpTrigger.id,
//         details: {
//           method: 'get',
//           path: '/',
//           type: 'query',
//         },
//       },
//       tagId,
//     );
//     await sdk.workflows.addAction({
//       displayName: listFilesAction.displayName,
//       featureId: featureId,
//       workflowId: queryId,
//       sourceId: listFilesAction.id,
//       details: {},
//       outputName: 'files',
//     });
//   },
// });

;// CONCATENATED MODULE: ../compiler/core/src/lib/hono/setup.txt
/* harmony default export */ const setup = ("import './features/crons'\nimport './features/listeners'\nimport { Hono } from 'hono';\nimport { cors } from 'hono/cors';\nimport { logger } from 'hono/logger';\n\nimport dataSource from './core/data-source';\nimport { ValidationFailedException } from './core/validation';\nimport routes from './features/routes';\nimport { IdentitySubject, loadSubject } from './identity';\n\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { StatusCode } from 'hono/utils/http-status';\n\nconst application = new Hono<{\n  Variables: { subject: IdentitySubject | null };\n}>();\napplication.use(cors(), logger());\n\n\napplication.use(async (context, next) => {\n  const subject = await loadSubject(context.req.header('Authorization'));\n  context.set('subject', subject);\n  await next();\n});\n\n// TODO: use rfc-7807-problem-details\napplication.onError((err, context) => {\n  console.error(err);\n\n  if (err instanceof ValidationFailedException) {\n    context.status(400);\n    return context.json(err);\n  }\n\n  if (err instanceof ProblemDetailsException) {\n    context.status(err.Details.status as StatusCode ?? 500);\n    return context.json(err.Details);\n  }\n\n  context.status(500);\n  return context.json({\n    type: 'about:blank',\n    title: 'Internal Server Error',\n    status: 500,\n    detail: 'An unexpected error occurred',\n  });\n});\n\nroutes.forEach((route) => {\n  application.route(...route);\n});\n\ndataSource\n  .initialize()\n  .then(() => {\n    console.log('Database initialized');\n  })\n  .catch((error) => {\n    console.error(error);\n    process.exit(1);\n  });\n\napplication.get('/', (context, next) => {\n  return context.json({\n    status: 'UP',\n  });\n});\n\napplication.get('/health', async (context, next) => {\n  await dataSource.query('SELECT 1');\n  return context.json({\n    status: 'UP',\n  });\n});\n\nexport default application;");
// EXTERNAL MODULE: external "openapi3-ts/oas31"
var oas31_ = __webpack_require__(29);
;// CONCATENATED MODULE: ../compiler/core/src/lib/koajs/swagger.ts





function builder(contract) {
    const paths = contract.workflows.reduce((acc, workflow) => {
        const inputs = workflow.actions
            .map((it) => it.inputs)
            .flat(2)
            .filter((it) => !(0,external_lodash_.isEmpty)(it));
        const workflowPath = normalizeWorkflowPath({
            featureName: contract.displayName,
            workflowTag: workflow.tag,
            workflowPath: workflow.trigger.details['path'],
        });
        return (0,external_lodash_.merge)(acc, {
            [workflowPath]: {
                [workflow.trigger.details['method']]: {
                    description: '',
                    security: [],
                    tags: [workflow.tag],
                    operationId: (0,external_uuid_.v4)(),
                    summary: workflow.displayName,
                    requestBody: collectBody(inputs),
                    parameters: makeParameterSchema(inputs),
                    responses: {
                        200: {
                            description: '',
                            content: {
                                'application/json': {
                                    schema: {
                                        type: 'object',
                                        properties: {
                                            data: {
                                                type: 'object',
                                                properties: workflow.output.properties.reduce((acc, input) => {
                                                    return {
                                                        ...acc,
                                                        [input.value]: {
                                                            ...makeSchema({
                                                                ...input,
                                                                validations: [],
                                                            }),
                                                            default: input.defaultValue,
                                                            type: input.type,
                                                        },
                                                    };
                                                }, {}),
                                            },
                                        },
                                    },
                                },
                            },
                        },
                        400: {
                            description: 'Bad Request',
                            content: {
                                'application/json': {
                                    schema: {
                                        $ref: '#/components/schemas/Error',
                                        // TODO: override errors schema
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
    }, {});
    return paths;
}
function makeParameterSchema(inputs) {
    const pathParameters = [];
    const queryParameters = [];
    const headersParameters = [];
    collect(inputs, (input) => input.startsWith('@trigger:path'), (name, prop) => {
        const { required, ...propSchema } = makeSchema(prop);
        return {
            schema: propSchema,
            allowEmptyValue: false,
            name: prop.data?.['parameterName'] ?? name,
            in: 'path',
            required: true,
        };
    }, pathParameters);
    collect(inputs, (input) => input.startsWith('@trigger:query'), (name, prop) => {
        const { required, ...propSchema } = makeSchema(prop);
        return {
            schema: {
                ...propSchema,
                default: prop.defaultValue,
            },
            name: name,
            in: 'query',
            required,
        };
    }, queryParameters);
    collect(inputs, (input) => input.startsWith('@trigger:headers'), (name, prop) => {
        const { required, ...propSchema } = makeSchema(prop);
        return {
            schema: propSchema,
            name: name,
            in: 'header',
            required,
        };
    }, headersParameters);
    return [...pathParameters, ...queryParameters, ...headersParameters];
}
function makeErrorSchema() {
    // The error represents "rfc 7807" along with
    // errors from the validation
    return {
        type: 'object',
        properties: {
            type: {
                type: 'string',
                description: 'A URI reference [RFC3986] that identifies the problem type.',
            },
            title: {
                type: 'string',
                description: 'A short, human-readable summary of the problem type.',
            },
            status: {
                type: 'integer',
                description: 'The HTTP status code ([RFC7231], Section 6) generated by the origin server for this occurrence of the problem.',
            },
            detail: {
                type: 'string',
                description: 'A human-readable explanation specific to this occurrence of the problem.',
            },
            instance: {
                type: 'string',
                description: 'A URI reference that identifies the specific occurrence of the problem.',
            },
            // format inputs to potential errors
            errors: {
                type: 'object',
                description: 'Validation errors',
                properties: {},
            },
        },
    };
}
function makeSwaggerSpec(contract) {
    const openapiBuilder = new oas31_.OpenApiBuilder({
        openapi: '3.1.0',
        info: {
            title: contract.displayName,
            version: '1.0.0',
            license: {
                name: 'MIT',
                url: 'https://opensource.org/licenses/MIT',
            },
        },
        paths: builder(contract),
        components: {
            schemas: {
                Error: makeErrorSchema(),
            },
        },
        servers: [
            {
                url: 'http://localhost:3000',
            },
        ],
    });
    return openapiBuilder.getSpec();
}
function collect(inputs, on, add, seed = []) {
    for (const input of inputs) {
        for (const [name, prop] of Object.entries(input)) {
            if (!prop.data?.['parameterName']) {
                continue;
            }
            if (Array.isArray(prop)) {
                collect([
                    {
                        [prop.data?.['parameterName']]: prop,
                    },
                ], on, add, seed);
                continue;
            }
            if (on(prop.input)) {
                seed.push(add(name, prop));
            }
        }
    }
}
function collectBody(inputs) {
    const bodyInputs = [];
    collect(inputs, (input) => input.startsWith('@trigger:body'), (name, prop) => ({ [name]: prop }), bodyInputs);
    const properties = bodyInputs.reduce((it, value) => {
        return {
            ...it,
            ...Object.entries(value).reduce((acc, [name, prop]) => {
                return {
                    ...acc,
                    [name]: {
                        default: prop.defaultValue,
                        type: prop.type,
                    },
                };
            }, {}),
        };
    }, {});
    const requiredInputs = [];
    for (const input of bodyInputs) {
        for (const [name, prop] of Object.entries(input)) {
            if (prop.input.startsWith('@trigger:body') &&
                (prop.validations ?? []).some((it) => it.name === 'mandatory')) {
                requiredInputs.push(name);
            }
        }
    }
    const schema = {
        // example: '', // TODO: generate example
        description: '',
        type: 'object',
        properties: properties,
    };
    if (requiredInputs.length > 0) {
        schema.required = requiredInputs;
    }
    const requestBody = {
        required: true,
        content: {
            'application/json': {
                schema: schema,
            },
        },
    };
    return bodyInputs.length > 0 ? requestBody : undefined;
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/hono/hono.extension.ts
var hono_extension_a, hono_extension_b;










let HonoExtension = class HonoExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    triggers = [
        '7a9d9a29-7079-4aa8-bdc0-d93a713a2440',
        '0aec7685-5c19-43eb-bc2c-93597b5cecfc',
    ];
    async handleSetup(details) {
        return [
            // {
            //   filePath: this._projectFS.makeCorePath('adapter.ts'),
            //   content: txt,
            // },
            {
                filePath: this._projectFS.makeSrcPath('main.ts'),
                content: [setup],
            },
        ];
    }
    handleInput(input) {
        const visitor = new hono_extension_SimpleVisitor();
        const { namespace, value } = visitor.visit(parseDsl(input));
        return this.handleInputV2({ namespace, value });
    }
    async handleInputV2({ namespace, value, }) {
        switch (namespace) {
            case 'subject': {
                const visitor = new hono_extension_HonoInputVisitor();
                const result = (await visitor.visit(value));
                if (typeof result === 'string') {
                    if (result === 'authenticated') {
                        return {
                            static: true,
                            type: 'string',
                            value: `await verifyToken(context.req.header('Authorization'))`,
                            structure: [
                                {
                                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                    moduleSpecifier: 'hono',
                                    namedImports: ['Context'],
                                },
                                {
                                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                    moduleSpecifier: `./subject`,
                                    namedImports: ['verifyToken'],
                                },
                            ],
                        };
                    }
                    throw new Error(`Unknown subject accessor: ${result}`);
                }
                return {
                    static: false,
                    type: 'string',
                    value: `context.get('subject').${result.accessor}.${result.accessee}`,
                    validations: [
                        {
                            name: 'mandatory',
                            type: 'mandatory',
                            details: {
                                value: 'true',
                            },
                        },
                    ],
                };
            }
            case 'trigger': {
                const visitor = new hono_extension_HonoInputVisitor();
                const result = (await visitor.visit(value));
                switch (result.accessor) {
                    case 'request':
                        return {
                            static: false,
                            type: 'IncomingMessage',
                            value: `(context.env as { incoming: IncomingMessage }).incoming`,
                            data: { parameterName: 'request' },
                            structure: [
                                // TODO: perhaps we need to split this into imports structure and inner/action structure
                                {
                                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                    moduleSpecifier: 'http',
                                    namedImports: ['IncomingMessage'],
                                },
                            ],
                        };
                    case 'body':
                        return {
                            static: false,
                            // FIXME: 'string' not the correct type here
                            // we need to be smart at guessing that
                            // I can think of new input "@forward:type" or wait, we already have that
                            // I mean the table fields already add types as validation
                            type: 'string',
                            value: `body.${result.accessee}`,
                            data: { parameterName: result.accessee },
                        };
                    case 'path':
                        return {
                            static: false,
                            type: 'string',
                            value: `pathParams.${result.accessee}`,
                            data: { parameterName: result.accessee },
                            validations: [
                                {
                                    name: 'mandatory',
                                    type: 'mandatory',
                                    details: {
                                        value: 'true',
                                    },
                                },
                            ],
                        };
                    case 'query':
                        return {
                            static: false,
                            type: 'string',
                            data: { parameterName: result.accessee },
                            value: `searchParams.${result.accessee}`,
                        };
                    case 'headers':
                        return {
                            static: false,
                            type: 'string',
                            data: { parameterName: result.accessee },
                            value: `context.req.header(${result.accessee})`,
                        };
                    default:
                        return null;
                }
            }
            default:
                return null;
        }
    }
    async extractInputs({ namespace, value, visit, }) {
        if (!['subject', 'trigger'].includes(namespace)) {
            return null;
        }
        const visitor = new hono_extension_InputsExtractor(visit);
        const result = await visitor.visit(value);
        return {
            [result.accessee]: `@${namespace}:${result.accessor}.${result.accessee}`,
        };
    }
    onFeatureContract(contract, addFile) {
        const swaggerSpec = makeSwaggerSpec({
            ...contract,
            workflows: contract.workflows.filter((it) => this.triggers[0] === it.trigger.sourceId),
        });
        addFile({
            filePath: this._projectFS.makeFeatureFile(contract.displayName, `${(0,external_stringcase_.spinalcase)(contract.displayName)}.swagger.json`),
            structure: [JSON.stringify(swaggerSpec, null, 2)],
        });
        // we need to generate empty swagger file at least
        if (contract.workflows.length === 0) {
            return;
        }
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'router'),
            structure: this.#generateController({
                featureName: contract.displayName,
                tags: contract.tags,
                policies: contract.workflows.map((it) => it.trigger.policies).flat(),
            }),
        });
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'router'),
            structure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: 'hono/streaming',
                    namedImports: ['streamSSE'],
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: '@scalar/hono-api-reference',
                    namedImports: ['apiReference'],
                },
                {
                    kind: external_ts_morph_.StructureKind.VariableStatement,
                    declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
                    declarations: [
                        {
                            name: 'router',
                            initializer: `new Hono()`,
                        },
                    ],
                },
                (writer) => writer.writeLine(external_dedent_default() `
            import swagger from './${(0,external_stringcase_.spinalcase)(contract.displayName)}.swagger.json';
            router.get(
              '/reference',
              apiReference({
                spec: { url: swagger as any },
              })
            );
      `),
                ...contract.workflows.map((contract) => {
                    const displayName = `${(0,external_stringcase_.camelcase)(contract.featureName)}.${(0,external_stringcase_.camelcase)(contract.trigger.displayName)}`;
                    const path = removeTrialingSlash(addLeadingSlash((0,external_path_.join)((0,external_stringcase_.snakecase)(contract.tag), contract.trigger.details['path'])));
                    const sourceTrigger = this._devKit.getSourceActionById(contract.trigger.sourceId);
                    switch (sourceTrigger.name) {
                        case 'http': {
                            const verb = `router.${contract.trigger.details['method']}`;
                            const authorize = contract.trigger.policies.length
                                ? `,authorize(${contract.trigger.policies
                                    .map(external_stringcase_.camelcase)
                                    .join(',')})`
                                : '';
                            return `${verb.toLowerCase()}("${path}" ${authorize}, ${displayName})`;
                        }
                        case 'sse': {
                            const verb = `router.get`;
                            const authorize = contract.trigger.policies.length
                                ? `,authorize(${contract.trigger.policies
                                    .map(external_stringcase_.camelcase)
                                    .join(',')})`
                                : '';
                            return `${verb.toLowerCase()}("${path}" ${authorize}, context=>{
  return streamSSE(context, async (stream) => {
    for await (const chunk of await ${displayName}(
      context,
    )) {
      stream.writeSSE({ data: JSON.stringify(chunk) });
    }
  });
              })`;
                        }
                        default:
                            throw new Error(`Trigger ${sourceTrigger.name} is not supported`);
                    }
                }),
                {
                    kind: external_ts_morph_.StructureKind.ExportAssignment,
                    isExportEquals: false,
                    expression: `['/${(0,external_stringcase_.spinalcase)(contract.displayName)}', router] as const`,
                },
            ],
        });
    }
    #generateController(contract) {
        return [
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                namedImports: ['Hono'],
                moduleSpecifier: 'hono',
            },
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: '../../identity',
                namedImports: ['authorize'],
            },
            ...contract.policies.map((it) => ({
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: `../../identity/${(0,external_stringcase_.spinalcase)(it)}.policy`,
                namedImports: [(0,external_stringcase_.camelcase)(it)],
            })),
            // import * as {featureName} from './routes'
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: `./routes`,
                namespaceImport: (0,external_stringcase_.camelcase)(contract.featureName),
            },
        ];
    }
    async processTrigger(contract, workflowInputs) {
        const trigger = await this._devKit.getSourceActionById(contract.sourceId);
        const displayName = (0,external_stringcase_.camelcase)(contract.displayName);
        const inputName = (0,external_stringcase_.camelcase)('input');
        const outputName = (0,external_stringcase_.camelcase)('output');
        const vars = {};
        for (const input of Object.values(contract.inputs)) {
            if (typeof input === 'string' || isNullOrUndefined(input.value)) {
                continue;
            }
            const value = input.value;
            if (value.startsWith('body') && !vars['body']) {
                vars['body'] = 'const body = await context.req.json()';
            }
            if (value.startsWith('pathParams') && !vars['pathParams']) {
                vars['pathParams'] = 'const pathParams = context.req.param()';
            }
            if (value.startsWith('searchParams') && !vars['searchParams']) {
                vars['searchParams'] = 'const searchParams = context.req.query()';
            }
        }
        const inputParams = signutureInputs({ ...contract.inputs });
        const actionInputsStr = this._devKit.toLiteralObject(inputParams);
        const workflowLoneParams = signutureInputs({ ...workflowInputs });
        for (const [name, prop] of workflowLoneParams) {
            vars[name] = `const ${name} = ${prop.value}`;
        }
        const workflowParams = [];
        if (inputParams.length) {
            workflowParams.push(inputName);
        }
        if (workflowLoneParams.length) {
            workflowParams.push(...workflowLoneParams.map(([name]) => name));
        }
        const workflowInputsStructures = Object.values(workflowInputs)
            .map((prop) => prop.structure)
            .filter(Boolean);
        switch (trigger.name) {
            case 'sse':
                return [
                    {
                        filePath: this._projectFS.makeIndexFilePath(contract.featureName, 'routes'),
                        structure: [
                            {
                                kind: external_ts_morph_.StructureKind.ExportDeclaration,
                                moduleSpecifier: this._projectFS.makeExportPath(contract.displayName, `route`),
                            },
                        ],
                    },
                    {
                        filePath: this._projectFS.makeControllerRoutePath(contract.featureName, contract.displayName),
                        structure: [
                            ...workflowInputsStructures.flat(),
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: `../${(0,external_stringcase_.spinalcase)(contract.tag)}`,
                                namespaceImport: (0,external_stringcase_.camelcase)(contract.tag),
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: 'lodash-es',
                                namedImports: ['pick'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                                namedImports: ['validateOrThrow'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: 'hono',
                                namedImports: ['Hono', 'Context', 'Next'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.Function,
                                isAsync: true,
                                isDefaultExport: false,
                                isExported: true,
                                name: displayName,
                                parameters: [{ name: 'context', type: 'Context' }],
                                statements: [
                                    ...Object.values(vars),
                                    (writer) => writer.conditionalWriteLine(!!inputParams.length, `const ${inputName} = ${actionInputsStr}`),
                                    (writer) => writer.conditionalWriteLine(!!inputParams.length, `validateOrThrow(${(0,external_stringcase_.camelcase)(contract.tag)}.${contract.schemaName}, ${inputName})`),
                                    (writer) => writer.writeLine(`const ${outputName} = await ${(0,external_stringcase_.camelcase)(contract.tag)}.${(0,external_stringcase_.camelcase)(contract.operationName)}(${workflowParams.join(',')})`),
                                    (writer) => writer.writeLine(`return ${outputName}`),
                                ],
                            },
                        ],
                    },
                ];
            case 'http': {
                return [
                    {
                        filePath: this._projectFS.makeIndexFilePath(contract.featureName, 'routes'),
                        structure: [
                            {
                                kind: external_ts_morph_.StructureKind.ExportDeclaration,
                                moduleSpecifier: this._projectFS.makeExportPath(contract.displayName, `route`),
                            },
                        ],
                    },
                    {
                        filePath: this._projectFS.makeControllerRoutePath(contract.featureName, contract.displayName),
                        structure: [
                            ...workflowInputsStructures.flat(),
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: `../${(0,external_stringcase_.spinalcase)(contract.tag)}`,
                                namespaceImport: (0,external_stringcase_.camelcase)(contract.tag),
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: 'lodash-es',
                                namedImports: ['pick'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                                namedImports: ['validateOrThrow'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: 'hono',
                                namedImports: ['Hono', 'Context', 'Next'],
                            },
                            {
                                kind: external_ts_morph_.StructureKind.Function,
                                isAsync: true,
                                isDefaultExport: false,
                                isExported: true,
                                name: displayName,
                                parameters: [
                                    { name: 'context', type: 'Context' },
                                    { name: 'next', type: 'Next' },
                                ],
                                statements: [
                                    ...Object.values(vars),
                                    (writer) => writer.conditionalWriteLine(!!inputParams.length, `const ${inputName} = ${actionInputsStr}`),
                                    (writer) => writer.conditionalWriteLine(!!inputParams.length, `validateOrThrow(${(0,external_stringcase_.camelcase)(contract.tag)}.${contract.schemaName}, ${inputName})`),
                                    (writer) => writer.writeLine(`const ${outputName} = await ${(0,external_stringcase_.camelcase)(contract.tag)}.${(0,external_stringcase_.camelcase)(contract.operationName)}(${workflowParams.join(',')})`),
                                    (writer) => writer.writeLine(`return context.json(${outputName})`),
                                ],
                            },
                        ],
                    },
                ];
            }
            default:
                throw new Error(`Trigger ${trigger.name} is not supported`);
        }
    }
    getServerSetup(exportApp, platform) {
        return external_dedent_default()(`
import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import application from './main';
import { relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { showRoutes } from 'hono/dev'

${platform === 'vercel' ? `import { handle } from '@hono/node-server/vercel'` : ''}

  const dirRelativeToCwd = relative(process.cwd(), dirname(fileURLToPath(import.meta.url)));

  application.use(
    '/:filename{.+\\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

  application.use('/:filename{.+\\\.swagger\\\.json$}', serveStatic({
    root: dirRelativeToCwd,
    rewriteRequestPath: (path) => path.split('/').pop() as string,
  }));

serve({
  fetch: application.fetch,
  port: parseInt(process.env.PORT ?? '3000', 10),
});

console.log(\`Server running at http://localhost:\${process.env.PORT ?? '3000'}\`);

if(process.env.NODE_ENV === 'development'){
  showRoutes(application, {
    verbose: true,
  });
}

${exportApp ? `export default handle(application);` : ''}

`);
    }
};
HonoExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (hono_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? hono_extension_a : Object, typeof (hono_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? hono_extension_b : Object])
], HonoExtension);

class hono_extension_HonoInputVisitor extends AsyncVisitor {
    visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visitIdentifier(node) {
        return node.value;
    }
    async visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visit(node) {
        return node.accept(this);
    }
}
class hono_extension_InputsExtractor extends StringAsyncVisitor {
    _visitor;
    constructor(_visitor) {
        super();
        this._visitor = _visitor;
    }
    async visitArg(node) {
        throw new Error('Method not implemented.');
    }
    async visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    async visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    async visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visit(node) {
        return node.accept(this);
    }
}
class hono_extension_SimpleVisitor extends StringVisitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.accept(this),
            value: node.expression,
        };
    }
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/identity/authorize.txt
/* harmony default export */ const authorize = ("import {\n  ProblemDetails,\n  ProblemDetailsException,\n} from 'rfc-7807-problem-details';\n\nexport function authorize<T>(\n  ...routePolicies: ((context: T) => Promise<boolean> | boolean)[]\n) {\n  return async (context: T, next: any) => {\n    for (const policy of routePolicies) {\n      if (!await policy(context)) {\n        throw new ProblemDetailsException(\n          new ProblemDetails('forbidden', 'no sufficient permissions', 403),\n        );\n      }\n    }\n    await next();\n  };\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/identity/index.txt
/* harmony default export */ const identity = ("export * from './authorize';\nexport * from './subject';");
;// CONCATENATED MODULE: ../compiler/core/src/lib/identity/subject.txt
/* harmony default export */ const identity_subject = ("import { IncomingMessage } from 'http';\nimport { getClientIp } from 'request-ip';\nimport UAParser, { IResult } from 'ua-parser-js';\n\nexport interface ClientInfo {\n  ip?: string | null;\n  userAgent?: string | null;\n  userAgentData: IResult;\n}\nexport type IdentitySubject = {\n  info: ClientInfo;\n};\n\nexport async function verifyToken(token:string): Promise<boolean> {\n  return true;\n}\n\nexport async function loadSubject(\n  token: string | null | undefined,\n): Promise<IdentitySubject | null> {\n  return null;\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/identity/identity.extension.ts
var identity_extension_a;






let IdentityExtension = class IdentityExtension {
    _projectFS;
    constructor(_projectFS) {
        this._projectFS = _projectFS;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeIdentityPath('index.ts'),
                content: [identity],
            },
            {
                filePath: this._projectFS.makeIdentityPath('authorize.ts'),
                content: [authorize],
            },
            {
                filePath: this._projectFS.makeIdentityPath('subject.ts'),
                content: [identity_subject],
            },
        ];
    }
};
IdentityExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (identity_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? identity_extension_a : Object])
], IdentityExtension);

// THOSE COMMENTS MOVED OUT OF subject.ts file
// FIXME: the loadSubject subject should only accept generic interface
// and each routing framework should adhere to provie the implementation
// based on the framework specifity
// should be moved to own extension or be part of routing extension
// function clientInfo(req: IncomingMessage) {
//   const userAgent = req.headers['user-agent'];
//   const ip = getClientIp(req);
//   const parser = new UAParser(userAgent);
//   const userAgentData = parser.getResult();
//   return {
//     ip,
//     userAgent,
//     userAgentData,
//   };
// }

;// CONCATENATED MODULE: ../compiler/core/src/lib/koajs/setup.txt
/* harmony default export */ const koajs_setup = ("import cors from '@koa/cors';\nimport { StatusCodes } from 'http-status-codes';\nimport Koa from 'koa';\nimport bodyParser from 'koa-bodyparser';\nimport logger from 'koa-logger';\nimport koaQs from 'koa-qs';\nimport serve from 'koa-static';\nimport path from 'path';\nimport { problemDetailsMiddleware } from 'rfc-7807-problem-details';\n\nimport dataSource from './core/data-source';\nimport { loadSubject } from './identity';\nimport routes from './features/routes';\n\nconst application = koaQs(new Koa().use(cors({ origin: '*' })).use(logger()));\n\nconst bp = bodyParser();\napplication.use(\n  problemDetailsMiddleware.koa((options) => {\n    // options.rethrow(Error);\n    options.mapToStatusCode(Error, StatusCodes.INTERNAL_SERVER_ERROR);\n  })\n);\napplication.use((ctx, next) => {\n  // Prevent koa-bodyparser from parsing already parsed body\n  ctx.request.body = ctx.request.body || (ctx.req as any).body;\n  return bp(ctx, next);\n});\n\napplication.use(async (context,next)=>{\n  const subject = await loadSubject(context.req);\n  context.state.subject = subject;\n  await next();\n})\n\nroutes.forEach((route) => {\n  application.use(route.routes());\n});\n\napplication.use((context, next) => {\n  if (context.path === '/') {\n    context.status = StatusCodes.OK;\n    context.body = {\n      status: 'UP',\n    };\n    return;\n  }\n  if (context.path === '/health') {\n    context.status = StatusCodes.OK;\n    context.body = {\n      status: 'UP',\n    };\n    return;\n  }\n  next();\n});\n\napplication.use(serve(path.join(__dirname, 'assets')));\n\ndataSource\n  .initialize()\n  .then(() => {\n    console.log('Database initialized');\n  })\n  .catch((error) => {\n    console.error(error);\n    process.exit(1);\n  });\n\nexport default application;\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/koajs/koajs.extension.ts
var koajs_extension_a, koajs_extension_b;









let KoaJsExtension = class KoaJsExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    async handleSetup(details) {
        return [
            {
                filePath: this._projectFS.makeSrcPath('main.ts'),
                content: [koajs_setup],
            },
        ];
    }
    triggers = ['http', 'sse'];
    handleInput(input) {
        const { namespace, value } = toSimple(input);
        switch (namespace) {
            case 'subject':
                return {
                    static: false,
                    type: 'string',
                    value: `context.subject.${value}`,
                    validations: [
                        {
                            name: 'mandatory',
                            type: 'mandatory',
                            details: {
                                value: 'true',
                            },
                        },
                    ],
                };
            case 'trigger': {
                switch (true) {
                    case value.startsWith('body'):
                        return {
                            static: false,
                            type: 'string',
                            // value: this._devKit.substring(value, 'body.'),
                            value: `(context.request.body as Record<string, any>).${this._devKit.substring(value, 'body.')}`,
                        };
                    case value.startsWith('path'):
                        return {
                            static: false,
                            type: 'string',
                            value: `context.params.${this._devKit.substring(value, 'path.')}`,
                            validations: [
                                {
                                    name: 'mandatory',
                                    type: 'mandatory',
                                    details: {
                                        value: 'true',
                                    },
                                },
                            ],
                        };
                    case value.startsWith('query'):
                        return {
                            static: false,
                            type: 'string',
                            value: `(context.query as Record<string, any>).${this._devKit.substring(value, 'query.')}`,
                        };
                    case value.startsWith('headers'):
                        return {
                            static: false,
                            type: 'string',
                            // value: this._devKit.substring(value, 'headers.'),
                            value: `context.headers.${this._devKit.substring(value, 'headers.')}`,
                        };
                    default:
                        return null;
                }
            }
            default:
                return null;
        }
    }
    onFeatureContract(contract, addFile) {
        const swaggerSpec = makeSwaggerSpec(contract);
        addFile({
            filePath: this._projectFS.makeFeatureFile(contract.displayName, 'swagger.json'),
            structure: [JSON.stringify(swaggerSpec, null, 2)],
        });
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'router'),
            structure: this.#generateController({
                featureName: contract.displayName,
                tags: contract.tags,
                policies: contract.workflows.map((it) => it.trigger.policies).flat(),
            }),
        });
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'router'),
            structure: [
                {
                    kind: external_ts_morph_.StructureKind.VariableStatement,
                    declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
                    declarations: [
                        {
                            name: 'router',
                            initializer: `new Router({prefix: '/${(0,external_stringcase_.spinalcase)(contract.displayName)}'})`,
                        },
                    ],
                },
                ...contract.workflows.map((contract) => {
                    const displayName = `${(0,external_stringcase_.camelcase)(contract.featureName)}.${(0,external_stringcase_.camelcase)(contract.trigger.displayName)}`;
                    const path = addLeadingSlash((0,external_path_.join)(contract.trigger.details['path'], (0,external_stringcase_.snakecase)(contract.tag)));
                    const verb = `router.${contract.trigger.details['method']}`;
                    const authorize = contract.trigger.policies.length
                        ? `,authorize(${contract.trigger.policies
                            .map((it) => `${(0,external_stringcase_.camelcase)(it)}`)
                            .join(',')})`
                        : '';
                    return `${verb}("${path}" ${authorize}, ${displayName})`;
                }),
                {
                    kind: external_ts_morph_.StructureKind.ExportAssignment,
                    isExportEquals: false,
                    expression: 'router',
                },
            ],
        });
    }
    #generateController(contract) {
        return [
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                defaultImport: 'Router',
                moduleSpecifier: '@koa/router',
            },
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: '../../identity',
                namedImports: ['authorize'],
            },
            ...contract.policies.map((it) => ({
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: `../../identity/${(0,external_stringcase_.spinalcase)(it)}.policy`,
                namedImports: [(0,external_stringcase_.camelcase)(it)],
            })),
            // import * as {featureName} from './routes'
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: `./routes`,
                namespaceImport: (0,external_stringcase_.camelcase)(contract.featureName),
            },
        ];
    }
    async processTrigger(contract) {
        const displayName = (0,external_stringcase_.camelcase)(contract.displayName);
        const inputName = (0,external_stringcase_.camelcase)('input');
        const outputName = (0,external_stringcase_.camelcase)('output');
        const actionInputsStr = `${this._devKit.toLiteralObject(contract.inputs)}`;
        return [
            {
                filePath: this._projectFS.makeControllerRoutePath(contract.featureName, contract.displayName),
                structure: [
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: `../${(0,external_stringcase_.spinalcase)(contract.tag)}`,
                        namespaceImport: (0,external_stringcase_.camelcase)(contract.tag),
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: 'lodash-es',
                        namedImports: ['pick'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                        namedImports: ['validateOrThrow'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: '@koa/router',
                        namedImports: ['RouterContext'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: 'koa',
                        namedImports: ['Next'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.Function,
                        isAsync: true,
                        isDefaultExport: false,
                        isExported: true,
                        name: displayName,
                        parameters: [
                            { name: 'context', type: 'RouterContext' },
                            { name: 'next', type: 'Next' },
                        ],
                        statements: [
                            `const ${inputName} = ${actionInputsStr}`,
                            (writer) => writer.conditionalWriteLine(actionInputsStr.trim().length > 0, `validateOrThrow(${(0,external_stringcase_.camelcase)(contract.tag)}.${contract.schemaName}, ${inputName})`),
                            // (writer) => writer.writeLine(`context.can({})`),
                            (writer) => writer.writeLine(`const ${outputName} = await handleOperation('${contract.operationName}', ${inputName})`),
                            (writer) => writer.writeLine(`context.body = ${outputName}`),
                            (writer) => writer.writeLine(`await next()`),
                        ],
                    },
                ],
            },
        ];
    }
    getServerSetup() {
        return external_dedent_default() `
        import application from './main';
        const host = process.env['HOST'] ?? '0.0.0.0';
        const port = parseInt(process.env['PORT'] || '3000') ;
        application.listen(port, host);
        console.log(\`http://\${host}:\${port}\`);
        	`;
    }
};
KoaJsExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (koajs_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? koajs_extension_a : Object, typeof (koajs_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? koajs_extension_b : Object])
], KoaJsExtension);


;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/date.txt
/* harmony default export */ const postgresql_date = ("function getQuarter(date: Date) {\n  return Math.floor(date.getMonth() / 3 + 1);\n}\n\nconst baseDate = (date: string | Date = new Date()) => {\n  if (typeof date === 'string') {\n    date = new Date(date);\n  }\n  date.setHours(0, 0, 0, 0);\n  return date;\n};\n\nconst addDays = (data: { date: Date; days: number }) => {\n  const { date, days } = data;\n  const newDate = baseDate(date);\n  newDate.setDate(date.getDate() + days);\n  return newDate;\n};\n\nconst addWeeks = (data: { date: Date; weeks: number }) => {\n  const { date, weeks } = data;\n  return addDays({ date, days: weeks * 7 });\n};\n\nconst addMonths = (data: { date: Date; months: number }) => {\n  const { date, months } = data;\n  const newDate = baseDate(date);\n  newDate.setMonth(date.getMonth() + months);\n  return newDate;\n};\n\nconst addQuarters = (data: { date: Date; quarters: number }) => {\n  const { date, quarters } = data;\n  //Remove middle months\n  const quarter = getQuarter(date);\n  const newDate = baseDate(date);\n  newDate.setMonth(date.getMonth() - (date.getMonth() - quarter * 3) - 1);\n  //add months\n  return addMonths({ date: newDate, months: quarters * 3 });\n};\n\nconst addYears = (data: { date: Date; years: number }) => {\n  const { date, years } = data;\n  const newDate = baseDate(date);\n  newDate.setFullYear(date.getFullYear() + years);\n  return newDate;\n};\n\nconst toISOString = (date: Date) => date.toISOString();\n\nexport const today = () => toISOString(baseDate());\n\nexport const day = (data: { date?: string; amount: number }) => {\n  const { date, amount } = data;\n  return toISOString(addDays({ date: baseDate(date), days: amount }));\n};\nexport const week = (data: { date?: string; amount: number }) => {\n  const { date, amount } = data;\n  const newDate = baseDate(date);\n  const startOfWeek = newDate.setDate(newDate.getDate() - newDate.getDay());\n  newDate.setDate(startOfWeek);\n  return toISOString(addWeeks({ date: newDate, weeks: amount }));\n};\nexport const month = (data: { date?: string; amount: number }) => {\n  const { date, amount } = data;\n  const newDate = baseDate(date);\n  newDate.setDate(0);\n  return toISOString(addMonths({ date: newDate, months: amount }));\n};\nexport const year = (data: { date?: string; amount: number }) => {\n  const { date, amount } = data;\n  const newDate = baseDate(date);\n  newDate.setDate(0);\n  newDate.setMonth(0);\n  return toISOString(addYears({ date: newDate, years: amount }));\n};\nexport const quarter = (data: { date?: string; amount: number }) => {\n  const { date, amount } = data;\n  const newDate = baseDate(date);\n  const quarter = getQuarter(newDate);\n  newDate.setMonth(quarter * 3);\n  return toISOString(addQuarters({ date: newDate, quarters: amount }));\n};\n\nexport const currentDay = () => {\n  const date = baseDate();\n  date.setHours(0, 0, 0, 0);\n  return toISOString(date);\n};\n\nexport const currentWeek = () => {\n  const date = baseDate();\n  const startOfWeek = date.setDate(date.getDate() - date.getDay());\n  date.setDate(startOfWeek);\n  return toISOString(date);\n};\n\nexport const currentMonth = () => {\n  const date = baseDate();\n  date.setDate(0);\n  return toISOString(date);\n};\n\nexport const currentYear = () => {\n  const date = baseDate();\n  date.setDate(0);\n  date.setMonth(0);\n  return toISOString(date);\n};\n\nexport const currentQuarter = () => {\n  const date = baseDate();\n  const quarter = getQuarter(date);\n  date.setMonth(quarter * 3);\n  return toISOString(date);\n};\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/execute.txt
/* harmony default export */ const execute = ("import sqlTag, { RawValue } from 'sql-template-tag';\nimport { camelCase } from 'lodash-es';\nimport {\n  Brackets,\n  DeepPartial,\n  EntityManager,\n  EntityTarget,\n  ObjectLiteral,\n  QueryRunner,\n  SelectQueryBuilder,\n  WhereExpressionBuilder,\n} from 'typeorm';\nimport dataSource from './data-source';\nimport { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';\nimport { Transform } from 'node:stream';\nexport type ExecutePipeline<I extends ObjectLiteral> = <\n  O extends Record<string, any>,\n>(\n  domainEntity: I,\n  rawEntity: Record<string, any>,\n) => I;\n\nexport async function execute<U extends ObjectLiteral>(\n  qb: SelectQueryBuilder<U>,\n  ...mappers: ExecutePipeline<U>[]\n) {\n  const { entities, raw } = await qb.getRawAndEntities();\n  return entities.map((entity, index) => {\n    return mappers.reduce((acc, mapper) => {\n      return mapper(acc, raw[index]);\n    }, entity);\n  });\n}\n\n/**\n * Begin a transaction and execute a computation. If the computation succeeds, the transaction is committed. If the computation fails, the transaction is rolled back.\n *\n * @param computation async function that takes a `EntityManager` and returns a `Promise`\n * @returns the result of the computation\n * @throws the error thrown by the computation or the error thrown by the transaction\n * @example\n *\n * // If the computation succeeds, the transaction is committed\n *\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  return user;\n * });\n *\n * // result is the updated user\n *\n * // If the computation fails, the transaction is rolled back\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  throw new Error('Something went wrong');\n * });\n *\n * // result is undefined\n * // If the transaction fails, the error is thrown\n * const result = await useTransaction(async (manager) => {\n *  const user = await manager.findOne(User, 1);\n *  user.name = 'New Name';\n *  await manager.save(user);\n *  await manager.query('DROP TABLE users');\n * });\n *\n */\nexport async function useTransaction<TResult>(\n  computation: (manager: EntityManager) => Promise<TResult>,\n) {\n  let queryRunner: QueryRunner = dataSource.createQueryRunner();\n  await queryRunner.connect();\n  await queryRunner.startTransaction();\n  try {\n    const result = await computation(queryRunner.manager);\n    await queryRunner.commitTransaction();\n    return result;\n  } catch (error) {\n    await queryRunner.rollbackTransaction();\n    await queryRunner.release();\n    (queryRunner as any) = null;\n    throw error;\n  }\n}\n\nexport function limitOffsetPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    pageNo?: number;\n    pageSize?: number;\n    count: number;\n  },\n) {\n  const pageSize = Number(options.pageSize||50);\n  const pageNo = Number(options.pageNo||1);\n  const offset = (pageNo - 1) * pageSize;\n  qb.take(pageSize);\n  qb.skip(offset);\n\n  return (result: Entity[]) => ({\n    hasNextPage: result.length === pageSize,\n    hasPreviousPage: offset > 0,\n    pageSize: options.pageSize,\n    currentPage: options.pageNo,\n    totalCount: options.count,\n    totalPages: Math.ceil(options.count / options.pageSize),\n  });\n}\n\nexport function deferredJoinPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    pageNo?: number | string | undefined;\n    pageSize?: number | string | undefined;\n    count: number;\n  },\n) {\n  const pageSize = Number(options.pageSize||50);\n  const pageNo = Number(options.pageNo||1);\n  const offset = (pageNo - 1) * pageSize;\n\n  const { tablePath: tableName } = qb.expressionMap.findAliasByName(qb.alias);\n  if (!tableName) {\n    throw new Error(`Could not find table path for alias ${qb.alias}`);\n  }\n\n  const subQueryAlias = `deferred_join_${tableName}`;\n  qb.innerJoin(\n    (subQuery) => {\n      const subQueryTableAlias = `deferred_${tableName}`;\n\n      return subQuery\n        .from(tableName, subQueryTableAlias)\n        .select(`${subQueryTableAlias}.id`, 'id')\n        .orderBy(`${subQueryTableAlias}.createdAt`)\n        .limit(pageSize)\n        .offset(offset);\n    },\n    subQueryAlias,\n    `${qb.alias}.id = ${subQueryAlias}.id`,\n  );\n  return (result: Entity[]) => ({\n    hasNextPage: result.length === pageSize,\n    hasPreviousPage: offset > 0,\n    pageSize: options.pageSize,\n    currentPage: options.pageNo,\n    totalCount: options.count,\n    totalPages: Math.ceil(options.count / pageSize),\n  });\n}\n\nexport function cursorPagination<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n  options: {\n    count: number;\n    pageSize: number;\n    /**\n     * Base64 encoded string of the last record's cursor\n     */\n    cursor?: string; // we shouldn't need to specify before or after cursor, the cursor should be enough\n  },\n) {\n  const cursorPayload = options.cursor\n    ? JSON.parse(Buffer.from(options.cursor, 'base64').toString('utf-8'))\n    : null;\n  const alias = qb.alias;\n\n  let orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n  if (!orderByColumns.includes(`${alias}.createdAt`)) {\n    // always order by createdAt to ensure a consistent order\n    // createdAt will be either first order by in case no order by is specified by the caller function or last order by in case the caller function specified an order by\n    qb.addOrderBy(`${alias}.createdAt`);\n  }\n  if (!orderByColumns.includes(`${alias}.id`)) {\n    // fallback to order by id if more than one record is duplicated (have the same attributes used in order by clause)\n    qb.addOrderBy(`${alias}.id`);\n  }\n\n  orderByColumns = Object.keys(qb.expressionMap.orderBys);\n\n  if (cursorPayload) {\n    qb.andWhere(\n      new Brackets((qb) => {\n        function withCurrentColumn(qb: WhereExpressionBuilder, index: number) {\n          const column = orderByColumns[index];\n          const paramName = camelCase(\n            `last ${getColumnNameWithoutAlias(column, alias)}`,\n          );\n          qb.andWhere(`${column} > :${paramName}`, {\n            [paramName]: cursorPayload[paramName],\n          });\n        }\n\n        for (let index = 0; index < orderByColumns.length; index++) {\n          if (index === 0) {\n            withCurrentColumn(qb, index);\n            continue;\n          }\n          qb.orWhere(\n            new Brackets((qb) => {\n              for (let j = 0; j < index; j++) {\n                const previousColumn = orderByColumns[j];\n                const paramName = camelCase(\n                  `last ${getColumnNameWithoutAlias(previousColumn, alias)}`,\n                );\n                qb.andWhere(`${previousColumn} = :${paramName}`, {\n                  [paramName]: cursorPayload[paramName],\n                });\n              }\n              withCurrentColumn(qb, index);\n            }),\n          );\n        }\n      }),\n    );\n  }\n\n  qb.take(options.pageSize + 1);\n  return (result: Entity[]) => ({\n    nextCursor: Buffer.from(\n      JSON.stringify(\n        orderByColumns.reduce<Record<string, any>>((acc, column) => {\n          const paramName = camelCase(\n            `last ${getColumnNameWithoutAlias(column, alias)}`,\n          );\n          return {\n            ...acc,\n            [paramName]: qb.expressionMap.parameters[paramName],\n          };\n        }, {}),\n      ),\n    ).toString('base64'),\n    previousCursor: null,\n    startCursor: null, // always null\n    endCursor: '', // think of it as startCursor but the order is reversed\n    hasNextPage: false, // if there is nextCursor, then there is a next page\n    hasPreviousPage: false, // if there is previousCursor, then there is a previous page\n    pageSize: options.pageSize,\n    totalCount: options.count,\n  });\n}\n\nexport function getEntityById<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  id: string,\n) {\n  const qb = createQueryBuilder(entity, 'entity')\n  .where('entity.id = :id', {\n    id,\n  })\n  .limit(1);\n  return qb.getOne();\n}\n\n\nfunction getColumnNameWithoutAlias(column: string, alias: string) {\n  return column.replace(`${alias}.`, '');\n}\n\nexport function createQueryBuilder<Entity extends ObjectLiteral>(\n  entity: EntityTarget<Entity>,\n  alias: string,\n) {\n  const repo = dataSource.getRepository(entity);\n  return repo.createQueryBuilder(alias);\n}\n\nexport async function removeEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(entityType: EntityTarget<Entity>, qb: SelectQueryBuilder<T>) {\n  const repo = dataSource.getRepository(entityType);\n  const entity = await qb.getOneOrFail();\n  await repo.softRemove(entity);\n  return entity;\n}\n\nexport async function patchEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>,\n) {\n  const result = await qb\n    .update()\n    .set(entity as unknown as Entity)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function setEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  qb: SelectQueryBuilder<T>,\n  entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  // TODO: should throw an error if the entity does not exist or one of the required filed is missing\n  // put replaces the whole record one met validation\n  return patchEntity(qb, entity);\n}\n\nexport async function increment<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :incrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('incrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport async function decrement<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n  Column extends Exclude<\n    keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>,\n    symbol | number\n  >,\n>(qb: SelectQueryBuilder<T>, column: Column, value: number | string) {\n  const setRecord: QueryDeepPartialEntity<Entity> = {\n    [column]: () => `${column} + :decrementValue`,\n  } as Entity;\n  const result = await qb\n    .update()\n    .set(setRecord as never)\n    .setParameter('decrementValue', value)\n    .execute();\n  return (result.affected ?? 0) > 0;\n}\n\nexport function saveEntity<\n  Entity extends ObjectLiteral,\n  T extends DeepPartial<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n) {\n  const repo = dataSource.getRepository(entityType);\n  return repo.save(entity as T);\n}\n\nexport async function upsertEntity<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(\n  entityType: EntityTarget<Entity>,\n  entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>,\n  conflictColumns: Extract<keyof (Entity & { id: string }), string>[] = ['id'],\n) {\n  const repo = dataSource.getRepository(entityType);\n  await repo\n    .createQueryBuilder()\n    .insert()\n    .into(entityType)\n    .values(entity as T)\n    .orUpdate(Object.keys(entity), conflictColumns)\n    .execute();\n}\n\nexport function sql(\n  strings: readonly string[],\n  ...values: readonly RawValue[]\n) {\n  const serializedSQL = sqlTag(strings, ...values);\n  return dataSource.query(serializedSQL.sql, serializedSQL.values);\n}\n\nexport function exists<Entity extends ObjectLiteral>(\n  qb: SelectQueryBuilder<Entity>,\n) {\n  return qb.getOne().then(Boolean);\n}\n\nexport async function stream<\n  Entity extends ObjectLiteral,\n  T extends QueryDeepPartialEntity<Entity>,\n>(qb: SelectQueryBuilder<T>) {\n  const stream = await qb.stream();\n  return stream.pipe(\n    new Transform({\n      objectMode: true,\n      transform(record, encoding, callback) {\n        callback(\n          null,\n          JSON.stringify(\n            Object.fromEntries(\n              Object.entries(record).map(([key, value]) => [\n                key.replace(/projects_/g, ''),\n                value,\n              ]),\n            ),\n          ),\n        );\n      },\n    }),\n  );\n}\n");
;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/i18n.txt
/* harmony default export */ const i18n = ("import { ObjectLiteral, SelectQueryBuilder } from 'typeorm';\n\nimport Translations from '../features/i18n/translations.entity';\n\n/**\n * Add i18n field to the query. The field is a json array of translations\n * for the given locales, if the locales is empty or contains '*' then\n * the i18n field is ignored.\n *\n * @example withI18n(qb, 'fr,en')\n * @example withI18n(qb, ['fr', 'en'])\n *\n * @param qb query builder\n * @param locales comma separated list of locales or array of locales\n * @returns join locale table and add i18n field to the query\n */\nexport function withI18n<T extends SelectQueryBuilder<any>>(\n  qb: T,\n  locales?: string | string[]\n) {\n  let localesArray: string[] = [];\n  if (locales) {\n    if (typeof locales === 'string') {\n      localesArray = locales.split(',');\n    } else if (Array.isArray(locales)) {\n      localesArray = locales;\n    }\n  }\n\n  const ignore = localesArray.includes('*') || localesArray.length === 0;\n  if (ignore) {\n    return qb;\n  }\n\n  localesArray = localesArray.map((locale) => locale.trim()); // remove whitespaces\n\n  return qb\n    .addSelect(\"'[' || GROUP_CONCAT(translations.i18n) || ']' as i18n\")\n    .leftJoin(\n      Translations,\n      'translations',\n      `translations.entityId = ${qb.alias}.id AND translations.locale IN (:...locales)`,\n      { locales: localesArray }\n    );\n}\n\n/**\n * Assign i18n field to the entity\n */\nexport function assignI18n<T extends ObjectLiteral>(): ExecutePipeline<T> {\n  return (entity, raw) => {\n    const out = Object.assign(entity, {\n      i18n: raw.i18n,\n    });\n    return out;\n  };\n}\n");
// EXTERNAL MODULE: external "pluralize"
var external_pluralize_ = __webpack_require__(30);
var external_pluralize_default = /*#__PURE__*/__webpack_require__.n(external_pluralize_);
;// CONCATENATED MODULE: ../compiler/core/src/lib/registry/dsl-dsl.visitor.ts




class dsl_dsl_visitor_InputsExtractor extends StringAsyncVisitor {
    _visitor;
    constructor(_visitor) {
        super();
        this._visitor = _visitor;
    }
    async visitArg(node) {
        return node.value.accept(this);
    }
    async visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    async visitCall(node) {
        const list = [];
        for (const arg of node.args) {
            list.push(await arg.accept(this));
        }
        return list;
    }
    async visitPropertyAccess(node) {
        throw new Error('Method not implemented.');
    }
    async visitNamespace(node) {
        return this._visitor.visit(node);
    }
    async visit(node) {
        return node.accept(this);
    }
}
class InputDslToQueryDslVisitor extends Visitor {
    visitArg(node) {
        return {
            name: node.name.accept(this),
            value: node.value.accept(this),
        };
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return {
            tableName: node.name.accept(this),
            args: node.args.map((arg) => arg.accept(this)),
        };
    }
    visitPropertyAccess(node) {
        return {
            ...node.name.accept(this),
            // fix it array. in the future it will be an array
            // prop.{first,second}
            columns: [node.expression.accept(this)],
        };
    }
    visitNamespace(node) {
        return {
            ...node.expression.accept(this),
        };
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
class AsyncInputDslToQueryDslVisitor extends StringAsyncVisitor {
    _context;
    constructor(_context) {
        super();
        this._context = _context;
    }
    get _inputParser() {
        return external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
    }
    async visitArg(node) {
        return {
            name: await node.name.accept(this),
            value: await node.value.accept(this),
        };
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    async visitCall(node) {
        return {
            tableName: await node.name.accept(this),
            args: await Promise.all(node.args.map((arg) => arg.accept(this))),
        };
    }
    async visitPropertyAccess(node) {
        return {
            ...(await node.name.accept(this)),
            // fix it array. in the future it will be an array
            // prop.{first,second}
            columns: [await node.expression.accept(this)],
        };
    }
    async visitNamespace(node) {
        const returnValue = this._inputParser.parseInputV2({
            namespace: await node.name.accept(this),
            value: node.expression,
        });
        return returnValue;
    }
}
async function toQueryDslAsync(context, node) {
    const visitor = new AsyncInputDslToQueryDslVisitor(context);
    const result = (await visitor.visit(node));
    const query = QueryFactory.createSelectRule([
        QueryFactory.createGroupRule('and', result.args.map((it) => QueryFactory.createEqualRule([it.name], {
            type: 'string',
            required: true,
            static: false,
            value: it.value,
        }))),
    ], (result.columns ?? []).map((it) => ({ name: it })));
    const params = toLiteralObject(result.args.reduce((acc, it) => ({
        ...acc,
        [(0,external_stringcase_.camelcase)(it.name)]: (0,external_stringcase_.camelcase)(it.name),
    }), {}));
    return {
        query,
        tableName: result.tableName,
        args: result.args,
        fnName: (0,external_stringcase_.camelcase)(`find ${result.tableName}`) + `(${params})`,
    };
}
function toQueryDsl(input) {
    const dslToDslVisitor = new InputDslToQueryDslVisitor();
    const result = dslToDslVisitor.visit(parseDsl(input));
    const query = QueryFactory.createSelectRule([
        QueryFactory.createGroupRule('and', result.args.map((it) => QueryFactory.createEqualRule([it.name], {
            type: 'string',
            required: true,
            static: false,
            value: it.value,
        }))),
    ], (result.columns ?? []).map((it) => ({ name: it })));
    return { query, tableName: result.tableName };
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/orm.ts


let OrmCodeWriter = class OrmCodeWriter {
};
OrmCodeWriter = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)()
], OrmCodeWriter);


;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/typeorm/utils.ts

const naminize = (input) => (0,external_stringcase_.camelcase)(input.join(' '));
function format(it) {
    // return {
    //   name: camelcase(it.input.join(' ')),
    //   namespace: 'REMOVE_NAMESPACE',
    //   value: it.data.value,
    //   type: it.data.type,
    //   defaultValue: it.data.defaultValue,
    //   validations: [], // FIXME: add required validation
    // };
    return {
        [naminize(it.input)]: {
            input: it.data.input,
            defaultValue: it.data.defaultValue,
            validations: it.data.validation,
        },
    };
}
function processSelect(select) {
    return select.data
        .map(processGroup)
        .flat()
        .reduce((acc, item) => {
        return {
            ...acc,
            ...item,
        };
    }, {});
}
function processGroup(group) {
    return group.data
        .map((item) => flatQueryConditions(item))
        .flat()
        .reduce((acc, item) => {
        return {
            ...acc,
            ...item,
        };
    }, {});
}
function processBetween(group) {
    return {
        ...format({
            input: group.input,
            data: group.data.min,
        }),
        ...format({
            input: group.input,
            data: group.data.max,
        }),
    };
}
function processDefault(group) {
    return format({
        input: group.input,
        data: group.data,
    });
}
function flatQueryConditions(condition) {
    switch (condition.operator) {
        case 'group':
            return processGroup(condition);
        case 'between':
            return processBetween(condition);
        case 'querySelect':
            return processSelect(condition);
        default:
            return processDefault(condition);
    }
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/postgresql.extension.ts
var postgresql_extension_a, postgresql_extension_b, postgresql_extension_c, postgresql_extension_d, _e, _f;

















let PostgreSQLExtension = class PostgreSQLExtension {
    _sdk;
    _projectFS;
    _devKit;
    _dynamicSource;
    _context;
    _ormCodeWriter;
    constructor(_sdk, _projectFS, _devKit, _dynamicSource, _context, _ormCodeWriter) {
        this._sdk = _sdk;
        this._projectFS = _projectFS;
        this._devKit = _devKit;
        this._dynamicSource = _dynamicSource;
        this._context = _context;
        this._ormCodeWriter = _ormCodeWriter;
    }
    async handleInput(input) {
        const { namespace, value } = toSimple(input);
        switch (true) {
            case namespace.startsWith('tables'): {
                switch (true) {
                    case value.startsWith('fields'):
                        return {
                            value: this._devKit.substring(value, 'fields.'),
                            static: false,
                            type: 'string',
                            data: {
                                local: true,
                            },
                        };
                    default:
                        const dsl = toQueryDsl(input);
                        const fnName = (0,external_stringcase_.camelcase)(`find ${dsl.tableName}`);
                        return {
                            static: true,
                            type: 'structure',
                            structure: this.#makeQueryFn({
                                tableName: dsl.tableName,
                                whereBy: dsl.query,
                                fnName: fnName,
                            }),
                            value: `await ${fnName}`,
                        };
                }
            }
            default:
                return null;
        }
    }
    async handleInputV2({ namespace, value, }) {
        switch (true) {
            case namespace.startsWith('tables'): {
                const dsl = await toQueryDslAsync(this._context, value);
                const fnName = (0,external_stringcase_.camelcase)(`find ${dsl.tableName}`);
                return {
                    static: true,
                    type: 'structure',
                    structure: this.#makeQueryFn({
                        tableName: dsl.tableName,
                        whereBy: dsl.query,
                        fnName: fnName,
                    }),
                    value: `await ${dsl.fnName}`,
                };
            }
            default:
                return null;
        }
    }
    async extractInputs({ namespace, value, visit, }) {
        switch (true) {
            case namespace.startsWith('tables'): {
                const visitor = new dsl_dsl_visitor_InputsExtractor(visit);
                return visitor.visit(value);
            }
            default:
                return null;
        }
    }
    async #generateSortByContract(tableId, sorts) {
        const contract = {};
        for (const item of sorts) {
            const field = await this.#getField(tableId, item.id);
            contract[(0,external_stringcase_.camelcase)(field.displayName)] = {
                input: item.input,
                validations: [],
            };
        }
        return contract;
    }
    // async #generateGroupByContract(
    //   tableId: string,
    //   groupBy: Contracts.GroupByInput[],
    // ): Promise<Record<string, IncomingActionProperty>> {
    //   const contract: Record<string, IncomingActionProperty> = {};
    //   for (const item of groupBy) {
    //     const field = await this._sdk.tables.getTableField(tableId, item.id);
    //     contract[camelcase(field.displayName)] = {
    //       input: item.input,
    //       validations: [],
    //     };
    //   }
    //   return contract;
    // }
    async #generateGroupByContract(tableId, groupBy) {
        const contract = [];
        for (const item of groupBy) {
            const field = await this._sdk.tables.getTableField(tableId, item.id);
            // FIXME: it shouldn't be parsed here. add handleInput method to resolve the input
            // const {
            //   name: { function: aggregator, arg: alias },
            // } = parseInput(item.input);
            // contract.push({
            //   aggregator,
            //   name: camelcase(field.displayName),
            //   alias,
            // });
        }
        return contract;
    }
    async processAction(contract, helpers, inputs, transfer) {
        switch (contract.sourceAction.name) {
            case 'list-records': {
                return {
                    inline: false,
                    structure: this._ormCodeWriter.generateQuery({
                        outputName: contract.output.displayName,
                        tableName: transfer['tableName'].value,
                        query: transfer['query'],
                        single: transfer['single'].value === 'true',
                        pagination: transfer['pagination'].value,
                        localizable: transfer['localizable'].value === 'true',
                        helpers,
                        inline: false,
                    }),
                };
            }
            case 'check-record-existance':
            case 'increment-field':
            case 'decrement-field':
            case 'delete-record':
            case 'set-fields': {
                return {
                    inline: false,
                    structure: this._ormCodeWriter.generateCommand({
                        action: contract,
                        helpers,
                        tableName: transfer['tableName'].value,
                        inline: false,
                    }),
                };
            }
            case 'upsert-record':
            case 'insert-record': {
                return {
                    inline: true,
                    structure: this._ormCodeWriter.generateCommand({
                        action: contract,
                        helpers,
                        tableName: transfer['tableName'].value,
                        inline: true,
                    }),
                };
            }
            case 'raw-sql-query': {
                return {
                    inline: true,
                    structure: this._ormCodeWriter.generateRaw({
                        action: contract,
                        helpers,
                        inline: true,
                    }),
                };
            }
            default:
                throw new Error(`Action ${contract.sourceAction.name} is not supported`);
        }
    }
    #paginationInputs = async (type, limit) => {
        switch (type) {
            case 'limit_offset':
            case 'deferred_joins':
                return {
                    pageSize: {
                        input: '@trigger:query.pageSize',
                        defaultValue: limit,
                        validations: [
                            {
                                ...(await this._devKit.getValidationByName('number')),
                                details: {
                                    value: 'true',
                                },
                            },
                            {
                                ...(await this._devKit.getValidationByName('mandatory')),
                                details: {
                                    value: 'true',
                                },
                            },
                            {
                                ...(await this._devKit.getValidationByName('min')),
                                details: {
                                    value: 1,
                                },
                            },
                        ],
                    },
                    pageNo: {
                        input: '@trigger:query.pageNo',
                        validations: [
                            {
                                ...(await this._devKit.getValidationByName('number')),
                                details: {
                                    value: 'true',
                                },
                            },
                            {
                                ...(await this._devKit.getValidationByName('min')),
                                details: {
                                    value: 1,
                                },
                            },
                        ],
                    },
                };
            case 'cursor':
                return {
                    cursor: {
                        input: '@trigger:query.cursor',
                        validations: [],
                    },
                    pageSize: {
                        input: '@trigger:query.pageSize',
                        defaultValue: limit,
                        validations: [
                            {
                                ...(await this._devKit.getValidationByName('mandatory')),
                                details: {
                                    value: 'true',
                                },
                            },
                            {
                                ...(await this._devKit.getValidationByName('min')),
                                details: {
                                    value: 1,
                                },
                            },
                        ],
                    },
                };
            default:
                return {};
        }
    };
    async handleAction(input) {
        if (input.sourceAction.name === 'raw-sql-query') {
            const parameters = (input.details['parameters'] ?? []).reduce((acc, prop) => ({
                ...acc,
                [prop.input.split('.').at(-1)]: prop,
            }), {});
            return {
                transfer: {
                    query: input.details['query'],
                    parameters: Object.keys(parameters),
                },
                runtimeInputs: {
                    ...parameters,
                },
            };
        }
        // FIXME: tableId and anything that is expected to be used at faslh
        // execution time should always be fixed
        // maybe we need to move them out of "metadata" to be in other property in the
        // json metadata or give them type "static" OR OR we can have new method beside #resolveInput
        // that will resolve inputs for the handleAction (it won't prefix things with "input.")
        const table = await this._sdk.tables.get(input.details['tableId']);
        switch (input.sourceAction.name) {
            case 'list-records': {
                // TODO: Invistigate adding new namespace to resolve this extension
                // inputs. if successful we might not need the query contract
                const queryContract = await this.#generateQueryContract(input.details['tableId'], input.details['query']?.['whereBy']);
                const sortByContract = await this.#generateSortByContract(input.details['tableId'], input.details['query']?.['sortBy'] ?? []);
                const inputs = {
                    ...flatQueryConditions(queryContract),
                    ...(await this.#paginationInputs(input.details['pagination'], input.details['limit'])),
                };
                if (input.details['localizable'] === 'true') {
                    inputs['locales'] = {
                        input: '@trigger:headers.locales',
                        defaultValue: '[]',
                        validations: [],
                    };
                }
                return {
                    transfer: {
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                        single: {
                            input: `@fixed:${input.details['limit'] === 1}`,
                        },
                        pagination: {
                            input: `@fixed:${input.details['pagination']}`,
                        },
                        localizable: {
                            input: `@fixed:${input.details['localizable']}`,
                        },
                        query: {
                            whereBy: queryContract,
                            sortBy: sortByContract,
                        },
                    },
                    runtimeInputs: inputs,
                };
            }
            case 'delete-record':
            case 'check-record-existance': {
                {
                    const queryContract = await this.#generateQueryContract(input.details['tableId'], input.details['query']?.['whereBy']);
                    return {
                        transfer: {
                            tableName: {
                                input: `@fixed:${table.displayName}`,
                            },
                            query: {
                                whereBy: queryContract,
                            },
                        },
                        runtimeInputs: flatQueryConditions(queryContract),
                    };
                }
            }
            case 'i18n':
                // type: 'Record<string, Record<string, any>>',
                return {
                    transfer: {
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                    },
                    runtimeInputs: {
                        i18n: {
                            input: '@trigger:body.i18n',
                            validations: [],
                        },
                    },
                };
            case 'set-fields': {
                const queryContract = await this.#generateQueryContract(input.details['tableId'], input.details['query']?.['whereBy']);
                const inputs = {
                    ...flatQueryConditions(queryContract),
                };
                const columns = (input.details['columns'] ?? []);
                for (const column of columns.filter((it) => !!it.input)) {
                    const field = await this.#getField(input.details['tableId'], column.name);
                    const validationContract = await generateValidationContract(field.validations);
                    inputs[(0,external_stringcase_.camelcase)(field.displayName)] = {
                        ...column,
                        // FIXME: instead of doing this
                        // return specialised postgres namespace in the input
                        // and handleInput in the postgres extension
                        // to resolve it in the process.
                        type: await this._sdk.tables.resolvePrimitiveType(field),
                        validations: validationContract,
                        data: { column: true, ...(column.data ?? {}) },
                    };
                }
                return {
                    transfer: {
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                        query: {
                            whereBy: queryContract,
                        },
                    },
                    runtimeInputs: inputs,
                };
            }
            case 'insert-record': {
                const inputs = {};
                const columns = (input.details['columns'] ?? []);
                for (const column of columns.filter((it) => !!it.input)) {
                    const field = await this.#getField(input.details['tableId'], column.name);
                    const validationContract = await generateValidationContract(field.validations);
                    inputs[(0,external_stringcase_.camelcase)(field.displayName)] = {
                        input: column.input,
                        validations: validationContract,
                        // type:
                        //   sourceField.name !== 'relation-id'
                        //     ? await this._sdk.tables.resolvePrimitiveType(field)
                        //     : field.details['relatedEntityPrimaryColumnType'],
                    };
                }
                return {
                    transfer: {
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                    },
                    runtimeInputs: inputs,
                };
            }
            case 'upsert-record': {
                const inputs = {};
                const columns = (input.details['columns'] ?? []);
                for (const column of columns.filter((it) => !!it.input)) {
                    const field = await this.#getField(input.details['tableId'], column.name);
                    const validationContract = await generateValidationContract(field.validations);
                    inputs[(0,external_stringcase_.camelcase)(field.displayName)] = {
                        input: column.input,
                        validations: validationContract,
                    };
                }
                return {
                    transfer: {
                        conflictFields: input.details['conflictFields'],
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                    },
                    runtimeInputs: inputs,
                };
            }
            case 'increment-field':
            case 'decrement-field': {
                const field = await this.#getField(input.details['tableId'], input.details['field'].name);
                const queryContract = await this.#generateQueryContract(input.details['tableId'], input.details['query']?.['whereBy']);
                const inputs = {
                    ...flatQueryConditions(queryContract),
                };
                return {
                    transfer: {
                        tableName: {
                            input: `@fixed:${table.displayName}`,
                        },
                        field: {
                            input: `@fixed:${field.displayName}`,
                        },
                        query: {
                            whereBy: queryContract,
                        },
                    },
                    runtimeInputs: {
                        ...inputs,
                        value: input.details['field'],
                    },
                };
            }
            default:
                throw new Error(`Action ${input.sourceAction.name} is not supported`);
        }
    }
    async #getField(tableId, name) {
        const table = await this._sdk.tables.get(tableId);
        if (!name) {
            throw new Error(`Trying to get field with empty name in table ${table.displayName}:${tableId}`);
        }
        const columnName = name.startsWith('@')
            ? await this.handleInput(name)
            : null;
        let field;
        if (isNullOrUndefined(columnName)) {
            field = table.fields.find((it) => it.id === name);
        }
        else {
            field = table.fields.find((it) => it.displayName === columnName.value);
        }
        if (!field) {
            throw new Error(`Field ${name} not found`);
        }
        return field;
    }
    async handleSetup(contract) {
        const contracts = [
            {
                filePath: this._projectFS.makeCorePath('execute.ts'),
                content: [execute],
            },
            {
                filePath: this._projectFS.makeCorePath('date.ts'),
                content: [postgresql_date],
            },
            {
                filePath: this._projectFS.makeCorePath('data-source.ts'),
                content: [
                    `
      import { DataSource, DefaultNamingStrategy } from 'typeorm';
      import { PostgresConnectionOptions } from 'typeorm/driver/postgres/PostgresConnectionOptions';
      import entites from '../features/entites';
      class NamingStrategy extends DefaultNamingStrategy {
          override tableName(
            targetName: string,
            userSpecifiedName: string | undefined,
          ): string {
            return super.tableName(userSpecifiedName ?? targetName, undefined);
          }
      }
      const options: PostgresConnectionOptions = {
        type: 'postgres',
        useUTC: true,
        url: ${contract['CONNECTION_STRING'].value},
        migrationsRun: true,
        entities: [...entites],
        logging: false, // process.env.NODE_ENV !== 'production'
        synchronize: true, // process.env.NODE_ENV !== 'production'
        ssl: process.env.NODE_ENV === 'production',
        namingStrategy: new NamingStrategy(),
      };
      export default new DataSource(options);
    `,
                ],
            },
        ];
        if (contract['i18n'].value === 'default') {
            contracts.push({
                filePath: this._projectFS.makeCorePath('i18n.ts'),
                content: [i18n],
            });
        }
        return contracts;
    }
    async handleField(input) {
        const mandatory = (input.validation ?? []).some((it) => it.name === 'mandatory' && it.details['value'] === 'true');
        const unique = (input.validation ?? []).some((it) => it.name === 'unique' && it.details['value'] === 'true');
        if (input.details['system_created_at']) {
            return {
                validations: await generateValidationContract(input.validation),
                mandatory,
                nativeType: 'createdAt',
                primitiveType: 'Date',
            };
        }
        if (input.details['system_updated_at']) {
            return {
                validations: await generateValidationContract(input.validation),
                mandatory,
                nativeType: 'updatedAt',
                primitiveType: 'Date',
            };
        }
        if (input.details['system_deleted_at']) {
            return {
                validations: await generateValidationContract(input.validation),
                mandatory,
                nativeType: 'deletedAt',
                primitiveType: 'Date',
            };
        }
        switch (input.sourceField.name) {
            case 'primary-key-uuid':
            case 'primary-key-custom':
            case 'primary-key-number':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'primary-key',
                    keyType: input.sourceField.name,
                    generated: input.details['system_auto_generated'],
                };
            case 'json':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'json',
                    mandatory: mandatory,
                };
            case 'integer':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'integer',
                    mandatory: mandatory,
                    unique: unique,
                };
            case 'boolean':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'boolean',
                    mandatory: mandatory,
                    unique: unique,
                };
            case 'datetime': {
                const local = input.validation.find((it) => it.name === 'datetime');
                if (!local) {
                    throw new Error('Datetime field must specifiy timezone.');
                }
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'datetime',
                    zone: local.details['value'] === 'iso-date-time'
                        ? 'timestamp'
                        : 'timestamptz',
                    mandatory: mandatory,
                    unique: unique,
                    primitiveType: 'string',
                };
            }
            case 'time': {
                const local = input.validation.find((it) => it.name === 'time');
                if (!local) {
                    throw new Error('Time field must specifiy timezone.');
                }
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'time',
                    zone: local.details['value'] === 'iso-time' ? 'time' : 'timetz',
                    mandatory: mandatory,
                    unique: unique,
                };
            }
            case 'uuid':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'uuid',
                    mandatory: mandatory,
                    unique: unique,
                };
            case 'url':
            case 'short-text':
            case 'email':
            case 'long-text':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'varchar',
                    mandatory: mandatory,
                    unique: unique,
                    length: input.details['length'],
                };
            case 'decimal':
            case 'price':
            case 'percentage':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'decimal',
                    mandatory: mandatory,
                    unique: unique,
                    precision: input.details['precision'],
                    scale: input.details['scale'],
                };
            case 'single-select':
                // TODO: the user should choose the datatype either enum, varchar or lookup
                if (input.details['style'] === 'enum') {
                    return {
                        validations: await generateValidationContract(input.validation),
                        nativeType: 'enum',
                        unique,
                        mandatory,
                        values: input.details['values'],
                    };
                }
                if (input.details['style'] === 'varchar') {
                    return {
                        validations: await generateValidationContract(input.validation),
                        nativeType: 'varchar',
                        unique,
                        mandatory,
                    };
                }
                throw new Error('Lookup not supported yet.');
            case 'relation-id':
                const referenceEntity = await this._sdk.tables.get(input.details['references']);
                const primaryKey = referenceEntity.fields.find((field) => field.details['system_primary_key']);
                if (!primaryKey) {
                    throw new Error(`Primary key not found on table ${referenceEntity.displayName}`);
                }
                const primaryKeySourceField = await this._devKit.getSourceFieldById(primaryKey.sourceId);
                const referencedPrimaryColumnType = primaryKeySourceField.primitiveType +
                    `${input.details['relationship'] === 'one-to-many' ? '[]' : ''}`;
                return {
                    virtualRelationField: input.details['virtualRelationField'],
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'relation-id',
                    mandatory: mandatory,
                    unique: unique,
                    tableName: input.details['tableName'],
                    primitiveType: referencedPrimaryColumnType,
                    columnNameOnSelfTable: input.details['columnNameOnSelfTable'],
                };
            case 'relation':
                return {
                    validations: await generateValidationContract(input.validation),
                    nativeType: 'relation',
                    primitiveType: await this._dynamicSource.resolvePrimitiveType(input.featureId, input.sourceField.primitiveType, {
                        context: input.details,
                        self: {}, // FIXME: provide self
                    }, (primitiveType) => primitiveType.primitiveType),
                    mandatory: mandatory,
                    unique: unique,
                    joinSide: input.details['joinSide'],
                    nameOfColumnOnRelatedEntity: input.details['nameOfColumnOnRelatedEntity'],
                    relationship: input.details['relationship'],
                    // FIXME: deprecate relatedEntityName, fetch the table from the sdk using references
                    relatedEntityName: input.details['relatedEntityName'],
                };
            default:
                throw new Error(`Field ${input.sourceField.name} not supported.`);
        }
    }
    async #generateQueryContract(tableId, condition) {
        const stack = [{ condition, parent: null, index: null }];
        const contracts = [];
        while (stack.length > 0) {
            const { condition, parent, index } = stack.pop();
            if (condition.operator === 'querySelect') {
                const queryContract = {
                    operator: 'querySelect',
                    input: await this.#generateGroupByContract(tableId, condition.input),
                    data: [],
                };
                contracts.push(queryContract);
                if (parent) {
                    parent.data[index] = queryContract;
                }
                for (let i = condition.data.filter(notNullOrUndefined).length - 1; i >= 0; i--) {
                    stack.push({
                        condition: condition.data[i],
                        parent: queryContract,
                        index: i,
                    });
                }
            }
            else if (condition.operator === 'group') {
                const groupContract = {
                    operator: 'group',
                    input: condition.input,
                    data: [],
                };
                contracts.push(groupContract);
                if (parent) {
                    parent.data[index] = groupContract;
                }
                for (let i = condition.data.length - 1; i >= 0; i--) {
                    stack.push({
                        condition: condition.data[i],
                        parent: groupContract,
                        index: i,
                    });
                }
            }
            else {
                const validations = [];
                if (condition.data?.required) {
                    const mandatoryValidation = await this._devKit.getValidationByName('mandatory');
                    validations.push({
                        name: mandatoryValidation.name,
                        sourceId: mandatoryValidation.id,
                        details: { value: 'true' },
                    });
                }
                if (condition.input.length > 1) {
                    const table = await this._sdk.tables.get(condition.data.name[0]);
                    const field = await this._sdk.tables.getTableField(condition.input[0], condition.input[1]);
                    const sourceField = await this._devKit.getSourceFieldById(field.sourceId);
                    const validationContracts = await generateValidationContract([
                        ...validations,
                        ...field.validations,
                    ]);
                    const contract = {
                        operator: condition.operator,
                        input: [table.displayName, field.displayName],
                        data: {
                            ...condition.data,
                            required: validationContracts.some((it) => it.name === 'mandatory'),
                            // FIXME: handle the type and validation in postgres handleInput
                            type: condition.data?.type || sourceField.primitiveType,
                            validation: await generateValidationContract([
                                ...validations,
                                ...field.validations,
                            ]),
                        },
                    };
                    contracts.push(contract);
                    if (parent) {
                        parent.data[index] = contract;
                    }
                }
                else {
                    const field = await this.#getField(tableId, condition.input[0]);
                    const sourceField = await this._devKit.getSourceFieldById(field.sourceId);
                    const validationContracts = await generateValidationContract([
                        ...validations,
                        ...field.validations,
                    ]);
                    const contract = {
                        operator: condition.operator,
                        input: [field.displayName],
                        data: {
                            ...condition.data,
                            required: validationContracts.some((it) => it.name === 'mandatory'),
                            // FIXME: handle the type and validation in postgres handleInput
                            type: condition.data?.type || sourceField.primitiveType,
                            validation: validationContracts,
                        },
                    };
                    contracts.push(contract);
                    if (parent) {
                        parent.data[index] = contract;
                    }
                }
            }
        }
        return contracts[0];
    }
    // FIXME: why not to use generate query fn instead?
    #makeQueryFn(input) {
        const variables = {};
        const topLevel = [];
        const body = [];
        const qbUsage = [];
        const result = this._ormCodeWriter.generateQuery({
            inline: false,
            localizable: false,
            single: true,
            outputName: 'output',
            pagination: 'none',
            tableName: input.tableName,
            helpers: {
                useVariable: (name, value) => {
                    variables[name] = {
                        declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
                        kind: external_ts_morph_.StructureKind.VariableStatement,
                        declarations: [{ name: name, initializer: value }],
                    };
                },
                useQb: (usage) => {
                    const qbString = 'qb';
                    qbUsage.push(usage(qbString));
                },
                resolveAction: () => ['not sure what it should do here'],
            },
            query: {
                sortBy: {},
                groupBy: [],
                whereBy: input.whereBy,
            },
        });
        if (typeof result === 'string' ||
            typeof result === 'function' ||
            Array.isArray(result)) {
            body.push(result);
        }
        else {
            body.push(result.actionStructure);
            topLevel.push(result.topLevelStructure);
        }
        return [
            ...topLevel.flat(),
            {
                kind: external_ts_morph_.StructureKind.Function,
                name: input.fnName,
                isAsync: true,
                isDefaultExport: false,
                isExported: true,
                parameters: [
                    {
                        name: `{${Object.keys(flatQueryConditions(input.whereBy))}}`,
                        type: 'Record<string, any>',
                    },
                ],
                statements: [...Object.values(variables), ...qbUsage, ...body.flat()],
            },
        ];
    }
};
PostgreSQLExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (postgresql_extension_a = typeof Sdk !== "undefined" && Sdk) === "function" ? postgresql_extension_a : Object, typeof (postgresql_extension_b = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? postgresql_extension_b : Object, typeof (postgresql_extension_c = typeof DevKit !== "undefined" && DevKit) === "function" ? postgresql_extension_c : Object, typeof (postgresql_extension_d = typeof DynamicSource !== "undefined" && DynamicSource) === "function" ? postgresql_extension_d : Object, typeof (_e = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? _e : Object, typeof (_f = typeof OrmCodeWriter !== "undefined" && OrmCodeWriter) === "function" ? _f : Object])
], PostgreSQLExtension);

// dev mode postgresql://youruser:yourpassword@postgres:5432/yourdatabase
// prod mode postgresql://january-test_owner:U17cOgTaYXIm@ep-holy-flower-a5lkn70o.us-east-2.aws.neon.tech/january-test?sslmode=require
onEvent({
    events: [],
    handler: async (event, context) => {
        const devKit = external_tiny_injector_.Injector.GetRequiredService(DevKit, context);
        const sdk = external_tiny_injector_.Injector.GetRequiredService(Sdk, context);
        const sourceField = await devKit.getSourceFieldById(event.data.sourceId);
        if (!(sourceField.name === 'relation' &&
            event.data.details['joinSide'] === true) // otherwise will create recursive relation
        ) {
            return;
        }
        const selfEntity = await sdk.tables.get(event.data.tableId);
        {
            if (event.data.details['relationship'] === 'many-to-many') {
                // FIXME: NOT COMPLETE
                const relationSourceField = await devKit.getSourceFieldByName('relation');
                const assoicativeTableId = await sdk.tables.addTable({
                    featureId: selfEntity.featureId,
                    details: {},
                    displayName: (0,external_stringcase_.pascalcase)(`${external_pluralize_default().singular(selfEntity.displayName)} To ${external_pluralize_default().singular(event.data.displayName)}`),
                });
                await sdk.tables.addField({
                    tableId: assoicativeTableId,
                    sourceId: relationSourceField.id,
                    displayName: external_pluralize_default().singular(selfEntity.displayName),
                    details: {
                        references: event.data.tableId,
                        joinSide: true,
                        relationship: 'many-to-one',
                    },
                });
                await sdk.tables.addField({
                    tableId: assoicativeTableId,
                    sourceId: relationSourceField.id,
                    displayName: external_pluralize_default().singular(event.data.displayName),
                    details: {
                        references: event.data.details['references'],
                        joinSide: true,
                        relationship: 'many-to-one',
                    },
                });
            }
        }
    },
});

;// CONCATENATED MODULE: ../compiler/core/src/lib/prettier/prettier.extension.ts
var prettier_extension_a, prettier_extension_b;





let PrettierExtension = class PrettierExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeWorkspacePath('.prettierrc'),
                content: [
                    this._devKit.toJson({
                        singleQuote: true,
                        importOrder: ['^./main$', '<THIRD_PARTY_MODULES>', '^[./]'],
                        importOrderSeparation: true,
                        importOrderSortSpecifiers: true,
                        importOrderParserPlugins: ['typescript', 'decorators-legacy'],
                    }),
                ],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('.prettierignore'),
                content: [
                    external_dedent_default() `
			/dist
			/coverage
		  `,
                ],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('.github/workflows/prettier.yml'),
                content: [
                    external_js_yaml_default().dump({
                        name: 'Format with Prettier',
                        on: {
                            push: {
                                branches: ['main'],
                            },
                        },
                        jobs: {
                            format: {
                                'runs-on': 'ubuntu-latest',
                                steps: [
                                    {
                                        name: 'Checkout',
                                        uses: 'actions/checkout@v3',
                                    },
                                    {
                                        name: 'Install',
                                        run: 'npm install --only=dev --no-audit --no-fund',
                                    },
                                    {
                                        name: 'Format',
                                        run: './node_modules/.bin/prettier --write .',
                                    },
                                    {
                                        name: 'Push changes',
                                        uses: 'stefanzweifel/git-auto-commit-action@v4',
                                        with: {
                                            commit_message: '"Format with Prettier"',
                                            commit_user_name: '"ci"',
                                            commit_user_email: '"ci@github.com"',
                                        },
                                    },
                                ],
                            },
                        },
                    }),
                ],
            },
        ];
    }
};
PrettierExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (prettier_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? prettier_extension_a : Object, typeof (prettier_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? prettier_extension_b : Object])
], PrettierExtension);


;// CONCATENATED MODULE: ../compiler/core/src/lib/resend/resend.extension.ts
var resend_extension_a, resend_extension_b;







let ResendExtension = class ResendExtension {
    _projectFS;
    _devkit;
    constructor(_projectFS, _devkit) {
        this._projectFS = _projectFS;
        this._devkit = _devkit;
    }
    async handleSetup(contract) {
        return [
            {
                filePath: this._projectFS.makeCorePath('resend.ts'),
                content: [
                    `
          import { Resend } from 'resend';
		      export default new Resend(${contract['RESEND_API_KEY'].value});
    		`,
                ],
            },
        ];
    }
    async processAction(action, helpers, inputs) {
        switch (action.sourceAction.name) {
            case 'resend-send-email':
                return {
                    inline: true,
                    structure: {
                        topLevelStructure: [
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/resend'),
                                defaultImport: 'resend',
                            },
                        ],
                        actionStructure: [
                            (writer) => writer.writeLine(external_dedent_default() `
            ${action.output.displayName ? `const ${action.output.displayName} = ` : ''} await resend.emails.send({${toProps(inputs)}});
            `),
                        ],
                    },
                };
            case 'resend-create-contact':
                return {
                    inline: true,
                    structure: {
                        topLevelStructure: [
                            {
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                defaultImport: 'resend',
                                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/resend'),
                            },
                        ],
                        actionStructure: [
                            (writer) => writer.writeLine(external_dedent_default() `
              ${action.output.displayName ? `const ${action.output.displayName} = ` : ''} await resend.contacts.create({${toProps(inputs)}});
              `),
                        ],
                    },
                };
        }
        throw new Error(`Action ${action.name} not supported`);
    }
    async handleAction(contract) {
        for (const [key] of Object.entries(contract.details)) {
            const { validations = [] } = contract.sourceAction.metadata[key];
            for (const validation of validations) {
                const sourceId = (await this._devkit.getValidationByName(validation.name)).id;
                validation.sourceId = sourceId;
            }
            contract.details[key] = {
                ...contract.details[key],
                validations: await generateValidationContract(validations),
            };
        }
        return {
            runtimeInputs: contract.details,
            transfer: {},
        };
    }
    async handleField(input) {
        throw new Error('Method not implemented.');
    }
};
ResendExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (resend_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? resend_extension_a : Object, typeof (resend_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? resend_extension_b : Object])
], ResendExtension);

function toProps(inputs) {
    return Object.entries(inputs)
        .filter(([, value]) => notNullOrUndefined(value))
        .map(([key, value]) => `${key}: ${useInput(value)}`)
        .join(', ');
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/vercel/vercel.extension.ts
var vercel_extension_a, vercel_extension_b, vercel_extension_c;





let VercelExtension = class VercelExtension {
    _projectFS;
    _context;
    _devKit;
    constructor(_projectFS, _context, _devKit) {
        this._projectFS = _projectFS;
        this._context = _context;
        this._devKit = _devKit;
    }
    get _inputParser() {
        return external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
    }
    async handleSetup(inputs) {
        const routingExt = await this._inputParser.routingExtension();
        return [
            {
                filePath: this._projectFS.makeRootPath('.github/workflows/deploy.yml'),
                content: [
                    vercel_extension_deployContent(
                    // rZ9aCDcjqdy5WcNH7aEFEd3C
                    // {"token":"rZ9aCDcjqdy5WcNH7aEFEd3C", "projectId":"prj_pJIBRbeDIacUqmeoCce0BMdcvgAB","orgId":"team_bQEldc2p1yCwDSZm0Xb6dnFU"}
                    inputs['VERCEL_API_TOKEN'].value, inputs['VERCEL_PROJECT_ID'].value, inputs['VERCEL_ORG_ID'].value),
                ],
            },
            {
                filePath: this._projectFS.makeSrcPath('server.ts'),
                content: [routingExt.extension.getServerSetup(true, 'vercel')],
            },
            {
                filePath: this._projectFS.makeWorkspacePath('vercel.json'),
                content: [
                    this._devKit.toJson({
                        $schema: 'https://openapi.vercel.sh/vercel.json',
                        version: 2,
                        installCommand: 'npm install --omit=dev --no-audit --no-fund',
                        buildCommand: 'npm run build:remote',
                        devCommand: 'npm run start:prod',
                        outputDirectory: '',
                        builds: [
                            {
                                src: 'build/server.js',
                                use: '@vercel/node',
                            },
                        ],
                        routes: [
                            {
                                src: '/(.*)',
                                dest: '/build/server.js',
                            },
                        ],
                    }),
                ],
            },
        ];
    }
};
VercelExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (vercel_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? vercel_extension_a : Object, typeof (vercel_extension_b = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? vercel_extension_b : Object, typeof (vercel_extension_c = typeof DevKit !== "undefined" && DevKit) === "function" ? vercel_extension_c : Object])
], VercelExtension);

const vercel_extension_deployContent = (appToken, projectId, orgId) => {
    return external_js_yaml_default().dump({
        name: 'Deploy To Vercel',
        on: {
            push: {
                branches: ['main'],
            },
            workflow_dispatch: {},
        },
        env: {
            VERCEL_ORG_ID: `\${{ secrets.${orgId} }}`,
            VERCEL_PROJECT_ID: `\${{ secrets.${projectId} }}`,
        },
        jobs: {
            deploy_to_vercel: {
                'runs-on': 'ubuntu-latest',
                steps: [
                    {
                        id: 'checkout',
                        name: 'checkout App Repo',
                        uses: 'actions/checkout@v3',
                    },
                    // FIXME: Removing this will give us few seconds back
                    {
                        id: 'install_lockfile',
                        name: 'Install Lockfile',
                        run: 'npm install --package-lock-only --no-audit --no-fund',
                    },
                    {
                        id: 'setup_node',
                        uses: 'actions/setup-node@v3',
                        name: 'Setup Node.js',
                        with: {
                            'node-version': '20',
                            cache: 'npm',
                        },
                    },
                    {
                        name: 'Install Vercel CLI',
                        run: 'npm install --global vercel@latest --no-audit --no-fund',
                    },
                    {
                        name: 'Pull Vercel Environment Information',
                        run: `vercel pull --yes --environment=production --token=\${{ secrets.${appToken} }}`,
                    },
                    {
                        name: 'Build Project Artifacts',
                        run: `vercel build --prod --token=\${{ secrets.${appToken} }}`,
                    },
                    {
                        name: 'Deploy Project Artifacts to Vercel',
                        run: `vercel deploy --prebuilt --prod --token=\${{ secrets.${appToken} }}`,
                    },
                ],
            },
        },
    }, {
        lineWidth: -1,
        skipInvalid: false,
        noRefs: true,
        noCompatMode: true,
        schema: (external_js_yaml_default()).JSON_SCHEMA,
    });
};

;// CONCATENATED MODULE: ../compiler/core/src/lib/node-cron/node-cron.extension.ts
var node_cron_extension_a, node_cron_extension_b;






let NodeCronExtension = class NodeCronExtension {
    _projectFS;
    _devKit;
    constructor(_projectFS, _devKit) {
        this._projectFS = _projectFS;
        this._devKit = _devKit;
    }
    triggers = ['cd76caa3-e9f0-49b8-bf7a-0ebed83bd486'];
    async handleSetup(details) {
        return [
        // {
        //   filePath: this._projectFS.makeControllerPath('integrations', 'router'),
        //   content: [webhookHandler],
        // },
        // {
        //   filePath: this._projectFS.makeCorePath('github-webhooks.ts'),
        //   content: [receiveWebhook],
        // },
        ];
    }
    onFeatureContract(contract, addFile) {
        if (contract.workflows.length === 0) {
            return;
        }
        addFile({
            filePath: this._projectFS.makeControllerPath(contract.displayName, 'cron'),
            structure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: 'node-cron',
                    namedImports: ['schedule'],
                },
                ...contract.workflows
                    .map((it) => it.trigger.policies)
                    .flat()
                    .map((it) => ({
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: `../../identity/${(0,external_stringcase_.spinalcase)(it)}.policy`,
                    namedImports: [(0,external_stringcase_.camelcase)(it)],
                })),
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: `./jobs`,
                    namespaceImport: 'jobs',
                },
                ...contract.workflows.map((contract) => {
                    const options = [];
                    if ('immediate' in contract.trigger.details) {
                        options.push(['runOnInit', contract.trigger.details['immediate']]);
                    }
                    const displayName = `jobs.${(0,external_stringcase_.camelcase)(contract.trigger.displayName)}`;
                    const authorize = contract.trigger.policies.length
                        ? `,${contract.trigger.policies
                            .map((it) => `${(0,external_stringcase_.camelcase)(it)}`)
                            .join(',')}`
                        : '';
                    return `schedule(
  '${contract.trigger.details['pattern']}'
  ${authorize},
  ${displayName},
  ${options.length ? this._devKit.toLiteralObject(options) : ''}

);
`;
                }),
            ],
        });
    }
    async processTrigger(contract, workflowInputs) {
        const displayName = (0,external_stringcase_.camelcase)(contract.displayName);
        const inputName = (0,external_stringcase_.camelcase)('input');
        const vars = {};
        const inputParams = signutureInputs({ ...contract.inputs });
        const actionInputsStr = this._devKit.toLiteralObject(inputParams.map(([name, prop]) => [
            name,
            {
                ...prop,
                value: `payload.${prop.value}`,
            },
        ]));
        const workflowLoneParams = signutureInputs({ ...workflowInputs });
        for (const [name, prop] of workflowLoneParams) {
            vars[name] = `const ${name} = ${prop.value}`;
        }
        const workflowParams = [];
        if (inputParams.length) {
            workflowParams.push(inputName);
        }
        if (workflowLoneParams.length) {
            workflowParams.push(...workflowLoneParams.map(([name]) => name));
        }
        const workflowInputsStructures = Object.values(workflowInputs)
            .map((prop) => prop.structure)
            .filter(Boolean);
        return [
            {
                filePath: this._projectFS.makeIndexFilePath(contract.featureName, 'jobs'),
                structure: [
                    {
                        kind: external_ts_morph_.StructureKind.ExportDeclaration,
                        moduleSpecifier: this._projectFS.makeExportPath(contract.displayName, `job`),
                    },
                ],
            },
            {
                filePath: this._projectFS.makeJobRoutePath(contract.featureName, contract.displayName),
                structure: [
                    ...workflowInputsStructures.flat(),
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: `../${(0,external_stringcase_.spinalcase)(contract.tag)}`,
                        namespaceImport: (0,external_stringcase_.camelcase)(contract.tag),
                    },
                    {
                        kind: external_ts_morph_.StructureKind.ImportDeclaration,
                        moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                        namedImports: ['validateOrThrow'],
                    },
                    {
                        kind: external_ts_morph_.StructureKind.Function,
                        isAsync: true,
                        isDefaultExport: false,
                        isExported: true,
                        name: displayName,
                        parameters: [],
                        statements: [
                            ...Object.values(vars),
                            (writer) => writer.conditionalWriteLine(!!inputParams.length, `const ${inputName} = ${actionInputsStr}`),
                            (writer) => writer.conditionalWriteLine(!!inputParams.length, `validateOrThrow(${(0,external_stringcase_.camelcase)(contract.tag)}.${contract.schemaName}, ${inputName})`),
                            (writer) => writer.writeLine(`await ${(0,external_stringcase_.camelcase)(contract.tag)}.${(0,external_stringcase_.camelcase)(contract.operationName)}(${workflowParams.join(',')})`),
                        ],
                    },
                ],
            },
        ];
    }
};
NodeCronExtension = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (node_cron_extension_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? node_cron_extension_a : Object, typeof (node_cron_extension_b = typeof DevKit !== "undefined" && DevKit) === "function" ? node_cron_extension_b : Object])
], NodeCronExtension);

class node_cron_extension_HonoInputVisitor extends AsyncVisitor {
    visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visitIdentifier(node) {
        return node.value;
    }
    async visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visit(node) {
        return node.accept(this);
    }
}
class node_cron_extension_InputsExtractor extends StringAsyncVisitor {
    _visitor;
    constructor(_visitor) {
        super();
        this._visitor = _visitor;
    }
    async visitArg(node) {
        throw new Error('Method not implemented.');
    }
    async visitBinary(node) {
        throw new Error('Method not implemented.');
    }
    async visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        return {
            accessor: await node.name.accept(this),
            accessee: await node.expression.accept(this),
        };
    }
    async visitNamespace(node) {
        throw new Error('Method not implemented.');
    }
    async visit(node) {
        return node.accept(this);
    }
}
class node_cron_extension_SimpleVisitor extends StringVisitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.accept(this),
            value: node.expression,
        };
    }
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/registry/all.ts
















const extensionsRegistry = {
    'firebase-functions': FirebaseFunctionsExtension,
    'google-cloud-storage': GoogleStorageExtension,
    prettier: PrettierExtension,
    postgresql: PostgreSQLExtension,
    koajs: KoaJsExtension,
    hono: HonoExtension,
    fly: FlyExtension,
    vercel: VercelExtension,
    resend: ResendExtension,
    ajax: AjaxExtension,
    core: CoreExtension,
    identity: IdentityExtension,
    'firebase-auth': FirebaseAuthExtension,
    github: GithubExtension,
    'node-cron': NodeCronExtension,
};
const actionHandlers = {
    'google-cloud-storage': GoogleStorageExtension,
    postgresql: PostgreSQLExtension,
    resend: ResendExtension,
    ajax: AjaxExtension,
    core: CoreExtension,
};
const EXTENISION_REGISTRY_TOKEN = new external_tiny_injector_.InjectionToken('EXTENISION_REGISTRY_TOKEN');
const ACTION_HANDLER_REGISTRY_TOKEN = new external_tiny_injector_.InjectionToken('ACTION_HANDLER_REGISTRY_TOKEN');

;// CONCATENATED MODULE: ../compiler/core/src/lib/registry/input-parser.ts
var input_parser_a, input_parser_b, input_parser_c, input_parser_d;









let ExtensionsRegistry = class ExtensionsRegistry extends AbstractInputParser {
    _context;
    _devKit;
    _sdk;
    _projectFS;
    constructor(_context, _devKit, _sdk, _projectFS) {
        super();
        this._context = _context;
        this._devKit = _devKit;
        this._sdk = _sdk;
        this._projectFS = _projectFS;
    }
    async getProjectMainSetup(externalDeps, extensions, userExt, userDependencies) {
        const results = [];
        for (const { sourceExtension } of await this.installedSourceExtensions()) {
            results.push(sourceExtension.packages ?? []);
        }
        const dependencies = results.flat();
        return [
            {
                filePath: this._projectFS.makeRootPath('.gitignore'),
                content: [
                // TODO: run on eject only
                // await fetch(
                //   'https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore',
                // ).then((res) => res.text()),
                ],
            },
            // {
            //   filePath: 'faslh.config.json',
            //   content: toJson({
            //     basePath: 'src',
            //     features: 'src/features',
            //     tsConfigFilePath: 'tsconfig.json',
            //   }),
            // },
            {
                filePath: this._projectFS.makeRootPath('package.json'),
                content: [
                    this._devKit.toJson({
                        version: '0.0.0',
                        main: './build/server.js',
                        type: 'module',
                        scripts: {
                            // FIXME: Temp workaround till we have a better way to pass env file
                            'start:dev': 'npx tsx --watch-path ./src ./src/server.ts',
                            'start:prod': 'node ./build/server.js',
                            'migration:generate': './node_modules/.bin/typeorm migration:generate ./src/migrations/migrations --dataSource ./src/datasource -o --pretty --outputJs',
                        },
                        dependencies: {
                            ...[
                                ...dependencies.filter((it) => it.dev !== true),
                                // ...externalDeps.map((it) => ({
                                //   name: it,
                                //   version: 'latest',
                                // })),
                            ].reduce((acc, it) => {
                                return {
                                    ...acc,
                                    [it.name]: it.version,
                                };
                            }, {}),
                            ...Object.fromEntries(Object.entries(userDependencies).filter(([name, version]) => !name.startsWith('@january/'))),
                        },
                        devDependencies: dependencies
                            .filter((it) => it.dev === true)
                            .reduce((acc, it) => {
                            return {
                                ...acc,
                                [it.name]: it.version,
                            };
                        }, {}),
                    }),
                ],
            },
            {
                filePath: this._projectFS.makeRootPath('tsconfig.json'),
                content: [
                    this._devKit.toJson({
                        compilerOptions: {
                            sourceMap: true,
                            target: 'ESNext',
                            module: 'esnext',
                            moduleResolution: 'node',
                            declaration: false,
                            outDir: 'dist',
                            baseUrl: '.',
                            rootDir: '.',
                            types: ['node'],
                            removeComments: true,
                            strict: true,
                            inlineSources: true,
                            sourceRoot: '/',
                            allowSyntheticDefaultImports: true,
                            esModuleInterop: true,
                            experimentalDecorators: true,
                            emitDecoratorMetadata: true,
                            importHelpers: true,
                            noEmitHelpers: true,
                            resolveJsonModule: true,
                            skipLibCheck: true,
                            skipDefaultLibCheck: true,
                            paths: {
                                ...extensions
                                    .filter((it) => it.main)
                                    .reduce((acc, it) => ({
                                    ...acc,
                                    [`@extensions/${it.name}`]: [
                                        `${this._projectFS.makeCorePath(it.main)}`,
                                    ],
                                }), {}),
                                ...userExt.reduce((acc, it) => ({
                                    ...acc,
                                    [`@extensions/${it}`]: [
                                        `${this._projectFS.makeSrcPath((0,external_path_.join)('extensions', it))}`,
                                    ],
                                }), {}),
                                '@workspace/entites': [
                                    `${this._projectFS.makeFeaturePath('entites.ts')}`,
                                ],
                                '@workspace/identity': [
                                    `${this._projectFS.makeIdentityPath('index.ts')}`,
                                ],
                            },
                        },
                        exclude: [
                            'node_modules',
                            'migrations',
                            'environment',
                            'dist',
                            'build',
                        ],
                    }),
                ],
            },
        ];
    }
    async getActionHandler(sourceId) {
        const sourceAction = await this._devKit.getSourceActionById(sourceId);
        if (!sourceAction) {
            throw new Error(`Action ${sourceId} not found.`);
        }
        const sourceExtension = this._devKit.getExtensionById(sourceAction.extensionId);
        if (!sourceExtension) {
            throw new Error(`Extension ${sourceAction.extensionId} not found.`);
        }
        const extensionType = extensionsRegistry[sourceExtension.name];
        if (!extensionType) {
            throw new Error(`Extension ${sourceExtension.name} not found.`);
        }
        const installedExtension = await this._sdk.getInstalledExtension(sourceExtension.id);
        if (!installedExtension) {
            throw new Error(`Extension ${sourceExtension.name} is not installed.`);
        }
        const extension = external_tiny_injector_.Injector.GetRequiredService(extensionType, this._context);
        return {
            sourceExtension,
            sourceAction,
            handler: extension,
        };
    }
    async getFieldHandler(sourceId) {
        const sourceField = await this._devKit.getSourceFieldById(sourceId);
        if (!sourceField) {
            throw new Error(`Field ${sourceId} not found.`);
        }
        const sourceExtension = this._devKit.getExtensionById(sourceField.extensionId);
        if (!sourceExtension) {
            throw new Error(`Extension ${sourceField.extensionId} not found.`);
        }
        const extensionType = extensionsRegistry[sourceExtension.name];
        if (!extensionType) {
            throw new Error(`Extension ${sourceExtension.name} not found.`);
        }
        const installedExtension = await this._sdk.getInstalledExtension(sourceExtension.id);
        if (!installedExtension) {
            throw new Error(`Extension ${sourceExtension.name} is not installed.`);
        }
        const extension = external_tiny_injector_.Injector.GetRequiredService(extensionType, this._context);
        return {
            sourceExtension,
            sourceField: sourceField,
            installedExtension,
            handler: extension,
        };
    }
    async installedSourceExtensions() {
        const installedExtensions = this._sdk.getInstalledExtensions();
        const results = [];
        for (const installedExtension of installedExtensions) {
            const sourceExtension = this._devKit.getExtensionById(installedExtension.id);
            if (!sourceExtension) {
                throw new Error(`Source extension with id ${installedExtension.id} not found.`);
            }
            const extensionsRegistry = external_tiny_injector_.Injector.GetRequiredService(EXTENISION_REGISTRY_TOKEN, this._context);
            const extensionType = extensionsRegistry[sourceExtension.name];
            if (!extensionType) {
                throw new Error(`Extension type ${sourceExtension.name} not found.`);
            }
            const extension = external_tiny_injector_.Injector.GetRequiredService(extensionType, this._context);
            results.push({
                extension,
                sourceExtension,
                installedExtension,
            });
        }
        return results;
    }
    async parseInput(dsl, workflow) {
        const extensions = await this.installedSourceExtensions();
        for (const it of extensions) {
            if ('handleInput' in it.extension) {
                const result = (await it.extension.handleInput(dsl.input, dsl.extras));
                if (result) {
                    return result;
                }
            }
        }
        if ('input' in dsl) {
            throw new Error(external_dedent_default() `
        Unable to parse input ${JSON.stringify(dsl.input)}
        Could be that related extension is not installed.
        `);
        }
        throw new Error(external_dedent_default() `
      Unable to parse input ${JSON.stringify(dsl)}
      Could be that related extension is not installed.
      `);
    }
    async parseInputV2(dsl) {
        const extensions = await this.installedSourceExtensions();
        for (const it of extensions) {
            if ('handleInputV2' in it.extension) {
                const result = await it.extension.handleInputV2(dsl);
                if (result) {
                    return result;
                }
            }
        }
        throw new Error(external_dedent_default() `
      Unable to parse input ${JSON.stringify(dsl)}
      Could be that related extension is not installed.
      `);
    }
    async routingExtension() {
        const exts = await this.installedSourceExtensions();
        const ext = exts.find((it) => it.sourceExtension.categories.includes('routing'));
        if (!ext) {
            throw new Error('No routing extension found');
        }
        return ext;
    }
    async processTrigger(contract, workflowInputs) {
        const action = await this.getActionHandler(contract.sourceId);
        return action.handler.processTrigger(contract, workflowInputs);
    }
    async evaulateRule(rule) {
        const structures = [];
        const indiviudalRules = decomposeVisitor(rule);
        const evaluatedRules = {};
        const evaluatedRulesIds = {};
        for (const [id, input] of Object.entries(indiviudalRules)) {
            const result = await this.parseInput({ input: input });
            if (result.structure) {
                structures.push(result.structure);
            }
            evaluatedRules[input] = result.value;
            evaluatedRulesIds[input] = id;
        }
        // FIXME: use the ContextAwareVisitor from CoreExtension
        // const visitor = new DslEvaluator(
        //   (input) => {
        //     return evaluatedRules[input];
        //   },
        //   (input) => {
        //     return evaluatedRulesIds[input];
        //   },
        // );
        const visitor = new ContextAwareVisitor(this._context);
        const evaluation = await visitor.start(parseDsl(rule), {
            emit: (structure) => {
                structures.push(structure);
            },
        });
        // const evaluation = visitor.visit(parseDsl(rule));
        return {
            structures: structures.flat(),
            evaluation,
        };
    }
    async extractInputs(dsl) {
        const extensions = await this.installedSourceExtensions();
        for (const it of extensions) {
            if ('extractInputs' in it.extension) {
                const result = await it.extension.extractInputs(dsl);
                if (result) {
                    return result;
                }
            }
        }
        return {};
    }
    async toInputs(dsl) {
        const visitor = new input_parser_InputsExtractor(this._context);
        let result = await visitor.visit(parseDsl(dsl));
        const inputs = {};
        if (!Array.isArray(result)) {
            result = [result];
        }
        for (const it of result.filter((it) => Object.keys(it).length > 0)) {
            const key = Object.keys(it)[0];
            const value = it[key];
            inputs[key] = { input: value };
        }
        return inputs;
    }
};
ExtensionsRegistry = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (input_parser_a = typeof external_tiny_injector_.Context !== "undefined" && external_tiny_injector_.Context) === "function" ? input_parser_a : Object, typeof (input_parser_b = typeof DevKit !== "undefined" && DevKit) === "function" ? input_parser_b : Object, typeof (input_parser_c = typeof Sdk !== "undefined" && Sdk) === "function" ? input_parser_c : Object, typeof (input_parser_d = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? input_parser_d : Object])
], ExtensionsRegistry);

class input_parser_InputsExtractor extends StringAsyncVisitor {
    _context;
    constructor(_context) {
        super();
        this._context = _context;
    }
    get _inputParser() {
        return external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
    }
    async visitCall(node) {
        const list = [];
        for (const arg of node.args) {
            list.push({
                name: await arg.name.accept(this),
                value: await arg.value.accept(this),
            });
        }
        return list;
    }
    async visitPropertyAccess(node) {
        const left = await node.name.accept(this);
        const right = await node.expression.accept(this);
        return `${left}.${right}`;
    }
    async visitBinary(node) {
        const left = await node.left.accept(this);
        const right = await node.right.accept(this);
        return [left, right];
    }
    async visitNamespace(node) {
        const result = await this._inputParser.extractInputs({
            namespace: await node.name.accept(this),
            value: node.expression,
            visit: this,
        });
        if (!result) {
            return {};
        }
        return result;
    }
    async visitArg(node) {
        return node.value.accept(this);
    }
    visit(node) {
        return node.accept(this);
    }
}
class ContextAwareVisitor extends StringAsyncVisitor {
    _context;
    emitter;
    constructor(_context) {
        super();
        this._context = _context;
    }
    get _inputParser() {
        return external_tiny_injector_.Injector.GetRequiredService(AbstractInputParser, this._context);
    }
    async visitBinary(node) {
        const operator = await node.operator.accept(this);
        let jsOperator = '';
        switch (operator) {
            case '=':
                jsOperator = '===';
                break;
            case '!=':
                jsOperator = '!==';
                break;
            default:
                throw new Error(`Operator ${operator} not supported`);
        }
        const left = await node.left.accept(this);
        const right = await node.right.accept(this);
        return `${left} ${jsOperator} ${right}`;
    }
    async visitArg(node) {
        return {
            name: await node.name.accept(this),
            value: await node.value.accept(this),
        };
    }
    async visitCall(node) {
        throw new Error('Method not implemented.');
    }
    async visitPropertyAccess(node) {
        const left = await node.name.accept(this);
        const right = await node.expression.accept(this);
        return `${left}.${right}`;
    }
    async visitNamespace(node) {
        const result = await this._inputParser.parseInputV2({
            namespace: await node.name.accept(this),
            value: node.expression,
        });
        if (result.structure) {
            this.emitter.emit(result.structure);
        }
        const returnValue = result.data?.['parameterName'] || result.value;
        return returnValue;
    }
    visit(node) {
        return node.accept(this);
    }
    start(node, emitter) {
        this.emitter = emitter;
        return node.accept(this);
    }
}

// EXTERNAL MODULE: external "deepmerge"
var external_deepmerge_ = __webpack_require__(31);
var external_deepmerge_default = /*#__PURE__*/__webpack_require__.n(external_deepmerge_);
;// CONCATENATED MODULE: ../compiler/core/src/lib/extension-manager.ts
var extension_manager_a, extension_manager_b, extension_manager_c, extension_manager_d, extension_manager_e;












external_tiny_injector_.Injector.AddSingleton(EXTENISION_REGISTRY_TOKEN, () => extensionsRegistry);
external_tiny_injector_.Injector.AddSingleton(ACTION_HANDLER_REGISTRY_TOKEN, () => actionHandlers);
let ExtensionManager = class ExtensionManager {
    _inputParser;
    _sdk;
    _projectFS;
    _devKit;
    _ormCodeWriter;
    constructor(_inputParser, _sdk, _projectFS, _devKit, _ormCodeWriter) {
        this._inputParser = _inputParser;
        this._sdk = _sdk;
        this._projectFS = _projectFS;
        this._devKit = _devKit;
        this._ormCodeWriter = _ormCodeWriter;
    }
    getOrmExtension() {
        return this._ormCodeWriter;
    }
    async getSetups() {
        const results = [];
        for (const { extension, installedExtension, } of await this._inputParser.installedSourceExtensions()) {
            if (!extension.handleSetup)
                continue;
            const setup = await extension.handleSetup(await this.#resolveRuntimeInputs(Object.entries(installedExtension.details)
                .map(([name, input]) => ({ [name]: { input } }))
                .reduce((acc, it) => ({ ...acc, ...it }), {})));
            results.push(setup);
        }
        return results.flat();
    }
    async generateFieldContract(input) {
        const { sourceField, ...action } = await this._inputParser.getFieldHandler(input.sourceId);
        const handler = action.handler;
        const defaults = {
            displayName: input.displayName,
            primitiveType: sourceField.primitiveType,
        };
        const result = await handler.handleField({
            featureId: input.featureId,
            sourceField,
            details: input.details,
            validation: input.validation,
            displayName: input.displayName,
        });
        return {
            ...defaults,
            ...result,
        };
    }
    async generateActionContract(sourceId, details, outputName) {
        const recorder = createRecorder({
            label: `generateActionContract ${sourceId}`,
        });
        recorder.record(`sourceId`);
        const { sourceAction, sourceExtension, ...action } = await this._inputParser.getActionHandler(sourceId);
        const handler = action.handler;
        recorder.recordEnd(`sourceId`);
        recorder.record(`handleAction`);
        const contract = handler.handleAction
            ? await handler.handleAction({
                sourceAction,
                outputName,
                details,
            })
            : {
                output: { displayName: outputName },
                runtimeInputs: details ?? {},
                transfer: {},
                workflowInputs: {},
            };
        recorder.recordEnd(`handleAction`);
        recorder.record(`returnVal`);
        const extras = {
            trigger: details['trigger'],
        };
        const returnVal = {
            inputs: await this.#resolveRuntimeInputs(contract.runtimeInputs ?? {}, extras),
            transfer: await this.#resolveRuntimeInputs(contract.transfer ?? {}, extras),
            output: contract.output ?? { displayName: outputName },
            sourceId: sourceId,
            sourceAction: sourceAction,
            workflowInputs: await this.#resolveRuntimeInputs(contract.workflowInputs ?? {}, extras),
        };
        recorder.recordEnd(`returnVal`);
        recorder.end();
        return returnVal;
    }
    async processFeature(contract) {
        const structures = [];
        (await this._inputParser.installedSourceExtensions()).forEach(({ extension }) => {
            if (extension.onFeatureContract) {
                const workflows = [];
                for (const workflow of contract.workflows) {
                    if ((extension.triggers ?? []).includes(workflow.trigger.sourceId)) {
                        workflows.push(workflow);
                    }
                }
                extension.onFeatureContract({
                    ...contract,
                    workflows,
                }, (concrete) => {
                    structures.push(concrete);
                });
            }
        });
        return structures;
    }
    async processWorkflow(contract) {
        const commandName = (0,external_stringcase_.camelcase)(contract.displayName);
        const structures = [];
        const fnNames = [];
        let workflowInputs = {};
        for (const action of contract.actions) {
            const result = await this.#processTreeActions(action);
            const structureResult = result.structures[0];
            structures.push({
                filePath: this._projectFS.makeCommandPath(contract.featureName, contract.tag, contract.displayName),
                structure: [
                    ...result.topLevel.flat(),
                    ...(structureResult.inline ? [] : structureResult.structure),
                ],
            });
            if (structureResult.inline) {
                fnNames.push(structureResult.structure);
            }
            else {
                fnNames.push([result.callExprStr]);
            }
            workflowInputs = {
                ...workflowInputs,
                ...action.workflowInputs,
            };
        }
        structures.push(...(await this._inputParser.processTrigger(contract.trigger, workflowInputs)));
        const dto = this.#inputDto({
            displayName: contract.displayName,
            inputs: contract.inputs,
            schemaName: contract.schemaName,
            inputName: contract.inputName,
        });
        const destructuredInputs = signutureInputs(contract.inputs).map(([name]) => name);
        const workflowParams = signutureInputs(workflowInputs).map(([name, prop]) => ({
            name: name,
            type: prop.type,
        }));
        if (destructuredInputs.length) {
            workflowParams.unshift({
                name: `input`,
                type: contract.inputName,
            });
        }
        // TODO: we don't need to have explict command creation here
        // we might create new extension named CQS and move this logic there
        // which would give us ability to have different flavors of code structure
        const workflowStructure = [
            ...(contract.trigger.details['imports'] ?? []),
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/validation'),
                namedImports: ['createSchema'],
            },
            ...dto,
            {
                kind: external_ts_morph_.StructureKind.Function,
                name: commandName,
                isAsync: true,
                isDefaultExport: false,
                isExported: true,
                parameters: workflowParams,
                statements: [...fnNames.flat(), `${contract.output.returnCode || ''};`],
            },
        ];
        structures.push({
            filePath: this._projectFS.makeCommandPath(contract.featureName, contract.tag, contract.displayName),
            structure: workflowStructure,
        });
        // export the command index.ts
        structures.push({
            filePath: this._projectFS.makeIndexFilePath(contract.featureName, contract.tag),
            structure: [
                {
                    kind: external_ts_morph_.StructureKind.ExportDeclaration,
                    moduleSpecifier: this._projectFS.makeExportPath(contract.displayName, 'command'),
                },
            ],
        });
        return structures;
    }
    async processPolicy(contract) {
        return [
            {
                filePath: this._projectFS.makeIdentityPath(`${(0,external_stringcase_.spinalcase)(contract.displayName)}.policy.ts`),
                structure: [
                    // ...structures.flat(),
                    contract.rule,
                    // {
                    //   isAsync: true,
                    //   kind: morph.StructureKind.Function,
                    //   name: camelcase(contract.displayName),
                    //   isDefaultExport: false,
                    //   isExported: true,
                    //   // parameters: [{ name: 'context', type: 'Record<string, any>' }],
                    //   // statements: [`return ${evaluation};`],
                    //   statements:[contract.rule]
                    // },
                ],
            },
        ];
    }
    async generateProjectContract(features, policies) {
        const recorder = createRecorder({
            label: 'generateProjectContract',
        });
        const contracts = {
            policies: policies.map((it) => ({
                displayName: it.displayName,
                rule: it.rule,
            })),
            features: await Promise.all(features.map(async (feature) => {
                recorder.record(`feature ${feature.displayName}`);
                const tags = new Set();
                const featureContract = {
                    displayName: feature.displayName,
                    tags: [],
                    tables: await Promise.all(feature.tables.map(async (table) => {
                        const indices = [];
                        for (const index of table.indexes) {
                            const indexes = [];
                            for (const column of index.columns) {
                                const result = await this.#resolveRuntimeInputs({
                                    column,
                                });
                                indexes.push(result.column.value);
                            }
                            indices.push({ columns: indexes });
                        }
                        const tableContract = {
                            tableName: table.displayName,
                            indexes: indices,
                            fields: await Promise.all(table.fields.map((field) => {
                                return this.generateFieldContract({
                                    featureId: feature.id,
                                    sourceId: field.sourceId,
                                    displayName: field.displayName,
                                    details: field.details,
                                    validation: field.validations,
                                });
                            })),
                        };
                        return tableContract;
                    })),
                    workflows: await Promise.all(feature.workflows.map(async (workflow) => {
                        recorder.record(`workflow ${workflow.displayName}`);
                        const actions = await Promise.all(workflow.actions.map(async (it) => {
                            const contract = await this.generateActionContract(it.sourceId, it.details, it.outputName);
                            return {
                                ...contract,
                                id: it.id,
                                name: it.displayName,
                                children: [],
                                data: {},
                            };
                        }));
                        const schemaName = (0,external_stringcase_.camelcase)(`${workflow.displayName} schema`);
                        const inputName = (0,external_stringcase_.pascalcase)(`${workflow.displayName} input`);
                        const inputs = external_deepmerge_default().all(actions.map((it) => it.inputs));
                        const workflowContract = {
                            actions: actions,
                            inputName: inputName,
                            inputs: inputs,
                            displayName: workflow.displayName,
                            schemaName: schemaName,
                            featureName: feature.displayName,
                            tag: workflow.tag,
                            output: {
                                properties: this.#generateOutputContract(workflow.output?.['properties'] ?? []),
                                returnCode: workflow.output?.['code']?.['inner'],
                            },
                            trigger: {
                                sourceId: workflow.trigger.sourceId,
                                policies: workflow.trigger['details']['policies'],
                                tag: workflow.tag, // NOTE: it only has effect for http triggers. we might need it for github action to support multiple webhooks
                                details: workflow.trigger.details,
                                inputName: inputName,
                                inputs: inputs,
                                displayName: workflow.displayName,
                                featureName: feature.displayName,
                                schemaName: schemaName,
                                operationName: (0,external_stringcase_.snakecase)(workflow.displayName),
                            },
                        };
                        tags.add(workflow.tag);
                        recorder.recordEnd(`workflow ${workflow.displayName}`);
                        return workflowContract;
                    })),
                };
                recorder.end();
                featureContract.tags = Array.from(tags);
                return featureContract;
            })),
        };
        return contracts;
    }
    #generateOutputContract(properties) {
        return properties.map((it) => ({
            type: it.primitiveType,
            validations: [],
            properties: [],
            static: false,
            value: it.name,
            input: '',
            namespace: it.kind,
            name: '',
            id: '',
        }));
    }
    #inputDto(contract) {
        const inputs = signutureInputs(contract.inputs);
        const schema = inputs.reduce((acc, [name, prop]) => {
            const type = (primitive) => [null, 'string', 'number'].includes(primitive)
                ? primitive
                : primitive === undefined
                    ? []
                    : primitive.endsWith('[]')
                        ? 'array'
                        : [];
            const primitiveType = type(prop.type);
            return {
                ...acc,
                [name]: {
                    type: primitiveType,
                    items: primitiveType === 'array'
                        ? {
                            type: type(prop.type.replace('[]', '')),
                        }
                        : undefined,
                    default: prop.defaultValue,
                    ...makeSchema(prop),
                },
            };
        }, {});
        return [
            (writer) => writer.writeLine(`export const ${contract.schemaName} = createSchema<${contract.inputName}>(${this._devKit.toJson(schema)});`),
            {
                kind: external_ts_morph_.StructureKind.Interface,
                isExported: true,
                isDefaultExport: false,
                name: contract.inputName,
                properties: inputs.map(([name, prop]) => {
                    const isMandatory = (prop.validations ?? []).some((it) => it.type === 'mandatory');
                    return {
                        decorators: [],
                        name: name,
                        hasQuestionToken: !isMandatory,
                        type: makeSchema(prop).type ?? prop.type,
                    };
                }),
            },
        ];
    }
    async #resolveRuntimeInputs(inputs, extras) {
        const value = inputs;
        const input = value.input;
        if (value !== null &&
            typeof value === 'object' &&
            typeof input === 'string' &&
            input.startsWith('@')) {
            const result = await this._inputParser.parseInput({
                input,
                extras,
            });
            (0,external_lodash_.merge)(value, result);
        }
        else {
            for (const [key, value] of Object.entries(inputs ?? {})) {
                if (Array.isArray(value)) {
                    for (const it of value) {
                        await this.#resolveRuntimeInputs(it, extras);
                    }
                }
                else if (value !== null && typeof value === 'object') {
                    const input = value.input;
                    if (typeof input === 'string' && input.startsWith('@')) {
                        const result = await this._inputParser.parseInput({
                            input,
                            extras,
                        });
                        (0,external_lodash_.merge)(value, result);
                    }
                    else {
                        await this.#resolveRuntimeInputs(value, extras);
                    }
                }
            }
        }
        return inputs;
    }
    async #processTreeActions(tree) {
        const actions = tree.children;
        const parameters = {};
        const topLevel = [];
        const actionsResults = {};
        for (const action of actions) {
            const result = await this.#processTreeActions(action);
            result.parameters.forEach((it) => (parameters[it.name] = it));
            actionsResults[action.id] = result;
            if (!result.structures[0].inline) {
                topLevel.push(...result.topLevel, result.structures[0].structure);
            }
            else {
                topLevel.push(...result.topLevel);
            }
        }
        const mainAction = await this.#proccesSingleAction((0,external_stringcase_.camelcase)(tree.name), tree, Object.values(parameters), (id) => {
            const actionResult = actionsResults[id];
            if (!actionResult) {
                throw new Error(`Action result ${id} not found`);
            }
            const result = actionResult.structures[0];
            if (result.inline) {
                return actionResult.unwrapped;
            }
            return [actionResult.callExprStr];
        });
        topLevel.push(...mainAction.topLevel);
        const actionStructure = [];
        const signutureParameters = nonStatic(tree.inputs).map(([name, prop]) => {
            const isMandatory = (prop.validations ?? []).some((it) => it.type === 'mandatory');
            return {
                kind: external_ts_morph_.StructureKind.Parameter,
                name: name,
                type: makeSchema(prop).type ?? prop.type ?? 'any',
                hasQuestionToken: !isMandatory,
            };
        });
        if (mainAction.inline) {
            // FIXME: the inline needs to be wrapped in a function
            // in case it is used in different places
            // so the meaning of inline is "guess if I can be inlined"
            // actionStructure.push(
            //   createArrowFn(
            //     camelcase(tree.name),
            //     [...signutureParameters, ...Object.values(parameters)],
            //     [mainAction.unwrapped],
            //   ),
            // );
            actionStructure.push({
                inline: true,
                structure: mainAction.unwrapped,
            });
        }
        else {
            actionStructure.push({
                inline: false,
                structure: [
                    {
                        kind: external_ts_morph_.StructureKind.Function,
                        name: (0,external_stringcase_.camelcase)(tree.name),
                        isAsync: true,
                        isDefaultExport: false,
                        isExported: false,
                        parameters: uniquify([...signutureParameters, ...Object.values(parameters)], (item) => item.name),
                        statements: mainAction.unwrapped,
                    },
                ],
            });
        }
        return {
            callExprStr: mainAction.callExprStr,
            structures: actionStructure,
            parameters: mainAction.parameters,
            topLevel: topLevel,
            unwrapped: mainAction.unwrapped,
        };
    }
    async #proccesSingleAction(name, action, childrenParameters, resolveAction) {
        const actionHanlder = await this._inputParser.getActionHandler(action.sourceId);
        const handler = actionHanlder.handler;
        const variables = {};
        const qbUsage = [];
        const topLevel = [];
        const body = [];
        const result = await handler.processAction(action, {
            useVariable: (name, value) => {
                variables[name] = {
                    declarationKind: external_ts_morph_.VariableDeclarationKind.Const,
                    kind: external_ts_morph_.StructureKind.VariableStatement,
                    declarations: [{ name: name, initializer: value }],
                };
            },
            useQb: (usage) => {
                // const qbString = `${action.output.displayName}QB`;
                const qbString = 'qb'; //
                // just name it "qb" given each action is function hence no name collision
                qbUsage.push(usage(qbString));
            },
            resolveAction,
        }, action.inputs, action.transfer);
        const structure = result.structure;
        if (typeof structure === 'string' ||
            typeof structure === 'function' ||
            Array.isArray(structure)) {
            body.push(structure);
        }
        else {
            body.push(structure.actionStructure);
            topLevel.push(structure.topLevelStructure);
        }
        const parameters = signutureInputs(action.inputs).map(([name, prop]) => {
            const isMandatory = (prop.validations ?? []).some((it) => it.type === 'mandatory');
            return {
                kind: external_ts_morph_.StructureKind.Parameter,
                name: name,
                type: makeSchema(prop).type ?? prop.type ?? 'any',
                hasQuestionToken: !isMandatory,
            };
        });
        const outputName = action.output.displayName;
        const withMaybeVar = outputName
            ? `const ${outputName} = `
            : `const ${(0,external_stringcase_.camelcase)(`${name}Output`)} = `;
        const callExprParameters = uniquify([
            ...nonStatic(action.inputs).map(paramName),
            ...childrenParameters.map((it) => it.name),
        ], (item) => item);
        if (result.inline) {
            return {
                inline: true,
                parameters,
                callExprStr: `${withMaybeVar} await ${name}(${callExprParameters.join(', ')})`,
                topLevel,
                unwrapped: [...body.flat()],
            };
        }
        return {
            inline: false,
            parameters,
            callExprStr: `${withMaybeVar} await ${name}(${callExprParameters.join(', ')})`,
            topLevel,
            unwrapped: [...Object.values(variables), ...qbUsage, ...body.flat()],
        };
    }
};
ExtensionManager = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (extension_manager_a = typeof AbstractInputParser !== "undefined" && AbstractInputParser) === "function" ? extension_manager_a : Object, typeof (extension_manager_b = typeof Sdk !== "undefined" && Sdk) === "function" ? extension_manager_b : Object, typeof (extension_manager_c = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? extension_manager_c : Object, typeof (extension_manager_d = typeof DevKit !== "undefined" && DevKit) === "function" ? extension_manager_d : Object, typeof (extension_manager_e = typeof OrmCodeWriter !== "undefined" && OrmCodeWriter) === "function" ? extension_manager_e : Object])
], ExtensionManager);

function resolveStepInput(property, bindings) {
    // remove "@step-"" word to get the action name
    const sourceId = property.namespace.replace('@step-', '');
    const usedAction = bindings.actions.find((it) => it.id === sourceId);
    if (!usedAction) {
        throw new Error(`Trying to access action ${sourceId} but it's not defined in the workflow`);
    }
    return `${usedAction.output.displayName}.${property.name}`;
}

// EXTERNAL MODULE: external "events"
var external_events_ = __webpack_require__(32);
var external_events_default = /*#__PURE__*/__webpack_require__.n(external_events_);
;// CONCATENATED MODULE: ../compiler/core/src/lib/hook/hook-manger.ts




/**
 * @deprecated use native DomainEvent or create Integration Event that uses
 * mediatr along with SDK instead of using hook manager
 */
let HookManager = class HookManager {
    #handlers = new Map();
    #em = new (external_events_default())({
        captureRejections: true,
    });
    off(eventName, callback) {
        const handler = this.#handlers.get(callback);
        if (!handler) {
            throw new Error('Handler not found');
        }
        this.#em.off(eventName, handler);
    }
    on(eventName, callback) {
        const handler = async (...args) => {
            const config = args.pop();
            try {
                await callback(...args);
                config.end();
            }
            catch (error) {
                config.end(error);
            }
        };
        this.#handlers.set(callback, handler);
        this.#em.on(eventName, handler);
    }
    async emit(eventName, ...args) {
        return new Promise((resolve, reject) => {
            let emitCount = 0;
            const listenerCount = this.#em.listenerCount(eventName);
            if (listenerCount === 0) {
                return resolve(void 0);
            }
            const operationId = (0,external_uuid_.v4)();
            this.#em.emit(eventName, ...[
                ...args,
                {
                    end: (error) => {
                        if (error) {
                            console.log(`Error processing operation: ${operationId} Error: ${error}`);
                            this.#em.removeAllListeners(operationId);
                            return reject(error);
                        }
                        emitCount++;
                        if (listenerCount === emitCount) {
                            this.#em.emit(operationId);
                            this.#em.removeAllListeners(operationId);
                        }
                    },
                },
            ]);
            (0,external_events_.once)(this.#em, operationId).then(resolve).catch(reject);
        });
    }
};
HookManager = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    })
], HookManager);


;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/typeorm/typeorm.visitor.ts



class TypeOrmVisitor extends expression_Visitor {
    _rootExpr;
    tableName;
    qbVar;
    constructor(_rootExpr, tableName, qbVar = 'qb') {
        super();
        this._rootExpr = _rootExpr;
        this.tableName = tableName;
        this.qbVar = qbVar;
    }
    _wrapInIfStatement(condition, statement) {
        return `if(${condition}) {
      ${statement}
    }`;
    }
    _wrapBrackets(statement) {
        // https://github.com/typeorm/typeorm/issues/6170#issuecomment-832790446
        return `new Brackets(qb => {${statement}})`;
        // return statement
    }
    _addSelect(columns) {
        // use it to group by non-aggregated columns
        const aggregateFound = columns.some((column) => column.aggregator);
        const groupbyCols = columns
            .filter((column) => !column.aggregator)
            .map((column) => `'${this.tableName}.${column.name}'`);
        const selectColumns = columns
            .map((column) => {
            if (column.aggregator) {
                /**
                 * we are using scape character because of having sql aggregators inside string
                 * the generated Code will be like this:
                 * "qb.addSelect('avg(\'Transactions.sales\') as avgSales');"
                 */
                return `'${column.aggregator}(\"${this.tableName}.${column.name}\") as ${column.alias ?? column.name}'`;
            }
            else if (column.name.includes('.')) {
                return `'${column.name} as ${column.alias ?? column.name.split('.')[1]}'`;
            }
            return `'${this.tableName}.${column.name}'`;
        })
            .join(', ');
        return `${this.qbVar}.addSelect(${selectColumns});${aggregateFound && groupbyCols.length
            ? `${this.qbVar}.addGroupBy(${groupbyCols.join(', ')});`
            : ''}`;
    }
    _addJoins(joinsFields) {
        return joinsFields
            .map((join) => {
            return `${this.qbVar}.innerJoin('${this.tableName}.${join.toLowerCase()}', '${join}');`;
        })
            .join(';');
    }
    _visitBetween(identifier, expr, context) {
        const left = expr.left.accept(this, {
            format: (value) => {
                return `:${value}`;
            },
        });
        const right = expr.right.accept(this, {
            format: (value) => {
                return `:${value}`;
            },
        });
        const statement = `${identifier.accept(this, {
            format: (value) => {
                const [tableNameOrFieldName, maybeFieldName] = value.split('.');
                if (!maybeFieldName) {
                    return `${this.tableName}.${value}`;
                }
                return `${tableNameOrFieldName}.${maybeFieldName}`;
            },
        })} BETWEEN :min AND :max`;
        const parameters = `{ min: ${left}, max: ${right} }`;
        const query = `${this.qbVar}.${context.combinator}Where('${statement}', ${parameters})`;
        return query;
    }
    visitDateLiteralExpr(expr, context) {
        // Why not use StringLiteral instead?
        return `'${expr.value}'`;
    }
    visitBinaryExpr(expr, context) {
        switch (expr.operator) {
            case 'between':
                return this._visitBetween(expr.left, expr.right, context);
            case 'like':
                return this._visitLike(expr, {
                    ...context,
                    required: context.required ?? false,
                    operator: context.inverse ? 'NOT LIKE' : 'LIKE',
                    prefix: context.prefix ?? '',
                    postfix: context.postfix ?? '',
                });
            case 'is':
                return this._visitIs(expr, {
                    ...context,
                    operator: context.inverse ? 'IS NOT' : 'IS',
                });
            case '===':
                return this._equal(expr, {
                    ...context,
                    operator: context.inverse ? '!=' : '=',
                });
            case '<':
                return this._equal(expr, {
                    ...context,
                    operator: context.inverse ? '>' : '<',
                });
            case '>':
                return this._equal(expr, {
                    ...context,
                    operator: context.inverse ? '<' : '>',
                });
            case '<=':
                return this._equal(expr, {
                    ...context,
                    operator: context.inverse ? '>=' : '<=',
                });
            case '>=':
                return this._equal(expr, {
                    ...context,
                    operator: context.inverse ? '<=' : '>=',
                });
            case 'in':
                return this._visitIn(expr, {
                    ...context,
                    operator: context.inverse ? 'NOT IN' : 'IN',
                });
            default:
                throw new Error(`Expression is not supported. operator: ${expr.operator}`);
        }
    }
    _visitIs(expr, context) {
        const left = this._acceptLeftExpression(expr, context);
        const binding = this._acceptBindings(expr, context);
        const statement = `${left} ${context.operator} ${binding}`;
        const parameters = this._acceptParameters(expr, context);
        const isRequired = context.required === true;
        const query = `${this.qbVar}.${context.combinator}Where('${statement}', ${parameters})`;
        const finalQuery = !isRequired
            ? this._wrapInIfStatement(expr.right.accept(this, {}), query)
            : query;
        return finalQuery;
    }
    _visitLike(expr, context) {
        const left = this._acceptLeftExpression(expr, context);
        const binding = this._acceptBindings(expr, context);
        const statement = `${left} ${context.operator} ${binding}`;
        const right = expr.right.accept(this, {
            ...context,
        });
        const keyName = expr.left.accept(this, {
            ...context,
            format: (value) => {
                const [tableNameOrFieldName, fieldName] = value.split('.');
                if (!fieldName) {
                    return `${tableNameOrFieldName}`;
                }
                return `${(0,external_stringcase_.camelcase)(value)}`;
            },
        });
        const rightWithBinding = `${context.prefix ? `'${context.prefix}' + ` : ''}${right}${context.postfix ? ` + '${context.postfix}'` : ''}`;
        const valueName = expr.right.accept(this, {
            ...context,
        });
        const parameters = `{${keyName}: ${rightWithBinding}}`;
        const isRequired = context.required === true;
        const query = `${this.qbVar}.${context.combinator}Where('${statement}', ${parameters})`;
        const finalQuery = !isRequired
            ? this._wrapInIfStatement(valueName, query)
            : query;
        return finalQuery;
    }
    _visitIn(expr, context) {
        const left = this._acceptLeftExpression(expr, context);
        const right = expr.right.accept(this, {
            ...context,
        });
        const binding = this._acceptBindings(expr, context);
        const statement = `${left} ${context.operator} ${binding}`;
        const keyName = expr.left.accept(this, {
            ...context,
            format: (value) => {
                const [tableName, prop] = value.split('.');
                if (!prop) {
                    return `${value}`;
                }
                return `${(0,external_stringcase_.camelcase)(value)}`;
            },
        });
        const parameters = `{ ${keyName}: ${right} }`;
        const valueName = expr.right.accept(this, {
            ...context,
        });
        const isRequired = context.required === true;
        const query = `${this.qbVar}.${context.combinator}Where('${statement}', ${parameters})`;
        const finalQuery = !isRequired
            ? this._wrapInIfStatement(valueName, query)
            : query;
        return finalQuery;
    }
    _acceptLeftExpression(expr, context) {
        return expr.left.accept(this, {
            ...context,
            format: (value) => {
                const [tableNameOrFieldName, maybeFieldName] = value.split('.');
                if (!maybeFieldName) {
                    return `${this.tableName}.${value}`;
                }
                return `${tableNameOrFieldName}.${maybeFieldName}`;
            },
        });
    }
    _acceptBindings(expr, context) {
        return expr.left.accept(this, {
            ...context,
            format: (value) => {
                const [tableName, prop] = value.split('.');
                if (!prop) {
                    return `:${value}`;
                }
                return `:${(0,external_stringcase_.camelcase)(value)}`;
            },
        });
    }
    _acceptParameters(expr, context) {
        const valueName = expr.right.accept(this, {
            ...context,
        });
        const keyName = expr.left.accept(this, {
            ...context,
            format: (value) => {
                const [tableName, prop] = value.split('.');
                if (!prop) {
                    return `${value}`;
                }
                return `${(0,external_stringcase_.camelcase)(value)}`;
            },
        });
        if (valueName === 'WILL_BE_USED_FROM_DESTRUCTURED_INPUT') {
            return `{${keyName}}`;
        }
        return `{ ${keyName}: ${valueName} }`;
    }
    _equal(expr, context) {
        // TODO: use template design pattern to override specific steps
        // for instance, _visitLike method uses same logic here with only
        // difference being that right expressions is formatted differently.
        const left = this._acceptLeftExpression(expr, context);
        const binding = this._acceptBindings(expr, context);
        const statement = `${left} ${context.operator} ${binding}`;
        const valueName = expr.right.accept(this, {
            ...context,
        });
        const parameters = this._acceptParameters(expr, context);
        const isRequired = context.required === true;
        const query = `${this.qbVar}.${context.combinator}Where('${statement}', ${parameters})`;
        const finalQuery = !isRequired
            ? this._wrapInIfStatement(valueName === 'WILL_BE_USED_FROM_DESTRUCTURED_INPUT'
                ? left
                : valueName, query)
            : query;
        return finalQuery;
    }
    visitNumericLiteralExpr(expr) {
        return `${expr.value}`;
    }
    visitNullLiteralExpr(expr) {
        return null;
    }
    visitBooleanLiteralExpr(expr) {
        return `${expr.value}`;
    }
    visitStringLiteralExpr(expr) {
        return `'${expr.value}'`;
    }
    visitIdentifier(expr, context) {
        if (context.format) {
            return context.format(expr.value);
        }
        return expr.value;
    }
    visitCombinator(expr, context) {
        return '';
    }
    visitListExpr(expr, context) {
        const children = expr.value.map((childExpr) => childExpr.accept(this, context));
        return `[${children.join(',')}]`;
    }
    visitQuerySelectExpr(expr, context) {
        const { columns, joinsFields } = context;
        const addSelectAndJoins = columns && columns.length
            ? `${this._addSelect(columns)}${this._addJoins(joinsFields)}`
            : '';
        const query = expr.value.map((group) => group.accept(this)).join(';');
        return `${addSelectAndJoins}${query}`;
    }
    visitGroupExpr(expr, context) {
        const qb = expr.value.map((childExpr) => {
            return childExpr.accept(this, {
                ...context,
                combinator: expr.combinator.operator,
            });
        });
        if (qb.length > 1) {
            return `${this.qbVar}.${expr.combinator.operator}Where(${this._wrapBrackets(qb.join(';'))})`;
        }
        return qb.join(';');
    }
    execute() {
        const result = this._rootExpr.accept(this);
        return result;
    }
    executeWithQueryBuiler() {
        const queryBuilder = `const ${this.qbVar} = createQueryBuilder(${(0,external_stringcase_.pascalcase)(this.tableName)},'${this.tableName}')`;
        const result = this._rootExpr.accept(this);
        return `${queryBuilder};${result}`;
    }
}
function runTypeormVisitor(props) {
    return new TypeOrmVisitor(toAst(props.query), (0,external_stringcase_.pascalcase)(props.tableName), props.qbVarName).execute();
}

;// CONCATENATED MODULE: ../compiler/core/src/lib/postgresql/typeorm/typeorm.writer.ts
var typeorm_writer_a;










let TypeORMCodeWriter = class TypeORMCodeWriter extends OrmCodeWriter {
    _projectFS;
    constructor(_projectFS) {
        super();
        this._projectFS = _projectFS;
    }
    #generateField(contract) {
        const decorators = [];
        const structure = {
            kind: external_ts_morph_.StructureKind.Property,
            name: (0,external_stringcase_.camelcase)(contract.displayName),
            type: contract.primitiveType,
            decorators: decorators,
        };
        return structure;
    }
    generateQuery(contract) {
        const classTableName = (0,external_stringcase_.pascalcase)(contract.tableName);
        const statements = [];
        contract.helpers.useQb((qb) => `const ${qb} = createQueryBuilder(${classTableName}, '${classTableName}');`);
        contract.helpers.useQb((qb) => `${new TypeOrmVisitor(toAst(contract.query.whereBy), (0,external_stringcase_.pascalcase)(contract.tableName), qb).execute()}`);
        Object.entries(contract.query.sortBy).forEach(([name, prop]) => {
            contract.helpers.useQb((qb) => `${qb}.addOrderBy('${name}', '${prop.value.toUpperCase()}');`);
        });
        contract.helpers.useQb((qbString) => (() => {
            switch (contract.pagination) {
                case 'limit_offset':
                    return `
          const paginationMetadata = deferredJoinPagination(${qbString}, {
            pageSize: pageSize,
            pageNo: pageNo,
            count: await qb.getCount(),
          });
        `;
                case 'deferred_joins':
                    return `
          const paginationMetadata = deferredJoinPagination(${qbString}, {
            pageSize: pageSize,
            pageNo: pageNo,
            count: await qb.getCount(),
          });
        `;
                case 'cursor':
                    return `
          const paginationMetadata = cursorPagination(${qbString}, {
            pageSize: pageSize,
            count: await qb.getCount(),
          });
        `;
                default:
                    return ``;
            }
        })());
        contract.helpers.useQb((qb) => `const ${contract.single === false ? 'records' : '[record]'} = (await execute(${qb}${contract.localizable ? 'assignI18n()' : ''}));`);
        if (contract.localizable) {
            contract.helpers.useQb((qb) => `withI18n(${qb}, input.locales);`);
        }
        return {
            actionStructure: [
                (writer) => statements.map((it) => writer.writeLine(it)),
                (writer) => writer.conditionalWriteLine(contract.pagination === 'none', `return record;`),
                (writer) => writer.conditionalWriteLine(contract.pagination !== 'none' && !contract.inline, external_dedent_default() `return {
                meta: paginationMetadata(records),
                records: records,
              }`),
                (writer) => writer.conditionalWriteLine(contract.pagination !== 'none' && contract.inline, external_dedent_default() `const result {
                meta: paginationMetadata(records),
                records: records,
              };
              return result;
              `),
            ],
            topLevelStructure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/execute'),
                    namedImports: [
                        'execute',
                        'createQueryBuilder',
                        ...[
                            contract.pagination === 'deferred_joins'
                                ? 'deferredJoinPagination'
                                : contract.pagination === 'cursor'
                                    ? 'cursorPagination'
                                    : contract.pagination === 'limit_offset'
                                        ? 'limitOffsetPagination'
                                        : null,
                        ].filter(notNullOrUndefined),
                    ],
                },
                {
                    // TODO: explicitly export date helpers because
                    // the query dsl is emitting them without importing them
                    // FIXME: Maybe we should move helpers parsing (non formal sql) to the query dsl
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/date'),
                    namedImports: [
                        'week',
                        'month',
                        'year',
                        'currentMonth',
                        'currentWeek',
                        'currentYear',
                    ],
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeEntityImportSpecifier(classTableName),
                    defaultImport: classTableName,
                },
            ],
        };
    }
    generateRaw(contract) {
        const processdActions = [];
        const outputName = contract.action.output.displayName;
        const outVarName = contract.inline
            ? outputName
                ? `const ${outputName} = await`
                : `await`
            : outputName
                ? 'return await'
                : 'await';
        switch (contract.action.sourceAction.name) {
            case 'raw-sql-query':
                {
                    processdActions.push(external_dedent_default()(`
              const serialized = sql\`${contract.action.transfer['query']}\`
              ${outVarName} dataSource.query(serialized.sql, serialized.values)
              `));
                }
                break;
            default:
                throw new Error(`Action not supported: ${contract.action.sourceAction.name}`);
        }
        return {
            actionStructure: [
                (writer) => processdActions.map((it) => writer.writeLine(it)),
            ],
            topLevelStructure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/data-source'),
                    defaultImport: 'dataSource',
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: 'sql-template-tag',
                    defaultImport: 'sql',
                },
            ],
        };
    }
    generateCommand(contract) {
        const processdActions = [];
        const classTableName = (0,external_stringcase_.pascalcase)(contract.tableName);
        const qbVarName = `qb`;
        const outputName = contract.action.output.displayName;
        const outVarName = contract.inline
            ? outputName
                ? `const ${outputName} = await`
                : `await`
            : outputName
                ? 'return await'
                : 'await';
        switch (contract.action.sourceAction.name) {
            case 'insert-record':
                {
                    const inputs = Object.entries(contract.action.inputs)
                        .map(([name, prop]) => {
                        if (prop.static) {
                            return `${(0,external_stringcase_.camelcase)(name)}: ${prop.value}`;
                        }
                        return `${(0,external_stringcase_.camelcase)(name)}`;
                    })
                        .join(', ');
                    processdActions.push(external_dedent_default()(`${outVarName} saveEntity(${classTableName},${inputs.length ? `{${inputs}}` : '{}'});
              `));
                }
                break;
            case 'upsert-record':
                {
                    const inputs = Object.entries(contract.action.inputs)
                        .map(([name, prop]) => {
                        if (prop.static) {
                            return `${(0,external_stringcase_.camelcase)(name)}: ${prop.value}`;
                        }
                        return `${(0,external_stringcase_.camelcase)(name)}`;
                    })
                        .join(', ');
                    const conflictFields = (contract.action.transfer['conflictFields'] ?? ['id']).map((it) => `'${it.input}'`);
                    processdActions.push(external_dedent_default()(`${outVarName} upsertEntity(${classTableName},${inputs.length ? `{${inputs}}` : '{}'}, [${conflictFields.join(',')}]);
              `));
                }
                break;
            case 'set-fields':
                {
                    const queryString = runTypeormVisitor({
                        query: contract.action.transfer['query']?.['whereBy'],
                        tableName: classTableName,
                        qbVarName: qbVarName,
                    });
                    let counters = Object.entries(contract.action.inputs).filter(([name, prop]) => prop.data?.['increment'] || prop.data?.['decrement']);
                    const counterParametrs = counters.map(([name, prop]) => {
                        if (prop.data?.['decrement']) {
                            return `${(0,external_stringcase_.camelcase)('decrement ' + name + ' by')}: ${prop.value}`;
                        }
                        return `${(0,external_stringcase_.camelcase)('increment ' + name + ' by')}: ${prop.value}`;
                    });
                    if (counters.length) {
                        const inputs = Object.entries(contract.action.inputs)
                            .filter(([name, prop]) => prop.data?.['column'])
                            .map(([name, prop]) => {
                            if (prop.data?.['increment']) {
                                return `${(0,external_stringcase_.camelcase)(name)}: () => '${(0,external_stringcase_.camelcase)(name)} + :${(0,external_stringcase_.camelcase)('increment ' + name + ' by')}'`;
                            }
                            if (prop.data?.['decrement']) {
                                return `${(0,external_stringcase_.camelcase)(name)}: () => '${(0,external_stringcase_.camelcase)(name)} - :${(0,external_stringcase_.camelcase)('decrement ' + name + ' by')}'`;
                            }
                            if (prop.static) {
                                return `${(0,external_stringcase_.camelcase)(name)}: ${prop.value}`;
                            }
                            return `${(0,external_stringcase_.camelcase)(name)}`;
                        })
                            .join(', ');
                        processdActions.push(external_dedent_default()(`const qb = createQueryBuilder(${classTableName}, '${classTableName}');
                ${queryString}
                ${outVarName} qb
                  .update()
                  .set({${inputs}})
                  .setParameters({${counterParametrs}})
                  .execute();
              `));
                    }
                    else {
                        const inputs = Object.entries(contract.action.inputs)
                            .filter(([name, prop]) => prop.data?.['column'])
                            .map(([name, prop]) => {
                            if (prop.static) {
                                return `${(0,external_stringcase_.camelcase)(name)}: ${prop.value}`;
                            }
                            return `${(0,external_stringcase_.camelcase)(name)}`;
                        })
                            .join(', ');
                        processdActions.push(external_dedent_default()(`const qb = createQueryBuilder(${classTableName}, '${classTableName}');
            ${queryString}
            ${outVarName} patchEntity(${qbVarName}, ${inputs.length ? `{${inputs}}` : '{}'});
              `));
                    }
                }
                break;
            case 'increment-field': {
                const queryString = runTypeormVisitor({
                    query: contract.action.transfer['query']?.['whereBy'],
                    tableName: classTableName,
                    qbVarName: qbVarName,
                });
                processdActions.push(external_dedent_default()(`const qb = createQueryBuilder(${classTableName}, '${classTableName}');
            ${queryString}
            ${outVarName} increment(qb, '${useInput(contract.action.transfer['field'])}', ${useInput(contract.action.inputs['value'])});
              `));
                break;
            }
            case 'decrement-field': {
                const queryString = runTypeormVisitor({
                    query: contract.action.transfer['query']?.['whereBy'],
                    tableName: classTableName,
                    qbVarName: qbVarName,
                });
                processdActions.push(external_dedent_default()(`const qb = createQueryBuilder(${classTableName}, '${classTableName}');
            ${queryString}
            ${outVarName} decrement(qb, '${useInput(contract.action.transfer['field'])}', ${useInput(contract.action.inputs['value'])});
              `));
                break;
            }
            case 'delete-record':
                {
                    // only works for "at" option
                    const queryString = runTypeormVisitor({
                        query: contract.action.transfer['query']?.['whereBy'],
                        tableName: classTableName,
                        qbVarName: qbVarName,
                    });
                    processdActions.push(external_dedent_default()(`const qb = createQueryBuilder(${classTableName}, '${classTableName}');
            ${queryString}
            ${outVarName} removeEntity(${classTableName}, ${qbVarName});
            `));
                }
                break;
            case 'check-record-existance':
                {
                    const queryString = runTypeormVisitor({
                        query: contract.action.transfer['query']?.['whereBy'],
                        tableName: classTableName,
                        qbVarName,
                    });
                    processdActions.push(external_dedent_default()(`const ${qbVarName} = createQueryBuilder(${classTableName}, '${classTableName}');
            ${queryString}
            ${outVarName} ${qbVarName}.getOne().then(Boolean);
            `));
                }
                break;
            // case 'i18n':
            //   return new I18nAction(it.details.columns);
            default:
                throw new Error(`Action not supported: ${contract.action.sourceAction.name}`);
        }
        return {
            actionStructure: [
                (writer) => processdActions.map((it) => writer.writeLine(it)),
            ],
            topLevelStructure: [
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: 'typeorm',
                    namedImports: ['Brackets'],
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/execute'),
                    namedImports: [
                        'createQueryBuilder',
                        'removeEntity',
                        'saveEntity',
                        'patchEntity',
                        'increment',
                        'decrement',
                        'upsertEntity',
                    ],
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeCoreImportSpecifier('core/date'),
                    namedImports: [
                        'week',
                        'month',
                        'year',
                        'currentMonth',
                        'currentWeek',
                        'currentYear',
                    ],
                },
                {
                    kind: external_ts_morph_.StructureKind.ImportDeclaration,
                    moduleSpecifier: this._projectFS.makeEntityImportSpecifier(classTableName),
                    defaultImport: classTableName,
                },
            ],
        };
    }
    generateTable(contract) {
        return [
            {
                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                moduleSpecifier: 'typeorm',
                namedImports: [
                    'Brackets',
                    'Entity',
                    'PrimaryColumn',
                    'PrimaryGeneratedColumn',
                    'Relation',
                    'ManyToOne',
                    'OneToMany',
                    'OneToOne',
                    'Column',
                    'CreateDateColumn',
                    'UpdateDateColumn',
                    'DeleteDateColumn',
                    'JoinColumn',
                    'JoinTable',
                    'ManyToMany',
                    'Index',
                    'RelationId',
                ],
            },
            {
                isDefaultExport: true,
                name: contract.tableName,
                kind: external_ts_morph_.StructureKind.Class,
                decorators: [
                    {
                        name: 'Entity',
                        arguments: [`"${(0,external_stringcase_.pascalcase)(contract.tableName)}"`],
                    },
                    ...(contract.indexes ?? []).map((index) => ({
                        name: 'Index',
                        arguments: [
                            `[${(index.columns ?? []).map((c) => `'${c}'`).join(',')}]`,
                            /**index.unique*/  true ? '{ unique: true }' : 0,
                        ],
                    })),
                ],
            },
        ];
    }
    generateCreatedAtField(contract) {
        const structure = this.#generateField(contract);
        structure.decorators ??= [];
        structure.hasExclamationToken = true;
        structure.hasQuestionToken = false;
        structure.decorators.push({
            kind: external_ts_morph_.StructureKind.Decorator,
            name: 'CreateDateColumn',
            arguments: [],
        });
        return structure;
    }
    generateDeletedAtField(contract) {
        // FIXME: remove deleted at field and replace it with status (draft, published, archived)
        const structure = this.#generateField(contract);
        structure.decorators ??= [];
        structure.hasExclamationToken = false;
        structure.hasQuestionToken = true;
        structure.decorators.push({
            kind: external_ts_morph_.StructureKind.Decorator,
            name: 'DeleteDateColumn',
            arguments: [],
        });
        return structure;
    }
    generateUpdatedAtField(contract) {
        const structure = this.#generateField(contract);
        structure.decorators ??= [];
        structure.hasExclamationToken = false;
        structure.hasQuestionToken = true;
        structure.decorators.push({
            kind: external_ts_morph_.StructureKind.Decorator,
            name: 'UpdateDateColumn',
            arguments: [],
        });
        return structure;
    }
    generatePrimaryField(contract) {
        const structure = this.#generateField(contract);
        structure.decorators ??= [];
        structure.hasExclamationToken = true;
        structure.hasQuestionToken = false;
        // TODO: Apply validation
        switch (contract.keyType) {
            case 'primary-key-custom':
                structure.decorators.push({
                    kind: external_ts_morph_.StructureKind.Decorator,
                    name: 'PrimaryColumn',
                    arguments: ['"varchar"'],
                });
                break;
            case 'primary-key-number':
                {
                    if (contract.generated) {
                        structure.decorators.push({
                            kind: external_ts_morph_.StructureKind.Decorator,
                            name: 'PrimaryGeneratedColumn',
                            arguments: ['"increment"'],
                        });
                    }
                    else {
                        structure.decorators.push({
                            kind: external_ts_morph_.StructureKind.Decorator,
                            name: 'PrimaryColumn',
                            arguments: ['"integer"'],
                        });
                    }
                }
                break;
            case 'primary-key-uuid':
                if (contract.generated) {
                    structure.decorators.push({
                        kind: external_ts_morph_.StructureKind.Decorator,
                        name: 'PrimaryGeneratedColumn',
                        arguments: ['"uuid"'],
                    });
                }
                else {
                    structure.decorators.push({
                        kind: external_ts_morph_.StructureKind.Decorator,
                        name: 'PrimaryColumn',
                        arguments: ['"uuid"'],
                    });
                }
                break;
            default:
                throw new Error(`Primary key type "${contract.keyType}" is not supported.`);
        }
        return structure;
    }
    generateField(contract) {
        if (contract.nativeType === 'primary-key') {
            return {
                fieldStructure: this.generatePrimaryField(contract),
                topLevelStructure: [],
            };
        }
        if (contract.nativeType === 'createdAt') {
            return {
                fieldStructure: this.generateCreatedAtField(contract),
                topLevelStructure: [],
            };
        }
        if (contract.nativeType === 'deletedAt') {
            return {
                fieldStructure: this.generateDeletedAtField(contract),
                topLevelStructure: [],
            };
        }
        if (contract.nativeType === 'updatedAt') {
            return {
                fieldStructure: this.generateUpdatedAtField(contract),
                topLevelStructure: [],
            };
        }
        const structure = this.#generateField(contract);
        const topLevelStructure = [];
        const columnOptions = [];
        structure.decorators ??= [];
        if (contract.mandatory) {
            structure.hasExclamationToken = true;
            structure.hasQuestionToken = false;
            columnOptions.push('nullable: false');
        }
        else {
            structure.hasExclamationToken = false;
            structure.hasQuestionToken = true;
            columnOptions.push('nullable: true');
            structure.type = `${structure.type}|null`;
        }
        // TODO: Apply validation
        switch (contract.nativeType) {
            case 'relation-id':
                if (contract.virtualRelationField) {
                    structure.decorators.push({
                        kind: external_ts_morph_.StructureKind.Decorator,
                        name: 'RelationId',
                        arguments: [
                            `(entity: ${(0,external_stringcase_.pascalcase)(contract.tableName)}) => entity.${contract.columnNameOnSelfTable}`,
                        ],
                    });
                }
                return {
                    fieldStructure: structure,
                    topLevelStructure: topLevelStructure,
                };
            case 'relation':
                structure.type = (0,external_stringcase_.pascalcase)(contract.relatedEntityName);
                switch (contract.relationship) {
                    case 'one-to-one':
                        {
                            topLevelStructure.push({
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeEntityImportSpecifier((0,external_stringcase_.pascalcase)(contract.relatedEntityName)),
                                defaultImport: (0,external_stringcase_.pascalcase)(contract.relatedEntityName),
                            });
                            // columnOptions.push('cascade: true');
                            if (contract.joinSide) {
                                structure.decorators.push({
                                    kind: external_ts_morph_.StructureKind.Decorator,
                                    name: 'JoinColumn',
                                    arguments: [],
                                });
                            }
                            structure.decorators.push({
                                kind: external_ts_morph_.StructureKind.Decorator,
                                name: 'OneToOne',
                                arguments: [
                                    `() => ${(0,external_stringcase_.pascalcase)(contract.relatedEntityName)}`,
                                    `(relatedEntity) => relatedEntity.${(0,external_stringcase_.camelcase)(contract.nameOfColumnOnRelatedEntity)}`,
                                    columnOptions.length ? `{${columnOptions.join(',')}}` : '',
                                ],
                            });
                        }
                        break;
                    case 'many-to-one':
                    case 'one-to-many':
                        {
                            topLevelStructure.push({
                                kind: external_ts_morph_.StructureKind.ImportDeclaration,
                                moduleSpecifier: this._projectFS.makeEntityImportSpecifier((0,external_stringcase_.pascalcase)(contract.relatedEntityName)),
                                defaultImport: (0,external_stringcase_.pascalcase)(contract.relatedEntityName),
                            });
                            if (contract.joinSide) {
                                structure.type = `Relation<${(0,external_stringcase_.pascalcase)(contract.relatedEntityName)}>`;
                                structure.decorators.push({
                                    kind: external_ts_morph_.StructureKind.Decorator,
                                    name: 'ManyToOne',
                                    arguments: [
                                        `() => ${(0,external_stringcase_.pascalcase)(contract.relatedEntityName)}`,
                                        `(relatedEntity) => relatedEntity.${contract.nameOfColumnOnRelatedEntity}`,
                                        columnOptions.length ? `{${columnOptions.join(',')}}` : '',
                                    ],
                                });
                            }
                            else {
                                structure.type = `${(0,external_stringcase_.pascalcase)(contract.relatedEntityName)}[]`;
                                structure.decorators.push({
                                    kind: external_ts_morph_.StructureKind.Decorator,
                                    name: 'OneToMany',
                                    arguments: [
                                        `() => ${(0,external_stringcase_.pascalcase)(contract.relatedEntityName)}`,
                                        `(relatedEntity) => relatedEntity.${contract.nameOfColumnOnRelatedEntity}`,
                                        columnOptions.length ? `{${columnOptions.join(',')}}` : '',
                                    ],
                                });
                            }
                        }
                        break;
                    case 'many-to-many':
                        {
                            //
                        }
                        break;
                    default:
                        throw new Error(`Relationship ${contract.relationship} is not supported.`);
                }
                return {
                    fieldStructure: structure,
                    topLevelStructure: topLevelStructure,
                };
            case 'json':
            case 'uuid':
                columnOptions.push(`type: "${contract.nativeType}"`);
                break;
            case 'varchar':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.nativeType}"`);
                if (notNullOrUndefined(contract.length)) {
                    columnOptions.push(`length: "${contract.length}"`);
                }
                break;
            case 'enum':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.nativeType}"`);
                columnOptions.push(`enum: [${contract.values.map((v) => `"${v}"`)}]`);
                break;
            case 'decimal':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.nativeType}"`);
                columnOptions.push(`precision: ${contract.precision}`);
                columnOptions.push(`scale: ${contract.scale}`);
                break;
            case 'integer':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.nativeType}"`);
                break;
            case 'boolean':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.nativeType}"`);
                break;
            case 'datetime':
            case 'time':
                if (contract.unique) {
                    columnOptions.push('unique: true');
                }
                columnOptions.push(`type: "${contract.zone}"`);
                columnOptions.push(` transformer: {
      to: (value: unknown) => value,
      from: (value: unknown) =>
        value instanceof Date ? value.toISOString() : value,
    },`);
                break;
            default:
                break;
        }
        structure.decorators.push({
            kind: external_ts_morph_.StructureKind.Decorator,
            name: 'Column',
            arguments: [columnOptions.length ? `{${columnOptions.join(',')}}` : ''],
        });
        return {
            fieldStructure: structure,
            topLevelStructure: topLevelStructure,
        };
    }
};
TypeORMCodeWriter = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
        serviceType: OrmCodeWriter,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (typeorm_writer_a = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? typeorm_writer_a : Object])
], TypeORMCodeWriter);

function wrapInTransaction(body) {
    // TODO: this should be an action that accepts list of actions
    return `
      const result = await dataSource.transaction(async (em) => {
        ${body}
      });
      return result
    `;
}
// export function applyValidations(
//   validations: readonly FieldValidation[]
// ): morph.DecoratorStructure[] {
//   // Should the validation be part of the Generator plugins?
//   return (validations ?? []).reduce((acc, validation) => {
//     const decoratorName = typeToValidationDecorators[validation.type];
//     if (!decoratorName) {
//       throw new Error(`${validation.type} doesn't have validation decorator.`);
//     }
//     const messageArg = validation.message
//       ? `{message: "${validation.message}"}`
//       : undefined;
//     switch (validation.type) {
//       case 'tel':
//         acc.push({
//           kind: morph.StructureKind.Decorator,
//           name: decoratorName,
//           arguments: [
//             `${validation.details.local || 'null'}`,
//             messageArg,
//           ].filter(notNullOrUndefined),
//         });
//         break;
//       case 'matches':
//         acc.push({
//           kind: morph.StructureKind.Decorator,
//           name: decoratorName,
//           arguments: [`${validation.details.pattern}`, messageArg].filter(
//             notNullOrUndefined
//           ),
//         });
//         break;
//       case 'email':
//         acc.push({
//           kind: morph.StructureKind.Decorator,
//           name: decoratorName,
//           arguments: [messageArg].filter(notNullOrUndefined),
//         });
//         break;
//       case 'decimal':
//         acc.push({
//           kind: morph.StructureKind.Decorator,
//           name: decoratorName,
//           arguments: [
//             validation.details.decimal_digits
//               ? `{decimal_digits: "${validation.details.decimal_digits}"}`
//               : undefined,
//             messageArg,
//           ].filter(notNullOrUndefined),
//         });
//         break;
//       default:
//         acc.push({
//           kind: morph.StructureKind.Decorator,
//           name: decoratorName,
//           arguments: [messageArg].filter(notNullOrUndefined),
//         });
//     }
//     return acc;
//   }, [] as morph.DecoratorStructure[]);
// }

;// CONCATENATED MODULE: ../compiler/core/src/index.ts



external_tiny_injector_.Injector.AddScoped(AbstractInputParser, ExtensionsRegistry);








;// CONCATENATED MODULE: ../compiler/generator/src/lib/virtual-files.ts
var virtual_files_a, virtual_files_b, virtual_files_c, virtual_files_d;








let VirtualFiles = class VirtualFiles {
    _extensionManager;
    _extensionsRegistry;
    _projectConfig;
    _projectFS;
    constructor(_extensionManager, _extensionsRegistry, _projectConfig, _projectFS) {
        this._extensionManager = _extensionManager;
        this._extensionsRegistry = _extensionsRegistry;
        this._projectConfig = _projectConfig;
        this._projectFS = _projectFS;
    }
    _refineChangesProjection(projection) {
        const features = projection.features.reduce((acc, curr) => {
            const workflows = projection.workflows.filter((workflow) => {
                return workflow.featureId === curr.id;
            });
            const tables = projection.tables.filter((table) => {
                return table.featureId === curr.id;
            });
            acc.push({
                workflows,
                tables,
                displayName: curr.displayName,
                id: curr.id,
            });
            return acc;
        }, []);
        const policies = projection.policies;
        return {
            features,
            policies,
            imports: projection.imports,
            extensions: projection.extensions,
        };
    }
    async generateConcreteStructure(contracts, projectDeps) {
        return {
            setup: projectDeps,
            policies: await Promise.all(contracts.policies.map((it) => this._extensionManager.processPolicy(it))),
            features: await Promise.all(contracts.features.map(async (feature) => {
                return {
                    displayName: feature.displayName,
                    structures: await this._extensionManager.processFeature(feature),
                    tables: await Promise.all(feature.tables.map(async (table) => {
                        return {
                            tableName: table.tableName,
                            entityStructure: this._extensionManager
                                .getOrmExtension()
                                .generateTable({
                                tableName: (0,external_stringcase_.pascalcase)(table.tableName),
                                indexes: table.indexes,
                            }),
                            fields: table.fields.map((it) => {
                                return {
                                    ...this._extensionManager
                                        .getOrmExtension()
                                        .generateField(it),
                                    tableName: (0,external_stringcase_.pascalcase)(table.tableName),
                                };
                            }),
                        };
                    })),
                    workflows: await Promise.all(feature.workflows.map((it) => this._extensionManager.processWorkflow(it))),
                };
            })),
        };
    }
    async prepareProject(changes, generateDir) {
        const recorder = createRecorder({
            label: 'Preparing',
        });
        if (generateDir) {
            recorder.record('update project config');
            const config = this._projectConfig.getConfig();
            this._projectConfig.updateConfig({
                basePath: (0,external_path_.join)(generateDir, config.basePath),
                features: (0,external_path_.join)(generateDir, config.features),
            });
            recorder.recordEnd('update project config');
        }
        recorder.record('generating project contract');
        const refinedChanges = this._refineChangesProjection(changes);
        const contracts = await this._extensionManager.generateProjectContract(refinedChanges.features, refinedChanges.policies);
        const userFiles = await this.getUserFiles(generateDir);
        const concreteStructure = await this.generateConcreteStructure(contracts, [
            ...(await this._extensionsRegistry.getProjectMainSetup(refinedChanges.imports, refinedChanges.extensions, userFiles.extensions, userFiles['package.json'].dependencies)),
            ...(await this._extensionManager.getSetups()),
        ]);
        recorder.recordEnd('generating concrete structure');
        recorder.end();
        return concreteStructure;
    }
    async generate(concreteStructure, generateDir) {
        const vProject = new VirtualProject(this._projectFS);
        vProject.generate(concreteStructure, generateDir);
        return {
            files: vProject.getOutput(),
            save: vProject.emit.bind(vProject),
            cleanup: () => vProject.cleanup(),
        };
    }
    async getSourceCode(changes, generateDir) {
        const recorder = createRecorder({
            label: 'Generating Source Code',
        });
        recorder.record('prepare project');
        const concreteStructure = await this.prepareProject(changes, generateDir);
        recorder.recordEnd('prepare project');
        recorder.record('generate');
        const result = await this.generate(concreteStructure, generateDir);
        recorder.recordEnd('generate');
        recorder.end();
        const extDir = (0,external_path_.join)(generateDir, '../', 'src', 'extensions');
        await (0,promises_.cp)(extDir, (0,external_path_.join)(generateDir, 'src', 'extensions'), {
            recursive: true,
        });
        return result;
    }
    async getUserFiles(dir) {
        const workspace = (0,external_path_.join)(dir, '../');
        const extDir = (0,external_path_.join)(workspace, 'src', 'extensions');
        return {
            extensions: await (0,promises_.readdir)(extDir),
            'package.json': JSON.parse(await (0,promises_.readFile)((0,external_path_.join)(workspace, 'package.json'), 'utf-8')),
        };
    }
};
VirtualFiles = (0,external_tslib_.__decorate)([
    (0,external_tiny_injector_.Injectable)({
        lifetime: external_tiny_injector_.ServiceLifetime.Scoped,
    }),
    (0,external_tslib_.__metadata)("design:paramtypes", [typeof (virtual_files_a = typeof ExtensionManager !== "undefined" && ExtensionManager) === "function" ? virtual_files_a : Object, typeof (virtual_files_b = typeof ExtensionsRegistry !== "undefined" && ExtensionsRegistry) === "function" ? virtual_files_b : Object, typeof (virtual_files_c = typeof ProjectConfig !== "undefined" && ProjectConfig) === "function" ? virtual_files_c : Object, typeof (virtual_files_d = typeof ProjectFS !== "undefined" && ProjectFS) === "function" ? virtual_files_d : Object])
], VirtualFiles);


;// CONCATENATED MODULE: ../compiler/generator/src/index.ts



// EXTERNAL MODULE: external "esbuild"
var external_esbuild_ = __webpack_require__(33);
var external_esbuild_default = /*#__PURE__*/__webpack_require__.n(external_esbuild_);
;// CONCATENATED MODULE: ../compiler/generator/src/bundling/virtual.ts


const nodeExternalsPlugin = (packageJsonV) => {
    const packageJson = JSON.parse(packageJsonV);
    const keys = [
        'dependencies',
        'devDependencies',
        'peerDependencies',
        'optionalDependencies',
    ];
    const nodeModules = keys
        .map((key) => Object.keys(packageJson[key] || {}))
        .flat();
    return {
        name: 'node-externals',
        setup(build) {
            // On every module resolved, we check if the module name should be an external
            build.onResolve({
                namespace: 'virtual',
                filter: /.*/,
            }, (args) => {
                // To allow sub imports from packages we take only the first path to deduct the name
                let moduleName = args.path.split('/')[0];
                // In case of scoped package
                if (args.path.startsWith('@')) {
                    const split = args.path.split('/');
                    moduleName = `${split[0]}/${split[1]}`;
                }
                // Mark the module as external so it is not resolved
                if (nodeModules.includes(moduleName)) {
                    return { path: args.path, external: true };
                }
                return null;
            });
        },
    };
};
function virtualBundle(options) {
    const getFile = (name) => {
        const file = options.files.find((file) => file.path.endsWith(name));
        if (!file) {
            return null;
        }
        return file;
    };
    const packageJsonFile = getFile('package.json');
    const configJson = getFile('tsconfig.json');
    const filesMap = Object.fromEntries(options.files.map((file) => [file.path, file.content]));
    return external_esbuild_default().build({
        entryPoints: [options.src],
        write: false,
        platform: 'node',
        treeShaking: true,
        minify: true,
        format: 'esm',
        outfile: options.dist,
        keepNames: true,
        bundle: true,
        assetNames: '[name]',
        loader: {
            '.json': 'file',
        },
        tsconfigRaw: configJson ? JSON.parse(configJson.content) : undefined,
        plugins: [
            packageJsonFile
                ? nodeExternalsPlugin(packageJsonFile.content)
                : {
                    name: 'node-externals',
                    setup(build) {
                        //
                    },
                },
            {
                name: 'virtual-files',
                setup(build) {
                    build.onResolve({ filter: /.*/ }, (args) => {
                        const path = (0,external_path_.relative)(process.cwd(), (0,external_path_.resolve)((0,external_path_.dirname)(args.importer), args.path));
                        const attempts = [path, `${path}.ts`, `${path}/index.ts`];
                        for (const attempt of attempts) {
                            if (attempt in filesMap) {
                                return {
                                    path: attempt,
                                    namespace: 'virtual',
                                };
                            }
                        }
                        return null;
                    });
                    build.onLoad({
                        filter: /.*/,
                        namespace: 'virtual',
                    }, (args) => {
                        return {
                            contents: filesMap[args.path],
                            loader: 'default',
                        };
                    });
                },
            },
        ],
    });
}

// EXTERNAL MODULE: external "esbuild-node-externals"
var external_esbuild_node_externals_ = __webpack_require__(34);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(35);
;// CONCATENATED MODULE: ../compiler/generator/src/bundling/bundler.ts




function bundle(options) {
    const tsconfig = JSON.parse((0,external_fs_.readFileSync)((0,external_path_.join)(options.projectRoot, 'tsconfig.json'), 'utf-8'));
    const paths = tsconfig.compilerOptions.paths;
    return external_esbuild_default().build({
        entryPoints: [options.src],
        platform: 'node',
        treeShaking: true,
        minify: true,
        format: 'esm',
        outfile: options.dist,
        bundle: true,
        plugins: [
            (0,external_esbuild_node_externals_.nodeExternalsPlugin)({
                packagePath: [(0,external_path_.join)(options.projectRoot, 'package.json')],
                allowList: Object.keys(paths),
            }),
        ],
        assetNames: '[name]',
        loader: {
            '.json': 'file',
        },
    });
}

;// CONCATENATED MODULE: ../compiler/generator/src/bundling/index.ts



// EXTERNAL MODULE: ../compiler/generator/utils/src/index.ts
var src = __webpack_require__(3);
;// CONCATENATED MODULE: ../sdk/src/lib/build_commit.ts
class BuildCommit {
    repoPath;
    changes;
    imports;
    constructor(repoPath, changes, imports) {
        this.repoPath = repoPath;
        this.changes = changes;
        this.imports = imports;
    }
}

;// CONCATENATED MODULE: ../sdk/src/lib/commands.ts






const commandsMap = {
    AddFeature: AddFeatureCommand,
    AddTable: AddTableCommand,
    AddField: AddFieldCommand,
    AddTag: AddTagCommand,
    AddWorkflow: AddWorkflowCommand,
    AddActionToWorkflow: AddActionToWorkflowCommand,
    AssignTagToWorkflow: AssignTagToWorkflowCommand,
    AdjustFieldValidation: AdjustFieldValidationCommand,
    CreateTableIndex: CreateTableIndexCommand,
    DeleteFeature: DeleteFeatureCommand,
    AssignPolicyToWorkflow: AssignPolicyToWorkflowCommand,
};
function dop(commands, claims, genDir, imports) {
    return external_tiny_injector_.Injector.CreateScope(async (context) => {
        const recorder = createRecorder({
            label: 'dop',
        });
        context.setExtra('claims', claims);
        recorder.record('fold changes');
        const mediator = external_tiny_injector_.Injector.GetRequiredService(tiny_mediatr_.Mediator, context);
        const failed = [];
        await Promise.all(commands.map((command) => mediator
            .send(mapper.map(command.payload, commandsMap[command.command]))
            .catch((error) => {
            failed.push({ command, error });
        })));
        if (failed.length > 0) {
            logMe({ 'Retrying failed commands': failed });
            await Promise.all(failed.map(({ command }) => mediator.send(mapper.map(command.payload, commandsMap[command.command]))));
            logMe({ 'Failed commands': failed });
        }
        recorder.recordEnd('fold changes');
        recorder.record('build commit');
        const result = await mediator.send(new BuildCommit(genDir, undefined, imports));
        recorder.recordEnd('build commit');
        recorder.end();
        return result;
    });
}
function fromDef(def, claims) {
    return external_tiny_injector_.Injector.CreateScope(async (context) => {
        const recorder = createRecorder({
            label: 'dop',
        });
        context.setExtra('claims', claims);
        context.setExtra('definition', def);
        recorder.record('fold changes');
        const mediator = external_tiny_injector_.Injector.GetRequiredService(tiny_mediatr_.Mediator, context);
        const failed = [];
        if (failed.length > 0) {
            logMe({ 'Retrying failed commands': failed });
            await Promise.all(failed.map(({ command }) => mediator.send(mapper.map(command.payload, commandsMap[command.command]))));
            logMe({ 'Failed commands': failed });
        }
        recorder.recordEnd('fold changes');
        recorder.record('build commit');
        // const result = await mediator.send(
        //   new BuildCommit(genDir, undefined, imports),
        // );
        recorder.recordEnd('build commit');
        recorder.end();
        // return result;
    });
}
dop.project = async (def, claims) => {
    return fromDef(def, claims);
};

;// CONCATENATED MODULE: ../sdk/src/lib/execute.ts





async function toCommands(projectDefinition) {
    const devKit = new DevKit();
    const commands = [];
    const tablesIds = {};
    const tagsIds = {};
    const workflowIds = {};
    const fieldsIds = {};
    const actionsIds = {};
    const pathsIds = {};
    projectDefinition.features.forEach((feature) => {
        Object.keys(feature.tables).forEach((tableName) => {
            tablesIds[tableName] = (0,external_uuid_.v4)();
            const table = feature.tables[tableName];
            Object.keys(table.fields).forEach((fieldName) => {
                fieldsIds[fieldName] = (0,external_uuid_.v4)();
            });
        });
        feature.workflows.forEach((workflow) => {
            workflowIds[workflow.name] = (0,external_uuid_.v4)();
            tagsIds[workflow.tag] ??= (0,external_uuid_.v4)();
            Object.keys(workflow.actions).forEach((actionName) => {
                actionsIds[actionName] = (0,external_uuid_.v4)();
                const action = workflow.actions[actionName];
                if (typeof action === 'function') {
                    return;
                }
                if (action.type === 'branch') {
                    const config = action.config;
                    if (hasProperty(config, 'paths')) {
                        config.paths.forEach((path) => {
                            pathsIds[path.name] = path.id;
                        });
                    }
                }
            });
        });
    });
    function mapQueries(details) {
        if (typeof details === 'string' ||
            typeof details === 'number' ||
            typeof details === 'boolean') {
            return details;
        }
        if (isRequest(details)) {
            return mapQuery(details);
        }
        if (isNullOrUndefined(details)) {
            return details;
        }
        if (Array.isArray(details)) {
            return details.map(mapQueries);
        }
        return Object.entries(details).reduce((acc, [key, value]) => {
            return {
                ...acc,
                [key]: mapQueries(value),
            };
        }, {});
    }
    function mapQuery(value) {
        if (isRequest(value)) {
            let result = undefined;
            switch (value.command) {
                case 'QueryTable':
                    result = tablesIds[value.payload.name];
                    break;
                case 'QueryTag':
                    result = tagsIds[value.payload.name];
                    break;
                case 'QueryWorkflow':
                    result = workflowIds[value.payload.name];
                    break;
                case 'QueryFieldName':
                    for (const feature of projectDefinition.features) {
                        for (const table of Object.values(feature.tables)) {
                            if (table.fields[value.payload.name]) {
                                const field = table.fields[value.payload.name];
                                if (field.type === 'relation') {
                                    result = (0,external_stringcase_.camelcase)(value.payload.name + ' id');
                                }
                            }
                        }
                    }
                    result ??= value.payload.name;
                    break;
                case 'QueryField':
                    for (const feature of projectDefinition.features) {
                        for (const table of Object.values(feature.tables)) {
                            if (table.fields[value.payload.name]) {
                                const field = table.fields[value.payload.name];
                                if (field.type === 'relation') {
                                    result = fieldsIds[(0,external_stringcase_.camelcase)(value.payload.name + ' id')];
                                }
                            }
                        }
                    }
                    // in case of relation field not found, fallback to the field itself
                    result ??= fieldsIds[value.payload.name];
                    break;
                case 'QueryAction':
                    result = actionsIds[value.payload.name];
                    break;
                case 'QueryPath':
                    result = pathsIds[value.payload.name];
                    break;
                default:
                    throw new Error(`Unknown command ${value.command}`);
            }
            if (isNullOrUndefined(result)) {
                throw new Error(`Could not find ${value.command} ${value.payload.name}`);
            }
            return result;
        }
        return value;
    }
    for (const feature of projectDefinition.features) {
        // Features
        const featureId = (0,external_uuid_.v4)();
        commands.push({
            command: 'AddFeature',
            payload: {
                id: featureId,
                displayName: feature.name,
                policies: Object.entries(feature.policies ?? {}).reduce((acc, [displayName, rule]) => {
                    return [
                        ...acc,
                        {
                            id: (0,external_uuid_.v4)(),
                            displayName,
                            rule,
                        },
                    ];
                }, []),
            },
        });
        // Tags
        for (const tag in tagsIds) {
            commands.push({
                command: 'AddTag',
                payload: {
                    id: tagsIds[tag],
                    featureId: featureId,
                    displayName: tag,
                },
            });
        }
        // Tables (make sure to add it before any logic that can use "useField")
        for (const tableName in feature.tables) {
            const table = feature.tables[tableName];
            commands.push({
                command: 'AddTable',
                payload: {
                    id: tablesIds[tableName],
                    featureId: featureId,
                    displayName: tableName,
                    details: {},
                },
            });
            for (const constraint of table.constraints) {
                commands.push({
                    command: 'CreateTableIndex',
                    payload: {
                        tableId: tablesIds[tableName],
                        details: mapQueries(constraint.details),
                    },
                });
            }
        }
        // Fields
        for (const tableName in feature.tables) {
            const table = feature.tables[tableName];
            // Fields
            for (const fieldName in table.fields) {
                const field = table.fields[fieldName];
                const source = await devKit.getSourceFieldByName(field.type);
                if (field.type === 'relation') {
                    const references = field.details['references'];
                    const relatedEntity = references.payload.name;
                    const shortText = await devKit.getSourceFieldByName('short-text');
                    const relationIdSourceField = await devKit.getSourceFieldByName('relation-id');
                    const relationSourceField = await devKit.getSourceFieldByName('relation');
                    switch (field.details['relationship']) {
                        case 'many-to-one':
                            {
                                // Self table
                                {
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[fieldName],
                                            displayName: fieldName,
                                            tableId: tablesIds[tableName],
                                            sourceId: source.id,
                                            details: {
                                                ...mapQueries(field.details),
                                                ...{
                                                    nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName)),
                                                    relatedEntityName: relatedEntity,
                                                },
                                            },
                                        },
                                    });
                                }
                                {
                                    const relationIdFieldName = (0,external_stringcase_.camelcase)(`${external_pluralize_default().singular(fieldName)} Id`);
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[relationIdFieldName],
                                            displayName: relationIdFieldName,
                                            tableId: tablesIds[tableName],
                                            sourceId: shortText.id,
                                            details: {
                                                length: null,
                                            },
                                        },
                                    });
                                }
                                // Other table
                                {
                                    const relatedEntity = references.payload.name;
                                    const fieldNameOnTheOtherTable = (0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName));
                                    fieldsIds[fieldNameOnTheOtherTable] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[fieldNameOnTheOtherTable],
                                            displayName: fieldNameOnTheOtherTable,
                                            tableId: tablesIds[relatedEntity],
                                            sourceId: relationSourceField.id,
                                            details: {
                                                ...mapQueries(field.details),
                                                ...{
                                                    ignoreIfExist: true,
                                                    joinSide: false,
                                                    nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(fieldName),
                                                    relationship: 'one-to-many',
                                                    references: tablesIds[tableName],
                                                    // FIXME: relation field have TableName stored in them
                                                    relatedEntityName: tableName,
                                                },
                                            },
                                        },
                                    });
                                }
                                {
                                    const relationIdFieldName = `${(0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName))}Ids`;
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[relationIdFieldName],
                                            displayName: relationIdFieldName,
                                            tableId: tablesIds[relatedEntity],
                                            sourceId: relationIdSourceField.id,
                                            details: {
                                                ignoreIfExist: true,
                                                virtualRelationField: true,
                                                tableName: relatedEntity,
                                                columnNameOnSelfTable: external_pluralize_default().plural((0,external_stringcase_.camelcase)(tableName)),
                                                relationship: 'one-to-many',
                                                references: tablesIds[tableName],
                                            },
                                        },
                                    });
                                }
                            }
                            break;
                        case 'one-to-many':
                            {
                                // Self table
                                {
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[fieldName],
                                            displayName: fieldName,
                                            tableId: tablesIds[tableName],
                                            sourceId: source.id,
                                            details: {
                                                ...mapQueries(field.details),
                                                ...{
                                                    nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(external_pluralize_default().singular(tableName)),
                                                    relatedEntityName: relatedEntity,
                                                },
                                            },
                                        },
                                    });
                                }
                                {
                                    const relationIdFieldName = (0,external_stringcase_.camelcase)(`${external_pluralize_default().singular(fieldName)} Id`);
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[relationIdFieldName],
                                            displayName: relationIdFieldName,
                                            tableId: tablesIds[tableName],
                                            sourceId: shortText.id,
                                            details: {
                                                length: null,
                                            },
                                        },
                                    });
                                }
                                // Other table
                                {
                                    const relatedEntity = references.payload.name;
                                    const fieldNameOnTheOtherTable = (0,external_stringcase_.camelcase)(external_pluralize_default().plural(relatedEntity));
                                    fieldsIds[fieldNameOnTheOtherTable] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[fieldNameOnTheOtherTable],
                                            displayName: fieldNameOnTheOtherTable,
                                            tableId: tablesIds[relatedEntity],
                                            sourceId: relationSourceField.id,
                                            details: {
                                                ...mapQueries(field.details),
                                                ...{
                                                    joinSide: false,
                                                    nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(fieldName),
                                                    relationship: field.details['relationship'],
                                                    relatedEntityName: tableName,
                                                    references: tablesIds[tableName],
                                                },
                                            },
                                        },
                                    });
                                }
                                {
                                    const relationIdFieldName = `${(0,external_stringcase_.camelcase)(external_pluralize_default().singular(tableName))}Id`;
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    commands.push({
                                        command: 'AddField',
                                        payload: {
                                            id: fieldsIds[relationIdFieldName],
                                            displayName: relationIdFieldName,
                                            tableId: tablesIds[relatedEntity],
                                            sourceId: relationIdSourceField.id,
                                            details: {
                                                virtualRelationField: true,
                                                tableName: relatedEntity,
                                                columnNameOnSelfTable: external_pluralize_default().singular((0,external_stringcase_.camelcase)(tableName)),
                                                relationship: 'one-to-one',
                                                references: tablesIds[tableName],
                                            },
                                        },
                                    });
                                }
                            }
                            break;
                        default:
                            throw new Error(`Unimplemented relationship ${field.details['relationship']}`);
                    }
                }
                else {
                    commands.push({
                        command: 'AddField',
                        payload: {
                            id: fieldsIds[fieldName],
                            displayName: fieldName,
                            tableId: tablesIds[tableName],
                            sourceId: source.id,
                            details: mapQueries(field.details),
                        },
                    });
                }
            }
            // Validations
            for (const fieldName in table.fields) {
                const field = table.fields[fieldName];
                const source = await devKit.getSourceFieldByName(field.type);
                const fieldValidation = [];
                for (const validation of field.validations.flat()) {
                    const source = await devKit.getValidationByName(validation.name);
                    fieldValidation.push({
                        details: validation.details,
                        name: source.name,
                        sourceId: source.id,
                    });
                }
                for (const item of source.initialValidation) {
                    const sourceValidation = await devKit.getValidationByName(item.name);
                    const condition = item.if;
                    if (condition) {
                        const pass = applyCondition(condition, {
                            context: field.details, // inital validation is always run on the field it self
                            self: field.details,
                        });
                        if (!pass) {
                            continue;
                        }
                    }
                    const details = Object.keys(item.details).reduce((acc, key) => {
                        const value = item.details[key];
                        if (typeof value === 'string' && value.startsWith('context.')) {
                            const fieldMetadataProperty = value.replace('context.', '');
                            return {
                                ...acc,
                                [key]: field.details[fieldMetadataProperty],
                            };
                        }
                        return {
                            ...acc,
                            [key]: value,
                        };
                    }, {});
                    fieldValidation.push({
                        details: details,
                        sourceId: sourceValidation.id,
                        name: sourceValidation.name,
                    });
                }
                commands.push({
                    command: 'AdjustFieldValidation',
                    payload: {
                        fieldId: fieldsIds[fieldName],
                        tableId: tablesIds[tableName],
                        validations: uniquify(fieldValidation, (item) => item.name),
                    },
                });
            }
            // Relations
        }
        // Workflows
        for (const workflow of feature.workflows) {
            const trigger = await devKit.getTriggerByName(workflow.trigger.type);
            commands.push({
                command: 'AddWorkflow',
                payload: {
                    id: workflowIds[workflow.name],
                    featureId: featureId,
                    displayName: workflow.name,
                    sourceId: trigger.id,
                    details: mapQueries({
                        ...workflow.trigger.config,
                        policies: workflow.trigger.policies ?? [],
                        inputs: workflow.trigger.inputs ?? {},
                        imports: projectDefinition.imports.map((imp) => ({
                            kind: external_ts_morph_.StructureKind.ImportDeclaration,
                            isTypeOnly: imp.isTypeOnly,
                            moduleSpecifier: imp.moduleSpecifier,
                            namedImports: imp.namedImports,
                            defaultImport: imp.defaultImport,
                            namespaceImport: imp.namespaceImport,
                        })),
                    }),
                },
            });
            commands.push({
                command: 'AssignTagToWorkflow',
                payload: {
                    featureId: featureId,
                    workflowId: workflowIds[workflow.name],
                    tagId: tagsIds[workflow.tag],
                },
            });
        }
        // Actions
        for (const workflow of feature.workflows) {
            for (const actionName in workflow.actions) {
                const action = workflow.actions[actionName];
                if (typeof action === 'function') {
                    continue;
                }
                const source = await devKit.getSourceActionByName(action.type);
                commands.push({
                    command: 'AddActionToWorkflow',
                    payload: {
                        id: actionsIds[actionName],
                        featureId: featureId,
                        workflowId: workflowIds[workflow.name],
                        displayName: actionName,
                        details: {
                            ...mapQueries(action.config),
                            trigger: workflow.trigger.type,
                        },
                        sourceId: source.id,
                    },
                });
            }
        }
    }
    // TODO: some operations needs ids (insert-record columns)
    // do the details updates after the creation commands
    // so that we can reference the created entities
    return commands;
}
async function toChanges(projectDefinition) {
    const devKit = new DevKit();
    const tablesIds = {};
    const workflowIds = {};
    const fieldsIds = {};
    const actionsIds = {};
    const pathsIds = {};
    const policiesIds = {};
    projectDefinition.features.forEach((feature) => {
        Object.keys(feature.tables).forEach((tableName) => {
            tablesIds[tableName] = (0,external_uuid_.v4)();
            const table = feature.tables[tableName];
            Object.keys(table.fields).forEach((fieldName) => {
                fieldsIds[fieldName] = (0,external_uuid_.v4)();
            });
        });
        Object.keys(feature.policies ?? {}).forEach((policyName) => {
            policiesIds[policyName] = (0,external_uuid_.v4)();
        });
        feature.workflows.forEach((workflow) => {
            workflowIds[workflow.name] = (0,external_uuid_.v4)();
            Object.keys(workflow.actions).forEach((actionName) => {
                actionsIds[actionName] = (0,external_uuid_.v4)();
                const action = workflow.actions[actionName];
                if (typeof action === 'function') {
                    return;
                }
                if (action.type === 'branch') {
                    const config = action.config;
                    if (hasProperty(config, 'paths')) {
                        config.paths.forEach((path) => {
                            pathsIds[path.name] = path.id;
                        });
                    }
                }
            });
        });
    });
    function mapQueries(details) {
        if (typeof details === 'string' ||
            typeof details === 'number' ||
            typeof details === 'boolean') {
            return details;
        }
        if (isRequest(details)) {
            return mapQuery(details);
        }
        if (isNullOrUndefined(details)) {
            return details;
        }
        if (Array.isArray(details)) {
            return details.map(mapQueries);
        }
        return Object.entries(details).reduce((acc, [key, value]) => {
            return {
                ...acc,
                [key]: mapQueries(value),
            };
        }, {});
    }
    function mapQuery(value) {
        if (isRequest(value)) {
            let result = undefined;
            switch (value.command) {
                case 'QueryTable':
                    result = tablesIds[value.payload.name];
                    break;
                case 'QueryWorkflow':
                    result = workflowIds[value.payload.name];
                    break;
                case 'QueryFieldName':
                    for (const feature of projectDefinition.features) {
                        for (const table of Object.values(feature.tables)) {
                            if (table.fields[value.payload.name]) {
                                const field = table.fields[value.payload.name];
                                if (field.type === 'relation') {
                                    result = (0,external_stringcase_.camelcase)(value.payload.name + ' id');
                                }
                            }
                        }
                    }
                    result ??= value.payload.name;
                    break;
                case 'QueryField':
                    for (const feature of projectDefinition.features) {
                        for (const table of Object.values(feature.tables)) {
                            if (table.fields[value.payload.name]) {
                                const field = table.fields[value.payload.name];
                                if (field.type === 'relation') {
                                    result = fieldsIds[(0,external_stringcase_.camelcase)(value.payload.name + ' id')];
                                }
                            }
                        }
                    }
                    // in case of relation field not found, fallback to the field itself
                    result ??= fieldsIds[value.payload.name];
                    break;
                case 'QueryAction':
                    result = actionsIds[value.payload.name];
                    break;
                case 'QueryPath':
                    result = pathsIds[value.payload.name];
                    break;
                default:
                    throw new Error(`Unknown command ${value.command}`);
            }
            if (isNullOrUndefined(result)) {
                throw new Error(`Could not find ${value.command} ${value.payload.name}`);
            }
            return result;
        }
        return value;
    }
    const policies = [];
    const features = [];
    const tables = [];
    const workflows = [];
    for (const feature of projectDefinition.features) {
        const featureId = (0,external_uuid_.v4)();
        features.push({
            id: featureId,
            displayName: feature.name,
        });
        for (const [policyName, policy] of Object.entries(feature.policies ?? {})) {
            policies.push({
                id: policiesIds[policyName],
                rule: policy,
                displayName: policyName,
            });
        }
        for (const [tableName, table] of Object.entries(feature.tables)) {
            tables.push({
                id: tablesIds[tableName],
                featureId: featureId,
                displayName: tableName,
                fields: [],
                indexes: table.constraints.map((constraint) => mapQueries(constraint.details)),
            });
        }
        for (const [tableName, table] of Object.entries(feature.tables)) {
            for (const [fieldName, field] of Object.entries(table.fields)) {
                const source = await devKit.getSourceFieldByName(field.type);
                const fieldValidation = [];
                for (const item of source.initialValidation) {
                    const sourceValidation = await devKit.getValidationByName(item.name);
                    const condition = item.if;
                    if (condition) {
                        const pass = applyCondition(condition, {
                            context: field.details, // inital validation is always run on the field it self
                            self: field.details,
                        });
                        if (!pass) {
                            continue;
                        }
                    }
                    const details = Object.keys(item.details).reduce((acc, key) => {
                        const value = item.details[key];
                        if (typeof value === 'string' && value.startsWith('context.')) {
                            const fieldMetadataProperty = value.replace('context.', '');
                            return {
                                ...acc,
                                [key]: field.details[fieldMetadataProperty],
                            };
                        }
                        return {
                            ...acc,
                            [key]: value,
                        };
                    }, {});
                    fieldValidation.push({
                        details: details,
                        sourceId: sourceValidation.id,
                        name: sourceValidation.name,
                    });
                }
                for (const validation of field.validations.flat()) {
                    const source = await devKit.getValidationByName(validation.name);
                    fieldValidation.push({
                        details: validation.details,
                        name: source.name,
                        sourceId: source.id,
                    });
                }
                if (field.type === 'relation') {
                    const shortText = await devKit.getSourceFieldByName('short-text');
                    const references = field.details['references'];
                    const relatedEntity = references.payload.name;
                    const table = tables.find((it) => it.displayName === tableName);
                    const relatedTable = tables.find((it) => it.displayName === relatedEntity);
                    if (!table) {
                        throw new Error(`Table ${tableName} not found`);
                    }
                    if (!relatedTable) {
                        throw new Error(`Table ${relatedEntity} not found`);
                    }
                    const relationIdSourceField = await devKit.getSourceFieldByName('relation-id');
                    const relationSourceField = await devKit.getSourceFieldByName('relation');
                    switch (field.details['relationship']) {
                        case 'many-to-one':
                            {
                                // Self table
                                {
                                    table.fields.push({
                                        id: fieldsIds[fieldName],
                                        displayName: fieldName,
                                        tableId: tablesIds[tableName],
                                        sourceId: source.id,
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        details: devKit.assignDefaults(source.metadata, {
                                            ...mapQueries(field.details),
                                            ...{
                                                nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName)),
                                                relatedEntityName: relatedEntity,
                                            },
                                        }),
                                    });
                                }
                                {
                                    const relationIdFieldName = (0,external_stringcase_.camelcase)(`${external_pluralize_default().singular(fieldName)} Id`);
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    table.fields.push({
                                        id: fieldsIds[relationIdFieldName],
                                        displayName: relationIdFieldName,
                                        tableId: tablesIds[tableName],
                                        sourceId: shortText.id,
                                        details: devKit.assignDefaults(shortText.metadata, {
                                            length: null,
                                        }),
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                    });
                                }
                                // Other table
                                {
                                    const relatedEntity = references.payload.name;
                                    const fieldNameOnTheOtherTable = (0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName));
                                    fieldsIds[fieldNameOnTheOtherTable] ??= (0,external_uuid_.v4)();
                                    relatedTable.fields.push({
                                        id: fieldsIds[fieldNameOnTheOtherTable],
                                        displayName: fieldNameOnTheOtherTable,
                                        tableId: tablesIds[relatedEntity],
                                        sourceId: relationSourceField.id,
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        details: devKit.assignDefaults(relationSourceField.metadata, {
                                            ...mapQueries(field.details),
                                            ...{
                                                ignoreIfExist: true,
                                                joinSide: false,
                                                nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(fieldName),
                                                relationship: 'one-to-many',
                                                references: tablesIds[tableName],
                                                // FIXME: relation field have TableName stored in them
                                                relatedEntityName: tableName,
                                            },
                                        }),
                                    });
                                }
                                {
                                    const relationIdFieldName = `${(0,external_stringcase_.camelcase)(external_pluralize_default().plural(tableName))}Ids`;
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    relatedTable.fields.push({
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        id: fieldsIds[relationIdFieldName],
                                        displayName: relationIdFieldName,
                                        tableId: tablesIds[relatedEntity],
                                        sourceId: relationIdSourceField.id,
                                        details: devKit.assignDefaults(relationIdSourceField.metadata, {
                                            ignoreIfExist: true,
                                            virtualRelationField: true,
                                            tableName: relatedEntity,
                                            columnNameOnSelfTable: external_pluralize_default().plural((0,external_stringcase_.camelcase)(tableName)),
                                            relationship: 'one-to-many',
                                            references: tablesIds[tableName],
                                        }),
                                    });
                                }
                            }
                            break;
                        case 'one-to-one':
                            {
                                // Self table
                                {
                                    table.fields.push({
                                        id: fieldsIds[fieldName],
                                        displayName: fieldName,
                                        tableId: tablesIds[tableName],
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        sourceId: source.id,
                                        details: devKit.assignDefaults(source.metadata, {
                                            ...mapQueries(field.details),
                                            ...{
                                                nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(external_pluralize_default().singular(tableName)),
                                                relatedEntityName: relatedEntity,
                                            },
                                        }),
                                    });
                                }
                                {
                                    const relationIdFieldName = (0,external_stringcase_.camelcase)(`${external_pluralize_default().singular(fieldName)} Id`);
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    table.fields.push({
                                        id: fieldsIds[relationIdFieldName],
                                        displayName: relationIdFieldName,
                                        tableId: tablesIds[tableName],
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        sourceId: shortText.id,
                                        details: devKit.assignDefaults(shortText.metadata, {
                                            length: null,
                                        }),
                                    });
                                }
                                // Other table
                                {
                                    const relatedEntity = references.payload.name;
                                    const fieldNameOnTheOtherTable = (0,external_stringcase_.camelcase)(external_pluralize_default().plural(relatedEntity));
                                    fieldsIds[fieldNameOnTheOtherTable] ??= (0,external_uuid_.v4)();
                                    relatedTable.fields.push({
                                        id: fieldsIds[fieldNameOnTheOtherTable],
                                        displayName: fieldNameOnTheOtherTable,
                                        tableId: tablesIds[relatedEntity],
                                        sourceId: relationSourceField.id,
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        details: devKit.assignDefaults(relationSourceField.metadata, {
                                            ...mapQueries(field.details),
                                            ...{
                                                joinSide: false,
                                                nameOfColumnOnRelatedEntity: (0,external_stringcase_.camelcase)(fieldName),
                                                relationship: field.details['relationship'],
                                                relatedEntityName: tableName,
                                                references: tablesIds[tableName],
                                            },
                                        }),
                                    });
                                }
                                {
                                    const relationIdFieldName = `${(0,external_stringcase_.camelcase)(external_pluralize_default().singular(tableName))}Id`;
                                    fieldsIds[relationIdFieldName] ??= (0,external_uuid_.v4)();
                                    relatedTable.fields.push({
                                        id: fieldsIds[relationIdFieldName],
                                        displayName: relationIdFieldName,
                                        tableId: tablesIds[relatedEntity],
                                        sourceId: relationIdSourceField.id,
                                        validations: uniquify(fieldValidation, (item) => item.name),
                                        details: devKit.assignDefaults(relationIdSourceField.metadata, {
                                            virtualRelationField: true,
                                            tableName: relatedEntity,
                                            columnNameOnSelfTable: external_pluralize_default().singular((0,external_stringcase_.camelcase)(tableName)),
                                            relationship: 'one-to-one',
                                            references: tablesIds[tableName],
                                        }),
                                    });
                                }
                            }
                            break;
                        default:
                            throw new Error(`Unimplemented relationship ${field.details['relationship']}`);
                    }
                }
                else {
                    const table = tables.find((it) => it.displayName === tableName);
                    if (!table) {
                        throw new Error(`Table ${tableName} not found`);
                    }
                    table.fields.push({
                        id: fieldsIds[fieldName],
                        displayName: fieldName,
                        validations: uniquify(fieldValidation, (item) => item.name),
                        tableId: tablesIds[tableName],
                        sourceId: source.id,
                        details: mapQueries(field.details),
                    });
                }
            }
        }
        for (const workflow of feature.workflows) {
            const trigger = await devKit.getTriggerByName(workflow.trigger.type);
            const actions = [];
            for (const actionName in workflow.actions) {
                const action = workflow.actions[actionName];
                const source = await devKit.getSourceActionByName(action.type);
                actions.push({
                    id: actionsIds[actionName],
                    displayName: actionName,
                    details: {
                        ...mapQueries(action.config),
                        trigger: workflow.trigger.type,
                    },
                    outputName: '',
                    sourceId: source.id,
                });
            }
            workflows.push({
                id: workflowIds[workflow.name],
                featureId: featureId,
                displayName: workflow.name,
                actions: actions,
                output: {},
                tag: workflow.tag,
                details: {
                    sourceId: trigger.id,
                    details: mapQueries({
                        ...workflow.trigger.config,
                        inputs: workflow.trigger.inputs ?? {},
                        imports: projectDefinition.imports.map((imp) => ({
                            kind: external_ts_morph_.StructureKind.ImportDeclaration,
                            isTypeOnly: imp.isTypeOnly,
                            moduleSpecifier: imp.moduleSpecifier,
                            namedImports: imp.namedImports,
                            defaultImport: imp.defaultImport,
                            namespaceImport: imp.namespaceImport,
                        })),
                    }),
                },
                trigger: {
                    sourceId: trigger.id,
                    details: mapQueries({
                        ...workflow.trigger.config,
                        policies: workflow.trigger.policies,
                        inputs: workflow.trigger.inputs ?? {},
                        imports: projectDefinition.imports.map((imp) => ({
                            kind: external_ts_morph_.StructureKind.ImportDeclaration,
                            isTypeOnly: imp.isTypeOnly,
                            moduleSpecifier: imp.moduleSpecifier,
                            namedImports: imp.namedImports,
                            defaultImport: imp.defaultImport,
                            namespaceImport: imp.namespaceImport,
                        })),
                    }),
                },
            });
        }
    }
    return {
        createdAt: null,
        updatedAt: null,
        appVersion: null,
        prefix: null,
        id: (0,external_uuid_.v4)(),
        extensions: Object.entries(projectDefinition.extensions).map(([name, details]) => {
            const source = devKit.getExtensionByName(name);
            return {
                id: source.id,
                name,
                main: source.main,
                details: devKit.assignDefaults(source.metadata, details ?? {}),
            };
        }),
        policies,
        features,
        imports: projectDefinition.imports.map((imp) => imp.moduleSpecifier),
        tables,
        workflows,
    };
}
function isRequest(command) {
    if (isNullOrUndefined(command)) {
        return false;
    }
    if (Array.isArray(command)) {
        return false;
    }
    if (typeof command !== 'object') {
        return false;
    }
    return 'command' in command;
}

;// CONCATENATED MODULE: ../sdk/src/index.ts




;// CONCATENATED MODULE: ./src/lib/generator.ts











async function generate(code, extensions, repoPath) {
    const recorder = createRecorder({
        label: 'Generating',
    });
    const { definition, reports } = await evaluate(code);
    if (reports.length) {
        throw new Error(`\n` +
            reports
                .map((report) => {
                return Array.isArray(report.message)
                    ? report.message[0]
                    : typeof report.message === 'string'
                        ? report.message
                        : Object.values(report.message)[0];
            })
                .join('\n'));
    }
    const pd = current_Project('roadmap', {
        ...definition,
        modules: definition.features,
        extensions: extensions,
    });
    return external_tiny_injector_.Injector.CreateScope(async (context) => {
        const virtualFiles = external_tiny_injector_.Injector.GetRequiredService(VirtualFiles, context);
        const changes = await toChanges(pd);
        context.setExtra('changes', changes);
        recorder.record('getSourceCode');
        const { save, cleanup, files } = await virtualFiles.getSourceCode(changes, repoPath);
        recorder.recordEnd('getSourceCode');
        await save(async (file) => file.replaceWithText(await (0,format_code.formatCode)(file.getFullText(), (0,src.getExt)(file.getFilePath()), true)));
        await cleanup();
        if (!repoPath) {
            return files;
        }
        recorder.record('bundle');
        // use virtual bundling to avoid waiting for the save operation
        await bundle({
            projectRoot: repoPath,
            src: (0,external_path_.join)(repoPath, 'src', 'server.ts'),
            dist: (0,external_path_.join)(repoPath, 'build', 'server.js'),
        });
        recorder.recordEnd('bundle');
        recorder.end();
        return files;
    });
}


/***/ })

};
;
//# sourceMappingURL=1.js.map