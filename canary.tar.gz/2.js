#!/usr/bin/env node
"use strict";
exports.id = 2;
exports.ids = [2];
exports.modules = {

/***/ 36:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generate: () => (/* binding */ generate)
/* harmony export */ });
/* harmony import */ var _setup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var tiny_injector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2);
/* harmony import */ var tiny_injector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tiny_injector__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _faslh_compiler_sdk_devkit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
/* harmony import */ var _faslh_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6);
/* harmony import */ var _faslh_utils_formatter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23);
/* harmony import */ var _january_evaluator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14);
/* harmony import */ var _january_generator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18);
/* harmony import */ var _january_generator_bundler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19);
/* harmony import */ var _january_generator_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20);
/* harmony import */ var _january_sdk__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(24);











async function generate(code, extensions, repoPath) {
    const recorder = (0,_faslh_utils__WEBPACK_IMPORTED_MODULE_4__.createRecorder)({
        label: 'Generating',
    });
    const { definition, reports } = await (0,_january_evaluator__WEBPACK_IMPORTED_MODULE_5__.evaluate)(code);
    if (reports.length) {
        throw new Error(`\n` +
            reports
                .map((report) => {
                return Array.isArray(report.message)
                    ? report.message[0]
                    : typeof report.message === 'string'
                        ? report.message
                        : Object.values(report.message)[0];
            })
                .join('\n'));
    }
    const pd = {
        features: definition.features,
        extensions: extensions,
        imports: definition.imports ?? [],
    };
    return tiny_injector__WEBPACK_IMPORTED_MODULE_2__.Injector.CreateScope(async (context) => {
        const changes = await (0,_january_sdk__WEBPACK_IMPORTED_MODULE_8__.toChanges)(pd);
        context.setExtra('changes', changes);
        const virtualFiles = tiny_injector__WEBPACK_IMPORTED_MODULE_2__.Injector.GetRequiredService(_january_generator__WEBPACK_IMPORTED_MODULE_6__.VirtualFiles, context);
        const projectConfig = tiny_injector__WEBPACK_IMPORTED_MODULE_2__.Injector.GetRequiredService(_faslh_compiler_sdk_devkit__WEBPACK_IMPORTED_MODULE_3__.ProjectConfig, context);
        const vProject = tiny_injector__WEBPACK_IMPORTED_MODULE_2__.Injector.GetRequiredService(_january_generator__WEBPACK_IMPORTED_MODULE_6__.VirtualProject, context);
        const config = projectConfig.getConfig();
        projectConfig.updateConfig({
            basePath: (0,path__WEBPACK_IMPORTED_MODULE_1__.join)(repoPath, config.basePath),
            features: (0,path__WEBPACK_IMPORTED_MODULE_1__.join)(repoPath, config.features),
        });
        const concreteStructure = await virtualFiles.getSourceCode(changes);
        vProject.generate(concreteStructure, repoPath);
        const { save, cleanup, files } = {
            files: vProject.getOutput(),
            save: vProject.emit.bind(vProject),
            cleanup: () => vProject.cleanup(),
        };
        await save(async (file) => file.replaceWithText(await (0,_faslh_utils_formatter__WEBPACK_IMPORTED_MODULE_9__.formatCode)(file.getFullText(), (0,_january_generator_utils__WEBPACK_IMPORTED_MODULE_10__.getExt)(file.getFilePath()), true)));
        await cleanup();
        if (!repoPath) {
            return files;
        }
        recorder.record('bundle');
        // use virtual bundling to avoid waiting for the save operation
        await (0,_january_generator_bundler__WEBPACK_IMPORTED_MODULE_7__.bundle)({
            projectRoot: repoPath,
            entry: (0,path__WEBPACK_IMPORTED_MODULE_1__.join)(repoPath, 'src', 'server.ts'),
            out: (0,path__WEBPACK_IMPORTED_MODULE_1__.join)(repoPath, 'build', 'server.js'),
        });
        recorder.recordEnd('bundle');
        recorder.end();
        return files;
    });
}


/***/ })

};
;
//# sourceMappingURL=2.js.map