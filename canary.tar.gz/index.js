#!/usr/bin/env node
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("fs");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("fs/promises");

/***/ }),
/* 3 */
/***/ ((module) => {

module.exports = require("path");

/***/ }),
/* 4 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Arg: () => (/* reexport */ Arg),
  AsyncVisitor: () => (/* reexport */ AsyncVisitor),
  Binary: () => (/* reexport */ Binary),
  Call: () => (/* reexport */ Call),
  Expression: () => (/* reexport */ Expression),
  Identifier: () => (/* reexport */ Identifier),
  Namespace: () => (/* reexport */ Namespace),
  NamespaceParser: () => (/* reexport */ NamespaceParser),
  ParserTokens: () => (/* reexport */ ParserTokens),
  PromptParser: () => (/* reexport */ PromptParser),
  PropertyAccess: () => (/* reexport */ PropertyAccess),
  SqliteVisitor: () => (/* reexport */ SqliteVisitor),
  StringAsyncVisitor: () => (/* reexport */ StringAsyncVisitor),
  StringLiteral: () => (/* reexport */ StringLiteral),
  StringVisitor: () => (/* reexport */ StringVisitor),
  Visitor: () => (/* reexport */ Visitor),
  addLeadingSlash: () => (/* reexport */ addLeadingSlash),
  applyCondition: () => (/* reexport */ applyCondition),
  assertNotNullOrUndefined: () => (/* reexport */ assertNotNullOrUndefined),
  buildUrl: () => (/* reexport */ buildUrl),
  byId: () => (/* reexport */ byId),
  camelcase: () => (/* reexport */ external_stringcase_.camelcase),
  cramcase: () => (/* reexport */ external_stringcase_.cramcase),
  createRecorder: () => (/* reexport */ createRecorder),
  decomposeVisitor: () => (/* reexport */ decomposeVisitor),
  dotcase: () => (/* reexport */ external_stringcase_.dotcase),
  extractError: () => (/* reexport */ extractError),
  hasProperty: () => (/* reexport */ hasProperty),
  isCondition: () => (/* reexport */ isCondition),
  isNullOrUndefined: () => (/* reexport */ isNullOrUndefined),
  isResolvable: () => (/* reexport */ isResolvable),
  logMe: () => (/* reexport */ logMe),
  normalizeWorkflowPath: () => (/* reexport */ normalizeWorkflowPath),
  notNullOrUndefined: () => (/* reexport */ notNullOrUndefined),
  orThrow: () => (/* reexport */ orThrow),
  parseDetails: () => (/* reexport */ parseDetails),
  parseDsl: () => (/* reexport */ parseDsl),
  parseInput: () => (/* reexport */ parseInput),
  partition: () => (/* reexport */ partition),
  pascalcase: () => (/* reexport */ external_stringcase_.pascalcase),
  profile: () => (/* reexport */ profile),
  removeDuplicates: () => (/* reexport */ removeDuplicates),
  removeTrialingSlash: () => (/* reexport */ removeTrialingSlash),
  reportException: () => (/* reexport */ reportException),
  resolveContextKey: () => (/* reexport */ resolveContextKey),
  retryPromise: () => (/* reexport */ retryPromise),
  runWorker: () => (/* reexport */ runWorker),
  safeFail: () => (/* reexport */ safeFail),
  scan: () => (/* reexport */ scan),
  sentencecase: () => (/* reexport */ external_stringcase_.sentencecase),
  sleep: () => (/* reexport */ sleep),
  snakecase: () => (/* reexport */ external_stringcase_.snakecase),
  spinalcase: () => (/* reexport */ external_stringcase_.spinalcase),
  titlecase: () => (/* reexport */ external_stringcase_.titlecase),
  toLiteralObject: () => (/* reexport */ toLiteralObject),
  toRecord: () => (/* reexport */ toRecord),
  toSimple: () => (/* reexport */ toSimple),
  toSqlite: () => (/* reexport */ toSqlite),
  toTypeorm: () => (/* reexport */ toTypeorm),
  tokenisePrompt: () => (/* reexport */ tokenisePrompt),
  typeChecker: () => (/* reexport */ typeChecker),
  uniquify: () => (/* reexport */ uniquify),
  upsert: () => (/* reexport */ upsert),
  upsertAsync: () => (/* reexport */ upsertAsync)
});

// EXTERNAL MODULE: external "stringcase"
var external_stringcase_ = __webpack_require__(5);
;// CONCATENATED MODULE: ../utils/src/lib/issue-tracker.ts
function reportException(title, error) {
    let data = error;
    const production = process.env['NODE_ENV'] === 'production';
    if ('toJSON' in error) {
        data = error.toJSON();
    }
    else if ('message' in error) {
        data = error.message + '\n' + error.stack;
    }
    if (!production) {
        return Promise.resolve();
    }
    const webhookURL = 'https://chat.googleapis.com/v1/spaces/AAAALeS7bIE/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=ha36EtuZyTeZaVLMvIvnX2V3mZd6OSYckpx6BI0kZug%3D';
    return fetch(webhookURL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({
            title,
            data,
        }),
    });
}

// EXTERNAL MODULE: external "uuid"
var external_uuid_ = __webpack_require__(6);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(7);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(3);
;// CONCATENATED MODULE: external "retry"
const external_retry_namespaceObject = require("retry");
var external_retry_default = /*#__PURE__*/__webpack_require__.n(external_retry_namespaceObject);
;// CONCATENATED MODULE: ../utils/src/lib/utils.ts




function orThrow(fn, message) {
    const result = fn();
    if ([undefined, null].includes(result)) {
        const error = new Error(message);
        Error.captureStackTrace(error, orThrow);
        throw error;
    }
    return result;
}
function isNullOrUndefined(value) {
    return value === undefined || value === null;
}
function notNullOrUndefined(value) {
    return !isNullOrUndefined(value);
}
function upsert(array, id, insert) {
    const [index, item] = byId(array, id);
    if (item) {
        array[index] = insert(item, false);
        return array;
    }
    else {
        return [...array, insert({ id }, true)];
    }
}
async function upsertAsync(array, id, insert) {
    const [index, item] = byId(array, id);
    if (item) {
        array[index] = await insert(item);
        return array;
    }
    else {
        return [...array, await insert({ id })];
    }
}
function byId(array, id) {
    const index = array.findIndex((it) => it.id === id);
    return [index, array[index]];
}
const removeEmpty = (obj) => {
    const newObj = {};
    Object.keys(obj).forEach((key) => {
        if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
            newObj[key] = removeEmpty(obj[key]);
        else if (obj[key] !== undefined)
            newObj[key] = obj[key];
    });
    return newObj;
};
function assertNotNullOrUndefined(value, debugLabel) {
    if (value === null || value === undefined) {
        throw new Error(`${debugLabel} is undefined or null.`);
    }
}
async function profile({ label, seconds = false, }, fn) {
    const startTime = performance.now();
    try {
        return await fn(); // Await the function if it's a promise
    }
    finally {
        const endTime = performance.now();
        const time = endTime - startTime;
        const formattedTime = seconds ? (time / 1000).toFixed(6) : time.toFixed(6);
        const timeUnit = seconds ? 'seconds' : 'milliseconds';
        console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
    }
}
const colors = {
    green: (message) => `\x1b[32m${message}\x1b[0m`,
    blue: (message) => `\x1b[34m${message}\x1b[0m`,
    magenta: (message) => `\x1b[35m${message}\x1b[0m`,
};
function createRecorder(options = { seconds: false }) {
    const startedAt = performance.now();
    function log(...args) {
        if (!process.env['RECORD_OFF']) {
            console.log(...args);
        }
    }
    log(colors.green(`Recording started => [${options.label}]`));
    const operations = new Map();
    return {
        record: (label) => {
            operations.set(label, performance.now());
            if (options.verbose) {
                log(colors.blue(`Recording => [${options.label ? `${options.label} => ` : ''}${label}]
        `));
            }
        },
        recordEnd: (label, result) => {
            const endTime = performance.now();
            const time = endTime - operations.get(label);
            const formattedTime = options.seconds
                ? (time / 1000).toFixed(6)
                : time.toFixed(6);
            const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
            log(colors.blue(`Execution time => [${options.label ? `${options.label} => ` : ''}${label}]: ${formattedTime} ${timeUnit}`), ...[result].filter((item) => typeof item !== 'undefined'));
            operations.delete(label);
        },
        end: () => {
            const endTime = performance.now();
            const time = endTime - startedAt;
            const lastEntry = Array.from(operations.entries()).at(-1);
            if (lastEntry) {
                // log missing end
                const [label, start] = lastEntry;
                const time = performance.now() - start;
                const formattedTime = options.seconds
                    ? (time / 1000).toFixed(6)
                    : time.toFixed(6);
                const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
                log(colors.magenta(`Recording Total time => [${options.label ? `${options.label} => ` : ''}${label}]: ${formattedTime} ${timeUnit}`));
                operations.delete(label);
            }
            const formattedTime = options.seconds
                ? (time / 1000).toFixed(6)
                : time.toFixed(6);
            const timeUnit = options.seconds ? 'seconds' : 'milliseconds';
            log(colors.magenta(`Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`));
        },
    };
}
function applyCondition(condition, context) {
    const input = resolveContextKey(condition.input, context);
    switch (condition.operator) {
        case 'equal':
            return input === condition.value ? condition.then : condition.else;
        case 'not_equal':
            return input !== condition.value ? condition.then : condition.else;
        default:
            throw new Error(`Unknown operator ${condition.operator}`);
    }
}
function resolveContextKey(key, details) {
    const [source, path] = key.split('.');
    if (source === 'self') {
        return (0,external_lodash_.get)(details.self, path);
    }
    else if (source === 'context') {
        return (0,external_lodash_.get)(details.context, path);
    }
    return key;
}
function buildUrl(url, details, binding) {
    {
        const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(':'));
        // no variables in url
        if (!variables.length || !details) {
            return { url, params: [] };
        }
        const params = variables.reduce((acc, variable) => {
            const key = variable.slice(1);
            return {
                ...acc,
                [key]: resolveContextKey(binding[key], details),
            };
        }, {});
        return {
            url: url,
            params: Object.values(params),
        };
    }
}
function isResolvable(maybeResolvable) {
    if (!maybeResolvable) {
        return false;
    }
    if (Array.isArray(maybeResolvable)) {
        return true;
    }
    if (maybeResolvable.url) {
        return true;
    }
    return false;
}
function isCondition(obj) {
    if (!obj || typeof obj === 'string' || Array.isArray(obj))
        return false;
    if ('input' in obj && 'operator' in obj && 'value' in obj) {
        return true;
    }
    return false;
}
function parseDetails(details, path) {
    const parsed = JSON.parse(details ?? '{}');
    return path ? (0,external_lodash_.get)(parsed, path, {}) : parsed;
}
const logMe = (object) => console.dir(object, {
    showHidden: false,
    depth: Infinity,
    maxArrayLength: Infinity,
    colors: true,
});
function toLiteralObject(obj, accessor = (value) => value) {
    return `{${Object.keys(obj)
        .map((key) => `${key}: ${accessor(obj[key])}`)
        .join(', ')}}`;
}
function addLeadingSlash(path) {
    return (0,external_path_.normalize)((0,external_path_.join)('/', path));
}
function removeTrialingSlash(path) {
    return path.replace(/\/$/, '');
}
function retryPromise(promise) {
    return new Promise((resolve, reject) => {
        const operation = external_retry_default().operation({
            factor: 2,
            randomize: true,
            minTimeout: 1000,
            maxTimeout: 2000,
        });
        operation.attempt(async (currentAttempt) => {
            try {
                const result = await promise();
                resolve(result);
            }
            catch (error) {
                if (!operation.retry(error)) {
                    reject(error);
                }
            }
        });
    });
}
function uniquify(data, accessor) {
    return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
function toRecord(array, config) {
    return array.reduce((acc, item) => {
        return {
            ...acc,
            [config.accessor(item)]: config.map(item),
        };
    }, {});
}
function hasProperty(obj, key) {
    if (typeof obj !== 'object') {
        return false;
    }
    return key in obj;
}
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
function safeFail(fn, defaultValue) {
    try {
        return fn();
    }
    catch (error) {
        return defaultValue;
    }
}
async function extractError(fn) {
    try {
        return {
            value: await fn(),
            error: undefined,
        };
    }
    catch (error) {
        return { error };
    }
}
function toCurlyBraces(path) {
    return path
        .replace(':', '$:')
        .split('$')
        .map((it) => {
        if (!it.startsWith(':')) {
            return it.split('/').filter(Boolean).join('/');
        }
        const [param, ...rest] = it.split('/');
        return [`{${param.slice(1)}}`, ...rest].join('/');
    })
        .join('/');
}
function normalizeWorkflowPath(config) {
    const path = removeTrialingSlash(addLeadingSlash((0,external_path_.join)((0,external_stringcase_.spinalcase)(config.featureName), (0,external_stringcase_.snakecase)(config.workflowTag), toCurlyBraces(config.workflowPath))));
    return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
const pool = {};
function runWorker(publicPath, message, options = {
    type: 'module',
    terminateImmediately: false,
}) {
    let worker;
    if (options.terminateImmediately) {
        worker = new Worker(publicPath, options);
    }
    else {
        worker = pool[publicPath] ??= new Worker(publicPath, options);
    }
    // const worker =
    //   process.env['NODE_ENV'] === 'development'
    //     ? new Worker(publicPath, options)
    //     : pool[publicPath];
    const defer = new Promise((resolve, reject) => {
        worker.onmessage = (e) => {
            if (options.terminateImmediately) {
                worker.terminate();
            }
            if ('error' in e.data) {
                reject(e.data.error);
                console.error(e.data.error);
            }
            else {
                resolve(e.data.data);
            }
        };
        worker.onerror = (e) => {
            if (options.terminateImmediately) {
                worker.terminate();
            }
            reject(e.error);
        };
    });
    worker.postMessage(message);
    return defer;
}
function removeDuplicates(data, accessor) {
    return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
function scan(array, accumulator) {
    const scanned = [];
    for (let i = 0; i < array.length; i++) {
        const element = array[i];
        const acc = [];
        for (let j = i - 1; j >= 0; j--) {
            acc.unshift(array[j]);
        }
        scanned.push(accumulator(element, acc));
    }
    return scanned;
}
function partition(array, ...predicates) {
    const result = Array.from({ length: predicates.length + 1 }, () => []);
    for (const item of array) {
        let found = false;
        for (let i = 0; i < predicates.length; i++) {
            const fn = predicates[i];
            if (fn(item)) {
                result[i].push(item);
                found = true;
            }
        }
        if (!found) {
            // no predicate matched, push to the non-matched array
            result.at(-1).push(item);
        }
    }
    return result;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/token.ts
class Expression {
    parent;
}
class Arg extends Expression {
    name;
    value;
    type = 'arg';
    constructor(name, value) {
        super();
        this.name = name;
        this.value = value;
        this.name.parent = this;
        this.value.parent = this;
    }
    accept(visitor) {
        return visitor.visitArg(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
    }
}
class Call extends Expression {
    name;
    args;
    type = 'call';
    constructor(name, args = []) {
        super();
        this.name = name;
        this.args = args;
        this.name.parent = this;
        this.args.forEach((arg) => (arg.parent = this));
    }
    accept(visitor) {
        return visitor.visitCall(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}(${this.args
            .map((arg) => arg.toLiteral(visitor))
            .join(', ')})`;
    }
}
class PropertyAccess extends Expression {
    name;
    expression;
    type = 'propertyAccess';
    constructor(name, expression) {
        super();
        this.name = name;
        this.expression = expression;
        this.name.parent = this;
        this.expression.parent = this;
    }
    accept(visitor) {
        return visitor.visitPropertyAccess(this);
    }
    toLiteral(visitor) {
        return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(visitor)}`;
    }
}
class Binary extends Expression {
    operator;
    left;
    right;
    type = 'propertyAccess';
    constructor(operator, left, right) {
        super();
        this.operator = operator;
        this.left = left;
        this.right = right;
        this.operator.parent = this;
        this.left.parent = this;
        this.right.parent = this;
    }
    accept(visitor) {
        return visitor.visitBinary(this);
    }
    toLiteral(visitor) {
        return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(visitor)} ${this.right.toLiteral(visitor)}`;
    }
}
class Namespace extends Expression {
    name;
    expression;
    type = 'namespace';
    constructor(name, expression) {
        super();
        this.name = name;
        this.expression = expression;
        this.name.parent = this;
        this.expression.parent = this;
    }
    accept(visitor) {
        return visitor.visitNamespace(this);
    }
    toLiteral(visitor) {
        return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
    }
}
class Identifier extends Expression {
    value;
    type = 'identifier';
    constructor(value) {
        super();
        this.value = value;
    }
    accept(visitor) {
        return visitor.visitIdentifier(this);
    }
    toLiteral(visitor) {
        return this.value;
    }
}
class StringLiteral extends Expression {
    value;
    type = 'string';
    constructor(value) {
        super();
        this.value = value;
    }
    accept(visitor) {
        return visitor.visitStringLiteral(this);
    }
    toLiteral(visitor) {
        return `'${this.value}'`;
    }
}
const typeChecker = {
    isCall(expression) {
        return expression.type === 'call';
    },
    isNamespace(expression) {
        return expression.type === 'namespace';
    },
    isPropertyAccess(expression) {
        return expression.type === 'propertyAccess';
    },
    isIdentifier(expression) {
        return expression.type === 'identifier';
    },
};
class Visitor {
}
class AsyncVisitor {
}
class StringVisitor extends Visitor {
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
class StringAsyncVisitor extends AsyncVisitor {
    async visitIdentifier(node) {
        return node.value;
    }
    async visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/sqlite.visitor.ts



class SqliteVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        const where = node.args.map((arg) => arg.accept(this)).join(', ');
        return `${node.name.accept(this)} WHERE id = ${where}`;
    }
    visitNamespace(node) {
        if (node.name.value === 'tables') {
            return `SELECT ${node.expression.accept(this)}`;
        }
        return `'${node.toLiteral(this)}'`;
    }
    visitPropertyAccess(node) {
        return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toSqlite(input) {
    const visitor = new SqliteVisitor();
    return visitor.visit(parseDsl(input));
}
class TypeormVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        const where = node.args.reduce((acc, current) => {
            return {
                ...acc,
                // static to id till we support multiple args
                id: current.accept(this),
            };
        }, {});
        const tableName = node.name.accept(this);
        return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLiteralObject(where, (value) => value)})`;
    }
    visitPropertyAccess(node) {
        return `.select('${node.expression.accept(this)}')${node.name.accept(this)}`;
    }
    visitNamespace(node) {
        if (node.name.value === 'tables') {
            return `qb${node.expression.accept(this)}`;
        }
        return `'${node.toLiteral(this)}'`;
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toTypeorm(input) {
    const visitor = new TypeormVisitor();
    return visitor.visit(parseDsl(input));
}
class SimpleVisitor extends Visitor {
    visitArg(node) {
        throw new Error('Method not implemented.');
    }
    visitBinary(propertyAccess) {
        throw new Error('Method not implemented.');
    }
    visitCall(node) {
        return node.toLiteral(this);
    }
    visitPropertyAccess(node) {
        return node.toLiteral(this);
    }
    visitNamespace(node) {
        return {
            namespace: node.name.value,
            value: node.expression.accept(this),
        };
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        return node.accept(this);
    }
}
function toSimple(input) {
    const visitor = new SimpleVisitor();
    return visitor.visit(parseDsl(input));
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
    let index = 0;
    const tokens = [];
    let lexeme = '';
    while (index < input.length) {
        const char = input[index];
        switch (char) {
            case '=':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'EQUALS',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case '!':
                if (input[index + 1] === '=') {
                    if (lexeme) {
                        tokens.push({
                            type: 'IDENTIFIER',
                            value: lexeme,
                            column: index,
                        });
                        lexeme = '';
                    }
                    tokens.push({
                        type: 'NOT_EQUALS',
                        value: '!=',
                        column: index,
                    });
                    index += 2;
                }
                else {
                    lexeme += char;
                    index++;
                }
                break;
            case '.':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'DOT',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ',':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'COMMA',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case '@':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                tokens.push({
                    type: 'AT',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ':':
                tokens.push({
                    type: 'IDENTIFIER',
                    value: lexeme,
                    column: index,
                });
                lexeme = '';
                tokens.push({
                    type: 'COLON',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case "'":
            case '"':
                {
                    index++;
                    while (input[index] !== "'" && input[index] !== '"') {
                        lexeme += input[index];
                        index++;
                    }
                    index++;
                    const column = index;
                    if (input[index] === ']') {
                        lexeme += input[index];
                        index++;
                    }
                    tokens.push({
                        type: 'STRING',
                        value: lexeme,
                        column: column,
                    });
                    lexeme = '';
                }
                break;
            case '(':
                tokens.push({
                    type: 'IDENTIFIER',
                    value: lexeme,
                    column: index,
                });
                lexeme = '';
                tokens.push({
                    type: 'OPEN_PAREN',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ')':
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                lexeme = '';
                tokens.push({
                    type: 'CLOSE_PAREN',
                    value: char,
                    column: index,
                });
                index++;
                break;
            case ' ':
            case '\r':
            case '\t':
                // Ignore whitespace.
                if (lexeme) {
                    tokens.push({
                        type: 'IDENTIFIER',
                        value: lexeme,
                        column: index,
                    });
                    lexeme = '';
                }
                index++;
                break;
            default:
                // assume string
                lexeme += char;
                index++;
                break;
        }
    }
    if (lexeme)
        tokens.push({ type: 'IDENTIFIER', value: lexeme });
    tokens.push({ type: 'EOF', value: '' });
    return tokens;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/input-parser.ts



const grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
    return toSimple(input);
}
class ParserTokens {
    currentIdx = 0;
    tokens = [];
    constructor(tokens) {
        this.tokens = tokens;
    }
    get peek() {
        return this.tokens[this.currentIdx];
    }
    get lookahead() {
        return this.tokens[this.currentIdx + 1];
    }
    get lookbehind() {
        return this.tokens[this.currentIdx - 1];
    }
    isAtEnd() {
        return this.check('EOF');
    }
    match(...types) {
        if (this.isAtEnd())
            return false;
        if (this.check(...types)) {
            this.advance();
            return true;
        }
        return false;
    }
    consume(type, message) {
        if (this.check(type)) {
            return this.advance();
        }
        const error = new Error(`${message} at ${this.currentIdx} Found ${this.peek.type}`);
        Error.captureStackTrace(error, this.consume);
        throw error;
    }
    check(...tokens) {
        return tokens.includes(this.peek.type);
    }
    advance() {
        return this.tokens[++this.currentIdx];
    }
    retreat() {
        return this.tokens[--this.currentIdx];
    }
    reset() {
        this.currentIdx = 0;
    }
    slice() {
        return this.tokens.slice(this.currentIdx);
    }
}
class DSLParser extends ParserTokens {
    input;
    constructor(input) {
        super(tokeniser(input));
        this.input = input;
    }
    subparsing(parserType) {
        const parser = new parserType(this.slice());
        const { expression, index } = parser.subparse();
        this.currentIdx += index;
        return expression;
    }
    #equal() {
        const expression = this.subparsing(NamespaceParser);
        if (this.match('EQUALS') || this.match('NOT_EQUALS')) {
            const operator = new Identifier(this.lookbehind.value);
            const right = this.#expression();
            return new Binary(operator, expression, right);
        }
        return expression;
    }
    #expression() {
        const expression = this.#equal();
        return expression;
    }
    parse() {
        const result = this.#expression();
        this.consume('EOF', 'Expecting EOF');
        this.reset();
        return result;
    }
}
function parseDsl(input) {
    const parser = new DSLParser(input);
    return parser.parse();
}
class NamespaceParser extends ParserTokens {
    #primary() {
        if (this.match('STRING')) {
            return new StringLiteral(this.lookbehind.value);
        }
        if (this.match('IDENTIFIER')) {
            return new Identifier(this.lookbehind.value);
        }
        if (this.match('AT')) {
            // const namespace = this.#primary() as Identifier;
            const namespace = new Identifier(this.peek.value);
            this.consume('IDENTIFIER', 'Expecting identifier');
            this.consume('COLON', 'Expecting :');
            return new Namespace(namespace, this.#expression());
        }
        const token = this.peek;
        const error = new Error(`Unexpected token ${token.value}`);
        // Error.captureStackTrace(error, this.#primary);
        throw error;
    }
    #call() {
        // FIXME: throw error if function is not an identifier
        const expression = this.#primary();
        if (this.match('OPEN_PAREN')) {
            const args = [];
            do {
                const name = this.#primary();
                this.consume('COLON', 'Expecting :');
                const value = this.#expression();
                args.push(new Arg(name, value));
            } while (this.match('COMMA'));
            this.consume('CLOSE_PAREN', 'Expecting )');
            return new Call(expression, args);
        }
        return expression;
    }
    #propertyAccess() {
        let expression = this.#call();
        while (this.match('DOT')) {
            const primary = this.#primary();
            expression = new PropertyAccess(expression, primary);
        }
        return expression;
    }
    #expression() {
        const expression = this.#propertyAccess();
        return expression;
    }
    subparse() {
        // this.consume('AT', 'Expecting @');
        const result = this.#expression();
        return {
            expression: result,
            index: this.currentIdx,
        };
    }
    parse() {
        // this.consume('AT', 'Expecting @');
        const result = this.#expression();
        this.consume('EOF', 'Expecting EOF');
        this.reset();
        return result;
    }
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/prompt-parser.ts

class PromptParser {
    prompt;
    tokens = [];
    objectives = ['extension', 'table', 'feature', 'workflow'];
    constructor(prompt) {
        this.prompt = prompt;
        this.tokens = tokeniser(this.prompt);
    }
    firstObjective() {
        const idx = this.tokens.findIndex((token, index) => {
            if (token.type === 'AT') {
                const nextToken = this.tokens[index + 1];
                if (nextToken && this.objectives.includes(nextToken.value)) {
                    return true;
                }
            }
            return false;
        });
        const objectiveTokens = [];
        for (let i = idx; i < this.tokens.length; i++) {
            objectiveTokens.push(this.tokens[i]);
            if (this.tokens[i].type === 'STRING')
                break;
        }
        if (objectiveTokens.length === 0) {
            throw new Error(`No namespace found in prompt: ${this.prompt}`);
        }
        const guessComplete = objectiveTokens.some((obj) => obj.type == 'COLON');
        if (!guessComplete) {
            throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
        }
        return {
            name: objectiveTokens[1].value,
            value: objectiveTokens.at(-1).value,
        };
    }
    stripObjective() {
        const start = this.tokens.findIndex((token, index) => {
            if (token.type === 'AT') {
                const nextToken = this.tokens[index + 1];
                if (nextToken && this.objectives.includes(nextToken.value)) {
                    return true;
                }
            }
            return false;
        });
        const end = this.tokens
            .slice(start)
            .findIndex((token) => token.type === 'STRING');
        const toks = [...this.tokens];
        toks.splice(start, end + 1);
        return toks.map((token) => token.value).join('');
    }
    nearestLexeme(index) {
        const lexeme = this.tokens.findLast((token) => {
            return token.column < index;
        });
        return lexeme;
    }
    replaceLexeme(index, value) {
        const lexeme = this.nearestLexeme(index);
        console.log({ lexeme, index });
        if (lexeme) {
            lexeme.value = value;
        }
        return this;
    }
    format() {
        return this.tokens.map((token) => token.value).join('');
    }
}
function tokenisePrompt(prompt) {
    // prompt: "install @extension:postgresql and set connection string to @process.env:CONNECTION_STRING"
    let index = 0;
    const lexemes = [];
    while (index < prompt.length) {
        const char = prompt[index];
        switch (char) {
            case '@':
                lexemes.push({
                    type: 'IDENTIFIER',
                    value: prompt[index++],
                    column: index,
                });
                break;
            case ' ':
                lexemes.push({
                    type: 'WHITESPACE',
                    value: prompt[index++],
                    column: index,
                });
                break;
            default:
                {
                    const token = lexemes.at(-1) ?? {
                        type: 'IDENTIFIER',
                        value: '',
                        column: index,
                    };
                    token.value += char;
                    index++;
                    lexemes[lexemes.length - 1] = token;
                }
                break;
        }
    }
    return lexemes;
}

;// CONCATENATED MODULE: ../utils/src/lib/parser/index.ts
// @subject:user.id = @tables:posts(@trigger:path.id).userId







class RuleDecomposerVisitor extends Visitor {
    visitArg(node) {
        const name = node.name.accept(this);
        if (typeChecker.isNamespace(node.value)) {
            const value = node.value.accept(this);
            return `${name}: ${value.id}`;
        }
        const value = node.value.accept(this);
        return `${name}: ${value.id}`;
    }
    namespaces = {};
    visitBinary(node) {
        const left = node.left.accept(this);
        const right = node.right.accept(this);
    }
    visitCall(node) {
        const name = node.name.accept(this);
        const args = node.args.map((arg) => {
            return arg.accept(this);
        });
        return `${name}(${args.join(', ')})`;
    }
    visitPropertyAccess(node) {
        return `${node.name.accept(this)}.${node.expression.accept(this)}`;
    }
    visitNamespace(node) {
        const id = (0,external_uuid_.v4)();
        const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
        this.namespaces = {
            ...this.namespaces,
            [id]: name,
        };
        return { id, name };
    }
    visitIdentifier(node) {
        return node.value;
    }
    visitStringLiteral(node) {
        return `'${node.value}'`;
    }
    visit(node) {
        node.accept(this);
        return this.namespaces;
    }
}
function decomposeVisitor(input) {
    const visitor = new RuleDecomposerVisitor();
    return visitor.visit(parseDsl(input));
}

;// CONCATENATED MODULE: ../utils/src/index.ts







/***/ }),
/* 5 */
/***/ ((module) => {

module.exports = require("stringcase");

/***/ }),
/* 6 */
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),
/* 7 */
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   emptyFile: () => (/* binding */ emptyFile),
/* harmony export */   getExt: () => (/* binding */ getExt),
/* harmony export */   getFile: () => (/* binding */ getFile),
/* harmony export */   mapFilesToTree: () => (/* binding */ mapFilesToTree),
/* harmony export */   mapFilesToTreeNodes: () => (/* binding */ mapFilesToTreeNodes),
/* harmony export */   toVirtualFile: () => (/* binding */ toVirtualFile)
/* harmony export */ });
const getExt = (fileName) => {
    if (!fileName) {
        return ''; // shouldn't happen as there will always be a file name
    }
    const ext = fileName.split('.').pop();
    if (ext === fileName) {
        // files that have no extension
        return '';
    }
    return ext || 'txt';
};
function toVirtualFile(it) {
    const parts = it.path.split('/').filter(Boolean);
    const fileName = parts.at(-1);
    return {
        isFolder: false,
        name: it.path.split('/').pop() || 'unknown',
        path: parts.join('/'),
        extension: getExt(fileName),
        content: it.content,
        metadata: {
            path: it.path,
        },
    };
}
function mapFilesToTree(files) {
    function toTree(parts, tree, content) {
        const [part, ...rest] = parts;
        if (rest.length === 0) {
            return {
                ...tree,
                [part]: content,
            };
        }
        return {
            ...tree,
            [part]: toTree(rest, tree[part] || {}, content),
        };
    }
    return files.reduce((acc, it) => {
        const parts = it.path.split('/').filter(Boolean); // ignore starting and ending slash and dobule slashes
        return toTree(parts, acc, it.content);
    }, {});
}
function mapFilesToTreeNodes(files) {
    const tree = mapFilesToTree(files);
    function toTreeNodes(tree, path = []) {
        return Object.entries(tree)
            .map(([name, value]) => {
            const newPath = [...path, name];
            if (typeof value === 'string') {
                return {
                    id: newPath.join('/'),
                    name,
                    path: newPath.join('/'),
                    metadata: {
                        path: newPath.join('/'),
                    },
                };
            }
            return {
                id: newPath.join('/'),
                name,
                children: toTreeNodes(value, newPath),
                metadata: {
                    path: newPath.join('/'),
                },
            };
        })
            .sort((a, b) => ('children' in a ? -1 : 1));
    }
    return toTreeNodes(tree);
}
function getFile(list, path) {
    const file = list.find((it) => JSON.stringify(it.path.split('/').filter(Boolean)) ===
        JSON.stringify(path.split('/').filter(Boolean)));
    if (!file) {
        throw new Error(`File not found: ${path}`);
    }
    return file;
}
function emptyFile(file = {}) {
    return {
        isFolder: false,
        name: 'unknown',
        extension: '',
        content: '',
        path: '',
        ...file,
    };
}


/***/ }),
/* 9 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatCode: () => (/* binding */ formatCode)
/* harmony export */ });
async function formatCode(code, extension, ignoreError = true) {
    if (!code || code.trim().length === 0)
        return '';
    function whatIsParserImport() {
        switch (extension) {
            case 'ts':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 33, 23))],
                    parserName: 'typescript',
                };
            case 'js':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 34, 23))],
                    parserName: 'babel',
                };
            case 'html':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 35, 23))],
                    parserName: 'html',
                };
            case 'css':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 36, 23))],
                    parserName: 'css',
                };
            case 'scss':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 36, 23))],
                    parserName: 'scss',
                };
            case 'code-snippets':
            case 'json':
            case 'prettierrc':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 34, 23))],
                    parserName: 'json',
                };
            case 'md':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 37, 23))],
                    parserName: 'markdown',
                };
            case 'yaml':
            case 'yml':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 38, 23))],
                    parserName: 'yaml',
                };
            case '':
            case 'gitignore':
            case 'prettierignore':
            case 'toml':
            case 'env':
            case 'txt':
                return {
                    parserImport: [],
                    parserName: '',
                };
            default:
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 34, 23))],
                    parserName: 'babel',
                };
        }
    }
    const { parserImport, parserName } = whatIsParserImport();
    if (!parserName)
        return code;
    const [prettier, ...plugins] = await Promise.all([
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 39, 23)),
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 40, 23)).then((e) => e),
        ...parserImport,
    ]);
    try {
        return prettier
            .format(code, {
            parser: parserName,
            plugins: plugins,
            singleQuote: true,
        })
            .then((formattedCode) => formattedCode.trim());
    }
    catch (error) {
        if (error instanceof Error)
            if (error.name === 'SyntaxError') {
                return ignoreError === true ? code : formatCode(code, 'ts', true);
            }
        throw error;
    }
}


/***/ }),
/* 10 */,
/* 11 */
/***/ ((module) => {

module.exports = require("tiny-injector");

/***/ }),
/* 12 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 13 */
/***/ ((module) => {

module.exports = require("@automapper/classes");

/***/ }),
/* 14 */
/***/ ((module) => {

module.exports = require("@automapper/core");

/***/ }),
/* 15 */
/***/ ((module) => {

module.exports = require("class-validator");

/***/ }),
/* 16 */
/***/ ((module) => {

module.exports = require("@faslh/tiny-mediatr");

/***/ }),
/* 17 */
/***/ ((module) => {

module.exports = require("tslog");

/***/ }),
/* 18 */
/***/ ((module) => {

module.exports = require("request-ip");

/***/ }),
/* 19 */
/***/ ((module) => {

module.exports = require("dedent");

/***/ }),
/* 20 */
/***/ ((module) => {

module.exports = require("sql-parser-cst");

/***/ }),
/* 21 */
/***/ ((module) => {

module.exports = require("ts-morph");

/***/ }),
/* 22 */
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),
/* 23 */
/***/ ((module) => {

module.exports = require("ajv-errors");

/***/ }),
/* 24 */
/***/ ((module) => {

module.exports = require("ajv-formats");

/***/ }),
/* 25 */
/***/ ((module) => {

module.exports = require("validator");

/***/ }),
/* 26 */
/***/ ((module) => {

module.exports = require("js-yaml");

/***/ }),
/* 27 */
/***/ ((module) => {

module.exports = require("openapi3-ts/oas31");

/***/ }),
/* 28 */
/***/ ((module) => {

module.exports = require("deepmerge");

/***/ }),
/* 29 */
/***/ ((module) => {

module.exports = require("events");

/***/ }),
/* 30 */
/***/ ((module) => {

module.exports = require("esbuild");

/***/ }),
/* 31 */
/***/ ((module) => {

module.exports = require("esbuild-node-externals");

/***/ }),
/* 32 */
/***/ ((module) => {

module.exports = require("pluralize");

/***/ }),
/* 33 */
/***/ ((module) => {

module.exports = require("prettier/plugins/typescript");

/***/ }),
/* 34 */
/***/ ((module) => {

module.exports = require("prettier/plugins/babel");

/***/ }),
/* 35 */
/***/ ((module) => {

module.exports = require("prettier/plugins/html");

/***/ }),
/* 36 */
/***/ ((module) => {

module.exports = require("prettier/plugins/postcss");

/***/ }),
/* 37 */
/***/ ((module) => {

module.exports = require("prettier/plugins/markdown");

/***/ }),
/* 38 */
/***/ ((module) => {

module.exports = require("prettier/plugins/yaml");

/***/ }),
/* 39 */
/***/ ((module) => {

module.exports = require("prettier/standalone");

/***/ }),
/* 40 */
/***/ ((module) => {

module.exports = require("prettier/plugins/estree");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/require chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "loaded", otherwise not loaded yet
/******/ 		var installedChunks = {
/******/ 			0: 1
/******/ 		};
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		var installChunk = (chunk) => {
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids, runtime = chunk.runtime;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 1;
/******/ 		
/******/ 		};
/******/ 		
/******/ 		// require() chunk loading for javascript
/******/ 		__webpack_require__.f.require = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					installChunk(require("./" + __webpack_require__.u(chunkId)));
/******/ 				} else installedChunks[chunkId] = 1;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		// no external install chunk
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  writeFiles: () => (/* binding */ writeFiles)
});

;// CONCATENATED MODULE: external "@octokit/core"
const core_namespaceObject = require("@octokit/core");
;// CONCATENATED MODULE: external "child_process"
const external_child_process_namespaceObject = require("child_process");
;// CONCATENATED MODULE: external "commander"
const external_commander_namespaceObject = require("commander");
;// CONCATENATED MODULE: external "date-fns"
const external_date_fns_namespaceObject = require("date-fns");
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(1);
// EXTERNAL MODULE: external "fs/promises"
var promises_ = __webpack_require__(2);
;// CONCATENATED MODULE: external "os"
const external_os_namespaceObject = require("os");
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(3);
;// CONCATENATED MODULE: external "semver"
const external_semver_namespaceObject = require("semver");
var external_semver_default = /*#__PURE__*/__webpack_require__.n(external_semver_namespaceObject);
;// CONCATENATED MODULE: external "simple-git"
const external_simple_git_namespaceObject = require("simple-git");
var external_simple_git_default = /*#__PURE__*/__webpack_require__.n(external_simple_git_namespaceObject);
// EXTERNAL MODULE: ../utils/formatter/src/lib/format-code.ts
var format_code = __webpack_require__(9);
;// CONCATENATED MODULE: external "stream"
const external_stream_namespaceObject = require("stream");
;// CONCATENATED MODULE: external "tar-stream"
const external_tar_stream_namespaceObject = require("tar-stream");
var external_tar_stream_default = /*#__PURE__*/__webpack_require__.n(external_tar_stream_namespaceObject);
// EXTERNAL MODULE: ../utils/src/index.ts + 9 modules
var src = __webpack_require__(4);
;// CONCATENATED MODULE: external "dockerode"
const external_dockerode_namespaceObject = require("dockerode");
var external_dockerode_default = /*#__PURE__*/__webpack_require__.n(external_dockerode_namespaceObject);
;// CONCATENATED MODULE: ../docker/src/lib/instance.ts

const docker = new (external_dockerode_default())();

;// CONCATENATED MODULE: external "crypto"
const external_crypto_namespaceObject = require("crypto");
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_namespaceObject);
;// CONCATENATED MODULE: ../docker/src/lib/utils.ts






async function upsertVolume(name) {
    try {
        return await docker.getVolume(name).inspect();
    }
    catch (error) {
        const { statusCode, message } = error;
        if (statusCode === 404) {
            return await docker.createVolume({ Name: name });
        }
        throw error;
    }
}
function upsertNetwork(name) {
    return docker
        .getNetwork(name)
        .inspect()
        .catch(() => docker.createNetwork({ Name: name }));
}
async function getContainer(containerId) {
    if (typeof containerId === 'string') {
        return docker.getContainer(containerId);
    }
    const containers = await docker.listContainers({ all: true });
    const container = containers.find((c) => c.Names.includes(`/${containerId.name}`));
    if (!container) {
        return null;
    }
    return docker.getContainer(container.Id);
}
async function removeContainer(nameOrContainer) {
    const container = typeof nameOrContainer === 'string'
        ? await getContainer({ name: nameOrContainer })
        : nameOrContainer;
    if (!container) {
        throw new Error('Container not found');
    }
    const isRunning = await isContainerRunning(container);
    if (isRunning) {
        await container.stop({ t: 0 }).catch(console.error);
    }
    await container.remove({ f: true }).catch(console.error);
}
async function isContainerRunning(nameOrContainer) {
    const container = typeof nameOrContainer === 'string'
        ? await getContainer({ name: nameOrContainer })
        : nameOrContainer;
    if (!container) {
        return false;
    }
    return container.inspect().then((info) => info.State.Running);
}
function computeChecksum(filePath) {
    return new Promise((resolve, reject) => {
        const hash = external_crypto_default().createHash('md5');
        const stream = typeof filePath === 'string' ? (0,external_fs_.createReadStream)(filePath) : filePath;
        stream.on('data', (data) => hash.update(data));
        stream.on('end', () => resolve(hash.digest('hex')));
        stream.on('error', (err) => reject(err));
    });
}
async function fileChanged(filePath, discrminator) {
    const checksumDirPath = (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), discrminator);
    await (0,promises_.mkdir)(checksumDirPath, { recursive: true });
    const checksumFilePath = (0,external_path_.join)(checksumDirPath, (0,external_path_.basename)(filePath));
    const currentChecksum = await computeChecksum(filePath);
    const flush = async () => {
        await (0,promises_.rm)(checksumFilePath, { force: true });
    };
    if (!(0,external_fs_.existsSync)(checksumFilePath)) {
        await (0,promises_.writeFile)(checksumFilePath, currentChecksum, 'utf-8');
        return {
            changed: true,
            flush,
        };
    }
    const storedChecksum = await (0,promises_.readFile)(checksumFilePath, 'utf-8');
    const changed = currentChecksum !== storedChecksum;
    if (changed) {
        await (0,promises_.writeFile)(checksumFilePath, currentChecksum, 'utf-8');
    }
    return {
        changed: changed,
        flush,
    };
}
async function contentChanged(content, fileName, discrminator) {
    const checksumFilePath = (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), discrminator, fileName);
    await (0,promises_.mkdir)((0,external_path_.dirname)(checksumFilePath), { recursive: true });
    const filePath = (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), 'check', discrminator, fileName);
    await (0,promises_.mkdir)((0,external_path_.dirname)(filePath), { recursive: true });
    await (0,promises_.writeFile)(filePath, content, 'utf-8');
    const currentChecksum = await computeChecksum(filePath);
    const flush = async () => {
        await (0,promises_.rm)(checksumFilePath, { force: true });
    };
    if (!(0,external_fs_.existsSync)(checksumFilePath)) {
        await (0,promises_.writeFile)(checksumFilePath, currentChecksum, 'utf-8');
        return {
            changed: true,
            flush,
        };
    }
    const storedChecksum = await (0,promises_.readFile)(checksumFilePath, 'utf-8');
    const changed = currentChecksum !== storedChecksum;
    if (changed) {
        await (0,promises_.writeFile)(checksumFilePath, currentChecksum, 'utf-8');
    }
    return {
        changed: changed,
        flush,
    };
}
function makeProjectPath(projectId) {
    return (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), 'client-server', projectId);
}
function makeRunningContainerName(projectId) {
    return `${projectId}-container`;
}
async function followLogs(container) {
    const stream = await container.logs({
        follow: true,
        stdout: true,
        stderr: true,
        details: true,
    });
    container.modem.demuxStream(stream, process.stdout, process.stderr);
}
async function startContainer(name, createContainer) {
    let container = null;
    if (typeof name === 'string') {
        container = await getContainer({ name });
    }
    else {
        container = name;
    }
    if (!container) {
        if (!createContainer) {
            throw new Error(`Cannot initialize server for project: ${name}`);
        }
        container = await createContainer();
    }
    const running = await isContainerRunning(container);
    if (!running) {
        await container.start().catch((error) => {
            if (error.statusCode === 304) {
                return;
            }
            throw error;
        });
    }
    return container;
}
async function getContainerPort(internalPort, containerId) {
    let container;
    if (typeof containerId === 'string' || 'name' in containerId) {
        container = await getContainer(containerId);
    }
    else {
        container = containerId;
    }
    if (!container) {
        throw new Error('Container not found');
    }
    const data = await container.inspect();
    return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}

;// CONCATENATED MODULE: ../docker/src/compose.ts
function compose(services) {
    const dockerCompose = {
        volumes: {},
        networks: {},
        services: {},
    };
    const appEnvironment = {};
    for (const [serviceName, it] of Object.entries(services)) {
        const depends_on = it.dependsOn(services);
        Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
        delete it.composeService.appEnvironment;
        dockerCompose.services[serviceName] = {
            ...it.composeService,
            environment: Object.keys(it.composeService.environment).length
                ? it.composeService.environment
                : undefined,
            depends_on: depends_on.length ? depends_on : undefined,
        };
        dockerCompose.volumes = {
            ...dockerCompose.volumes,
            ...it.volumes
                .filter((it) => it.isNamedVolume)
                .reduce((acc, it) => ({
                ...acc,
                [it.src]: {},
            }), {}),
        };
        dockerCompose.networks = {
            ...dockerCompose.networks,
            ...it.networks.reduce((acc, it) => ({
                ...acc,
                [it]: {},
            }), {}),
        };
    }
    return {
        dockerCompose: dockerCompose,
        environment: appEnvironment,
    };
}
function service(serviceLike) {
    const ports = (serviceLike.ports ?? []).map((it) => {
        const [host, internal] = it.split(':');
        return {
            host,
            internal,
        };
    });
    const volumes = (serviceLike.volumes ?? []).map((it) => {
        const [src, dest] = it.split(':');
        return {
            src,
            dest,
            isNamedVolume: !(src.startsWith('/') || src.startsWith('./')),
        };
    });
    return {
        composeService: serviceLike,
        ports,
        volumes,
        networks: serviceLike.networks ?? [],
        dependsOn: (services) => {
            const depends_on = [];
            for (const dependencie of serviceLike.depends_on ?? []) {
                for (const [serviceName, serviceLike] of Object.entries(services)) {
                    if (serviceLike.composeService === dependencie) {
                        depends_on.push(serviceName);
                    }
                }
            }
            return depends_on;
        },
    };
}
function toKevValEnv(obj) {
    return Object.entries(obj)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
}

;// CONCATENATED MODULE: ../docker/src/index.ts







function createPack(content) {
    const pack = external_tar_stream_default().pack();
    const entry = pack.entry({ name: 'package.json' }, content, () => {
        pack.finalize();
    });
    entry.end();
    return new Promise((resolve, reject) => {
        entry.on('finish', () => {
            resolve(pack);
        });
        entry.on('error', reject);
    });
}
function createExtract(onEntry) {
    const extract = external_tar_stream_default().extract();
    extract.on('entry', (header, stream, next) => {
        onEntry(header.name, stream);
        stream.on('end', next);
        stream.resume();
    });
    extract.on('finish', () => {
        console.log('File extraction complete');
    });
    return extract;
}
const mainOutStream = new external_stream_namespaceObject.PassThrough();
const mainErrStream = new external_stream_namespaceObject.PassThrough();
if (process.env['NODE_ENV'] === 'development') {
    // mainErrStream.setMaxListeners(Infinity);
    // mainOutStream.setMaxListeners(Infinity);
    // mainOutStream.pipe(process.stdout);
    // mainErrStream.pipe(process.stderr);
}
async function execCommand(container, cmd) {
    const exec = await container.exec({
        AttachStdout: true,
        AttachStderr: true,
        Cmd: cmd,
        Tty: false,
        Privileged: false,
    });
    const stream = await exec.start({});
    const outStream = new external_stream_namespaceObject.PassThrough();
    const errStream = new external_stream_namespaceObject.PassThrough();
    container.modem.demuxStream(stream, outStream, errStream);
    // if (process.env['NODE_ENV'] === 'development') {
    //   outStream.pipe(mainOutStream);
    //   errStream.pipe(mainErrStream);
    // }
    let out = '';
    let err = '';
    outStream.on('data', (chunk) => {
        out += chunk.toString();
    });
    errStream.on('data', (chunk) => {
        err += chunk.toString();
    });
    return new Promise((resolve, reject) => {
        stream.on('end', async () => {
            try {
                console.log(`Command ${cmd.join(' ')}`);
                const a = await exec.inspect();
                if (a.ExitCode !== 0) {
                    // logMe(a);
                    const error = new Error(err);
                    error.cause = a;
                    reject(error);
                }
                else if (err) {
                    const error = new Error(err);
                    error.cause = a;
                    return reject(error);
                }
                else {
                    resolve(out);
                }
            }
            catch (e) {
                reject(e);
            }
        });
    });
}
async function getDependencyInstaller() {
    const container = await startContainer('dependency-installer', () => docker.createContainer({
        name: 'dependency-installer',
        Image: 'node:lts',
        WorkingDir: '/app',
        Cmd: ['tail', '-f', '/dev/null'],
        HostConfig: {
            Binds: [`node_modules:/app/node_modules`],
            CapDrop: ['ALL'],
            Privileged: false,
        },
    }));
    await followLogs(container);
    return container;
}
async function installPackage(sourceData) {
    const container = await getDependencyInstaller();
    await execCommand(container, [
        'sh',
        '-c',
        `echo '${JSON.stringify({
            version: '0.0.0',
            main: './build/server.js',
            type: 'module',
            dependencies: {
                'ua-parser-js': '^1.0.37',
                'request-ip': '^3.3.0',
                'rfc-7807-problem-details': '^1.1.0',
                ajv: '8.12.0',
                'ajv-formats': '2.1.1',
                'ajv-errors': '3.0.0',
                'ajv-keywords': '5.1.0',
                validator: '13.9.0',
                'lodash-es': '^4.17.21',
                'http-status-codes': '2.2.0',
                hono: '^4.4.0',
                '@hono/node-server': '^1.11.1',
                '@scalar/hono-api-reference': '^0.5.145',
                typeorm: '0.3.20',
                pg: '8.11.5',
                'sql-template-tag': '5.2.1',
                resend: '1.0.0',
                '@octokit/webhooks': '^13.2.7',
                'node-cron': '^3.0.3',
                [sourceData.package]: sourceData.version,
            },
            devDependencies: {
                '@types/ua-parser-js': '^0.7.39',
                '@types/request-ip': '^0.0.41',
                '@types/lodash-es': '^4.17.12',
                '@types/node': '^20.11.26',
                typescript: '^4.9.4',
                '@types/validator': '13.7.17',
                '@types/node-cron': '^3.0.11',
                prettier: '3.3.2',
            },
        })}' > package.json`,
    ]);
    await execCommand(container, [
        'sh',
        '-c',
        'npm install',
        '--no-audit',
        '--no-fund',
    ]);
    return container;
}
async function installPackageJson(content, projectId) {
    const containerName = `${projectId}-install-deps`;
    const volumeName = 'node_modules';
    const depsImage = 'node:lts';
    const pack = await createPack(content);
    const { value: container, error } = await (0,src.extractError)(() => docker.createContainer({
        Image: depsImage,
        WorkingDir: '/app',
        name: containerName,
        Cmd: ['sh', '-c', 'npm install', '--no-audit', '--no-fund'],
        HostConfig: {
            // Binds: [`${volumeName}:/app/node_modules`],
            AutoRemove: true,
            // ReadonlyRootfs: true,
            CapDrop: ['ALL'],
        },
    }));
    if (error) {
        const { statusCode, message } = error;
        switch (statusCode) {
            case 409:
                await removeContainer(containerName).catch(() => {
                    // noop
                });
                await installPackageJson(content, projectId);
                break;
            case 404:
                console.log(`Image not found: ${depsImage}`);
                console.error(error);
                // FIXME: pull and try again
                break;
            default:
                console.error(error);
                break;
        }
        return;
    }
    try {
        // Copy your package.json into the container
        await container.putArchive(pack, {
            path: '/app',
        });
        const stream = await container.attach({
            stream: true,
            stdout: true,
            stderr: true,
            logs: true,
        });
        stream.pipe(process.stdout);
        await container.start();
        await container.wait({
            condition: 'removed',
        });
        console.log('Dependencies installed');
    }
    finally {
        await removeContainer(containerName).catch(() => {
            // call remove just in case the container didn't remove itself
        });
    }
}
function followProgress(stream, logger = console) {
    return new Promise((resolve, reject) => {
        docker.modem.followProgress(stream, (err, res) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(res);
            }
        }, logger.log);
    });
}


// EXTERNAL MODULE: ../compiler/generator/utils/src/index.ts
var utils_src = __webpack_require__(8);
;// CONCATENATED MODULE: ./src/lib/snippets.ts
/* harmony default export */ const snippets = ({
    'HTTP Workflow': {
        prefix: 'httpworkflow',
        body: [
            `workflow('$1', {
  tag: '$2',
  trigger: trigger.http({
    method: '$3',
    path: '$4',
  }),
  execute: async (trigger, request) => {
  const url = new URL(request.url);
  return {
      path: url.pathname,
      method: request.method,
    }
  },
});
      `,
        ],
        description: 'Creates a generic HTTP workflow with customizable method and path',
    },
    'Schedule Workflow': {
        prefix: 'cronworkflow',
        body: [
            `workflow('$1', {
  tag: '$2',
  trigger: trigger.schedule({
    pattern: '$3',
  }),
  execute: async (trigger) => {
    // Scheduled task logic here
  },
});
      `,
        ],
        description: 'Creates a generic Cron schedule workflow',
    },
    'WebSocket Workflow': {
        prefix: 'websocketworkflow',
        body: [
            `workflow('$1', {
  tag: '$2',
  trigger: trigger.websocket({
    topic: '$3',
  }),
  execute: async (trigger) => {
    return trigger.channel; // WebSocket response logic here
  },
});
      `,
        ],
        description: 'Creates a generic WebSocket workflow',
    },
    'SSE Workflow': {
        prefix: 'sseworkflow',
        body: [
            `workflow('$1', {
  tag: '$2',
  trigger: trigger.sse({
    path: '$3',
  }),
  execute: async (trigger) => {
    const stream = new PassThrough();
    setInterval(() => {
    stream.push('data: $4\\n\\n');
    }, 1000);
    return stream;
  },
});
      `,
        ],
        description: 'Creates a generic Server-Sent Events (SSE) workflow',
    },
    'GitHub Webhook Workflow': {
        prefix: 'githubworkflow',
        body: [
            `workflow('$1', {
  tag: '$2',
  trigger: trigger.github({
    event: '$3',
  }),
  execute: async (trigger) => {
    // Webhook logic here
  },
});
      `,
        ],
        description: 'Creates a generic GitHub Webhook workflow',
    },
    'Create Workflow': {
        prefix: 'createworkflow',
        body: [
            `workflow('Create$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'post',
    path: '/$3',
  }),
  execute: async (trigger) => {
    const record = await saveEntity(tables.$4, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    });
    return {
      id: record.id,
    };
  },
});
      `,
        ],
        description: "Creates a workflow for inserting a new entity and returns the record's ID",
    },
    'List Workflow': {
        prefix: 'listworkflow',
        body: [
            `workflow('List$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(tables.$4, '$4');
    const paginationMetadata = limitOffsetPagination(qb, {
      pageSize: trigger.query.pageSize,
      pageNo: trigger.query.pageNo,
      count: await qb.getCount(),
    });
    const records = await execute(qb);
    return {
      meta: paginationMetadata(records),
      records: records,
    };
  },
});
      `,
        ],
        description: 'Creates a workflow for listing multiple entities with pagination',
    },
    'Get Workflow': {
        prefix: 'getworkflow',
        body: [
            `workflow('Get$1ById', {
  tag: '$2',
  trigger: trigger.http({
    method: 'get',
    path: '/$3/:id',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id });
    const record = await execute(qb);
    return record;
  },
});
      `,
        ],
        description: 'Creates a workflow for reading a single entity by ID',
    },
    'Update Workflow': {
        prefix: 'updateworkflow',
        body: [
            `workflow('Update$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'patch',
    path: '/$3/:id',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(ttables.$4, '$4').where('id = :id', { id: trigger.path.id });
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    });
    return {
      id: record.id,
    };
  },
});
      `,
        ],
        description: "Creates a workflow for updating an entity by ID and returns the record's ID",
    },
    'Delete Workflow': {
        prefix: 'deleteworkflow',
        body: [
            `workflow('Delete$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'delete',
    path: '/$3/:id',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id });
    await removeEntity(qb);
    return {
      id: trigger.path.id,
    };
  },
});
      `,
        ],
        description: 'Creates a workflow for deleting an entity by ID and returns the deleted ID',
    },
    'Replace Workflow': {
        prefix: 'replaceworkflow',
        body: [
            `workflow('Replace$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'put',
    path: '/$3/:id',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id });
    const record = await updateEntity(qb, {
      field1: trigger.body.field1,
      field2: trigger.body.field2,
    });
    return {
      id: record.id,
    };
  },
});
      `,
        ],
        description: 'Creates a workflow for replacing an entity and returns the updated ID',
    },
    'Exists Workflow': {
        prefix: 'existsworkflow',
        body: [
            `workflow('Exists$1', {
  tag: '$2',
  trigger: trigger.http({
    method: 'head',
    path: '/$3/:id',
  }),
  execute: async (trigger) => {
    const qb = createQueryBuilder(tables.$4, '$4').where('id = :id', { id: trigger.path.id });
    const doesExist = await exists(qb);
    return {
      exists: doesExist,
    };
  },
});
      `,
        ],
        description: 'Creates a workflow to check if an entity exists by ID',
    },
});

;// CONCATENATED MODULE: ./src/index.ts
//#!/usr/bin/env node














const BASIC_EXTENSIONS = {
    core: {},
    identity: {},
    hono: {},
    postgresql: {
        CONNECTION_STRING: '@process:env.CONNECTION_STRING',
    },
    fly: {
        FLY_API_TOKEN: '@build:secrets.FLY_API_TOKEN',
        FLY_APP_NAME: '@build:secrets.FLY_APP_NAME',
    },
    prettier: {},
};
const projectDir = process.cwd();
const cli = external_commander_namespaceObject.program
    .name('january')
    .version('1.0.0')
    .description('January')
    .helpOption('-h, --help', 'Display help for command')
    .helpCommand('help [command]', 'Display help for command')
    .option('--no-upgrade', 'Do not upgrade to latest version', true);
cli
    .command('init')
    .argument('<name>', 'Name to greet')
    .action(async (name) => {
    const dir = (0,external_path_.join)(projectDir, name);
    const initialProjectCode = `import {  feature,  field,  mandatory,  policy,  project,  table,  trigger,  useTable,  workflow,} from '@january/declarative';\n\nexport default project();`;
    // Scaffold the project directory
    await writeFiles(dir, {
        '.vscode/january.code-snippets': JSON.stringify(snippets),
        '.vscode/settings.json': {
            'editor.snippets.codeActions.enabled': true,
            'editor.suggest.showSnippets': true,
            'editor.suggest.snippetsPreventQuickSuggestions': false,
            'editor.snippetSuggestions': 'top',
            'typescript.preferences.importModuleSpecifier': 'non-relative',
            'files.autoSave': 'afterDelay',
            'files.autoSaveWhenNoErrors': false,
            'files.refactoring.autoSave': true,
            'files.autoSaveDelay': 500,
            'explorer.fileNesting.enabled': true,
            'explorer.fileNesting.expand': true,
            'explorer.fileNesting.patterns': {
                'compose.ts': 'compose.*, docker-compose.*, *.env',
                'package.json': 'package*.json',
                'tsconfig.json': 'tsconfig*.json, .prettier*, .gitignore',
                Dockerfile: 'Dockerfile*, *.toml',
            },
        },
        'package.json': {
            name: name,
            version: '1.0.0',
            workspaces: ['output'],
            private: true,
            scripts: {
                dev: 'npm run dev -w output',
                build: 'node --watch-path ./src ./node_modules/@january/canary generate',
            },
            dependencies: {
                '@january/declarative': 'https://github.com/JanuaryLabs/dist/raw/main/declarative.tar.gz',
                '@january/extensions': 'https://github.com/JanuaryLabs/dist/raw/main/extensions.tar.gz',
                '@january/canary': 'https://github.com/JanuaryLabs/dist/raw/main/canary.tar.gz',
                '@january/docker': 'https://github.com/JanuaryLabs/dist/raw/main/docker.tar.gz',
            },
        },
        'tsconfig.json': {
            extends: './output/tsconfig.json',
            include: ['src/**/*.ts'],
            exclude: ['vite.config.ts', 'src/**/*.spec.ts', 'src/**/*.test.ts'],
            compilerOptions: {
                rootDir: '.',
                moduleResolution: 'Bundler',
                module: 'ESNext',
            },
        },
        '.env': toKevValEnv({
            NODE_ENV: 'development',
        }),
        'extensions.json': {},
        '.gitignore': await fetch('https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore')
            .then((res) => res.text())
            .then((it) => it + '\noutput/'),
        'src/project.ts': initialProjectCode,
        'src/extensions/user/index.ts': '',
        'compose.ts': `
      import { compose, service, toKevValEnv } from '@january/docker';
      import { writeCompose } from '@january/extensions';
      import { localServer } from '@january/extensions/fly';
      import { postgres, pgadmin } from '@january/extensions/postgresql';

writeCompose(compose({
  database: service(postgres),
  pgadmin: service(pgadmin),
  server: service({
    ...localServer(),
    depends_on: [postgres],
  }),
}));
`,
    });
    // Run the generator on an empty project to populate the output directory
    const { generate } = await __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(__webpack_require__, 10));
    const outputDir = (0,external_path_.join)(dir, 'output');
    await generate(initialProjectCode, BASIC_EXTENSIONS, outputDir);
    // Initialize git
    const git = external_simple_git_default()(projectDir);
    await git.init().catch(() => {
        // ignore any kind of errors and let the user manually initialize the git repo
        console.warn('Failed to initialize git repo. Please initialize the git repo "git init".');
    });
    // Install dependencies
    (0,external_child_process_namespaceObject.execSync)('npm install --no-audit --no-fund', {
        cwd: dir,
        encoding: 'utf-8',
        stdio: 'inherit',
    });
});
cli.command('generate').action(async () => {
    const opts = external_commander_namespaceObject.program.opts();
    if (opts.upgrade) {
        await checkForNewVersion().catch((error) => {
            console.error('Failed to check for new version');
            console.error(error);
        });
    }
    const outputDir = (0,external_path_.join)(projectDir, 'output');
    const code = await (0,promises_.readFile)((0,external_path_.join)(projectDir, 'src', 'project.ts'), 'utf-8');
    const extensions = JSON.parse(await (0,promises_.readFile)((0,external_path_.join)(projectDir, 'extensions.json'), 'utf-8'));
    const { generate } = await __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(__webpack_require__, 10));
    await generate(code, {
        ...BASIC_EXTENSIONS,
        ...extensions,
    }, outputDir);
});
cli.parse(process.argv);
async function writeFiles(dir, contents) {
    for (const [file, content] of Object.entries(contents)) {
        const filePath = (0,external_path_.isAbsolute)(file) ? file : (0,external_path_.join)(dir, file);
        await (0,promises_.mkdir)((0,external_path_.dirname)(filePath), { recursive: true });
        await (0,promises_.writeFile)(filePath, await (0,format_code.formatCode)(typeof content === 'string' ? content : JSON.stringify(content), (0,utils_src.getExt)(file)), 'utf-8');
    }
}
async function getLatestVersion() {
    const octokit = new core_namespaceObject.Octokit();
    const fullName = 'JanuaryLabs/dist';
    const [owner, repo] = fullName.split('/');
    const { data: files } = await octokit.request('GET /repos/{owner}/{repo}/contents', {
        owner,
        repo,
        path: '',
        ref: 'main',
    });
    const semvers = files
        .filter((it) => it.type === 'dir')
        .map((it) => it.name);
    return external_semver_default().maxSatisfying(semvers, '*');
}
async function checkForNewVersion() {
    const januaryUpdateFile = (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), 'january-update.txt');
    const lastUpdate = await (0,promises_.readFile)(januaryUpdateFile, 'utf-8').catch(() => null);
    if (lastUpdate &&
        (0,external_date_fns_namespaceObject.differenceInMinutes)(new Date(), new Date(lastUpdate)) < 60) {
        return;
    }
    const canaryPackageJson = await readPackageJson((0,external_path_.join)(process.cwd(), 'node_modules', '@january/canary'));
    const projectPackageJson = await readPackageJson(process.cwd());
    const latestVersion = await getLatestVersion();
    if (external_semver_default().gt(latestVersion, canaryPackageJson.version)) {
        console.log(`New version ${latestVersion} available. Upgrading...`);
        const packages = ['canary', 'docker', 'declarative', 'extensions'];
        const packagesLinks = packages.map((it) => `https://github.com/JanuaryLabs/dist/raw/main/${latestVersion}/${it}.tar.gz`);
        projectPackageJson.dependencies = packages.reduce((acc, it, i) => ({
            ...acc,
            [`@january/${it}`]: packagesLinks[i],
        }), projectPackageJson.dependencies ?? {});
        // install the new versions
        (0,external_child_process_namespaceObject.execSync)(`npm install ${packagesLinks.join(' ')} --no-audit --no-fund`, {
            cwd: process.cwd(),
            encoding: 'utf-8',
            stdio: 'inherit',
        });
        // update the package.json
        await (0,promises_.writeFile)((0,external_path_.join)(process.cwd(), 'package.json'), JSON.stringify(projectPackageJson, null, 2), 'utf-8');
        // write current time to temp file
        await (0,promises_.writeFile)(januaryUpdateFile, new Date().toISOString());
    }
}
async function readPackageJson(dir) {
    const packageJsonPath = (0,external_path_.join)(dir, 'package.json');
    return JSON.parse(await (0,promises_.readFile)(packageJsonPath, 'utf-8'));
}
async function timeSinceLastRun(name) {
    const file = (0,external_path_.join)((0,external_os_namespaceObject.tmpdir)(), `${name}.lastrun`);
    if (!(0,external_fs_.existsSync)(file)) {
        return 0;
    }
    const lastRun = new Date(await (0,promises_.readFile)(file, 'utf-8'));
    return {
        minutes: (0,external_date_fns_namespaceObject.differenceInMinutes)(new Date(), lastRun),
        update: () => (0,promises_.writeFile)(file, new Date().toISOString()),
    };
}

module.exports = __webpack_exports__;
/******/ })()
;
//# sourceMappingURL=index.js.map