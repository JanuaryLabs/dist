import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/parser/src/index.ts
import { readFileSync } from "node:fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  globalThis.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveDefaultExpr(defaultExpr, code)
  };
}
function resolveDefaultExpr(defaultExpr, code) {
  if (checker.isCallExpression(defaultExpr.expression)) {
    return resolveCallExpression(defaultExpr.expression, code);
  }
  if (checker.isObjectExpression(defaultExpr.expression)) {
    return resolveObjectExpression(defaultExpr.expression, code);
  }
  return null;
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      list.push(resolveMemberExpression(arg.expression, []).join("."));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
var checker, Checker;
var init_src = __esm({
  "libs/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
    })(Checker || (Checker = {}));
  }
});

// libs/canary/src/exceptions.txt
var exceptions_default = "import {\n  ProblemDetails,\n  ProblemDetailsException,\n} from 'rfc-7807-problem-details';\n\nexport function authorize<T>(\n  ...routePolicies: ((context: T) => Promise<boolean> | boolean)[]\n) {\n  return async (context: T, next: any) => {\n    for (const policy of routePolicies) {\n      if (!await policy(context)) {\n        throw new ForbiddenException();\n      }\n    }\n    await next();\n  };\n}\n\nexport class UnauthorizedException extends ProblemDetailsException {\n  constructor(detail?: string) {\n    super(\n      new ProblemDetails(\n        'Unauthorized',\n        detail ?? 'Authentication is required to access this resource.',\n        401\n      )\n    );\n    Error.captureStackTrace(this, UnauthorizedException);\n  }\n}\n\nexport class ForbiddenException extends ProblemDetailsException {\n  constructor(detail?: string) {\n    super(\n      new ProblemDetails('Forbidden', detail ?? 'You do not have permission to access this resource.', 403)\n    );\n    Error.captureStackTrace(this, ForbiddenException);\n  }\n}";

// libs/canary/src/index.ts
import debug from "debug";
import { merge } from "lodash-es";
import { cp as cp2, readFile as readFile3 } from "node:fs/promises";
import { basename as basename2, extname as extname2, join as join6, relative as relative3 } from "node:path";
import * as morph from "ts-morph";

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "node:path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function addLeadingSlash(path) {
  return normalize(join("/", path));
}

// libs/compiler/contracts/src/contract.ts
var Contracts;
((Contracts2) => {
  function fffffff(input) {
    const [namespace, value] = input.split(":");
    return {
      namespace,
      value
    };
  }
})(Contracts || (Contracts = {}));

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/bundler/src/virtual.ts
import esbuild from "esbuild";

// libs/bundler/src/bundler.ts
import esbuild2 from "esbuild";
import { join as join3, relative } from "node:path";

// libs/modern/src/index.ts
import { cp, readFile as readFile2, stat as stat2, writeFile as writeFile2 } from "node:fs/promises";
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/file-system.ts
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { dirname, isAbsolute, join as join2 } from "node:path";
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};
async function exist(file) {
  return stat(file).then(() => true).catch(() => false);
}
async function readFolder(path) {
  if (await exist(path)) {
    return readdir(path);
  }
  return [];
}
async function writeFiles(dir, contents, format = true) {
  return Promise.all(
    Object.entries(contents).map(async ([file, content]) => {
      const filePath = isAbsolute(file) ? file : join2(dir, file);
      await mkdir(dirname(filePath), { recursive: true });
      if (typeof content === "string") {
        await writeFile(
          filePath,
          format ? await formatCode(content, getExt(file)) : content,
          "utf-8"
        );
      } else {
        if (content.ignoreIfExists) {
          if (!await exist(filePath)) {
            await writeFile(
              filePath,
              format ? await formatCode(content.content, getExt(file)) : content.content,
              "utf-8"
            );
          }
        }
      }
    })
  );
}

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
async function readJson(path) {
  const content = JSON.parse(await readFile2(path, "utf-8"));
  return {
    content,
    write: (value = content) => writeFile2(path, JSON.stringify(value, null, 2), "utf-8")
  };
}

// libs/bundler/src/bundler.ts
async function bundle(options) {
  const packages = [];
  const jumps = ["/", ...relative(options.cwd, options.projectRoot).split("/")];
  while (jumps.length) {
    const path = join3(options.cwd, jumps.join("/"), "package.json");
    if (await exist(path)) {
      packages.push(path);
    }
    jumps.pop();
  }
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);"
    },
    packages: "external",
    assetNames: "[name]",
    loader: {
      "swagger.json": "file"
    }
  });
}

// libs/sdk/evaluator/src/lib/evaluate.ts
import { get } from "lodash-es";
import { randomBytes } from "node:crypto";

// libs/sdk/declarative/src/lib/table.ts
import pluralize from "pluralize";

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config2 = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config2.message
    }
  };
}
var required = mandatory;
function unique(config2 = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config2.message
      }
    }
  ];
}
function defineValidation(config2) {
  return {
    name: config2.name,
    config: config2
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config2) {
  const additionalFields = {};
  const idField = Object.values(config2.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config2.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config2.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config2.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        mode: "string"
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true,
        mode: "string"
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config2.fields,
      ...additionalFields
    },
    constraints: config2.constraints || []
  };
}
((table2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = table2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown table type: ${type}`);
    }
    return table2(type);
  }
  table2.fromConfig = fromConfig;
  function link(config2) {
    const { table1, table2: table22 } = config2;
    return table2({
      fields: {
        ...config2.fields,
        [pluralize.singular(distilTableName(table1))]: field.relation({
          references: table1,
          relationship: "many-to-one"
        }),
        [pluralize.singular(distilTableName(table22))]: field.relation({
          references: table22,
          relationship: "many-to-one"
        })
      },
      constraints: config2.constraints
    });
  }
  table2.link = link;
})(table || (table = {}));
function field(config2) {
  const { type, validations = [], metadata = {}, ...rest } = config2;
  return {
    type: config2.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config2) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config2.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config2.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config2 = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config2;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config2) {
    return field2({
      type: "relation",
      metadata: { ...config2, references: distilTableName(config2.references) },
      validations: config2.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
function distilTableName(table2) {
  const [, relatedTableName, ...rest] = table2.split(".");
  if (rest.length) {
    throw new Error(
      `Wrong relation reference: ${table2}. Did you mean tables.${relatedTableName}`
    );
  }
  return relatedTableName;
}
field.enum = (config2) => {
  return field({
    type: "single-select",
    validations: config2.validations,
    metadata: {
      style: "enum",
      values: config2.values,
      defaultValue: config2.defaultValue
    }
  });
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(config2) {
  const execute = config2.trigger.refineExecute(config2.execute);
  return {
    trigger: config2.trigger,
    execute,
    description: config2.description,
    tag: config2.tag
  };
}

// libs/sdk/evaluator/src/lib/evaluate.ts
init_src();
var defaultPrimitiveCallers = {
  workflow,
  table: table.fromConfig,
  field: field.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  index
  // z: {
  //   object(...args: any[]) {
  //     logMe({ 'z.objectile': args });
  //     return args;
  //   },
  //   uuid() {
  //     return 'uuid';
  //   },
  //   int(...args: any[]) {
  //     logMe({ 'z.int': args });
  //     return 'int';
  //   },
  //   number(...args: any[]) {
  //     logMe({ 'z.number': args });
  //     return 'number';
  //   },
  //   string() {
  //     return 'string';
  //   },
  //   array(...args: any[]) {
  //     logMe({ 'z.array': args });
  //     return {
  //       type: 'array',
  //     };
  //   },
  // } as any,
  // z(...args: any[]) {
  //   logMe({ z: args });
  //   return args;
  // },
  // object(...args: any[]) {
  //   logMe({ 'z.object': args });
  //   return 'object';
  // },
  // uuid() {
  //   return 'uuid';
  // },
  // int() {
  //   return 'int';
  // },
  // number() {
  //   return 'string';
  // },
  // string() {
  //   return 'string';
  // },
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers, node, hooks = {}) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    let callerImpl = callers[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node.arguments.map((it) => staticEval(callers, it, hooks));
    if (typeof callerImpl === "function") {
      if (type.length) {
        args.unshift(type.join("."));
      }
      return callerImpl(...args);
    }
    callerImpl = get(callerImpl, type);
    if (!callerImpl) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => staticEval(callers, it, hooks));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      obj[key] = staticEval(callers, value, hooks);
    }
    return obj;
  }
  return node;
}
async function evaluate(code, callers) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    block: staticEval(callers, ast.project),
    imports: ast.imports
  };
}

// libs/compiler/generator/src/index.ts
import { isFunction } from "lodash-es";
import {
  Project as Project4,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project as Project2, SyntaxKind, VariableDeclarationKind as VariableDeclarationKind2 } from "ts-morph";

// libs/compiler/generator/src/lib/sourcecode.ts
import { basename, dirname as dirname2, extname, join as join5, relative as relative2, sep } from "node:path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project3,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";

// libs/compiler/generator/src/lib/project-fs.ts
import { join as join4 } from "node:path";
import { Injectable, ServiceLifetime } from "tiny-injector";
var config = {
  basePath: "./src/app",
  extensions: "./src/app/extensions",
  features: "./src/app/features",
  entities: "./src/app/entities"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  makeFeatureFile = (featureName, fileName) => join4(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join4(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join4(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join4(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join4(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join4(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join4(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join4("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join4("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join4("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeQueryPath = (tableName, queryName) => join4(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectFS);
var commandsGlob = () => {
  return `${config.features}/**/*.command.ts`;
};
var routersGlob = () => {
  return "/**/*.router.ts";
};
var listenersGlob = () => {
  return "/**/*.github.ts";
};
var cronsGlob = () => {
  return "/**/*.cron.ts";
};
var entitiesGlob = () => {
  return "/**/*.entity.ts";
};
var makeFeaturePath = (fileName) => join4(config.features, fileName);

// libs/compiler/generator/src/lib/sourcecode.ts
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project3(options);
}
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join5(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative2(
            dirname2(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
      }
    }
  }
};
findClassSourceFile_fn = function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
};
exportsDir_fn = function(dir) {
  const fullPath = join5(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join5(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportsCommands_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join5(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname2(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName)}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join5(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
};
exportRoutes_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join5(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join5(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { type HonoEnv } from '#core/utils.ts';import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono<HonoEnv>][]`,
    { overwrite: true }
  );
};
exportListeners_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join5(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join5(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportJobs_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join5(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join5(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportEntities_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join5(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from '../${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join5(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities ${exportDefaults.length ? "" : ": any[]"} = [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
};
tuneImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport || it.namespaceImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: false,
        namespaceImport: it.namespaceImport
      });
    }
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: true
      });
    }
  });
};
removeUnusedImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).filter((it) => !it.getAncestors().includes(importDeclaration)).some((it) => it.getText() === importedName);
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
};
moveImportsToTop_fn = function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index2) => {
    file.insertImportDeclaration(index2, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText(),
        isTypeOnly: namedImport.isTypeOnly()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
};
VirtualProject = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}
function emitFiles(concreteStructure, generateDir) {
  const vProject = new VirtualProject(generateDir);
  vProject.generate(concreteStructure);
  return {
    files: vProject.getOutput(),
    save: vProject.emit.bind(vProject),
    cleanup: () => vProject.cleanup()
  };
}

// libs/canary/src/changes/execute.ts
import { StructureKind as StructureKind3 } from "ts-morph";
async function toChanges(projectDefinition) {
  const features = [];
  const workflows = [];
  for (const feature of projectDefinition) {
    features.push({
      displayName: feature.name
    });
    for (const [name, workflow2] of Object.entries(feature.workflows)) {
      const { structures, params, ...triggerConfig } = workflow2.trigger.config;
      workflows.push({
        displayName: name,
        featureName: feature.name,
        description: workflow2.description,
        tag: workflow2.tag,
        code: workflow2.execute.code,
        params: [
          ...workflow2.execute.params ?? [],
          ...params ?? []
        ],
        structures: [
          ...workflow2.execute.structures,
          ...structures ?? []
        ],
        imports: feature.imports.map(
          (imp) => ({
            kind: StructureKind3.ImportDeclaration,
            ...imp
          })
        ),
        trigger: {
          metadata: workflow2.execute.metadata,
          sourceId: workflow2.trigger.type,
          details: {
            ...triggerConfig,
            inputs: Object.assign(
              {},
              workflow2.trigger.inputs ?? {},
              workflow2.execute.inputs
            ),
            policies: workflow2.trigger.policies
          }
        }
      });
    }
  }
  return {
    features,
    workflows
  };
}

// libs/canary/src/esbuild-plugin.ts
function esbuildPlugin(options) {
  return {
    name: "january",
    setup(build) {
      build.onStart(async () => {
        await defineConfig({
          ...options,
          formatGeneratedCode: false,
          bundle: false
        });
        await options.formatter();
      });
    }
  };
}

// libs/canary/src/index.ts
var logger = debug("january:canary");
var coreExt = {
  files: {
    "src/core/exceptions.ts": exceptions_default
  },
  packages: {
    esbuild: {
      version: "^0.25.0",
      dev: true
    },
    concurrently: { version: "9.1.2", dev: true },
    "rfc-7807-problem-details": {
      version: "^1.1.0",
      dev: false
    },
    "lodash-es": {
      version: "^4.17.21",
      dev: false
    },
    "@types/lodash-es": {
      version: "^4.17.12",
      dev: true
    },
    "@types/node": {
      version: "^20.11.26",
      dev: true
    },
    typescript: {
      version: "^5.7.0",
      dev: true
    },
    prettier: {
      version: "^3.3.3",
      dev: true
    },
    zod: {
      version: "^3.23.8",
      dev: false
    }
  }
};
async function defineConfig(config2) {
  logger(`Generating...`);
  const devDependencies = {};
  const dependencies = {};
  const scripts = {};
  logger("Collecting dependencies");
  const extensions = [coreExt, ...config2.extensions];
  for (const { packages, scripts: packageScripts } of extensions) {
    Object.assign(scripts, packageScripts ?? {});
    Object.entries(packages).forEach(([name, config3]) => {
      if (config3.dev) {
        devDependencies[name] = config3.version;
      } else {
        dependencies[name] = config3.version;
      }
    });
  }
  logger("Forming settings");
  const cwd = config2.fs?.cwd ?? process.cwd();
  const settings = {
    fs: {
      january: join6(cwd, "src", "january"),
      features: join6(cwd, "src", "january", "features"),
      tables: [join6(cwd, "src", "january", "tables.ts")],
      policies: [join6(cwd, "src", "january", "policies.ts")],
      output: config2.fs?.output ?? cwd,
      extensions: join6(cwd, "src", "january", "extensions"),
      thirdPartyExtensions: join6(cwd, "src", "app", "extensions"),
      cwd
    },
    runtime: "node",
    formatGeneratedCode: config2.formatGeneratedCode
  };
  logger("Copying user extensions");
  if (await exist(settings.fs.extensions)) {
    await cp2(
      settings.fs.extensions,
      join6(settings.fs.output, "src", "app", "extensions"),
      { recursive: true }
    );
  }
  if (await exist(settings.fs.policies[0])) {
    await cp2(
      settings.fs.policies[0],
      join6(settings.fs.output, "src", "app", "core", "policies.ts")
    );
  }
  const { concreteStructure, references } = await generate(
    settings,
    extensions
  );
  logger("To concrete structure");
  await writeFiles(
    settings.fs.output,
    Object.assign(
      {},
      ...extensions.map((it) => {
        return Object.fromEntries(
          Object.entries(it.files).map(([key, value]) => [
            key.replace(/^src\//, "src/app/"),
            value
          ])
        );
      })
    ),
    false
  );
  const packageJson = await readJson(join6(settings.fs.cwd, "package.json"));
  Object.assign(packageJson.content.dependencies, dependencies);
  Object.assign(packageJson.content.devDependencies, devDependencies);
  Object.assign(packageJson.content.scripts, scripts);
  await packageJson.write();
  logger("Writing project setup");
  if (config2.bundle) {
    await bundle({
      cwd: process.cwd(),
      projectRoot: settings.fs.output,
      entry: join6(settings.fs.output, "src", "server.ts"),
      out: join6(settings.fs.output, "build", "server.js")
    });
  }
  logger(`Generated`);
  return concreteStructure;
}
async function getChanges(settings, primitives) {
  const featurePaths = await readFolder(settings.fs.features);
  const changes = await toChanges(
    await Promise.all(
      featurePaths.map(async (feature) => {
        const featureText = await readFile3(
          join6(settings.fs.features, feature),
          "utf-8"
        );
        const def = await evaluate(
          featureText,
          merge(...[...primitives, defaultPrimitiveCallers])
        );
        return {
          workflows: def.block,
          imports: def.imports,
          name: basename2(feature).replace(extname2(feature), "")
        };
      })
    )
  );
  return {
    features: changes.features.reduce(
      (acc, curr) => [
        ...acc,
        {
          displayName: curr.displayName,
          workflows: changes.workflows.filter(
            (workflow2) => workflow2.featureName === curr.displayName
          )
        }
      ],
      []
    ).map((feature) => {
      const tags = /* @__PURE__ */ new Set();
      const featureContract = {
        ...feature,
        tags: [],
        workflows: feature.workflows.map((workflow2) => {
          const schemaName = camelcase(`${workflow2.displayName} schema`);
          const inputName = pascalcase(`${workflow2.displayName} input`);
          const inputs = workflow2.trigger.details["inputs"];
          const workflowContract = {
            inputName,
            inputs,
            description: workflow2.description,
            displayName: workflow2.displayName,
            schemaName,
            featureName: feature.displayName,
            tag: workflow2.tag,
            triggerInput: workflow2.trigger.details["triggerInput"],
            output: {
              properties: [],
              returnCode: ""
            },
            code: workflow2.code,
            structures: workflow2.structures,
            imports: workflow2.imports,
            params: workflow2.params,
            trigger: {
              metadata: workflow2.trigger.metadata,
              sourceId: workflow2.trigger.sourceId,
              // TODO: how about moving policies to the workflow level?
              policies: workflow2.trigger["details"]["policies"],
              tag: workflow2.tag,
              // NOTE: it only has effect for http triggers. we might need it for github action to support multiple webhooks
              details: workflow2.trigger.details,
              inputName,
              inputs,
              displayName: workflow2.displayName,
              featureName: feature.displayName,
              schemaName,
              operationName: snakecase2(workflow2.displayName)
            }
          };
          tags.add(workflow2.tag);
          return workflowContract;
        })
      };
      featureContract.tags = Array.from(tags);
      return featureContract;
    })
  };
}
async function generate(settings, extensions = []) {
  const concreteStructure = await getChanges(
    settings,
    extensions.map((it) => it.primitives ?? {})
  );
  logger(`Getting changes`);
  const collector = {};
  const relativeCwd = relative3(process.cwd(), settings.fs.cwd);
  const extTypesPaths = [];
  const levelsToRoot = [
    ...relativeCwd.split("/").filter(Boolean).map((_) => `..`)
  ].join("/");
  for (const ext of extensions) {
    if (ext.id) {
      extTypesPaths.push(
        `${levelsToRoot === "" ? `${levelsToRoot}` : `${levelsToRoot}/`}node_modules/@january/extensions/src/${ext.id}/index.d.ts`
      );
    }
    const fs = new ProjectFS();
    if (ext.onInit) {
      Object.assign(
        collector,
        await ext.onInit({
          fs,
          settings
        })
      );
    }
    for (const feature of concreteStructure.features) {
      if (ext.onFeature) {
        Object.assign(
          collector,
          ext.onFeature(feature, {
            fs,
            settings
          })
        );
      }
    }
  }
  logger(`Extensions ran`);
  const { save, cleanup } = emitFiles(collector, settings.fs.output);
  logger(`Emit prepared`);
  if (settings.formatGeneratedCode) {
    logger(`Formatting files`);
    await save(async (file) => {
      file.replaceWithText(
        await formatCode(file.getFullText(), getExt(file.getFilePath())).catch(
          () => {
            console.error(`Failed to format ${file.getFilePath()}`);
            return file.getFullText();
          }
        )
      );
    });
  } else {
    await save();
  }
  logger(`Files Emitted`);
  await cleanup();
  return {
    concreteStructure,
    references: extTypesPaths.map((it) => `/// <reference path="${it}" />`).join("\n")
  };
}
export {
  defineConfig,
  esbuildPlugin,
  generate
};
//# sourceMappingURL=index.js.map
