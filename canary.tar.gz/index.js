#!/usr/bin/env node
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("fs/promises");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("path");

/***/ }),
/* 3 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   emptyFile: () => (/* binding */ emptyFile),
/* harmony export */   getExt: () => (/* binding */ getExt),
/* harmony export */   getFile: () => (/* binding */ getFile),
/* harmony export */   mapFilesToTree: () => (/* binding */ mapFilesToTree),
/* harmony export */   mapFilesToTreeNodes: () => (/* binding */ mapFilesToTreeNodes),
/* harmony export */   toVirtualFile: () => (/* binding */ toVirtualFile)
/* harmony export */ });
const getExt = (fileName) => {
    if (!fileName) {
        return ''; // shouldn't happen as there will always be a file name
    }
    const ext = fileName.split('.').pop();
    if (ext === fileName) {
        // files that have no extension
        return '';
    }
    return ext || 'txt';
};
function toVirtualFile(it) {
    const parts = it.path.split('/').filter(Boolean);
    const fileName = parts.at(-1);
    return {
        isFolder: false,
        name: it.path.split('/').pop() || 'unknown',
        path: parts.join('/'),
        extension: getExt(fileName),
        content: it.content,
        metadata: {
            path: it.path,
        },
    };
}
function mapFilesToTree(files) {
    function toTree(parts, tree, content) {
        const [part, ...rest] = parts;
        if (rest.length === 0) {
            return {
                ...tree,
                [part]: content,
            };
        }
        return {
            ...tree,
            [part]: toTree(rest, tree[part] || {}, content),
        };
    }
    return files.reduce((acc, it) => {
        const parts = it.path.split('/').filter(Boolean); // ignore starting and ending slash and dobule slashes
        return toTree(parts, acc, it.content);
    }, {});
}
function mapFilesToTreeNodes(files) {
    const tree = mapFilesToTree(files);
    function toTreeNodes(tree, path = []) {
        return Object.entries(tree)
            .map(([name, value]) => {
            const newPath = [...path, name];
            if (typeof value === 'string') {
                return {
                    id: newPath.join('/'),
                    name,
                    path: newPath.join('/'),
                    metadata: {
                        path: newPath.join('/'),
                    },
                };
            }
            return {
                id: newPath.join('/'),
                name,
                children: toTreeNodes(value, newPath),
                metadata: {
                    path: newPath.join('/'),
                },
            };
        })
            .sort((a, b) => ('children' in a ? -1 : 1));
    }
    return toTreeNodes(tree);
}
function getFile(list, path) {
    const file = list.find((it) => JSON.stringify(it.path.split('/').filter(Boolean)) ===
        JSON.stringify(path.split('/').filter(Boolean)));
    if (!file) {
        throw new Error(`File not found: ${path}`);
    }
    return file;
}
function emptyFile(file = {}) {
    return {
        isFolder: false,
        name: 'unknown',
        extension: '',
        content: '',
        path: '',
        ...file,
    };
}


/***/ }),
/* 4 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatCode: () => (/* binding */ formatCode)
/* harmony export */ });
async function formatCode(code, extension, ignoreError) {
    if (!code || code.trim().length === 0)
        return '';
    function whatIsParserImport() {
        switch (extension) {
            case 'ts':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 35, 23))],
                    parserName: 'typescript',
                };
            case 'js':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 36, 23))],
                    parserName: 'babel',
                };
            case 'html':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 37, 23))],
                    parserName: 'html',
                };
            case 'css':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 38, 23))],
                    parserName: 'css',
                };
            case 'scss':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 38, 23))],
                    parserName: 'scss',
                };
            case 'json':
            case 'prettierrc':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 36, 23))],
                    parserName: 'json',
                };
            case 'md':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 39, 23))],
                    parserName: 'markdown',
                };
            case 'yaml':
            case 'yml':
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 40, 23))],
                    parserName: 'yaml',
                };
            case '':
            case 'gitignore':
            case 'prettierignore':
            case 'toml':
            case 'env':
                return {
                    parserImport: [],
                    parserName: '',
                };
            default:
                return {
                    parserImport: [Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 36, 23))],
                    parserName: 'babel',
                };
        }
    }
    const { parserImport, parserName } = whatIsParserImport();
    if (!parserName)
        return code;
    const [prettier, ...plugins] = await Promise.all([
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 41, 23)),
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 42, 23)).then((e) => e),
        ...parserImport,
    ]);
    try {
        return prettier
            .format(code, {
            parser: parserName,
            plugins: plugins,
            singleQuote: true,
        })
            .then((formattedCode) => formattedCode.trim());
    }
    catch (error) {
        if (error instanceof Error)
            if (error.name === 'SyntaxError') {
                return ignoreError === true ? '' : formatCode(code, 'ts', true);
            }
        throw error;
    }
}


/***/ }),
/* 5 */,
/* 6 */
/***/ ((module) => {

module.exports = require("better-sqlite3");

/***/ }),
/* 7 */
/***/ ((module) => {

module.exports = require("dedent");

/***/ }),
/* 8 */
/***/ ((module) => {

module.exports = require("os");

/***/ }),
/* 9 */
/***/ ((module) => {

module.exports = require("tiny-injector");

/***/ }),
/* 10 */
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),
/* 11 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 12 */
/***/ ((module) => {

module.exports = require("@automapper/classes");

/***/ }),
/* 13 */
/***/ ((module) => {

module.exports = require("@automapper/core");

/***/ }),
/* 14 */
/***/ ((module) => {

module.exports = require("stringcase");

/***/ }),
/* 15 */
/***/ ((module) => {

module.exports = require("class-validator");

/***/ }),
/* 16 */
/***/ ((module) => {

module.exports = require("@faslh/tiny-mediatr");

/***/ }),
/* 17 */
/***/ ((module) => {

module.exports = require("tslog");

/***/ }),
/* 18 */
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),
/* 19 */
/***/ ((module) => {

module.exports = require("retry");

/***/ }),
/* 20 */
/***/ ((module) => {

module.exports = require("request-ip");

/***/ }),
/* 21 */
/***/ ((module) => {

module.exports = require("sql-parser-cst");

/***/ }),
/* 22 */
/***/ ((module) => {

module.exports = require("ts-morph");

/***/ }),
/* 23 */
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),
/* 24 */
/***/ ((module) => {

module.exports = require("ajv-errors");

/***/ }),
/* 25 */
/***/ ((module) => {

module.exports = require("ajv-formats");

/***/ }),
/* 26 */
/***/ ((module) => {

module.exports = require("validator");

/***/ }),
/* 27 */
/***/ ((module) => {

module.exports = require("fs");

/***/ }),
/* 28 */
/***/ ((module) => {

module.exports = require("js-yaml");

/***/ }),
/* 29 */
/***/ ((module) => {

module.exports = require("openapi3-ts/oas31");

/***/ }),
/* 30 */
/***/ ((module) => {

module.exports = require("deepmerge");

/***/ }),
/* 31 */
/***/ ((module) => {

module.exports = require("events");

/***/ }),
/* 32 */
/***/ ((module) => {

module.exports = require("esbuild");

/***/ }),
/* 33 */
/***/ ((module) => {

module.exports = require("esbuild-node-externals");

/***/ }),
/* 34 */
/***/ ((module) => {

module.exports = require("pluralize");

/***/ }),
/* 35 */
/***/ ((module) => {

module.exports = require("prettier/plugins/typescript");

/***/ }),
/* 36 */
/***/ ((module) => {

module.exports = require("prettier/plugins/babel");

/***/ }),
/* 37 */
/***/ ((module) => {

module.exports = require("prettier/plugins/html");

/***/ }),
/* 38 */
/***/ ((module) => {

module.exports = require("prettier/plugins/postcss");

/***/ }),
/* 39 */
/***/ ((module) => {

module.exports = require("prettier/plugins/markdown");

/***/ }),
/* 40 */
/***/ ((module) => {

module.exports = require("prettier/plugins/yaml");

/***/ }),
/* 41 */
/***/ ((module) => {

module.exports = require("prettier/standalone");

/***/ }),
/* 42 */
/***/ ((module) => {

module.exports = require("prettier/plugins/estree");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/require chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "loaded", otherwise not loaded yet
/******/ 		var installedChunks = {
/******/ 			0: 1
/******/ 		};
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		var installChunk = (chunk) => {
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids, runtime = chunk.runtime;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 1;
/******/ 		
/******/ 		};
/******/ 		
/******/ 		// require() chunk loading for javascript
/******/ 		__webpack_require__.f.require = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					installChunk(require("./" + __webpack_require__.u(chunkId)));
/******/ 				} else installedChunks[chunkId] = 1;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		// no external install chunk
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  writeFiles: () => (/* binding */ writeFiles)
});

;// CONCATENATED MODULE: external "child_process"
const external_child_process_namespaceObject = require("child_process");
;// CONCATENATED MODULE: external "commander"
const external_commander_namespaceObject = require("commander");
// EXTERNAL MODULE: external "fs/promises"
var promises_ = __webpack_require__(1);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(2);
// EXTERNAL MODULE: ../utils/formatter/src/lib/format-code.ts
var format_code = __webpack_require__(4);
// EXTERNAL MODULE: ../compiler/generator/utils/src/index.ts
var src = __webpack_require__(3);
;// CONCATENATED MODULE: ./src/index.ts
//#!/usr/bin/env node






const BASIC_EXTENSIONS = {
    core: {},
    identity: {},
    hono: {},
    postgresql: {
        CONNECTION_STRING: '@process:env.CONNECTION_STRING',
    },
    fly: {
        FLY_API_TOKEN: '@build:secrets.FLY_API_TOKEN',
        FLY_APP_NAME: '@build:secrets.FLY_APP_NAME',
    },
};
const projectDir = process.cwd();
const cli = external_commander_namespaceObject.program
    .name('january')
    .version('1.0.0')
    .description('January')
    .helpOption('-h, --help', 'Display help for command')
    .helpCommand('help [command]', 'Display help for command');
cli
    .command('init')
    .argument('<name>', 'Name to greet')
    .action(async (name) => {
    const dir = (0,external_path_.join)(projectDir, name);
    const initialProjectCode = `import {  feature,  field,  mandatory,  policy,  project,  table,  trigger,  useTable,  workflow,} from '@january/declarative';\n\nexport default project();`;
    await writeFiles(dir, {
        '.vscode/settings.json': {
            'files.autoSave': 'afterDelay',
            'files.autoSaveWhenNoErrors': false,
            'files.refactoring.autoSave': true,
            'files.autoSaveDelay': 500,
        },
        'package.json': {
            name: name,
            version: '1.0.0',
            workspaces: ['output'],
            scripts: {
                start: 'npm run start:dev -w output',
                build: 'node --watch-path ./src ./node_modules/@january/canary generate',
            },
            dependencies: {
                prettier: '^3.3.3',
                '@january/declarative': 'https://github.com/JanuaryLabs/dist/raw/main/declarative.tar.gz',
                '@january/extensions': 'https://github.com/JanuaryLabs/dist/raw/main/extensions.tar.gz',
                '@january/canary': 'https://github.com/JanuaryLabs/dist/raw/main/canary.tar.gz',
            },
        },
        'tsconfig.json': {
            extends: './output/tsconfig.json',
            include: ['src/**/*.ts'],
            exclude: ['vite.config.ts', 'src/**/*.spec.ts', 'src/**/*.test.ts'],
            compilerOptions: {
                rootDir: '.',
                moduleResolution: 'Bundler',
                module: 'ESNext',
            },
        },
        'extensions.json': {},
        '.prettierignore': '/dist\n/coverage',
        '.prettierrc': {
            singleQuote: true,
            importOrder: ['^./main$', '<THIRD_PARTY_MODULES>', '^[./]'],
            importOrderSeparation: true,
            importOrderSortSpecifiers: true,
            importOrderParserPlugins: ['typescript', 'decorators-legacy'],
        },
        '.gitignore': await fetch('https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore')
            .then((res) => res.text())
            .then((it) => it + '\noutput/'),
        'src/project.ts': initialProjectCode,
        'src/extensions/user/index.ts': '',
    });
    const { generate } = await __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(__webpack_require__, 5));
    const outputDir = (0,external_path_.join)(dir, 'output');
    await generate(initialProjectCode, BASIC_EXTENSIONS, outputDir);
    (0,external_child_process_namespaceObject.execSync)('npm install --no-audit --no-fund', {
        cwd: dir,
        encoding: 'utf-8',
        stdio: 'inherit',
    });
});
cli.command('generate').action(async () => {
    const outputDir = (0,external_path_.join)(projectDir, 'output');
    const code = await (0,promises_.readFile)((0,external_path_.join)(projectDir, 'src', 'project.ts'), 'utf-8');
    const extensions = JSON.parse(await (0,promises_.readFile)((0,external_path_.join)(projectDir, 'extensions.json'), 'utf-8'));
    const { generate } = await __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(__webpack_require__, 5));
    await generate(code, {
        ...BASIC_EXTENSIONS,
        ...extensions,
    }, outputDir);
});
external_commander_namespaceObject.program.parse(process.argv);
async function writeFiles(dir, contents) {
    for (const [file, content] of Object.entries(contents)) {
        const filePath = (0,external_path_.isAbsolute)(file) ? file : (0,external_path_.join)(dir, file);
        await (0,promises_.mkdir)((0,external_path_.dirname)(filePath), { recursive: true });
        await (0,promises_.writeFile)(filePath, await (0,format_code.formatCode)(typeof content === 'string' ? content : JSON.stringify(content), (0,src.getExt)(file)), 'utf-8');
    }
}

module.exports = __webpack_exports__;
/******/ })()
;
//# sourceMappingURL=index.js.map