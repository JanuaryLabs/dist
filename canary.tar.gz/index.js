import { createRequire } from 'module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/sdk/parser/src/index.ts
var src_exports = {};
__export(src_exports, {
  Checker: () => Checker,
  getExports: () => getExports,
  legacy_parse: () => legacy_parse,
  parse: () => parse
});
import { readFileSync } from "fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const featureExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!featureExpr) {
    return null;
  }
  if (!checker.isCallExpression(featureExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(featureExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
async function getExports(code) {
  const ast = await parseCode(code);
  if (!ast) {
    return [];
  }
  return ast.body.filter(isExportItem);
}
var checker, Checker, isWorker, exportTypes;
var init_src = __esm({
  "libs/sdk/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      __name(isKeyValueProperty, "isKeyValueProperty");
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      __name(isNullLiteral, "isNullLiteral");
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      __name(isIdentifier, "isIdentifier");
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      __name(isMemberExpression, "isMemberExpression");
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(Checker || (Checker = {}));
    isWorker = /* @__PURE__ */ __name(() => {
      return typeof global.importScripts === "function";
    }, "isWorker");
    __name(isRecord, "isRecord");
    __name(isSpan, "isSpan");
    __name(adjustOffsetOfAst, "adjustOffsetOfAst");
    __name(parseCode, "parseCode");
    __name(legacy_parse, "legacy_parse");
    __name(parse, "parse");
    __name(getImports, "getImports");
    __name(resolveAsExpression, "resolveAsExpression");
    __name(resolveCallExpression, "resolveCallExpression");
    __name(resolveUnaryExpression, "resolveUnaryExpression");
    __name(resolveArrayExpression, "resolveArrayExpression");
    __name(resolveObjectExpression, "resolveObjectExpression");
    __name(resolveMemberExpression, "resolveMemberExpression");
    exportTypes = [
      "ExportAllDeclaration",
      "ExportDeclaration",
      "ExportDefaultDeclaration",
      "ExportDefaultExpression",
      "ExportNamedDeclaration",
      "ImportDeclaration"
    ];
    __name(isExportItem, "isExportItem");
    __name(getExports, "getExports");
  }
});

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index2, item] = byId(array, id);
  if (item) {
    array[index2] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index2, item] = byId(array, id);
  if (item) {
    array[index2] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index2 = array.findIndex((it) => it.id === id);
  return [index2, array[index2]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input2 = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input2 === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input2 !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve2, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve2(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config2) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config2.accessor(item)]: config2.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve2) => setTimeout(resolve2, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config2) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config2.featureName),
        snakecase(config2.workflowTag),
        toCurlyBraces(config2.workflowPath)
      )
    )
  );
  return config2.workflowMethod ? `${config2.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve2, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve2(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where2 = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where2}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input2) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input2));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where2 = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where2,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input2) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input2));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input2) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input2));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input2) {
  let index2 = 0;
  const tokens = [];
  let lexeme = "";
  while (index2 < input2.length) {
    const char = input2[index2];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "!":
        if (input2[index2 + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index2
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index2
          });
          index2 += 2;
        } else {
          lexeme += char;
          index2++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index2
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index2
        });
        index2++;
        break;
      case "'":
      case '"':
        {
          index2++;
          while (input2[index2] !== "'" && input2[index2] !== '"') {
            lexeme += input2[index2];
            index2++;
          }
          index2++;
          const column = index2;
          if (input2[index2] === "]") {
            lexeme += input2[index2];
            index2++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index2
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index2
        });
        index2++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index2
        });
        index2++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index2
          });
          lexeme = "";
        }
        index2++;
        break;
      default:
        lexeme += char;
        index2++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input2) {
  return toSimple(input2);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input2) {
    super(tokeniser(input2));
    this.input = input2;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index: index2 } = parser.subparse();
    this.currentIdx += index2;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input2) {
  const parser = new DSLParser(input2);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index2) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index2 + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index2) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index2 + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index2) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index2;
    });
    return lexeme;
  }
  replaceLexeme(index2, value) {
    const lexeme = this.nearestLexeme(index2);
    console.log({ lexeme, index: index2 });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index2 = 0;
  const lexemes = [];
  while (index2 < prompt.length) {
    const char = prompt[index2];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index2++],
          column: index2
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index2++],
          column: index2
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index2
          };
          token.value += char;
          index2++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input2) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input2));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/compiler/sdk/dynamic-source/src/lib/dynamic-source.ts
import { InjectionToken } from "tiny-injector";
var DYNAMIC_SOURCE_MAPPER = new InjectionToken(`a token to hold dynamic source mapper`);
var DynamicSource = class {
  static {
    __name(this, "DynamicSource");
  }
  typesResolverMap = {
    date: "Date"
  };
  #get(featureId, url, ...args) {
    const fetcher = this._mapper(featureId);
    if (!fetcher) {
      throw new Error(`No mapping found ${url}`);
    }
    const obs = fetcher[url];
    if (!obs) {
      throw new Error(`No matching found for url ${url}`);
    }
    if (typeof obs === "function") {
      return obs(...args);
    }
    return obs;
  }
  async resolveSource(featureId, source, details) {
    let _source = source;
    if (isCondition(source)) {
      _source = applyCondition(source, details);
    }
    if (!isResolvable(_source)) {
      return _source;
    }
    if (Array.isArray(_source)) {
      return _source;
    }
    const { url, params } = buildUrl(
      _source.url,
      details,
      _source.binding ?? {}
    );
    if (!url) return [];
    return this.#get(featureId, url, ...params);
  }
  async resolvePrimitiveType(featureId, primitiveType, context, resolver) {
    if (!primitiveType) {
      return "";
    }
    if (typeof primitiveType === "string") {
      return this.typesResolverMap[primitiveType] || primitiveType;
    }
    if (isCondition(primitiveType)) {
      return applyCondition(primitiveType, context);
    }
    const maybeThisWillWork = resolver(primitiveType);
    if (isCondition(maybeThisWillWork)) {
      return applyCondition(maybeThisWillWork, context);
    }
    return this.resolveSource(featureId, maybeThisWillWork, context);
  }
};

// libs/compiler/sdk/platform/src/lib/features.sdk.ts
import {
  Injectable,
  InjectionToken as InjectionToken2,
  Injector,
  ServiceLifetime
} from "tiny-injector";
var Features = class {
  changes = Injector.GetRequiredService(CHANGES_PROJECTION_TOKEN);
  list() {
    return this.changes.features;
  }
  async get(id) {
    const feature2 = this.changes.features.find((it) => it.id === id);
    if (!feature2) {
      throw new Error(`Feature ${id} not found`);
    }
    return feature2;
  }
};
__name(Features, "Features");
Features = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], Features);
var CHANGES_PROJECTION_TOKEN = new InjectionToken2(
  "CHANGES_PROJECTION_TOKEN"
);

// libs/compiler/sdk/devkit/src/lib/data/actions.json
var actions_default = [
  {
    id: "077b1325-0ade-4f63-8f66-ced39cef38ba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Atomic",
    name: "atomic",
    visible: true,
    multi: true,
    allowedActions: [],
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "9c858969-f48b-4b72-8282-bfe82654ae9a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Delete Record",
    name: "delete-record",
    visible: true,
    output: {
      displayName: "deletedRecord",
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    },
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      cascade: {
        displayName: "Cascade",
        type: "boolean",
        defaultValue: true,
        required: true,
        visible: false
      }
    }
  },
  {
    id: "b036bc50-9292-486a-9714-1f551fee5dc4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Record Exist",
    name: "check-record-existance",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: false,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "recordExists",
      source: [
        {
          id: "recordExists",
          primitiveType: "boolean",
          displayName: "recordExists"
        }
      ]
    }
  },
  {
    id: "83ce1e80-0117-4ebc-86ac-3bdad3b32796",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Insert Record",
    name: "insert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      columns: {
        displayName: "Payload",
        type: "columns-list",
        required: false,
        source: {
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ],
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "2bb630dd-7ba3-4cda-95a7-f65ee22116ee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Raw SQL Query",
    name: "raw-sql-query",
    metadata: {
      query: {
        displayName: "Query",
        type: "string",
        required: true
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "62e55ba2-9a81-4f88-995e-2093ca3fc067",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Upsert Record",
    name: "upsert-record",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select"
      },
      columns: {
        displayName: "Payload",
        type: "columns-list"
      }
    },
    output: {
      displayName: "inserted",
      outputName: {
        url: "/tables/:id",
        binding: {
          id: "context.tableId"
        },
        format: "new @source.displayName"
      },
      source: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.tableId"
        }
      }
    }
  },
  {
    id: "a8ded515-b99e-4fca-9654-7d2c12624a7a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "increment-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "b5a5e901-9ef8-4d2c-86f2-39263ca8ebee",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Increment Field",
    name: "decrement-field",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true
      },
      column: {
        displayName: "Field",
        type: "string",
        required: true
      }
    }
  },
  {
    output: {
      type: "context.tableId",
      displayName: "updatedRecord",
      source: []
    },
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Set Fields",
    name: "set-fields",
    metadata: {
      tableId: {
        displayName: "Table",
        type: "single-select",
        required: true,
        source: {
          url: "/tables"
        }
      },
      query: {
        displayName: "Filter",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      },
      columns: {
        displayName: "Field",
        type: "columns-list",
        required: true,
        source: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          },
          except: [
            "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
            "6c09acb6-e45a-479f-be05-c391dfbced8e"
          ]
        }
      }
    }
  },
  {
    id: "0eeac945-4dcd-40ff-be62-1ad371406ae4",
    extensionId: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    displayName: "With i18n",
    name: "i18n"
  },
  {
    id: "3c40908c-1c69-4222-a936-7a569a1198b5",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "Upload file to google storage",
    name: "upload-file",
    output: {
      displayName: "uploadedFile",
      source: []
    },
    metadata: {
      multiple: {
        displayName: "Can upload multiple files",
        type: "boolean",
        required: false,
        defaultValue: "@fixed:false"
      },
      maxFileCount: {
        displayName: "Maximum file count",
        type: "number",
        required: false,
        defaultValue: "@fixed:1",
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxTotalSize: {
        displayName: "Maximum total size",
        type: "number",
        required: false,
        if: {
          operator: "equal",
          input: "context.multiple",
          value: true
        }
      },
      maxFileSize: {
        displayName: "Maximum file size",
        type: "number",
        required: false
      }
    }
  },
  {
    id: "c4ec127b-e167-4a30-8544-732c55d1bd24",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "List Records",
    name: "list-records",
    metadata: {
      localizable: {
        displayName: "Localizable",
        type: "boolean",
        required: false,
        fieldset: "first",
        visible: false,
        defaultValue: "false"
      },
      pagination: {
        displayName: "Pagination",
        type: "single-select",
        required: true,
        fieldset: "pagination",
        defaultValue: "deferred_joins",
        source: [
          {
            id: "none",
            displayName: "None"
          },
          {
            id: "limit_offset",
            displayName: "Limit & Offset"
          },
          {
            id: "deferred_joins",
            displayName: "Deferred Joins"
          },
          {
            id: "cursor",
            displayName: "Cursor"
          }
        ]
      },
      tableId: {
        displayName: "Table",
        type: "single-select",
        fieldset: "first",
        required: true,
        source: {
          url: "/tables"
        }
      },
      limit: {
        displayName: "Limit",
        type: "number",
        required: false,
        fieldset: "pagination",
        defaultValue: 50
      },
      query: {
        displayName: "Query",
        type: "query-builder",
        required: true,
        source: {
          url: "/tables/:id",
          binding: {
            id: "context.tableId"
          }
        }
      }
    },
    output: {
      source: {
        input: "context.pagination",
        operator: "equal",
        value: "none",
        then: {
          url: "/tables/:id/fields",
          binding: {
            id: "context.tableId"
          }
        },
        else: [
          {
            id: "records",
            displayName: "records",
            primitiveType: {
              input: "context.limit",
              operator: "equal",
              value: 1,
              then: "object",
              else: "array"
            },
            typeName: {
              url: "/tables/:id",
              binding: {
                id: "context.tableId"
              },
              use: "displayName"
            },
            interface: {
              url: "/tables/:id/fields",
              binding: {
                id: "context.tableId"
              }
            },
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          },
          {
            id: "meta",
            displayName: "meta",
            typeName: "Meta",
            primitiveType: "object",
            interface: [
              {
                id: "hasNextPage",
                displayName: "hasNextPage",
                primitiveType: "boolean"
              },
              {
                id: "hasPreviousPage",
                displayName: "hasPreviousPage",
                primitiveType: "boolean"
              },
              {
                id: "pageSize",
                displayName: "pageSize",
                primitiveType: "number"
              },
              {
                id: "currentPage",
                displayName: "currentPage",
                primitiveType: "number"
              },
              {
                id: "totalCount",
                displayName: "totalCount",
                primitiveType: "number"
              },
              {
                id: "totalPages",
                displayName: "totalPages",
                primitiveType: "number"
              }
            ],
            if: {
              input: "context.pagination",
              operator: "equal",
              value: "none",
              then: true,
              else: false
            }
          }
        ]
      }
    }
  },
  {
    id: "89ad4cdb-2ed1-4c42-84bd-4986648bbfe2",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    displayName: "List Files",
    name: "list-files",
    output: {
      displayName: "files",
      source: []
    },
    metadata: {
      prefix: {
        displayName: "Prefix",
        type: "string",
        required: false,
        fieldset: "first"
      },
      flat: {
        displayName: "Flat",
        type: "boolean",
        required: false,
        fieldset: "first"
      }
    }
  },
  {
    id: "43ea3f72-f3b0-419f-abef-f1bd4b5e9b22",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Custom Code",
    name: "custom-code",
    output: {
      source: []
    },
    metadata: {
      code: {
        displayName: "Code",
        type: "code-editor",
        required: true,
        extras: {
          language: "typescript"
        }
      }
    }
  },
  {
    id: "e0c60892-6b26-417e-8140-8e8d31f64ab2",
    extensionId: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    displayName: "Branch",
    name: "branch",
    type: "branch",
    multi: true,
    output: {
      source: []
    },
    metadata: {}
  },
  {
    id: "89e16a38-25f1-444e-bcf7-96e6455c3707",
    extensionId: "485654c6-06fc-425e-9ba6-341ec2c9ae07",
    displayName: "Send Email",
    name: "send-email",
    output: {
      outputName: "sentEmail",
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        required: true,
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        required: true,
        fieldset: "email"
      },
      replayTo: {
        displayName: "Replay To",
        type: "string",
        required: false
      },
      subject: {
        displayName: "Subject",
        type: "string",
        required: true,
        fieldset: "content"
      },
      templateId: {
        displayName: "Template",
        type: "string",
        fieldset: "content",
        required: true
      }
    }
  },
  {
    id: "69a01ada-a83a-451f-a3fe-fb486e08ffa9",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Send Email",
    name: "resend-send-email",
    output: {
      source: []
    },
    metadata: {
      from: {
        displayName: "From",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      to: {
        displayName: "To",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "email"
      },
      subject: {
        displayName: "Subject",
        type: "string",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ],
        fieldset: "content"
      },
      text: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      html: {
        displayName: "Text",
        type: "string",
        fieldset: "content",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "c292a9d7-1f66-47b9-b366-e25f3faff840",
    extensionId: "ee5d3a3a-501a-4653-914e-d3665760f7bf",
    displayName: "Resend: Create Contact",
    name: "resend-create-contact",
    output: {
      source: []
    },
    metadata: {
      firstName: {
        displayName: "First name",
        type: "string",
        fieldset: "general"
      },
      lastName: {
        displayName: "Last name",
        type: "string",
        required: false,
        fieldset: "general"
      },
      email: {
        displayName: "Email",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      },
      unsubscribed: {
        displayName: "Unsubscribed",
        type: "string",
        required: false,
        fieldset: "email"
      },
      audienceId: {
        displayName: "Audience id",
        type: "string",
        fieldset: "email",
        validations: [
          {
            name: "mandatory",
            details: { value: "true" }
          }
        ]
      }
    }
  },
  {
    id: "b3b5b8a0-5b0a-4b0a-8e9a-9f8b8b8b8b8b",
    extensionId: "389d81cd-5b58-4ade-b815-add468c48e37",
    displayName: "Ajax",
    name: "ajax",
    output: {
      source: []
    },
    metadata: {
      url: {
        displayName: "URL",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      method: {
        displayName: "Method",
        type: "inline",
        required: true,
        fieldset: "first"
      },
      body: {
        displayName: "Body",
        type: "json",
        required: false
      }
    }
  },
  {
    id: "7a9d9a29-7079-4aa8-bdc0-d93a713a2440",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger",
    metadata: {
      path: {
        fieldset: "config",
        type: "string",
        displayName: "Path",
        required: true,
        pattern: "^(/|((/){0,1}({[a-zA-Z]+}|[^/{}]+)(/){0,1})*)$"
      },
      method: {
        fieldset: "config",
        displayName: "Method",
        type: "single-select",
        source: [
          {
            id: "get",
            displayName: "GET"
          },
          {
            id: "post",
            displayName: "POST"
          },
          {
            id: "put",
            displayName: "PUT"
          },
          {
            id: "patch",
            displayName: "PATCH"
          },
          {
            id: "delete",
            displayName: "DELETE"
          },
          {
            id: "head",
            displayName: "HEAD"
          }
        ],
        required: true
      },
      contentType: {
        visible: false,
        fieldset: "optional",
        type: "single-select",
        displayName: "Content Type",
        required: false,
        source: [
          {
            id: "application/json",
            displayName: "application/json"
          },
          {
            id: "application/x-www-form-urlencoded",
            displayName: "application/x-www-form-urlencoded"
          },
          {
            id: "multipart/form-data",
            displayName: "multipart/form-data"
          }
        ]
      },
      summary: {
        fieldset: "optional",
        type: "string",
        displayName: "Summary",
        required: false,
        visible: false
      }
    }
  },
  {
    id: "0aec7685-5c19-43eb-bc2c-93597b5cecfc",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    id: "6432f258-6511-4d8a-86a6-628db3f333e7",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    id: "7b1696e9-9c89-4ba7-abc0-e1448b287772",
    extensionId: "9c034274-069e-4567-ab33-bab8f31f874c",
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    id: "11e4e048-cf30-4fa1-b0ff-25baa7a5f416",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "File Trigger",
    name: "file",
    type: "trigger"
  },
  {
    id: "0bd0b432-5f7a-447a-afab-6db83d8976b1",
    extensionId: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    id: "cd76caa3-e9f0-49b8-bf7a-0ebed83bd486",
    extensionId: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];

// libs/compiler/sdk/devkit/src/lib/data/extensions.json
var extensions_default = [
  {
    id: "e2b0b8a0-5b7a-4b0a-9b0a-9b8b8b8b8b8b",
    visible: false,
    name: "soft-delete",
    categories: ["soft-delete"],
    title: "",
    subtitle: "Support Soft Delete functionality in any table.",
    description: "Soft delete is a way to mark data as deleted instead of actually deleting it. This is useful for auditing purposes and to prevent accidental data loss.",
    tableMetadata: {
      tableId: {
        displayName: "Support Soft Delete",
        required: false,
        visible: false,
        type: "single-select",
        source: [
          {
            id: "none",
            displayName: "No soft delete"
          },
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag"
          },
          {
            id: "trash",
            displayName: "Using trash table"
          }
        ]
      }
    },
    metadata: {}
  },
  {
    id: "339b60c7-7b1c-49e1-b1dd-716c2e3ab334",
    visible: true,
    name: "core",
    categories: ["misc"],
    title: "Core",
    main: "src/core/validation.ts",
    subtitle: "Core functionality",
    metadata: {},
    description: "Essential functionality that is required for all projects."
  },
  {
    id: "977a059f-ddda-4677-b785-4d1b04a7c201",
    visible: true,
    name: "prettier",
    categories: ["misc"],
    title: "Prettier",
    subtitle: "An opinionated code formatter",
    description: "Prettier is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary.",
    logo: "assets/prettier.png",
    metadata: {}
  },
  {
    id: "e81b26bb-051b-4b30-a94d-e34ad615504c",
    visible: true,
    name: "identity",
    categories: ["misc"],
    title: "identity",
    subtitle: "identity",
    description: "",
    metadata: {}
  },
  {
    id: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "postgresql",
    categories: ["database"],
    main: "src/extensions/postgresql/index.ts",
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "PostgreSQL",
    subtitle: "A free and open-source relational database management system emphasizing extensibility and SQL compliance.",
    description: "PostgreSQL is a powerful, open source object-relational database system. It has more than 15 years of active development and a proven architecture that has earned it a strong reputation for reliability, data integrity, and correctness.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "71c97a1c-3efe-4712-b35b-56714dafa02f",
    name: "mysql",
    categories: ["database"],
    disabled: true,
    metadata: {
      orm: {
        displayName: "ORM",
        type: "inline",
        defaultValue: "@fixed:typeorm",
        source: ["@fixed:typeorm"],
        description: "The ORM to use",
        required: true
      },
      i18n: {
        displayName: "i18n",
        type: "inline",
        defaultValue: "@fixed:none",
        description: "Whether to enable internationalization (i18n) or not",
        source: [
          {
            displayName: "None",
            id: "@fixed:none"
          },
          {
            displayName: "Default",
            id: "@fixed:default"
          }
        ],
        required: true
      },
      CONNECTION_STRING: {
        description: "The connection string to the database",
        displayName: "Connection String",
        type: "string",
        defaultValue: "@process:env.CONNECTION_STRING",
        required: true
      }
    },
    tableMetadata: {
      softDelete: {
        displayName: "Support Soft Delete",
        required: true,
        type: "single-select",
        visible: false,
        defaultValue: "@fixed:at",
        source: [
          {
            id: "at",
            displayName: "Using deletedAt column"
          },
          {
            id: "flag",
            displayName: "Using deleted flag",
            visible: false
          },
          {
            id: "trash",
            displayName: "Using trash table",
            visible: false
          }
        ]
      }
    },
    svg: "SiPostgresql",
    title: "MySQL",
    description: "MySQL is an open-source relational database management system.",
    logo: "assets/postgresql.svg"
  },
  {
    id: "1e8e1778-4be6-4346-aa79-9955f9e422a4",
    name: "firebase-functions",
    categories: ["hosting"],
    disabled: true,
    logo: "assets/firebase-functions.png",
    svg: "SiFirebase",
    title: "Firebase Functions",
    subtitle: "Cloud Functions for Firebase is a serverless framework that lets you automatically run backend code",
    description: "Firebase Functions is a serverless framework that lets you automatically run backend code.",
    metadata: {
      FIREBASE_FUNCTION_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_PROJECT_ID"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@build:secrets.FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY"
      }
    }
  },
  {
    id: "d9e83836-e41d-4ae2-aa93-229a0ef27069",
    name: "firebase-auth",
    categories: ["identity"],
    disabled: false,
    main: "firebase.ts",
    metadata: {
      FIREBASE_AUTH_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        required: true,
        type: "json",
        defaultValue: "@process:env.FIREBASE_AUTH_SERVICE_ACCOUNT_KEY"
      }
    },
    title: "Firebase Authentication",
    description: "Firebase Authentication provides backend services, easy-to-use SDKs, and ready-made UI libraries to authenticate users to your app.",
    subtitle: "Authenticate users with Firebase"
  },
  {
    id: "34d9ec05-de0d-4d79-ae2a-9a06200d20dd",
    name: "fly",
    categories: ["hosting"],
    logo: "assets/fly.png",
    title: "Fly",
    description: "Fly is a platform for applications that need to run globally. It runs your code close to users and scales compute in cities where your app is busiest.",
    metadata: {
      FLY_API_TOKEN: {
        displayName: "Deploy Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_API_TOKEN",
        description: "The token to deploy the app"
      },
      FLY_APP_NAME: {
        displayName: "App Name",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.FLY_APP_NAME",
        description: "The name of the app"
      }
    }
  },
  {
    name: "vercel",
    id: "4c82c872-1a2f-4849-98a6-bd7017498191",
    categories: ["hosting"],
    title: "Vercel",
    description: "Vercel combines the best developer experience with an obsessive focus on end-user performance. Our platform enables frontend teams to do their best work.",
    metadata: {
      VERCEL_ORG_ID: {
        displayName: "Org ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_ORG_ID"
      },
      VERCEL_PROJECT_ID: {
        displayName: "Project ID",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_PROJECT_ID"
      },
      VERCEL_API_TOKEN: {
        displayName: "API Token",
        required: true,
        type: "string",
        defaultValue: "@build:secrets.VERCEL_API_TOKEN"
      }
    }
  },
  {
    id: "0d9101cf-7c31-4ac5-bcad-620acb566cce",
    name: "hono",
    categories: ["routing"],
    title: "Hono.dev",
    main: "src/extensions/tus/index.ts",
    description: "Hono is an ultrafast and lightweight web framework that allows developers to build web applications that run on multiple platforms like Cloudflare, Fastly, Deno, Bun, AWS, and Node.js from the same codebase.",
    metadata: {}
  },
  {
    id: "109aa1af-f9d0-4d31-bbc6-c4603be5b7b0",
    name: "koajs",
    disabled: true,
    categories: ["routing"],
    title: "Koa.js",
    description: "Koa is a web framework designed by the team behind Express, which aims to be a smaller, more expressive, and more robust foundation for web applications and APIs.",
    logo: "assets/http.svg",
    metadata: {},
    svg: "SiKoa",
    packages: [
      {
        name: "koa",
        version: "latest"
      },
      {
        name: "koa-static",
        version: "latest"
      },
      {
        name: "@types/koa-static",
        version: "latest"
      },
      {
        name: "@koa/router",
        version: "latest"
      },
      {
        name: "koa-body",
        version: "latest"
      },
      {
        name: "koa-bodyparser",
        version: "latest"
      },
      {
        name: "koa-logger",
        version: "latest"
      },
      {
        name: "koa-qs",
        version: "latest"
      },
      {
        name: "@koa/cors",
        version: "latest"
      },
      {
        name: "@types/koa-logger",
        version: "latest"
      },
      {
        name: "@types/koa__cors",
        version: "^3.3.0"
      },
      {
        name: "@types/koa__router",
        version: "^12.0.0"
      },
      {
        name: "@types/koa-bodyparser",
        version: "^4.3.10"
      },
      {
        name: "@types/koa-qs",
        version: "^2.0.0"
      },
      {
        name: "swagger-ui-dist",
        version: "latest"
      },
      {
        name: "@types/swagger-ui-dist",
        version: "latest"
      }
    ]
  },
  {
    id: "3633c476-c120-4f9f-893b-b6b03f67b9e9",
    name: "expressjs",
    svg: "SiExpress",
    disabled: true,
    categories: ["routing"],
    title: "Express.js",
    description: "Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
    logo: "assets/http.svg",
    metadata: {},
    packages: [
      {
        name: "express",
        version: "latest"
      },
      {
        name: "body-parser",
        version: "latest"
      },
      {
        name: "morgan",
        version: "latest"
      },
      {
        name: "cors",
        version: "latest"
      },
      {
        name: "@types/express",
        version: "latest",
        dev: true
      },
      {
        name: "@types/body-parser",
        version: "latest",
        dev: true
      },
      {
        name: "@types/cors",
        version: "latest",
        dev: true
      },
      {
        name: "@types/morgan",
        version: "latest",
        dev: true
      }
    ]
  },
  {
    id: "3e184f8b-d2dc-4592-9507-979d649277f5",
    visible: true,
    name: "gcs",
    categories: ["file-storage"],
    logo: "assets/cloud-storage.svg",
    title: "Google Cloud Storage",
    description: "Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure. The service combines the performance and scalability of Google's cloud with advanced security and sharing capabilities.",
    main: "src/extensions/gcs/index.ts",
    metadata: {
      BUCKET_NAME: {
        _comment: "// should the bucket name be stored here? a user might create multiple pages, a bucket for each, in this setup that requirement won't work",
        displayName: "Bucket Name",
        type: "string",
        required: true,
        description: "The name of the bucket"
      },
      FIREBASE_FUNCTION_SERVICE_ACCOUNT_KEY: {
        displayName: "Service Account Key (JSON)",
        type: "json",
        description: "The service account key to access the bucket",
        required: true
      }
    }
  },
  {
    id: "9c034274-069e-4567-ab33-bab8f31f874c",
    visible: true,
    name: "github",
    categories: [],
    title: "GitHub Webhooks",
    description: "GitHub Webhooks allow you to build or set up integrations that subscribe to certain events on GitHub.com",
    metadata: {
      WEBHOOK_SECRET: {
        displayName: "Webhook Secret",
        defaultValue: "@process:env.WEBHOOK_SECRET",
        type: "string",
        required: true
      }
    }
  },
  {
    id: "4320a2a1-bab9-4ca8-bab5-eb56280933c6",
    visible: true,
    name: "node-cron",
    categories: ["schedulers"],
    title: "Node Cron",
    description: "A simple cron-like job scheduler for Node.js",
    metadata: {},
    packages: [
      {
        name: "@types/node-cron",
        version: "^3.0.11",
        dev: true
      },
      {
        name: "node-cron",
        version: "^3.0.3"
      }
    ]
  },
  {
    id: "389d81cd-5b58-4ade-b815-add468c48e37",
    visible: true,
    disabled: true,
    name: "ajax",
    categories: ["misc"],
    logo: "assets/ajax.png",
    title: "Ajax",
    description: "Ajax is a set of web development techniques using many web technologies on the client side to create asynchronous web applications. With Ajax, web applications can send and retrieve data from a server asynchronously without interfering with the display and behavior of the existing page.",
    metadata: {},
    svg: "SiAjax"
  },
  {
    id: "8c438fcd-b8c0-444e-9100-24abd93a6bcb",
    visible: true,
    disabled: true,
    name: "sqlite",
    categories: ["database"],
    main: "src/extensions/sqlite/index.ts",
    title: "Sqlite",
    description: "Sqlite is a relational database management system.",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/fields.json
var fields_default = [
  {
    id: "23bfb249-0149-4033-a2a9-2dbec614d461",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "bytes",
    primitiveType: "Uint8Array",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      }
    },
    initialValidation: []
  },
  {
    id: "87c7ba43-9c31-4080-9e82-453feb763789",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Short Text",
    description: "Short Text is perfect for short text fields like name, email, phone, etc.",
    name: "short-text",
    icon: "text_format",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "1e39950b-1af8-4721-a6e0-a304b96431f2",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Email",
    name: "email",
    icon: "email",
    primitiveType: "string",
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    allowedValidations: ["mandatory", "maxlength", "minlength", "matches"],
    categories: ["text"],
    metadata: {
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 255
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        details: {},
        name: "email"
      }
    ]
  },
  {
    id: "475a740d-da4d-4d15-8752-b98f42f1565d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Long Text",
    description: "Long Text is perfect for long text fields like description, address, etc.",
    name: "long-text",
    icon: "keyboard",
    allowedValidations: [
      {
        name: "string",
        visible: false
      },
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "maxlength"
      },
      {
        name: "minlength"
      },
      {
        name: "matches"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    categories: ["text"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "TEXT"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "string"
      }
    ]
  },
  {
    id: "43d892e7-24e6-4390-b92a-b6d3dcfc75ff",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Local Tel is a field for local telephone numbers",
    displayName: "Local Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "local-tel",
    icon: "call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "464944c4-c24d-487d-8480-4591fcee4b40",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "International Tel is a field for international/local telephone numbers",
    displayName: "International Tel",
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "tel"
    ],
    name: "international-tel",
    icon: "add_call",
    categories: ["text", "phone"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        type: "string",
        defaultValue: "varchar"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: true,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 12
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "tel"
      }
    ]
  },
  {
    id: "d7a0f960-f087-4590-b56f-1db86c7b6bec",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Date",
    name: "date",
    icon: "today",
    allowedValidations: ["mandatory", "date"],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        required: true,
        displayName: "Native Type",
        type: "string",
        defaultValue: "date"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "date"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "b9c5462e-ee19-4f5b-a919-c022a9f45750",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Time (hh:mm:ss)",
    name: "time",
    icon: "alarm",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "time",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        required: false,
        displayName: "Timezone",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "UTC"
          },
          {
            id: "timetz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {
          value: "time"
        },
        name: "time"
      }
    ],
    allowedOperators: [
      {
        name: "between",
        details: {}
      },
      {
        name: "after",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      }
    ]
  },
  {
    id: "cd4a3d74-1592-4ea7-a289-d7e9e731f50f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "DateTime",
    name: "datetime",
    icon: "schedule",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "unique"
      },
      {
        name: "isBefore"
      },
      {
        name: "isAfter"
      },
      {
        name: "datetime",
        required: true
      }
    ],
    categories: ["date/time"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        _comment: "We are relying on the timezone validation to figure out the correct native type",
        visible: false,
        displayName: "Timezone",
        required: false,
        type: "single-select",
        source: [
          {
            id: "timestamp",
            displayName: "UTC"
          },
          {
            id: "timestamptz",
            displayName: "Local"
          }
        ]
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {
          value: "date-time"
        },
        name: "datetime"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "before_on",
        details: {}
      },
      {
        name: "after_on",
        details: {}
      },
      {
        name: "before",
        details: {}
      },
      {
        name: "after",
        details: {}
      }
    ]
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Single select",
    icon: "list",
    name: "single-select",
    id: "093a4d33-c4b9-4292-9748-645d6261d66e",
    categories: ["text", "select"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory"
      },
      {
        name: "oneof",
        visible: false
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    initialValidation: [
      {
        name: "oneof",
        details: {
          value: "context.values"
        }
      }
    ],
    metadata: {
      style: {
        visible: false,
        required: true,
        displayName: "Style",
        type: "single-select",
        defaultValue: "varchar",
        source: [
          {
            displayName: "Lookup Table",
            id: "lookup",
            visible: false,
            _comment: "will seed the lookup table with the values provided in the values property"
          },
          {
            displayName: "Enum",
            id: "enum",
            visible: false
          },
          {
            displayName: "Varchar",
            id: "varchar"
          }
        ]
      },
      values: {
        visible: true,
        required: false,
        displayName: "Values",
        type: "chips"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    }
  },
  {
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    displayName: "Multi select",
    icon: "list",
    categories: ["select"],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ],
    name: "multi-select",
    id: "be52ff83-c6e6-4d62-9f23-48d2589b01b5",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "feff0537-8b05-432e-9aae-ec6284613c85",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "password",
    displayName: "Password",
    icon: "lock",
    categories: ["secret"],
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      }
    ]
  },
  {
    id: "6e88c2c4-e479-439e-8d68-91f37c25bd60",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "url",
    displayName: "URL",
    icon: "http",
    categories: ["text", "special-text"],
    allowedValidations: [
      "mandatory",
      "maxlength",
      "minlength",
      "matches",
      "url"
    ],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "varchar",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      length: {
        visible: false,
        displayName: "Length",
        type: "number",
        required: true,
        defaultValue: 2083
      }
    },
    initialValidation: [
      {
        details: {},
        name: "url"
      }
    ],
    allowedOperators: [
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "contains",
        details: {}
      },
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "starts_with",
        details: {}
      },
      {
        name: "ends_with",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      }
    ]
  },
  {
    id: "ea25d8ae-6d69-40c0-898c-6a94b18037fa",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "boolean",
    icon: "toggle_on",
    displayName: "Boolean",
    categories: ["boolean"],
    allowedValidations: ["mandatory"],
    primitiveType: "boolean",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "boolean",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "boolean"
      }
    ],
    allowedOperators: [
      {
        name: "is",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "f40d6da3-71b0-4739-9698-946843b431d9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "percentage",
    displayName: "Percentage",
    icon: "percent",
    primitiveType: "string",
    categories: ["decimal"],
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      },
      precision: {
        visible: false,
        displayName: "Precision",
        type: "number",
        required: false,
        defaultValue: 5
      },
      scale: {
        visible: false,
        displayName: "Scale",
        type: "number",
        required: false,
        defaultValue: 2
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "2"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e2071017-feab-475e-b6eb-055cd7b4e500",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "price",
    displayName: "Price",
    icon: "attach_money",
    categories: ["decimal"],
    primitiveType: "string",
    allowedValidations: [
      {
        name: "mandatory",
        details: {}
      },
      {
        name: "decimal",
        details: {}
      }
    ],
    metadata: {
      precision: {
        visible: false,
        displayName: "Precision",
        required: true,
        defaultValue: "8",
        type: "number"
      },
      scale: {
        visible: false,
        displayName: "Scale",
        required: true,
        defaultValue: "3",
        type: "number"
      },
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        name: "decimal",
        details: {
          value: "3"
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "0cb69328-fc62-422b-a3cc-8e8abb9377b8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "decimal",
    icon: "houseboat",
    primitiveType: "number",
    displayName: "Decimal",
    categories: ["decimal"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedValidations: ["mandatory", "decimal"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "decimal"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    categories: ["integer"],
    id: "2bd6d573-3f3e-43a7-a68b-5aed9b8c397e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "integer",
    icon: "numbers",
    displayName: "Integer",
    primitiveType: "number",
    allowedValidations: ["mandatory"],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "integer",
        type: "number"
      },
      defaultValue: {
        visible: false,
        displayName: "",
        type: "number",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        details: {},
        name: "mandatory"
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    allowedValidations: ["mandatory", "decimal"],
    id: "a7931686-886c-463b-9644-515187ea918e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "latitude",
    icon: "my_location",
    categories: ["decimal", "location"],
    displayName: "Latitude",
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "latitude"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "8d3fa9a4-1be7-4f2f-9f64-cf37ea6a67f9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "longitude",
    icon: "my_location",
    displayName: "Longitude",
    allowedValidations: ["mandatory", "decimal"],
    categories: ["decimal", "location"],
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        name: "longitude",
        details: {}
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "decimal",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "string",
        required: false
      }
    },
    allowedOperators: []
  },
  {
    id: "6024fb09-a6b2-4400-85bd-cb9bed8e93da",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "json",
    icon: "json",
    displayName: "JSON",
    categories: ["json", "files"],
    allowedValidations: ["mandatory"],
    primitiveType: "string",
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "jsonb",
        type: "string"
      },
      defaultValue: {
        visible: false,
        displayName: "Default Value",
        type: "object",
        required: false
      }
    },
    initialValidation: [
      {
        details: {},
        name: "mandatory"
      },
      {
        details: {},
        name: "string"
      }
    ],
    allowedOperators: []
  },
  {
    categories: ["misc"],
    id: "b7da5b61-655a-47f7-a18f-d0e38f3ae02a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation",
    icon: "share",
    displayName: "Relation",
    allowedValidations: ["mandatory"],
    primitiveType: {
      transformer: "pascalcase",
      primitiveType: {
        input: "context.relationship",
        operator: "equal",
        value: "many-to-one",
        then: "object",
        else: "array"
      },
      typeName: {
        url: "/tables/:id",
        binding: {
          id: "context.references"
        },
        use: "displayName"
      },
      interface: {
        url: "/tables/:id/fields",
        binding: {
          id: "context.references"
        }
      }
    },
    metadata: {
      references: {
        visible: true,
        displayName: "Related Table",
        required: true,
        type: "single-select",
        fieldset: "relation",
        source: {
          url: "/tables"
        }
      },
      joinSide: {
        visible: false,
        displayName: "Join side",
        type: "boolean",
        required: true,
        defaultValue: true
      },
      relationship: {
        fieldset: "relation",
        visible: true,
        displayName: "Relationship",
        type: "single-select",
        required: true,
        source: [
          {
            displayName: "Single",
            id: "one-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-one"
          },
          {
            displayName: "Multiple",
            id: "many-to-many"
          }
        ]
      }
    },
    initialValidation: []
  },
  {
    categories: ["misc"],
    id: "17a0ef1e-b51c-4db3-b3a0-073ad874ddfd",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "relation-id",
    icon: "share",
    displayName: "Relation Id",
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ],
    allowedValidations: ["mandatory"],
    metadata: {
      references: {
        displayName: "Related entity id",
        visible: true,
        required: true,
        type: "string"
      }
    },
    initialValidation: []
  },
  {
    id: "0ac2f72b-c6f0-4fca-91b2-e31467540c48",
    extensionId: "3e184f8b-d2dc-4592-9507-979d649277f5",
    description: "File Storage connected to a Google Blob Storage",
    name: "gs-file",
    icon: "file_upload",
    categories: ["files", "blob-based"],
    displayName: "File",
    primitiveType: "string",
    extends: "38d8dfa1-fa38-41be-a66f-eb3c847129fe",
    allowedValidations: [
      {
        name: "mandatory"
      }
    ],
    initialValidation: []
  },
  {
    id: "14844d66-d729-4ce6-a269-2b4fb44c8ea9",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "uuid",
    icon: "raw_on",
    allowedValidations: ["mandatory", "uuid"],
    categories: ["uuid"],
    displayName: "UUID",
    primitiveType: "string",
    initialValidation: [
      {
        details: {
          value: true
        },
        name: "mandatory"
      },
      {
        details: {},
        name: "uuid"
      }
    ],
    metadata: {
      nativeType: {
        visible: false,
        displayName: "Native Type",
        required: true,
        defaultValue: "uuid",
        type: "string"
      }
    },
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {
          defaultValue: [null, ""]
        }
      },
      {
        name: "is_not_empty",
        details: {
          defaultValue: [null, ""]
        }
      }
    ]
  },
  {
    id: "2ee187ad-fbb5-4aef-bcd0-42ac0c19f86e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    name: "primary-key-uuid",
    icon: "branding_watermark",
    references: "uuid",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - UUID",
    primitiveType: "string",
    initialValidation: [
      {
        name: "uuid",
        details: {}
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  },
  {
    id: "6c09acb6-e45a-479f-be05-c391dfbced8e",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    visible: false,
    name: "primary-key-number",
    references: "integer",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - Auto Increment",
    primitiveType: "number",
    initialValidation: [
      {
        details: {},
        name: "number"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "one_of",
        details: {}
      },
      {
        name: "between",
        details: {}
      },
      {
        name: "less_than",
        details: {}
      },
      {
        name: "more_than",
        details: {}
      }
    ]
  },
  {
    id: "e23bca0c-faa5-473a-a9e6-87d65549fd0c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "",
    visible: false,
    name: "primary-key-custom",
    references: "short-text",
    icon: "branding_watermark",
    allowedValidations: [],
    categories: ["key"],
    displayName: "Primary Key - String",
    primitiveType: "string",
    initialValidation: [
      {
        details: {},
        name: "string"
      },
      {
        name: "mandatory",
        details: {
          value: true
        }
      }
    ],
    allowedOperators: [
      {
        name: "equals",
        details: {}
      },
      {
        name: "not_equals",
        details: {}
      },
      {
        name: "is_empty",
        details: {}
      },
      {
        name: "is_not_empty",
        details: {}
      }
    ]
  }
];

// libs/compiler/sdk/devkit/src/lib/data/operators.json
var operators_default = [
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Equal To",
    name: "equals",
    metadata: {}
  },
  {
    id: "e5b765c8-215a-4d0c-ac7c-bfc7ad0f0c70",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Not Equal To",
    name: "not_equals",
    metadata: {}
  },
  {
    id: "f3d3c1af-0066-4884-8533-917ec2c71fd1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "One Of",
    name: "one_of",
    metadata: {}
  },
  {
    id: "f56f9948-7745-4203-928f-e75c481d13d8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Between",
    name: "between",
    metadata: {}
  },
  {
    id: "c2e22f65-ce15-42cc-a99f-7e5bca84b69f",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "63ec8fb7-357f-403a-b753-6df8a3f25737",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "More Than",
    name: "more_than",
    metadata: {}
  },
  {
    id: "162eedc3-3ace-48c2-8a38-0c1db9058d8a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    name: "contains",
    metadata: {}
  },
  {
    id: "60e18406-a4a7-44a4-8b91-2481710fb4e8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    name: "starts_with",
    metadata: {}
  },
  {
    id: "d3b7f462-d154-4bfa-8645-3f74a958bed6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    name: "ends_with",
    metadata: {}
  },
  {
    id: "d1a02de2-8928-4517-884d-502bdb8d8409",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Less Than",
    name: "less_than",
    metadata: {}
  },
  {
    id: "fa2b1831-9ceb-4808-984e-1f834a723c56",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Greater Than",
    name: "greater-than",
    metadata: {}
  },
  {
    id: "a2c10af5-c9dd-401c-b28c-59bb48c85345",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Not Empty",
    name: "is_not_empty",
    metadata: {}
  },
  {
    id: "8bd0f5d5-18fe-4fcf-92c6-7821e437a8a1",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Empty",
    name: "is_empty",
    metadata: {}
  },
  {
    id: "73963f47-092a-4bf2-a38a-50dca50ca5e6",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before",
    name: "before",
    metadata: {}
  },
  {
    id: "a830cb78-e9f2-4259-9753-d6259bea1bed",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Before On",
    name: "before_on",
    metadata: {}
  },
  {
    id: "d23be707-a71d-44bd-8b61-9489e84f1a2d",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After On",
    name: "after_on",
    metadata: {}
  },
  {
    id: "8648374e-f78a-4322-ac67-67467d4fbff5",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "After",
    name: "after",
    metadata: {}
  }
];

// libs/compiler/sdk/devkit/src/lib/data/validations.json
var validations_default = [
  {
    id: "119aaf66-e16a-40ef-9aaa-22ebec809f1a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Max Length",
    type: "maxlength",
    name: "maxlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max length",
        type: "number"
      }
    }
  },
  {
    id: "4d2dfa41-03b9-418d-82f6-cd90b0002133",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Min Length",
    type: "minlength",
    name: "minlength",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min length",
        type: "number"
      }
    }
  },
  {
    id: "8f092043-adab-49b8-884d-ef911405c52a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Starts With",
    type: "startswith",
    name: "startswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "b78350ef-90f7-45be-bff3-adc4b8a4c661",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Ends With",
    type: "endswith",
    name: "endswith",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "de06ff25-e747-4751-8237-717b6e698e0a",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Contains",
    type: "contains",
    name: "contains",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      pattern: {
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "951455fe-7772-43b6-8528-aca9760d1969",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is UUID",
    type: "uuid",
    name: "uuid",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      version: {
        displayName: "Version",
        defaultValue: 4,
        type: "number"
      }
    }
  },
  {
    id: "bbf3e749-62ac-4f2b-aad3-212c6322173b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    type: "date",
    name: "date",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Date",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "735bb87a-d35e-4bb9-b040-2a0a3436e680",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Boolean",
    type: "boolean",
    name: "boolean",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "0d8ec049-391d-40a2-a0de-16aeae3d94b7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Mandatory",
    type: "mandatory",
    name: "mandatory",
    metadata: {
      value: {
        displayName: "Required",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "147e7bf1-d716-4606-9e6b-c007d9663060",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Unique",
    type: "unique",
    name: "unique",
    metadata: {
      value: {
        displayName: "Unique",
        type: "single-select",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      },
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "987965d1-0240-42b9-acf6-f378d6f06ea7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Matches",
    type: "matches",
    name: "matches",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern"
      }
    }
  },
  {
    id: "53b6704f-f02a-4113-8803-c3fa7d629213",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Email",
    type: "email",
    name: "email",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      pattern: {
        displayName: "Pattern",
        type: "string",
        defaultValue: "^[w-.]+@([w-]+.)+[w-]{2,4}$"
      }
    }
  },
  {
    id: "5190a2b4-d7c0-4fa5-82bd-3bae74c564c8",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Is Arabic",
    type: "matches",
    name: "arabic",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "string",
        displayName: "Pattern",
        defaultValue: "/[\u0600-\u06FF\u0750-\u077F]/"
      }
    }
  },
  {
    id: "8d4e9579-775c-4b05-ba13-5703b66ab9be",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Decimal",
    type: "decimal",
    name: "decimal",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Decimal Places",
        type: "number"
      },
      precision: {
        required: true,
        type: "number"
      }
    }
  },
  {
    id: "0ae68509-73f1-4d49-9497-5cd0429371ce",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Latitude",
    type: "latitude",
    name: "latitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "c5215c89-94bf-452d-a552-0e08e1a21b8c",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Longitude",
    type: "longitude",
    name: "longitude",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Longitude",
        type: "string"
      }
    }
  },
  {
    id: "6f6eea02-58b9-4863-8d8d-63f28bd46dba",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Number",
    type: "number",
    name: "number",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Is Number",
        type: "single-select",
        _comment: "what about negative and positive",
        source: [
          {
            id: "true",
            displayName: "Yes"
          },
          {
            id: "false",
            displayName: "No"
          }
        ]
      }
    }
  },
  {
    id: "237c6189-2860-46a7-a329-281303b1d128",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "String",
    type: "string",
    name: "string",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      trim: {
        displayName: "Trim",
        type: "boolean"
      },
      allowEmpty: {
        displayName: "Allow Empty",
        type: "boolean"
      }
    }
  },
  {
    id: "d733d906-3682-4c39-919d-a318b44c5b48",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Tel",
    type: "tel",
    name: "tel",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      }
    }
  },
  {
    id: "3b5031c1-7ac4-40dd-bdad-156a4da5aa54",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "Url",
    type: "url",
    name: "url",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        visible: false,
        displayName: "Pattern",
        type: "string"
      }
    }
  },
  {
    id: "7ecd51dc-b396-422e-a180-a34a00aee7fe",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    displayName: "IP",
    type: "ip",
    name: "ip",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Version",
        type: "single-select",
        source: [
          {
            id: "ipv4",
            displayName: "ipv4"
          },
          {
            id: "ipv6",
            displayName: "ipv6"
          }
        ]
      }
    }
  },
  {
    id: "f8603858-4ddc-4ff6-972f-12e3030e3d73",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBefore",
    displayName: "Is Before",
    type: "isBefore",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is Before"
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "ed36a909-e554-4125-b916-bf281fcdfb37",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isAfter",
    displayName: "Is After",
    type: "isAfter",
    metadata: {
      value: {
        type: "datetime",
        displayName: "Is After"
      },
      message: {
        type: "string",
        displayName: "Message",
        visible: false
      }
    }
  },
  {
    id: "d8b0f376-9d34-4ac2-92ad-0e054d88d372",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "isBetween",
    displayName: "Is Between",
    type: "isBetween",
    metadata: {
      message: {
        type: "string",
        displayName: "Message"
      },
      value: {
        type: "datetime-range",
        displayName: "Is Between"
      }
    }
  },
  {
    id: "8c8636a4-480a-4b29-bfa0-80a1aae9d913",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "datetime",
    type: "datetime",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "date-time",
            displayName: "Yes"
          },
          {
            id: "iso-date-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "c6c48353-3095-47cd-8060-a60400972720",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    name: "time",
    type: "time",
    metadata: {
      value: {
        displayName: "Local",
        type: "single-select",
        source: [
          {
            id: "time",
            displayName: "Yes"
          },
          {
            id: "iso-time",
            displayName: "No"
          }
        ]
      },
      message: {
        type: "string",
        displayName: "Message"
      }
    }
  },
  {
    id: "90ff5d13-4846-4c57-9f7b-5e9730582d39",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Min",
    displayName: "Min",
    type: "min",
    name: "min",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Min",
        type: "number"
      }
    }
  },
  {
    id: "4c86e4c6-36e2-470d-be82-ae6c65809fa7",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Max",
    displayName: "Max",
    type: "max",
    name: "max",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Max",
        type: "number"
      }
    }
  },
  {
    id: "b1b4b5a0-0b0a-4b0e-8b0a-5b8b5b0b0b0b",
    extensionId: "931799e0-12e0-45d7-86a3-6a46f874576b",
    description: "Oneof",
    displayName: "Oneof",
    type: "oneof",
    name: "oneof",
    metadata: {
      message: {
        displayName: "Message",
        type: "string"
      },
      value: {
        displayName: "Enum",
        type: "string"
      }
    }
  }
];

// libs/compiler/sdk/devkit/src/lib/devkit.ts
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var DevKit = class {
  getDeps() {
    const exts = this.extensions();
    const dependencies = exts.map((it) => it.packages ?? []).flat();
    const possibleDeps = [
      {
        name: "discord.js",
        version: "^14.15.3",
        dev: false
      }
    ];
    return [...dependencies, ...possibleDeps].reduce((acc, it) => {
      return {
        ...acc,
        [it.name]: it.version
      };
    }, {});
  }
  getExtensionActions(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return actions_default.filter((it) => it.extensionId === id);
  }
  actions() {
    return actions_default;
  }
  async getExtensionTriggers(id) {
    const extension = this.extensions().find((it) => it.id === id);
    if (!extension) {
      throw new Error(`Extension with id ${id} not found`);
    }
    return (await this.triggers()).filter((it) => it.extensionId === id);
  }
  async triggers() {
    return (await this.actions()).filter((it) => it.type === "trigger");
  }
  extensions() {
    return extensions_default;
  }
  toJson(obj) {
    return JSON.stringify(obj, null, 2);
  }
  async getValidationsByIds(ids) {
    const validations = await this.validations();
    const list = [];
    for (const id of ids) {
      const validation2 = validations.find((it) => it.id === id);
      if (!validation2) {
        throw new Error(`Validation with id ${id} not found`);
      }
      list.push(validation2);
    }
    return list;
  }
  async getValidationsByNames(names) {
    const validations = await this.validations();
    const list = [];
    for (const name of names) {
      const validation2 = validations.find((it) => it.name === name);
      if (!validation2) {
        throw new Error(`Validation with name ${name} not found`);
      }
      list.push(validation2);
    }
    return list;
  }
  async getFieldsByExtension() {
    return await this.fields();
  }
  fields() {
    return fields_default;
  }
  validations() {
    return validations_default;
  }
  operators() {
    return operators_default;
  }
};
__name(DevKit, "DevKit");
DevKit = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], DevKit);
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}
__name(toJson, "toJson");
function substring(input2, sub) {
  const index2 = input2.indexOf(sub);
  if (index2 === -1) {
    return input2;
  }
  return input2.slice(sub.length);
}
__name(substring, "substring");
function getSourceActionById(id) {
  const action = actions_default.find((it) => it.id === id);
  if (!action) {
    throw new Error(`Action with id ${id} not found`);
  }
  return action;
}
__name(getSourceActionById, "getSourceActionById");
function getExtensionById(id) {
  const item = extensions_default.find((it) => it.id === id);
  if (!item) {
    throw new Error(`Extension with id ${id} not found`);
  }
  return item;
}
__name(getExtensionById, "getExtensionById");
function getValidationByName(name) {
  const validation2 = validations_default.find((a) => a.name === name);
  if (!validation2) {
    throw new Error(`Validation with name ${name} not found`);
  }
  return validation2;
}
__name(getValidationByName, "getValidationByName");
function getSourceFieldById(id) {
  const field2 = fields_default.find((it) => it.id === id);
  if (!field2) {
    throw new Error(`Field with id ${id} not found`);
  }
  return field2;
}
__name(getSourceFieldById, "getSourceFieldById");
function getSourceFieldByName(name) {
  const field2 = fields_default.find((it) => it.name === name);
  if (!field2) {
    throw new Error(`Field with name ${name} not found`);
  }
  return field2;
}
__name(getSourceFieldByName, "getSourceFieldByName");
function assignDefaults(metadata, details) {
  Object.entries(metadata ?? {}).forEach(([name, config2]) => {
    if (details[name] === void 0 && config2.defaultValue !== void 0) {
      details[name] = config2.defaultValue;
    }
  });
  return details;
}
__name(assignDefaults, "assignDefaults");
function getTriggerByName(name) {
  const trigger2 = actions_default.find(
    (it) => it.type === "trigger" && it.name === name
  );
  if (!trigger2) {
    throw new Error(`Trigger with name ${name} not found`);
  }
  return trigger2;
}
__name(getTriggerByName, "getTriggerByName");
function getValidationById(id) {
  const validation2 = validations_default.find((it) => it.id === id);
  if (!validation2) {
    throw new Error(`Validation with id ${id} not found`);
  }
  return validation2;
}
__name(getValidationById, "getValidationById");
function getSourceActionByName(name) {
  if (isNullOrUndefined(name)) {
    throw new Error(
      "getSourceActionByName:name is required. received: " + name
    );
  }
  const action = actions_default.find((it) => it.name === name);
  if (!action) {
    throw new Error(`Action with name ${name} not found`);
  }
  return action;
}
__name(getSourceActionByName, "getSourceActionByName");
function getExtensionByName(name) {
  const item = extensions_default.find((it) => it.name === name);
  if (!item) {
    throw new Error(`Extension with name ${name} not found`);
  }
  return item;
}
__name(getExtensionByName, "getExtensionByName");

// libs/compiler/sdk/devkit/src/lib/project-config.ts
var _config;
import { Injectable as Injectable3, ServiceLifetime as ServiceLifetime3 } from "tiny-injector";
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
__name(ProjectConfig, "ProjectConfig");
ProjectConfig = __decorateClass([
  Injectable3({
    lifetime: ServiceLifetime3.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join as join2 } from "path";
import { Injectable as Injectable4, Injector as Injector2, ServiceLifetime as ServiceLifetime4 } from "tiny-injector";
var config = {
  basePath: "./src",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  _projectConfig = Injector2.GetRequiredService(ProjectConfig);
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = /* @__PURE__ */ __name((importPath) => {
    return join2("#{relative}", config.basePath, importPath);
  }, "makeCoreImportSpecifier");
  makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  }, "makeEntityImportSpecifier");
  makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
  makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
  makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "identity", fileName), "makeIdentityPath");
  makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
  makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  ), "makeWorkspacePath");
  makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
  makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  ), "makeCommandPath");
  makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
  makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  ), "makeControllerPath");
  makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  ), "makeControllerRoutePath");
  makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  ), "makeListenerRoutePath");
  makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  ), "makeJobRoutePath");
  makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  ), "makeEntityPath");
  makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  ), "makeQueryPath");
  makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
};
__name(ProjectFS, "ProjectFS");
ProjectFS = __decorateClass([
  Injectable4({
    lifetime: ServiceLifetime4.Singleton
  })
], ProjectFS);
var commandsGlob = /* @__PURE__ */ __name(() => {
  return `${config.features}/**/*.command.ts`;
}, "commandsGlob");
var routersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.router.ts";
}, "routersGlob");
var listenersGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.github.ts";
}, "listenersGlob");
var cronsGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.cron.ts";
}, "cronsGlob");
var entitiesGlob = /* @__PURE__ */ __name(() => {
  return "/**/*.entity.ts";
}, "entitiesGlob");
var makeFeatureFile = /* @__PURE__ */ __name((featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName), "makeFeatureFile");
var makeCorePath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "core", fileName), "makeCorePath");
var makeIdentityPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "identity", fileName), "makeIdentityPath");
var makeSrcPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, fileName), "makeSrcPath");
var makeWorkspacePath = /* @__PURE__ */ __name((fileName) => join2(
  config.basePath,
  "../",
  /** We need this to work with new january cli */
  "../",
  fileName
), "makeWorkspacePath");
var makeRootPath = /* @__PURE__ */ __name((fileName) => join2(config.basePath, "../", fileName), "makeRootPath");
var makeCommandPath = /* @__PURE__ */ __name((featureName, tagName, commandName) => makeFeatureFile(
  featureName,
  join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
), "makeCommandPath");
var makeIndexFilePath = /* @__PURE__ */ __name((featureName, tagName) => makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`)), "makeIndexFilePath");
var makeControllerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
), "makeControllerRoutePath");
var makeListenerRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
), "makeListenerRoutePath");
var makeJobRoutePath = /* @__PURE__ */ __name((featureName, routeName) => makeFeatureFile(
  featureName,
  join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
), "makeJobRoutePath");
var makeEntityPath = /* @__PURE__ */ __name((featureName, tableName, suffix) => join2(
  config.features,
  spinalcase2(featureName),
  `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
), "makeEntityPath");
var makeQueryPath = /* @__PURE__ */ __name((tableName, queryName) => join2(
  config.features,
  spinalcase2(tableName),
  "queries",
  `${spinalcase2(queryName)}.query.ts`
), "makeQueryPath");
var makeExportPath = /* @__PURE__ */ __name((workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`, "makeExportPath");
var makeEntityImportSpecifier = /* @__PURE__ */ __name((tableName) => {
  return join2("#{entity}", pascalcase(tableName));
}, "makeEntityImportSpecifier");
var makeControllerPath = /* @__PURE__ */ __name((featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
), "makeControllerPath");
var makeFeaturePath = /* @__PURE__ */ __name((fileName) => join2(config.features, fileName), "makeFeaturePath");

// libs/compiler/sdk/platform/src/lib/tables.sdk.ts
import { Injectable as Injectable5, Injector as Injector3, ServiceLifetime as ServiceLifetime5 } from "tiny-injector";
var Tables = class {
  changes = Injector3.GetRequiredService(CHANGES_PROJECTION_TOKEN);
  _dynamicSource = new DynamicSource();
  async get(tableId) {
    const table2 = this.changes.tables.find((it) => it.id === tableId);
    if (!table2) {
      throw new Error(`Table ${tableId} not found`);
    }
    return table2;
  }
  async getTableField(tableId, id) {
    const table2 = await this.get(tableId);
    const field2 = table2.fields.find((it) => it.id === id);
    if (!field2) {
      throw new Error(`Field ${id} not found`);
    }
    return field2;
  }
  async resolvePrimitiveType(field2, sourceField) {
    sourceField ??= await getSourceFieldById(field2.sourceId);
    return await this._dynamicSource.resolvePrimitiveType(
      void 0,
      sourceField.primitiveType,
      {
        context: field2.details,
        self: field2
      },
      (primitiveType) => primitiveType.primitiveType
    );
  }
};
__name(Tables, "Tables");
Tables = __decorateClass([
  Injectable5({
    lifetime: ServiceLifetime5.Singleton
  })
], Tables);

// libs/compiler/sdk/platform/src/lib/sdk.ts
import { Injectable as Injectable6, Injector as Injector4, ServiceLifetime as ServiceLifetime6 } from "tiny-injector";
var Sdk = class {
  tables = Injector4.GetRequiredService(Tables);
  features = Injector4.GetRequiredService(Features);
  changes = Injector4.GetRequiredService(CHANGES_PROJECTION_TOKEN);
  getInstalledExtensions() {
    throw new Error("Not implemented");
  }
  getInstalledExtension(id) {
    throw new Error("Not implemented");
  }
};
__name(Sdk, "Sdk");
Sdk = __decorateClass([
  Injectable6({
    lifetime: ServiceLifetime6.Singleton
  })
], Sdk);

// libs/canary/src/lib/setup.ts
import { Context, Injector as Injector5 } from "tiny-injector";
Error.stackTraceLimit = Infinity;
Injector5.TryAddScoped(Context, (c) => c);
Injector5.AddScoped(DYNAMIC_SOURCE_MAPPER, (context) => (featureId) => {
  const sdk = Injector5.GetRequiredService(Sdk, context);
  return {
    "/tables/:id": /* @__PURE__ */ __name((id) => sdk.tables.get(id), "/tables/:id"),
    "/tables/:id/fields": /* @__PURE__ */ __name((id) => sdk.tables.get(id).then((it) => it ? it.fields : []), "/tables/:id/fields")
  };
});

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";
var Contracts;
((Contracts2) => {
  function fffffff(input2) {
    const [namespace, value] = input2.split(":");
    return {
      namespace,
      value
    };
  }
  __name(fffffff, "fffffff");
})(Contracts || (Contracts = {}));
function makeSchema(property) {
  const result = {};
  (property.validations ?? []).filter((validation2) => validation2.type !== "unique").map((validation2) => {
    const validationType = validation2.type;
    if (!validationType) {
      throw new Error(`Validation ${validation2.id} not found.`);
    }
    if (validation2.details["message"]) {
      result["errorMessage"] = validation2.details["message"];
    }
    switch (validationType) {
      case "mandatory":
        result["required"] = true;
        if (property.type === "string") {
          result["minLength"] ??= 1;
        }
        break;
      case "string":
        break;
      case "number":
        result["type"] = "number";
        break;
      case "oneof":
        result["type"] = "string";
        result["enum"] = validation2.details["value"];
        break;
      case "email":
        result["type"] = "string";
        result["format"] = "email";
        result["isEmail"] = [];
        break;
      case "minlength":
        result["type"] = "string";
        result["minLength"] = validation2.details["value"];
        break;
      case "maxlength":
        result.type = "string";
        result.maxLength = validation2.details["value"];
        break;
      case "min":
        result.minLength = void 0;
        result.type = "number";
        result.minimum = validation2.details["value"];
        break;
      case "max":
        result.type = "number";
        result.maximum = validation2.details["value"];
        break;
      case "pattern":
        result.type = "string";
        result.regex = validation2.details["value"];
        break;
      case "url":
        result.type = "string";
        result.format = "uri";
        result["isURL"] = [];
        break;
      case "uuid":
        result.type = "string";
        result.format = "uuid";
        break;
      case "startswith":
        result.type = "string";
        result.pattern = `^${validation2.details["value"]}`;
        break;
      case "endswith":
        result.type = "string";
        result.pattern = `${validation2.details["value"]}$`;
        break;
      case "contains":
        result.type = "string";
        result.pattern = validation2.details["value"];
        break;
      case "before":
        result.type = "string";
        result["isBefore"] = [validation2.details["value"]];
        break;
      case "after":
        result.type = "string";
        result["isAfter"] = [validation2.details["value"]];
        break;
      case "boolean":
        result.type = "boolean";
        break;
      case "date":
        result.type = "string";
        result.format = "date";
        break;
      case "datetime":
        result.type = "string";
        result.format = validation2.details["value"];
        break;
      case "time":
        result.type = "string";
        result.format = validation2.details["value"];
        break;
      case "tel":
        result["isMobilePhone"] = ["any"];
        break;
      case "longitude":
      case "latitude":
        result.type = "string";
        result["isLatLong"] = [];
        break;
      case "ip":
        result.type = "string";
        result.format = validation2.details["value"];
        break;
      case "decimal":
        result.type = "string";
        result.format = "double";
        result.multipleOf = 1 / Math.pow(10, +validation2.details["value"]);
        break;
      default:
        throw new Error(`Validation ${validationType} not supported.`);
    }
  });
  return result;
}
__name(makeSchema, "makeSchema");
function isActionProperty(property) {
  return property.name && property.namespace;
}
__name(isActionProperty, "isActionProperty");
function createSwitch(cases, fallback) {
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile("index.ts");
  const fn = sourceFile.addFunction({
    name: "myFunction",
    parameters: [{ name: "value", type: "string" }],
    returnType: "void",
    isExported: true
  });
  const [switchStmt] = fn.addStatements(
    (writer) => writer.write(
      dedent(`switch (true) {
        ${cases.map((it) => `case ${it.condition}:`).join("\n")}
        ${fallback ? "default:" : ""}
        }`)
    )
  );
  const clauses = switchStmt.getClauses();
  for (let index2 = 0; index2 < cases.length; index2++) {
    clauses[index2].addStatements(
      Array.isArray(cases[index2].logic) ? [...cases[index2].logic, "break;"] : [cases[index2].logic, "break;"]
    );
  }
  if (fallback && fallback.logic) {
    clauses.at(-1)?.addStatements(
      Array.isArray(fallback.logic) ? [...fallback.logic, "break;"] : [fallback.logic, "break;"]
    );
  }
  return [switchStmt.getFullText()];
}
__name(createSwitch, "createSwitch");
function createIfElse(defaultCase, fallback) {
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile("index.ts");
  const fn = sourceFile.addFunction({
    name: "myFunction",
    parameters: [{ name: "value", type: "string" }],
    returnType: "void",
    isExported: true
  });
  const [ifStmt] = fn.addStatements(
    (writer) => writer.write(
      dedent(`
        if(${defaultCase.condition}) {}
        ${fallback ? "else {}" : ""}
      `)
    )
  );
  ifStmt.getThenStatement().addStatements(defaultCase.logic);
  if (fallback && fallback.logic) {
    ifStmt.getElseStatement().addStatements(fallback.logic);
  }
  return [ifStmt.getFullText()];
}
__name(createIfElse, "createIfElse");
function createArrowFn(name, params, body) {
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile("index.ts");
  const varFnStm = sourceFile.addVariableStatement({
    declarationKind: VariableDeclarationKind.Const,
    declarations: [
      {
        name,
        initializer: "async () => {}"
      }
    ]
  });
  const [declaration] = varFnStm.getDeclarations();
  const arrowFn = declaration.getInitializerOrThrow();
  for (const stmt of body) {
    arrowFn.addStatements(stmt);
    arrowFn.addParameters(params);
  }
  return varFnStm.getFullText();
}
__name(createArrowFn, "createArrowFn");
function useInput(parsedInput) {
  if (!parsedInput) {
    return void 0;
  }
  return parsedInput.data?.["parameterName"] ?? parsedInput.value;
}
__name(useInput, "useInput");
function generateValidationContract(validations) {
  const result = [];
  for (const validation2 of validations) {
    const sourceValidation = getValidationById(validation2.sourceId);
    result.push({
      id: validation2.sourceId,
      details: validation2.details,
      name: sourceValidation.name,
      type: sourceValidation.type
    });
  }
  return result;
}
__name(generateValidationContract, "generateValidationContract");
function nonStatic(inputs) {
  return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
__name(nonStatic, "nonStatic");
function standaloneInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique2 = uniquify(
    Object.entries(inputs).filter(
      ([name, prop]) => prop.data?.["standalone"] && predicate([name, prop])
    ),
    ([name, prop]) => paramName([name, prop])
  );
  return unique2.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
__name(standaloneInputs, "standaloneInputs");
function nonStaticInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique2 = uniquify(
    nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])),
    ([name, prop]) => paramName([name, prop])
  );
  return unique2.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
__name(nonStaticInputs, "nonStaticInputs");
function paramName([name, prop]) {
  return prop.data?.["parameterName"] || name;
}
__name(paramName, "paramName");

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  __name(whatIsParserImport, "whatIsParserImport");
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}
__name(formatCode, "formatCode");

// libs/sdk/declarative/src/lib/feature.ts
function feature(nameOrConfig, config2) {
  if (typeof nameOrConfig === "string") {
    if (!config2) {
      throw new Error(`Missing config for feature ${nameOrConfig}`);
    }
    return {
      name: nameOrConfig,
      tables: config2.tables,
      workflows: config2.workflows,
      policies: Object.entries(config2.policies || {}).reduce(
        (acc, [key, value]) => {
          const result = value(key);
          if (result) {
            acc[key] = result;
          }
          return acc;
        },
        {}
      )
    };
  }
  return {
    name: "",
    tables: nameOrConfig.tables,
    workflows: nameOrConfig.workflows,
    policies: Object.entries(nameOrConfig.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}
__name(feature, "feature");
feature.new = (name, config2) => {
  throw new Error("Not implemented");
};

// libs/sdk/declarative/src/lib/functional.ts
function input(value) {
  if (typeof value === "number" || typeof value === "boolean" || value === null) {
    return input.primitive(value);
  }
  if (value.startsWith("context") || value.startsWith("workflow")) {
    return input.workflow(value.replace("context.", ""));
  }
  if (value.startsWith("trigger")) {
    return input.trigger(value.replace("trigger.", ""));
  }
  if (!value.startsWith("@")) {
    return input.primitive(value);
  }
  return {
    input: value
  };
}
__name(input, "input");
((input2) => {
  function primitive(value) {
    return {
      input: `@fixed:${typeof value === "boolean" || typeof value === "number" || value === null ? value : `'${value}'`}`
    };
  }
  input2.primitive = primitive;
  __name(primitive, "primitive");
  function workflow2(path) {
    return {
      input: `@workflow:${path}`
    };
  }
  input2.workflow = workflow2;
  __name(workflow2, "workflow");
  function trigger2(path) {
    return {
      input: `@trigger:${path}`
    };
  }
  input2.trigger = trigger2;
  __name(trigger2, "trigger");
  function field2(name) {
    return {
      input: `@tables:fields.${name}`
    };
  }
  input2.field = field2;
  __name(field2, "field");
})(input || (input = {}));

// libs/sdk/declarative/src/lib/project.ts
function current_Project(config2) {
  return {
    features: config2.modules,
    imports: config2.imports ?? []
  };
}
__name(current_Project, "current_Project");
function project(...features) {
  return features;
}
__name(project, "project");

// libs/compiler/transpilers/src/lib/expression.ts
var QueryBuilder;
((QueryBuilder2) => {
  class Expression2 {
    static {
      __name(this, "Expression");
    }
  }
  QueryBuilder2.Expression = Expression2;
  function createBooleanLiteral(value) {
    return {
      value,
      type: "boolean",
      accept(visitor, context) {
        return visitor.visitBooleanLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createBooleanLiteral = createBooleanLiteral;
  __name(createBooleanLiteral, "createBooleanLiteral");
  function createDateLiteral(value) {
    return {
      value,
      type: "date",
      accept(visitor, context) {
        return visitor.visitDateLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createDateLiteral = createDateLiteral;
  __name(createDateLiteral, "createDateLiteral");
  function createStringLiteral(value, defaultContext) {
    return {
      value,
      type: "string",
      accept(visitor, context = defaultContext) {
        return visitor.visitStringLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createStringLiteral = createStringLiteral;
  __name(createStringLiteral, "createStringLiteral");
  function createNumericLiteral(value) {
    return {
      value,
      type: "numeric",
      accept(visitor, context) {
        return visitor.visitNumericLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNumericLiteral = createNumericLiteral;
  __name(createNumericLiteral, "createNumericLiteral");
  function createNullLiteral(defaultContext) {
    return {
      type: "null",
      accept(visitor, context = defaultContext) {
        return visitor.visitNullLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNullLiteral = createNullLiteral;
  __name(createNullLiteral, "createNullLiteral");
  function createIdentifier(value, defaultContext) {
    return {
      value,
      type: "identifier",
      accept(visitor, context) {
        return visitor.visitIdentifier(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createIdentifier = createIdentifier;
  __name(createIdentifier, "createIdentifier");
  function createCombinator(operator) {
    return {
      operator,
      type: "combinator",
      accept(visitor, context) {
        return visitor.visitCombinator(this, context);
      }
    };
  }
  QueryBuilder2.createCombinator = createCombinator;
  __name(createCombinator, "createCombinator");
  function createBinaryExpression(left, operator, right, defaultContext) {
    return {
      type: "binary",
      left,
      operator,
      right,
      accept(visitor, context = defaultContext) {
        return visitor.visitBinaryExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createBinaryExpression = createBinaryExpression;
  __name(createBinaryExpression, "createBinaryExpression");
  function createGroupExpression(list, combinator, defaultContext) {
    return {
      type: "group",
      combinator,
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitGroupExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createGroupExpression = createGroupExpression;
  __name(createGroupExpression, "createGroupExpression");
  function createQuerySelectExpression(groups, defaultContext) {
    return {
      type: "querySelect",
      value: groups,
      accept(visitor, context = defaultContext) {
        return visitor.visitQuerySelectExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createQuerySelectExpression = createQuerySelectExpression;
  __name(createQuerySelectExpression, "createQuerySelectExpression");
  function createListExpression(list, defaultContext) {
    return {
      type: "list",
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitListExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createListExpression = createListExpression;
  __name(createListExpression, "createListExpression");
})(QueryBuilder || (QueryBuilder = {}));
var Visitor2 = class {
  static {
    __name(this, "Visitor");
  }
};

// libs/compiler/transpilers/src/lib/ast.ts
import { camelcase as camelcase2 } from "stringcase";
var formatInput = /* @__PURE__ */ __name((input2) => input2.join("."), "formatInput");
function collectJoinsFromGroup(it) {
  const tablesNames = [];
  it.data.forEach((it2) => {
    if (it2.operator === "querySelect") {
      throw new Error("querySelect must not be inside a group");
    } else if (it2.operator === "group") {
      const groupJoins = collectJoinsFromGroup(it2);
      groupJoins.forEach((it3) => {
        if (!tablesNames.includes(it3)) {
          tablesNames.push(it3);
        }
      });
    } else if (it2.input.length === 2) {
      const tableOrColumn = it2.input[0];
      if (!tablesNames.includes(tableOrColumn) && it2.input.length === 2) {
        tablesNames.push(tableOrColumn);
      }
    }
  });
  return tablesNames;
}
__name(collectJoinsFromGroup, "collectJoinsFromGroup");
function collectJoins(query2) {
  const columns = query2.input ?? [];
  const groups = query2.data;
  const tablesFromSelect = (columns ?? []).map((it) => {
    if (it.name.split(".").length === 2) {
      return it.name.split(".")[0];
    }
    return "";
  }).filter((it) => it !== "");
  const tablesNames = [...tablesFromSelect];
  groups.forEach((group) => {
    collectJoinsFromGroup(group).forEach((it) => {
      if (!tablesNames.includes(it)) {
        tablesNames.push(it);
      }
    });
  });
  return tablesNames;
}
__name(collectJoins, "collectJoins");
function toAst(it) {
  const operator = it.operator;
  if (it.operator === "querySelect") {
    const columns = it.input ?? [];
    const groups = it.data;
    const groupsAst = [];
    for (const group of groups) {
      const combinator = group.input[0];
      if (combinator !== "and" && combinator !== "or") {
        throw new Error(`Invalid combinator ${combinator}`);
      }
      if (!group.data.length) {
        continue;
      }
      const groupAst = [];
      for (const item of group.data) {
        const result = toAst(item);
        if (result) groupAst.push(result);
      }
      groupsAst.push(
        QueryBuilder.createGroupExpression(
          groupAst,
          QueryBuilder.createCombinator(combinator)
        )
      );
    }
    return QueryBuilder.createQuerySelectExpression(groupsAst, {
      columns: columns ?? [],
      joinsFields: collectJoins(it)
    });
  }
  if (it.operator === "group") {
    const combinator = it.input[0];
    if (combinator !== "and" && combinator !== "or") {
      throw new Error(`Invalid combinator ${combinator}`);
    }
    if (!it.data.length) {
      return null;
    }
    const groupAst = [];
    for (const item of it.data) {
      const result = toAst(item);
      if (result) groupAst.push(result);
    }
    return QueryBuilder.createGroupExpression(
      groupAst,
      QueryBuilder.createCombinator(combinator)
    );
  }
  if (it.operator === "equals") {
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "===",
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "===",
      QueryBuilder.createIdentifier(it.input[0]),
      // QueryBuilder.createIdentifier('WILL_BE_USED_FROM_DESTRUCTURED_INPUT'),
      it.data
    );
  }
  if (it.operator === "one_of") {
    const oneOfArr = it.data.value;
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "in",
        QueryBuilder.createListExpression(oneOfArr.map((a) => pickLiteral(a))),
        { ...it.data, required: true }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "in",
      QueryBuilder.createListExpression(
        oneOfArr.map((a) => QueryBuilder.createIdentifier(a))
      ),
      it.data
    );
  }
  if (it.operator === "ends_with" || it.operator === "contains" || it.operator === "starts_with") {
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        "like",
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "like",
      QueryBuilder.createIdentifier(it.data.value),
      it.data
    );
  }
  if (it.operator === "is") {
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "is",
      pickLiteral(it.data),
      {
        ...it.data,
        required: true
      }
    );
  }
  if (it.operator === "is_empty") {
    const combinator = it.data.inverse ? QueryBuilder.createCombinator("and") : QueryBuilder.createCombinator("or");
    const identifier = QueryBuilder.createIdentifier(formatInput(it.input));
    const nullBnryExpr = QueryBuilder.createBinaryExpression(
      identifier,
      "is",
      QueryBuilder.createNullLiteral(),
      {
        inverse: it.data.inverse,
        required: true
      }
    );
    if (it.data.type === "string") {
      const stringBnryExpr = QueryBuilder.createBinaryExpression(
        identifier,
        "is",
        QueryBuilder.createStringLiteral(""),
        {
          inverse: it.data.inverse,
          required: true
        }
      );
      return QueryBuilder.createGroupExpression(
        [stringBnryExpr, nullBnryExpr],
        combinator,
        {
          inverse: it.data.inverse
        }
      );
    } else {
      return QueryBuilder.createGroupExpression([nullBnryExpr], combinator, {
        inverse: it.data.inverse
      });
    }
  }
  const comparisonMap = {
    less_than: "<",
    more_than: ">",
    less_than_or_equal: "<=",
    more_than_or_equal: ">="
  };
  if (comparisonMap[operator]) {
    const sqlOperator = comparisonMap[operator];
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        sqlOperator,
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      sqlOperator,
      QueryBuilder.createIdentifier(it.data.value),
      // the ui should validate that the value is string in case of dynamic
      it.data
    );
  }
  const dateMap = {
    before: "<",
    after: ">",
    before_on: "<=",
    after_on: ">="
  };
  if (dateMap[operator]) {
    const sqlOperator = dateMap[operator];
    if (it.data.static) {
      return QueryBuilder.createBinaryExpression(
        QueryBuilder.createIdentifier(formatInput(it.input)),
        sqlOperator,
        pickLiteral(it.data),
        {
          ...it.data,
          required: true
        }
      );
    }
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      sqlOperator,
      pickDateOperation(it.data),
      { ...it.data, required: true }
    );
  }
  if (it.operator === "between") {
    return QueryBuilder.createBinaryExpression(
      QueryBuilder.createIdentifier(formatInput(it.input)),
      "between",
      QueryBuilder.createBinaryExpression(
        it.data.min.kind === "@fixed" ? QueryBuilder.createStringLiteral(it.data.min.value) : QueryBuilder.createIdentifier(it.data.min.value),
        "AND",
        it.data.max.kind === "@fixed" ? QueryBuilder.createStringLiteral(it.data.max.value) : QueryBuilder.createIdentifier(it.data.max.value)
      )
    );
  }
  throw new Error(`Operator is not supported. operator: ${it.operator}`);
}
__name(toAst, "toAst");
function pickLiteral(data) {
  switch (data.type) {
    case "string":
      return QueryBuilder.createStringLiteral(data.value);
    case "number":
      return QueryBuilder.createNumericLiteral(data.value);
    case "date":
      return QueryBuilder.createDateLiteral(data.value);
    case "boolean":
      return QueryBuilder.createBooleanLiteral(data.value);
    case "null":
      return QueryBuilder.createNullLiteral();
    default:
      if (data.static && data.value === "null") {
        return QueryBuilder.createNullLiteral();
      }
      throw new Error(`Data Type ${data.type} Not Supported`);
  }
}
__name(pickLiteral, "pickLiteral");
function pickDateOperation(data) {
  const { period, relativeTo, amount } = data;
  if (!["day", "week", "month", "quarter", "year"].includes(period)) {
    throw new Error(`Period ${period} Not Supported`);
  }
  if (!amount) {
    return QueryBuilder.createIdentifier(camelcase2(`current_${period}()`));
  }
  const args = [];
  if (relativeTo && relativeTo !== "now") {
    args.push(`date: '${relativeTo}'`);
  }
  args.push(`amount: ${amount}`);
  const argsObjectLiteral = `{ ${args.join(", ")} }`;
  return QueryBuilder.createIdentifier(`${period}(${argsObjectLiteral})`);
}
__name(pickDateOperation, "pickDateOperation");

// libs/compiler/transpilers/src/lib/factory.ts
var QueryFactory;
((QueryFactory2) => {
  function createEmptyGroupRule() {
    return {
      data: [],
      operator: "group",
      input: ["and"]
    };
  }
  QueryFactory2.createEmptyGroupRule = createEmptyGroupRule;
  __name(createEmptyGroupRule, "createEmptyGroupRule");
  function createGroupRule(combinator, data) {
    return {
      input: [combinator],
      operator: "group",
      data
    };
  }
  QueryFactory2.createGroupRule = createGroupRule;
  __name(createGroupRule, "createGroupRule");
  function createSelectRule(groups, columns) {
    return {
      operator: "querySelect",
      input: columns ?? [],
      data: groups
    };
  }
  QueryFactory2.createSelectRule = createSelectRule;
  __name(createSelectRule, "createSelectRule");
  function createIsEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsEmptyRule = createIsEmptyRule;
  __name(createIsEmptyRule, "createIsEmptyRule");
  function createIsNotEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotEmptyRule = createIsNotEmptyRule;
  __name(createIsNotEmptyRule, "createIsNotEmptyRule");
  function createEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createEqualRule = createEqualRule;
  __name(createEqualRule, "createEqualRule");
  function createGreaterThanRule(input2, data) {
    return {
      operator: "more_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanRule = createGreaterThanRule;
  __name(createGreaterThanRule, "createGreaterThanRule");
  function createGreaterThanEqualRule(input2, data) {
    return {
      operator: "more_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanEqualRule = createGreaterThanEqualRule;
  __name(createGreaterThanEqualRule, "createGreaterThanEqualRule");
  function createLessThanRule(input2, data) {
    return {
      operator: "less_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanRule = createLessThanRule;
  __name(createLessThanRule, "createLessThanRule");
  function createLessThanEqualRule(input2, data) {
    return {
      operator: "less_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanEqualRule = createLessThanEqualRule;
  __name(createLessThanEqualRule, "createLessThanEqualRule");
  function createIsRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsRule = createIsRule;
  __name(createIsRule, "createIsRule");
  function createIsNotRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotRule = createIsNotRule;
  __name(createIsNotRule, "createIsNotRule");
  function createNotEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotEqualRule = createNotEqualRule;
  __name(createNotEqualRule, "createNotEqualRule");
  function createOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createOneOfRule = createOneOfRule;
  __name(createOneOfRule, "createOneOfRule");
  function createNotOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotOneOfRule = createNotOneOfRule;
  __name(createNotOneOfRule, "createNotOneOfRule");
  function createBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createBetweenRule = createBetweenRule;
  __name(createBetweenRule, "createBetweenRule");
  function createNotBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotBetweenRule = createNotBetweenRule;
  __name(createNotBetweenRule, "createNotBetweenRule");
  function createContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createContainRule = createContainRule;
  __name(createContainRule, "createContainRule");
  function createMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createMatchRule = createMatchRule;
  __name(createMatchRule, "createMatchRule");
  function createNotMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotMatchRule = createNotMatchRule;
  __name(createNotMatchRule, "createNotMatchRule");
  function createNotContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotContainRule = createNotContainRule;
  __name(createNotContainRule, "createNotContainRule");
  function createStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createStartsWithRule = createStartsWithRule;
  __name(createStartsWithRule, "createStartsWithRule");
  function createNotStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotStartsWithRule = createNotStartsWithRule;
  __name(createNotStartsWithRule, "createNotStartsWithRule");
  function createEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createEndsWithRule = createEndsWithRule;
  __name(createEndsWithRule, "createEndsWithRule");
  function createNotEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotEndsWithRule = createNotEndsWithRule;
  __name(createNotEndsWithRule, "createNotEndsWithRule");
  function createPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: false
      }
    };
  }
  QueryFactory2.createPeriodRule = createPeriodRule;
  __name(createPeriodRule, "createPeriodRule");
  function createNotPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: true
      }
    };
  }
  QueryFactory2.createNotPeriodRule = createNotPeriodRule;
  __name(createNotPeriodRule, "createNotPeriodRule");
})(QueryFactory || (QueryFactory = {}));

// libs/compiler/transpilers/src/lib/visitors/js.visitor.ts
var JsVisitor = class extends Visitor2 {
  constructor(_rootExpr) {
    super();
    this._rootExpr = _rootExpr;
  }
  static {
    __name(this, "JsVisitor");
  }
  visitCombinator(expr, context) {
    return "";
  }
  visitListExpr(expr, context) {
    const list = expr.value.map((item) => item.accept(this, context));
    return list.join(",");
  }
  visitQuerySelectExpr(expr, context) {
    return "";
  }
  visitGroupExpr(expr, context) {
    throw new Error("Method not implemented.");
  }
  visitDateLiteralExpr(expr, context = {}) {
    return expr.value;
  }
  visitBinaryExpr(expr, context) {
    const left = expr.left.accept(this, context);
    const right = expr.right.accept(this, context);
    switch (expr.operator) {
      case "===":
        return `(${left} === ${right})`;
      case "like":
        switch (context.pattern) {
          case "%{}":
            return `${left}.endsWith(${right})`;
          case "{}%":
            return `${left}.startsWith(${right})`;
          case "%{}%":
            return `${left}.includes(${right})`;
          default:
            throw new Error(
              `Like operator not supported. pattern: ${context.pattern}`
            );
        }
        break;
      default:
        throw new Error(
          `Expression is not supported. operator: ${expr.operator}`
        );
    }
  }
  visitNumericLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitNullLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitBooleanLiteralExpr(expr) {
    return `${expr.value}`;
  }
  visitStringLiteralExpr(expr) {
    return `"${expr.value}"`;
  }
  visitIdentifier(expr) {
    return `${expr.value}`;
  }
  execute() {
    return this.visitGroupExpr(this._rootExpr, {});
  }
};

// libs/sdk/declarative/src/lib/utils.ts
import { Project as Project2, StructureKind, SyntaxKind } from "ts-morph";
function isValidIdentifier(property) {
  const regex = /^[a-zA-Z_$][0-9a-zA-Z_$]*$/;
  return regex.test(property);
}
__name(isValidIdentifier, "isValidIdentifier");
function createPathProxy(path = "###$$$###") {
  return new Proxy(
    () => {
    },
    {
      get(target, property) {
        if (property === "valueOf") {
          return () => path;
        }
        if (property === Symbol.toPrimitive) {
          return (hint) => {
            if (hint === "string") {
              return path;
            }
            throw new Error("Invalid hint");
          };
        }
        if (path === "###$$$###") {
          return createPathProxy(`@trigger:` + String(property));
        }
        return createPathProxy(
          path + (typeof property === "string" ? isValidIdentifier(property) ? `.${property}` : `['${property}']` : `.${String(property)}`)
        );
      },
      apply(target, thisArg, argumentsList) {
        const argsString = argumentsList.map((arg) => JSON.stringify(arg)).join(", ");
        return createPathProxy(path + `(${argsString})`);
      }
    }
  );
}
__name(createPathProxy, "createPathProxy");
function createEnvProxy() {
  return new Proxy(process.env, {
    get(target, property, receiver) {
      if (typeof property === "string") {
        return `process.env.${property}`;
      }
      return Reflect.get(target, property, receiver);
    }
  });
}
__name(createEnvProxy, "createEnvProxy");
function getErrors(fn) {
  try {
    fn();
    return [];
  } catch (e) {
    return [e].flat();
  }
}
__name(getErrors, "getErrors");
function coerceString(value) {
  if (value === void 0 || value === null) {
    return value;
  }
  if (typeof value === "number") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.join(".");
  }
  return value.valueOf();
}
__name(coerceString, "coerceString");
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${arg})`;
  const guard = transferable.toString();
  const project2 = new Project2({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind.ArrowFunction);
  const inputs = {};
  const parameters = guardFunction.getParameters();
  if (parameters.length > 1) {
    inputs["request"] = {
      static: true,
      type: "IncomingMessage",
      value: `(context.env as { incoming: IncomingMessage }).incoming`,
      data: {
        parameterName: "request",
        standalone: true
      },
      structure: [
        {
          kind: StructureKind.ImportDeclaration,
          moduleSpecifier: "http",
          namedImports: ["IncomingMessage"]
        }
      ]
    };
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!parent) {
      inputs["trigger"] = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs[v] = {
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()"
      }
    };
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = /* @__PURE__ */ __name((ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  }, "isOutputReturn");
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  for (const ret of returns) {
    if (isOutputReturn(ret)) {
      continue;
    }
    const isReturningCall = ret.getExpressionIfKind(SyntaxKind.CallExpression);
    let returnValue = ret.getText().trim().replace("return ", "");
    if (returnValue.endsWith(";")) {
      returnValue = returnValue.slice(0, -1);
    }
    if (returnValue === "return") {
      ret.replaceWithText(options.setOutput());
    } else {
      ret.replaceWithText(
        options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
      );
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs
  };
}
__name(refineExecute, "refineExecute");

// libs/sdk/declarative/src/lib/query.ts
function where(column, operator, value) {
  const columnName = coerceColumnName(column);
  let condition;
  value = coerceString(value);
  switch (operator) {
    case "after":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "after",
        value
      );
      break;
    case "before":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "before",
        value
      );
      break;
  }
  if (condition) {
    return {
      kind: "condition",
      implementation: condition
    };
  }
  if (typeof value !== "string") {
    throw new Error(`Value ${value} is not supported`);
  }
  const data = {
    type: "string",
    input: value
  };
  switch (operator) {
    case "equals":
      condition = QueryFactory.createEqualRule([columnName], data);
      break;
    case "not_equals":
      condition = QueryFactory.createNotEqualRule([columnName], data);
      break;
    case "more_than":
      condition = QueryFactory.createGreaterThanRule([columnName], data);
      break;
    case "less_than":
      condition = QueryFactory.createLessThanRule([columnName], data);
      break;
    case "more_than_or_equal":
      condition = QueryFactory.createGreaterThanEqualRule([columnName], data);
      break;
    case "less_than_or_equal":
      condition = QueryFactory.createLessThanEqualRule([columnName], data);
      break;
    case "is":
      condition = QueryFactory.createIsRule([columnName], data);
      break;
    case "is_not_empty":
      condition = QueryFactory.createIsNotEmptyRule([columnName], data);
      break;
    case "is_empty":
      condition = QueryFactory.createIsEmptyRule([columnName], data);
      break;
    case "contains":
      condition = QueryFactory.createContainRule([columnName], data);
      break;
    case "starts_with":
      condition = QueryFactory.createStartsWithRule([columnName], data);
      break;
    case "ends_with":
      condition = QueryFactory.createEndsWithRule([columnName], data);
      break;
    default:
      throw new Error(`Operator ${operator} is not supported`);
  }
  return {
    kind: "condition",
    implementation: condition
  };
}
__name(where, "where");
function sort(name, input2) {
  return {
    kind: "sort",
    implementation: {
      id: coerceColumnName(name),
      input: input2.startsWith("@fixed") ? input2 : `@fixed:${input2}`
    }
  };
}
__name(sort, "sort");
function isKind(featureOrKind, kind) {
  if (!featureOrKind) {
    return false;
  }
  if (typeof featureOrKind === "string") {
    return (feature2) => feature2 && feature2.kind === featureOrKind;
  }
  return featureOrKind.kind === kind;
}
__name(isKind, "isKind");
function assertKind(feature2, kind, label) {
  if (!feature2 || feature2.kind !== kind) {
    throw new Error(label ?? `Expected ${kind} feature`);
  }
}
__name(assertKind, "assertKind");
function query(...features) {
  const sorts = features.filter(isKind("sort"));
  const columns = features.filter((f) => f.kind === "select").map((f) => f.implementation);
  const conditions = features.filter(isKind("condition"));
  const groups = [
    ...features.filter((f) => f.kind === "group"),
    and(...conditions)
    // wrap this in an "and" group to simulate implicit "and" condition
  ].map((f) => f.implementation);
  const limit2 = features.find(isKind("limit"))?.implementation;
  return {
    whereBy: QueryFactory.createSelectRule(groups, columns),
    sortBy: sorts.map((it) => it.implementation),
    limit: limit2
  };
}
__name(query, "query");
query.sql = (sql) => {
};
function select(name) {
  return {
    kind: "select",
    implementation: {
      name
    }
  };
}
__name(select, "select");
function and(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("and", rules)
  };
}
__name(and, "and");
function or(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("or", rules)
  };
}
__name(or, "or");
var coerceColumnName = /* @__PURE__ */ __name((column) => {
  if (!column.startsWith("@tables")) {
    return `@tables:fields.${column}`;
  }
  return column;
}, "coerceColumnName");
var date;
((date2) => {
  let after;
  ((after2) => {
    function startOfThisWeek() {
      return weeksAgo(0);
    }
    after2.startOfThisWeek = startOfThisWeek;
    __name(startOfThisWeek, "startOfThisWeek");
    function weekAgo() {
      return weeksAgo(1);
    }
    after2.weekAgo = weekAgo;
    __name(weekAgo, "weekAgo");
    function weeksAgo(amount, relativeTo = "now") {
      return {
        period: "week",
        amount: -Math.abs(amount),
        relativeTo
      };
    }
    after2.weeksAgo = weeksAgo;
    __name(weeksAgo, "weeksAgo");
    function weekInYear(n, relativeTo = "now") {
    }
    __name(weekInYear, "weekInYear");
    function monthInYear(n) {
    }
    __name(monthInYear, "monthInYear");
    function startOfThisMonth() {
      return monthsAgo(0);
    }
    after2.startOfThisMonth = startOfThisMonth;
    __name(startOfThisMonth, "startOfThisMonth");
    function monthAgo() {
      return monthsAgo(1);
    }
    after2.monthAgo = monthAgo;
    __name(monthAgo, "monthAgo");
    function monthsAgo(amount) {
      return {
        period: "month",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.monthsAgo = monthsAgo;
    __name(monthsAgo, "monthsAgo");
    function startOfThisYear() {
      return yearsAgo(0);
    }
    after2.startOfThisYear = startOfThisYear;
    __name(startOfThisYear, "startOfThisYear");
    function yearAgo() {
      return yearsAgo(1);
    }
    after2.yearAgo = yearAgo;
    __name(yearAgo, "yearAgo");
    function yearsAgo(amount) {
      return {
        period: "year",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.yearsAgo = yearsAgo;
    __name(yearsAgo, "yearsAgo");
  })(after = date2.after || (date2.after = {}));
})(date || (date = {}));
function limit(upTo) {
  return {
    kind: "limit",
    implementation: upTo
  };
}
__name(limit, "limit");

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config2 = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config2.message
    }
  };
}
__name(mandatory, "mandatory");
var required = mandatory;
function unique(config2 = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config2.message
      }
    }
  ];
}
__name(unique, "unique");
function defineValidation(config2) {
  return {
    name: config2.name,
    config: config2
  };
}
__name(defineValidation, "defineValidation");
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config2) {
  const additionalFields = {};
  const idField = Object.values(config2.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config2.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config2.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config2.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config2.fields,
      ...additionalFields
    },
    constraints: config2.constraints || []
  };
}
__name(table, "table");
table.unique = (...fields) => {
  return {
    type: "unique",
    details: {
      columns: fields
    }
  };
};
table.index = (...fields) => {
  return {
    type: "index",
    details: {
      columns: fields
    }
  };
};
table.use = useTable;
function useTable(name) {
  return {
    command: "QueryTable",
    payload: {
      name
    }
  };
}
__name(useTable, "useTable");
function field(config2) {
  const { type, validations = [], metadata = {}, ...rest } = config2;
  return {
    type: config2.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
__name(field, "field");
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      if (type.endsWith(".rule")) {
        const reports = [];
        return reports;
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
  function primary(config2) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config2.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config2.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  __name(primary, "primary");
  function shortText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  __name(shortText, "shortText");
  function longText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  __name(longText, "longText");
  function datetime(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  __name(datetime, "datetime");
  function url(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  __name(url, "url");
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  __name(integer, "integer");
  function decimal(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  __name(decimal, "decimal");
  function price(config2 = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config2;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  __name(price, "price");
  function boolean(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  __name(boolean, "boolean");
  function bytes(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  __name(bytes, "bytes");
  function relation(config2) {
    return field2({
      type: "relation",
      metadata: config2,
      validations: config2.validations
    });
  }
  field2.relation = relation;
  __name(relation, "relation");
})(field || (field = {}));
field.enum = (config2) => {
  return field({
    type: "single-select",
    metadata: {
      style: "enum",
      values: config2.values,
      defaultValue: config2.defaultValue
    }
  });
};
function useField(name, value) {
  value = coerceString(value);
  if (value === void 0) {
    return {
      input: {
        command: "QueryFieldName",
        payload: {
          name
        }
      }
    };
  }
  return {
    ...input(value),
    name: {
      command: "QueryField",
      payload: {
        name
      }
    }
  };
}
__name(useField, "useField");
useField.increment = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      increment: true
    }
  };
};
useField.decrement = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      decrement: true
    }
  };
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}
__name(index, "index");

// libs/sdk/declarative/src/lib/workflow.ts
import { Project as Project3, StructureKind as StructureKind2, SyntaxKind as SyntaxKind2 } from "ts-morph";
function experimental_wokflow(features) {
}
__name(experimental_wokflow, "experimental_wokflow");
function workflow(name, config2) {
  const execute = config2.trigger.refineExecute(config2.execute);
  return {
    name,
    trigger: config2.trigger,
    raw: !Object.keys(config2.trigger.inputs ?? {}).length,
    execute,
    tag: config2.tag
  };
}
__name(workflow, "workflow");
function defineTrigger(type, config2) {
  return {
    type,
    config: config2
  };
}
__name(defineTrigger, "defineTrigger");
var trigger;
((trigger2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? trigger2 : defineTrigger;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown trigger type: ${type}`);
  }
  trigger2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
})(trigger || (trigger = {}));
((trigger2) => {
  function schedule(config2) {
    return {
      type: "node-cron-trigger",
      config: config2,
      policies: [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.schedule = schedule;
  __name(schedule, "schedule");
})(trigger || (trigger = {}));
function inputize(inputFn) {
  const inputs = {};
  const guard = inputFn.toString();
  const project2 = new Project3({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind2.ArrowFunction);
  if (guardFunction) {
    const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind2.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(SyntaxKind2.ReturnStatement);
    const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
      SyntaxKind2.ObjectLiteralExpression
    );
    returnObjExpr.getProperties().forEach((prop) => {
      const propAssignment = prop.asKindOrThrow(SyntaxKind2.PropertyAssignment);
      const propName = propAssignment.getName();
      const withSelectorAndAgainst = propAssignment.getInitializerIfKind(
        SyntaxKind2.ObjectLiteralExpression
      );
      if (withSelectorAndAgainst) {
        const propValue = withSelectorAndAgainst;
        const selectFn = propValue.getPropertyOrThrow(
          "select"
        );
        const againstFn = propValue.getProperty(
          "against"
        );
        const usageText = selectFn.getInitializerOrThrow().getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: againstFn.getInitializerOrThrow().getText()
          }
        };
      } else {
        const usageText = propAssignment.getInitializerIfKindOrThrow(SyntaxKind2.PropertyAccessExpression).getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: "z.any()"
          }
        };
      }
    });
  }
  return inputs;
}
__name(inputize, "inputize");
((trigger2) => {
  function http(config2) {
    return {
      type: "http",
      inputs: config2.input ? inputize(config2.input) : {},
      config: {
        ...config2,
        params: [
          {
            name: "output",
            type: "trigger.http.output"
          }
        ],
        structures: [
          {
            kind: StructureKind2.ImportDeclaration,
            moduleSpecifier: "@january/declarative",
            namedImports: ["trigger"]
          }
        ]
      },
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => `input.${key}`, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.http = http;
  __name(http, "http");
})(trigger || (trigger = {}));
((trigger2) => {
  function sse(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => "input", "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.sse = sse;
  __name(sse, "sse");
  function websocket(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.websocket = websocket;
  __name(websocket, "websocket");
  function stream(config2) {
    return {
      type: "stream",
      inputs: config2.input ? inputize(config2.input) : {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => `input.${key}`, "replaceKey"),
          setOutput: /* @__PURE__ */ __name((arg) => `return ${arg}`, "setOutput")
        });
      }, "refineExecute")
    };
  }
  trigger2.stream = stream;
  __name(stream, "stream");
})(trigger || (trigger = {}));
((trigger2) => {
  function github(config2) {
    const inputs = {};
    return {
      type: "github-trigger",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.github = github;
  __name(github, "github");
})(trigger || (trigger = {}));
((trigger2) => {
  function tus(config2) {
    const inputs = {};
    return {
      type: "tus",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(execute, {
          replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
        });
      }, "refineExecute")
    };
  }
  trigger2.tus = tus;
  __name(tus, "tus");
})(trigger || (trigger = {}));
((trigger2) => {
  function file(config2) {
    return {
      type: "file",
      config: {
        ...config2,
        rewrite: config2.rewrite ? config2.rewrite.toString() : void 0
      },
      policies: config2.policies ?? [],
      refineExecute: /* @__PURE__ */ __name((execute) => {
        return refineExecute(
          () => {
          },
          {
            replaceKey: /* @__PURE__ */ __name((key) => key, "replaceKey")
          }
        );
      }, "refineExecute")
    };
  }
  trigger2.file = file;
  __name(file, "file");
})(trigger || (trigger = {}));
function policy(rule) {
  return rule;
}
__name(policy, "policy");
function definePolicy(rule) {
  return (name) => rule;
}
__name(definePolicy, "definePolicy");
((policy2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? policy2 : definePolicy;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown policy type: ${type}`);
  }
  policy2.fromConfig = fromConfig;
  __name(fromConfig, "fromConfig");
  function authenticated() {
    return (name) => `
    import { Context } from 'hono';
    import { verifyToken } from './subject';

    export async function ${name}(context: Context) {
      return verifyToken(context.req.header('Authorization'));
    }
  `;
  }
  policy2.authenticated = authenticated;
  __name(authenticated, "authenticated");
  function http() {
    return () => "";
  }
  __name(http, "http");
  function github(config2) {
    if (!config2.events || !config2.events.length || !config2.guard) {
      return () => "";
    }
    const project2 = new Project3({
      useInMemoryFileSystem: true
    });
    let body = "return true";
    if (config2.guard) {
      const guard = config2.guard.toString();
      const sourceFile = project2.createSourceFile(
        "guard.ts",
        `const guard = ${guard}`
      );
      const guardFunction = sourceFile.getVariableDeclarationOrThrow("guard").getInitializerOrThrow();
      const isBlock = guardFunction.getBody().isKind(SyntaxKind2.Block);
      body = isBlock ? guardFunction.getBodyText() : `return ${guardFunction.getBodyText()}`;
    }
    return (name) => `
    import { EmitterWebhookEvent } from '@octokit/webhooks';
    import { isEventOfType } from '../core/github-webhooks';

    export async function ${name}(event: EmitterWebhookEvent) {
      if(isEventOfType(event, ${(config2.events ?? []).map((it) => `'${it}'`).join(", ")})) {
        ${body}
      }
      return false;

  }`;
  }
  policy2.github = github;
  __name(github, "github");
})(policy || (policy = {}));
policy.unstable_country = (country) => {
  return `@trigger:context.country === '${country}'`;
};

// libs/sdk/evaluator/src/lib/evaluate.ts
init_src();
var callers = {
  project,
  table,
  feature,
  workflow,
  trigger: trigger.fromConfig,
  field: field.fromConfig,
  policy: policy.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  useTable,
  useField,
  query,
  select,
  sort,
  where,
  limit,
  and,
  or,
  input,
  index,
  withTrigger: /* @__PURE__ */ __name((...args) => {
  }, "withTrigger")
};
function call(node, parent = null, metadata) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node.caller}`);
    }
    const args = node.arguments.map((it) => call(it, node));
    if (type.length) {
      args.unshift(type.join("."));
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => call(it, node));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      if (metadata === "actions") {
        obj[key] = call(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          node,
          key
        );
      } else {
        obj[key] = call(value, node, key);
      }
    }
    return obj;
  }
  return node;
}
__name(call, "call");
function diagnose(service, ast) {
  const reports = [];
  if (Checker.isCallExpression(ast.node)) {
    const [implFn, ...type] = ast.node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${ast.node.caller}`);
    }
    const args = [ast, service];
    reports.push(
      ...ast.node.arguments.map(
        (it) => diagnose(service, {
          parent: ast,
          node: it
        })
      )
    );
    if (type.length) {
      args.unshift([...type, "rule"].join("."));
      reports.push(...callerImpl(...args));
    } else {
      if ("rule" in callerImpl) {
        reports.push(...callerImpl.rule(...args));
      }
    }
    return reports;
  }
  if (Checker.isArrayExpression(ast.node)) {
    return ast.node.map(
      (it) => diagnose(service, {
        parent: ast,
        node: it
      })
    );
  }
  if (Checker.isObjectExpression(ast.node)) {
    for (const [key, value] of Object.entries(ast.node)) {
      reports.push(
        ...diagnose(service, {
          parent: ast,
          node: value
        })
      );
    }
    return reports;
  }
  return reports;
}
__name(diagnose, "diagnose");
async function defensiveEvaluate(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  const features = call(ast.project);
  const service = {
    getFeature(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "feature") {
          return features.find(
            (feature2) => feature2.name === parent.node.arguments[0]
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    getWorkflow(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "workflow") {
          const feature2 = this.getFeature(parent);
          const [workflowName] = parent.node.arguments;
          return feature2?.workflows.find(
            (workflow2) => workflow2.name === workflowName
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    duplicateWorkflowTriggerConfig: /* @__PURE__ */ __name((relatedWorkflow, check) => {
      for (const feature2 of features) {
        for (const workflow2 of feature2.workflows) {
          if (workflow2 === relatedWorkflow) {
            continue;
          }
          if (check(workflow2, feature2)) {
            return true;
          }
        }
      }
      return false;
    }, "duplicateWorkflowTriggerConfig"),
    hasField: /* @__PURE__ */ __name((name) => features.some(
      (feature2) => Object.keys(feature2.tables ?? {}).some(
        (table2) => Object.keys(feature2.tables[table2].fields).includes(name)
      )
    ), "hasField"),
    hasTable: /* @__PURE__ */ __name((name) => features.some((feature2) => {
      return (feature2.tables ?? {})[name];
    }), "hasTable"),
    inUniqueFeature: /* @__PURE__ */ __name((name) => {
      let count = 0;
      for (const feature2 of features) {
        if (feature2.name === name) {
          count++;
        }
      }
      return count === 1;
    }, "inUniqueFeature"),
    isUniqueWorkflow: /* @__PURE__ */ __name((name) => {
      for (const feature2 of features) {
        let count = 0;
        for (const workflow2 of feature2.workflows) {
          if (workflow2.name === name) {
            count++;
          }
        }
        if (count > 1) {
          return false;
        }
      }
      return true;
    }, "isUniqueWorkflow"),
    validateName(name, context) {
      const errors = [];
      if (typeof name !== "string") {
        errors.push(`${context} must be a string`);
      } else if (name.trim().length === 0) {
        errors.push(`${context} must not be empty`);
      }
      return errors;
    }
  };
  return {
    reports: [],
    definition: {
      features,
      imports: ast.imports
    }
  };
}
__name(defensiveEvaluate, "defensiveEvaluate");
async function evaluate(code) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    feature: call(ast.project),
    imports: ast.imports
  };
}
__name(evaluate, "evaluate");
async function compare(a, b) {
  const removeSpans = /* @__PURE__ */ __name((node) => {
    if (!node) return "";
    return JSON.stringify(node, (key, value) => {
      if (key === "span") {
        return void 0;
      }
      return value;
    });
  }, "removeSpans");
  return removeSpans((await legacy_parse(a))?.project ?? null) === removeSpans((await legacy_parse(a))?.project ?? null);
}
__name(compare, "compare");

// libs/sdk/evaluator/src/lib/infertype.ts
init_src();
var noop = /* @__PURE__ */ __name(() => {
}, "noop");
var callers2 = {
  project: /* @__PURE__ */ __name((...args) => {
    const [name, config2] = args;
    return args[0];
  }, "project"),
  feature: /* @__PURE__ */ __name((...args) => {
    const [name, config2] = args;
    return {
      workflows: config2.workflows,
      tables: config2.tables,
      featureName: name
    };
  }, "feature"),
  table,
  field,
  workflow,
  trigger: trigger.fromConfig,
  useTable: noop,
  mandatory: noop,
  required: noop,
  unique: noop,
  useField: noop,
  query: noop,
  select: noop,
  sort: noop,
  where: noop,
  limit: noop,
  and: noop,
  or: noop,
  input: noop,
  index: noop
};
function call2(node, metadata, parent) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    const callerImpl = callers2[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node.caller}`);
    }
    const args = node.arguments.map((it) => call2(it));
    if (type.length) {
      args.unshift([...type, "dts"].join("."));
    } else {
      if ("dts" in callerImpl) {
        return callerImpl.dts(...args, metadata);
      }
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => call2(it));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      if (metadata === "actions") {
        obj[key] = call2(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          key
        );
      } else {
        obj[key] = call2(value, key, node);
      }
    }
    return obj;
  }
  return node;
}
__name(call2, "call");
async function inferType(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    return [];
  }
  const result = call2(ast.project);
  return result;
}
__name(inferType, "inferType");

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project as Project4, SyntaxKind as SyntaxKind3, VariableDeclarationKind as VariableDeclarationKind2 } from "ts-morph";
function getDefaultExport(code, project2 = new Project4({ useInMemoryFileSystem: true })) {
  const sourceFile = project2.createSourceFile("index.ts", code);
  const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
  const exportAssignment = defaultExport.getValueDeclarationOrThrow();
  return {
    value: exportAssignment.getExpression().getFullText(),
    sourceFile
  };
}
__name(getDefaultExport, "getDefaultExport");
function getReturnTypeOfDefaultExport(workflowOutput, project2 = new Project4({ useInMemoryFileSystem: true })) {
  const sourceFile = project2.createSourceFile("index.ts", workflowOutput);
  const defaultExport = sourceFile.getDefaultExportSymbolOrThrow();
  const exportAssignment = defaultExport.getValueDeclarationOrThrow();
  const fn = exportAssignment.getFirstDescendantByKind(SyntaxKind3.ArrowFunction) ?? exportAssignment.getFirstDescendantByKindOrThrow(
    SyntaxKind3.FunctionDeclaration
  );
  const returnStatement = fn.getFirstDescendantByKind(
    SyntaxKind3.ReturnStatement
  );
  const returnType = fn.getReturnType();
  if (!returnStatement) {
    return {
      properties: [],
      returnCode: "",
      returnTypeStr: ""
    };
  }
  const objectLiteral = returnStatement.getFirstChildByKind(
    SyntaxKind3.ObjectLiteralExpression
  );
  if (!objectLiteral) {
    throw new Error("Return statement should return an object literal");
  }
  return {
    returnTypeStr: returnType.getText(),
    // replace "steps" with "" to get the name of the property
    returnCode: returnStatement.getText().replace(/steps\./g, ""),
    properties: returnType.getProperties().map((it) => ({
      name: it.getName(),
      primitiveType: it.getValueDeclaration()?.getType().getText(),
      parameter: it.getValueDeclaration()?.getFirstDescendantByKindOrThrow(SyntaxKind3.PropertyAccessExpression)?.getText()
    }))
  };
}
__name(getReturnTypeOfDefaultExport, "getReturnTypeOfDefaultExport");
function assignDefaultExportToVar(code, varName, project2 = new Project4({ useInMemoryFileSystem: true })) {
  const { value, sourceFile } = getDefaultExport(code, project2);
  const varStmt = sourceFile.addVariableStatement({
    declarationKind: VariableDeclarationKind2.Const,
    declarations: [
      {
        name: varName,
        initializer: value
      }
    ]
  });
  return varStmt.getFullText();
}
__name(assignDefaultExportToVar, "assignDefaultExportToVar");

// libs/compiler/generator/src/lib/sourcecode.ts
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
import { basename, dirname, extname, join as join3, relative, sep } from "path";
import { Injectable as Injectable7, Injector as Injector6, ServiceLifetime as ServiceLifetime7 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project5,
  ScriptTarget,
  StructureKind as StructureKind3,
  SyntaxKind as SyntaxKind4
} from "ts-morph";
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project5(options);
}
__name(getMorph, "getMorph");
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __publicField(this, "_projectFS", Injector6.GetRequiredService(ProjectFS));
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join3(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = /* @__PURE__ */ __name(function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
        case moduleSpecifier.startsWith("#{entity}"): {
          const entityName = moduleSpecifier.replace("#{entity}/", "");
          const files = __privateGet(this, _morphProject).getSourceFiles(
            join3(__privateGet(this, _outputDir), "/**/src/features/**/*.entity.ts")
          );
          const filePath = __privateMethod(this, _VirtualProject_instances, findClassSourceFile_fn).call(this, files, entityName);
          if (!filePath) {
            throw new Error(`Entity ${entityName} file not found.`);
          }
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(`${moduleSpecifier}.ts`);
          break;
        }
      }
    }
  }
}, "#resolveImports");
findClassSourceFile_fn = /* @__PURE__ */ __name(function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
}, "#findClassSourceFile");
exportsCommands_fn = /* @__PURE__ */ __name(function() {
  const commandsFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const routerFile of commandsFiles) {
    const fileName = routerFile.getBaseName();
    const tag = dirname(routerFile.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join3(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
}, "#exportsCommands");
exportRoutes_fn = /* @__PURE__ */ __name(function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono][]`,
    { overwrite: true }
  );
}, "#exportRoutes");
exportListeners_fn = /* @__PURE__ */ __name(function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
}, "#exportListeners");
exportJobs_fn = /* @__PURE__ */ __name(function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
}, "#exportJobs");
exportEntities_fn = /* @__PURE__ */ __name(function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities= [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
}, "#exportEntities");
tuneImports_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      assertElements: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
    importDeclaration.getAssertClause()?.getElements().forEach((item) => {
      uniqueImports[moduleSpecifierValue].assertElements.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    const assertElements = Array.from(it.assertElements.values());
    file.addImportDeclaration({
      kind: StructureKind3.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements,
      defaultImport: it.defaultImport,
      isTypeOnly: false,
      namespaceImport: it.namespaceImport
    });
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    file.addImportDeclaration({
      kind: StructureKind3.ImportDeclaration,
      moduleSpecifier,
      namedImports,
      assertElements: [],
      defaultImport: it.defaultImport,
      isTypeOnly: true
    });
  });
}, "#tuneImports");
removeUnusedImports_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind4.Identifier).some(
        (it) => it.getText() === importedName && it.getParent() !== namedImport
      );
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
}, "#removeUnusedImports");
moveImportsToTop_fn = /* @__PURE__ */ __name(function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index2) => {
    file.insertImportDeclaration(index2, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
}, "#moveImportsToTop");
__name(VirtualProject, "VirtualProject");
VirtualProject = __decorateClass([
  Injectable7({
    lifetime: ServiceLifetime7.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}
__name(getLastNParts, "getLastNParts");
function emitFiles(concreteStructure, generateDir) {
  const vProject = new VirtualProject(generateDir);
  vProject.generate(concreteStructure);
  return {
    files: vProject.getOutput(),
    save: vProject.emit.bind(vProject),
    cleanup: /* @__PURE__ */ __name(() => vProject.cleanup(), "cleanup")
  };
}
__name(emitFiles, "emitFiles");
function emitFilesNoConfig(concreteStructure, generateDir) {
  const projectConfig = Injector6.GetRequiredService(ProjectConfig);
  const vProject = new VirtualProject(generateDir);
  if (generateDir) {
    const config2 = projectConfig.getConfig();
    projectConfig.updateConfig({
      basePath: join3(generateDir, config2.basePath),
      features: join3(generateDir, config2.features)
    });
  }
  vProject.generate(concreteStructure);
  return {
    files: vProject.getOutput(),
    save: vProject.emit.bind(vProject),
    cleanup: /* @__PURE__ */ __name(() => vProject.cleanup(), "cleanup")
  };
}
__name(emitFilesNoConfig, "emitFilesNoConfig");

// libs/compiler/generator/src/bundling/virtual.ts
import esbuild from "esbuild";
import { dirname as dirname2, relative as relative2, resolve } from "path";
var nodeExternalsPlugin = /* @__PURE__ */ __name((packageJsonV) => {
  const packageJson = JSON.parse(packageJsonV);
  const keys = [
    "dependencies",
    "devDependencies",
    "peerDependencies",
    "optionalDependencies"
  ];
  const nodeModules = keys.map((key) => Object.keys(packageJson[key] || {})).flat();
  return {
    name: "node-externals",
    setup(build) {
      build.onResolve(
        {
          namespace: "virtual",
          filter: /.*/
        },
        (args) => {
          let moduleName = args.path.split("/")[0];
          if (args.path.startsWith("@")) {
            const split = args.path.split("/");
            moduleName = `${split[0]}/${split[1]}`;
          }
          if (nodeModules.includes(moduleName)) {
            return { path: args.path, external: true };
          }
          return null;
        }
      );
    }
  };
}, "nodeExternalsPlugin");
function virtualBundle(options) {
  const getFile3 = /* @__PURE__ */ __name((name) => {
    const file = options.files.find((file2) => file2.path.endsWith(name));
    if (!file) {
      return null;
    }
    return file;
  }, "getFile");
  const packageJsonFile = getFile3("package.json");
  const configJson = getFile3("tsconfig.json");
  const filesMap = Object.fromEntries(
    options.files.map((file) => [file.path, file.content])
  );
  return esbuild.build({
    entryPoints: [options.src],
    write: false,
    platform: "node",
    treeShaking: true,
    minify: true,
    format: "esm",
    outfile: options.dist,
    keepNames: true,
    bundle: true,
    assetNames: "[name]",
    loader: {
      ".json": "file"
    },
    tsconfigRaw: configJson ? JSON.parse(configJson.content) : void 0,
    plugins: [
      packageJsonFile ? nodeExternalsPlugin(packageJsonFile.content) : {
        name: "node-externals",
        setup(build) {
        }
      },
      {
        name: "virtual-files",
        setup(build) {
          build.onResolve({ filter: /.*/ }, (args) => {
            const path = relative2(
              process.cwd(),
              resolve(dirname2(args.importer), args.path)
            );
            const attempts = [path, `${path}.ts`, `${path}/index.ts`];
            for (const attempt of attempts) {
              if (attempt in filesMap) {
                return {
                  path: attempt,
                  namespace: "virtual"
                };
              }
            }
            return null;
          });
          build.onLoad(
            {
              filter: /.*/,
              namespace: "virtual"
            },
            (args) => {
              return {
                contents: filesMap[args.path],
                loader: "default"
              };
            }
          );
        }
      }
    ]
  });
}
__name(virtualBundle, "virtualBundle");

// libs/compiler/generator/src/bundling/bundler.ts
import esbuild2 from "esbuild";
import { nodeExternalsPlugin as nodeExternalsPlugin2 } from "esbuild-node-externals";
import { readFileSync as readFileSync2 } from "fs";
import { join as join4 } from "path";
function bundle(options) {
  const tsconfig = JSON.parse(
    readFileSync2(join4(options.projectRoot, "tsconfig.json"), "utf-8")
  );
  const paths = tsconfig.compilerOptions.paths;
  return esbuild2.build({
    entryPoints: [options.entry],
    platform: "node",
    treeShaking: true,
    minify: false,
    keepNames: true,
    minifyIdentifiers: false,
    minifySyntax: false,
    minifyWhitespace: false,
    format: "esm",
    outfile: options.out,
    bundle: true,
    banner: {
      js: "import { createRequire } from 'module'; const require = createRequire(import.meta.url);"
    },
    plugins: [
      nodeExternalsPlugin2({
        packagePath: [join4(options.projectRoot, "package.json")],
        allowList: Object.keys(paths)
      })
    ],
    assetNames: "[name]",
    loader: {
      ".swagger.json": "file"
    }
  });
}
__name(bundle, "bundle");

// libs/compiler/generator/utils/src/index.ts
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toVirtualFile(it) {
  const parts = it.path.split("/").filter(Boolean);
  const fileName = parts.at(-1);
  return {
    isFolder: false,
    name: it.path.split("/").pop() || "unknown",
    path: parts.join("/"),
    extension: getExt(fileName),
    content: it.content,
    metadata: {
      path: it.path
    }
  };
}
__name(toVirtualFile, "toVirtualFile");
function mapFilesToTree(files) {
  function toTree(parts, tree, content) {
    const [part, ...rest] = parts;
    if (rest.length === 0) {
      return {
        ...tree,
        [part]: content
      };
    }
    return {
      ...tree,
      [part]: toTree(rest, tree[part] || {}, content)
    };
  }
  __name(toTree, "toTree");
  return files.reduce((acc, it) => {
    const parts = it.path.split("/").filter(Boolean);
    return toTree(parts, acc, it.content);
  }, {});
}
__name(mapFilesToTree, "mapFilesToTree");
function mapFilesToTreeNodes(files) {
  const tree = mapFilesToTree(files);
  function toTreeNodes(tree2, path = []) {
    return Object.entries(tree2).map(([name, value]) => {
      const newPath = [...path, name];
      if (typeof value === "string") {
        return {
          id: newPath.join("/"),
          name,
          path: newPath.join("/"),
          metadata: {
            path: newPath.join("/")
          }
        };
      }
      return {
        id: newPath.join("/"),
        name,
        children: toTreeNodes(value, newPath),
        metadata: {
          path: newPath.join("/")
        }
      };
    }).sort((a, b) => "children" in a ? -1 : 1);
  }
  __name(toTreeNodes, "toTreeNodes");
  return toTreeNodes(tree);
}
__name(mapFilesToTreeNodes, "mapFilesToTreeNodes");
function getFile(list, path) {
  const file = list.find(
    (it) => JSON.stringify(it.path.split("/").filter(Boolean)) === JSON.stringify(path.split("/").filter(Boolean))
  );
  if (!file) {
    throw new Error(`File not found: ${path}`);
  }
  return file;
}
__name(getFile, "getFile");
function emptyFile(file = {}) {
  return {
    isFolder: false,
    name: "unknown",
    extension: "",
    content: "",
    path: "",
    ...file
  };
}
__name(emptyFile, "emptyFile");

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";
var BrowserLookupFs = class {
  static {
    __name(this, "BrowserLookupFs");
  }
  #lookupModules = /* @__PURE__ */ new Set();
  exists(path) {
    return localforage.getItem(path).then((item) => !!item).catch(() => false);
  }
  moduleExists(sourceData) {
    return this.exists(`package:${sourceData.package}`);
  }
  getFiles(sourceData) {
    return localforage.getItem(`files:${sourceData.package}`).then((files) => files || []).catch(() => []);
  }
  getFileContent(path) {
    return localforage.getItem(path).then((item) => item);
  }
  getPackageJson(sourceData) {
    return localforage.getItem(`package:${sourceData.package}`).then((item) => item);
  }
  mapFiles(files) {
    return files.map((file) => ({
      originalFile: file,
      relativeFile: file
    }));
  }
  lock(source) {
    this.#lookupModules.add(source);
  }
  isLocked(source) {
    return this.#lookupModules.has(source);
  }
};

// libs/playground/package-installer/src/lib/parser.ts
import { dirname as dirname3, join as join5 } from "path";
function coercePackageJson(packageJson) {
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.peerDependencies = packageJson.peerDependencies || {};
  return packageJson;
}
__name(coercePackageJson, "coercePackageJson");
function makeFileUri(specifier, fileName) {
  return `file:///node_modules/${specifier}/${fileName}`;
}
__name(makeFileUri, "makeFileUri");
function parseSpecifer(specifier) {
  const [moduleName, version] = specifier.split("@").filter(Boolean);
  return {
    moduleName,
    version: version === "*" ? "latest" : version
  };
}
__name(parseSpecifer, "parseSpecifer");
function normalizeImport(typesUrl, relativeImport) {
  const url = new URL(typesUrl);
  const relativeImportPathname = join5(dirname3(url.pathname), relativeImport);
  return new URL(relativeImportPathname, url.origin).href;
}
__name(normalizeImport, "normalizeImport");
function cleanText(text) {
  return text.replace("export {}", "").replaceAll("export function", "export declare function").replaceAll("export const", "export declare const");
}
__name(cleanText, "cleanText");
async function fetchDts(typesUrl) {
  const result = {
    error: false,
    loaded: false,
    text: ""
  };
  try {
    const response = await fetch(typesUrl);
    if (response.ok) {
      const text = await response.text();
      if (text.includes("[Package Error]")) {
        throw new Error("Package Error");
      }
      result.text = cleanText(text);
      result.loaded = true;
    } else {
      result.error = true;
    }
  } catch (error) {
    result.error = true;
    result.loaded = false;
  }
  return result;
}
__name(fetchDts, "fetchDts");
function parseSource(source) {
  let index2 = 0;
  const tokens = [];
  while (index2 < source.length) {
    switch (source[index2]) {
      case "@":
        {
          let subindex = index2 + 1;
          while (subindex < source.length && source[subindex] !== "/") {
            subindex++;
          }
          tokens.push({
            type: "at",
            value: source.slice(index2 + 1, subindex)
          });
          index2 = subindex;
        }
        break;
      default:
        {
          let lastToken = tokens[tokens.length - 1];
          if (!lastToken || lastToken.type !== "string") {
            lastToken = {
              type: "string",
              value: ""
            };
            tokens.push(lastToken);
          }
          lastToken.value += source[index2];
          index2++;
        }
        break;
    }
  }
  if (tokens[0].type === "at") {
    tokens[0].type = "scope";
    tokens[1].type = "package";
    if (tokens[2]) {
      tokens[2].type = "version";
    }
  }
  if (tokens[0].type === "string") {
    tokens[0].type = "package";
    if (tokens[1]) {
      tokens[1].type = "version";
    }
  }
  const moduleName = (tokens.find((x) => x.type === "package")?.value || "").replace("/", "");
  const version = tokens.find((x) => x.type === "version")?.value || "latest";
  const scope = tokens.find((x) => x.type === "scope")?.value;
  const file = tokens.find((x) => x.type === "string")?.value;
  return {
    moduleName,
    version,
    scope,
    package: `${scope ? `@${scope}/` : ""}${moduleName}`,
    full: `${scope ? `@${scope}/` : ""}${moduleName}@${version}`,
    file
  };
}
__name(parseSource, "parseSource");
function sourceDataToString(source) {
  return `${source.scope ? `${source.scope}/` : ""}${source.moduleName}@${source.version}`;
}
__name(sourceDataToString, "sourceDataToString");

// libs/playground/package-installer/src/lib/deps-install-manager.ts
import { basename as basename2, dirname as dirname4, extname as extname2, join as join6, relative as relative3 } from "path";
var PackageExports = class {
  constructor(pkg) {
    this.pkg = pkg;
  }
  static {
    __name(this, "PackageExports");
  }
  #extractTypes(exportConfig) {
    if (Array.isArray(exportConfig)) {
      return this.#extractTypes(
        exportConfig.filter((it) => typeof it === "string")[0]
      );
    }
    if (typeof exportConfig === "object") {
      if (typeof exportConfig?.types === "string") {
        return this.#extractTypes(exportConfig.types);
      }
      if (typeof exportConfig?.default === "string") {
        return this.#extractTypes(exportConfig?.default);
      }
    }
    if (typeof exportConfig === "string") {
      return fixTypeExportName(exportConfig);
    }
    return null;
  }
  #correctEndpoint(endpoint) {
    if (typeof endpoint === "string") {
      return fixTypeExportName(endpoint);
    }
    return this.#extractTypes(endpoint);
  }
  #tryFiles(index2) {
    if (!index2.endsWith("index.d.ts")) {
      return this.pkg.files?.find((it) => it.endsWith("index.d.ts")) || index2;
    }
    return index2;
  }
  formatExports() {
    const exports = this.mainExport();
    const deleteKeys = [
      (it) => it.includes("*"),
      (it) => it.includes("production"),
      (it) => it.includes("development"),
      (it) => it.includes("package.json"),
      (it) => it.includes("default"),
      (it) => it.includes("require"),
      (it) => it.includes("import"),
      (it) => it === ".",
      (it) => it === "./",
      (it) => it === "/"
    ];
    const cleanedExports = Object.fromEntries(
      Object.entries(this.pkg.exports).filter(
        ([endpoint]) => !deleteKeys.some((x) => x(endpoint))
      )
    );
    const formattedEndpoints = Object.fromEntries(
      Object.entries(cleanedExports).map(([endpoint, exports2]) => [
        endpoint,
        {
          types: this.#correctEndpoint(exports2) || // use the endpoint as the type as last resort
          fixTypeExportName(endpoint)
        }
      ])
    );
    return {
      ...exports,
      ...formattedEndpoints
    };
  }
  mainExport() {
    if (!this.pkg.exports) {
      return {
        ".": {
          types: this.#tryFiles(
            fixTypeExportName(
              this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
            )
          )
        }
      };
    }
    if (typeof this.pkg.exports === "string") {
      return {
        ".": {
          types: this.#tryFiles(fixTypeExportName(this.pkg.exports))
        }
      };
    }
    return {
      ".": {
        types: this.#correctEndpoint(this.pkg.exports["."]) || this.#tryFiles(
          fixTypeExportName(
            this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
          )
        )
      }
    };
  }
};
var nodeTypes = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
var Resolver = class {
  constructor(pkgKeeper, keeper, registries) {
    this.pkgKeeper = pkgKeeper;
    this.keeper = keeper;
    this.registries = registries;
  }
  static {
    __name(this, "Resolver");
  }
  async resolve(source) {
    if (nodeTypes.includes(source) || nodeTypes.some((it) => `node:${it}` === source) || nodeTypes.includes(`node:${source}`) || source.startsWith("@extensions")) {
      return null;
    }
    console.log("Resolving => ", source);
    const info = {
      deps: []
    };
    const resolutions$ = [];
    const pkg = await this.#packageJson(source).catch((error) => null);
    if (pkg === null) {
      console.log(`Resolution stopped: package.json not found for ${source}`);
      return null;
    }
    if (!pkg) {
      console.log(`Resolution stopped: missing package.json for ${source}`);
      return null;
    }
    const sourceData = parseSource(source);
    if (sourceData.version === "latest") {
      source = sourceDataToString({
        ...sourceData,
        version: pkg.version
      });
    }
    const recorder = createRecorder({ label: source });
    for (const [specifier, version] of [
      ...Object.entries(pkg.dependencies ?? {}),
      ...Object.entries(pkg.peerDependencies ?? {})
    ]) {
      const source2 = `${specifier}@${version}`;
      resolutions$.push(async () => {
        info.deps.push(await this.resolve(source2));
      });
    }
    const endpoints = [];
    for (const [secondaryEndpoint, exportedModule] of Object.entries(
      pkg.exports
    )) {
      resolutions$.push(async () => {
        const secondaryEndpointSource = join6(source, secondaryEndpoint);
        console.log("Resolving secondary", secondaryEndpointSource);
        await this.#fetch(
          secondaryEndpointSource,
          join6(source, exportedModule.types)
        ).then((r) => {
          if (secondaryEndpoint === "." && r.loaded) {
            info.resolved = true;
          }
        });
        endpoints.push({
          source: secondaryEndpointSource,
          typePath: exportedModule.types,
          typeSource: join6(source, exportedModule.types),
          name: secondaryEndpoint
        });
      });
    }
    info.source = source;
    info.endpoints = endpoints;
    await Promise.all(
      resolutions$.map(
        (it) => it()
        //   .catch((error) => {
        //   console.error(error);
        //   throw error;
        // }),
        //   .catch((error) => {
        //   console.log(`Failed to resolve ${source} due to`);
        //   console.error(error);
        // }),
      )
    );
    recorder.end();
    console.log("Resolved", source);
    return info;
  }
  async #resolveRelativeImports(fileContent, source) {
    const exports = await getFileExports(
      fileContent.replaceAll("export const", "declare const")
    );
    const types$ = exports.map(async (exportSepecifier) => {
      const maybeDeps = !exportSepecifier.startsWith(".");
      if (maybeDeps) {
        console.log("Resolving relative deps", exportSepecifier);
        const isDeps = await this.resolve(exportSepecifier).catch(() => null);
        if (isDeps?.resolved) {
          return null;
        }
      }
      console.log("Resolving relative file", exportSepecifier);
      const relativeExportSource = join6(source, exportSepecifier);
      const relativeExportTypeExport = fixTypeExportName(relativeExportSource);
      const entry = await this.#entry(relativeExportSource);
      entry.path = exportSepecifier;
      if (entry.loaded) {
        return null;
      }
      if (entry.error || entry.loading) {
        return null;
      }
      return this.#fetch(relativeExportSource, relativeExportTypeExport);
    });
    return Promise.all(types$);
  }
  async #fetch(source, typeExport) {
    const entry = await this.#entry(source);
    if (entry.loaded) {
      console.log(`Already loaded ${source}`);
      return entry;
    }
    if (entry.error) {
      console.log(`Already errored ${source}`);
      return entry;
    }
    if (entry.loading) {
      console.log(`Already loading ${source}`);
      return entry;
    }
    entry.loading = true;
    entry.loaded = false;
    const registries = this.registries.slice(0);
    while (!entry.loaded) {
      const registry = registries.shift();
      if (!registry) {
        break;
      }
      const result = await registry.resolve(typeExport);
      if (result.loaded) {
        entry.loaded = true;
        entry.text = result.text;
        await this.keeper.set(source, entry);
        break;
      }
    }
    entry.typeExport = typeExport;
    entry.loading = false;
    if (entry.loaded) {
      const entries = await this.#resolveRelativeImports(
        entry.text,
        dirname4(typeExport)
      );
      entry.related = entries.filter(notNullOrUndefined);
    }
    entry.error = entry.loaded === false;
    return entry;
  }
  async #packageJson(source) {
    let pkg = await this.pkgKeeper.get(source).catch((error) => {
      console.error(error);
      return null;
    });
    if (pkg === null) {
      console.log(`Using cached package ${source}`);
      return pkg;
    }
    if (!pkg) {
      const registries = this.registries.slice(0);
      while (!pkg) {
        const registry = registries.shift();
        if (!registry) {
          break;
        }
        pkg = await registry.packageJson(source).catch(() => null);
      }
      await this.pkgKeeper.set(source, pkg || null);
    }
    if (!pkg) {
      throw new Error(`Failed to resolve package ${source}`);
    }
    pkg.dependencies = pkg.dependencies || {};
    pkg.devDependencies = pkg.devDependencies || {};
    pkg.peerDependencies = pkg.peerDependencies || {};
    const packageExports = new PackageExports(pkg);
    pkg.exports = packageExports.formatExports();
    pkg.dependencies = Object.fromEntries(
      Object.entries(pkg.dependencies).map(([specifier, version]) => {
        if (pkg.devDependencies && pkg.devDependencies[`@types/${specifier}`]) {
          return [
            `@types/${specifier}`,
            pkg.devDependencies[`@types/${specifier}`]
          ];
        }
        return [specifier, version];
      })
    );
    return pkg;
  }
  async #entry(source) {
    const inCache = await this.keeper.get(source);
    if (inCache) {
      return inCache;
    }
    const entry = {
      loaded: false,
      source,
      text: "",
      loading: false,
      typeExport: "",
      related: [],
      path: ""
    };
    return entry;
  }
  async #flatEntry(entry, basePath, seed) {
    for (const endpointEntry of (await this.#entry(entry.source)).related) {
      if (!endpointEntry.loaded) {
        continue;
      }
      seed.push({
        path: join6(
          dirname4(
            join6(
              basePath,
              relative3(dirname4(entry.typeSource), endpointEntry.source)
            )
          ),
          basename2(endpointEntry.typeExport)
        ),
        content: endpointEntry.text,
        loaded: endpointEntry.loaded
      });
      for (const nestedEntry of endpointEntry.related) {
        seed.push({
          path: join6(
            dirname4(
              join6(
                basePath,
                relative3(dirname4(entry.typeSource), nestedEntry.source)
              )
            ),
            basename2(nestedEntry.typeExport)
          ),
          content: nestedEntry.text,
          loaded: nestedEntry.loaded
        });
        await this.#flatEntry(
          {
            source: nestedEntry.source,
            typeSource: nestedEntry.typeExport
          },
          join6(basePath, nestedEntry.path),
          seed
        );
      }
    }
  }
  async flatten(info, basePath, seed) {
    for (const endpoint of info.endpoints) {
      const secondaryPath = join6(basePath, endpoint.name);
      await this.#flatEntry(endpoint, secondaryPath, seed);
      const entry = await this.#entry(endpoint.source);
      seed.push({
        path: join6(secondaryPath, basename2(endpoint.typePath)),
        content: entry.text,
        loaded: entry.loaded
      });
    }
    for (const deps of info.deps) {
      if (!deps) {
        continue;
      }
      const depsSourceData = parseSource(deps.source);
      await this.flatten(
        deps,
        join6(basePath, "node_modules", depsSourceData.package),
        seed
      );
    }
  }
};
async function getFileExports(content) {
  const isNodejs = typeof process !== "undefined";
  const exports = isNodejs ? await Promise.resolve().then(() => (init_src(), src_exports)).then(
    ({ getExports: getExports2 }) => getExports2(content)
  ) : await runWorker("/morph/parser.worker.js", {
    type: "getExports",
    payload: content
  });
  return removeDuplicates(
    exports.filter(
      (it) => it.type === "ExportAllDeclaration" || it.type === "ExportNamedDeclaration" || it.type === "ImportDeclaration"
    ).map((it) => it.source?.value).filter(notNullOrUndefined),
    (it) => it
  );
}
__name(getFileExports, "getFileExports");
function fixTypeExportName(name) {
  if (extname2(name)) {
    name = name.replace(".d.ts", "").replace(".ts", "").replace(".js", "");
  }
  return `${name}.d.ts`;
}
__name(fixTypeExportName, "fixTypeExportName");

// libs/modern/src/lib/module-lookup.ts
var nodeTypes2 = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
async function lookupModule(source, fs, options) {
  const sourceData = parseSource(source);
  if (nodeTypes2.includes(sourceData.package) || nodeTypes2.some((it) => `node:${it}` === sourceData.package) || nodeTypes2.includes(`node:${sourceData.package}`) || source.startsWith("@extensions")) {
    console.log(`Source ${source} is a node type`);
    return;
  }
  if (fs.isLocked(source)) {
    return;
  }
  fs.lock(source);
  if (!await fs.moduleExists(sourceData)) {
    console.log(`Source ${source} not found`);
    const installed = await options.onMissingPackage(source, sourceData);
    if (!installed) {
      return;
    }
  }
  const packageJson = await fs.getPackageJson(sourceData);
  const files = await fs.getFiles(sourceData);
  await options.onFiles(sourceData, packageJson, files);
  await options.onPackageJson(sourceData, packageJson);
  await lookupPackage(packageJson, fs, options);
}
__name(lookupModule, "lookupModule");
async function lookupPackage(packageJson, fs, options) {
  coercePackageJson(packageJson);
  for (const depKey of ["dependencies", "peerDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      await lookupModule(depsName, fs, options);
    }
  }
  for (const depKey of ["devDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      if (depsName.startsWith("@types/")) {
        await lookupModule(depsName, fs, options);
      }
    }
  }
}
__name(lookupPackage, "lookupPackage");

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";
var octokit = /* @__PURE__ */ __name((token) => import("@octokit/core").then(({ Octokit }) => new Octokit({ auth: token })), "octokit");
async function generateKey() {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.crypto_secretbox_keygen();
}
__name(generateKey, "generateKey");
async function encrypt(key, plain) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const secret = sodium.crypto_secretbox_easy(
    plain,
    nonce,
    new Uint8Array(key)
  );
  return {
    secret,
    nonce
  };
}
__name(encrypt, "encrypt");
async function decrypt(secret, nonce, key) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.to_string(
    sodium.crypto_secretbox_open_easy(secret, nonce, key)
  );
}
__name(decrypt, "decrypt");
async function createEmptySecret(token, repositoryName, name) {
  const [owner, repo] = repositoryName.split("/");
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  try {
    await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
      owner,
      repo,
      secret_name: name
    });
    return;
  } catch (error) {
    const _error = error;
    if ("documentation_url" in _error) {
      if (_error.status !== 404) {
        throw error;
      }
    }
  }
  const key = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/public-key", {
    owner,
    repo
  });
  const binkey = sodium.from_base64(
    key.data.key,
    sodium.base64_variants.ORIGINAL
  );
  const binsec = sodium.from_string(" ");
  const encBytes = sodium.crypto_box_seal(binsec, binkey);
  const output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  await (await octokit(token)).request("PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
    owner,
    repo,
    secret_name: name,
    encrypted_value: output,
    key_id: key.data.key_id
  });
}
__name(createEmptySecret, "createEmptySecret");
async function createRepoistory(token, repositoryName, organizationId, workspaceId, projectId) {
  try {
    const result = await (await octokit(token)).request("POST /user/repos", {
      name: repositoryName,
      description: "January generated repository.",
      gitignore_template: "Node",
      private: true,
      auto_init: false,
      request: {
        projectId
      },
      homepage: "https://january.sh"
      // TODO: it should be user server or user local development server (january ones)
    });
    return {
      id: result.data.id,
      name: result.data.full_name
    };
  } catch (error) {
    if (error?.response?.data) {
      const _error = error.response;
      const [firstError] = _error.errors ?? [];
      if (firstError && firstError.code === "custom" && firstError.field === "name") {
        throw new Error(
          "Repository already exists on this account. Please change the project name and try again."
        );
      }
    }
    throw error;
  }
}
__name(createRepoistory, "createRepoistory");
async function triggerDeploy(token, repositoryName, inputs = {}) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request(
    "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
    {
      owner,
      repo,
      // TODO: we should get the installed hosting extension and get the workflow id from it
      workflow_id: "deploy.yml",
      ref: "main",
      inputs
    }
  );
}
__name(triggerDeploy, "triggerDeploy");
async function deleteRepository(token, repositoryName) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request("DELETE /repos/{owner}/{repo}", {
    owner,
    repo
  });
}
__name(deleteRepository, "deleteRepository");
async function listWorkflows(token, repositoryName, workflowFileName) {
  const [owner, repo] = repositoryName.split("/");
  const client = await octokit(token);
  const workflow2 = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  const run = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  return { workflow: workflow2, run };
}
__name(listWorkflows, "listWorkflows");
async function getWorkflowRun(token, repositoryName, workflowFileName, sha) {
  const [owner, repo] = repositoryName.split("/");
  const result = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs", {
    owner,
    repo,
    workflow_id: workflowFileName,
    head_sha: sha,
    branch: "main",
    exclude_pull_requests: true
  });
  const run = result.data.workflow_runs[0];
  if (!run) {
    return {
      run: {
        status: "queued",
        conclusion: null
      },
      jobs: []
    };
  }
  const runJobs = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs", {
    owner,
    repo,
    run_id: run.id
  });
  return {
    run,
    jobs: runJobs.data.jobs.map((it) => ({
      id: it.id,
      name: it.name,
      status: it.status,
      conclusion: it.conclusion,
      steps: (it.steps ?? []).map((step) => ({
        id: `${step.name}-${step.number}-${step.completed_at ?? 0}`,
        name: step.name,
        status: step.status,
        conclusion: step.conclusion,
        elapsed: step.completed_at && step.started_at ? differenceInSeconds(
          new Date(step.completed_at),
          new Date(step.started_at)
        ) : null
      }))
    }))
  };
}
__name(getWorkflowRun, "getWorkflowRun");

// libs/modern/src/index.ts
import { mkdir, writeFile } from "fs/promises";
import { dirname as dirname5, isAbsolute, join as join7 } from "path";
import { tap } from "rxjs/operators";
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag, enabled = true) {
  const header = /* @__PURE__ */ __name((value, error) => typeof tag === "string" ? tag : tag(value, error), "header");
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}
__name(debug, "debug");
async function writeFiles(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join7(dir, file);
    await mkdir(dirname5(filePath), { recursive: true });
    await writeFile(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}
__name(writeFiles, "writeFiles");

// libs/sdk/src/lib/execute.ts
import pluralize from "pluralize";
import { StructureKind as StructureKind4 } from "ts-morph";
import { v4 as v42 } from "uuid";
async function toChanges(projectDefinition) {
  const tablesIds = {};
  const workflowIds = {};
  const fieldsIds = {};
  const pathsIds = {};
  const policiesIds = {};
  projectDefinition.features.forEach((feature2) => {
    Object.keys(feature2.tables).forEach((tableName) => {
      tablesIds[tableName] = v42();
      const table2 = feature2.tables[tableName];
      Object.keys(table2.fields).forEach((fieldName) => {
        fieldsIds[fieldName] = v42();
      });
    });
    Object.keys(feature2.policies ?? {}).forEach((policyName) => {
      policiesIds[policyName] = v42();
    });
    feature2.workflows.forEach((workflow2) => {
      workflowIds[workflow2.name] = v42();
    });
  });
  function getTableDef(tableName) {
    let tableDef;
    for (const { tables: tables2 } of projectDefinition.features) {
      const table2 = Object.entries(tables2).find(([it]) => it === tableName) ?? [];
      tableDef = table2[1];
      if (tableDef) {
        break;
      }
    }
    return tableDef;
  }
  __name(getTableDef, "getTableDef");
  function mapQueries(details) {
    if (typeof details === "string" || typeof details === "number" || typeof details === "boolean") {
      return details;
    }
    if (isRequest(details)) {
      return mapQuery(details);
    }
    if (isNullOrUndefined(details)) {
      return details;
    }
    if (Array.isArray(details)) {
      return details.map(mapQueries);
    }
    return Object.entries(details).reduce((acc, [key, value]) => {
      return {
        ...acc,
        [key]: mapQueries(value)
      };
    }, {});
  }
  __name(mapQueries, "mapQueries");
  function mapQuery(value) {
    if (isRequest(value)) {
      let result = void 0;
      switch (value.command) {
        case "QueryTable":
          result = tablesIds[value.payload.name];
          break;
        case "QueryWorkflow":
          result = workflowIds[value.payload.name];
          break;
        case "QueryFieldName":
          for (const feature2 of projectDefinition.features) {
            for (const table2 of Object.values(feature2.tables)) {
              if (table2.fields[value.payload.name]) {
                const field2 = table2.fields[value.payload.name];
                if (field2.type === "relation") {
                  result = camelcase(value.payload.name + " id");
                }
              }
            }
          }
          result ??= value.payload.name;
          break;
        case "QueryField":
          for (const feature2 of projectDefinition.features) {
            for (const table2 of Object.values(feature2.tables)) {
              if (table2.fields[value.payload.name]) {
                const field2 = table2.fields[value.payload.name];
                if (field2.type === "relation") {
                  result = fieldsIds[camelcase(value.payload.name + " id")];
                }
              }
            }
          }
          result ??= fieldsIds[value.payload.name];
          break;
        case "QueryPath":
          result = pathsIds[value.payload.name];
          break;
        default:
          throw new Error(`Unknown command ${value.command}`);
      }
      if (isNullOrUndefined(result)) {
        throw new Error(
          `Could not find ${value.command} ${value.payload.name}`
        );
      }
      return result;
    }
    return value;
  }
  __name(mapQuery, "mapQuery");
  const policies = [];
  const features = [];
  const tables = [];
  const workflows = [];
  for (const feature2 of projectDefinition.features) {
    const featureId = v42();
    features.push({
      id: featureId,
      displayName: feature2.name
    });
    for (const [policyName, policy2] of Object.entries(feature2.policies ?? {})) {
      policies.push({
        id: policiesIds[policyName],
        rule: policy2,
        displayName: policyName
      });
    }
    for (const [tableName, table2] of Object.entries(feature2.tables)) {
      tables.push({
        id: tablesIds[tableName],
        featureId,
        displayName: tableName,
        fields: [],
        indexes: table2.constraints.map(
          (constraint) => mapQueries(constraint.details)
        )
      });
    }
    for (const [tableName, table2] of Object.entries(feature2.tables)) {
      for (const [fieldName, field2] of Object.entries(table2.fields)) {
        const source = await getSourceFieldByName(field2.type);
        const fieldValidation = [];
        for (const item of source.initialValidation) {
          const sourceValidation = await getValidationByName(item.name);
          const condition = item.if;
          if (condition) {
            const pass = applyCondition(condition, {
              context: field2.details,
              // inital validation is always run on the field it self
              self: field2.details
            });
            if (!pass) {
              continue;
            }
          }
          const details = Object.keys(item.details).reduce(
            (acc, key) => {
              const value = item.details[key];
              if (typeof value === "string" && value.startsWith("context.")) {
                const fieldMetadataProperty = value.replace("context.", "");
                return {
                  ...acc,
                  [key]: field2.details[fieldMetadataProperty]
                };
              }
              return {
                ...acc,
                [key]: value
              };
            },
            {}
          );
          fieldValidation.push({
            details,
            sourceId: sourceValidation.id,
            name: sourceValidation.name
          });
        }
        for (const validation2 of field2.validations.flat()) {
          const source2 = await getValidationByName(validation2.name);
          fieldValidation.push({
            details: validation2.details,
            name: source2.name,
            sourceId: source2.id
          });
        }
        if (field2.type === "relation") {
          const references = field2.details["references"];
          const relatedEntity = references.payload.name;
          const relatedEntityDef = getTableDef(relatedEntity);
          if (!relatedEntityDef) {
            throw new Error(
              `Referenced entity '${relatedEntity}' in relation field '${fieldName}' not found`
            );
          }
          const table3 = tables.find((it) => it.displayName === tableName);
          const relatedTable = tables.find(
            (it) => it.displayName === relatedEntity
          );
          if (!table3) {
            throw new Error(`Table ${tableName} not found`);
          }
          if (!relatedTable) {
            throw new Error(
              `Referenced entity '${relatedEntity}' in relation field '${fieldName}' not found`
            );
          }
          const [, referencedPrimaryField] = Object.entries(
            relatedEntityDef.fields
          ).find(
            ([fieldName2, field3]) => [
              "primary-key-uuid",
              "primary-key-number",
              "primary-key-custom"
            ].includes(field3.type)
          );
          const referencedPrimaryFieldSource = await getSourceFieldByName(
            referencedPrimaryField.type
          );
          const relationIdField = await getSourceFieldByName(
            referencedPrimaryFieldSource.references
          );
          const relationIdSourceField = await getSourceFieldByName("relation-id");
          const relationSourceField = await getSourceFieldByName("relation");
          switch (field2.details["relationship"]) {
            case "many-to-one":
              {
                {
                  table3.fields.push({
                    id: fieldsIds[fieldName],
                    displayName: fieldName,
                    tableId: tablesIds[tableName],
                    sourceId: source.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(source.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        nameOfColumnOnRelatedEntity: camelcase(
                          pluralize.plural(tableName)
                        ),
                        relatedEntityName: relatedEntity
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = camelcase(
                    `${pluralize.singular(fieldName)} Id`
                  );
                  fieldsIds[relationIdFieldName] ??= v42();
                  table3.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[tableName],
                    sourceId: relationIdField.id,
                    details: assignDefaults(relationIdField.metadata, {
                      length: null
                    }),
                    validations: uniquify(fieldValidation, (item) => item.name)
                  });
                }
                {
                  const relatedEntity2 = references.payload.name;
                  const fieldNameOnTheOtherTable = camelcase(
                    pluralize.plural(tableName)
                  );
                  fieldsIds[fieldNameOnTheOtherTable] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[fieldNameOnTheOtherTable],
                    displayName: fieldNameOnTheOtherTable,
                    tableId: tablesIds[relatedEntity2],
                    sourceId: relationSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationSourceField.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        ignoreIfExist: true,
                        joinSide: false,
                        nameOfColumnOnRelatedEntity: camelcase(fieldName),
                        relationship: "one-to-many",
                        references: tablesIds[tableName],
                        // FIXME: relation field have TableName stored in them
                        relatedEntityName: tableName
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = `${camelcase(
                    pluralize.plural(tableName)
                  )}Ids`;
                  fieldsIds[relationIdFieldName] ??= v42();
                  relatedTable.fields.push({
                    validations: uniquify(fieldValidation, (item) => item.name),
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[relatedEntity],
                    sourceId: relationIdSourceField.id,
                    details: assignDefaults(relationIdSourceField.metadata, {
                      ignoreIfExist: true,
                      virtualRelationField: true,
                      tableName: relatedEntity,
                      columnNameOnSelfTable: pluralize.plural(
                        camelcase(tableName)
                      ),
                      relationship: "one-to-many",
                      references: tablesIds[relatedEntity]
                    })
                  });
                }
              }
              break;
            case "one-to-one":
              {
                {
                  table3.fields.push({
                    id: fieldsIds[fieldName],
                    displayName: fieldName,
                    tableId: tablesIds[tableName],
                    validations: uniquify(fieldValidation, (item) => item.name),
                    sourceId: source.id,
                    details: assignDefaults(source.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        nameOfColumnOnRelatedEntity: camelcase(
                          pluralize.singular(tableName)
                        ),
                        relatedEntityName: relatedEntity
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = camelcase(
                    `${pluralize.singular(fieldName)} Id`
                  );
                  fieldsIds[relationIdFieldName] ??= v42();
                  table3.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[tableName],
                    sourceId: relationIdField.id,
                    details: assignDefaults(relationIdField.metadata, {
                      length: null
                    }),
                    validations: uniquify(fieldValidation, (item) => item.name)
                  });
                }
                {
                  const relatedEntity2 = references.payload.name;
                  const fieldNameOnTheOtherTable = camelcase(
                    pluralize.singular(tableName)
                  );
                  fieldsIds[fieldNameOnTheOtherTable] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[fieldNameOnTheOtherTable],
                    displayName: fieldNameOnTheOtherTable,
                    tableId: tablesIds[relatedEntity2],
                    sourceId: relationSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationSourceField.metadata, {
                      ...mapQueries(field2.details),
                      ...{
                        joinSide: false,
                        nameOfColumnOnRelatedEntity: camelcase(fieldName),
                        relationship: field2.details["relationship"],
                        relatedEntityName: tableName,
                        references: tablesIds[tableName]
                      }
                    })
                  });
                }
                {
                  const relationIdFieldName = `${camelcase(
                    pluralize.singular(tableName)
                  )}Id`;
                  fieldsIds[relationIdFieldName] ??= v42();
                  relatedTable.fields.push({
                    id: fieldsIds[relationIdFieldName],
                    displayName: relationIdFieldName,
                    tableId: tablesIds[relatedEntity],
                    sourceId: relationIdSourceField.id,
                    validations: uniquify(fieldValidation, (item) => item.name),
                    details: assignDefaults(relationIdSourceField.metadata, {
                      virtualRelationField: true,
                      tableName: relatedEntity,
                      columnNameOnSelfTable: pluralize.singular(
                        camelcase(tableName)
                      ),
                      relationship: "one-to-one",
                      references: tablesIds[relatedEntity]
                    })
                  });
                }
              }
              break;
            default:
              throw new Error(
                `Unimplemented relationship ${field2.details["relationship"]}`
              );
          }
        } else {
          const table3 = tables.find((it) => it.displayName === tableName);
          if (!table3) {
            throw new Error(`Table ${tableName} not found`);
          }
          table3.fields.push({
            id: fieldsIds[fieldName],
            displayName: fieldName,
            validations: uniquify(fieldValidation, (item) => item.name),
            tableId: tablesIds[tableName],
            sourceId: source.id,
            details: mapQueries(field2.details)
          });
        }
      }
    }
    for (const workflow2 of feature2.workflows) {
      const trigger2 = await getTriggerByName(workflow2.trigger.type);
      const { structures, ...triggerConfig } = workflow2.trigger.config;
      workflows.push({
        id: workflowIds[workflow2.name],
        featureId,
        displayName: workflow2.name,
        output: {},
        tag: workflow2.tag,
        code: workflow2.execute.code,
        structures: [
          ...workflow2.execute.structures,
          ...structures ?? []
        ],
        trigger: {
          sourceId: trigger2.id,
          details: mapQueries({
            ...triggerConfig,
            raw: workflow2.raw,
            inputs: Object.assign(
              {},
              workflow2.trigger.inputs ?? {},
              workflow2.execute.inputs
            ),
            policies: workflow2.trigger.policies,
            imports: projectDefinition.imports.map(
              (imp) => ({
                kind: StructureKind4.ImportDeclaration,
                isTypeOnly: imp.isTypeOnly,
                moduleSpecifier: imp.moduleSpecifier,
                namedImports: imp.namedImports,
                defaultImport: imp.defaultImport,
                namespaceImport: imp.namespaceImport
              })
            )
          })
        }
      });
    }
  }
  return {
    policies,
    features,
    imports: projectDefinition.imports.map((imp) => imp.moduleSpecifier),
    tables,
    workflows
  };
}
__name(toChanges, "toChanges");
function isRequest(request) {
  if (isNullOrUndefined(request)) {
    return false;
  }
  if (Array.isArray(request)) {
    return false;
  }
  if (typeof request !== "object") {
    return false;
  }
  return "command" in request;
}
__name(isRequest, "isRequest");

// libs/canary/src/index.ts
import { existsSync } from "fs";
import { cp, lstat, readFile, readdir } from "fs/promises";
import { basename as basename3, extname as extname3, join as join8 } from "path";
import { Injector as Injector7 } from "tiny-injector";
import * as morph2 from "ts-morph";
var coreExt = {
  files: {},
  packages: {
    "rfc-7807-problem-details": {
      version: "^1.1.0",
      dev: false
    },
    ajv: {
      version: "8.12.0",
      dev: false
    },
    "ajv-formats": {
      version: "2.1.1",
      dev: false
    },
    "ajv-errors": {
      version: "3.0.0",
      dev: false
    },
    "ajv-keywords": {
      version: "5.1.0",
      dev: false
    },
    validator: {
      version: "13.9.0",
      dev: false
    },
    "lodash-es": {
      version: "^4.17.21",
      dev: false
    },
    "@types/lodash-es": {
      version: "^4.17.12",
      dev: true
    },
    "http-status-codes": {
      version: "2.2.0",
      dev: false
    },
    "@types/node": {
      version: "^20.11.26",
      dev: true
    },
    typescript: {
      version: "^4.9.4",
      dev: true
    },
    "@types/validator": {
      version: "13.7.17",
      dev: true
    },
    prettier: {
      version: "^3.3.3",
      dev: true
    },
    zod: {
      version: "^3.23.8",
      dev: false
    },
    "@january/console": {
      version: "https://github.com/JanuaryLabs/dist/raw/main/console.tar.gz"
    }
  }
};
async function getUserFiles(workspace) {
  const extDir = join8(workspace, "src", "extensions");
  const thirdPartyExtsDir = join8(workspace, "output", "src", "extensions");
  const packageJson = await getFile2(join8(workspace, "package.json")) || '{"dependencies":{}}';
  return {
    userExts: await Promise.all(
      (await readFolder(extDir)).map(async (dir) => {
        const indexFile = (await readFolder(join8(extDir, dir))).find(
          (it) => it.startsWith("index.")
        );
        return {
          dir,
          index: indexFile
        };
      })
    ),
    thirdPartyExts: await readFolder(thirdPartyExtsDir),
    "package.json": JSON.parse(packageJson),
    startup: join8(workspace, "src", "startup.ts"),
    public: join8(workspace, "public")
  };
}
__name(getUserFiles, "getUserFiles");
function getFile2(path) {
  if (!existsSync(path)) return null;
  return readFile(path, "utf-8");
}
__name(getFile2, "getFile");
function readFolder(path) {
  return existsSync(path) ? readdir(path) : [];
}
__name(readFolder, "readFolder");
async function defineConfig(config2) {
  const devDependencies = {};
  const dependencies = {};
  const scripts = {
    dev: "node --watch ./",
    start: "node ./"
    // 'migration:generate':
    //   './node_modules/.bin/typeorm migration:generate ./src/migrations/migrations --dataSource ./src/datasource -o --pretty --outputJs',
  };
  for (const { packages, scripts: packageScripts } of [
    coreExt,
    ...config2.extensions
  ]) {
    Object.assign(scripts, packageScripts ?? {});
    Object.entries(packages).forEach(([name, config3]) => {
      if (config3.dev) {
        devDependencies[name] = config3.version;
      } else {
        dependencies[name] = config3.version;
      }
    });
  }
  const cwd = process.cwd();
  const outputDir = join8(cwd, "output");
  const settings = {
    cwd,
    runtime: "node",
    outputDir
  };
  await generate(settings, config2.extensions);
  await writeFiles(
    join8(process.cwd(), "output"),
    Object.assign({}, ...config2.extensions.map((it) => it.files))
  );
  const userFiles = await getUserFiles(cwd);
  const copyList = [
    [userFiles.public, join8(outputDir, "build", "public")],
    [userFiles.startup, join8(outputDir, "src")]
  ];
  for (const [src, dest] of copyList) {
    const stat = await lstat(src).catch(() => null);
    if (!stat) {
      continue;
    }
    if (stat.isFile()) {
      const fileName = basename3(src);
      const filePath = dest.endsWith(fileName) ? dest : join8(dest, fileName);
      await cp(src, filePath, { force: true });
    } else {
      await cp(src, dest, { force: true });
    }
  }
  for (const { dir, index: index2 } of userFiles.userExts) {
    if (!index2) {
      console.warn(`Missing index.ts file for extension ${dir}`);
    }
  }
  await writeFiles(join8(process.cwd(), "output"), {
    // TODO: run on eject only
    // await fetch(
    //   'https://raw.githubusercontent.com/github/gitignore/main/Node.gitignore',
    // ).then((res) => res.text()),
    // '.gitignore': '',
    "package.json": toJson({
      version: "0.0.0",
      main: "./build/server.js",
      type: "module",
      private: true,
      scripts,
      dependencies: {
        ...dependencies,
        ...Object.fromEntries(
          Object.entries(userFiles["package.json"].dependencies).filter(
            ([name, version]) => !name.startsWith("@january/")
          )
        )
      },
      devDependencies
    }),
    "tsconfig.json": toJson({
      compilerOptions: {
        jsx: "preserve",
        sourceMap: true,
        target: "ESNext",
        module: "esnext",
        moduleResolution: "node",
        declaration: false,
        outDir: "dist",
        baseUrl: ".",
        rootDir: ".",
        types: ["node"],
        removeComments: true,
        strict: true,
        inlineSources: true,
        sourceRoot: "/",
        allowSyntheticDefaultImports: true,
        esModuleInterop: true,
        experimentalDecorators: true,
        emitDecoratorMetadata: true,
        importHelpers: true,
        noEmitHelpers: true,
        resolveJsonModule: true,
        skipLibCheck: true,
        skipDefaultLibCheck: true,
        lib: ["ESNext"],
        noEmit: true,
        allowImportingTsExtensions: true,
        paths: {
          ...userFiles.thirdPartyExts.reduce(
            (acc, it) => ({
              ...acc,
              [`@extensions/${it}`]: [
                `${join8("src", "extensions", it)}/index.ts`
              ]
            }),
            {}
          ),
          ...userFiles.userExts.filter((it) => it.index).reduce(
            (acc, it) => ({
              ...acc,
              [`@extensions/${it.dir}`]: [
                `${join8("../", "src", "extensions", it.dir, it.index)}`
              ]
            }),
            {}
          ),
          "@workspace/entities": ["src/features/entities.ts"],
          "@workspace/identity": ["src/extensions/identity/index.ts"],
          "@workspace/validation": ["src/core/validation.ts"]
        }
      },
      exclude: ["node_modules", "migrations", "environment", "dist", "build"]
    })
  });
  await bundle({
    projectRoot: outputDir,
    entry: join8(outputDir, "src", "server.ts"),
    out: join8(outputDir, "build", "server.js")
  });
}
__name(defineConfig, "defineConfig");
async function getChanges(config2) {
  const projectFs = Injector7.GetRequiredService(ProjectFS);
  const projectCode = await getFile2(join8(config2.cwd, "src", "project.ts"));
  const featurePaths = await readFolder(join8(config2.cwd, "src", "features"));
  const features = await Promise.all(
    featurePaths.map(async (feature2) => {
      return evaluate(
        await readFile(join8(config2.cwd, "src", "features", feature2), "utf-8")
      ).then((it) => {
        it.feature.name = basename3(feature2).replace(extname3(feature2), "");
        return it;
      });
    })
  );
  if (projectCode) {
    console.log("project.ts is deprecated and will be removed in the v1");
  }
  const { definition, reports } = await defensiveEvaluate(
    projectCode || "export default project();"
  );
  if (reports.length) {
    throw new Error(
      `
` + reports.map((report) => {
        return Array.isArray(report.message) ? report.message[0] : typeof report.message === "string" ? report.message : Object.values(report.message)[0];
      }).join("\n")
    );
  }
  const pd = {
    features: [...definition.features, ...features.map((it) => it.feature)],
    imports: [
      ...definition.imports ?? [],
      ...features.map((it) => it.imports)
    ].flat(1)
  };
  const extDir = join8(config2.cwd, "src", "extensions");
  if (existsSync(extDir)) {
    await cp(extDir, join8(config2.outputDir, "src", "extensions"), {
      recursive: true
    });
  }
  const changes = await toChanges(pd);
  return {
    imports: changes.imports,
    policies: changes.policies.map((it) => [
      {
        filePath: projectFs.makeIdentityPath(
          `${spinalcase2(it.displayName)}.policy.ts`
        ),
        structure: [it.rule]
      }
    ]),
    features: await Promise.all(
      changes.features.reduce(
        (acc, curr) => [
          ...acc,
          {
            id: curr.id,
            displayName: curr.displayName,
            workflows: changes.workflows.filter(
              (workflow2) => workflow2.featureId === curr.id
            ),
            tables: changes.tables.filter(
              (table2) => table2.featureId === curr.id
            )
          }
        ],
        []
      ).map(async (feature2) => {
        const tags = /* @__PURE__ */ new Set();
        const featureContract = {
          displayName: feature2.displayName,
          tags: [],
          tables: feature2.tables.map((it) => ({
            id: it.id,
            featureName: feature2.displayName,
            displayName: it.displayName,
            fields: it.fields,
            indexes: it.indexes
          })),
          workflows: await Promise.all(
            feature2.workflows.map(async (workflow2) => {
              const schemaName = camelcase(`${workflow2.displayName} schema`);
              const inputName = pascalcase(`${workflow2.displayName} input`);
              const inputs = workflow2.trigger.details["inputs"];
              const workflowContract = {
                inputName,
                inputs,
                displayName: workflow2.displayName,
                schemaName,
                featureName: feature2.displayName,
                tag: workflow2.tag,
                raw: workflow2.trigger.details["raw"],
                triggerInput: workflow2.trigger.details["triggerInput"],
                output: {
                  properties: [],
                  returnCode: ""
                },
                code: workflow2.code,
                structures: workflow2.structures,
                trigger: {
                  sourceId: workflow2.trigger.sourceId,
                  policies: workflow2.trigger["details"]["policies"],
                  tag: workflow2.tag,
                  // NOTE: it only has effect for http triggers. we might need it for github action to support multiple webhooks
                  details: workflow2.trigger.details,
                  inputName,
                  inputs,
                  displayName: workflow2.displayName,
                  featureName: feature2.displayName,
                  schemaName,
                  operationName: snakecase2(workflow2.displayName)
                }
              };
              tags.add(workflow2.tag);
              return workflowContract;
            })
          )
        };
        featureContract.tags = Array.from(tags);
        return featureContract;
      })
    )
  };
}
__name(getChanges, "getChanges");
async function generate(settings, extensions = []) {
  const concreteStructure = await getChanges(settings);
  return Injector7.CreateScope(async (context) => {
    const projectConfig = Injector7.GetRequiredService(ProjectConfig, context);
    const pConfig = projectConfig.getConfig();
    projectConfig.updateConfig({
      basePath: join8(settings.outputDir, pConfig.basePath),
      features: join8(settings.outputDir, pConfig.features)
    });
    const collector = {};
    for (const feature2 of concreteStructure.features) {
      Object.assign(
        collector,
        ...feature2.workflows.map((it) => processWorkflow(it))
      );
      for (const ext of extensions) {
        if (ext.onFeature) {
          Object.assign(
            collector,
            ext.onFeature(feature2, {
              fs: Injector7.GetRequiredService(ProjectFS)
            })
          );
        }
      }
    }
    const { save, cleanup, files } = emitFiles(collector, settings.outputDir);
    await save(async (file) => {
      file.replaceWithText(
        await formatCode(file.getFullText(), getExt(file.getFilePath())).catch(
          () => {
            console.error(`Failed to format ${file.getFilePath()}`);
            return file.getFullText();
          }
        )
      );
    });
    await cleanup();
    if (!settings.outputDir) {
      return files;
    }
    return files;
  });
}
__name(generate, "generate");
function processWorkflow(contract) {
  const commandName = camelcase(contract.displayName);
  const workflowInputs = contract.inputs;
  const zod = Object.entries(contract.inputs).filter(([key, prop]) => !prop.data?.["standalone"]).reduce(
    (acc, [key, prop]) => ({
      ...acc,
      [key]: prop.data?.["zod"] || `z.any()`
    }),
    {}
  );
  const destructuredInputs = nonStaticInputs(contract.inputs).map(
    ([name]) => name
  );
  const workflowParams = standaloneInputs(workflowInputs).map(
    ([name, prop]) => ({
      name,
      type: prop.type
    })
  );
  const workflowInputsStructures = Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean);
  if (destructuredInputs.length) {
    workflowParams.unshift({
      name: `input`,
      type: `z.infer<typeof ${contract.schemaName}>,`
    });
  }
  workflowParams.push(
    ...(contract.trigger.details.params ?? []).map((it) => ({
      name: it.name,
      type: it.type
    }))
  );
  const dto = Object.keys(zod).length ? [
    {
      kind: morph2.StructureKind.ImportDeclaration,
      moduleSpecifier: "zod",
      defaultImport: "z"
    },
    `
export const ${contract.schemaName} = z.object(${toLiteralObject(zod)})`
  ] : [];
  const workflowStructure = [
    ...contract.trigger.details["imports"] ?? [],
    ...workflowInputsStructures.flat(),
    ...dto,
    ...contract.structures,
    {
      kind: morph2.StructureKind.Function,
      name: commandName,
      isAsync: true,
      isDefaultExport: false,
      isExported: true,
      parameters: workflowParams,
      statements: [contract.code]
    }
  ];
  return {
    // FIXME: file trigger doesn't need a command so we need not to add one
    [makeCommandPath(contract.featureName, contract.tag, contract.displayName)]: workflowStructure
  };
}
__name(processWorkflow, "processWorkflow");
async function processTreeActions(tree) {
  const actions = tree.children;
  const parameters = {};
  const topLevel = [];
  const actionsResults = {};
  for (const action of actions) {
    const result = await processTreeActions(action);
    result.parameters.forEach((it) => parameters[it.name] = it);
    actionsResults[action.id] = result;
    if (!result.structures[0].inline) {
      topLevel.push(...result.topLevel, result.structures[0].structure);
    } else {
      topLevel.push(...result.topLevel);
    }
  }
  const mainAction = await proccesSingleAction(
    camelcase(tree.name),
    tree,
    Object.values(parameters)
  );
  topLevel.push(...mainAction.topLevel);
  const actionStructure = [];
  const signutureParameters = nonStatic(
    tree.inputs
  ).map(([name, prop]) => {
    const isMandatory = (prop.validations ?? []).some(
      (it) => it.type === "mandatory"
    );
    return {
      kind: morph2.StructureKind.Parameter,
      name,
      type: makeSchema(prop).type ?? prop.type ?? "any",
      hasQuestionToken: !isMandatory
    };
  });
  if (mainAction.inline) {
    actionStructure.push({
      inline: true,
      structure: mainAction.unwrapped
    });
  } else {
    actionStructure.push({
      inline: false,
      structure: [
        {
          kind: morph2.StructureKind.Function,
          name: camelcase(tree.name),
          isAsync: true,
          isDefaultExport: false,
          isExported: false,
          parameters: uniquify(
            [...signutureParameters, ...Object.values(parameters)],
            (item) => item.name
          ),
          statements: mainAction.unwrapped
        }
      ]
    });
  }
  return {
    callExprStr: mainAction.callExprStr,
    structures: actionStructure,
    parameters: mainAction.parameters,
    topLevel,
    unwrapped: mainAction.unwrapped
  };
}
__name(processTreeActions, "processTreeActions");
async function proccesSingleAction(name, action, childrenParameters) {
  const topLevel = [];
  const body = [];
  const parameters = nonStaticInputs(
    action.inputs
  ).map(([name2, prop]) => {
    const isMandatory = (prop.validations ?? []).some(
      (it) => it.type === "mandatory"
    );
    return {
      kind: morph2.StructureKind.Parameter,
      name: name2,
      type: makeSchema(prop).type ?? prop.type ?? "any",
      hasQuestionToken: !isMandatory
    };
  });
  const outputName = action.output.displayName;
  const withMaybeVar = outputName ? `const ${outputName} = ` : `const ${camelcase(`${name}Output`)} = `;
  const callExprParameters = uniquify(
    [
      ...nonStatic(action.inputs).map(paramName),
      ...childrenParameters.map((it) => it.name)
    ],
    (item) => item
  );
  return {
    inline: true,
    parameters,
    callExprStr: `${withMaybeVar} await ${name}(${callExprParameters.join(
      ", "
    )})`,
    topLevel,
    unwrapped: body.flat()
  };
}
__name(proccesSingleAction, "proccesSingleAction");
export {
  defineConfig,
  generate
};
//# sourceMappingURL=index.js.map
