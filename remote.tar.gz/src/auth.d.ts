import { Command } from 'commander';
export declare function login(): Promise<void>;
declare const _default: Command;
export default _default;
