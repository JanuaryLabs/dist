import type { Readable } from 'stream';
export * from './lib/instance';
export * from './lib/manager';
export * from './lib/proxy/docker';
export * from './lib/proxy/docker.runner';
export declare function remote(config: {
    distDir: string;
}): Promise<void>;
export declare function remotePack(tar: Readable): Promise<void>;
