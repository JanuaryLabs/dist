export declare const baseUrl: string;
export declare namespace request {
    function get<R>(path: string, config?: {
        withAuth?: boolean;
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<readonly [undefined, unknown] | readonly [R, null]>;
    function put<R>(path: string, data: Record<string, unknown>, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<readonly [undefined, unknown] | readonly [R, null]>;
    function patch<T extends Record<string, unknown>>(path: string, data: T, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<any[]>;
    function post<R>(path: string, data: Record<string, unknown>, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<readonly [undefined, unknown] | readonly [R, null]>;
    function request<T extends Record<string, unknown>>(path: string, method: 'GET' | 'PATCH' | 'POST' | 'PUT' | 'DELETE', data?: T, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<readonly [Response] | readonly [null, unknown]>;
    function remove<T extends Record<string, unknown>>(path: string, data: T, config?: Omit<RequestInit, 'method' | 'body' | 'headers'> & {
        headers?: Record<string, string | undefined>;
        baseUrl?: string;
    }): Promise<any[]>;
}
