export interface ReleaseInfo {
    channel: string;
    release: string;
    projectId: string;
    projectName: string;
    domainPrefix: string;
    image: string;
}
interface Rec {
    id: string;
    createdAt: string;
}
interface Project extends Rec {
    name: string;
}
interface Release extends Rec {
    project: Project;
    status: string;
    conclusion: string;
}
interface Token extends Rec {
    project: Project;
}
export declare function fetchReleases(options?: {
    projectId?: string;
}): Promise<readonly [undefined, unknown] | readonly [{
    records: Release[];
}, null]>;
export declare function fetchProjects(options?: {
    name?: string;
}): Promise<readonly [undefined, unknown] | readonly [{
    records: Project[];
}, null]>;
export declare function fetchTokens(): Promise<readonly [undefined, unknown] | readonly [Token[], null]>;
export declare function validateToken(token: string): Promise<readonly [undefined, unknown] | readonly [Token, null]>;
export declare function setSecret(data: any): Promise<readonly [undefined, unknown] | readonly [Record<string, string>, null]>;
export declare function getProjectEnv(projectId: string): Promise<Record<string, string>>;
export declare function makeRelease(releaseInfo: ReleaseInfo, token: string | undefined): Promise<{
    create: () => Promise<void>;
    waiting: () => Promise<any[]>;
    fail: () => Promise<any[]>;
    success: () => Promise<any[]>;
    snapshot: (name: string) => Promise<readonly [undefined, unknown] | readonly [unknown, null]>;
}>;
export {};
