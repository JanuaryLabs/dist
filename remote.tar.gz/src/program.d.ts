import debug from 'debug';
export declare const defaultHealthCheck: Record<string, any>;
export declare const cli: import("commander").Command;
export declare function dfn(): any;
export declare function appName(): any;
export declare const ast: {
    healthCheckOptions: Record<string, any> | undefined;
    paths: string[];
    expose: string;
};
export declare const logger: debug.Debugger;
export declare const spinner: import("ora").Ora;
export declare function printDivider(character?: string): void;
export declare function tell(message: string): void;
