export declare const logs$: import("rxjs").Observable<string>;
export declare function connectToRunnerServer(): void;
