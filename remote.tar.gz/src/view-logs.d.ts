import { Observable } from 'rxjs';
import type { ReleaseInfo } from './lib/api-client';
import { type AST } from './program';
export declare function followLogs(release: ReleaseInfo, next?: boolean): void;
export declare function toBase64(data: any): string;
export declare function sse(ast: AST, tarLocation: string, config: ReleaseInfo, token: string): Observable<string>;
