#!/usr/bin/env node
import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// libs/remote/src/cli.ts
import { watch } from "chokidar";
import { Command, program } from "commander";
import { DockerfileParser } from "dockerfile-ast";
import { parse } from "dotenv";
import glob from "fast-glob";
import { readFile } from "fs/promises";
import { join } from "path";
import { Subject, debounceTime, exhaustMap, filter, switchMap } from "rxjs";
import { WebSocket } from "ws";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";

// libs/remote/src/lib/proxy/docker.runner.ts
import tar from "tar";
import tarStream2 from "tar-stream";

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/lib/proxy/docker.runner.ts
function createTar(baseTag, files) {
  const dockerfile = getRunnerDockerfile(baseTag);
  const pack = tarStream2.pack();
  for (const { path, content } of files) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
function getRunnerDockerfile(imageName) {
  return `
FROM ${imageName} as deps

WORKDIR /app

# FROM node:lts as base
# WORKDIR /app
COPY ./package.json /app/package.json
COPY . /app/build/
# COPY --from=deps /app/node_modules /app/node_modules

# it'll make install dynamic dependencies faster
# COPY --from=deps /app/package-lock.json /app/package-lock.json

# RUN npm ci --omit=dev --no-audit --no-fund --prefer-offline

# CMD tail -f /dev/null

CMD [ "npm", "start" ]
`;
}

// libs/remote/src/cli.ts
var watcher = new Subject();
var setCommand = new Command("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in the format NAME=VALUE").action(async (secretsList, s) => {
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: apiKey()
      }
    });
  }
});
var setFileCommand = new Command("set-file").usage("[options] ./remove.env").argument("<envFile>", "Path to the file with secrets").action(async (file) => {
  const secrets = Object.entries(
    parse(await readFile(join(process.cwd(), file), "utf-8"))
  );
  for (const [name, value] of secrets) {
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: apiKey()
      }
    });
  }
});
var connectCommand = new Command("connect").argument("[dockerfilePath]", "Path to the Dockerfile", "Dockerfile").action(async (dockerfileName) => {
  {
    const ws = new WebSocket(`${serverizeWs}?apiKey=${apiKey()}`);
    ws.on("open", () => {
      console.log("Connected to source server");
      ws.send(
        JSON.stringify({
          command: "logs",
          payload: {
            apiKey: apiKey()
          }
        })
      );
    });
    ws.on("message", (data) => {
      process.stdout.write(data.toString());
    });
    ws.on("close", () => {
      console.log("Disconnected from source server");
    });
  }
  const options = program.opts();
  const filesToWatch = await getFiles(dockerfileName);
  watch(filesToWatch, { cwd: process.cwd(), persistent: true }).on(
    "all",
    async (event, path) => {
      watcher.next(path);
    }
  );
  watcher.pipe(
    debounceTime(1e3),
    switchMap(() => {
      return Promise.all(
        filesToWatch.map(async (file) => ({
          path: file,
          content: await readFile(join(process.cwd(), file), "utf-8")
        }))
      );
    }),
    exhaustMap(async (files) => {
      const tar2 = createTar("node:lts", files);
      return fetch(`${serverizeUrl}/upload`, {
        method: "POST",
        duplex: "half",
        body: tar2,
        headers: {
          "Content-Type": "application/x-tar",
          Apikey: options["apiKey"]
        }
      });
    }),
    filter((response) => response.ok),
    switchMap(
      (response) => response.body.pipeThrough(new TextDecoderStream())
    )
  ).subscribe();
});
var secretCommand = new Command("secrets").addCommand(setCommand).addCommand(setFileCommand);
var cli = program.name("Serverize").version("1.0.0").description("Serverize").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command").requiredOption("-k, --api-key <key>", "API key for authentication");
cli.usage("npx @january/remote connect ./Dockerfile").addCommand(connectCommand).addCommand(secretCommand).parse(process.argv);
async function getFiles(dockerfileName) {
  const dockerfile = await readFile(
    join(process.cwd(), dockerfileName),
    "utf-8"
  );
  const ast = DockerfileParser.parse(dockerfile);
  const copies = ast.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    const path = srcArg.getValue();
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const files = await glob(Array.from(paths), {
    cwd: process.cwd()
  });
  return [dockerfileName, ...files];
}
function apiKey() {
  const options = program.opts();
  return options["apiKey"];
}
//# sourceMappingURL=cli.js.map
