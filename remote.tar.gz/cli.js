#!/usr/bin/env node

// libs/remote/src/cli.ts
import { watch } from "chokidar";
import { DockerfileParser } from "dockerfile-ast";
import glob from "fast-glob";
import { readFile } from "fs/promises";
import { join } from "path";
import { Subject, debounceTime, exhaustMap } from "rxjs";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/issue-tracker.ts
import axios from "axios";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { isNotEmpty, isString } from "class-validator";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag) {
  const header = (value, error) => typeof tag === "string" ? tag : tag(value, error);
  return tap({
    next(value) {
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}

// libs/remote/src/lib/proxy/docker.runner.ts
import tar from "tar";
import tarStream2 from "tar-stream";

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
import { readFileSync } from "fs";
var options = process.env["DOCKER_HOST"] ? {
  sshOptions: {
    privateKey: readFileSync("/Users/ezzabuzaid/.ssh/id_ed25519")
  }
} : void 0;
var docker = new Docker(options);

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/lib/proxy/docker.runner.ts
function createTar(baseTag, files2) {
  const dockerfile = getRunnerDockerfile(baseTag);
  const pack = tarStream2.pack();
  for (const { path, content } of files2) {
    pack.entry({ name: path }, content);
  }
  pack.finalize();
  return pack;
}
function getRunnerDockerfile(imageName) {
  return `
FROM ${imageName} as deps

WORKDIR /app

# FROM node:lts as base
# WORKDIR /app
COPY ./package.json /app/package.json
COPY . /app/build/
# COPY --from=deps /app/node_modules /app/node_modules

# it'll make install dynamic dependencies faster
# COPY --from=deps /app/package-lock.json /app/package-lock.json

# RUN npm ci --omit=dev --no-audit --no-fund --prefer-offline

# CMD tail -f /dev/null

CMD [ "npm", "run", "start:prod" ]
`;
}

// libs/remote/src/cli.ts
var [, , dockerfileName = "Dockerfile"] = process.argv;
var watcher = new Subject();
var files = await getFiles(dockerfileName);
watch(
  files.map((it) => it.path),
  { cwd: process.cwd(), persistent: true }
).on("all", async (event, path) => {
  watcher.next(path);
});
watcher.pipe(
  debug("files"),
  debounceTime(500),
  exhaustMap(() => dispatch(files))
).subscribe();
async function dispatch(files2) {
  const tar2 = createTar("node:lts", files2);
  return fetch("http://localhost:3100/upload", {
    method: "POST",
    duplex: "half",
    body: tar2,
    headers: { "Content-Type": "application/x-tar" }
  });
}
async function getFiles(dockerfileName2) {
  const dockerfile = await readFile(
    join(process.cwd(), dockerfileName2),
    "utf-8"
  );
  const ast = DockerfileParser.parse(dockerfile);
  const copies = ast.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    const path = srcArg.getValue();
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const files2 = await glob(Array.from(paths), {
    cwd: process.cwd()
  });
  return [
    {
      path: dockerfileName2,
      content: dockerfile
    },
    ...await Promise.all(
      files2.map(async (file) => ({
        path: file,
        content: await readFile(join(process.cwd(), file), "utf-8")
      }))
    )
  ];
}
//# sourceMappingURL=cli.js.map
