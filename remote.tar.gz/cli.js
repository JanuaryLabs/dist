#!/usr/bin/env node
import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// libs/remote/src/cli.ts
import { marked } from "marked";
import { markedTerminal } from "marked-terminal";

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 0.85,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
box.print = function(title, ...lines) {
  console.log(box(title, ...lines.map((it) => it.trimEnd())));
};

// libs/remote/src/auth.ts
import { confirm, input as input2, password } from "@inquirer/prompts";
import { Command } from "commander";
import { signOut } from "firebase/auth";
import open from "open";
import validator2 from "validator";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";

// libs/remote/src/lib/auth.ts
import { FirebaseError } from "firebase/app";
import {
  AuthErrorCodes,
  EmailAuthProvider,
  GithubAuthProvider,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  getRedirectResult,
  linkWithCredential,
  linkWithPopup,
  onAuthStateChanged,
  signInAnonymously,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect
} from "firebase/auth";

// libs/remote/src/lib/firebase.ts
import { initializeApp } from "firebase/app";
import { initializeAuth } from "firebase/auth";
import { readFile, rm, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { join as join2 } from "path";
var file = join2(tmpdir(), "serverize");
var FilePersistence = class {
  static type = "NONE";
  type = "NONE";
  async _isAvailable() {
    return true;
  }
  decode(key) {
    return key;
  }
  async _set(key, value) {
    return writeFile(join2(tmpdir(), this.decode(key)), JSON.stringify(value));
  }
  async _get(base64) {
    return await readFile(join2(tmpdir(), this.decode(base64)), "utf-8").then((data) => {
      return safeFail(() => JSON.parse(data), null);
    }).catch((error) => {
      return null;
    });
  }
  async _remove(base64) {
    await rm(join2(tmpdir(), this.decode(base64)), { force: true });
  }
  _addListener(_key, _listener) {
    return;
  }
  _removeListener(_key, _listener) {
    return;
  }
};
var app = initializeApp({
  apiKey: "AIzaSyA6OFi52evEph_dFBFxHd-71BIGpJiCTOA",
  authDomain: "january-9f554.firebaseapp.com",
  projectId: "january-9f554",
  storageBucket: "january-9f554.appspot.com",
  messagingSenderId: "299506012875",
  appId: "1:299506012875:web:ac6e9ff54cd104fdfcc14e"
});
var auth = initializeAuth(app, {
  persistence: [FilePersistence]
});

// libs/remote/src/lib/auth.ts
async function signInWithGoogle() {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  const provider = new GoogleAuthProvider();
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithPopup(auth.currentUser, provider);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token, accessToken: credential?.accessToken };
  } catch (error) {
    if (error instanceof FirebaseError) {
      if (error.code === AuthErrorCodes.EMAIL_EXISTS) {
        throw new Error(
          "Looks like you already have an account. Please sign in."
        );
      }
    }
  }
  return { user: null };
}
async function signUpWithEmail(email, password2) {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(
      auth.currentUser,
      EmailAuthProvider.credential(email, password2)
    );
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password2);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  } catch (error) {
    if (error instanceof FirebaseError) {
      switch (error.code) {
        case AuthErrorCodes.INVALID_EMAIL:
          throw new Error("Invalid email address");
        case AuthErrorCodes.WEAK_PASSWORD:
          throw new Error("Password is too weak");
        case AuthErrorCodes.EMAIL_EXISTS:
          throw new Error(
            box(
              "User already exists",
              "Looks like you already have an account. Please sign in.",
              `$ npx serverize auth signin`
            )
          );
        case AuthErrorCodes.CREDENTIAL_ALREADY_IN_USE:
          throw new Error(
            "Looks like you already have an account. Please sign in."
          );
        default:
          throw error;
      }
    }
    throw error;
  }
}
async function signInWithEmail(email, password2) {
  if (auth.currentUser && !auth.currentUser.isAnonymous) {
    return {
      user: auth.currentUser,
      token: await auth.currentUser.getIdToken(true)
    };
  }
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(
      auth.currentUser,
      EmailAuthProvider.credential(email, password2)
    );
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  }
  try {
    const result = await signInWithEmailAndPassword(auth, email, password2);
    const user = result.user;
    const token = await user.getIdToken(true);
    return { user, token };
  } catch (error) {
    if (error instanceof FirebaseError) {
      switch (error.code) {
        case AuthErrorCodes.INVALID_IDP_RESPONSE:
        case AuthErrorCodes.INVALID_LOGIN_CREDENTIALS:
          throw new Error("Wrong email or password, please try again.");
        default:
          throw error;
      }
    }
  }
  return { user: null };
}
function initialise() {
  return new Promise((resolve, reject) => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (user) => {
        unsubscribe();
        resolve(user);
      },
      reject
    );
  });
}
Error.stackTraceLimit = Infinity;

// libs/remote/src/lib/http.ts
import { v4 as v42 } from "uuid";
var baseUrl2 = process.env.NODE_ENV === "development" ? "http://localhost:3000" : "https://serverize.fly.dev";
var request;
((_request) => {
  async function makeHeaders(withAuth = true) {
    const headers = [
      ["Content-Type", "application/json"],
      ["x-request-id", v42()]
    ];
    if (withAuth) {
      const token = await auth.currentUser?.getIdToken();
      if (token) {
        headers.push(["Authorization", `Bearer ${token}`]);
      }
    }
    return headers;
  }
  async function get2(path, config = { withAuth: true }) {
    const [response, error] = await request2(path, "GET", void 0, config);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.get = get2;
  async function put(path, data, config) {
    const [response, error] = await request2(path, "PUT", data, config);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.put = put;
  async function patch(path, data, config) {
    const [response, error] = await request2(path, "PATCH", data, config);
    if (error || !response) {
      return [null, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.patch = patch;
  async function post(path, data, config) {
    const [response, error] = await request2(path, "POST", data, config);
    if (error || !response) {
      return [void 0, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.post = post;
  async function request2(path, method, data, config) {
    const extraHeaders = config?.headers ? Object.entries(config.headers).filter(
      ([_, value]) => notNullOrUndefined(value)
    ) : [];
    try {
      const response = await fetch(
        `${config?.baseUrl || baseUrl2}${addLeadingSlash(path)}`,
        {
          method,
          body: data ? JSON.stringify(data) : void 0,
          headers: [...await makeHeaders(), ...extraHeaders]
        }
      );
      if (response.ok) {
        return [response];
      }
      const error = await handleError(response);
      return [null, error];
    } catch (error) {
      return [null, error];
    }
  }
  _request.request = request2;
  async function remove(path, data, config = { withAuth: true }) {
    const [response, error] = await request2(path, "DELETE", data, config);
    if (error || !response) {
      return [null, error];
    }
    const result = await response.json();
    return [result, null];
  }
  _request.remove = remove;
})(request || (request = {}));
async function handleError(response) {
  try {
    if (response.status >= 400 && response.status < 500) {
      const body = await response.json();
      return new Error(body.detail);
    }
    return new Error(
      `An error occurred while fetching the data. Status: ${response.status}`
    );
  } catch (error) {
    return error;
  }
}

// libs/remote/src/program.ts
import ignore from "@balena/dockerignore";
import { input, select } from "@inquirer/prompts";
import chalk from "chalk";
import cliSpinners from "cli-spinners";
import { Option, program } from "commander";
import debug from "debug";
import { DockerfileParser } from "dockerfile-ast";
import glob2 from "fast-glob";
import { existsSync } from "fs";
import { readFile as readFile2 } from "fs/promises";
import ms from "ms";
import ora from "ora";
import { platform } from "os";
import { join as join3 } from "path";
import validator from "validator";

// libs/remote/src/lib/api-client.ts
function fetchReleases(options = {}) {
  const params = new URLSearchParams();
  Object.entries(options).forEach(([key, value]) => {
    if (value !== void 0) {
      params.append(key, value);
    }
  });
  return request.get(`/releases?${params}`);
}
function fetchProjects(options = {}) {
  const params = new URLSearchParams();
  Object.entries(options).forEach(([key, value]) => {
    if (value !== void 0) {
      params.append(key, value);
    }
  });
  return request.get(`/projects?${params}`);
}
function fetchTokens() {
  return request.get("/tokens");
}
function validateToken(token) {
  return request.get(`/tokens/${token}`);
}
function setSecret(data) {
  return request.post(`/secrets`, data);
}
async function stopRelease(id) {
  const token = await auth.currentUser?.getIdToken();
  const config = {
    headers: { Authorization: `Bearer ${token}` },
    withAuth: false
  };
  return request.remove(`/releases/${id}`, {}, config);
}

// libs/remote/src/program.ts
var defaultHealthCheck = {
  Test: "CMD wget --no-verbose --tries=1 --spider / || exit 1",
  Retries: 3,
  StartPeriod: ns(ms("2s")),
  Timeout: ns(ms("3s")),
  Interval: ns(ms("30s"))
};
var cli = program.name("Serverize").version("1.0.0").description("Serverize");
async function toAst(projectDockerFilePath) {
  const dockerignorefilePath = join3(process.cwd(), ".dockerignore");
  const dockerfilePath = join3(process.cwd(), projectDockerFilePath);
  if (!existsSync(dockerignorefilePath)) {
    throw new Error(`No .dockerignore found at ${dockerignorefilePath}`);
  }
  if (!existsSync(dockerfilePath)) {
    throw new Error(`No Dockerfile found at ${dockerfilePath}`);
  }
  logger("Reading .dockerignore at %s", dockerignorefilePath);
  const dockerignore = await readFile2(dockerignorefilePath, "utf-8");
  logger("Reading Dockerfile at %s", dockerfilePath);
  const dockerfile = await readFile2(dockerfilePath, "utf-8");
  const ast = DockerfileParser.parse(dockerfile);
  const exposeInstructions = ast.getInstructions().find((instruction) => instruction.getInstruction() === "EXPOSE");
  const copies = ast.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    let path = srcArg.getValue();
    if (path === ".") {
      path = "./";
    }
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const filteredPaths = ignore({ ignorecase: true }).add(dockerignore).filter(
    await glob2(Array.from(paths), {
      cwd: process.cwd()
    })
  );
  const [healthCheck] = ast.getHEALTHCHECKs();
  const healthCheckOptions = {};
  if (healthCheck) {
    const flags = healthCheck.getFlags();
    const keys = [
      {
        prop: "StartPeriod",
        flag: "start-period",
        format: (value) => ns(ms(value))
      },
      {
        prop: "Retries",
        flag: "retries",
        format: (value) => parseInt(value, 10)
      },
      {
        prop: "Timeout",
        flag: "timeout",
        format: (value) => ns(ms(value))
      },
      {
        prop: "Interval",
        flag: "interval",
        format: (value) => ns(ms(value))
      }
    ];
    for (const { prop, flag, format } of keys) {
      const value = flags.find((it) => it.getName() === flag);
      if (value) {
        healthCheckOptions[prop] = format ? format(value.getValue()) : value.getValue();
      } else {
        healthCheckOptions[prop] = defaultHealthCheck[prop];
      }
    }
    healthCheckOptions["Test"] = healthCheck.getRawArgumentsContent();
  }
  const exposedPort = exposeInstructions ? exposeInstructions.getArguments().map((it) => it.getValue())[0] : "";
  return {
    healthCheckOptions: Object.keys(healthCheckOptions).length ? healthCheckOptions : void 0,
    paths: filteredPaths,
    expose: exposedPort,
    dockerfile: dockerfilePath
  };
}
function ns(ms2) {
  return ms2 * 1e6;
}
var logger = debug("serverize");
console.log("\n");
var SPINNER_TYPE = platform() === "win32" ? cliSpinners.material : cliSpinners.pipe;
var spinner = ora({
  spinner: SPINNER_TYPE,
  prefixText: "\u2500 Serverize"
});
function printDivider(character = "\u2500") {
  const columns = process.stdout.columns || 80;
  const line = character.repeat(columns);
  console.log(line);
}
function tell(message, newLine = false) {
  spinner.text = `${message}${newLine ? "\n" : ""}`;
  spinner.render();
}
var askForProjectName = () => input({
  message: "Project name",
  validate: (v) => {
    const isValid = validator.isAlpha(v, "en-US", { ignore: "-" });
    if (!isValid) {
      return "Project name can only contain letters and hyphens";
    }
    return true;
  }
});
var channelOption = new Option(
  "-c, --channel <channel>",
  "Channel to deploy to"
).default("dev");
var releaseOption = new Option(
  "-r, --release <release>",
  "Release name"
).default("latest");
var projectOption = new Option(
  "-p, --project <projectName>",
  "The project name"
).makeOptionMandatory(true);
if (process.env.SERVERIZE_PROJECT) {
  projectOption.default(process.env.SERVERIZE_PROJECT);
}
if (process.env.SERVERIZE_PROJECT || process.env.SERVERIZE_API_TOKEN) {
  projectOption.makeOptionMandatory(false);
}
async function ensureUser() {
  const user = await initialise();
  const say = () => {
    tell("You need to sign in first", true);
    box.print(
      "Authentication",
      "Login $ npx serverize auth signin",
      "Signup $ npx serverize auth signup"
    );
  };
  if (!user) {
    say();
    return null;
  }
  const { claims } = await user.getIdTokenResult(true);
  if (!claims.aknowledged) {
    await user.delete().catch(() => {
    });
    say();
    return null;
  }
  if (!user.emailVerified) {
    tell("Email not verified: Please verify your email.", true);
  }
  return { user, claims };
}
async function dropdown(config) {
  return select({
    message: config.title,
    default: config.default,
    loop: true,
    choices: config.choices
  });
}
async function getCurrentProject(project) {
  const apiToken = process.env.SERVERIZE_API_TOKEN?.trim();
  const useProject = async () => {
    const user = await ensureUser();
    if (!user) return;
    const [data, error] = await fetchProjects({ name: project });
    if (error || !data) {
      spinner.fail(`Failed to get project ${project}`);
      return;
    }
    if (data.records.length === 0) {
      spinner.fail(`Project ${chalk.green(project)} not found`);
      return;
    }
    return {
      projectId: data.records[0].id,
      projectName: data.records[0].name,
      token: await user.user.getIdToken()
    };
  };
  if (project && apiToken) {
    return await useProject();
  } else if (project) {
    return await useProject();
  } else if (apiToken) {
    const [data, error] = await validateToken(apiToken);
    if (error || !data) {
      spinner.fail("Invalid token");
      process.exit(1);
      return;
    }
    return {
      projectId: data.project.id,
      projectName: data.project.name,
      token: apiToken
    };
  }
  await ensureUser();
  return;
}

// libs/remote/src/auth.ts
var CLIENT_ID = process.env.NODE_ENV === "development" ? "Ov23liFrVjYBjqttXVYt" : "Ov23liTdbDl03bHIuT4N";
var REDIRECT_URI = `${serverizeUrl}/callback`;
async function github() {
  const timestamp = Date.now();
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    cache_bust: timestamp.toString(),
    redirect_uri: encodeURI(`${REDIRECT_URI}/github`)
  });
  const authUrl = `https://github.com/login/oauth/authorize?${params}`;
  await open(authUrl);
}
async function selectProvider() {
  return "password";
}
async function credsForm(validatePassword = true) {
  const email = await input2({
    message: "Email",
    validate: validator2.isEmail
  });
  const pw = await password({
    message: "Password",
    validate: (value) => {
      if (!validatePassword) {
        return validator2.isStrongPassword(value, {
          minLength: 8,
          minLowercase: 0,
          minNumbers: 0,
          minUppercase: 0,
          minSymbols: 0
        });
      }
      const strongEnough = validator2.isStrongPassword(value, {
        minLength: 8,
        minLowercase: 1,
        minNumbers: 1,
        minUppercase: 1,
        minSymbols: 1
      });
      if (!strongEnough) {
        return "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one symbol.";
      }
      return true;
    }
  });
  return { email, pw };
}
async function askUser() {
  const user = await initialise();
  if (user) {
    const yes = await confirm({
      message: "You are already signed in. Do you want to sign out first?",
      default: false
    });
    if (yes) {
      await signOut(auth);
      return true;
    }
    return false;
  }
  return true;
}
var signin = new Command("signin").alias("login").action(async () => {
  const wants = await askUser();
  if (!wants) {
    return;
  }
  const value = await selectProvider();
  switch (value) {
    case "github":
      await github();
      break;
    case "google":
      await signInWithGoogle();
      break;
    case "password":
      {
        try {
          const { email, pw } = await credsForm(false);
          tell("Signing in...");
          await signInWithEmail(email, pw);
          tell("Signed in");
        } catch (error) {
          spinner.fail(error.message);
        }
      }
      break;
  }
});
var signup = new Command("signup").alias("register").action(async () => {
  const wants = await askUser();
  if (!wants) {
    return;
  }
  const value = await selectProvider();
  switch (value) {
    case "github":
      await github();
      break;
    case "google":
      await signInWithGoogle();
      break;
    case "password":
      {
        const { email, pw } = await credsForm();
        try {
          tell("Creating account...", true);
          const { user } = await signUpWithEmail(email, pw);
          tell("Few more things please...", true);
          const orgName = await input2({
            message: "Organization name",
            validate: (v) => {
              const isValid = validator2.isAlpha(v, "en-US", { ignore: "-" });
              if (!isValid) {
                return "Organization name can only contain letters and hyphens";
              }
              return true;
            }
          });
          const projectName = await askForProjectName();
          tell("Continuing...");
          const [res, orgError] = await request.post("/organizations/default", {
            uid: user.uid,
            name: orgName,
            projectName
          });
          if (orgError) {
            spinner.fail(orgError.message);
            await user.delete();
            return;
          }
          await user.reload();
          spinner.succeed(`You're ready to deploy ${projectName}`);
          console.log(
            box(
              `Deploy ${projectName}`,
              `To deploy: npx serverize deploy -p ${projectName}`,
              `To set secrets: npx serverize secrets set-file .env -p ${projectName}`
            )
          );
        } catch (error) {
          await auth.currentUser?.delete().catch(() => {
          });
          spinner.fail(error.message);
          process.exit(1);
        }
      }
      break;
  }
});
var signout = new Command("signout").alias("logout").action(async () => {
  const user = await initialise();
  if (!user) {
    tell("Not authenticated");
    return;
  }
  const yes = await confirm({
    message: "Are you sure you want to sign out?",
    default: false
  });
  if (yes) {
    await signOut(auth);
    tell("Signed out");
  }
});
var whoami = new Command("whoami").action(async () => {
  const user = await initialise();
  if (user) {
    console.log(
      `Signed in as ${user.displayName || user.email || user.phoneNumber}`
    );
  } else {
    console.log("Not authenticated");
  }
});
var auth_default = new Command("auth").description("Authenticate with serverize (signin, signup, signout)").addCommand(signin).addCommand(signup).addCommand(signout).addCommand(whoami);

// libs/remote/src/deploy.ts
import { AsyncLocalStorage } from "async_hooks";
import { spawn } from "child_process";
import { watch } from "chokidar";
import { Command as Command2 } from "commander";
import { writeFileSync } from "fs";
import {
  Observable as Observable3,
  debounceTime,
  exhaustMap,
  finalize,
  from as from2,
  mergeMap as mergeMap2,
  switchMap as switchMap2,
  tap as tap3
} from "rxjs";
import { Upload } from "tus-js-client";

// libs/docker/src/index.ts
import { parse } from "dotenv";
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}

// libs/docker/src/compose.ts
import yaml from "js-yaml";

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/lib/instance.ts
import {
  Observable,
  Subject,
  defer,
  from,
  map,
  merge,
  mergeMap,
  switchMap,
  tap as tap2
} from "rxjs";
import tarStream2 from "tar-stream";

// libs/remote/src/lib/manager.ts
Error.stackTraceLimit = Infinity;
(async () => {
  await upsertNetwork("traefik-network");
})();
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}

// libs/remote/src/view-logs.ts
import debug2 from "debug";
import EventSource from "eventsource";
import { Observable as Observable2 } from "rxjs";
import { WebSocket } from "ws";
var logger2 = debug2("serverize");
function followLogs2(release, next) {
  const ws = new WebSocket(`${serverizeWs}?apiKey=${release.domainPrefix}`);
  ws.on("open", () => {
    logger2("Connected to runner server");
    ws.send(
      JSON.stringify({
        command: "logs",
        payload: {
          next: next ?? true
        }
      })
    );
  });
  ws.on("message", (data) => {
    logger2("Received message from runner server");
    console.log(data.toString());
  });
  ws.on("close", () => {
    logger2("Disconnected from source server");
    process.exit(0);
  });
}
function toBase64(data) {
  return Buffer.from(JSON.stringify(data)).toString("base64");
}
function sse(ast, tarLocation, config, token) {
  return new Observable2((subscriber) => {
    const eventSource = new EventSource(`${serverizeUrl}/progress`, {
      headers: {
        Authorization: token,
        "x-release": toBase64(config),
        "x-docker": toBase64({
          port: parseInt(ast.expose || "3000", 10),
          Healthcheck: ast.healthCheckOptions || defaultHealthCheck
        }),
        "x-docker-tar": tarLocation
      }
    });
    eventSource.onmessage = (event) => {
      const payload = safeFail(() => JSON.parse(event.data), { message: "" });
      if (payload.type === "error") {
        subscriber.error(payload.message);
      } else if (payload.type === "complete") {
        subscriber.next(payload.message);
        subscriber.complete();
        eventSource.close();
      } else if (payload.type === "logs") {
        process.stdout.write(payload.message);
      } else {
        subscriber.next(payload.message);
      }
    };
    eventSource.onerror = (error) => {
      console.log(error);
      subscriber.error(error.data);
    };
    return () => {
      eventSource.close();
    };
  });
}

// libs/remote/src/deploy.ts
var als = new AsyncLocalStorage();
var PROTOCOL = process.env.USE_PROTOCOL || "tus";
var deployPreviewCommand = new Command2("preview").option(
  "-pr, --preview [NAME]",
  "Preview deployment name"
);
var deploy_default = new Command2("deploy").usage("npx serverize deploy -p <projectName>").option("-w, --watch", "Watch for changes", false).option(
  "-f, --file [dockerfilepath]",
  'Name of the Dockerfile (default:"$(pwd)/Dockerfile")',
  "Dockerfile"
).option("-o, --output [file]", "Write output to a file").addOption(channelOption).addOption(releaseOption).addOption(projectOption).action(
  async ({
    watch: watch2,
    project: projectName,
    file: file2,
    channel,
    release,
    output: outputFile
  }) => {
    spinner.start();
    const currentProject = await getCurrentProject(projectName);
    if (!currentProject) {
      return;
    }
    spinner.info(`Deploying (${currentProject.projectName})...`);
    const ast = await toAst(file2);
    const domainPrefix = [
      currentProject.projectName,
      channel,
      release === "latest" ? "" : release
      // createHash('sha1').digest('hex'),
    ].filter(Boolean).join("-");
    const releaseInfo = {
      channel,
      release,
      projectId: currentProject.projectId,
      projectName: currentProject.projectName,
      image: makeRunningImageName(domainPrefix),
      domainPrefix
    };
    als.run({ ast, project: currentProject.projectName, releaseInfo }, () => {
      if (watch2) {
        logger("using watch mode");
        followLogs2(releaseInfo);
        watchFiles().pipe(
          exhaustMap((x) => sendImage()),
          tap3({
            next: tell,
            error: (error) => {
              spinner.fail("Failed to push the image");
              console.error(error);
            }
          }),
          switchMap2(
            (tarLocation) => sse(ast, tarLocation, releaseInfo, currentProject.token).pipe(
              finalize(() => {
                spinner.info("Deployed. Waiting for changes...");
                spinner.info(
                  `Accessible at https://${releaseInfo.domainPrefix}.beta.january.sh`
                );
              })
            )
          )
        ).subscribe({
          next: tell,
          error: (error) => {
            const message = safeFail(
              () => (typeof error === "string" ? error : error.message).trim(),
              ""
            );
            if (message) {
              spinner.fail(`Failed to process image: ${message}`);
            } else {
              spinner.fail(`Failed to process image`);
              console.error(error);
            }
          }
        });
      } else {
        from2(sendImage()).pipe(
          tap3({
            next: tell,
            error: (error) => {
              spinner.fail("Failed to push the image");
              console.error(error);
              process.exit(1);
            }
          }),
          mergeMap2(
            (tarLocation) => sse(ast, tarLocation, releaseInfo, currentProject.token)
          )
        ).subscribe({
          next: tell,
          error: (error) => {
            const message = safeFail(
              () => (typeof error === "string" ? error : error.message).trim(),
              ""
            );
            if (message) {
              spinner.fail(`Failed to process image: ${message}`);
            } else {
              spinner.fail(`Failed to process image`);
              console.error(error);
            }
            process.exit(1);
          },
          complete: () => {
            const url = `https://${releaseInfo.domainPrefix}.beta.january.sh`;
            spinner.succeed("Deployed successfully");
            box.print(
              `${currentProject.projectName} Deployed`,
              `Accessible at ${url}`,
              `Logs: npx serverize logs -a ${currentProject.projectName}`,
              `Stuck? Join us at https://discord.gg/aj9bRtrmNt`
            );
            if (outputFile) {
              writeFileSync(
                outputFile,
                JSON.stringify({
                  project: currentProject.projectName,
                  url
                }),
                "utf-8"
              );
            }
          }
        });
      }
    });
  }
);
function createWatcher(files) {
  return new Observable3((subscriber) => {
    const watcher = watch(files, {
      cwd: process.cwd(),
      persistent: true
    });
    watcher.on("all", async (event, path) => {
      subscriber.next(path);
    });
    watcher.on("error", (error) => {
      subscriber.error(error);
    });
    return () => {
      watcher.close();
    };
  });
}
function getAst() {
  const value = als.getStore();
  if (!value) {
    throw new Error(
      `Couldn't parse the Dockerfile. This is most likely a bug. Please report it.`
    );
  }
  return value.ast;
}
function getReleaseInfo() {
  const value = als.getStore();
  if (!value) {
    throw new Error(
      `Couldn't get project name. This is most likely a bug. Please report it.`
    );
  }
  return value.releaseInfo;
}
function watchFiles() {
  const ast = getAst();
  logger(`Watching files 
${ast.paths.join(", ")}
`);
  return createWatcher(ast.paths).pipe(debounceTime(1e3));
}
async function sendImage(quiet = false) {
  const ast = getAst();
  if (!ast.expose) {
    spinner.warn("No exposed port found, use 3000 as default");
  }
  if (!ast.healthCheckOptions) {
    spinner.warn(`No health check options found, using default health check`);
  }
  switch (PROTOCOL) {
    case "tus":
      return useTus(quiet);
    default:
      return useHttp(quiet);
  }
}
async function useHttp(quiet = false) {
  const tar = await saveImage(quiet);
  tell("Pushing the image...");
  const response = await fetch(`${serverizeUrl}/upload`, {
    method: "POST",
    duplex: "half",
    body: tar,
    headers: {
      "x-release": toBase64(getReleaseInfo()),
      "Content-Type": "application/x-tar",
      Authorization: process.env.SERVERIZE_API_TOKEN || await auth.currentUser?.getIdToken()
    }
  });
  if (!response.ok) {
    const error = await response.text();
    throw {
      status: response.statusText,
      message: error
    };
  }
  return response.text();
}
async function useTus(quiet = false) {
  const tar = await saveImage(quiet);
  const releaseInfo = getReleaseInfo();
  tell("Pushing the image...");
  const bytes = (mb) => mb * 1024 * 1024;
  const chunkSize = bytes(50);
  return new Promise((resolve, reject) => {
    const upload = new Upload(tar, {
      endpoint: `${serverizeUrl}/uploads`,
      // 50MB chunk size
      chunkSize,
      uploadLengthDeferred: true,
      metadata: {
        filename: releaseInfo.image,
        filetype: "application/x-tar"
      },
      onError: reject,
      onSuccess() {
        resolve(upload.url.replace(this.endpoint, ""));
      }
    });
    upload.start();
  });
}
async function saveImage(quiet = false) {
  const releaseInfo = getReleaseInfo();
  await buildImage(quiet);
  printDivider();
  console.log("\n");
  return docker.getImage(releaseInfo.image).get();
}
function buildImage(quiet = false) {
  const ast = getAst();
  const releaseInfo = getReleaseInfo();
  return new Promise((resolve, reject) => {
    const platforms = ["linux/amd64"];
    const options = [
      "--pull",
      "--rm",
      "-t",
      releaseInfo.image,
      "-f",
      ast.dockerfile,
      "--platform",
      platforms.join(","),
      "."
    ];
    if (quiet) {
      options.push("--quiet");
    }
    console.log("\n");
    printDivider();
    const ls = spawn("docker", ["build", ...options], {
      cwd: process.cwd(),
      stdio: "inherit",
      env: {
        ...process.env,
        DOCKER_CLI_HINTS: "false",
        DOCKER_BUILDKIT: "1"
      }
    });
    ls.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject();
      }
    });
  });
}

// libs/remote/src/logs.ts
import { Command as Command3 } from "commander";
var logs_default = new Command3("logs").usage("npx serverize logs -p <projectName>").addOption(projectOption).action(({ project }) => {
  followLogs2(project, false);
});

// libs/remote/src/project.ts
import { Command as Command4 } from "commander";
var create = new Command4("create").argument("[name]", "Name of the project").action(async (name) => {
  const user = await ensureUser();
  if (!user) return;
  name ??= await askForProjectName();
  const [res, error] = await request.post(`/projects`, {
    name,
    workspaceId: user.claims.workspaceId
  });
  if (error) {
    spinner.fail(error.message);
    process.exit(1);
  }
  spinner.succeed(`Project ${name} created`);
});
var list = new Command4("list").action(async (name) => {
  const user = await ensureUser();
  if (!user) return;
  const [projects = { records: [] }, error] = await fetchProjects();
  if (error) {
    spinner.fail(error.message);
    process.exit(1);
  }
  if (projects.records.length === 0) {
    box.print(
      "No projects found",
      "Create a project by running:",
      "$ npx serverize projects create <project-name>"
    );
    return;
  }
  console.table(projects.records, ["id", "name"]);
});
var project_default = new Command4("projects").description("Manage your projects").addCommand(create).addCommand(list);

// libs/remote/src/releases.ts
import { Command as Command5 } from "commander";
var list2 = new Command5("list").addOption(projectOption.makeOptionMandatory(false)).action(async ({ project }) => {
  const currentProject = await getCurrentProject(project);
  if (!currentProject) return;
  const [releases = { records: [] }] = await fetchReleases({
    projectId: currentProject.projectId
  });
  if (!releases) return;
  if (releases.records.length === 0) {
    box.print(
      "No releases found",
      "Create a release by running:",
      "$ npx serverize deploy -p <project-name>"
    );
    return;
  }
  console.table(
    releases.records.map((release) => ({
      // ID: token.id,
      Project: release.project.name,
      "Created At": release.createdAt,
      Status: release.status,
      Conclusion: release.conclusion,
      Name: release.name,
      Channel: release.channel
    }))
  );
});
var stop = new Command5("stop").addOption(channelOption.makeOptionMandatory(true)).addOption(releaseOption).addOption(projectOption).action(async ({ project: projectName, channel, release }) => {
  const currentProject = await getCurrentProject(projectName);
  if (!currentProject) return;
  const [releases = { records: [] }, error] = await fetchReleases({
    channel,
    projectId: currentProject.projectId,
    name: release,
    status: "completed",
    conclusion: "success"
  });
  if (error) {
    spinner.fail(error.message);
    return;
  }
  const releaseData = releases.records[0];
  await request.remove(
    "/terminate",
    {},
    {
      baseUrl: serverizeUrl,
      withAuth: false,
      headers: {
        Authorization: `Bearer ${currentProject.token}`,
        "x-release": toBase64({
          id: releaseData.id,
          containerName: releaseData.containerName
        })
      }
    }
  );
  if (error) {
    spinner.fail(error.message);
    return;
  }
  const [, stoppingReleaseError] = await stopRelease(releaseData.id);
  if (stoppingReleaseError) {
    spinner.fail(stoppingReleaseError.message);
    return;
  }
  spinner.succeed(
    `Release ${releaseData.name} of ${channel} stopped successfully`
  );
});
var releases_default = new Command5("releases").addCommand(list2).addCommand(stop);

// libs/remote/src/secrets.ts
import { Command as Command6 } from "commander";
import { parse as parse2 } from "dotenv";
import { readFile as readFile3 } from "fs/promises";
import { join as join4 } from "path";
var setCommand = new Command6("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in format NAME=VALUE").addOption(projectOption).action(async (secretsList, { project }) => {
  const currentProject = await getCurrentProject(project);
  if (!currentProject) {
    return;
  }
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error(`Secret "${secret}" must be in the format NAME=VALUE`);
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await setSecret({
      projectId: currentProject.projectId,
      secretLabel: name,
      secretValue: value
    });
  }
  spinner.succeed("Secrets set successfully");
});
var setFileCommand = new Command6("set-file").usage("[options] .env").argument("<envFile>", "Path to the file with secrets").addOption(projectOption).action(async (file2, { project }) => {
  const currentProject = await getCurrentProject(project);
  if (!currentProject) {
    return;
  }
  const secrets = Object.entries(
    parse2(await readFile3(join4(process.cwd(), file2), "utf-8"))
  );
  for (const [name, value] of secrets) {
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await setSecret({
      projectId: currentProject.projectId,
      secretLabel: name,
      secretValue: value
    });
  }
  spinner.succeed("Secrets set successfully");
});
var secrets_default = new Command6("secrets").description("Manage project secrets").addCommand(setCommand).addCommand(setFileCommand);

// libs/remote/src/tokens.ts
import chalk2 from "chalk";
import { Command as Command7 } from "commander";
var create2 = new Command7("create").addOption(projectOption.makeOptionMandatory(false)).action(async ({ name }) => {
  const user = await ensureUser();
  if (!user) return;
  const [projects = { records: [] }] = await fetchProjects();
  if (projects.records.length === 0) {
    box.print(
      "No projects found",
      "$ npx serverize projects create <project-name>"
    );
    return;
  }
  let projectId = projects.records.length === 1 ? projects.records[0].id : "";
  if (name) {
    const [project] = projects.records.filter(
      (project2) => project2.name === name
    );
    if (!project) {
      spinner.fail(`Project ${chalk2.red(name)} not found`);
      return;
    }
    projectId = project.id;
  }
  projectId ??= await dropdown({
    title: "Select a project",
    choices: projects.records.map(({ name: name2, id }) => ({ name: name2, value: id }))
  });
  const [data, error] = await request.post("/tokens", { projectId });
  if (error || !data) return;
  box.print("Save it in secure place", data);
});
var revoke = new Command7("revoke").action(async () => {
  const user = await ensureUser();
  if (!user) return;
  await request.remove("/tokens", {});
});
var list3 = new Command7("list").action(async () => {
  const user = await ensureUser();
  if (!user) return;
  const [tokens] = await fetchTokens();
  if (!tokens) return;
  if (tokens.length === 0) {
    box.print(
      "No tokens found",
      "$ npx serverize tokens create <project-name>"
    );
    return;
  }
  console.table(
    tokens.map((token) => ({
      Project: token.project.name,
      "Created At": token.createdAt
    }))
  );
});
var tokens_default = new Command7("tokens").addCommand(create2).addCommand(list3).addCommand(revoke);

// libs/remote/src/cli.ts
marked.use(markedTerminal({}));
cli.action(async () => {
  box.print(
    "Welcome!",
    "",
    "Serverize makes it effortless to deploy your project to the cloud and have it running in seconds.",
    "",
    "Get started in three simple steps:",
    "1. Sign in or create an account.",
    "2. Containerize your project.",
    "3. Run the deploy command.",
    "",
    await marked(
      "Check out our [Guides](https://serverize.beta.january.sh/#integrations-section) on how to containerize your project."
    ),
    "",
    "To log in: $ npx serverize auth signin",
    "To sign up: $ npx serverize auth signup",
    "",
    "Once logged in, and dockerized, run the deploy command",
    "To deploy: $ npx serverize deploy -p <project-name>",
    "",
    "For more commands, run $ npx serverize --help"
  );
}).addCommand(deploy_default).addCommand(secrets_default).addCommand(logs_default).addCommand(auth_default).addCommand(project_default).addCommand(tokens_default).addCommand(releases_default).parse(process.argv);
//# sourceMappingURL=cli.js.map
