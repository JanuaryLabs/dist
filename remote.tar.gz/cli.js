#!/usr/bin/env node
import { createRequire } from 'module'; const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// libs/sdk/parser/src/index.ts
var src_exports = {};
__export(src_exports, {
  Checker: () => Checker,
  getExports: () => getExports,
  legacy_parse: () => legacy_parse,
  parse: () => parse
});
import { readFileSync } from "fs";
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const featureExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!featureExpr) {
    return null;
  }
  if (!checker.isCallExpression(featureExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(featureExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, prop.key.value);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}
function isExportItem(item) {
  return exportTypes.some((x) => {
    return item && item.type === x;
  });
}
async function getExports(code) {
  const ast2 = await parseCode(code);
  if (!ast2) {
    return [];
  }
  return ast2.body.filter(isExportItem);
}
var checker, Checker, isWorker, exportTypes;
var init_src = __esm({
  "libs/sdk/parser/src/index.ts"() {
    "use strict";
    ((checker2) => {
      function isCallExpression(node, name) {
        if (!node) {
          return false;
        }
        const isCallExpr = node.type === "CallExpression";
        if (!isCallExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        if (node.callee.type === "MemberExpression") {
          return node.callee.property.type === "Identifier" && node.callee.property.value === name;
        }
        return node.callee.type === "Identifier" && node.callee.value === name;
      }
      checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(node) {
        return node.type === "ObjectExpression";
      }
      checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isKeyValueProperty(node, valueType, keyName) {
        if (node.type !== "KeyValueProperty") {
          return false;
        }
        if (!valueType) {
          return true;
        }
        const sameType = node.value.type === valueType;
        if (!sameType) {
          return false;
        }
        if (!keyName) {
          return true;
        }
        return isIdentifier(node.key, keyName);
      }
      checker2.isKeyValueProperty = isKeyValueProperty;
      __name(isKeyValueProperty, "isKeyValueProperty");
      function isNullLiteral(node) {
        return node.type === "NullLiteral";
      }
      checker2.isNullLiteral = isNullLiteral;
      __name(isNullLiteral, "isNullLiteral");
      function isPrimitive(node) {
        if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
          return true;
        }
        return false;
      }
      checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isIdentifier(node, name) {
        if (!node) {
          return false;
        }
        const isIdentifier2 = node.type === "Identifier";
        if (!isIdentifier2) {
          return false;
        }
        if (!name) {
          return true;
        }
        return node.value === name;
      }
      checker2.isIdentifier = isIdentifier;
      __name(isIdentifier, "isIdentifier");
      function isMemberExpression(node, name) {
        if (!node) {
          return false;
        }
        const isMemberExpr = node.type === "MemberExpression";
        if (!isMemberExpr) {
          return false;
        }
        if (!name) {
          return true;
        }
        return isIdentifier(node.property, name);
      }
      checker2.isMemberExpression = isMemberExpression;
      __name(isMemberExpression, "isMemberExpression");
      function isArrayExpression(node) {
        return node.type === "ArrayExpression";
      }
      checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(checker || (checker = {}));
    ((Checker2) => {
      function isPrimitive(value) {
        return value !== Object(value);
      }
      Checker2.isPrimitive = isPrimitive;
      __name(isPrimitive, "isPrimitive");
      function isCallExpression(value) {
        return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
      }
      Checker2.isCallExpression = isCallExpression;
      __name(isCallExpression, "isCallExpression");
      function isObjectExpression(value) {
        return !isCallExpression(value) && value !== null && typeof value === "object";
      }
      Checker2.isObjectExpression = isObjectExpression;
      __name(isObjectExpression, "isObjectExpression");
      function isArrayExpression(value) {
        return Array.isArray(value);
      }
      Checker2.isArrayExpression = isArrayExpression;
      __name(isArrayExpression, "isArrayExpression");
    })(Checker || (Checker = {}));
    isWorker = /* @__PURE__ */ __name(() => {
      return typeof global.importScripts === "function";
    }, "isWorker");
    __name(isRecord, "isRecord");
    __name(isSpan, "isSpan");
    __name(adjustOffsetOfAst, "adjustOffsetOfAst");
    __name(parseCode, "parseCode");
    __name(legacy_parse, "legacy_parse");
    __name(parse, "parse");
    __name(getImports, "getImports");
    __name(resolveAsExpression, "resolveAsExpression");
    __name(resolveCallExpression, "resolveCallExpression");
    __name(resolveUnaryExpression, "resolveUnaryExpression");
    __name(resolveArrayExpression, "resolveArrayExpression");
    __name(resolveObjectExpression, "resolveObjectExpression");
    __name(resolveMemberExpression, "resolveMemberExpression");
    exportTypes = [
      "ExportAllDeclaration",
      "ExportDeclaration",
      "ExportDefaultDeclaration",
      "ExportDefaultExpression",
      "ExportNamedDeclaration",
      "ImportDeclaration"
    ];
    __name(isExportItem, "isExportItem");
    __name(getExports, "getExports");
  }
});

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 1,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}
__name(box, "box");
function network(port = process.env["PORT"]) {
  console.log(
    box(
      "Server",
      `\u2139 Localhost: http://localhost:${port}`,
      `\u2714 Network IP: http://${ip.address()}:${port}`,
      `\u26A0 Note: Ensure the requesting device connected on the same network`
    )
  );
}
__name(network, "network");
var pretty = {
  network,
  box,
  swagger: /* @__PURE__ */ __name(async (pattern) => {
    const swaggerFiles = await glob(pattern, {
      cwd: import.meta.dirname
    });
    const swaggerEndpoints = swaggerFiles.map((x) => x.split(".swagger.json").shift()).map((it) => `/${it}/swagger`);
    console.log(box("Swagger Docs", ...swaggerEndpoints));
  }, "swagger")
};

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors2 = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors2.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors2.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors2.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors2.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors2.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlash(path) {
  return path.replace(/\/$/, "");
}
__name(removeTrialingSlash, "removeTrialingSlash");
function retryPromise(promise) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config.accessor(item)]: config.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms2) {
  return new Promise((resolve) => setTimeout(resolve, ms2));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return {
      value: await fn(),
      error: void 0
    };
  } catch (error) {
    return { error };
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlash(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node) {
    return node.value;
  }
  async visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.map((arg) => arg.accept(this)).join(", ");
    return `${node.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `SELECT ${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitPropertyAccess(node) {
    return `${node.expression.accept(this)} FROM ${node.name.accept(this)}`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    const where = node.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node) {
    return `.select('${node.expression.accept(this)}')${node.name.accept(
      this
    )}`;
  }
  visitNamespace(node) {
    if (node.name.value === "tables") {
      return `qb${node.expression.accept(this)}`;
    }
    return `'${node.toLiteral(this)}'`;
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node) {
    return node.toLiteral(this);
  }
  visitPropertyAccess(node) {
    return node.toLiteral(this);
  }
  visitNamespace(node) {
    return {
      namespace: node.name.value,
      value: node.expression.accept(this)
    };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    return node.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node) {
    const name = node.name.accept(this);
    if (typeChecker.isNamespace(node.value)) {
      const value2 = node.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node) {
    const left = node.left.accept(this);
    const right = node.right.accept(this);
  }
  visitCall(node) {
    const name = node.name.accept(this);
    const args = node.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node) {
    return `${node.name.accept(this)}.${node.expression.accept(this)}`;
  }
  visitNamespace(node) {
    const id = v4();
    const name = `@${node.name.accept(this)}:${node.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node) {
    return node.value;
  }
  visitStringLiteral(node) {
    return `'${node.value}'`;
  }
  visit(node) {
    node.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
import crypto from "crypto";
import { createReadStream, existsSync } from "fs";
import { mkdir, readFile, rm, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { basename, dirname as dirname2, join as join2 } from "path";
function followProgress(stream, logger5 = console) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger5.log(obj);
        }
      }
    );
  });
}
__name(followProgress, "followProgress");
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
__name(upsertVolume, "upsertVolume");
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
__name(upsertNetwork, "upsertNetwork");
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
__name(getContainer, "getContainer");
async function removeContainer(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    await container.stop({ t: 0 }).catch(console.error);
  }
  await container.remove({ force: true }).catch(console.error);
}
__name(removeContainer, "removeContainer");
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
__name(isContainerRunning, "isContainerRunning");
function computeChecksum(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("md5");
    const stream = typeof filePath === "string" ? createReadStream(filePath) : filePath;
    stream.on("data", (data) => hash.update(data));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", (err) => reject(err));
  });
}
__name(computeChecksum, "computeChecksum");
async function fileChanged(filePath, discrminator) {
  const checksumDirPath = join2(tmpdir(), discrminator);
  await mkdir(checksumDirPath, { recursive: true });
  const checksumFilePath = join2(checksumDirPath, basename(filePath));
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(fileChanged, "fileChanged");
async function contentChanged(content, fileName, discrminator) {
  const checksumFilePath = join2(tmpdir(), discrminator, fileName);
  await mkdir(dirname2(checksumFilePath), { recursive: true });
  const filePath = join2(tmpdir(), "check", discrminator, fileName);
  await mkdir(dirname2(filePath), { recursive: true });
  await writeFile(filePath, content, "utf-8");
  const currentChecksum = await computeChecksum(filePath);
  const flush = /* @__PURE__ */ __name(async () => {
    await rm(checksumFilePath, { force: true });
  }, "flush");
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
__name(contentChanged, "contentChanged");
function makeProjectPath(projectId) {
  return join2(tmpdir(), "client-server", projectId);
}
__name(makeProjectPath, "makeProjectPath");
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
__name(makeRunningImageName, "makeRunningImageName");
function makeRunningContainerName(projectId) {
  return projectId;
}
__name(makeRunningContainerName, "makeRunningContainerName");
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}
__name(followLogs, "followLogs");
async function startContainer(name, createContainer) {
  let container = null;
  if (typeof name === "string") {
    container = await getContainer({ name });
  } else {
    container = name;
  }
  if (!container) {
    if (!createContainer) {
      throw new Error(`Cannot initialize server for project: ${name}`);
    }
    container = await createContainer();
  }
  const running = await isContainerRunning(container);
  if (!running) {
    await container.start().catch((error) => {
      if (error.statusCode === 304) {
        return;
      }
      throw error;
    });
  }
  return container;
}
__name(startContainer, "startContainer");
async function getContainerNet(containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings;
}
__name(getContainerNet, "getContainerNet");
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}
__name(getContainerExternalPort, "getContainerExternalPort");
async function pushImage(repo, tag = "latest") {
  const image = docker.getImage(repo);
  const stream = await image.push({
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    },
    tag
  });
  await followProgress(stream);
  return image;
}
__name(pushImage, "pushImage");
async function pullImage(image, tag = "latest") {
  const stream = await docker.createImage({
    fromImage: image,
    tag,
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    }
  });
  await followProgress(stream);
  return image;
}
__name(pullImage, "pullImage");

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  __name(whatIsParserImport, "whatIsParserImport");
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}
__name(formatCode, "formatCode");

// libs/compiler/generator/utils/src/index.ts
var getExt = /* @__PURE__ */ __name((fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
}, "getExt");
function toVirtualFile(it) {
  const parts = it.path.split("/").filter(Boolean);
  const fileName = parts.at(-1);
  return {
    isFolder: false,
    name: it.path.split("/").pop() || "unknown",
    path: parts.join("/"),
    extension: getExt(fileName),
    content: it.content,
    metadata: {
      path: it.path
    }
  };
}
__name(toVirtualFile, "toVirtualFile");
function mapFilesToTree(files) {
  function toTree(parts, tree, content) {
    const [part, ...rest] = parts;
    if (rest.length === 0) {
      return {
        ...tree,
        [part]: content
      };
    }
    return {
      ...tree,
      [part]: toTree(rest, tree[part] || {}, content)
    };
  }
  __name(toTree, "toTree");
  return files.reduce((acc, it) => {
    const parts = it.path.split("/").filter(Boolean);
    return toTree(parts, acc, it.content);
  }, {});
}
__name(mapFilesToTree, "mapFilesToTree");
function mapFilesToTreeNodes(files) {
  const tree = mapFilesToTree(files);
  function toTreeNodes(tree2, path = []) {
    return Object.entries(tree2).map(([name, value]) => {
      const newPath = [...path, name];
      if (typeof value === "string") {
        return {
          id: newPath.join("/"),
          name,
          path: newPath.join("/"),
          metadata: {
            path: newPath.join("/")
          }
        };
      }
      return {
        id: newPath.join("/"),
        name,
        children: toTreeNodes(value, newPath),
        metadata: {
          path: newPath.join("/")
        }
      };
    }).sort((a, b) => "children" in a ? -1 : 1);
  }
  __name(toTreeNodes, "toTreeNodes");
  return toTreeNodes(tree);
}
__name(mapFilesToTreeNodes, "mapFilesToTreeNodes");
function getFile(list, path) {
  const file = list.find(
    (it) => JSON.stringify(it.path.split("/").filter(Boolean)) === JSON.stringify(path.split("/").filter(Boolean))
  );
  if (!file) {
    throw new Error(`File not found: ${path}`);
  }
  return file;
}
__name(getFile, "getFile");
function emptyFile(file = {}) {
  return {
    isFolder: false,
    name: "unknown",
    extension: "",
    content: "",
    path: "",
    ...file
  };
}
__name(emptyFile, "emptyFile");

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";
var BrowserLookupFs = class {
  static {
    __name(this, "BrowserLookupFs");
  }
  #lookupModules = /* @__PURE__ */ new Set();
  exists(path) {
    return localforage.getItem(path).then((item) => !!item).catch(() => false);
  }
  moduleExists(sourceData) {
    return this.exists(`package:${sourceData.package}`);
  }
  getFiles(sourceData) {
    return localforage.getItem(`files:${sourceData.package}`).then((files) => files || []).catch(() => []);
  }
  getFileContent(path) {
    return localforage.getItem(path).then((item) => item);
  }
  getPackageJson(sourceData) {
    return localforage.getItem(`package:${sourceData.package}`).then((item) => item);
  }
  mapFiles(files) {
    return files.map((file) => ({
      originalFile: file,
      relativeFile: file
    }));
  }
  lock(source) {
    this.#lookupModules.add(source);
  }
  isLocked(source) {
    return this.#lookupModules.has(source);
  }
};

// libs/playground/package-installer/src/lib/parser.ts
import { dirname as dirname3, join as join3 } from "path";
function coercePackageJson(packageJson) {
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.peerDependencies = packageJson.peerDependencies || {};
  return packageJson;
}
__name(coercePackageJson, "coercePackageJson");
function makeFileUri(specifier, fileName) {
  return `file:///node_modules/${specifier}/${fileName}`;
}
__name(makeFileUri, "makeFileUri");
function parseSpecifer(specifier) {
  const [moduleName, version] = specifier.split("@").filter(Boolean);
  return {
    moduleName,
    version: version === "*" ? "latest" : version
  };
}
__name(parseSpecifer, "parseSpecifer");
function normalizeImport(typesUrl, relativeImport) {
  const url = new URL(typesUrl);
  const relativeImportPathname = join3(dirname3(url.pathname), relativeImport);
  return new URL(relativeImportPathname, url.origin).href;
}
__name(normalizeImport, "normalizeImport");
function cleanText(text) {
  return text.replace("export {}", "").replaceAll("export function", "export declare function").replaceAll("export const", "export declare const");
}
__name(cleanText, "cleanText");
async function fetchDts(typesUrl) {
  const result = {
    error: false,
    loaded: false,
    text: ""
  };
  try {
    const response = await fetch(typesUrl);
    if (response.ok) {
      const text = await response.text();
      if (text.includes("[Package Error]")) {
        throw new Error("Package Error");
      }
      result.text = cleanText(text);
      result.loaded = true;
    } else {
      result.error = true;
    }
  } catch (error) {
    result.error = true;
    result.loaded = false;
  }
  return result;
}
__name(fetchDts, "fetchDts");
function parseSource(source) {
  let index = 0;
  const tokens = [];
  while (index < source.length) {
    switch (source[index]) {
      case "@":
        {
          let subindex = index + 1;
          while (subindex < source.length && source[subindex] !== "/") {
            subindex++;
          }
          tokens.push({
            type: "at",
            value: source.slice(index + 1, subindex)
          });
          index = subindex;
        }
        break;
      default:
        {
          let lastToken = tokens[tokens.length - 1];
          if (!lastToken || lastToken.type !== "string") {
            lastToken = {
              type: "string",
              value: ""
            };
            tokens.push(lastToken);
          }
          lastToken.value += source[index];
          index++;
        }
        break;
    }
  }
  if (tokens[0].type === "at") {
    tokens[0].type = "scope";
    tokens[1].type = "package";
    if (tokens[2]) {
      tokens[2].type = "version";
    }
  }
  if (tokens[0].type === "string") {
    tokens[0].type = "package";
    if (tokens[1]) {
      tokens[1].type = "version";
    }
  }
  const moduleName = (tokens.find((x) => x.type === "package")?.value || "").replace("/", "");
  const version = tokens.find((x) => x.type === "version")?.value || "latest";
  const scope = tokens.find((x) => x.type === "scope")?.value;
  const file = tokens.find((x) => x.type === "string")?.value;
  return {
    moduleName,
    version,
    scope,
    package: `${scope ? `@${scope}/` : ""}${moduleName}`,
    full: `${scope ? `@${scope}/` : ""}${moduleName}@${version}`,
    file
  };
}
__name(parseSource, "parseSource");
function sourceDataToString(source) {
  return `${source.scope ? `${source.scope}/` : ""}${source.moduleName}@${source.version}`;
}
__name(sourceDataToString, "sourceDataToString");

// libs/playground/package-installer/src/lib/deps-install-manager.ts
import { basename as basename2, dirname as dirname4, extname, join as join4, relative } from "path";
var PackageExports = class {
  constructor(pkg) {
    this.pkg = pkg;
  }
  static {
    __name(this, "PackageExports");
  }
  #extractTypes(exportConfig) {
    if (Array.isArray(exportConfig)) {
      return this.#extractTypes(
        exportConfig.filter((it) => typeof it === "string")[0]
      );
    }
    if (typeof exportConfig === "object") {
      if (typeof exportConfig?.types === "string") {
        return this.#extractTypes(exportConfig.types);
      }
      if (typeof exportConfig?.default === "string") {
        return this.#extractTypes(exportConfig?.default);
      }
    }
    if (typeof exportConfig === "string") {
      return fixTypeExportName(exportConfig);
    }
    return null;
  }
  #correctEndpoint(endpoint) {
    if (typeof endpoint === "string") {
      return fixTypeExportName(endpoint);
    }
    return this.#extractTypes(endpoint);
  }
  #tryFiles(index) {
    if (!index.endsWith("index.d.ts")) {
      return this.pkg.files?.find((it) => it.endsWith("index.d.ts")) || index;
    }
    return index;
  }
  formatExports() {
    const exports = this.mainExport();
    const deleteKeys = [
      (it) => it.includes("*"),
      (it) => it.includes("production"),
      (it) => it.includes("development"),
      (it) => it.includes("package.json"),
      (it) => it.includes("default"),
      (it) => it.includes("require"),
      (it) => it.includes("import"),
      (it) => it === ".",
      (it) => it === "./",
      (it) => it === "/"
    ];
    const cleanedExports = Object.fromEntries(
      Object.entries(this.pkg.exports).filter(
        ([endpoint]) => !deleteKeys.some((x) => x(endpoint))
      )
    );
    const formattedEndpoints = Object.fromEntries(
      Object.entries(cleanedExports).map(([endpoint, exports2]) => [
        endpoint,
        {
          types: this.#correctEndpoint(exports2) || // use the endpoint as the type as last resort
          fixTypeExportName(endpoint)
        }
      ])
    );
    return {
      ...exports,
      ...formattedEndpoints
    };
  }
  mainExport() {
    if (!this.pkg.exports) {
      return {
        ".": {
          types: this.#tryFiles(
            fixTypeExportName(
              this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
            )
          )
        }
      };
    }
    if (typeof this.pkg.exports === "string") {
      return {
        ".": {
          types: this.#tryFiles(fixTypeExportName(this.pkg.exports))
        }
      };
    }
    return {
      ".": {
        types: this.#correctEndpoint(this.pkg.exports["."]) || this.#tryFiles(
          fixTypeExportName(
            this.pkg.types || this.pkg.typings || this.pkg.main || "index.d.ts"
          )
        )
      }
    };
  }
};
var nodeTypes = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
var Resolver = class {
  constructor(pkgKeeper, keeper, registries) {
    this.pkgKeeper = pkgKeeper;
    this.keeper = keeper;
    this.registries = registries;
  }
  static {
    __name(this, "Resolver");
  }
  async resolve(source) {
    if (nodeTypes.includes(source) || nodeTypes.some((it) => `node:${it}` === source) || nodeTypes.includes(`node:${source}`) || source.startsWith("@extensions")) {
      return null;
    }
    console.log("Resolving => ", source);
    const info = {
      deps: []
    };
    const resolutions$ = [];
    const pkg = await this.#packageJson(source).catch((error) => null);
    if (pkg === null) {
      console.log(`Resolution stopped: package.json not found for ${source}`);
      return null;
    }
    if (!pkg) {
      console.log(`Resolution stopped: missing package.json for ${source}`);
      return null;
    }
    const sourceData = parseSource(source);
    if (sourceData.version === "latest") {
      source = sourceDataToString({
        ...sourceData,
        version: pkg.version
      });
    }
    const recorder = createRecorder({ label: source });
    for (const [specifier, version] of [
      ...Object.entries(pkg.dependencies ?? {}),
      ...Object.entries(pkg.peerDependencies ?? {})
    ]) {
      const source2 = `${specifier}@${version}`;
      resolutions$.push(async () => {
        info.deps.push(await this.resolve(source2));
      });
    }
    const endpoints = [];
    for (const [secondaryEndpoint, exportedModule] of Object.entries(
      pkg.exports
    )) {
      resolutions$.push(async () => {
        const secondaryEndpointSource = join4(source, secondaryEndpoint);
        console.log("Resolving secondary", secondaryEndpointSource);
        await this.#fetch(
          secondaryEndpointSource,
          join4(source, exportedModule.types)
        ).then((r) => {
          if (secondaryEndpoint === "." && r.loaded) {
            info.resolved = true;
          }
        });
        endpoints.push({
          source: secondaryEndpointSource,
          typePath: exportedModule.types,
          typeSource: join4(source, exportedModule.types),
          name: secondaryEndpoint
        });
      });
    }
    info.source = source;
    info.endpoints = endpoints;
    await Promise.all(
      resolutions$.map(
        (it) => it()
        //   .catch((error) => {
        //   console.error(error);
        //   throw error;
        // }),
        //   .catch((error) => {
        //   console.log(`Failed to resolve ${source} due to`);
        //   console.error(error);
        // }),
      )
    );
    recorder.end();
    console.log("Resolved", source);
    return info;
  }
  async #resolveRelativeImports(fileContent, source) {
    const exports = await getFileExports(
      fileContent.replaceAll("export const", "declare const")
    );
    const types$ = exports.map(async (exportSepecifier) => {
      const maybeDeps = !exportSepecifier.startsWith(".");
      if (maybeDeps) {
        console.log("Resolving relative deps", exportSepecifier);
        const isDeps = await this.resolve(exportSepecifier).catch(() => null);
        if (isDeps?.resolved) {
          return null;
        }
      }
      console.log("Resolving relative file", exportSepecifier);
      const relativeExportSource = join4(source, exportSepecifier);
      const relativeExportTypeExport = fixTypeExportName(relativeExportSource);
      const entry = await this.#entry(relativeExportSource);
      entry.path = exportSepecifier;
      if (entry.loaded) {
        return null;
      }
      if (entry.error || entry.loading) {
        return null;
      }
      return this.#fetch(relativeExportSource, relativeExportTypeExport);
    });
    return Promise.all(types$);
  }
  async #fetch(source, typeExport) {
    const entry = await this.#entry(source);
    if (entry.loaded) {
      console.log(`Already loaded ${source}`);
      return entry;
    }
    if (entry.error) {
      console.log(`Already errored ${source}`);
      return entry;
    }
    if (entry.loading) {
      console.log(`Already loading ${source}`);
      return entry;
    }
    entry.loading = true;
    entry.loaded = false;
    const registries = this.registries.slice(0);
    while (!entry.loaded) {
      const registry = registries.shift();
      if (!registry) {
        break;
      }
      const result = await registry.resolve(typeExport);
      if (result.loaded) {
        entry.loaded = true;
        entry.text = result.text;
        await this.keeper.set(source, entry);
        break;
      }
    }
    entry.typeExport = typeExport;
    entry.loading = false;
    if (entry.loaded) {
      const entries = await this.#resolveRelativeImports(
        entry.text,
        dirname4(typeExport)
      );
      entry.related = entries.filter(notNullOrUndefined);
    }
    entry.error = entry.loaded === false;
    return entry;
  }
  async #packageJson(source) {
    let pkg = await this.pkgKeeper.get(source).catch((error) => {
      console.error(error);
      return null;
    });
    if (pkg === null) {
      console.log(`Using cached package ${source}`);
      return pkg;
    }
    if (!pkg) {
      const registries = this.registries.slice(0);
      while (!pkg) {
        const registry = registries.shift();
        if (!registry) {
          break;
        }
        pkg = await registry.packageJson(source).catch(() => null);
      }
      await this.pkgKeeper.set(source, pkg || null);
    }
    if (!pkg) {
      throw new Error(`Failed to resolve package ${source}`);
    }
    pkg.dependencies = pkg.dependencies || {};
    pkg.devDependencies = pkg.devDependencies || {};
    pkg.peerDependencies = pkg.peerDependencies || {};
    const packageExports = new PackageExports(pkg);
    pkg.exports = packageExports.formatExports();
    pkg.dependencies = Object.fromEntries(
      Object.entries(pkg.dependencies).map(([specifier, version]) => {
        if (pkg.devDependencies && pkg.devDependencies[`@types/${specifier}`]) {
          return [
            `@types/${specifier}`,
            pkg.devDependencies[`@types/${specifier}`]
          ];
        }
        return [specifier, version];
      })
    );
    return pkg;
  }
  async #entry(source) {
    const inCache = await this.keeper.get(source);
    if (inCache) {
      return inCache;
    }
    const entry = {
      loaded: false,
      source,
      text: "",
      loading: false,
      typeExport: "",
      related: [],
      path: ""
    };
    return entry;
  }
  async #flatEntry(entry, basePath, seed) {
    for (const endpointEntry of (await this.#entry(entry.source)).related) {
      if (!endpointEntry.loaded) {
        continue;
      }
      seed.push({
        path: join4(
          dirname4(
            join4(
              basePath,
              relative(dirname4(entry.typeSource), endpointEntry.source)
            )
          ),
          basename2(endpointEntry.typeExport)
        ),
        content: endpointEntry.text,
        loaded: endpointEntry.loaded
      });
      for (const nestedEntry of endpointEntry.related) {
        seed.push({
          path: join4(
            dirname4(
              join4(
                basePath,
                relative(dirname4(entry.typeSource), nestedEntry.source)
              )
            ),
            basename2(nestedEntry.typeExport)
          ),
          content: nestedEntry.text,
          loaded: nestedEntry.loaded
        });
        await this.#flatEntry(
          {
            source: nestedEntry.source,
            typeSource: nestedEntry.typeExport
          },
          join4(basePath, nestedEntry.path),
          seed
        );
      }
    }
  }
  async flatten(info, basePath, seed) {
    for (const endpoint of info.endpoints) {
      const secondaryPath = join4(basePath, endpoint.name);
      await this.#flatEntry(endpoint, secondaryPath, seed);
      const entry = await this.#entry(endpoint.source);
      seed.push({
        path: join4(secondaryPath, basename2(endpoint.typePath)),
        content: entry.text,
        loaded: entry.loaded
      });
    }
    for (const deps of info.deps) {
      if (!deps) {
        continue;
      }
      const depsSourceData = parseSource(deps.source);
      await this.flatten(
        deps,
        join4(basePath, "node_modules", depsSourceData.package),
        seed
      );
    }
  }
};
async function getFileExports(content) {
  const isNodejs = typeof process !== "undefined";
  const exports = isNodejs ? await Promise.resolve().then(() => (init_src(), src_exports)).then(
    ({ getExports: getExports2 }) => getExports2(content)
  ) : await runWorker("/morph/parser.worker.js", {
    type: "getExports",
    payload: content
  });
  return removeDuplicates(
    exports.filter(
      (it) => it.type === "ExportAllDeclaration" || it.type === "ExportNamedDeclaration" || it.type === "ImportDeclaration"
    ).map((it) => it.source?.value).filter(notNullOrUndefined),
    (it) => it
  );
}
__name(getFileExports, "getFileExports");
function fixTypeExportName(name) {
  if (extname(name)) {
    name = name.replace(".d.ts", "").replace(".ts", "").replace(".js", "");
  }
  return `${name}.d.ts`;
}
__name(fixTypeExportName, "fixTypeExportName");

// libs/modern/src/lib/module-lookup.ts
var nodeTypes2 = [
  "path",
  "constants",
  "domain",
  "diagnostics_channel",
  "globals",
  "sea",
  "string_decoder",
  "tls",
  "tty",
  "punycode",
  "readline",
  "crypto",
  "trace_events",
  "events",
  "os",
  "buffer",
  "querystring",
  "worker_threads",
  "dom-events",
  "console",
  "async_hooks",
  "dns",
  "vm",
  "timers",
  "globals.global",
  "test",
  "http",
  "http2",
  "stream",
  "inspector",
  "v8",
  "perf_hooks",
  "url",
  "cluster",
  "https",
  "assert",
  "fs",
  "repl",
  "dgram",
  "child_process",
  "zlib",
  "module",
  "process",
  "util",
  "wasi",
  "index",
  "net",
  "dns/promises",
  "readline/promises",
  "timers/promises",
  "stream/consumers",
  "stream/web",
  "stream/promises",
  "fs/promises",
  "assert/strict"
];
async function lookupModule(source, fs, options) {
  const sourceData = parseSource(source);
  if (nodeTypes2.includes(sourceData.package) || nodeTypes2.some((it) => `node:${it}` === sourceData.package) || nodeTypes2.includes(`node:${sourceData.package}`) || source.startsWith("@extensions")) {
    console.log(`Source ${source} is a node type`);
    return;
  }
  if (fs.isLocked(source)) {
    return;
  }
  fs.lock(source);
  if (!await fs.moduleExists(sourceData)) {
    console.log(`Source ${source} not found`);
    const installed = await options.onMissingPackage(source, sourceData);
    if (!installed) {
      return;
    }
  }
  const packageJson = await fs.getPackageJson(sourceData);
  const files = await fs.getFiles(sourceData);
  await options.onFiles(sourceData, packageJson, files);
  await options.onPackageJson(sourceData, packageJson);
  await lookupPackage(packageJson, fs, options);
}
__name(lookupModule, "lookupModule");
async function lookupPackage(packageJson, fs, options) {
  coercePackageJson(packageJson);
  for (const depKey of ["dependencies", "peerDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      await lookupModule(depsName, fs, options);
    }
  }
  for (const depKey of ["devDependencies"]) {
    for (const [depsName, depsVersion] of Object.entries(packageJson[depKey])) {
      if (depsName.startsWith("@types/")) {
        await lookupModule(depsName, fs, options);
      }
    }
  }
}
__name(lookupPackage, "lookupPackage");

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";
var octokit = /* @__PURE__ */ __name((token) => import("@octokit/core").then(({ Octokit }) => new Octokit({ auth: token })), "octokit");
async function generateKey() {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.crypto_secretbox_keygen();
}
__name(generateKey, "generateKey");
async function encrypt(key, plain) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const secret = sodium.crypto_secretbox_easy(
    plain,
    nonce,
    new Uint8Array(key)
  );
  return {
    secret,
    nonce
  };
}
__name(encrypt, "encrypt");
async function decrypt(secret, nonce, key) {
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  return sodium.to_string(
    sodium.crypto_secretbox_open_easy(secret, nonce, key)
  );
}
__name(decrypt, "decrypt");
async function createEmptySecret(token, repositoryName, name) {
  const [owner, repo] = repositoryName.split("/");
  const sodium = await import("libsodium-wrappers").then(
    ({ default: sodium2 }) => sodium2.ready.then(() => sodium2)
  );
  try {
    await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
      owner,
      repo,
      secret_name: name
    });
    return;
  } catch (error) {
    const _error = error;
    if ("documentation_url" in _error) {
      if (_error.status !== 404) {
        throw error;
      }
    }
  }
  const key = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/secrets/public-key", {
    owner,
    repo
  });
  const binkey = sodium.from_base64(
    key.data.key,
    sodium.base64_variants.ORIGINAL
  );
  const binsec = sodium.from_string(" ");
  const encBytes = sodium.crypto_box_seal(binsec, binkey);
  const output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL);
  await (await octokit(token)).request("PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}", {
    owner,
    repo,
    secret_name: name,
    encrypted_value: output,
    key_id: key.data.key_id
  });
}
__name(createEmptySecret, "createEmptySecret");
async function createRepoistory(token, repositoryName, organizationId, workspaceId, projectId) {
  try {
    const result = await (await octokit(token)).request("POST /user/repos", {
      name: repositoryName,
      description: "January generated repository.",
      gitignore_template: "Node",
      private: true,
      auto_init: false,
      request: {
        projectId
      },
      homepage: "https://january.sh"
      // TODO: it should be user server or user local development server (january ones)
    });
    return {
      id: result.data.id,
      name: result.data.full_name
    };
  } catch (error) {
    if (error?.response?.data) {
      const _error = error.response;
      const [firstError] = _error.errors ?? [];
      if (firstError && firstError.code === "custom" && firstError.field === "name") {
        throw new Error(
          "Repository already exists on this account. Please change the project name and try again."
        );
      }
    }
    throw error;
  }
}
__name(createRepoistory, "createRepoistory");
async function triggerDeploy(token, repositoryName, inputs = {}) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request(
    "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
    {
      owner,
      repo,
      // TODO: we should get the installed hosting extension and get the workflow id from it
      workflow_id: "deploy.yml",
      ref: "main",
      inputs
    }
  );
}
__name(triggerDeploy, "triggerDeploy");
async function deleteRepository(token, repositoryName) {
  const [owner, repo] = repositoryName.split("/");
  return (await octokit(token)).request("DELETE /repos/{owner}/{repo}", {
    owner,
    repo
  });
}
__name(deleteRepository, "deleteRepository");
async function listWorkflows(token, repositoryName, workflowFileName) {
  const [owner, repo] = repositoryName.split("/");
  const client = await octokit(token);
  const workflow = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  const run = await client.request(
    "GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    {
      owner,
      repo,
      workflow_id: workflowFileName
    }
  );
  return { workflow, run };
}
__name(listWorkflows, "listWorkflows");
async function getWorkflowRun(token, repositoryName, workflowFileName, sha) {
  const [owner, repo] = repositoryName.split("/");
  const result = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs", {
    owner,
    repo,
    workflow_id: workflowFileName,
    head_sha: sha,
    branch: "main",
    exclude_pull_requests: true
  });
  const run = result.data.workflow_runs[0];
  if (!run) {
    return {
      run: {
        status: "queued",
        conclusion: null
      },
      jobs: []
    };
  }
  const runJobs = await (await octokit(token)).request("GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs", {
    owner,
    repo,
    run_id: run.id
  });
  return {
    run,
    jobs: runJobs.data.jobs.map((it) => ({
      id: it.id,
      name: it.name,
      status: it.status,
      conclusion: it.conclusion,
      steps: (it.steps ?? []).map((step) => ({
        id: `${step.name}-${step.number}-${step.completed_at ?? 0}`,
        name: step.name,
        status: step.status,
        conclusion: step.conclusion,
        elapsed: step.completed_at && step.started_at ? differenceInSeconds(
          new Date(step.completed_at),
          new Date(step.started_at)
        ) : null
      }))
    }))
  };
}
__name(getWorkflowRun, "getWorkflowRun");

// libs/modern/src/index.ts
import { mkdir as mkdir2, writeFile as writeFile2 } from "fs/promises";
import { dirname as dirname5, isAbsolute, join as join5 } from "path";
import { tap } from "rxjs/operators";
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag, enabled = true) {
  const header = /* @__PURE__ */ __name((value, error) => typeof tag === "string" ? tag : tag(value, error), "header");
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}
__name(debug, "debug");
async function writeFiles(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join5(dir, file);
    await mkdir2(dirname5(filePath), { recursive: true });
    await writeFile2(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}
__name(writeFiles, "writeFiles");

// libs/docker/src/compose.ts
import yaml from "js-yaml";
function compose(services) {
  const dockerCompose = {
    volumes: {},
    networks: {},
    services: {}
  };
  const appEnvironment = {};
  for (const [serviceName, it] of Object.entries(services)) {
    const depends_on = it.dependsOn(services);
    Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
    delete it.composeService.appEnvironment;
    dockerCompose.services[serviceName] = {
      ...it.composeService,
      environment: Object.keys(it.composeService.environment).length ? it.composeService.environment : void 0,
      depends_on: depends_on.length ? depends_on : void 0
    };
    dockerCompose.volumes = {
      ...dockerCompose.volumes,
      ...it.volumes.filter((it2) => it2.isNamedVolume).reduce(
        (acc, it2) => ({
          ...acc,
          [it2.src]: {}
        }),
        {}
      )
    };
    dockerCompose.networks = {
      ...dockerCompose.networks,
      ...it.networks.reduce(
        (acc, it2) => ({
          ...acc,
          [it2]: {}
        }),
        {}
      )
    };
  }
  return {
    dockerCompose,
    environment: appEnvironment
  };
}
__name(compose, "compose");
function service(serviceLike) {
  const ports = (serviceLike.ports ?? []).map((it) => {
    const [host, internal] = it.split(":");
    return {
      host,
      internal
    };
  });
  const volumes = (serviceLike.volumes ?? []).map((it) => {
    const [src, dest] = it.split(":");
    return {
      src,
      dest,
      isNamedVolume: !(src.startsWith("/") || src.startsWith("./"))
    };
  });
  return {
    composeService: serviceLike,
    ports,
    volumes,
    networks: serviceLike.networks ?? [],
    dependsOn: /* @__PURE__ */ __name((services) => {
      const depends_on = [];
      for (const dependencie of serviceLike.depends_on ?? []) {
        for (const [serviceName, serviceLike2] of Object.entries(services)) {
          if (serviceLike2.composeService === dependencie) {
            depends_on.push(serviceName);
          }
        }
      }
      return depends_on;
    }, "dependsOn")
  };
}
__name(service, "service");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
var postgres = {
  image: "postgres:16",
  ports: ["5432:5432"],
  volumes: ["postgres_data:/var/lib/postgresql/data"],
  networks: ["development"],
  environment: {
    POSTGRES_PASSWORD: "yourpassword",
    POSTGRES_USER: "youruser",
    POSTGRES_DB: "yourdatabase"
  },
  get appEnvironment() {
    const {
      POSTGRES_PASSWORD: password,
      POSTGRES_USER: user,
      POSTGRES_DB: db
    } = this.environment;
    const [host, internal] = (this.ports ?? [])[0].split(":");
    return {
      CONNECTION_STRING: `postgresql://${user}:${password}@database:${host}/${db}`
    };
  }
};
var pgadmin = {
  image: "dpage/pgadmin4",
  ports: ["8080:8080"],
  networks: ["development"],
  environment: {
    PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
    PGADMIN_DEFAULT_PASSWORD: "password"
  }
};
var localServer = /* @__PURE__ */ __name((options = {
  port: "3000"
}) => {
  options.port ??= "3000";
  return {
    image: "node:lts",
    build: {
      context: ".",
      dockerfile: "Dockerfile"
    },
    networks: ["development"],
    restart: "unless-stopped",
    command: "node --watch /app/build/server.js",
    develop: {
      watch: [
        {
          action: "sync",
          path: "./output/build/server.js",
          target: "/app/build/server.js",
          ignore: ["node_modules/"]
        },
        {
          action: "rebuild",
          path: "./output/package.json"
        },
        {
          action: "rebuild",
          path: "./package.json"
        }
      ]
    },
    ports: [`${options.port}:${options.port}`, "9229:9229"],
    environment: {
      NODE_ENV: "development",
      PORT: options.port
    },
    env_file: [".env.compose", ".env", ...options.env_file ?? []]
  };
}, "localServer");
function writeCompose({
  dockerCompose,
  environment
}) {
  return writeFiles(process.cwd(), {
    "compose.dev.yml": yaml.dump(dockerCompose, {
      skipInvalid: false,
      noRefs: true,
      forceQuotes: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }),
    ".env.compose": toKevValEnv(environment)
  });
}
__name(writeCompose, "writeCompose");

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";
function createPack(content) {
  const pack = tarStream.pack();
  const entry = pack.entry({ name: "package.json" }, content, () => {
    pack.finalize();
  });
  entry.end();
  return new Promise((resolve, reject) => {
    entry.on("finish", () => {
      resolve(pack);
    });
    entry.on("error", reject);
  });
}
__name(createPack, "createPack");
function createExtract(onEntry) {
  const extract = tarStream.extract();
  extract.on("entry", (header, stream, next) => {
    onEntry(header.name, stream);
    stream.on("end", next);
    stream.resume();
  });
  extract.on("finish", () => {
    console.log("File extraction complete");
  });
  return extract;
}
__name(createExtract, "createExtract");
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}
async function execCommand(container, cmd) {
  const exec = await container.exec({
    AttachStdout: true,
    AttachStderr: true,
    Cmd: cmd,
    Tty: false,
    Privileged: false
  });
  const stream = await exec.start({});
  const outStream = new PassThrough();
  const errStream = new PassThrough();
  container.modem.demuxStream(stream, outStream, errStream);
  let out = "";
  let err = "";
  outStream.on("data", (chunk) => {
    out += chunk.toString();
  });
  errStream.on("data", (chunk) => {
    err += chunk.toString();
  });
  return new Promise((resolve, reject) => {
    stream.on("end", async () => {
      try {
        console.log(`Command ${cmd.join(" ")}`);
        const a = await exec.inspect();
        if (a.ExitCode !== 0) {
          const error = new Error(err);
          error.cause = a;
          reject(error);
        } else if (err) {
          const error = new Error(err);
          error.cause = a;
          return reject(error);
        } else {
          resolve(out);
        }
      } catch (e) {
        reject(e);
      }
    });
  });
}
__name(execCommand, "execCommand");
async function getDependencyInstaller() {
  const container = await startContainer(
    "dependency-installer",
    () => docker.createContainer({
      name: "dependency-installer",
      Image: "node:lts",
      WorkingDir: "/app",
      Cmd: ["tail", "-f", "/dev/null"],
      HostConfig: {
        Binds: [`node_modules:/app/node_modules`],
        CapDrop: ["ALL"],
        Privileged: false
      }
    })
  );
  await followLogs(container);
  return container;
}
__name(getDependencyInstaller, "getDependencyInstaller");
async function installPackage(sourceData) {
  const container = await getDependencyInstaller();
  await execCommand(container, [
    "sh",
    "-c",
    `echo '${JSON.stringify({
      version: "0.0.0",
      main: "./build/server.js",
      type: "module",
      dependencies: {
        "ua-parser-js": "^1.0.37",
        "request-ip": "^3.3.0",
        "rfc-7807-problem-details": "^1.1.0",
        ajv: "8.12.0",
        "ajv-formats": "2.1.1",
        "ajv-errors": "3.0.0",
        "ajv-keywords": "5.1.0",
        validator: "13.9.0",
        "lodash-es": "^4.17.21",
        "http-status-codes": "2.2.0",
        hono: "^4.4.0",
        "@hono/node-server": "^1.11.1",
        "@scalar/hono-api-reference": "^0.5.145",
        typeorm: "0.3.20",
        pg: "8.11.5",
        "sql-template-tag": "5.2.1",
        resend: "1.0.0",
        "@octokit/webhooks": "^13.2.7",
        "node-cron": "^3.0.3",
        [sourceData.package]: sourceData.version
      },
      devDependencies: {
        "@types/ua-parser-js": "^0.7.39",
        "@types/request-ip": "^0.0.41",
        "@types/lodash-es": "^4.17.12",
        "@types/node": "^20.11.26",
        typescript: "^4.9.4",
        "@types/validator": "13.7.17",
        "@types/node-cron": "^3.0.11",
        prettier: "3.3.2"
      }
    })}' > package.json`
  ]);
  await execCommand(container, [
    "sh",
    "-c",
    "npm install",
    "--no-audit",
    "--no-fund"
  ]);
  return container;
}
__name(installPackage, "installPackage");
async function installPackageJson(content, projectId) {
  const containerName = `${projectId}-install-deps`;
  const volumeName = "node_modules";
  const depsImage = "node:lts";
  const pack = await createPack(content);
  const { value: container, error } = await extractError(
    () => docker.createContainer({
      Image: depsImage,
      WorkingDir: "/app",
      name: containerName,
      Cmd: ["sh", "-c", "npm install", "--no-audit", "--no-fund"],
      HostConfig: {
        // Binds: [`${volumeName}:/app/node_modules`],
        AutoRemove: true,
        // ReadonlyRootfs: true,
        CapDrop: ["ALL"]
      }
    })
  );
  if (error) {
    const { statusCode, message } = error;
    switch (statusCode) {
      case 409:
        await removeContainer(containerName).catch(() => {
        });
        await installPackageJson(content, projectId);
        break;
      case 404:
        console.log(`Image not found: ${depsImage}`);
        console.error(error);
        break;
      default:
        console.error(error);
        break;
    }
    return;
  }
  try {
    await container.putArchive(pack, {
      path: "/app"
    });
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      logs: true
    });
    stream.pipe(process.stdout);
    await container.start();
    await container.wait({
      condition: "removed"
    });
    console.log("Dependencies installed");
  } finally {
    await removeContainer(containerName).catch(() => {
    });
  }
}
__name(installPackageJson, "installPackageJson");

// libs/remote/src/program.ts
import ignore from "@balena/dockerignore";
import { program } from "commander";
import { DockerfileParser } from "dockerfile-ast";
import glob2 from "fast-glob";
import { existsSync as existsSync2 } from "fs";
import { readFile as readFile2 } from "fs/promises";
import ms from "ms";
import { join as join6 } from "path";
var cli = program.name("Serverize").version("1.0.0").description("Serverize").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command").requiredOption("-a, --app <app>", "The app name").option(
  "-f, --file",
  'Name of the Dockerfile (default:"$(pwd)/Dockerfile")',
  "Dockerfile"
);
function dfn() {
  const options = program.opts();
  return options["file"];
}
__name(dfn, "dfn");
function appName() {
  const options = program.opts();
  return options["app"];
}
__name(appName, "appName");
var dockerignorefileName = join6(process.cwd(), ".dockerignore");
var dockerfileName = join6(process.cwd(), dfn());
if (!existsSync2(dockerignorefileName)) {
  throw new Error("No .dockerignore file found");
}
if (!existsSync2(dockerfileName)) {
  throw new Error("No Dockerfile found");
}
var dockerignore = await readFile2(dockerignorefileName, "utf-8");
var dockerfile = await readFile2(dockerfileName, "utf-8");
async function toAst() {
  const ast2 = DockerfileParser.parse(dockerfile);
  const exposeInstructions = ast2.getInstructions().find((instruction) => instruction.getInstruction() === "EXPOSE");
  const copies = ast2.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    let path = srcArg.getValue();
    if (path === ".") {
      path = "./";
    }
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const filteredPaths = ignore({ ignorecase: true }).add(dockerignore).filter(
    await glob2(Array.from(paths), {
      cwd: process.cwd()
    })
  );
  const [healthCheck] = ast2.getHEALTHCHECKs();
  const healthCheckOptions = {};
  if (healthCheck) {
    const flags = healthCheck.getFlags();
    const keys = [
      {
        prop: "StartPeriod",
        flag: "start-period",
        format: /* @__PURE__ */ __name((value) => ms(value) * 1e5, "format")
      },
      {
        prop: "Retries",
        flag: "retries",
        format: /* @__PURE__ */ __name((value) => parseInt(value, 10), "format")
      },
      {
        prop: "Timeout",
        flag: "timeout",
        format: /* @__PURE__ */ __name((value) => ms(value) * 1e5, "format")
      },
      {
        prop: "Interval",
        flag: "interval",
        format: /* @__PURE__ */ __name((value) => ms(value) * 1e5, "format")
      }
    ];
    for (const { prop, flag, format } of keys) {
      const value = flags.find((it) => it.getName() === flag);
      if (value) {
        healthCheckOptions[prop] = format ? format(value.getValue()) : value.getValue();
      }
    }
    healthCheckOptions["Test"] = healthCheck.getRawArgumentsContent();
  }
  const exposedPort = exposeInstructions ? exposeInstructions.getArguments().map((it) => it.getValue())[0] : "";
  if (!exposedPort) {
    console.warn("No exposed port found, use 3000 as default");
  }
  return {
    healthCheckOptions: Object.keys(healthCheckOptions).length ? healthCheckOptions : void 0,
    paths: filteredPaths,
    expose: exposedPort || "3000"
  };
}
__name(toAst, "toAst");
var ast = await toAst();

// libs/remote/src/view-logs.ts
import debug2 from "debug";
import { map } from "rxjs";
import { webSocket } from "rxjs/webSocket";
import { WebSocket } from "ws";
var logger = debug2("serverize");
global.WebSocket = WebSocket;
var subject = webSocket({
  url: serverizeWs,
  closeObserver: {
    next: /* @__PURE__ */ __name(() => {
      process.exit(0);
    }, "next")
  }
});
var logs$ = subject.multiplex(
  () => ({
    command: "logs",
    apiKey: appName(),
    payload: { appName: appName() }
  }),
  () => ({
    command: "logs",
    apiKey: appName(),
    payload: { appName: appName(), complete: true }
  }),
  (message) => message.command === "logs"
).pipe(map((it) => it.payload));
var events = ["SIGINT", "SIGTERM", "unhandledRejection", "uncaughtException"];
events.forEach((event) => {
  process.on(event, () => {
    subject.complete();
    process.exit(1);
  });
});
function connectToRunnerServer() {
  const ws = new WebSocket(`${serverizeWs}?apiKey=${appName()}`);
  ws.on("open", () => {
    logger("Connected to runner server");
    ws.send(
      JSON.stringify({
        command: "logs",
        payload: {
          apiKey: appName()
        }
      })
    );
  });
  ws.on("message", (data) => {
    process.stdout.write(data.toString());
  });
  ws.on("close", () => {
    logger("Disconnected from source server");
    process.exit(0);
  });
}
__name(connectToRunnerServer, "connectToRunnerServer");

// libs/remote/src/deploy.ts
import { execSync } from "child_process";
import { watch } from "chokidar";
import { Command } from "commander";
import debug3 from "debug";
import { readFile as readFile3 } from "fs/promises";
import ora from "ora";
import { join as join7 } from "path";
import {
  Observable,
  debounceTime,
  exhaustMap,
  from,
  switchMap,
  tap as tap2
} from "rxjs";
import { createGzip } from "zlib";
var logger2 = debug3("serverize");
var spinner = ora({ prefixText: "\n\u2500 Serverize" });
var deploy_default = new Command("deploy").usage("npx serverize -a <appName> deploy ./Dockerfile").option("-w, --watch", "Watch for changes", false).action(async ({ watch: watch2 }) => {
  spinner.start(`Deploying (${appName()})...`);
  if (watch2) {
    logger2("using watch mode");
    connectToRunnerServer();
    watchFiles().subscribe({
      next: /* @__PURE__ */ __name((data) => {
        if (data.endsWith("-".repeat(4))) {
          spinner.info("Deployed. Watching for changes...");
          const subdomain = makeRunningContainerName(appName());
          console.log(
            box(
              `${appName()} Serverized`,
              `Accessible at https://${subdomain}.beta.january.sh`
            )
          );
        } else {
          process.stdout.write("\n");
          process.stdout.write(data.toString());
        }
      }, "next"),
      error: /* @__PURE__ */ __name((error) => {
        spinner.fail("Failed to send image");
        console.error(error);
      }, "error")
    });
  } else {
    sendImage().subscribe({
      // await readFiles(await getFiles(dockerfileName))
      complete: /* @__PURE__ */ __name(() => {
        spinner.succeed("Deployed successfully");
        const subdomain = makeRunningContainerName(appName());
        console.log(
          box(
            `${appName()} Deployed`,
            `Accessible at https://${subdomain}.beta.january.sh`,
            `Logs: npx serverize logs -a ${appName()}`
          )
        );
      }, "complete"),
      next: /* @__PURE__ */ __name((data) => {
        process.stdout.write("\n");
        process.stdout.write(data.toString());
      }, "next"),
      error: /* @__PURE__ */ __name((error) => {
        spinner.fail("Failed to send image");
        console.error(error);
      }, "error")
    });
  }
});
function createWatcher(files) {
  return new Observable((subscriber) => {
    const watcher = watch(files, {
      cwd: process.cwd(),
      persistent: true
    });
    watcher.on("all", async (event, path) => {
      subscriber.next(path);
    });
    watcher.on("error", (error) => {
      subscriber.error(error);
    });
    return () => {
      watcher.close();
    };
  });
}
__name(createWatcher, "createWatcher");
function readFiles(files) {
  return Promise.all(
    files.map(async (file) => ({
      path: file,
      content: await readFile3(join7(process.cwd(), file), "utf-8"),
      // FIXME: we should use the file size to determine if the file has changed
      // or we should use the file hash to determine if the file has changed
      hasChanged: true
    }))
  );
}
__name(readFiles, "readFiles");
function watchFiles() {
  logger2(`Watching files 
${ast.paths.join(", ")}
`);
  return createWatcher(ast.paths).pipe(
    debounceTime(1e3),
    // switchMap((filesToWatch) => readFiles(filesToWatch)),
    // filter((files) => files.some((it) => it.hasChanged)),
    exhaustMap(() => sendImage(true))
  );
}
__name(watchFiles, "watchFiles");
var bases4 = Buffer.from(
  JSON.stringify({
    port: parseInt(ast.expose, 10),
    Healthcheck: ast.healthCheckOptions
  })
).toString("base64");
function sendImage(quiet = false) {
  return from(saveImage(quiet)).pipe(
    tap2(() => tell("Uploading image...")),
    switchMap(
      (tar) => fetch(`${serverizeUrl}/upload`, {
        method: "POST",
        duplex: "half",
        body: tar,
        headers: {
          "x-docker": bases4,
          "Content-Type": "application/gzip",
          Apikey: appName()
        }
      })
    ),
    switchMap(async (response) => {
      if (!response.ok) {
        const error = await response.text();
        throw {
          status: response.statusText,
          message: error
        };
      }
      return response;
    }),
    switchMap(
      (response) => response.body.pipeThrough(new TextDecoderStream())
    )
  );
}
__name(sendImage, "sendImage");
async function saveImage(quiet = false) {
  tell("Building Docker image...");
  const runnerImageTag = makeRunningImageName(appName());
  const platforms = ["linux/amd64"];
  const options = [
    "--pull",
    "--rm",
    "-t",
    runnerImageTag,
    "-f",
    "Dockerfile",
    "--platform",
    platforms.join(","),
    "."
  ];
  if (quiet) {
    options.push("--quiet");
  }
  console.log("\n");
  printDivider();
  execSync(`docker build ${options.join(" ")}`, {
    cwd: process.cwd(),
    stdio: "inherit",
    env: {
      ...process.env,
      DOCKER_CLI_HINTS: "false",
      DOCKER_BUILDKIT: "1"
    }
  });
  printDivider();
  console.log("\n");
  return docker.getImage(runnerImageTag).get().then((x) => x.pipe(createGzip()));
}
__name(saveImage, "saveImage");
function printDivider(character = "\u2500") {
  const columns = process.stdout.columns || 80;
  const line = character.repeat(columns);
  console.log(line);
}
__name(printDivider, "printDivider");
function tell(message) {
  spinner.text = `${message}
`;
}
__name(tell, "tell");

// libs/remote/src/logs.ts
import { Command as Command2 } from "commander";
import debug4 from "debug";
import ora2 from "ora";
var logger3 = debug4("serverize");
var spinner2 = ora2({ prefixText: "\n\u2500 Serverize" });
var logs_default = new Command2("logs").usage("npx serverize logs -a <appName>").action(async () => {
  connectToRunnerServer();
});

// libs/remote/src/secrets.ts
import { Command as Command3 } from "commander";
import debug5 from "debug";
import { parse as parse2 } from "dotenv";
import { readFile as readFile4 } from "fs/promises";
import ora3 from "ora";
import { join as join8 } from "path";
var logger4 = debug5("serverize");
var spinner3 = ora3({ prefixText: "\n\u2500 Serverize" });
var setCommand = new Command3("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in the format NAME=VALUE").action(async (secretsList, s) => {
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error(`Secret "${secret}" must be in the format NAME=VALUE`);
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: appName()
      }
    });
  }
});
var setFileCommand = new Command3("set-file").usage("[options] ./remove.env").argument("<envFile>", "Path to the file with secrets").action(async (file) => {
  const secrets = Object.entries(
    parse2(await readFile4(join8(process.cwd(), file), "utf-8"))
  );
  for (const [name, value] of secrets) {
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: appName()
      }
    });
  }
});
var secrets_default = new Command3("secrets").addCommand(setCommand).addCommand(setFileCommand);

// libs/remote/src/cli.ts
cli.addCommand(deploy_default).addCommand(secrets_default).addCommand(logs_default).parse(process.argv);
//# sourceMappingURL=cli.js.map
