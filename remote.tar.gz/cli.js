#!/usr/bin/env node
import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// libs/remote/src/cli.ts
import { execSync } from "child_process";
import { watch } from "chokidar";
import { Command } from "commander";
import { parse } from "dotenv";
import { readFile as readFile2 } from "fs/promises";
import ora from "ora";
import { join as join2 } from "path";
import {
  Observable,
  debounceTime,
  exhaustMap,
  from,
  map,
  of,
  switchMap,
  tap as tap2
} from "rxjs";
import { WebSocket } from "ws";

// libs/console/src/lib/console.ts
import boxen from "boxen";
import glob from "fast-glob";
import ip from "ip";
function box(title, ...lines) {
  return boxen(lines.join("\n"), {
    padding: 0.75,
    margin: 1,
    borderStyle: "round",
    title,
    titleAlignment: "center",
    dimBorder: true
  });
}

// libs/docker/src/index.ts
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
function makeRunningImageName(projectId) {
  return `${projectId}-image:latest`;
}
function makeRunningContainerName(projectId) {
  return projectId;
}

// libs/docker/src/compose.ts
import yaml from "js-yaml";

// libs/modern/src/index.ts
import { tap } from "rxjs/operators";

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
function debug(tag, enabled = true) {
  const header = (value, error) => typeof tag === "string" ? tag : tag(value, error);
  return tap({
    next(value) {
      if (!enabled) return;
      console.log(
        `%c[${header(value, null)}: Next]`,
        "background: #009688; color: #fff; padding: 3px; font-size: 9px;",
        value
      );
    },
    error(error) {
      if (!enabled) return;
      console.log(
        `%c[${header(null, error)}: Error]`,
        "background: #E91E63; color: #fff; padding: 3px; font-size: 9px;",
        error
      );
    },
    complete() {
      if (!enabled) return;
      console.log(
        `%c[${header(null, null)}]: Complete`,
        "background: #00BCD4; color: #fff; padding: 3px; font-size: 9px;"
      );
    }
  });
}

// libs/docker/src/index.ts
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}

// libs/remote/src/program.ts
import ignore from "@balena/dockerignore";
import { program } from "commander";
import { DockerfileParser } from "dockerfile-ast";
import glob2 from "fast-glob";
import { existsSync } from "fs";
import { readFile } from "fs/promises";
import ms from "ms";
import { join } from "path";
var cli = program.name("Serverize").version("1.0.0").description("Serverize").helpOption("-h, --help", "Display help for command").helpCommand("help [command]", "Display help for command").requiredOption("-k, --api-key <key>", "API key for authentication").option(
  "-f, --file",
  'Name of the Dockerfile (default:"$(pwd)/Dockerfile")',
  "Dockerfile"
);
function dfn() {
  const options = program.opts();
  return options["file"];
}
function apiKey() {
  const options = program.opts();
  return options["apiKey"];
}
var dockerignorefileName = join(process.cwd(), ".dockerignore");
var dockerfileName = join(process.cwd(), dfn());
if (!existsSync(dockerignorefileName)) {
  throw new Error("No .dockerignore file found");
}
if (!existsSync(dockerfileName)) {
  throw new Error("No Dockerfile found");
}
var dockerignore = await readFile(dockerignorefileName, "utf-8");
var dockerfile = await readFile(dockerfileName, "utf-8");
async function toAst() {
  const ast2 = DockerfileParser.parse(dockerfile);
  const exposeInstructions = ast2.getInstructions().find((instruction) => instruction.getInstruction() === "EXPOSE");
  const copies = ast2.getCOPYs();
  const paths = /* @__PURE__ */ new Set();
  for (const copy of copies) {
    if (copy.getFlags().length) continue;
    const [srcArg] = copy.getArguments();
    let path = srcArg.getValue();
    if (path === ".") {
      path = "./";
    }
    paths.add(!path.endsWith("/") ? path : path + "**");
  }
  const filteredPaths = ignore({ ignorecase: true }).add(dockerignore).filter(
    await glob2(Array.from(paths), {
      cwd: process.cwd()
    })
  );
  const [healthCheck] = ast2.getHEALTHCHECKs();
  const healthCheckOptions = {};
  if (healthCheck) {
    const flags = healthCheck.getFlags();
    const keys = [
      {
        prop: "StartPeriod",
        flag: "start-period",
        format: (value) => ms(value) * 1e5
      },
      {
        prop: "Retries",
        flag: "retries",
        format: (value) => parseInt(value, 10)
      },
      {
        prop: "Timeout",
        flag: "timeout",
        format: (value) => ms(value) * 1e5
      },
      {
        prop: "Interval",
        flag: "interval",
        format: (value) => ms(value) * 1e5
      }
    ];
    for (const { prop, flag, format } of keys) {
      const value = flags.find((it) => it.getName() === flag);
      if (value) {
        healthCheckOptions[prop] = format ? format(value.getValue()) : value.getValue();
      }
    }
    healthCheckOptions["Test"] = healthCheck.getRawArgumentsContent();
  }
  const exposedPort = exposeInstructions ? exposeInstructions.getArguments().map((it) => it.getValue())[0] : "";
  if (!exposedPort) {
    console.warn("No exposed port found, use 3000 as default");
  }
  return {
    healthCheckOptions: Object.keys(healthCheckOptions).length ? healthCheckOptions : void 0,
    paths: filteredPaths,
    expose: exposedPort || "3000"
  };
}
var ast = await toAst();

// libs/remote/src/cli.ts
var spinner = ora();
var setCommand = new Command("set").usage("[options] NAME=VALUE NAME=VALUE ...").argument("<secrets...>", "Secrets in the format NAME=VALUE").action(async (secretsList, s) => {
  for (const secret of secretsList) {
    const [name, value] = secret.split("=");
    if (!name && !value) {
      throw new Error(`Secret "${secret}" must be in the format NAME=VALUE`);
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: apiKey()
      }
    });
  }
});
var setFileCommand = new Command("set-file").usage("[options] ./remove.env").argument("<envFile>", "Path to the file with secrets").action(async (file) => {
  const secrets = Object.entries(
    parse(await readFile2(join2(process.cwd(), file), "utf-8"))
  );
  for (const [name, value] of secrets) {
    if (!name && !value) {
      throw new Error("Secret must be in the format NAME=VALUE");
    }
    if (name && !value) {
      throw new Error(`Secret ${name} is missing value`);
    }
    await fetch(`${serverizeUrl}/set-secrets`, {
      method: "POST",
      body: JSON.stringify({
        secretLabel: name,
        secretValue: value
      }),
      headers: {
        "Content-Type": "application/json",
        Apikey: apiKey()
      }
    });
  }
});
var deployCommand = new Command("deploy").usage("npx @january/remote deploy ./Dockerfile").option("-w, --watch", "Watch for changes", false).action(async ({ watch: watch2 }) => {
  if (watch2) {
    connectToRunnerServer();
    watchFiles().subscribe({
      next: () => {
        spinner.succeed("Image sent successfully. Watching for changes...");
        const subdomain = makeRunningContainerName(apiKey());
        box(`Access your server at https://${subdomain}.beta.january.sh`);
      },
      error: (error) => {
        spinner.fail("Failed to send image");
        console.error(error);
      }
    });
  } else {
    spinner.start("Reading files...");
    sendImage().subscribe({
      // await readFiles(await getFiles(dockerfileName))
      next: (data) => {
        process.stdout.write(data.toString());
        spinner.succeed("Deployed successfully");
        const subdomain = makeRunningContainerName(apiKey());
        box(`Access your server at https://${subdomain}.beta.january.sh`);
      },
      error: (error) => {
        spinner.fail("Failed to send image");
        console.error(error);
      }
    });
  }
});
var secretCommand = new Command("secrets").addCommand(setCommand).addCommand(setFileCommand);
cli.addCommand(deployCommand).addCommand(secretCommand).parse(process.argv);
function createWatcher(files) {
  return new Observable((subscriber) => {
    const watcher = watch(files, {
      cwd: process.cwd(),
      persistent: true
    });
    watcher.on("all", async (event, path) => {
      subscriber.next(path);
    });
    watcher.on("error", (error) => {
      subscriber.error(error);
    });
    return () => {
      watcher.close();
    };
  });
}
function watchFiles() {
  console.log(`Watching files 
${ast.paths.join(", ")}
`);
  return of(ast.paths).pipe(
    switchMap((files) => createWatcher(files).pipe(map(() => files))),
    debounceTime(1e3),
    // switchMap((filesToWatch) => readFiles(filesToWatch)),
    // filter((files) => files.some((it) => it.hasChanged)),
    debug("sending image"),
    exhaustMap(() => sendImage(true))
  );
}
var bases4 = Buffer.from(
  JSON.stringify({
    port: parseInt(ast.expose, 10),
    Healthcheck: ast.healthCheckOptions
  })
).toString("base64");
function sendImage(quiet = false) {
  return from(saveImage(quiet)).pipe(
    tap2(() => spinner.text = "Uploading image..."),
    switchMap(
      (tar) => fetch(`${serverizeUrl}/upload`, {
        method: "POST",
        duplex: "half",
        body: tar,
        headers: {
          "x-docker": bases4,
          "Content-Type": "application/x-tar",
          Apikey: apiKey()
        }
      })
    ),
    tap2((response) => {
      if (!response.ok) {
        throw new Error(response.statusText);
      }
    }),
    switchMap(
      (response) => response.body.pipeThrough(new TextDecoderStream())
    )
  );
}
async function saveImage(quiet = false) {
  spinner.text = "Building Docker image...";
  const runnerImageTag = makeRunningImageName(apiKey());
  const platforms = ["linux/amd64"];
  const options = [
    "--pull",
    "--rm",
    "-t",
    runnerImageTag,
    "-f",
    "Dockerfile",
    "--platform",
    platforms.join(","),
    "."
  ];
  if (quiet) {
    options.push("--quiet");
  }
  execSync(`docker build ${options.join(" ")}`, {
    cwd: process.cwd(),
    stdio: "inherit"
  });
  const image = docker.getImage(runnerImageTag);
  return image.get();
}
function connectToRunnerServer() {
  const ws = new WebSocket(`${serverizeWs}?apiKey=${apiKey()}`);
  ws.on("open", () => {
    console.log("Connected to runner server");
    ws.send(
      JSON.stringify({
        command: "logs",
        payload: {
          apiKey: apiKey()
        }
      })
    );
  });
  ws.on("message", (data) => {
    process.stdout.write(data.toString());
  });
  ws.on("close", () => {
    console.log("Disconnected from source server");
    process.exit(0);
  });
}
//# sourceMappingURL=cli.js.map
