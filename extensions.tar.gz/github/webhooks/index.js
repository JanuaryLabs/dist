var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/extensions/src/github/webhooks/receive-webhook.txt
var receive_webhook_default = "import {\n  EmitterWebhookEvent,\n  EmitterWebhookEventName,\n  Webhooks,\n  createNodeMiddleware,\n} from '@octokit/webhooks';\nimport { IncomingMessage, ServerResponse } from 'node:http';\n\nconst webhooks = new Webhooks({\n  secret: process.env.WEBHOOK_SECRET,\n  log: console,\n});\n\nexport function isEventOfType<T extends EmitterWebhookEventName>(\n  event: EmitterWebhookEvent,\n  ...types: T[]\n): event is EmitterWebhookEvent<T> {\n  const eventName =\n    'action' in event.payload\n      ? `${event.name}.${event.payload.action}`\n      : event.name;\n  return types.includes(eventName as T);\n}\n\n\nexport function onGithubEvent<EventName extends EmitterWebhookEventName>(\n  event: EventName,\n  ...middlewares: ((\n    event: EmitterWebhookEvent<EventName>,\n  ) => boolean | void | Promise<boolean | void>)[]\n) {\n  webhooks.on(event, async (event) => {\n    for (const middleware of middlewares) {\n      let canContinue = await middleware(event);\n      if (canContinue === false) {\n        break;\n      }\n    }\n  });\n}\n\nexport async function receiveGithubEvents(\n  request: IncomingMessage,\n  response: ServerResponse<IncomingMessage>,\n  path: string,\n) {\n  let body = '';\n  let statusCode = 200;\n  let headers = {};\n\n  const orignalEnd = response.end;\n  const originalWriteHead = response.writeHead;\n\n  response.end = function (...args: any[]) {\n    body = args[0];\n    return this;\n  };\n\n  response.writeHead = function (...args: any[]) {\n    statusCode = args[0];\n    headers = args[1];\n    return this;\n  };\n\n  Object.defineProperty(response, 'statusCode', {\n    set: function (value) {\n      statusCode = value;\n    },\n  });\n\n  const handler = createNodeMiddleware(webhooks, {\n    path,\n    log: console,\n  });\n\n  const processed = await handler(request, response);\n\n  response.end = orignalEnd;\n  response.writeHead = originalWriteHead;\n\n  return {\n    processed,\n    body,\n    statusCode,\n    headers,\n  };\n}\n";

// libs/extensions/src/github/webhooks/webhook-handler.txt
var webhook_handler_default = "import { Hono } from 'hono';\nimport type { StatusCode } from 'hono/utils/http-status';\nimport type { IncomingMessage, ServerResponse } from 'node:http';\nimport { receiveGithubEvents } from '../../core/github-webhooks';\n\nconst router = new Hono();\n\nrouter.post('/github/webhooks', async (context, next) => {\n  const nodeContext = context.env as {\n    incoming: IncomingMessage;\n    outgoing: ServerResponse<IncomingMessage>;\n  };\n\n  const { processed, body, headers, statusCode } = await receiveGithubEvents(\n    nodeContext.incoming,\n    nodeContext.outgoing,\n    '/integrations/github/webhooks',\n  );\n  if (!processed) {\n    // github middleware did not process the request due to\n    // path mismatch which is unlikely to happen given we control the path\n    return context.body('', 400);\n  }\n  return context.body(body, statusCode as StatusCode, headers);\n});\n\nexport default ['/integrations', router] as const;\n";

// libs/extensions/src/github/webhooks/index.ts
import { Project as Project4, SyntaxKind as SyntaxKind4 } from "ts-morph";

// libs/compiler/generator/src/index.ts
import { isFunction } from "lodash-es";
import {
  Project as Project3,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "node:path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function addLeadingSlash(path) {
  return normalize(join("/", path));
}

// libs/compiler/generator/src/lib/project-fs.ts
import { join as join2 } from "node:path";
import { Injectable, ServiceLifetime } from "tiny-injector";
var config = {
  basePath: "./src/app",
  extensions: "./src/app/extensions",
  features: "./src/app/features",
  entities: "./src/app/entities"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.entities + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join2("#{relative}", config.basePath, importPath);
  };
  makeEntityImportSpecifier = (tableName) => {
    return join2("#{entity}", pascalcase(tableName));
  };
  makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join2(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join2(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join2(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeQueryPath = (tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectFS);
var commandsGlob = () => {
  return `${config.features}/**/*.command.ts`;
};
var routersGlob = () => {
  return "/**/*.router.ts";
};
var listenersGlob = () => {
  return "/**/*.github.ts";
};
var cronsGlob = () => {
  return "/**/*.cron.ts";
};
var entitiesGlob = () => {
  return "/**/*.entity.ts";
};
var makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
var makeEntityImportSpecifier = (tableName) => {
  return join2("#{entity}", pascalcase(tableName));
};
var makeControllerPath = (featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
);
var makeFeaturePath = (fileName) => join2(config.features, fileName);

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project, SyntaxKind, VariableDeclarationKind } from "ts-morph";

// libs/compiler/generator/src/lib/sourcecode.ts
import { basename, dirname, extname, join as join3, relative, sep } from "node:path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project2,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project2(options);
}
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join3(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
        case moduleSpecifier.startsWith("#{entity}"): {
          const entityName = moduleSpecifier.replace("#{entity}/", "");
          const files = __privateGet(this, _morphProject).getSourceFiles(
            join3(__privateGet(this, _outputDir), entitiesGlob())
          );
          const filePath = __privateMethod(this, _VirtualProject_instances, findClassSourceFile_fn).call(this, files, entityName);
          if (!filePath) {
            throw new Error(`Entity ${entityName} file not found.`);
          }
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(`${moduleSpecifier}.ts`);
          break;
        }
      }
    }
  }
};
findClassSourceFile_fn = function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
};
exportsDir_fn = function(dir) {
  const fullPath = join3(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportsCommands_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join3(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
};
exportRoutes_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { type HonoEnv } from '@workspace/utils';import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono<HonoEnv>][]`,
    { overwrite: true }
  );
};
exportListeners_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportJobs_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportEntities_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from '../${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities= [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
};
tuneImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport || it.namespaceImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: false,
        namespaceImport: it.namespaceImport
      });
    }
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: true
      });
    }
  });
};
removeUnusedImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).filter((it) => !it.getAncestors().includes(importDeclaration)).some((it) => it.getText() === importedName);
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
};
moveImportsToTop_fn = function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index) => {
    file.insertImportDeclaration(index, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText(),
        isTypeOnly: namedImport.isTypeOnly()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
};
VirtualProject = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}

// libs/compiler/generator/src/index.ts
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${typeof arg === "undefined" ? "" : arg})`;
  const guard = transferable.toString();
  const project = new Project3({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const subjectIdentifierText = "subject";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind3.ArrowFunction);
  let subjectUsed = false;
  const [config2] = guardFunction.getParameters();
  if (config2) {
    const name = config2.getNameNode();
    if (name.isKind(SyntaxKind3.ObjectBindingPattern)) {
      const properties = name.getElements();
      subjectUsed = properties.some(
        (prop) => prop.getName() === subjectIdentifierText
      );
    }
  }
  const inputs = /* @__PURE__ */ new Map();
  const parameters = guardFunction.getParameters();
  for (const [key, value] of Object.entries(options.inputs ?? {})) {
    if (isFunction(value)) {
      const result = value(parameters, subjectUsed);
      if (result) {
        inputs.set(key, result);
      }
    } else {
      inputs.set(key, value);
    }
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind3.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind3.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind3.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind2.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!parent) {
      const triggerInput = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      inputs.set("trigger", triggerInput);
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind3.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind3.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind3.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs.set(v, {
      // TODO: do we still use "input"?
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()",
        source: "internal"
      }
    });
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = (ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind3.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  };
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind3.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  const atLeastOneOutputReturn = returns.some(isOutputReturn);
  if (!atLeastOneOutputReturn) {
    for (const ret of returns) {
      if (isOutputReturn(ret)) {
        continue;
      }
      const isReturningCall = ret.getExpressionIfKind(
        SyntaxKind3.CallExpression
      );
      let returnValue = ret.getText().trim().replace("return ", "");
      if (returnValue.endsWith(";")) {
        returnValue = returnValue.slice(0, -1);
      }
      if (returnValue === "return") {
        ret.replaceWithText(options.setOutput());
      } else {
        ret.replaceWithText(
          options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
        );
      }
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs: Object.fromEntries(inputs)
  };
}

// libs/extensions/src/github/webhooks/index.ts
var webhooks = {
  id: "github/webhooks",
  packages: {
    "@octokit/webhooks": {
      version: "^13.3.0",
      dev: false
    }
  },
  files: {
    [makeControllerPath("integrations", "router")]: webhook_handler_default,
    "src/core/github-webhooks.ts": receive_webhook_default
  },
  primitives: {
    policy: {
      github(config2) {
        if (!config2.events || !config2.events.length || !config2.guard) {
          return () => "";
        }
        const project = new Project4({
          useInMemoryFileSystem: true
        });
        let body = "return true";
        if (config2.guard) {
          const guard = config2.guard.toString();
          const sourceFile = project.createSourceFile(
            "guard.ts",
            `const guard = ${guard}`
          );
          const guardFunction = sourceFile.getVariableDeclarationOrThrow("guard").getInitializerOrThrow();
          const isBlock = guardFunction.getBody().isKind(SyntaxKind4.Block);
          body = isBlock ? guardFunction.getBodyText() : `return ${guardFunction.getBodyText()}`;
        }
        return (name) => `
    import { EmitterWebhookEvent } from '@octokit/webhooks';
    import { isEventOfType } from '../core/github-webhooks';

    export async function ${name}(event: EmitterWebhookEvent) {
      if(isEventOfType(event, ${(config2.events ?? []).map((it) => `'${it}'`).join(", ")})) {
        ${body}
      }
      return false;

  }`;
      }
    },
    trigger: {
      github(config2) {
        return {
          type: "github-trigger",
          config: config2,
          policies: config2.policies ?? [],
          refineExecute: (execute) => {
            return refineExecute(execute, {
              replaceKey: (key) => key
            });
          }
        };
      }
    }
  }
};
export {
  webhooks
};
//# sourceMappingURL=index.js.map
