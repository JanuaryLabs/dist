// libs/extensions/src/index.ts
import { mkdir, writeFile } from "fs/promises";
import yaml from "js-yaml";
import { dirname, isAbsolute, join } from "path";

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "prettierignore":
      case "toml":
      case "env":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? "" : formatCode(code, "ts", true);
      }
    }
    throw error;
  }
}

// libs/compiler/generator/utils/src/index.ts
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const ext = fileName.split(".").pop();
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};

// libs/extensions/fly/src/index.ts
var FlyExtension = class {
  composeService() {
    return {
      api: {
        image: "node:lts",
        build: {
          context: ".",
          dockerfile: "Dockerfile"
        },
        networks: ["development"],
        restart: "unless-stopped",
        command: "node --watch /app/build/server.js",
        develop: {
          watch: [
            {
              action: "sync",
              path: "./output/build/server.js",
              target: "/app/build/server.js",
              ignore: ["node_modules/"]
            },
            {
              action: "rebuild",
              path: "./output/package.json"
            }
          ]
        },
        env_file: [".env"],
        ports: ["3000:3000", "9229:9229"],
        depends_on: ["database"]
      }
    };
  }
  env() {
    return {
      PORT: "3000"
    };
  }
};

// libs/extensions/postgresql/src/index.ts
var PostgreSQLExtension = class {
  composeService() {
    return {
      database: {
        image: "postgres:16",
        ports: ["5432:5432"],
        volumes: ["postgres_data:/var/lib/postgresql/data"],
        networks: ["development"],
        environment: {
          POSTGRES_PASSWORD: "yourpassword",
          POSTGRES_USER: "youruser",
          POSTGRES_DB: "yourdatabase"
        }
      },
      pgadmin: {
        image: "dpage/pgadmin4",
        ports: ["8080:8080"],
        networks: ["development"],
        environment: {
          PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
          PGADMIN_DEFAULT_PASSWORD: "password"
        }
      }
    };
  }
  env() {
    return {
      CONNECTION_STRING: "postgresql://youruser:yourpassword@database:5432/yourdatabase"
    };
  }
};

// libs/extensions/src/index.ts
function run(ext) {
  console.log(ext);
  const services = ext.reduce(
    (acc, it) => {
      const services2 = it.composeService();
      const networks = Object.entries(services2).map(([, { networks: networks2 }]) => networks2 ?? []).flat().filter(Boolean);
      const volumes = Object.entries(services2).map(([, { volumes: volumes2 }]) => volumes2 ?? []).flat().map((it2) => it2.split(":")[0]).filter(Boolean);
      return {
        ...acc,
        services: {
          ...acc.services,
          ...services2
        },
        volumes: {
          ...acc.volumes,
          ...Object.fromEntries(volumes.map((it2) => [it2, {}]))
        },
        networks: {
          ...acc.networks,
          ...Object.fromEntries(networks.map((it2) => [it2, {}]))
        }
      };
    },
    {
      services: {},
      volumes: {},
      networks: {}
    }
  );
  const env = ext.reduce((acc, it) => {
    return {
      ...acc,
      ...it.env()
    };
  }, {});
  writeFiles(process.cwd(), {
    "compose.dev.yml": yaml.dump(services, {
      skipInvalid: false,
      noRefs: true,
      forceQuotes: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }),
    ".env": Object.entries({
      ...env,
      ...{
        NODE_ENV: "development"
      }
    }).map(([key, value]) => `${key}=${value}`).join("\n")
  });
}
async function writeFiles(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join(dir, file);
    await mkdir(dirname(filePath), { recursive: true });
    await writeFile(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}
export {
  FlyExtension,
  PostgreSQLExtension,
  run,
  writeFiles
};
