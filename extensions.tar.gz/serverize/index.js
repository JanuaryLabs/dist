// libs/extensions/src/serverize/index.ts
import dedent from "dedent";
import yaml from "js-yaml";
var deployContent = (withBuild) => {
  const buildSteps = [
    {
      id: "setup_node",
      uses: "actions/setup-node@v4",
      name: "Setup Node.js",
      with: {
        "node-version": "20",
        cache: "npm"
      }
    },
    {
      id: "cache_deps",
      name: "Cache Or Restore Node Modules.",
      uses: "actions/cache@v3",
      with: {
        path: "node_modules",
        key: "${{ runner.os }}-node-${{ hashFiles('package-lock.json') }}"
      }
    },
    {
      id: "install_deps",
      name: "Install project dependencies.",
      run: "npm install --no-audit --no-fund",
      if: `steps.cache_deps.outputs.cache-hit != 'true'`
    },
    {
      name: "Build",
      run: "npm run build"
    }
  ];
  return yaml.dump(
    {
      name: "Deploy To Serverize",
      on: {
        push: {
          branches: ["main"]
        },
        workflow_dispatch: {}
      },
      concurrency: {
        group: "${{ github.workflow }}-${{ github.event.pull_request.number || github.ref }}",
        "cancel-in-progress": true
      },
      jobs: {
        deploy_serverize: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v4"
            },
            ...withBuild ? buildSteps : [],
            {
              id: "deploy",
              name: "Deploying...",
              run: `npx serverize deploy -f Dockerfile.serverize`,
              env: {
                SERVERIZE_API_TOKEN: `\${{ secrets.SERVERIZE_API_TOKEN }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
};
var serverize = (options = { runBuildInDocker: true }) => {
  options.runBuildInDocker = options.runBuildInDocker ?? true;
  const installCommand = [
    "npm ci",
    options.runBuildInDocker ? "--omit=dev" : "",
    "--no-audit",
    "--no-fund",
    "--legacy-peer-deps"
  ].join(" ");
  return {
    packages: {},
    files: {
      "../.github/workflows/deploy-serverize.yml": {
        ignoreIfExists: true,
        content: deployContent(!options.runBuildInDocker)
      },
      // '../.dockerignore': nodejs.dockerignore.join('\n'),
      "../Dockerfile.serverize": {
        ignoreIfExists: true,
        content: dedent`
FROM node:lts-alpine AS base

FROM base AS devdeps
WORKDIR /temp/dev
COPY package.json ./
RUN npm install

FROM base AS builder
WORKDIR /app
COPY --from=devdeps /temp/dev/node_modules node_modules
COPY . .
RUN npm run build

FROM base AS proddeps
WORKDIR /temp/prod
COPY --from=devdeps /temp/dev/node_modules node_modules
COPY --from=builder /app/output/package.json ./package.json
RUN npm install --omit=dev --legacy-peer-deps

FROM base AS start
WORKDIR /app

COPY --from=proddeps /temp/prod/node_modules ./node_modules
COPY --from=builder /app/output/build/ ./build/

RUN mkdir -p /app/db
RUN chown -R node:node /app/db

ENV NODE_ENV=production
ENV PORT=3000
ENV HOST=0.0.0.0
USER node
EXPOSE 3000

CMD ["node", "build/server.js"]
    `
      },
      "src/server.ts": {
        ignoreIfExists: true,
        content: `
      import { serve } from '@hono/node-server';
import { serveStatic } from '@hono/node-server/serve-static';
import { showRoutes } from 'hono/dev';
import { relative } from 'node:path';

import application from './app';
import './startup.ts';

const dirRelativeToCwd = relative(process.cwd(), import.meta.dirname);

  application.use(
    '/:filename{.+\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

const port = parseInt(process.env.PORT ?? '3000', 10);
serve({
  fetch: application.fetch,
  port: port,
});

if (process.env.NODE_ENV === 'development') {
  showRoutes(application, { verbose: true });
}
`
      }
    }
  };
};
export {
  serverize
};
//# sourceMappingURL=index.js.map
