// libs/extensions/src/vercel/index.ts
import yaml from "js-yaml";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toJson(obj) {
  return JSON.stringify(obj, null, 2);
}

// libs/extensions/src/vercel/index.ts
var deployContent = () => {
  return yaml.dump(
    {
      name: "Deploy To Vercel",
      on: {
        push: {
          branches: ["main"]
        },
        workflow_dispatch: {}
      },
      env: {
        VERCEL_ORG_ID: `\${{ secrets.VERCEL_ORG_ID }}`,
        VERCEL_PROJECT_ID: `\${{ secrets.VERCEL_PROJECT_ID }}`
      },
      jobs: {
        deploy_to_vercel: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            {
              id: "setup_node",
              uses: "actions/setup-node@v3",
              name: "Setup Node.js",
              with: {
                "node-version": "20",
                cache: "npm"
              }
            },
            {
              name: "Install Vercel CLI",
              run: "npm install --global vercel@latest --no-audit --no-fund"
            },
            {
              name: "Pull Vercel Environment Information",
              run: `vercel pull --yes --environment=production --token=\${{ secrets.VERCEL_API_TOKEN }}`
            },
            {
              name: "Build Project Artifacts",
              run: `vercel build --prod --token=\${{ secrets.VERCEL_API_TOKEN }}`
            },
            {
              name: "Deploy Project Artifacts to Vercel",
              run: `vercel deploy --prebuilt --prod --token=\${{ secrets.VERCEL_API_TOKEN }}`
            }
          ]
        }
      }
    },
    {
      lineWidth: -1,
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
};
var vercel = {
  packages: {},
  files: {
    "../.github/workflows/deploy.yml": deployContent(),
    "../vercel.json": toJson({
      $schema: "https://openapi.vercel.sh/vercel.json",
      version: 2,
      installCommand: "npm install --omit=dev --no-audit --no-fund",
      buildCommand: "npm run build:remote",
      devCommand: "npm start",
      outputDirectory: "",
      builds: [
        {
          src: "build/server.js",
          use: "@vercel/node"
        }
      ],
      routes: [
        {
          src: "/(.*)",
          dest: "/build/server.js"
        }
      ]
    }),
    "src/server.ts": `
import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import application from './app';
import { relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { showRoutes } from 'hono/dev'
import ip from 'ip';
import boxen from 'boxen';
import glob from 'fast-glob';
import { pretty } from '@january/console';

import { handle } from '@hono/node-server/vercel'

  const dirRelativeToCwd = relative(process.cwd(), import.meta.dirname);

  application.use(
    '/:filename{.+\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

  application.use('/:filename{.+\\.swagger\\.json$}', serveStatic({
    root: dirRelativeToCwd,
    rewriteRequestPath: (path) => path.split('/').pop() as string,
  }));

const port = parseInt(process.env.PORT ?? '3000', 10)
serve({
  fetch: application.fetch,
  port: port,
});

if(process.env.NODE_ENV === 'development'){
  showRoutes(application, { verbose: true });
}

pretty.network(port);
pretty.swagger('*.swagger.json', import.meta.dirname)

export default handle(application);
`
  }
};
export {
  vercel
};
//# sourceMappingURL=index.js.map
