export declare class PostgreSQLExtension {
    composeService(): {
        database: {
            image: string;
            ports: string[];
            volumes: string[];
            networks: string[];
            environment: {
                POSTGRES_PASSWORD: string;
                POSTGRES_USER: string;
                POSTGRES_DB: string;
            };
        };
        pgadmin: {
            image: string;
            ports: string[];
            networks: string[];
            environment: {
                PGADMIN_DEFAULT_EMAIL: string;
                PGADMIN_DEFAULT_PASSWORD: string;
            };
        };
    };
    env(): {
        CONNECTION_STRING: string;
    };
}
