import type { ProjectFS } from '@faslh/compiler/sdk/devkit';
export declare class HonoExtension {
    setup(fs: ProjectFS): {
        filePath: string;
        content: string[];
    }[];
}
