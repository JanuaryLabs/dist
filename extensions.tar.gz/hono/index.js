var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

// libs/extensions/src/hono/hono.txt
var hono_default = "import type { trigger } from '@january/declarative';\nimport type { Context } from 'hono';\nimport { createMiddleware } from 'hono/factory';\nimport { type RedirectStatusCode } from 'hono/utils/http-status';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nexport const consume = (contentType: string) => {\n  return createMiddleware(async (context, next) => {\n    const clientContentType = context.req.header('Content-Type');\n    if (clientContentType !== contentType) {\n      throw new ProblemDetailsException({\n        title: 'Unsupported Media Type',\n        status: 415,\n        detail: `Expected content type: ${contentType}, but got: ${clientContentType}`,\n      });\n    }\n    await next();\n  });\n};\n\nexport function createOutput(\n  context: Context,\n): trigger.http.outputWithFinalizer {\n  let result: Response;\n  return {\n    raw: (value: any) => {\n			result = value;\n		},\n    nocontent() {\n      result = context.body(null, 204);\n    },\n    ok(value?: unknown) {\n      if (value === undefined || value === null) {\n        result = context.body(null, 204);\n      } else {\n        result = context.json(value, 200);\n      }\n    },\n    created(valueOrUri: unknown, value?: unknown) {\n      if (typeof valueOrUri === 'string') {\n        if (value) {\n          result = context.json(value, 201, {\n            Location: valueOrUri,\n          });\n        } else {\n          result = context.body(null, 201, {\n            Location: valueOrUri,\n          });\n        }\n      } else {\n        result = context.json(valueOrUri!, 201);\n      }\n    },\n    redirect(uri: string | URL, statusCode?: unknown) {\n      result = context.redirect(\n        uri.toString(),\n        (statusCode as RedirectStatusCode) ?? undefined,\n      );\n    },\n    finalize() {\n      return result;\n    },\n  };\n}\n";

// libs/extensions/src/hono/setup.txt
var setup_default = "import './features/crons';\nimport './features/listeners';\nimport { Hono } from 'hono';\nimport { cors } from 'hono/cors';\nimport { logger } from 'hono/logger';\nimport { timing } from 'hono/timing';\nimport { type StatusCode } from 'hono/utils/http-status';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nimport { loadSubject } from '#core/identity/subject.ts';\nimport { type HonoEnv } from '#core/utils.ts';\nimport routes from './features/routes';\n\nconst application = new Hono<HonoEnv>();\napplication.use(timing(), cors(), logger()).use(async (context, next) => {\n	const subject = await loadSubject(context.req.header('Authorization'));\n	context.set('subject', subject);\n	await next();\n});\n\napplication.notFound(() => {\n	throw new ProblemDetailsException({\n		title: 'Not Found',\n		status: 404,\n		detail: 'The requested resource could not be found',\n	});\n});\n\napplication.onError((err, context) => {\n	console.error(err);\n\n	if (err instanceof ProblemDetailsException) {\n		context.status((err.Details.status as StatusCode) ?? 500);\n		return context.json(err.Details);\n	}\n\n	context.status(500);\n	return context.json({\n		title: 'Internal Server Error',\n		status: 500,\n		detail: 'An unexpected error occurred',\n	});\n});\n\nroutes.forEach(([path, route]) => {\n	application.route(path, route);\n});\n\nexport default application;\n";

// libs/extensions/src/hono/zod.txt
var zod_default = "import { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { z } from 'zod';\n\nexport function parse<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: unknown,\n) {\n  const result = schema.safeParse(input);\n  if (!result.success) {\n    const errors = result.error.flatten((issue) => ({\n      message: issue.message,\n      code: issue.code,\n      fatel: issue.fatal,\n      path: issue.path.join('.'),\n    })).fieldErrors;\n    return [null, errors];\n  }\n  return [result.data, null];\n}\n\nexport function parseOrThrow<T extends z.ZodRawShape>(\n  schema: z.ZodObject<T>,\n  input: unknown,\n): z.infer<z.ZodObject<T>> {\n  const [data, errors] = parse(schema, input);\n  if (errors) {\n    const exception = new ProblemDetailsException({\n      type: 'validation-failed',\n      status: 400,\n      title: 'Bad Request.',\n      detail: 'Validation failed.',\n    });\n    exception.Details.errors = errors;\n    throw exception;\n  }\n  return data as z.infer<z.ZodObject<T>>;\n}\n";

// libs/extensions/src/hono/index.ts
import { join as join4 } from "node:path";

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "node:path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}

// libs/compiler/contracts/src/contract.ts
var Contracts;
((Contracts2) => {
  function fffffff(input) {
    const [namespace, value] = input.split(":");
    return {
      namespace,
      value
    };
  }
})(Contracts || (Contracts = {}));
function nonStatic(inputs) {
  return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
function standaloneInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique = uniquify(
    Object.entries(inputs).filter(
      ([name, prop]) => prop.data?.["standalone"] && predicate([name, prop])
    ),
    ([name, prop]) => paramName([name, prop])
  );
  return unique.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
function nonStaticInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique = uniquify(
    nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])),
    ([name, prop]) => paramName([name, prop])
  );
  return unique.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
function paramName([name, prop]) {
  return prop.data?.["parameterName"] || name;
}

// libs/compiler/generator/src/index.ts
import { isFunction } from "lodash-es";
import {
  Project as Project4,
  StructureKind as StructureKind2,
  SyntaxKind as SyntaxKind3
} from "ts-morph";

// libs/compiler/generator/src/lib/output-analyser.ts
import { Project as Project2, SyntaxKind, VariableDeclarationKind as VariableDeclarationKind2 } from "ts-morph";

// libs/compiler/generator/src/lib/sourcecode.ts
import { basename, dirname, extname, join as join3, relative, sep } from "node:path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
import {
  ModuleKind,
  ModuleResolutionKind,
  Project as Project3,
  ScriptTarget,
  StructureKind,
  SyntaxKind as SyntaxKind2
} from "ts-morph";

// libs/compiler/generator/src/lib/project-fs.ts
import { join as join2 } from "node:path";
import { Injectable, ServiceLifetime } from "tiny-injector";
var config = {
  basePath: "./src/app",
  extensions: "./src/app/extensions",
  features: "./src/app/features",
  entities: "./src/app/entities"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join2(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join2(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join2(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join2(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join2(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join2(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join2("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeQueryPath = (tableName, queryName) => join2(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectFS);
var commandsGlob = () => {
  return `${config.features}/**/*.command.ts`;
};
var routersGlob = () => {
  return "/**/*.router.ts";
};
var listenersGlob = () => {
  return "/**/*.github.ts";
};
var cronsGlob = () => {
  return "/**/*.cron.ts";
};
var entitiesGlob = () => {
  return "/**/*.entity.ts";
};
var makeFeatureFile = (featureName, fileName) => join2(config.features, spinalcase2(featureName), fileName);
var makeControllerPath = (featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
);
var makeFeaturePath = (fileName) => join2(config.features, fileName);

// libs/compiler/generator/src/lib/sourcecode.ts
var tsConfig = {
  compilerOptions: {
    sourceMap: true,
    target: "ESNext",
    module: "esnext",
    moduleResolution: "node",
    declaration: false,
    types: ["node"],
    removeComments: true,
    strict: true,
    inlineSources: true,
    sourceRoot: "/",
    allowSyntheticDefaultImports: true,
    esModuleInterop: true,
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    importHelpers: true,
    noEmitHelpers: true,
    resolveJsonModule: true,
    skipLibCheck: true,
    skipDefaultLibCheck: true
  }
};
function getMorph(generateDir) {
  const options = {
    compilerOptions: {
      ...tsConfig.compilerOptions,
      module: ModuleKind.ESNext,
      moduleResolution: ModuleResolutionKind.Bundler,
      target: ScriptTarget.ESNext
    },
    skipFileDependencyResolution: false,
    skipAddingFilesFromTsConfig: true,
    useInMemoryFileSystem: !generateDir
  };
  return new Project3(options);
}
var _morphProject, _outputDir, _VirtualProject_instances, resolveImports_fn, findClassSourceFile_fn, exportsDir_fn, exportsCommands_fn, exportRoutes_fn, exportListeners_fn, exportJobs_fn, exportEntities_fn, tuneImports_fn, removeUnusedImports_fn, moveImportsToTop_fn;
var VirtualProject = class {
  constructor(outputDir) {
    __privateAdd(this, _VirtualProject_instances);
    __privateAdd(this, _morphProject);
    __privateAdd(this, _outputDir);
    __privateSet(this, _morphProject, getMorph(outputDir));
    __privateSet(this, _outputDir, outputDir ?? "/");
  }
  getProject() {
    if (!__privateGet(this, _morphProject)) {
      throw new Error("Project not initialized");
    }
    return __privateGet(this, _morphProject);
  }
  generate(concreteStructure) {
    const sourceFiles = {};
    Object.entries(concreteStructure).forEach(([path, content]) => {
      path = join3(__privateGet(this, _outputDir), path);
      sourceFiles[path] ??= __privateGet(this, _morphProject).createSourceFile(path, "", {
        overwrite: true
      });
      sourceFiles[path].addStatements(content);
    });
  }
  write(contract) {
    for (const it of contract) {
      const sourceFile = __privateGet(this, _morphProject).getSourceFile(it.path) ?? __privateGet(this, _morphProject).createSourceFile(it.path, "", {
        overwrite: true
      });
      if (it.path.endsWith(".ts")) {
        sourceFile.removeStatements([0, sourceFile.getStatements().length]);
      }
      sourceFile.addStatements(it.content);
    }
  }
  getOutput() {
    __privateMethod(this, _VirtualProject_instances, resolveImports_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportEntities_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportListeners_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportJobs_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportRoutes_fn).call(this);
    __privateMethod(this, _VirtualProject_instances, exportsCommands_fn).call(this);
    const morphFiles = __privateGet(this, _morphProject).getSourceFiles();
    const files = morphFiles.map((file) => {
      if (file.getFilePath().endsWith(".ts")) {
        __privateMethod(this, _VirtualProject_instances, tuneImports_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, moveImportsToTop_fn).call(this, file);
        __privateMethod(this, _VirtualProject_instances, removeUnusedImports_fn).call(this, file);
      }
      return {
        path: file.getFilePath(),
        content: file.getFullText()
      };
    });
    return files;
  }
  cleanup() {
    __privateGet(this, _morphProject).getSourceFiles().forEach((file) => {
      file.forget();
    });
  }
  async emit(before) {
    await Promise.all(
      __privateGet(this, _morphProject).getSourceFiles().map((file) => before?.(file))
    );
    return __privateGet(this, _morphProject).save();
  }
};
_morphProject = new WeakMap();
_outputDir = new WeakMap();
_VirtualProject_instances = new WeakSet();
resolveImports_fn = function() {
  for (const sourceFile of __privateGet(this, _morphProject).getSourceFiles()) {
    const imports = sourceFile.getImportDeclarations();
    for (const it of imports) {
      let moduleSpecifier = it.getModuleSpecifierValue();
      if (!moduleSpecifier.startsWith("#{")) {
        continue;
      }
      switch (true) {
        case moduleSpecifier.startsWith("#{relative}"): {
          const filePath = moduleSpecifier.replace("#{relative}/", "");
          moduleSpecifier = relative(
            dirname(addLeadingSlash(sourceFile.getFilePath())),
            addLeadingSlash(filePath)
          );
          if (!moduleSpecifier.startsWith(".")) {
            moduleSpecifier = "./" + moduleSpecifier;
          }
          it.setModuleSpecifier(moduleSpecifier);
          break;
        }
      }
    }
  }
};
findClassSourceFile_fn = function(files, className) {
  for (const sourceFile of files) {
    const classDeclaration = sourceFile.getClass(className);
    if (classDeclaration) {
      const filePath = sourceFile.getFilePath();
      const extName = extname(filePath);
      const noExt = filePath.slice(0, -extName.length);
      return noExt;
    }
  }
  return null;
};
exportsDir_fn = function(dir) {
  const fullPath = join3(__privateGet(this, _outputDir), dir);
  const files = __privateGet(this, _morphProject).getSourceFiles(`${fullPath}/*.ts`);
  const imports = [];
  for (const file of files) {
    const fileName = file.getBaseName();
    imports.push(
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(fullPath, "index.ts"),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportsCommands_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), commandsGlob())
  );
  const tags = /* @__PURE__ */ new Map();
  for (const file of files) {
    const fileName = file.getBaseName();
    const tag = dirname(file.getFilePath());
    tags.set(tag, [
      ...tags.get(tag) ?? [],
      `export * from './${basename(fileName).replace(extname(fileName), "")}'`
    ]);
  }
  for (const [tag, imports] of tags.entries()) {
    __privateGet(this, _morphProject).createSourceFile(
      join3(tag, "index.ts"),
      `${imports.join("\n")}`,
      { overwrite: true }
    );
  }
};
exportRoutes_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), routersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of routerFiles) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from './${getLastNParts(
        routerFile.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("routes.ts")),
    `import { type HonoEnv } from '#core/utils.ts';import { Hono } from 'hono';
${imports.join("\n")}

export default [${exportDefaults.join(", ")}] as [string, Hono<HonoEnv>][]`,
    { overwrite: true }
  );
};
exportListeners_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), listenersGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("listeners.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportJobs_fn = function() {
  const files = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), cronsGlob())
  );
  const imports = [];
  const exportDefaults = [];
  for (const routerFile of files) {
    const fileName = routerFile.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import './${getLastNParts(routerFile.getFilePath(), 2, false)}'`
    );
    exportDefaults.push(defaultImportName);
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("crons.ts")),
    `${imports.join("\n")}`,
    { overwrite: true }
  );
};
exportEntities_fn = function() {
  const routerFiles = __privateGet(this, _morphProject).getSourceFiles(
    join3(__privateGet(this, _outputDir), entitiesGlob())
  );
  const imports = [];
  const exportDefaults = [];
  const tables = [];
  for (const entityFiles of routerFiles) {
    const fileName = entityFiles.getBaseName();
    const defaultImportName = camelcase(fileName.replace(".ts", ""));
    imports.push(
      `import ${defaultImportName} from '../${getLastNParts(
        entityFiles.getFilePath(),
        2,
        false
      )}'`
    );
    exportDefaults.push(defaultImportName);
    tables.push(
      `${camelcase(fileName.replace(".entity.ts", ""))}: ${defaultImportName}`
    );
  }
  __privateGet(this, _morphProject).createSourceFile(
    join3(__privateGet(this, _outputDir), makeFeaturePath("entities.ts")),
    `
      ${imports.join("\n")}
      const entities= [${exportDefaults.join(", ")}];

export const tables = {
  ${tables.join(",\n")}
} as const;
      export default entities;
      `,
    { overwrite: true }
  );
};
tuneImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  const uniqueImports = {};
  const uniqueTypeImports = {};
  for (const importDeclaration of imports.filter((it) => it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueTypeImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0
    };
    uniqueTypeImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    importDeclaration.getNamedImports().forEach((item) => {
      uniqueTypeImports[moduleSpecifierValue].namedImports.set(
        item.getName(),
        item.getStructure()
      );
    });
  }
  for (const importDeclaration of imports.filter((it) => !it.isTypeOnly())) {
    const moduleSpecifierValue = importDeclaration.getModuleSpecifierValue();
    uniqueImports[moduleSpecifierValue] ??= {
      namedImports: /* @__PURE__ */ new Map(),
      defaultImport: void 0,
      namespaceImport: void 0
    };
    uniqueImports[moduleSpecifierValue].defaultImport ??= importDeclaration.getDefaultImport()?.getText();
    uniqueImports[moduleSpecifierValue].namespaceImport = importDeclaration.getNamespaceImport()?.getText();
    for (const item of importDeclaration.getNamedImports()) {
      if (uniqueImports[moduleSpecifierValue] && uniqueImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      ) || uniqueTypeImports[moduleSpecifierValue] && uniqueTypeImports[moduleSpecifierValue].namedImports.has(
        item.getName()
      )) {
        continue;
      }
      if (item.isTypeOnly()) {
        uniqueTypeImports[moduleSpecifierValue] ??= {
          namedImports: /* @__PURE__ */ new Map()
        };
        uniqueTypeImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      } else {
        uniqueImports[moduleSpecifierValue].namedImports.set(
          item.getName(),
          item.getStructure()
        );
      }
    }
  }
  imports.forEach((it) => {
    it.remove();
  });
  Object.entries(uniqueImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport || it.namespaceImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: false,
        namespaceImport: it.namespaceImport
      });
    }
  });
  Object.entries(uniqueTypeImports).forEach(([moduleSpecifier, it]) => {
    const namedImports = Array.from(it.namedImports.values());
    if (namedImports.length || it.defaultImport) {
      file.addImportDeclaration({
        kind: StructureKind.ImportDeclaration,
        moduleSpecifier,
        namedImports,
        defaultImport: it.defaultImport,
        isTypeOnly: true
      });
    }
  });
};
removeUnusedImports_fn = function(file) {
  const imports = file.getImportDeclarations();
  for (const importDeclaration of imports) {
    const isInjectImport = !importDeclaration.getImportClause();
    const isNamespaceImport = importDeclaration.getNamespaceImport();
    const defaultImport = importDeclaration.getDefaultImport();
    if (isInjectImport || isNamespaceImport || defaultImport) {
      continue;
    }
    const namedImports = importDeclaration.getNamedImports();
    for (const namedImport of namedImports) {
      const importedName = namedImport.getName();
      const isUsed = file.getDescendantsOfKind(SyntaxKind2.Identifier).filter((it) => !it.getAncestors().includes(importDeclaration)).some((it) => it.getText() === importedName);
      if (isUsed) {
        continue;
      }
      namedImport.remove();
    }
    if (!importDeclaration.getNamedImports().length) {
      importDeclaration.remove();
    }
  }
};
moveImportsToTop_fn = function(file) {
  const imports = file.getImportDeclarations();
  imports.forEach((it, index) => {
    file.insertImportDeclaration(index, {
      moduleSpecifier: it.getModuleSpecifierValue(),
      namespaceImport: it.getNamespaceImport()?.getText(),
      namedImports: it.getNamedImports().map((namedImport) => ({
        name: namedImport.getName(),
        alias: namedImport.getAliasNode()?.getText(),
        isTypeOnly: namedImport.isTypeOnly()
      })),
      defaultImport: it.getDefaultImport()?.getText()
    });
  });
  imports.forEach((it) => it.remove());
};
VirtualProject = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], VirtualProject);
function getLastNParts(path, n, withExt = true) {
  const result = path.split(sep).slice(-n).join(sep);
  return withExt ? result : result.replace(extname(result), "");
}

// libs/compiler/generator/src/index.ts
function getArrowFnBody(arrowFn) {
  const project = new Project4({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${arrowFn}`
  );
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind3.ArrowFunction);
  return guardFunction?.getBodyText();
}
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${typeof arg === "undefined" ? "" : arg})`;
  const guard = transferable.toString();
  const project = new Project4({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const subjectIdentifierText = "subject";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind3.ArrowFunction);
  let subjectUsed = false;
  const [config2] = guardFunction.getParameters();
  if (config2) {
    const name = config2.getNameNode();
    if (name.isKind(SyntaxKind3.ObjectBindingPattern)) {
      const properties = name.getElements();
      subjectUsed = properties.some(
        (prop) => prop.getName() === subjectIdentifierText
      );
    }
  }
  const inputs = /* @__PURE__ */ new Map();
  const parameters = guardFunction.getParameters();
  for (const [key, value] of Object.entries(options.inputs ?? {})) {
    if (isFunction(value)) {
      const result = value(parameters, subjectUsed);
      if (result) {
        inputs.set(key, result);
      }
    } else {
      inputs.set(key, value);
    }
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind3.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind3.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind3.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind2.ImportDeclaration,
      moduleSpecifier: `#entities/${spinalcase2(propertyAccess.getName())}.entity.ts`,
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!parent) {
      const triggerInput = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      inputs.set("trigger", triggerInput);
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind3.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind3.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind3.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs.set(v, {
      // TODO: do we still use "input"?
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()",
        source: "internal"
      }
    });
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = (ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind3.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind3.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind3.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  };
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind3.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  const atLeastOneOutputReturn = returns.some(isOutputReturn);
  if (!atLeastOneOutputReturn) {
    for (const ret of returns) {
      if (isOutputReturn(ret)) {
        continue;
      }
      const isReturningCall = ret.getExpressionIfKind(
        SyntaxKind3.CallExpression
      );
      let returnValue = ret.getText().trim().replace("return ", "");
      if (returnValue.endsWith(";")) {
        returnValue = returnValue.slice(0, -1);
      }
      if (returnValue === "return") {
        ret.replaceWithText(options.setOutput());
      } else {
        ret.replaceWithText(
          options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
        );
      }
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs: Object.fromEntries(inputs)
  };
}

// libs/extensions/src/hono/trigger.ts
import { Project as Project5, StructureKind as StructureKind3, SyntaxKind as SyntaxKind4 } from "ts-morph";
var signalInput = {
  static: true,
  type: "AbortSignal",
  value: `signal`,
  data: {
    parameterName: "signal",
    standalone: true,
    formatted: "context.req.raw.signal"
  }
};
var subjectInput = {
  static: true,
  type: "IdentitySubject",
  value: `subject`,
  data: {
    parameterName: "subject",
    standalone: true,
    formatted: "context.var.subject!"
  },
  structure: [
    `import { type IdentitySubject } from '#core/identity/subject.ts';`
  ]
};
var honotriggers = {
  http(config2) {
    return {
      type: "http",
      inputs: config2.input ? inputize(config2.input) : {},
      config: {
        ...config2,
        structures: [`import { type trigger } from '@january/declarative';`]
      },
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => `input.${key}`,
          inputs: {
            output: {
              static: true,
              type: "trigger.http.output",
              value: `output`,
              data: {
                parameterName: "output",
                standalone: true
              }
            },
            request: (parameters) => parameters.length > 1 ? {
              static: true,
              type: "IncomingMessage",
              value: `(context.env as { incoming: IncomingMessage }).incoming`,
              data: {
                parameterName: "request",
                standalone: true
              },
              structure: [`import { IncomingMessage } from 'node:http';`]
            } : null,
            subject: (parameters, subjectUsed) => subjectUsed ? subjectInput : null,
            signal: signalInput
          }
        });
      }
    };
  },
  sse(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => "input"
        });
      }
    };
  },
  websocket(config2) {
    return {
      type: "sse",
      inputs: {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  },
  stream(config2) {
    return {
      type: "stream",
      inputs: config2.input ? inputize(config2.input) : {},
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => `input.${key}`,
          setOutput: (arg) => `return ${arg}`,
          inputs: {
            request: (parameters) => parameters.length > 1 ? {
              static: true,
              type: "IncomingMessage",
              value: `(context.env as { incoming: IncomingMessage }).incoming`,
              data: {
                parameterName: "request",
                standalone: true
              },
              structure: [
                {
                  kind: StructureKind3.ImportDeclaration,
                  moduleSpecifier: "http",
                  namedImports: ["IncomingMessage"]
                }
              ]
            } : null,
            subject: (parameters, subjectUsed) => subjectUsed ? subjectInput : null,
            signal: signalInput
          }
        });
      }
    };
  },
  tus(config2) {
    const inputs = {};
    return {
      type: "tus",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  },
  file(config2) {
    return {
      type: "file",
      config: {
        ...config2,
        rewrite: config2.rewrite ? config2.rewrite.toString() : void 0
      },
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(
          () => {
          },
          {
            replaceKey: (key) => key
          }
        );
      }
    };
  }
};
function inputize(inputFn) {
  const inputs = {};
  const guard = inputFn.toString();
  const project = new Project5({
    useInMemoryFileSystem: true
  });
  const sourceFile = project.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKind(SyntaxKind4.ArrowFunction);
  if (guardFunction) {
    const returnExpr = guardFunction.getFirstChildByKind(SyntaxKind4.ParenthesizedExpression) ?? guardFunction.getFirstDescendantByKindOrThrow(SyntaxKind4.ReturnStatement);
    const returnObjExpr = returnExpr.getExpressionIfKindOrThrow(
      SyntaxKind4.ObjectLiteralExpression
    );
    returnObjExpr.getProperties().forEach((prop) => {
      const propAssignment = prop.asKindOrThrow(SyntaxKind4.PropertyAssignment);
      const propName = propAssignment.getName();
      const withSelectorAndAgainst = propAssignment.getInitializerIfKind(
        SyntaxKind4.ObjectLiteralExpression
      );
      if (withSelectorAndAgainst) {
        const propValue = withSelectorAndAgainst;
        const selectFn = propValue.getPropertyOrThrow(
          "select"
        );
        const againstFn = propValue.getProperty(
          "against"
        );
        const usageText = selectFn.getInitializerOrThrow().getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: againstFn.getInitializerOrThrow().getText(),
            source: rest[0]
          }
        };
      } else {
        const usageText = propAssignment.getInitializerIfKindOrThrow(SyntaxKind4.PropertyAccessExpression).getText();
        const [namespace, ...rest] = usageText.split(".");
        inputs[propName] = {
          input: `@${namespace}:${rest.join(".")}`,
          value: usageText.replaceAll(`${triggerIdentifierText}.`, ""),
          data: {
            standalone: false,
            zod: "z.any()",
            source: "internal"
          }
        };
      }
    });
  }
  return inputs;
}

// libs/extensions/src/hono/index.ts
var triggersManifest = [
  {
    displayName: "HTTP Trigger",
    name: "http",
    type: "trigger"
  },
  {
    displayName: "SSE Trigger",
    name: "sse",
    type: "trigger"
  },
  {
    displayName: "Stream Trigger",
    name: "stream",
    type: "trigger"
  },
  {
    displayName: "Github Trigger",
    name: "github-trigger",
    type: "trigger"
  },
  {
    displayName: "File Trigger",
    name: "file",
    type: "trigger"
  },
  {
    displayName: "Tus Trigger",
    name: "tus",
    type: "trigger"
  },
  {
    displayName: "Scheduler",
    name: "node-cron-trigger",
    type: "trigger"
  }
];
var triggers = [
  "http",
  "sse",
  "stream",
  "github-trigger",
  "file",
  "tus",
  "node-cron-trigger"
];
var honoDefaultOptions = {
  useFeatureNameAsBasePath: false
};
function hono(options = honoDefaultOptions) {
  return {
    id: "hono",
    primitives: {
      trigger: honotriggers,
      policy: {
        http(transferable) {
          return (name) => `
    import { type Context } from 'hono';
    import { type HonoEnv } from '#core/utils.ts';

    export async function ${name}(context: Context<HonoEnv>): Promise<boolean> {
      ${getArrowFnBody(transferable)}
    }
  `;
        }
      }
    },
    packages: {
      boxen: {
        version: "^8.0.1",
        dev: false
      },
      "fast-glob": {
        version: "^3.3.2",
        dev: false
      },
      ip: {
        version: "^2.0.1",
        dev: false
      },
      "@types/ip": {
        version: "^1.1.3",
        dev: false
      },
      hono: {
        version: "^4.6.14",
        dev: false
      },
      "@hono/node-server": {
        version: "^1.13.7",
        dev: false
      },
      "@scalar/hono-api-reference": {
        version: "^0.5.165",
        dev: false
      },
      "@tus/file-store": {
        version: "^1.5.0",
        dev: false
      },
      "@tus/server": {
        version: "^1.8.0",
        dev: false
      }
    },
    files: {
      // this is here because we don't have core extension anymore, but that might change in the future
      "src/core/validation.ts": zod_default,
      "src/core/utils.ts": `import { type IdentitySubject } from '#core/identity/subject.ts';
export interface HonoEnv {
	Variables: { subject: IdentitySubject | null };
}
`,
      // 'src/extensions/hono/tus.ts': tus,
      "src/extensions/hono/helpers.ts": hono_default,
      "src/extensions/hono/index.ts": `
      export * from './helpers';
      // export * from './tus';
    `,
      "src/app.ts": { content: setup_default, ignoreIfExists: true }
    },
    onFeature(contract, { fs }) {
      const workflows = contract.workflows.filter(
        (it) => triggers.includes(it.trigger.sourceId)
      );
      if (!workflows.length) {
        return {};
      }
      return {
        [makeControllerPath(contract.displayName)]: [
          `import { Hono } from 'hono';`,
          `import { createOutput } from '#hono';`,
          `import { apiReference } from '@scalar/hono-api-reference';`,
          `import { type HonoEnv } from '#core/utils.ts';`,
          `import { serveStatic } from '@hono/node-server/serve-static';`,
          `import { streamSSE, streamText } from 'hono/streaming';`,
          `import { join, relative } from 'node:path';`,
          ...contract.workflows.map((it) => it.imports).flat(),
          `const router = new Hono<HonoEnv>();`,
          ...workflows.map((workflow) => {
            const displayName = `${camelcase(workflow.featureName)}.${camelcase(
              workflow.trigger.displayName
            )}`;
            let workflowInputs = {};
            const standaloneInputs2 = {};
            const inputs = { ...workflow.inputs };
            for (const [key, value] of Object.entries(inputs)) {
              if (value.data?.["standalone"]) {
                standaloneInputs2[key] = value;
                delete inputs[key];
              }
            }
            workflowInputs = {
              ...workflowInputs,
              ...standaloneInputs2
            };
            const sourceTrigger = triggersManifest.find(
              (it) => it.name === workflow.trigger.sourceId
            );
            if (!sourceTrigger) {
              throw new Error(
                `Action with id ${workflow.trigger.sourceId} not found`
              );
            }
            const policies = workflow.trigger.policies.filter(Boolean);
            const triggerStructures = processTrigger(
              workflow.trigger,
              workflowInputs,
              sourceTrigger
            );
            let path = removeTrialingSlashes(
              addLeadingSlash(
                join4(
                  contract.displayName !== "root" ? snakecase2(workflow.tag) : "/",
                  workflow.trigger.details["path"]
                )
              )
            );
            path = path === "" ? "/" : path;
            switch (sourceTrigger.name) {
              case "tus": {
                const displayName2 = `createUploader(${toLiteralObject(
                  Object.fromEntries(
                    Object.entries(workflow.trigger.details).filter(
                      ([key]) => !["path", "policies", "inputs"].includes(key)
                    ).concat([
                      [
                        "path",
                        `'${addLeadingSlash(join4(snakecase2(contract.displayName), path))}'`
                      ]
                    ]).map(([key, value]) => [key, value])
                  )
                )})`;
                const authorize = policies ? `,authorize(${policies.join(",")})` : "";
                return [
                  ...triggerStructures.imports,
                  `import { createUploader } from '#hono';`,
                  `router
              .all("${path}" ${authorize})
              .all("*", ${displayName2});`
                ];
              }
              case "http": {
                const method = workflow.trigger.details["method"].toLowerCase();
                const verb = `router.${method}`;
                const contentType = ["put", "patch", "post"].includes(method) ? 'consume("application/json")' : "";
                const authorize = policies ? `authorize(${policies.join(",")})` : "";
                const args = [`"${path}"`, contentType, authorize].filter(
                  Boolean
                );
                return [
                  ...triggerStructures.imports,
                  `${verb.toLowerCase()}(${args.join(",")} ,async (context,next)=>{${triggerStructures.content.join(";")}})`
                ];
              }
              case "sse": {
                const verb = `router.get`;
                const authorize = policies ? `,authorize(${policies.join(",")})` : "";
                return [
                  ...triggerStructures.imports,
                  `${verb.toLowerCase()}("${path}" ${authorize}, context => {
  return streamSSE(context, async (stream) => {
    ${triggerStructures.content.join(";")}
    for await (const chunk of await output) {
      await stream.writeSSE({ data: JSON.stringify(chunk) });
    }
  });
              })`
                ];
              }
              case "stream": {
                const method = workflow.trigger.details["method"].toLowerCase();
                const verb = `router.${method}`;
                const contentType = ["put", "patch", "post"].includes(method) ? 'consume("application/json")' : "";
                const authorize = policies ? `authorize(${policies.join(",")})` : "";
                const args = [`"${path}"`, contentType, authorize].filter(
                  Boolean
                );
                return [
                  ...triggerStructures.imports,
                  `${verb.toLowerCase()}(${args.join(",")} ,async (context,next)=>{${triggerStructures.content.join(";")}})`
                ];
              }
              case "file": {
                const verb = `router.use`;
                const authorize = policies ? `,authorize(${policies.join(",")})` : "";
                const rewrite = workflow.trigger.details["rewrite"] ? `rewriteRequestPath: ${workflow.trigger.details["rewrite"]}` : "";
                return `${verb.toLowerCase()}("${path}" ${authorize}, serveStatic({
                  root: join(relative(process.cwd(), import.meta.dirname), 'public', ${workflow.trigger.details["root"] ? `'${workflow.trigger.details["root"]}'` : ""}),
                  ${rewrite}
              }));`;
              }
              default:
                throw new Error(
                  `Trigger ${sourceTrigger.name} is not supported`
                );
            }
          }).flat(),
          (writer) => writer.writeLine(
            `export default ['/${options.useFeatureNameAsBasePath ? spinalcase2(contract.displayName) : ""}', router] as const;`
          )
        ]
      };
    }
  };
}
function processTrigger(contract, workflowInputs, trigger) {
  const inputName = camelcase("input");
  const workflowInputsStructures = Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean);
  const vars = {};
  for (const input of Object.values({
    ...contract.inputs,
    ...workflowInputs
  })) {
    if (typeof input === "string" || isNullOrUndefined(input.value)) {
      continue;
    }
    const value = input.value;
    if (value.startsWith("body") && !vars["body"]) {
      vars["body"] = "const body = await context.req.json()";
    }
    if (value.startsWith("path") && !vars["path"]) {
      vars["path"] = "const path = context.req.param()";
    }
    if (value.startsWith("query") && !vars["query"]) {
      vars["query"] = "const query = context.req.query()";
    }
  }
  const inputParams = nonStaticInputs({ ...contract.inputs }).map(
    ([name, prop]) => {
      if (prop.value.startsWith("headers.")) {
        const [, right] = prop.value.split("headers.");
        return [
          name,
          { ...prop, value: `context.req.header('${right}')` }
        ];
      }
      const propZod = prop.data?.zod;
      if (propZod && propZod.startsWith("z.array(")) {
        const [, right] = prop.value.split("query.");
        return [
          name,
          { ...prop, value: `context.req.queries('${right}')` }
        ];
      }
      return [name, prop];
    }
  );
  const workflowLoneParams = standaloneInputs(workflowInputs);
  const actionInputsStr = toLiteralObject(inputParams);
  for (const [name, prop] of workflowLoneParams) {
    if (prop.structure) {
      workflowInputsStructures.push(prop.structure);
    }
    if (prop.value === name) {
      continue;
    }
    if (prop.value.startsWith("headers.")) {
      vars[name] = `const ${name} = context.req.header(${prop.value})`;
    } else {
      vars[name] = `const ${name} = ${prop.value}`;
    }
  }
  const workflowParams = [];
  if (inputParams.length) {
    workflowParams.push(inputName);
  }
  if (workflowLoneParams.length) {
    workflowParams.push(
      ...workflowLoneParams.map(([name, prop]) => {
        return prop.data?.["formatted"] || name;
      })
    );
  }
  const imports = [
    ...workflowInputsStructures.flat(),
    `import * as ${camelcase(contract.tag)} from './${spinalcase2(contract.tag)}'`,
    `import { parseOrThrow } from '#core/validation.ts'`,
    `import { consume, createOutput } from '#hono'`,
    `import { authorize } from '#core/authorize.ts'`
  ];
  switch (trigger.name) {
    case "file":
      return { imports, content: [] };
    case "tus":
      return { imports, content: [] };
    case "sse":
      return {
        imports,
        content: [
          ...Object.values(vars),
          "\n",
          inputParams.length ? `const ${inputName} = parseOrThrow(${camelcase(contract.tag)}.${contract.schemaName}, ${actionInputsStr})` : "",
          "\n",
          `const output = await ${camelcase(
            contract.tag
          )}.${camelcase(contract.operationName)}(${workflowParams.join(",")})`
        ]
      };
    case "stream": {
      const operationName = `${camelcase(
        contract.tag
      )}.${camelcase(contract.operationName)}`;
      return {
        imports,
        content: [
          ...Object.values(vars),
          "\n",
          inputParams.length ? `const ${inputName} = parseOrThrow(${camelcase(contract.tag)}.${contract.schemaName}, ${actionInputsStr})` : "",
          "\n",
          `return streamText(context, async (stream) => {
                        for await (const chunk of await ${operationName}(${workflowParams.join(",")})) {
                         await stream.write(chunk);
                        }
                      });`
        ]
      };
    }
    case "http": {
      const operationName = `${camelcase(
        contract.tag
      )}.${camelcase(contract.operationName)}`;
      return {
        imports,
        content: [
          ...Object.values(vars),
          "\n",
          inputParams.length ? `const ${inputName} = parseOrThrow(${camelcase(contract.tag)}.${contract.schemaName}, ${actionInputsStr})` : "",
          "\n",
          `const output = createOutput(context);`,
          `await ${operationName}(${workflowParams.join(",")})`,
          `return output.finalize();`
        ]
      };
    }
    default:
      throw new Error(`Trigger ${trigger.name} is not supported`);
  }
}
export {
  hono,
  honoDefaultOptions
};
//# sourceMappingURL=index.js.map
