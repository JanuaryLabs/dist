// libs/extensions/hono/src/setup.txt
var setup_default = "import './features/crons'\nimport './features/listeners'\nimport { Hono } from 'hono';\nimport { cors } from 'hono/cors';\nimport { logger } from 'hono/logger';\n\nimport dataSource from '@extensions/postgresql';\nimport { ValidationFailedException } from './core/validation';\nimport routes from './features/routes';\nimport { IdentitySubject, loadSubject } from './identity';\n\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\nimport { StatusCode } from 'hono/utils/http-status';\n\nconst application = new Hono<{\n  Variables: { subject: IdentitySubject | null };\n}>();\napplication.use(cors(), logger());\n\n\napplication.use(async (context, next) => {\n  const subject = await loadSubject(context.req.header('Authorization'));\n  context.set('subject', subject);\n  await next();\n});\n\n// TODO: use rfc-7807-problem-details\napplication.onError((err, context) => {\n  console.error(err);\n\n  if (err instanceof ValidationFailedException) {\n    context.status(400);\n    return context.json(err);\n  }\n\n  if (err instanceof ProblemDetailsException) {\n    context.status(err.Details.status as StatusCode ?? 500);\n    return context.json(err.Details);\n  }\n\n  context.status(500);\n  return context.json({\n    type: 'about:blank',\n    title: 'Internal Server Error',\n    status: 500,\n    detail: 'An unexpected error occurred',\n  });\n});\n\nroutes.forEach((route) => {\n  application.route(...route);\n});\n\ndataSource\n  .initialize()\n  .then(() => {\n    console.log('Database initialized');\n  })\n  .catch((error) => {\n    console.error(error);\n    process.exit(1);\n  });\n\napplication.get('/', (context, next) => {\n  return context.json({\n    status: 'UP',\n  });\n});\n\napplication.get('/health', async (context, next) => {\n  await dataSource.query('SELECT 1');\n  return context.json({\n    status: 'UP',\n  });\n});\n\nexport default application;";

// libs/extensions/hono/src/index.ts
var HonoExtension = class {
  setup(fs) {
    return [
      // {
      //   filePath: this._projectFS.makeCorePath('adapter.ts'),
      //   content: txt,
      // },
      {
        filePath: fs.makeSrcPath("main.ts"),
        content: [setup_default]
      }
    ];
  }
};
export {
  HonoExtension
};
