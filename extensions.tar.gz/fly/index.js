// libs/extensions/src/fly/index.ts
import dedent from "dedent";
import yaml from "js-yaml";
var deployContent = (withBuild) => {
  const buildSteps = [
    {
      id: "setup_node",
      uses: "actions/setup-node@v3",
      name: "Setup Node.js",
      with: {
        "node-version": "20",
        cache: "npm"
      }
    },
    {
      id: "cache_deps",
      name: "Cache Or Restore Node Modules.",
      uses: "actions/cache@v3",
      with: {
        path: "node_modules",
        key: "${{ runner.os }}-node-${{ hashFiles('package-lock.json') }}"
      }
    },
    {
      id: "install_deps",
      name: "Install project dependencies.",
      run: "npm install --no-audit --no-fund",
      if: `steps.cache_deps.outputs.cache-hit != 'true'`
    },
    {
      name: "Build",
      run: "npm run build"
    }
  ];
  return yaml.dump(
    {
      name: "Deploy To Fly.io",
      on: {
        push: {
          branches: ["main"]
        },
        workflow_dispatch: {}
      },
      concurrency: {
        group: "${{ github.workflow }}-${{ github.event.pull_request.number || github.ref }}",
        "cancel-in-progress": true
      },
      jobs: {
        deploy_to_fly: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            ...withBuild ? buildSteps : [],
            {
              name: "Setup Fly.io cli.",
              uses: "superfly/flyctl-actions/setup-flyctl@master"
            },
            {
              name: "Deploying ...",
              run: `flyctl deploy --app \${{ secrets.FLY_APP_NAME }} --remote-only`,
              env: {
                FLY_API_TOKEN: `\${{ secrets.FLY_API_TOKEN }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
};
var fly = (options = { runBuildInDocker: true }) => {
  options.runBuildInDocker = options.runBuildInDocker ?? true;
  return {
    packages: {},
    files: {
      "../.github/workflows/deploy-fly.yml": deployContent(
        !options.runBuildInDocker
      ),
      "../.dockerignore": ["node_modules", ".git"].join("\n"),
      "../Dockerfile": dedent`
FROM node:alpine AS base

# Install dependencies only when needed
FROM base AS deps
# Check https://github.com/nodejs/docker-node/tree/b4117f9333da4138b03a546ec926ef50a31506c3#nodealpine to understand why libc6-compat might be needed.
RUN apk add --no-cache libc6-compat
WORKDIR /app

# Install dependencies based on the preferred package manager
COPY package.json yarn.lock* package-lock.json* pnpm-lock.yaml* ./
RUN \
  if [ -f yarn.lock ]; then yarn --frozen-lockfile; \
  elif [ -f package-lock.json ]; then npm ci; \
  elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile; \
  else echo "Lockfile not found." && exit 1; \
  fi

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

RUN \
  if [ -f yarn.lock ]; then yarn run build; \
  elif [ -f package-lock.json ]; then npm run build; \
  elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build; \
  else echo "Lockfile not found." && exit 1; \
  fi

FROM base AS runner
WORKDIR /app

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 runtime

COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder ./output/build/ ./build/

ENV NODE_ENV=production
ENV PORT=3000

USER runtime
EXPOSE 3000

CMD ["node", "server.js"]
    `,
      "src/server.ts": `import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import application from './app';
import { relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { showRoutes } from 'hono/dev'
import ip from 'ip';
import boxen from 'boxen';
import glob from 'fast-glob';
import { pretty } from '@january/console';
import './startup.ts';
const dirRelativeToCwd = relative(process.cwd(), import.meta.dirname);

  application.use(
    '/:filename{.+\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

  application.use('/:filename{.+\\.swagger\\.json$}', serveStatic({
    root: dirRelativeToCwd,
    rewriteRequestPath: (path) => path.split('/').pop() as string,
  }));

const port = parseInt(process.env.PORT ?? '3000', 10)
serve({
  fetch: application.fetch,
  port: port,
});

if(process.env.NODE_ENV === 'development'){
  showRoutes(application, { verbose: true });
}

pretty.network(port);
pretty.swagger('*.swagger.json')
`
    }
  };
};
export {
  fly
};
//# sourceMappingURL=index.js.map
