var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function orThrow(fn, message) {
  const result = fn();
  if ([void 0, null].includes(result)) {
    const error = new Error(message);
    Error.captureStackTrace(error, orThrow);
    throw error;
  }
  return result;
}
__name(orThrow, "orThrow");
function isNullOrUndefined(value) {
  return value === void 0 || value === null;
}
__name(isNullOrUndefined, "isNullOrUndefined");
function notNullOrUndefined(value) {
  return !isNullOrUndefined(value);
}
__name(notNullOrUndefined, "notNullOrUndefined");
function upsert(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = insert(item, false);
    return array;
  } else {
    return [...array, insert({ id }, true)];
  }
}
__name(upsert, "upsert");
async function upsertAsync(array, id, insert) {
  const [index, item] = byId(array, id);
  if (item) {
    array[index] = await insert(item);
    return array;
  } else {
    return [...array, await insert({ id })];
  }
}
__name(upsertAsync, "upsertAsync");
function byId(array, id) {
  const index = array.findIndex((it) => it.id === id);
  return [index, array[index]];
}
__name(byId, "byId");
var removeEmpty = /* @__PURE__ */ __name((obj) => {
  const newObj = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] === Object(obj[key]) && !Array.isArray(obj[key]))
      newObj[key] = removeEmpty(obj[key]);
    else if (obj[key] !== void 0) newObj[key] = obj[key];
  });
  return newObj;
}, "removeEmpty");
function assertNotNullOrUndefined(value, debugLabel) {
  if (value === null || value === void 0) {
    throw new Error(`${debugLabel} is undefined or null.`);
  }
}
__name(assertNotNullOrUndefined, "assertNotNullOrUndefined");
async function profile({
  label,
  seconds = false
}, fn) {
  const startTime = performance.now();
  try {
    return await fn();
  } finally {
    const endTime = performance.now();
    const time = endTime - startTime;
    const formattedTime = seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
    const timeUnit = seconds ? "seconds" : "milliseconds";
    console.log(`Execution time => [${label}]: ${formattedTime} ${timeUnit}`);
  }
}
__name(profile, "profile");
var colors = {
  green: /* @__PURE__ */ __name((message) => `\x1B[32m${message}\x1B[0m`, "green"),
  blue: /* @__PURE__ */ __name((message) => `\x1B[34m${message}\x1B[0m`, "blue"),
  magenta: /* @__PURE__ */ __name((message) => `\x1B[35m${message}\x1B[0m`, "magenta")
};
function createRecorder(options = { seconds: false }) {
  const startedAt = performance.now();
  function log(...args) {
    if (!process.env["RECORD_OFF"]) {
      console.log(...args);
    }
  }
  __name(log, "log");
  log(colors.green(`Recording started => [${options.label}]`));
  const operations = /* @__PURE__ */ new Map();
  return {
    record: /* @__PURE__ */ __name((label) => {
      operations.set(label, performance.now());
      if (options.verbose) {
        log(
          colors.blue(`Recording => [${options.label ? `${options.label} => ` : ""}${label}]
        `)
        );
      }
    }, "record"),
    recordEnd: /* @__PURE__ */ __name((label, result) => {
      const endTime = performance.now();
      const time = endTime - operations.get(label);
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.blue(
          `Execution time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime} ${timeUnit}`
        ),
        ...[result].filter((item) => typeof item !== "undefined")
      );
      operations.delete(label);
    }, "recordEnd"),
    end: /* @__PURE__ */ __name(() => {
      const endTime = performance.now();
      const time = endTime - startedAt;
      const lastEntry = Array.from(operations.entries()).at(-1);
      if (lastEntry) {
        const [label, start] = lastEntry;
        const time2 = performance.now() - start;
        const formattedTime2 = options.seconds ? (time2 / 1e3).toFixed(6) : time2.toFixed(6);
        const timeUnit2 = options.seconds ? "seconds" : "milliseconds";
        log(
          colors.magenta(
            `Recording Total time => [${options.label ? `${options.label} => ` : ""}${label}]: ${formattedTime2} ${timeUnit2}`
          )
        );
        operations.delete(label);
      }
      const formattedTime = options.seconds ? (time / 1e3).toFixed(6) : time.toFixed(6);
      const timeUnit = options.seconds ? "seconds" : "milliseconds";
      log(
        colors.magenta(
          `Recording end => [${options.label}]: ${formattedTime} ${timeUnit}`
        )
      );
    }, "end")
  };
}
__name(createRecorder, "createRecorder");
function applyCondition(condition, context) {
  const input = resolveContextKey(condition.input, context);
  switch (condition.operator) {
    case "equal":
      return input === condition.value ? condition.then : condition.else;
    case "not_equal":
      return input !== condition.value ? condition.then : condition.else;
    default:
      throw new Error(`Unknown operator ${condition.operator}`);
  }
}
__name(applyCondition, "applyCondition");
function resolveContextKey(key, details) {
  const [source, path] = key.split(".");
  if (source === "self") {
    return get(details.self, path);
  } else if (source === "context") {
    return get(details.context, path);
  }
  return key;
}
__name(resolveContextKey, "resolveContextKey");
function buildUrl(url, details, binding) {
  {
    const variables = url.split(/\/([^\/]+)/).filter((x) => x.startsWith(":"));
    if (!variables.length || !details) {
      return { url, params: [] };
    }
    const params = variables.reduce((acc, variable) => {
      const key = variable.slice(1);
      return {
        ...acc,
        [key]: resolveContextKey(binding[key], details)
      };
    }, {});
    return {
      url,
      params: Object.values(params)
    };
  }
}
__name(buildUrl, "buildUrl");
function isResolvable(maybeResolvable) {
  if (!maybeResolvable) {
    return false;
  }
  if (Array.isArray(maybeResolvable)) {
    return true;
  }
  if (maybeResolvable.url) {
    return true;
  }
  return false;
}
__name(isResolvable, "isResolvable");
function isCondition(obj) {
  if (!obj || typeof obj === "string" || Array.isArray(obj)) return false;
  if ("input" in obj && "operator" in obj && "value" in obj) {
    return true;
  }
  return false;
}
__name(isCondition, "isCondition");
function parseDetails(details, path) {
  const parsed = JSON.parse(details ?? "{}");
  return path ? get(parsed, path, {}) : parsed;
}
__name(parseDetails, "parseDetails");
var logMe = /* @__PURE__ */ __name((object) => console.dir(object, {
  showHidden: false,
  depth: Infinity,
  maxArrayLength: Infinity,
  colors: true
}), "logMe");
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
__name(toLitObject, "toLitObject");
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
__name(toLiteralObject, "toLiteralObject");
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
__name(addLeadingSlash, "addLeadingSlash");
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
__name(removeTrialingSlashes, "removeTrialingSlashes");
function retryPromise(promise, options = {}) {
  return new Promise((resolve, reject) => {
    const operation = retry.operation({
      factor: 2,
      randomize: true,
      minTimeout: 1e3,
      maxTimeout: 2e3,
      ...options
    });
    operation.attempt(async (currentAttempt) => {
      try {
        const result = await promise();
        resolve(result);
      } catch (error) {
        if (!operation.retry(error)) {
          reject(error);
        }
      }
    });
  });
}
__name(retryPromise, "retryPromise");
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(uniquify, "uniquify");
function toRecord(array, config) {
  return array.reduce((acc, item) => {
    return {
      ...acc,
      [config.accessor(item)]: config.map(item)
    };
  }, {});
}
__name(toRecord, "toRecord");
function hasProperty(obj, key) {
  if (typeof obj !== "object") {
    return false;
  }
  return key in obj;
}
__name(hasProperty, "hasProperty");
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
__name(sleep, "sleep");
function safeFail(fn, defaultValue) {
  try {
    return fn();
  } catch (error) {
    return defaultValue;
  }
}
__name(safeFail, "safeFail");
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
__name(extractError, "extractError");
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
__name(toCurlyBraces, "toCurlyBraces");
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
__name(normalizeWorkflowPath, "normalizeWorkflowPath");
var pool = {};
function runWorker(publicPath, message, options = {
  type: "module",
  terminateImmediately: false
}) {
  let worker;
  if (options.terminateImmediately) {
    worker = new Worker(publicPath, options);
  } else {
    worker = pool[publicPath] ??= new Worker(publicPath, options);
  }
  const defer = new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      if ("error" in e.data) {
        reject(e.data.error);
        console.error(e.data.error);
      } else {
        resolve(e.data.data);
      }
    };
    worker.onerror = (e) => {
      if (options.terminateImmediately) {
        worker.terminate();
      }
      reject(e.error);
    };
  });
  worker.postMessage(message);
  return defer;
}
__name(runWorker, "runWorker");
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
__name(removeDuplicates, "removeDuplicates");
function scan(array, accumulator) {
  const scanned = [];
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
    const acc = [];
    for (let j = i - 1; j >= 0; j--) {
      acc.unshift(array[j]);
    }
    scanned.push(accumulator(element, acc));
  }
  return scanned;
}
__name(scan, "scan");
function partition(array, ...predicates) {
  const result = Array.from({ length: predicates.length + 1 }, () => []);
  for (const item of array) {
    let found = false;
    for (let i = 0; i < predicates.length; i++) {
      const fn = predicates[i];
      if (fn(item)) {
        result[i].push(item);
        found = true;
      }
    }
    if (!found) {
      result.at(-1).push(item);
    }
  }
  return result;
}
__name(partition, "partition");
function isLiteralObject(obj) {
  return obj !== null && !Array.isArray(obj) && typeof obj === "object" && obj.constructor === Object;
}
__name(isLiteralObject, "isLiteralObject");
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
__name(toKevValEnv, "toKevValEnv");
function msToNs(ms) {
  return ms * 1e6;
}
__name(msToNs, "msToNs");
function nsToMs(nano) {
  return parseInt(typeof nano === "number" ? String(nano) : nano, 10) / 1e6;
}
__name(nsToMs, "nsToMs");

// libs/utils/src/lib/parser/token.ts
var Expression = class {
  static {
    __name(this, "Expression");
  }
  parent;
};
var Arg = class extends Expression {
  constructor(name, value) {
    super();
    this.name = name;
    this.value = value;
    this.name.parent = this;
    this.value.parent = this;
  }
  static {
    __name(this, "Arg");
  }
  type = "arg";
  accept(visitor) {
    return visitor.visitArg(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}: ${this.value.toLiteral(visitor)}`;
  }
};
var Call = class extends Expression {
  constructor(name, args = []) {
    super();
    this.name = name;
    this.args = args;
    this.name.parent = this;
    this.args.forEach((arg) => arg.parent = this);
  }
  static {
    __name(this, "Call");
  }
  type = "call";
  accept(visitor) {
    return visitor.visitCall(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}(${this.args.map((arg) => arg.toLiteral(visitor)).join(", ")})`;
  }
};
var PropertyAccess = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "PropertyAccess");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitPropertyAccess(this);
  }
  toLiteral(visitor) {
    return `${this.name.toLiteral(visitor)}.${this.expression.toLiteral(
      visitor
    )}`;
  }
};
var Binary = class extends Expression {
  constructor(operator, left, right) {
    super();
    this.operator = operator;
    this.left = left;
    this.right = right;
    this.operator.parent = this;
    this.left.parent = this;
    this.right.parent = this;
  }
  static {
    __name(this, "Binary");
  }
  type = "propertyAccess";
  accept(visitor) {
    return visitor.visitBinary(this);
  }
  toLiteral(visitor) {
    return `${this.left.toLiteral(visitor)} ${this.operator.toLiteral(
      visitor
    )} ${this.right.toLiteral(visitor)}`;
  }
};
var Namespace = class extends Expression {
  constructor(name, expression) {
    super();
    this.name = name;
    this.expression = expression;
    this.name.parent = this;
    this.expression.parent = this;
  }
  static {
    __name(this, "Namespace");
  }
  type = "namespace";
  accept(visitor) {
    return visitor.visitNamespace(this);
  }
  toLiteral(visitor) {
    return `@${this.name.value}:${this.expression.toLiteral(visitor)}`;
  }
};
var Identifier = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "Identifier");
  }
  type = "identifier";
  accept(visitor) {
    return visitor.visitIdentifier(this);
  }
  toLiteral(visitor) {
    return this.value;
  }
};
var StringLiteral = class extends Expression {
  constructor(value) {
    super();
    this.value = value;
  }
  static {
    __name(this, "StringLiteral");
  }
  type = "string";
  accept(visitor) {
    return visitor.visitStringLiteral(this);
  }
  toLiteral(visitor) {
    return `'${this.value}'`;
  }
};
var typeChecker = {
  isCall(expression) {
    return expression.type === "call";
  },
  isNamespace(expression) {
    return expression.type === "namespace";
  },
  isPropertyAccess(expression) {
    return expression.type === "propertyAccess";
  },
  isIdentifier(expression) {
    return expression.type === "identifier";
  }
};
var Visitor = class {
  static {
    __name(this, "Visitor");
  }
};
var AsyncVisitor = class {
  static {
    __name(this, "AsyncVisitor");
  }
};
var StringVisitor = class extends Visitor {
  static {
    __name(this, "StringVisitor");
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
var StringAsyncVisitor = class extends AsyncVisitor {
  static {
    __name(this, "StringAsyncVisitor");
  }
  async visitIdentifier(node2) {
    return node2.value;
  }
  async visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};

// libs/utils/src/lib/parser/sqlite.visitor.ts
var SqliteVisitor = class extends Visitor {
  static {
    __name(this, "SqliteVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    const where = node2.args.map((arg) => arg.accept(this)).join(", ");
    return `${node2.name.accept(this)} WHERE id = ${where}`;
  }
  visitNamespace(node2) {
    if (node2.name.value === "tables") {
      return `SELECT ${node2.expression.accept(this)}`;
    }
    return `'${node2.toLiteral(this)}'`;
  }
  visitPropertyAccess(node2) {
    return `${node2.expression.accept(this)} FROM ${node2.name.accept(this)}`;
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toSqlite(input) {
  const visitor = new SqliteVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSqlite, "toSqlite");
var TypeormVisitor = class extends Visitor {
  static {
    __name(this, "TypeormVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    const where = node2.args.reduce(
      (acc, current) => {
        return {
          ...acc,
          // static to id till we support multiple args
          id: current.accept(this)
        };
      },
      {}
    );
    const tableName = node2.name.accept(this);
    return `.from('${tableName}', '${tableName}').andWhere('id = :id', ${toLitObject(
      where,
      (value) => value
    )})`;
  }
  visitPropertyAccess(node2) {
    return `.select('${node2.expression.accept(this)}')${node2.name.accept(
      this
    )}`;
  }
  visitNamespace(node2) {
    if (node2.name.value === "tables") {
      return `qb${node2.expression.accept(this)}`;
    }
    return `'${node2.toLiteral(this)}'`;
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toTypeorm(input) {
  const visitor = new TypeormVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toTypeorm, "toTypeorm");
var SimpleVisitor = class extends Visitor {
  static {
    __name(this, "SimpleVisitor");
  }
  visitArg(node2) {
    throw new Error("Method not implemented.");
  }
  visitBinary(propertyAccess) {
    throw new Error("Method not implemented.");
  }
  visitCall(node2) {
    return node2.toLiteral(this);
  }
  visitPropertyAccess(node2) {
    return node2.toLiteral(this);
  }
  visitNamespace(node2) {
    return {
      namespace: node2.name.value,
      value: node2.expression.accept(this)
    };
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    return node2.accept(this);
  }
};
function toSimple(input) {
  const visitor = new SimpleVisitor();
  return visitor.visit(parseDsl(input));
}
__name(toSimple, "toSimple");

// libs/utils/src/lib/parser/tokeniser.ts
function tokeniser(input) {
  let index = 0;
  const tokens = [];
  let lexeme = "";
  while (index < input.length) {
    const char = input[index];
    switch (char) {
      case "=":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "EQUALS",
          value: char,
          column: index
        });
        index++;
        break;
      case "!":
        if (input[index + 1] === "=") {
          if (lexeme) {
            tokens.push({
              type: "IDENTIFIER",
              value: lexeme,
              column: index
            });
            lexeme = "";
          }
          tokens.push({
            type: "NOT_EQUALS",
            value: "!=",
            column: index
          });
          index += 2;
        } else {
          lexeme += char;
          index++;
        }
        break;
      case ".":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "DOT",
          value: char,
          column: index
        });
        index++;
        break;
      case ",":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "COMMA",
          value: char,
          column: index
        });
        index++;
        break;
      case "@":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        tokens.push({
          type: "AT",
          value: char,
          column: index
        });
        index++;
        break;
      case ":":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "COLON",
          value: char,
          column: index
        });
        index++;
        break;
      case "'":
      case '"':
        {
          index++;
          while (input[index] !== "'" && input[index] !== '"') {
            lexeme += input[index];
            index++;
          }
          index++;
          const column = index;
          if (input[index] === "]") {
            lexeme += input[index];
            index++;
          }
          tokens.push({
            type: "STRING",
            value: lexeme,
            column
          });
          lexeme = "";
        }
        break;
      case "(":
        tokens.push({
          type: "IDENTIFIER",
          value: lexeme,
          column: index
        });
        lexeme = "";
        tokens.push({
          type: "OPEN_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case ")":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        lexeme = "";
        tokens.push({
          type: "CLOSE_PAREN",
          value: char,
          column: index
        });
        index++;
        break;
      case " ":
      case "\r":
      case "	":
        if (lexeme) {
          tokens.push({
            type: "IDENTIFIER",
            value: lexeme,
            column: index
          });
          lexeme = "";
        }
        index++;
        break;
      default:
        lexeme += char;
        index++;
        break;
    }
  }
  if (lexeme) tokens.push({ type: "IDENTIFIER", value: lexeme });
  tokens.push({ type: "EOF", value: "" });
  return tokens;
}
__name(tokeniser, "tokeniser");

// libs/utils/src/lib/parser/input-parser.ts
var grammars = `
  <expression> ::= <namespace> <property-access>
  <namespace> ::= @<identifier>:
  <property-access> ::= <property-access> . <identifier> | <identifier>
  <call> ::= <function> <arg>
  <function> ::= <identifier>
  <arg> ::= <namespace> | <identifier>
  <arg> ::= <namespace> | <identifier>

  <identifier> ::= <letter> | <identifier> <char>
  <char> ::= <letter> | <digit> | "_"
  <letter> ::= "a" | "b" | ... | "z" | "A" | "B" | ... | "Z"
  <digit> ::= "0" | "1" | ... | "9"
`;
function parseInput(input) {
  return toSimple(input);
}
__name(parseInput, "parseInput");
var ParserTokens = class {
  static {
    __name(this, "ParserTokens");
  }
  currentIdx = 0;
  tokens = [];
  constructor(tokens) {
    this.tokens = tokens;
  }
  get peek() {
    return this.tokens[this.currentIdx];
  }
  get lookahead() {
    return this.tokens[this.currentIdx + 1];
  }
  get lookbehind() {
    return this.tokens[this.currentIdx - 1];
  }
  isAtEnd() {
    return this.check("EOF");
  }
  match(...types) {
    if (this.isAtEnd()) return false;
    if (this.check(...types)) {
      this.advance();
      return true;
    }
    return false;
  }
  consume(type, message) {
    if (this.check(type)) {
      return this.advance();
    }
    const error = new Error(
      `${message} at ${this.currentIdx} Found ${this.peek.type}`
    );
    Error.captureStackTrace(error, this.consume);
    throw error;
  }
  check(...tokens) {
    return tokens.includes(this.peek.type);
  }
  advance() {
    return this.tokens[++this.currentIdx];
  }
  retreat() {
    return this.tokens[--this.currentIdx];
  }
  reset() {
    this.currentIdx = 0;
  }
  slice() {
    return this.tokens.slice(this.currentIdx);
  }
};
var DSLParser = class extends ParserTokens {
  constructor(input) {
    super(tokeniser(input));
    this.input = input;
  }
  static {
    __name(this, "DSLParser");
  }
  subparsing(parserType) {
    const parser = new parserType(this.slice());
    const { expression, index } = parser.subparse();
    this.currentIdx += index;
    return expression;
  }
  #equal() {
    const expression = this.subparsing(NamespaceParser);
    if (this.match("EQUALS") || this.match("NOT_EQUALS")) {
      const operator = new Identifier(this.lookbehind.value);
      const right = this.#expression();
      return new Binary(operator, expression, right);
    }
    return expression;
  }
  #expression() {
    const expression = this.#equal();
    return expression;
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};
function parseDsl(input) {
  const parser = new DSLParser(input);
  return parser.parse();
}
__name(parseDsl, "parseDsl");
var NamespaceParser = class extends ParserTokens {
  static {
    __name(this, "NamespaceParser");
  }
  #primary() {
    if (this.match("STRING")) {
      return new StringLiteral(this.lookbehind.value);
    }
    if (this.match("IDENTIFIER")) {
      return new Identifier(this.lookbehind.value);
    }
    if (this.match("AT")) {
      const namespace = new Identifier(this.peek.value);
      this.consume("IDENTIFIER", "Expecting identifier");
      this.consume("COLON", "Expecting :");
      return new Namespace(namespace, this.#expression());
    }
    const token = this.peek;
    const error = new Error(`Unexpected token ${token.value}`);
    throw error;
  }
  #call() {
    const expression = this.#primary();
    if (this.match("OPEN_PAREN")) {
      const args = [];
      do {
        const name = this.#primary();
        this.consume("COLON", "Expecting :");
        const value = this.#expression();
        args.push(new Arg(name, value));
      } while (this.match("COMMA"));
      this.consume("CLOSE_PAREN", "Expecting )");
      return new Call(expression, args);
    }
    return expression;
  }
  #propertyAccess() {
    let expression = this.#call();
    while (this.match("DOT")) {
      const primary = this.#primary();
      expression = new PropertyAccess(expression, primary);
    }
    return expression;
  }
  #expression() {
    const expression = this.#propertyAccess();
    return expression;
  }
  subparse() {
    const result = this.#expression();
    return {
      expression: result,
      index: this.currentIdx
    };
  }
  parse() {
    const result = this.#expression();
    this.consume("EOF", "Expecting EOF");
    this.reset();
    return result;
  }
};

// libs/utils/src/lib/parser/prompt-parser.ts
var PromptParser = class {
  constructor(prompt) {
    this.prompt = prompt;
    this.tokens = tokeniser(this.prompt);
  }
  static {
    __name(this, "PromptParser");
  }
  tokens = [];
  objectives = ["extension", "table", "feature", "workflow"];
  firstObjective() {
    const idx = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const objectiveTokens = [];
    for (let i = idx; i < this.tokens.length; i++) {
      objectiveTokens.push(this.tokens[i]);
      if (this.tokens[i].type === "STRING") break;
    }
    if (objectiveTokens.length === 0) {
      throw new Error(`No namespace found in prompt: ${this.prompt}`);
    }
    const guessComplete = objectiveTokens.some((obj) => obj.type == "COLON");
    if (!guessComplete) {
      throw new Error(`Incomplete namespace found in prompt: ${this.prompt}`);
    }
    return {
      name: objectiveTokens[1].value,
      value: objectiveTokens.at(-1).value
    };
  }
  stripObjective() {
    const start = this.tokens.findIndex((token, index) => {
      if (token.type === "AT") {
        const nextToken = this.tokens[index + 1];
        if (nextToken && this.objectives.includes(nextToken.value)) {
          return true;
        }
      }
      return false;
    });
    const end = this.tokens.slice(start).findIndex((token) => token.type === "STRING");
    const toks = [...this.tokens];
    toks.splice(start, end + 1);
    return toks.map((token) => token.value).join("");
  }
  nearestLexeme(index) {
    const lexeme = this.tokens.findLast((token) => {
      return token.column < index;
    });
    return lexeme;
  }
  replaceLexeme(index, value) {
    const lexeme = this.nearestLexeme(index);
    console.log({ lexeme, index });
    if (lexeme) {
      lexeme.value = value;
    }
    return this;
  }
  format() {
    return this.tokens.map((token) => token.value).join("");
  }
};
function tokenisePrompt(prompt) {
  let index = 0;
  const lexemes = [];
  while (index < prompt.length) {
    const char = prompt[index];
    switch (char) {
      case "@":
        lexemes.push({
          type: "IDENTIFIER",
          value: prompt[index++],
          column: index
        });
        break;
      case " ":
        lexemes.push({
          type: "WHITESPACE",
          value: prompt[index++],
          column: index
        });
        break;
      default:
        {
          const token = lexemes.at(-1) ?? {
            type: "IDENTIFIER",
            value: "",
            column: index
          };
          token.value += char;
          index++;
          lexemes[lexemes.length - 1] = token;
        }
        break;
    }
  }
  return lexemes;
}
__name(tokenisePrompt, "tokenisePrompt");

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";
var RuleDecomposerVisitor = class extends Visitor {
  static {
    __name(this, "RuleDecomposerVisitor");
  }
  visitArg(node2) {
    const name = node2.name.accept(this);
    if (typeChecker.isNamespace(node2.value)) {
      const value2 = node2.value.accept(this);
      return `${name}: ${value2.id}`;
    }
    const value = node2.value.accept(this);
    return `${name}: ${value.id}`;
  }
  namespaces = {};
  visitBinary(node2) {
    const left = node2.left.accept(this);
    const right = node2.right.accept(this);
  }
  visitCall(node2) {
    const name = node2.name.accept(this);
    const args = node2.args.map((arg) => {
      return arg.accept(this);
    });
    return `${name}(${args.join(", ")})`;
  }
  visitPropertyAccess(node2) {
    return `${node2.name.accept(this)}.${node2.expression.accept(this)}`;
  }
  visitNamespace(node2) {
    const id = v4();
    const name = `@${node2.name.accept(this)}:${node2.expression.accept(this)}`;
    this.namespaces = {
      ...this.namespaces,
      [id]: name
    };
    return { id, name };
  }
  visitIdentifier(node2) {
    return node2.value;
  }
  visitStringLiteral(node2) {
    return `'${node2.value}'`;
  }
  visit(node2) {
    node2.accept(this);
    return this.namespaces;
  }
};
function decomposeVisitor(input) {
  const visitor = new RuleDecomposerVisitor();
  return visitor.visit(parseDsl(input));
}
__name(decomposeVisitor, "decomposeVisitor");

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/dockerfile/src/lib/declarative.ts
import { AsyncLocalStorage } from "node:async_hooks";
import { writeFile } from "node:fs/promises";
import { join as join2, normalize as normalize2 } from "node:path";
var store = new AsyncLocalStorage();
function followStage(stages, stage4) {
  return typeof stage4.from === "string" ? [stage4.from, stage4] : "image" in stage4.from ? [stage4.from.image, stage4] : (() => {
    const s = Object.entries(stages).find(([, stageValue]) => {
      return stageValue === stage4.from;
    });
    if (!s) {
      throw new Error(
        `Stage ${JSON.stringify(stage4.from.from)} not found`
      );
    }
    return s;
  })();
}
__name(followStage, "followStage");
function copyWriter(stages) {
  const writeCopy = /* @__PURE__ */ __name((workdir, copy) => {
    const lines = [];
    if (!copy) return lines;
    if ("link" in copy) {
      lines.push(...writeShortCopy(workdir, copy));
    } else {
      lines.push(...writePointToPointCopy(workdir, copy));
    }
    return lines;
  }, "writeCopy");
  const writeShortCopy = /* @__PURE__ */ __name((workdir, copy) => {
    const lines = [];
    const fixedPoint = normalize2(join2("/", copy.link, "/"));
    const path = fixedPoint.replace(/^\//, "./").replace(/\/$/, "");
    if (copy.from) {
      const relatedStage = followStage(stages, copy);
      lines.push(
        `COPY --from=${relatedStage[0]} ${normalize2(
          join2(
            store.getStore()?.stagesSet[relatedStage[0]].config.workdir || "",
            copy.link
          )
        )} ${path}`
      );
    } else {
      lines.push(`COPY ${path} ${path}`);
    }
    return lines;
  }, "writeShortCopy");
  function writePointToPointCopy(workdir, copy) {
    function normalizeDest(srcs, dest) {
      return dest === "." ? srcs.length === 1 ? "." : "./" : dest;
    }
    __name(normalizeDest, "normalizeDest");
    let instruction = "COPY";
    let copySrcs = (Array.isArray(copy.src) ? copy.src : [copy.src]).map(
      (src) => normalize2(join2(src))
    );
    if (copy.from) {
      const relatedStage = followStage(stages, copy);
      instruction = `COPY --from=${relatedStage[0]}`;
      copySrcs = copySrcs.map(
        (it) => `${normalize2(
          join2(
            store.getStore()?.stagesSet[relatedStage[0]].config.workdir || "",
            it
          )
        )}`
      );
    }
    if (!copy.dest) {
      const dest = ".";
      return [
        `${instruction} ${copySrcs.join(" ")} ${normalizeDest(copySrcs, dest)}`
      ];
    }
    if (typeof copy.dest === "string") {
      return [
        `${instruction} ${copySrcs.join(" ")} ${normalizeDest(copySrcs, copy.dest)}`
      ];
    } else {
      const lines = [
        copy.dest.create ? `RUN mkdir -p ${normalize2(join2("./", copy.dest.path))}` : "",
        `COPY ${copySrcs.join(" ")} ${normalize2(join2("./", normalizeDest(copySrcs, copy.dest.path)))}`
      ];
      return lines;
    }
  }
  __name(writePointToPointCopy, "writePointToPointCopy");
  return {
    writeCopy,
    writeShortCopy,
    writePointToPointCopy
  };
}
__name(copyWriter, "copyWriter");
function createWriter(stages) {
  let entrypoint;
  let cmd;
  let expose;
  let healthCheck;
  const stagesSet = {};
  return {
    cmd(value) {
      cmd = value;
    },
    entrypoint(value) {
      entrypoint = value;
    },
    expose(port) {
      expose = port;
    },
    healthCheck(value) {
      healthCheck = value;
    },
    addStage(name, stage4) {
      stagesSet[name] = stage4;
    },
    print: /* @__PURE__ */ __name(() => {
      return store.run({ stages, stagesSet }, () => {
        const lines = [];
        Object.entries(stagesSet).forEach(([name, stage4]) => {
          lines.push(...stage4.format(name, stages));
        });
        if (expose) {
          lines.push(`EXPOSE ${expose}`);
        }
        if (entrypoint && entrypoint.length) {
          lines.push(
            `ENTRYPOINT [${coerceArray(entrypoint).map((it) => safeFail(() => `"${JSON.parse(`"${it}"`)}"`, it)).join(", ")}]`
          );
        }
        if (healthCheck) {
          const flags = [];
          if (healthCheck.interval) {
            flags.push(`--interval=${healthCheck.interval}`);
          }
          if (healthCheck.timeout) {
            flags.push(`--timeout=${healthCheck.timeout}`);
          }
          if (healthCheck.retries) {
            flags.push(`--retries=${healthCheck.retries}`);
          }
          if (healthCheck.startPeriod) {
            flags.push(`--start-period=${healthCheck.startPeriod}`);
          }
          flags.push(`CMD ${healthCheck.test}`);
          lines.push(`HEALTHCHECK ${flags.join(" ")}`);
        }
        if (cmd && cmd.length) {
          lines.push(
            `CMD [${coerceArray(cmd).map((it) => safeFail(() => `"${JSON.parse(`"${it}"`)}"`, it)).join(", ")}]`
          );
        }
        return lines.join("\n").trim();
      });
    }, "print")
  };
}
__name(createWriter, "createWriter");
function coerceArray(value) {
  return Array.isArray(value) ? value : [value];
}
__name(coerceArray, "coerceArray");
function stageFactory(config) {
  config.environment ??= {};
  function env(name, value) {
    if (typeof name === "string" && value) {
      config.environment[name] = value;
      return this;
    }
    Object.entries(name).forEach(
      ([name2, value2]) => config.environment[name2] = value2
    );
    return this;
  }
  __name(env, "env");
  return {
    config,
    package(...packages) {
      config.packages = packages;
      return this;
    },
    from(from) {
      config.from = from;
      return this;
    },
    workdir(workdir) {
      config.workdir = workdir;
      return this;
    },
    addCopy(value) {
      if (!config.copy) {
        config.copy = value;
        return this;
      }
      value = Array.isArray(value) ? value : [value];
      if (Array.isArray(config.copy)) {
        config.copy = [...config.copy, ...value];
      } else {
        config.copy = [
          ...Array.isArray(config.copy) ? config.copy : [config.copy],
          ...value
        ];
      }
      return this;
    },
    addUser() {
      return this;
    },
    user(name) {
      config.user = name;
      return this;
    },
    addOutput(value) {
      config.output;
      return this;
    },
    env,
    format: /* @__PURE__ */ __name((name, stages) => {
      const lines = [];
      const pkgs = config.packages || [];
      const moreCopies = [];
      if (config.from) {
        lines.push("\n");
        const [from] = followStage(stages, config);
        lines.push(`FROM ${from} AS ${name}`);
      }
      const pm = typeof config.from === "string" ? "" : "pm" in config.from ? config.from.pm : "apt-get";
      if (pkgs.length) {
        if (pm === "apk") {
          lines.push(`RUN apk update && apk add --no-cache ${pkgs.join(" ")}`);
        } else {
          lines.push(
            `RUN apt-get update && apt-get install -y ${pkgs.join(" ")}`
          );
        }
      }
      if (config.workdir) {
        lines.push(`WORKDIR ${config.workdir}`);
      }
      if (config.copy) {
        const copies = Array.isArray(config.copy) ? config.copy : [config.copy];
        for (const copy of [...copies, ...moreCopies]) {
          lines.push(
            ...copyWriter(stages).writeCopy(
              config.workdir || "",
              typeof copy === "string" ? { src: copy } : copy
            )
          );
        }
      }
      Object.entries(config.environment ?? {}).forEach(([name2, value]) => {
        lines.push(`ENV ${name2}=${value}`);
      });
      const run = coerceArray(config.run ?? []);
      const userIndex = lines.length - 1;
      if (config.user) {
        lines.push(`USER ${config.user}`);
      }
      run.forEach((it) => {
        if (typeof it === "string") {
          if (it.trim()) {
            lines.push(`RUN ${it.trim()}`);
          }
        } else if (Array.isArray(it)) {
          const cmds = [
            "\\",
            ...it.map((l, index, arr) => {
              if (arr.length === index + 1) return `	${l}`;
              return `	${l} \\`;
            })
          ];
          lines.push(`RUN ${cmds.join("\n")}`);
        } else {
          const cmds = [it.cwd ? `cd ${it.cwd}` : "", ...coerceArray(it.cmd)].filter(Boolean).join(" && ");
          if (it.root) {
            lines.splice(userIndex, 0, `RUN ${cmds}`);
          } else {
            lines.push(`RUN ${cmds}`);
          }
        }
      });
      return lines;
    }, "format")
  };
}
__name(stageFactory, "stageFactory");
function dockerfile(config) {
  const dismantleStage = /* @__PURE__ */ __name((value) => Array.isArray(value) ? value[0] : value, "dismantleStage");
  config.stages ??= {};
  const stages = Object.entries(config.stages).reduce(
    (acc, [name, value]) => ({
      ...acc,
      [name]: dismantleStage(value)
    }),
    {}
  );
  const writer = createWriter(stages);
  const startStage = stageFactory(config.start).env(config.start.environment ?? {}).env("PORT", config.start.port);
  Object.entries(config.stages).forEach(([name, value]) => {
    const stageConfig = Array.isArray(value) ? typeof value[0] === "function" ? value[0](value[1]) : value[0] : value;
    writer.addStage(name, stageFactory(stageConfig));
    const output = (stageConfig.output ? Array.isArray(stageConfig.output) ? stageConfig.output : [stageConfig.output] : []).map((it) => {
      const src = typeof it === "string" ? it : it.src;
      const dest = typeof it === "string" ? it : it.dest;
      return {
        from: dismantleStage(value),
        src,
        dest
      };
    });
    startStage.addCopy(output);
  });
  writer.addStage("start", startStage);
  writer.expose(config.start.port);
  writer.entrypoint(config.start.entrypoint ?? []);
  writer.cmd(config.start.cmd ?? []);
  writer.healthCheck(config.start.healthCheck);
  return {
    print: /* @__PURE__ */ __name(() => writer.print(), "print"),
    save: /* @__PURE__ */ __name((filePath) => {
      return writeFile(filePath, writer.print(), "utf-8");
    }, "save"),
    run: /* @__PURE__ */ __name((options = {}) => {
      throw new Error("Not implemented");
    }, "run")
  };
}
__name(dockerfile, "dockerfile");

// libs/dockerfile/src/lib/servers.ts
function nodeServer(config) {
  if (typeof config === "string") {
    return {
      from: nodeServer,
      workdir: "/app",
      cmd: `node ${config}`,
      port: 3e3,
      user: "node",
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  const additionalProps = {};
  if (typeof config.entry === "string") {
    additionalProps.cmd = [`node`, config.entry];
  } else if (config.entry.type === "script") {
    additionalProps.cmd = ["npm", "run", config.entry.value];
  } else if (config.entry.type === "file") {
    additionalProps.cmd = ["npm", config.entry.value];
  } else {
    throw new Error("Invalid entry type");
  }
  return {
    workdir: "/app",
    port: 3e3,
    user: "node",
    ...config,
    ...additionalProps,
    from: config.from ?? nodeServer,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config.environment ?? {}
    }
  };
}
__name(nodeServer, "nodeServer");
denoServer.image = "denoland/deno:alpine";
denoServer.pm = "apk";
function denoServer(config) {
  if (typeof config === "string") {
    return {
      from: denoServer,
      workdir: "/app",
      cmd: [`deno`, "--allow-net", config],
      port: 8e3,
      user: "deno",
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  const additionalProps = {};
  if (config.entry.type === "script") {
    additionalProps.cmd = ["deno", "task", config.entry.value];
  } else if (config.entry.type === "file") {
    additionalProps.cmd = [
      "deno",
      "run",
      ...config.entry.flags,
      config.entry.value
    ];
  } else if (config.entry.type === "executable") {
    additionalProps.cmd = [`./${config.entry.value}`];
  } else {
    throw new Error("Invalid entry type");
  }
  return {
    workdir: "/app",
    ...additionalProps,
    port: 8e3,
    user: "deno",
    ...config,
    from: config.from ?? denoServer,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config.environment ?? {}
    }
  };
}
__name(denoServer, "denoServer");
nodeServer.image = "node:alpine";
nodeServer.pm = "apk";
nodeServer.dockerignore = [
  "**/node_modules/",
  "**/.git",
  "**/README.md",
  "**/LICENSE",
  "**/.vscode",
  "**/.idea",
  "**/npm-debug.log",
  "**/coverage*",
  "**/.env",
  "**/.editorconfig",
  "**/.aws",
  "**/dist",
  "**/build",
  "**/.output",
  "**/output",
  "**/tmp",
  "**/test-results",
  "**/tests",
  "**/__tests__",
  "**/docs",
  ".dockerignore",
  "docker-compose*",
  ".gitignore",
  "Dockerfile*",
  "Jenkinsfile*",
  "helm-charts",
  "Makefile",
  "Thumbs.db",
  ".DS_Store"
];
function bunServer(config) {
  if (typeof config === "string") {
    return {
      from: bunServer,
      user: "bun",
      workdir: "/app",
      port: 3e3,
      cmd: `bun ${config}`,
      environment: {
        NODE_ENV: "production",
        HOST: "0.0.0.0"
      }
    };
  }
  return {
    user: "bun",
    workdir: "/app",
    port: 3e3,
    cmd: ["bun", "run", config.entry],
    ...config,
    from: config.from ?? bunServer,
    environment: {
      NODE_ENV: "production",
      HOST: "0.0.0.0",
      ...config.environment ?? {}
    }
  };
}
__name(bunServer, "bunServer");
bunServer.image = "oven/bun:1";
function nginx(config = {}) {
  return {
    workdir: "/usr/share/nginx/html",
    user: "nginx",
    port: 8080,
    cmd: ["nginx", "-g", '"daemon off;"'],
    environment: {},
    healthCheck: {
      test: "curl -f / || exit 1"
    },
    ...config,
    from: config.from ?? "nginxinc/nginx-unprivileged"
  };
}
__name(nginx, "nginx");
function httpd() {
  return {
    from: "httpd:alpine",
    workdir: "/usr/local/apache2/htdocs/",
    user: "nginx",
    port: 80,
    cmd: 'nginx -g "daemon off;"',
    environment: {}
  };
}
__name(httpd, "httpd");
denoServer.dockerignore = [...nodeServer.dockerignore, ".vscode"];

// libs/dockerfile/src/lib/utils.ts
function knownPackageManager(userSepcified) {
  if (!userSepcified) {
    return false;
  }
  return ["yarn", "npm", "pnpm"].includes(userSepcified);
}
__name(knownPackageManager, "knownPackageManager");
var packageManagerCommands = {
  npm: {
    install: "npm ci",
    build: "npm run build"
  },
  yarn: {
    install: "yarn --frozen-lockfile",
    build: "yarn run build"
  },
  pnpm: {
    install: "corepack enable pnpm && pnpm i --frozen-lockfile",
    build: "corepack enable pnpm && pnpm run build"
  },
  bun: {
    install: "bun install --frozen-lockfile",
    build: "bun run build"
  }
};
var guessPackageManager = {
  build: [
    "if [ -f yarn.lock ]; then yarn run build;",
    "elif [ -f package-lock.json ]; then npm run build;",
    "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
    'else echo "Lockfile not found." && exit 1;',
    "fi"
  ],
  install: [
    "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
    "elif [ -f package-lock.json ]; then npm ci;",
    "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
    'else echo "Lockfile not found." && exit 1;',
    "fi"
  ]
};
function stage(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage, "stage");

// libs/dockerfile/src/lib/angular.ts
var base = {
  from: nodeServer,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps = /* @__PURE__ */ __name((options) => ({
  from: base,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ]
}), "deps");
var builder = /* @__PURE__ */ __name((packageManager) => ({
  from: base,
  workdir: "/app",
  copy: [
    {
      from: deps,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ]
}), "builder");
var angular = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    base: stage(base),
    deps: stage(deps, {
      packageManager: config.packageManager,
      mode: config.mode
    }),
    builder: stage(builder, config.packageManager)
  },
  start: config.mode === "spa" ? nginx({
    copy: {
      from: builder,
      src: `${config.outputPath}/browser`
    }
  }) : nodeServer({
    from: base,
    copy: {
      from: builder,
      src: config.outputPath
    },
    entry: "server/server.mjs"
  })
}), "angular");
angular.dockerignore = [...nodeServer.dockerignore, ".angular"];

// libs/dockerfile/src/lib/astro.ts
var base2 = {
  from: nodeServer,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps2 = /* @__PURE__ */ __name((options) => ({
  from: base2,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ],
  output: options.mode !== "static" ? ["node_modules"] : []
}), "deps");
var builder2 = /* @__PURE__ */ __name((packageManager) => ({
  from: base2,
  workdir: "/app",
  copy: [
    {
      from: deps2,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ],
  output: [{ src: "dist", dest: "." }]
}), "builder");
var astrojs = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage(base2),
    deps: stage(deps2, {
      packageManager: options.packageManager,
      mode: options.mode
    }),
    builder: stage(builder2, options.packageManager)
  },
  start: options.mode === "static" ? nginx() : nodeServer({
    from: base2,
    entry: "server/entry.mjs"
  })
}), "astrojs");
astrojs.dockerignore = [...nodeServer.dockerignore, ".astro"];

// libs/dockerfile/src/lib/bun.ts
var base3 = {
  from: "oven/bun:1",
  packages: ["wget"]
};
var installDev = {
  from: base3,
  copy: [
    {
      src: ["package.json", "bun.lockb"],
      dest: {
        path: "/temp/dev",
        create: true
      }
    }
  ],
  run: [
    {
      cwd: "/temp/dev",
      cmd: "bun install --frozen-lockfile"
    }
  ]
};
var installProd = {
  from: base3,
  copy: [
    {
      src: ["package.json", "bun.lockb"],
      dest: {
        path: "/temp/prod",
        create: true
      }
    }
  ],
  run: [
    {
      cwd: "/temp/prod",
      cmd: "bun install --frozen-lockfile --production"
    }
  ]
};
var prerelease = {
  from: base3,
  copy: [
    {
      src: "/temp/dev/node_modules",
      dest: "node_modules"
    },
    { link: "." }
  ],
  run: "bun run ./src/index.ts"
};
var release = {
  from: base3,
  copy: [
    {
      src: "/temp/prod/node_modules",
      dest: "node_modules"
    },
    { from: prerelease, link: "." }
  ]
};
var deps3 = {
  from: base3,
  workdir: "/app",
  copy: ["package.json", "bun.lockb"],
  run: "bun install --frozen-lockfile"
};
var builder3 = /* @__PURE__ */ __name((config) => ({
  from: deps3,
  workdir: "/app",
  copy: [{ from: deps3, link: "node_modules" }, "."],
  run: config.buildCommand,
  output: config.entrypoint
}), "builder");
var bun = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    base: base3,
    deps: deps3,
    builder: stage(builder3, config)
  },
  start: bunServer({
    from: base3,
    entry: "index.js"
  })
}), "bun");
bun.dockerignore = [...nodeServer.dockerignore];

// libs/dockerfile/src/lib/deno.ts
var base4 = {
  from: "denoland/deno:alpine",
  workdir: "/app"
};
var deps4 = {
  from: base4,
  workdir: "/app",
  copy: ["deno.{json*,lock}"],
  run: "deno install"
};
var builder4 = {
  from: deps4,
  workdir: "/app",
  copy: ".",
  run: "deno compile --allow-net --allow-env --output entry main.ts"
};
var deno = /* @__PURE__ */ __name(() => dockerfile({
  stages: { base: base4, deps: deps4, builder: builder4 },
  start: denoServer({
    from: base4,
    entry: {
      type: "executable",
      value: "entry"
    },
    copy: {
      from: builder4,
      link: "entry"
    }
  })
}), "deno");
deno.dockerignore = [...nodeServer.dockerignore];

// libs/dockerfile/src/lib/dotnet.ts
var build = /* @__PURE__ */ __name((config) => ({
  from: "mcr.microsoft.com/dotnet/sdk",
  workdir: "/app",
  copy: ".",
  run: [
    `dotnet restore ${config.projectFile}`,
    `dotnet publish -c Release -o out ${config.projectFile}`
  ]
}), "build");
var dotnet = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    build: stage(build, { projectFile: `${config.projectName}.csproj` })
  },
  start: {
    packages: ["curl"],
    from: "mcr.microsoft.com/dotnet/aspnet:8.0",
    workdir: "/app",
    copy: { from: build, src: "out" },
    port: 8080,
    entrypoint: ["dotnet", `${config.projectName}.dll`],
    healthCheck: {
      test: `curl -f ${config.healthCheck} || exit 1`
    }
  }
}), "dotnet");
dotnet.dockerignore = [
  ...nodeServer.dockerignore,
  "# Created by https://www.gitignore.io/api/csharp",
  "",
  "### Csharp ###",
  "## Ignore Visual Studio temporary files, build results, and",
  "## files generated by popular Visual Studio add-ons.",
  "",
  "# User-specific files",
  "*.suo",
  "*.user",
  "*.userosscache",
  "*.sln.docstates",
  "",
  "# User-specific files (MonoDevelop/Xamarin Studio)",
  "*.userprefs",
  "",
  "# Build results",
  "# [Dd]ebug/",
  "[Dd]ebugPublic/",
  "[Rr]elease/",
  "[Rr]eleases/",
  "x64/",
  "x86/",
  "bld/",
  "# [Bb]in/",
  "[Oo]bj/",
  "[Ll]og/",
  "",
  "# Visual Studio 2015 cache/options directory",
  ".vs/",
  "# Uncomment if you have tasks that create the project's static files in wwwroot",
  "#wwwroot/",
  "",
  "# MSTest test Results",
  "[Tt]est[Rr]esult*/",
  "[Bb]uild[Ll]og.*",
  "",
  "# NUNIT",
  "*.VisualState.xml",
  "TestResult.xml",
  "",
  "# Build Results of an ATL Project",
  "[Dd]ebugPS/",
  "[Rr]eleasePS/",
  "dlldata.c",
  "",
  "# DNX",
  "project.lock.json",
  "project.fragment.lock.json",
  "artifacts/",
  "Properties/launchSettings.json",
  "",
  "*_i.c",
  "*_p.c",
  "*_i.h",
  "*.ilk",
  "*.meta",
  "*.obj",
  "*.pch",
  "*.pdb",
  "*.pgc",
  "*.pgd",
  "*.rsp",
  "*.sbr",
  "*.tlb",
  "*.tli",
  "*.tlh",
  "*.tmp",
  "*.tmp_proj",
  "*.log",
  "*.vspscc",
  "*.vssscc",
  ".builds",
  "*.pidb",
  "*.svclog",
  "*.scc",
  "",
  "# Chutzpah Test files",
  "_Chutzpah*",
  "",
  "# Visual C++ cache files",
  "ipch/",
  "*.aps",
  "*.ncb",
  "*.opendb",
  "*.opensdf",
  "*.sdf",
  "*.cachefile",
  "*.VC.db",
  "*.VC.VC.opendb",
  "",
  "# Visual Studio profiler",
  "*.psess",
  "*.vsp",
  "*.vspx",
  "*.sap",
  "",
  "# TFS 2012 Local Workspace",
  "$tf/",
  "",
  "# Guidance Automation Toolkit",
  "*.gpState",
  "",
  "# ReSharper is a .NET coding add-in",
  "_ReSharper*/",
  "*.[Rr]e[Ss]harper",
  "*.DotSettings.user",
  "",
  "# JustCode is a .NET coding add-in",
  ".JustCode",
  "",
  "# TeamCity is a build add-in",
  "_TeamCity*",
  "",
  "# DotCover is a Code Coverage Tool",
  "*.dotCover",
  "",
  "# Visual Studio code coverage results",
  "*.coverage",
  "*.coveragexml",
  "",
  "# NCrunch",
  "_NCrunch_*",
  ".*crunch*.local.xml",
  "nCrunchTemp_*",
  "",
  "# MightyMoose",
  "*.mm.*",
  "AutoTest.Net/",
  "",
  "# Web workbench (sass)",
  ".sass-cache/",
  "",
  "# Installshield output folder",
  "[Ee]xpress/",
  "",
  "# DocProject is a documentation generator add-in",
  "DocProject/buildhelp/",
  "DocProject/Help/*.HxT",
  "DocProject/Help/*.HxC",
  "DocProject/Help/*.hhc",
  "DocProject/Help/*.hhk",
  "DocProject/Help/*.hhp",
  "DocProject/Help/Html2",
  "DocProject/Help/html",
  "",
  "# Click-Once directory",
  "publish/",
  "",
  "# Publish Web Output",
  "*.[Pp]ublish.xml",
  "*.azurePubxml",
  "# TODO: Comment the next line if you want to checkin your web deploy settings",
  "# but database connection strings (with potential passwords) will be unencrypted",
  "*.pubxml",
  "*.publishproj",
  "",
  "# Microsoft Azure Web App publish settings. Comment the next line if you want to",
  "# checkin your Azure Web App publish settings, but sensitive information contained",
  "# in these scripts will be unencrypted",
  "PublishScripts/",
  "",
  "# NuGet Packages",
  "*.nupkg",
  "# The packages folder can be ignored because of Package Restore",
  "**/packages/*",
  "# except build/, which is used as an MSBuild target.",
  "!**/packages/build/",
  "# Uncomment if necessary however generally it will be regenerated when needed",
  "#!**/packages/repositories.config",
  "# NuGet v3's project.json files produces more ignoreable files",
  "*.nuget.props",
  "*.nuget.targets",
  "",
  "# Microsoft Azure Build Output",
  "csx/",
  "*.build.csdef",
  "",
  "# Microsoft Azure Emulator",
  "ecf/",
  "rcf/",
  "",
  "# Windows Store app package directories and files",
  "AppPackages/",
  "BundleArtifacts/",
  "Package.StoreAssociation.xml",
  "_pkginfo.txt",
  "",
  "# Visual Studio cache files",
  "# files ending in .cache can be ignored",
  "*.[Cc]ache",
  "# but keep track of directories ending in .cache",
  "!*.[Cc]ache/",
  "",
  "# Others",
  "ClientBin/",
  "~$*",
  "*~",
  "*.dbmdl",
  "*.dbproj.schemaview",
  "*.jfm",
  "*.pfx",
  "*.publishsettings",
  "node_modules/",
  "orleans.codegen.cs",
  "",
  "# Since there are multiple workflows, uncomment next line to ignore bower_components",
  "# (https://github.com/github/gitignore/pull/1529#issuecomment-104372622)",
  "#bower_components/",
  "",
  "# RIA/Silverlight projects",
  "Generated_Code/",
  "",
  "# Backup & report files from converting an old project file",
  "# to a newer Visual Studio version. Backup files are not needed,",
  "# because we have git ;-)",
  "_UpgradeReport_Files/",
  "Backup*/",
  "UpgradeLog*.XML",
  "UpgradeLog*.htm",
  "",
  "# SQL Server files",
  "*.mdf",
  "*.ldf",
  "",
  "# Business Intelligence projects",
  "*.rdl.data",
  "*.bim.layout",
  "*.bim_*.settings",
  "",
  "# Microsoft Fakes",
  "FakesAssemblies/",
  "",
  "# GhostDoc plugin setting file",
  "*.GhostDoc.xml",
  "",
  "# Node.js Tools for Visual Studio",
  ".ntvs_analysis.dat",
  "",
  "# Visual Studio 6 build log",
  "*.plg",
  "",
  "# Visual Studio 6 workspace options file",
  "*.opt",
  "",
  "# Visual Studio 6 auto-generated workspace file (contains which files were open etc.)",
  "*.vbw",
  "",
  "# Visual Studio LightSwitch build output",
  "**/*.HTMLClient/GeneratedArtifacts",
  "**/*.DesktopClient/GeneratedArtifacts",
  "**/*.DesktopClient/ModelManifest.xml",
  "**/*.Server/GeneratedArtifacts",
  "**/*.Server/ModelManifest.xml",
  "_Pvt_Extensions",
  "",
  "# Paket dependency manager",
  ".paket/paket.exe",
  "paket-files/",
  "",
  "# FAKE - F# Make",
  ".fake/",
  "",
  "# JetBrains Rider",
  ".idea/",
  "*.sln.iml",
  "",
  "# CodeRush",
  ".cr/",
  "",
  "# Python Tools for Visual Studio (PTVS)",
  "__pycache__/",
  "*.pyc",
  "",
  "# Cake - Uncomment if you are using it",
  "tools/",
  "tools/Cake.CoreCLR",
  "tools",
  ".dotnet"
];

// libs/dockerfile/src/lib/nextjs.ts
var base5 = {
  from: nodeServer,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps5 = /* @__PURE__ */ __name((config) => ({
  from: base5,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(config.packageManager) ? guessPackageManager.install : packageManagerCommands[config.packageManager].install
  ],
  output: config.mode === "export" ? [] : ["node_modules"]
}), "deps");
var builder5 = /* @__PURE__ */ __name((config) => ({
  from: base5,
  workdir: "/app",
  copy: [
    {
      from: deps5,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    config.mode === "export" ? "" : "mkdir -p ./public",
    !knownPackageManager(config.packageManager) ? guessPackageManager.build : packageManagerCommands[config.packageManager].build
  ],
  environment: {
    NEXT_TELEMETRY_DISABLED: "1"
  },
  output: config.mode === "export" ? [{ src: "out", dest: "." }] : config.mode === "standalone" ? [
    "public",
    ".next/static",
    {
      src: ".next/standalone",
      dest: "."
    }
  ] : ["public", ".next"]
}), "builder");
function stage2(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage2, "stage");
var nextjs = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage2(base5),
    deps: stage2(deps5, options),
    builder: stage2(builder5, options)
  },
  start: options.mode === "export" ? nginx() : nodeServer({
    from: base5,
    entry: {
      ...options.mode === "standalone" ? { type: "file", value: "server.js" } : { type: "script", value: "start" }
    },
    environment: {
      NEXT_TELEMETRY_DISABLED: "1"
    },
    copy: "package.json"
  })
}), "nextjs");
nextjs.dockerignore = [...nodeServer.dockerignore, ".next"];

// libs/dockerfile/src/lib/node.ts
import { basename, dirname } from "path";
var base6 = {
  from: nodeServer
};
var deps6 = /* @__PURE__ */ __name((config) => ({
  from: base6,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(config.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config.packageManager].install
  ]
}), "deps");
var builder6 = /* @__PURE__ */ __name((config) => ({
  from: deps6,
  workdir: "/app",
  copy: [{ from: deps6, link: "node_modules" }, "."],
  run: [
    !knownPackageManager(config.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[config.packageManager].build
  ]
}), "builder");
var node = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    base: base6,
    deps: stage(deps6, config),
    ...config.shouldBuild ? { builder: stage(builder6, config) } : {}
  },
  start: nodeServer({
    from: base6,
    entry: config.entrypoint,
    copy: [
      config.shouldBuild ? [{ from: builder6, link: basename(dirname(config.entrypoint)) }] : [{ from: deps6, link: "node_modules" }, "."]
    ].flat()
  })
}), "node");
node.dockerignore = [...nodeServer.dockerignore];

// libs/dockerfile/src/lib/nuxtjs.ts
var base7 = {
  from: nodeServer,
  packages: ["libc6-compat"]
};
var deps7 = /* @__PURE__ */ __name((packageManager) => ({
  from: base7,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].install
  ],
  output: ["node_modules"]
}), "deps");
var builder7 = /* @__PURE__ */ __name((config) => {
  const buildScript = config.mode === "static" ? "generate" : "build";
  return {
    from: base7,
    workdir: "/app",
    copy: [
      {
        from: deps7,
        link: "node_modules"
      },
      { link: "." }
    ],
    run: [
      !knownPackageManager(config.packageManager) ? [
        `if [ -f yarn.lock ]; then yarn run ${buildScript};`,
        `elif [ -f package-lock.json ]; then npm run ${buildScript};`,
        `elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run ${buildScript};`,
        'else echo "Lockfile not found." && exit 1;',
        "fi"
      ] : packageManagerCommands[config.packageManager].build.replace(
        "build",
        buildScript
      )
    ],
    environment: {
      NUXT_TELEMETRY_DISABLED: "1"
    },
    output: config.mode === "static" ? [
      {
        src: ".output/public",
        dest: "."
      }
    ] : [".output"]
  };
}, "builder");
var nuxtjs = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    base: stage(base7),
    deps: stage(deps7, config.packageManager),
    builder: stage(builder7, config)
  },
  start: config.mode === "static" ? nginx() : nodeServer({
    from: base7,
    entry: ".output/server/index.mjs",
    environment: {
      NUXT_TELEMETRY_DISABLED: "1"
    }
  })
}), "nuxtjs");
nuxtjs.dockerignore = [...nodeServer.dockerignore, ".nuxt"];

// libs/dockerfile/src/lib/remix.ts
var base8 = {
  from: nodeServer,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps8 = /* @__PURE__ */ __name((options) => ({
  from: base8,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(options.packageManager) ? [
      "if [ -f yarn.lock ]; then yarn --frozen-lockfile;",
      "elif [ -f package-lock.json ]; then npm ci;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[options.packageManager].install
  ]
}), "deps");
var builder8 = /* @__PURE__ */ __name((packageManager) => ({
  from: base8,
  workdir: "/app",
  copy: [
    {
      from: deps8,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? [
      "if [ -f yarn.lock ]; then yarn run build;",
      "elif [ -f package-lock.json ]; then npm run build;",
      "elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm run build;",
      'else echo "Lockfile not found." && exit 1;',
      "fi"
    ] : packageManagerCommands[packageManager].build
  ]
}), "builder");
var remix = /* @__PURE__ */ __name((config) => dockerfile({
  stages: {
    base: stage(base8),
    deps: stage(deps8, {
      packageManager: config.packageManager,
      mode: config.mode
    }),
    builder: stage(builder8, config.packageManager)
  },
  start: config.mode === "spa" ? nginx({
    copy: [{ from: builder8, src: "build/client" }]
  }) : nodeServer({
    from: base8,
    entry: {
      type: "script",
      value: "start"
    },
    copy: [
      { from: builder8, link: "build" },
      { from: deps8, link: "node_modules" },
      "package.json"
    ]
  })
}), "remix");
remix.dockerignore = [...nodeServer.dockerignore, ".astro"];

// libs/dockerfile/src/lib/streamlit.ts
var base9 = {
  from: "python:3.9-slim",
  packages: ["build-essential", "curl", "software-properties-common", "git"],
  run: ["rm -rf /var/lib/apt/lists/*"]
};
var streamlit = /* @__PURE__ */ __name(() => dockerfile({
  stages: { base: base9 },
  start: {
    from: base9,
    workdir: "/app",
    copy: [
      // 'requirements.txt',
      "."
    ],
    run: "pip3 install -r requirements.txt",
    port: 8501,
    healthCheck: {
      test: "curl --fail http://localhost:8501/_stcore/health"
    },
    cmd: ["app.py", "--server.port=8501", "--server.address=0.0.0.0"],
    entrypoint: ["streamlit", "run"]
  }
}), "streamlit");
streamlit.dockerignore = [
  ...nodeServer.dockerignore,
  "__pycache__/",
  "*.pyc",
  "venv/"
];

// libs/dockerfile/src/lib/vite.ts
var base10 = {
  from: nodeServer,
  workdir: "/app",
  packages: ["libc6-compat"]
};
var deps9 = /* @__PURE__ */ __name((config) => ({
  from: base10,
  workdir: "/app",
  copy: {
    src: [
      "package.json",
      "yarn.lock*",
      "package-lock.json*",
      "pnpm-lock.yaml*"
    ],
    dest: "."
  },
  run: [
    !knownPackageManager(config.packageManager) ? guessPackageManager.install : packageManagerCommands[config.packageManager].install
  ]
}), "deps");
var builder9 = /* @__PURE__ */ __name((packageManager) => ({
  from: base10,
  workdir: "/app",
  copy: [
    {
      from: deps9,
      link: "node_modules"
    },
    { link: "." }
  ],
  run: [
    !knownPackageManager(packageManager) ? guessPackageManager.build : packageManagerCommands[packageManager].build
  ]
}), "builder");
function stage3(stageConfig, options) {
  if (options) {
    return [stageConfig, options];
  }
  return [stageConfig];
}
__name(stage3, "stage");
var vite = /* @__PURE__ */ __name((options) => dockerfile({
  stages: {
    base: stage3(base10),
    deps: stage3(deps9, {
      packageManager: options.packageManager
    }),
    builder: stage3(builder9, options.packageManager)
  },
  start: nginx({
    copy: { from: builder9, src: "dist" }
  })
}), "vite");
vite.dockerignore = [...nodeServer.dockerignore];

// libs/extensions/src/fly/index.ts
import dedent from "dedent";
import yaml from "js-yaml";
var deployContent = /* @__PURE__ */ __name((withBuild) => {
  const buildSteps = [
    {
      id: "setup_node",
      uses: "actions/setup-node@v3",
      name: "Setup Node.js",
      with: {
        "node-version": "20",
        cache: "npm"
      }
    },
    {
      id: "cache_deps",
      name: "Cache Or Restore Node Modules.",
      uses: "actions/cache@v3",
      with: {
        path: "node_modules",
        key: "${{ runner.os }}-node-${{ hashFiles('package-lock.json') }}"
      }
    },
    {
      id: "install_deps",
      name: "Install project dependencies.",
      run: "npm install --no-audit --no-fund",
      if: `steps.cache_deps.outputs.cache-hit != 'true'`
    },
    {
      name: "Build",
      run: "npm run build"
    }
  ];
  return yaml.dump(
    {
      name: "Deploy To Fly.io",
      on: {
        push: {
          branches: ["main"]
        },
        workflow_dispatch: {}
      },
      concurrency: {
        group: "${{ github.workflow }}-${{ github.event.pull_request.number || github.ref }}",
        "cancel-in-progress": true
      },
      jobs: {
        deploy_to_fly: {
          "runs-on": "ubuntu-latest",
          steps: [
            {
              id: "checkout",
              name: "checkout App Repo",
              uses: "actions/checkout@v3"
            },
            ...withBuild ? buildSteps : [],
            {
              name: "Setup Fly.io cli.",
              uses: "superfly/flyctl-actions/setup-flyctl@master"
            },
            {
              name: "Deploying ...",
              run: `flyctl deploy --app \${{ secrets.FLY_APP_NAME }} --remote-only`,
              env: {
                FLY_API_TOKEN: `\${{ secrets.FLY_API_TOKEN }}`
              }
            }
          ]
        }
      }
    },
    {
      skipInvalid: false,
      noRefs: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }
  );
}, "deployContent");
var fly = /* @__PURE__ */ __name((options = { runBuildInDocker: true }) => {
  options.runBuildInDocker = options.runBuildInDocker ?? true;
  return {
    packages: {},
    files: {
      "../.github/workflows/deploy-fly.yml": deployContent(
        !options.runBuildInDocker
      ),
      "../.dockerignore": node.dockerignore.join("\n"),
      "../Dockerfile": dedent`
FROM node:alpine AS base
WORKDIR /app

# Install dependencies
FROM base AS devdeps
WORKDIR /app
COPY package.json ./
RUN npm install --production=false

# Build the app
FROM base AS builder
WORKDIR /app
COPY --from=devdeps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM base AS proddeps
WORKDIR /app
COPY --from=devdeps /app/node_modules ./node_modules
COPY --from=builder /app/output/build/ ./build/
COPY --from=builder /app/output/package.json ./package.json
RUN npm install --omit=dev --legacy-peer-deps

FROM base AS runner
WORKDIR /app

COPY --from=proddeps /app/node_modules ./node_modules
COPY --from=builder /app/output/build/ ./build/
COPY --from=builder /app/output/package.json ./package.json

RUN mkdir -p /app/db
RUN chown -R node:node /app/db

ENV NODE_ENV=production
ENV PORT=3000

USER node
EXPOSE 3000

CMD ["node", "build/server.js"]
    `,
      "src/server.ts": `import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import application from './app';
import { relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { showRoutes } from 'hono/dev'
import ip from 'ip';
import boxen from 'boxen';
import glob from 'fast-glob';
import { pretty } from '@january/console';
import './startup.ts';
const dirRelativeToCwd = relative(process.cwd(), import.meta.dirname);

  application.use(
    '/:filename{.+\\.png$}',
    serveStatic({ root: dirRelativeToCwd })
  );

  application.use('/:filename{.+\\.swagger\\.json$}', serveStatic({
    root: dirRelativeToCwd,
    rewriteRequestPath: (path) => path.split('/').pop() as string,
  }));

const port = parseInt(process.env.PORT ?? '3000', 10)
serve({
  fetch: application.fetch,
  port: port,
});

if(process.env.NODE_ENV === 'development'){
  showRoutes(application, { verbose: true });
}

pretty.network(port);
pretty.swagger('*.swagger.json', import.meta.dirname)
`
    }
  };
}, "fly");
export {
  fly
};
//# sourceMappingURL=index.js.map
