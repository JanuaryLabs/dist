// libs/extensions/src/identity/authorize.txt
var authorize_default = "import {\n  ProblemDetails,\n  ProblemDetailsException,\n} from 'rfc-7807-problem-details';\n\nexport function authorize<T>(\n  ...routePolicies: ((context: T) => Promise<boolean> | boolean)[]\n) {\n  return async (context: T, next: any) => {\n    for (const policy of routePolicies) {\n      if (!await policy(context)) {\n        throw new ProblemDetailsException(\n          new ProblemDetails('forbidden', 'no sufficient permissions', 403),\n        );\n      }\n    }\n    await next();\n  };\n}\n";

// libs/extensions/src/identity/index.ts
var identity = {
  id: "identity",
  packages: {
    "ua-parser-js": {
      version: "^1.0.37",
      dev: false
    },
    "@types/ua-parser-js": {
      version: "^0.7.39",
      dev: true
    },
    "@types/request-ip": {
      version: "^0.0.41",
      dev: true
    },
    "request-ip": {
      version: "^3.3.0",
      dev: false
    }
  },
  files: {
    "src/extensions/identity/authorize.ts": authorize_default
    // 'src/extensions/identity/subject.ts': subjectText,
  }
};
export {
  identity
};
//# sourceMappingURL=index.js.map
