var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/extensions/src/node-cron/index.ts
import * as morph from "ts-morph";

// libs/compiler/contracts/src/contract.ts
import dedent from "dedent";
import { Project, VariableDeclarationKind } from "ts-morph";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function toLiteralObject(obj) {
  if (Array.isArray(obj)) {
    return toLitObject(Object.fromEntries(obj), (value) => {
      try {
        if ("value" in value) {
          return value.value;
        }
      } catch (e) {
        return value;
      }
    });
  }
  return toLitObject(obj, (value) => {
    try {
      if ("value" in value) {
        return value.value;
      }
    } catch (e) {
      return value;
    }
  });
}
function uniquify(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}

// libs/compiler/contracts/src/contract.ts
var Contracts;
((Contracts2) => {
  function fffffff(input) {
    const [namespace, value] = input.split(":");
    return {
      namespace,
      value
    };
  }
})(Contracts || (Contracts = {}));
function nonStatic(inputs) {
  return Object.entries(inputs).filter(([name, prop]) => !prop.static);
}
function nonStaticInputs(inputs, predicate = ([, prop]) => !prop.data?.["local"]) {
  const unique = uniquify(
    nonStatic(inputs).filter(([name, prop]) => predicate([name, prop])),
    ([name, prop]) => paramName([name, prop])
  );
  return unique.map(([name, prop]) => {
    return [paramName([name, prop]), prop];
  });
}
function paramName([name, prop]) {
  return prop.data?.["parameterName"] || name;
}

// libs/compiler/sdk/devkit/src/lib/project-config.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var _config;
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
ProjectConfig = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join } from "path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";
var config = {
  basePath: "./src",
  extensions: "./src/extensions",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join("#{relative}", config.basePath, importPath);
  };
  makeEntityImportSpecifier = (tableName) => {
    return join("#{entity}", pascalcase(tableName));
  };
  makeFeatureFile = (featureName, fileName) => join(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeEntityPath = (featureName, tableName, suffix) => join(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  );
  makeQueryPath = (tableName, queryName) => join(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectFS);
var makeFeatureFile = (featureName, fileName) => join(config.features, spinalcase2(featureName), fileName);
var makeJobRoutePath = (featureName, routeName) => makeFeatureFile(
  featureName,
  join("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
);
var makeControllerPath = (featureName, suffix = "router") => makeFeatureFile(
  featureName,
  `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
);

// libs/extensions/src/node-cron/index.ts
var triggers = ["cd76caa3-e9f0-49b8-bf7a-0ebed83bd486"];
var nodeCron = {
  id: "node-cron",
  packages: {
    "node-cron": { version: "^3.0.3", dev: false },
    "@types/node-cron": { version: "^3.0.11", dev: true }
  },
  files: {},
  onFeature: (contract, { fs }) => {
    const workflows = contract.workflows.filter(
      (it) => triggers.includes(it.trigger.sourceId)
    );
    if (workflows.length === 0) {
      return {};
    }
    return {
      [makeControllerPath(contract.displayName, "cron")]: [
        {
          kind: morph.StructureKind.ImportDeclaration,
          moduleSpecifier: "node-cron",
          namedImports: ["schedule"]
        },
        ...contract.workflows.map((it) => it.trigger.policies).flat().map(
          (it) => ({
            kind: morph.StructureKind.ImportDeclaration,
            moduleSpecifier: `../../identity/${spinalcase2(it)}.policy`,
            namedImports: [camelcase(it)]
          })
        ),
        {
          kind: morph.StructureKind.ImportDeclaration,
          moduleSpecifier: `./jobs`,
          namespaceImport: "jobs"
        },
        ...workflows.map((contract2) => {
          const options = [];
          if ("immediate" in contract2.trigger.details) {
            options.push(["runOnInit", contract2.trigger.details["immediate"]]);
          }
          const displayName = `jobs.${camelcase(contract2.trigger.displayName)}`;
          const authorize = contract2.trigger.policies.length ? `,${contract2.trigger.policies.map((it) => `${camelcase(it)}`).join(",")}` : "";
          return `schedule(
  '${contract2.trigger.details["pattern"]}'
  ${authorize},
  ${displayName},
  ${options.length ? toLiteralObject(options) : ""}

);
`;
        })
      ],
      ...workflows.reduce((acc, it) => {
        return {
          ...acc,
          [makeJobRoutePath(contract.displayName, it.displayName)]: processTrigger(it.trigger, {})
        };
      }, {})
    };
  }
};
function processTrigger(contract, workflowInputs) {
  const displayName = camelcase(contract.displayName);
  const inputName = camelcase("input");
  const vars = {};
  const inputParams = nonStaticInputs({ ...contract.inputs });
  const actionInputsStr = toLiteralObject(
    inputParams.map(
      ([name, prop]) => [
        name,
        {
          ...prop,
          value: `payload.${prop.value}`
        }
      ]
    )
  );
  const workflowLoneParams = nonStaticInputs({ ...workflowInputs });
  for (const [name, prop] of workflowLoneParams) {
    vars[name] = `const ${name} = ${prop.value}`;
  }
  const workflowParams = [];
  if (inputParams.length) {
    workflowParams.push(inputName);
  }
  if (workflowLoneParams.length) {
    workflowParams.push(...workflowLoneParams.map(([name]) => name));
  }
  const workflowInputsStructures = Object.values(workflowInputs).map((prop) => prop.structure).filter(Boolean);
  return [
    ...workflowInputsStructures.flat(),
    {
      kind: morph.StructureKind.ImportDeclaration,
      moduleSpecifier: `../${spinalcase2(contract.tag)}`,
      namespaceImport: camelcase(contract.tag)
    },
    {
      kind: morph.StructureKind.ImportDeclaration,
      moduleSpecifier: "@workspace/validation",
      namedImports: ["validateOrThrow"]
    },
    {
      kind: morph.StructureKind.Function,
      isAsync: true,
      isDefaultExport: false,
      isExported: true,
      name: displayName,
      parameters: [],
      statements: [
        ...Object.values(vars),
        (writer) => writer.conditionalWriteLine(
          !!inputParams.length,
          `const ${inputName} = ${actionInputsStr}`
        ),
        (writer) => writer.conditionalWriteLine(
          !!inputParams.length,
          `validateOrThrow(${camelcase(contract.tag)}.${contract.schemaName}, ${inputName})`
        ),
        (writer) => writer.writeLine(
          `await ${camelcase(
            contract.tag
          )}.${camelcase(contract.operationName)}(${workflowParams.join(",")})`
        )
      ]
    }
  ];
}
export {
  nodeCron
};
//# sourceMappingURL=index.js.map
