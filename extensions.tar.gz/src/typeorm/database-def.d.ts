import type { Command } from '@faslh/isomorphic';
import type { TableDefinition } from '@january/declarative';
import type { ExtensionField, ExtensionValidation } from './fields.type';
export declare function toTableChanges(tablesDef: Record<string, TableDefinition>): Promise<TableVM[]>;
export type FieldValidationType = 'longitude' | 'latitude' | 'email' | 'contains' | 'tel' | 'optional' | 'required' | 'string' | 'number' | 'decimal' | 'url' | 'uuid' | 'matches' | 'datetime' | 'min' | 'max' | 'minlength' | 'minlength' | 'maxlength' | 'startwith' | 'endwith' | 'boolean';
export declare class FieldValidation {
    details: Record<string, any>;
    sourceId: string;
    name: string;
}
export interface TableFieldVM {
    id: string;
    tableId: string;
    sourceId: string;
    displayName: string;
    details: Record<string, any>;
    validations: FieldValidation[];
}
export interface TableVM {
    id: string;
    displayName: string;
    fields: TableFieldVM[];
    indexes: {
        columns: string[];
    }[];
}
export declare function isRequest<T extends Record<string, unknown>>(request: any): request is Command<T>;
export declare function getValidationByName(name: string): ExtensionValidation;
export declare function getSourceFieldById(id: string): ExtensionField;
export declare function getSourceFieldByName(name: string): ExtensionField;
export declare function assignDefaults(metadata: Record<string, any>, details: Record<string, any>): Record<string, any>;
export declare function getValidationById(id: string): ExtensionValidation;
export declare const makeEntityPath: (tableName: string, suffix: string) => string;
