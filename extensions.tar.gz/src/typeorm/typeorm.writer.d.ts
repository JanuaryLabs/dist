import * as morph from 'ts-morph';
import type { ConcreteContracts, Contracts } from '@faslh/compiler/contracts';
import { ProjectFS } from '@faslh/compiler/sdk/devkit';
export declare class TypeORMCodeWriter {
    #private;
    private _projectFS;
    constructor(_projectFS: ProjectFS);
    generateTable(contract: Contracts.Table): ConcreteContracts.MorphStatementWriter;
    generateCreatedAtField(contract: Contracts.Field): morph.PropertyDeclarationStructure;
    generateDeletedAtField(contract: Contracts.Field): morph.PropertyDeclarationStructure;
    generateUpdatedAtField(contract: Contracts.Field): morph.PropertyDeclarationStructure;
    generatePrimaryField(contract: Contracts.PrimaryField): morph.PropertyDeclarationStructure;
    generateField(contract: Contracts.FieldUnion): {
        fieldStructure: morph.PropertyDeclarationStructure;
        topLevelStructure: ConcreteContracts.MorphStatementWriter;
        classDecorators?: undefined;
    } | {
        fieldStructure: morph.PropertyDeclarationStructure;
        topLevelStructure: ConcreteContracts.MorphStatementWriter;
        classDecorators: morph.OptionalKind<morph.DecoratorStructure>[];
    };
}
