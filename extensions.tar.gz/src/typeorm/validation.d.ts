interface ActionPropertyValidation {
    id: string;
    details: Record<string, any>;
    name: string;
    type: string;
}
interface Validation {
    name: string;
    details: Record<string, unknown>;
    sourceId: string;
}
export declare function generateValidationContract(validations: Validation[]): ActionPropertyValidation[];
export {};
