import { Transform } from 'node:stream';
import { RawValue } from 'sql-template-tag';
import { DeepPartial, EntityManager, EntityTarget, ObjectLiteral, SelectQueryBuilder } from 'typeorm';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity.js';
export type ExecutePipeline<I extends ObjectLiteral> = <O extends Record<string, any>>(domainEntity: I, rawEntity: Record<string, any>) => I;
export declare function execute<U extends ObjectLiteral>(qb: SelectQueryBuilder<U>, ...mappers: ExecutePipeline<U>[]): Promise<U[]>;
export declare function useTransaction<TResult>(computation: (manager: EntityManager) => Promise<TResult>): Promise<TResult>;
export declare function createQueryBuilder<Entity extends ObjectLiteral>(entity: EntityTarget<Entity>, alias: string): any;
export declare function limitOffsetPagination<Entity extends ObjectLiteral>(qb: SelectQueryBuilder<Entity>, options: {
    pageNo?: number;
    pageSize?: number;
    count: number;
}): (result: Entity[]) => {
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    pageSize: number | undefined;
    currentPage: number | undefined;
    totalCount: number;
    totalPages: number;
};
export declare function deferredJoinPagination<Entity extends ObjectLiteral>(qb: SelectQueryBuilder<Entity>, options: {
    pageNo?: number | string | undefined;
    pageSize?: number | string | undefined;
    count: number;
}): (result: Entity[]) => {
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    pageSize: string | number | undefined;
    currentPage: string | number | undefined;
    totalCount: number;
    totalPages: number;
};
export declare function cursorPagination<Entity extends ObjectLiteral>(qb: SelectQueryBuilder<Entity>, options: {
    count: number;
    pageSize: number;
    /**
     * Base64 encoded string of the last record's cursor
     */
    cursor?: string;
}): (result: Entity[]) => {
    nextCursor: string;
    previousCursor: null;
    startCursor: null;
    endCursor: string;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    pageSize: number;
    totalCount: number;
};
export declare function getEntityById<Entity extends ObjectLiteral>(entity: EntityTarget<Entity>, id: string): any;
export declare function removeEntity<Entity extends ObjectLiteral, T extends DeepPartial<Entity>>(entityType: EntityTarget<Entity>, qbOrEntity: SelectQueryBuilder<T> | Entity): Promise<Entity | T>;
export declare function patchEntity<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>>(qb: SelectQueryBuilder<T>, entity: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>>): Promise<boolean>;
export declare function setEntity<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>>(qb: SelectQueryBuilder<T>, entity: Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>): Promise<boolean>;
export declare function increment<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>, Column extends Exclude<keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>, symbol | number>>(qb: SelectQueryBuilder<T>, column: Column, value: number | string): Promise<boolean>;
export declare function decrement<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>, Column extends Exclude<keyof Omit<T, 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'>, symbol | number>>(qb: SelectQueryBuilder<T>, column: Column, value: number | string): Promise<boolean>;
export declare function saveEntity<Entity extends ObjectLiteral, T extends DeepPartial<Entity>>(entityType: EntityTarget<Entity>, entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>): any;
export declare function upsertEntity<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>>(entityType: EntityTarget<Entity>, entity: Omit<T, 'createdAt' | 'updatedAt' | 'deletedAt'>, conflictColumns?: Extract<keyof (Entity & {
    id: string;
}), string>[]): Promise<void>;
export declare function sql(strings: readonly string[], ...values: readonly RawValue[]): any;
export declare function exists<Entity extends ObjectLiteral>(qb: SelectQueryBuilder<Entity>): Promise<boolean>;
export declare function stream<Entity extends ObjectLiteral, T extends QueryDeepPartialEntity<Entity>>(qb: SelectQueryBuilder<T>): Promise<Transform>;
