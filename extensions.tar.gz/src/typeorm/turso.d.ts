import { Database } from './database';
export declare function turso(options?: {
    uri?: string;
}): Database;
