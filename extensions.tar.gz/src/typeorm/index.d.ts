import type { Extension } from '../extension';
import { Database } from './database';
export * from './postgresql/postgresql';
export * from './sqlite/sqlite';
export * from './turso/turso';
export declare function typeorm(config: {
    database: Database;
}): Extension;
