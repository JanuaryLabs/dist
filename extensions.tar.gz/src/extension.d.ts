import type { FeatureContract } from '@faslh/compiler/contracts';
import type { Policy, TriggerDefinition } from '@january/declarative';
import { ProjectFS } from '@january/generator';
import type { OnFeatureR } from '@january/generator';
export interface WorkspaceSettings {
    runtime: string;
    /**
     * If true, the generated code will be formatted using prettier
     */
    formatGeneratedCode?: boolean;
    fs: {
        tables: string[];
        january: string;
        features: string;
        cwd: string;
        output: string;
        /**
         * The directory where the output files will be generated relative to the cwd
         */
        thirdPartyExtensions: string;
        extensions: string;
        tsconfig: string;
    };
}
export type Package = Record<string, {
    version: string;
    dev?: boolean;
}>;
export interface Extension {
    id?: string;
    packages: Package;
    scripts?: Record<string, string>;
    files: Record<string, string | {
        content: string;
        ignoreIfExists?: boolean;
    }>;
    primitives?: {
        policy?: Record<string, (...args: any[]) => Policy>;
        trigger?: Record<string, (...args: any[]) => TriggerDefinition<unknown>>;
    };
    onInit?: (api: {
        fs: ProjectFS;
        settings: WorkspaceSettings;
    }) => Promise<OnFeatureR>;
    onFeature?: (feature: FeatureContract, api: {
        fs: ProjectFS;
        settings: WorkspaceSettings;
    }) => OnFeatureR;
}
