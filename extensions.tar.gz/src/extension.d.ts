export type Package = Record<string, {
    version: string;
    dev?: boolean;
}>;
export interface Extension {
    packages: Package;
    files: Record<string, string>;
}
