import type { Contracts } from '@faslh/compiler/contracts';
import { ProjectFS } from '@faslh/compiler/sdk/devkit';
import type { Policy, TriggerDefinition } from '@january/declarative';
import type { OnFeatureR } from '@january/generator';
export type Package = Record<string, {
    version: string;
    dev?: boolean;
}>;
export interface Extension {
    id?: string;
    packages: Package;
    scripts?: Record<string, string>;
    files: Record<string, string>;
    primitives?: {
        policy?: Record<string, (...args: any[]) => Policy>;
        trigger?: Record<string, (...args: any[]) => TriggerDefinition<unknown, unknown>>;
    };
    onFeature?: (feature: Contracts.FeatureContract, api: {
        fs: ProjectFS;
    }) => OnFeatureR;
}
