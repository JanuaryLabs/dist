import type { ConcreteContracts, Contracts } from '@faslh/compiler/contracts';
import { ProjectFS } from '@faslh/compiler/sdk/devkit';
export type Package = Record<string, {
    version: string;
    dev?: boolean;
}>;
export type OnFeatureR = Record<string, ConcreteContracts.MorphStatementWriter>;
export interface Extension {
    id?: string;
    packages: Package;
    scripts?: Record<string, string>;
    files: Record<string, string>;
    onFeature?: (feature: Contracts.FeatureContract, api: {
        fs: ProjectFS;
    }) => OnFeatureR;
}
