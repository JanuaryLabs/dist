import type { Extension } from '../extension';
export declare const fly: Extension;
