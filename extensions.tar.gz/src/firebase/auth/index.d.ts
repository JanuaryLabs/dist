import type { Policy } from '@january/declarative';
import type { Extension } from '../../extension';
export declare function auth(): Extension;
declare module '@january/declarative' {
    namespace policy {
        function authenticated(): Policy;
    }
    namespace trigger {
        interface HttpTrigger<M> {
            subject: import('@extensions/identity').IdentitySubject;
        }
    }
}
