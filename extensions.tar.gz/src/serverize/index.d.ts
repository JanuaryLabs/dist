import type { Extension } from '../extension';
interface ServerizeOptions {
    /**
     * If true, the build will be run in a docker container instead of github actions.
     *
     * @default false
     *
     */
    runBuildInDocker?: boolean;
}
export declare const serverize: (options?: ServerizeOptions) => Extension;
export {};
