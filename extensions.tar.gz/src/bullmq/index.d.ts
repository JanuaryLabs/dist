import type { Job, JobState, QueueEventsListener } from 'bullmq';
import type { TriggerDefinition } from '@january/declarative';
import type { Extension } from '../extension';
export declare const bullmq: () => Extension;
declare module '@january/declarative' {
    namespace trigger {
        function queue(config: {
            /**
             * The name of the job to listen to.
             */
            jobName: string | string[];
            /**
             * Status is not allowed when `jobName` is specified without `local`.
             */
            status?: never;
            local?: never;
        }): TriggerDefinition<[Job], unknown>;
        function queue<T extends KeyOf<QueueEventsListener>>(config: {
            /**
             * The status of the job to listen to.
             */
            status: T;
            /**
             * Name is not allowed for global events.
             */
            jobName?: never;
            local?: never;
        }): TriggerDefinition<Parameters<QueueEventsListener[T]>, unknown>;
        function queue(config: {
            /**
             * The status of the job to listen to.
             */
            status: JobState;
            /**
             * The name of the job to listen to.
             */
            jobName?: string | string[];
            /**
             * Must be explicitly set to `true` when both `status` and `jobName` are provided.
             */
            local: true;
        }): TriggerDefinition<[Job], unknown>;
    }
}
type KeyOf<T extends object> = Extract<keyof T, string>;
export {};
