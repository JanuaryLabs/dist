// libs/extensions/src/gcs/file-manager.txt
var file_manager_default = "import type {\n  Bucket,\n  CreateWriteStreamOptions,\n  GetFileOptions,\n  GetFilesOptions,\n  GetSignedUrlConfig,\n  SaveOptions\n} from '@google-cloud/storage';\nimport {\n  Storage,\n} from '@google-cloud/storage';\nimport type { Writable } from 'stream';\nimport type { GoogleServiceAccount } from './service-account';\n\ninterface FileStorageAdapter {\n  listSignedLinks(...args: any[]): any;\n  listPublicLinks(...args: any[]): any;\n  list(...args: any[]): any;\n  exists(...args: any[]): Promise<any>;\n  delete(...args: any[]): Promise<any>;\n  create(...args: any[]): Promise<any>;\n  uploadStream(...args: any[]): Writable;\n  filePublicUrl(...args: any[]): any;\n}\n\nconst typeToKindMap: Record<string, Kind> = {\n  png: 'image',\n  jpeg: 'image',\n  pdf: 'document',\n};\n\nfunction getKindByType(value: string) {\n  return typeToKindMap[value] ?? 'other';\n}\n\ntype Kind = 'folder' | 'image' | 'document' | 'other';\ninterface FFile {\n  kind: Kind;\n  name: string;\n  link: string;\n  ext: string;\n  isFolder: boolean;\n  size?: string|number;\n  updatedAt?: string;\n  createdAt?: string;\n}\n\ninterface ServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n}\n\ninterface GoogleCloudStorageAdapterConfig {\n  /**\n   * The service account to use for authentication.\n   * @see https://cloud.google.com/storage/docs/authentication#service_accounts\n   * @see https://cloud.google.com/iam/docs/creating-managing-service-accounts\n   * @see https://cloud.google.com/iam/docs/creating-managing-service-account-keys\n   * @see https://cloud.google.com/iam/docs/understanding-service-accounts\n   */\n  serviceAccount: ServiceAccount;\n\n  /**\n   * The name of the bucket to use. If not provided, the bucket name will be\n   * inferred from the service account.\n   * @default <project-id>.appspot.com\n   * @see https://cloud.google.com/storage/docs/projects\n   * @see https://cloud.google.com/storage/docs/naming-buckets\n   */\n  bucket?: string;\n}\n\nexport class GoogleCloudStorageAdapter implements FileStorageAdapter {\n  private _storage: Storage;\n  private _bucket: Bucket;\n\n  constructor({ bucket, serviceAccount }: GoogleCloudStorageAdapterConfig) {\n    this._storage = new Storage({ credentials: serviceAccount });\n    bucket = bucket || `${serviceAccount.project_id}.appspot.com`;\n    this._bucket = this._storage.bucket(bucket);\n  }\n\n  filePublicUrl(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).publicUrl();\n  }\n\n  uploadStream(options: { fileName: string } & CreateWriteStreamOptions) {\n    return this._bucket\n      .file(options.fileName)\n      .createWriteStream({ resumable: false, ...options });\n  }\n\n  /**\n   * Lists public URLs for the files in the bucket.\n   *\n   * @param options The options to use when listing the files.\n   * @returns A list of public URLs for the files in the bucket.\n   */\n  async listPublicLinks(options?: GetFilesOptions) {\n    const [files] = await this._bucket.getFiles(options);\n    const result: FFile[] = [];\n    for (const file of files) {\n      const link = file.publicUrl();\n      const ext = link.split('.').pop() as string;\n      result.push({\n        ext,\n        link: link,\n        name: file.name,\n        kind: file.name.endsWith('/') ? 'folder' : getKindByType(ext),\n        isFolder: file.name.endsWith('/'),\n        createdAt: file.metadata.timeCreated,\n        updatedAt: file.metadata.updated,\n        size: file.metadata.size,\n      });\n    }\n    return result;\n  }\n\n  /**\n   * Returns a list of signed URLs for the files in the bucket.\n   *\n   * @param signUrlOptions The options to use when generating the signed URLs.\n   * @param options The options to use when listing the files.\n   * @returns A list of signed URLs for the files in the bucket.\n   */\n  async listSignedLinks(\n    signUrlOptions: GetSignedUrlConfig,\n    options?: GetFileOptions\n  ): Promise<FFile[]> {\n    const [files] = await this._bucket.getFiles(options);\n    const result: FFile[] = [];\n    for (const file of files) {\n      const [link] = await file.getSignedUrl(signUrlOptions);\n      const ext = link.split('.').pop() as string;\n      result.push({\n        ext,\n        link: link,\n        kind: file.name.endsWith('/') ? 'folder' : getKindByType(ext),\n        name: file.name,\n        isFolder: file.name.endsWith('/'),\n        createdAt: file.metadata.timeCreated,\n        updatedAt: file.metadata.updated,\n        size: file.metadata.size,\n      });\n    }\n    return result;\n  }\n\n  /**\n   * Lists files in the bucket.\n   *\n   * @param options The options to use when listing the files.\n   * @returns A list of files in the bucket.\n   */\n  list(options?: GetFileOptions) {\n    return this._bucket.getFiles(options);\n  }\n\n  create(options: { fileName: string; content: Buffer } & SaveOptions) {\n    return this._bucket.file(options.fileName).save(options.content, options);\n  }\n\n  delete(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).delete({});\n  }\n\n  exists(options: { fileName: string }) {\n    return this._bucket.file(options.fileName).exists({});\n  }\n}\n\nexport class FileManager<T extends FileStorageAdapter>\n  implements FileStorageAdapter\n{\n  private _adapter: FileStorageAdapter;\n  constructor({ adapter }: { adapter: T }) {\n    this._adapter = adapter;\n  }\n\n  filePublicUrl(\n    ...args: Parameters<T['filePublicUrl']>\n  ): Promise<ReturnType<T['filePublicUrl']>> {\n    return this._adapter.filePublicUrl(...args);\n  }\n\n  exists(...args: Parameters<T['exists']>): Promise<ReturnType<T['exists']>> {\n    return this._adapter.exists(...args);\n  }\n  delete(...args: Parameters<T['delete']>) {\n    return this._adapter.delete(...args);\n  }\n  create(...args: Parameters<T['create']>) {\n    return this._adapter.create(...args);\n  }\n  list(...args: Parameters<T['list']>): ReturnType<T['list']> {\n    return this._adapter.list(...args);\n  }\n  listPublicLinks(\n    ...args: Parameters<T['listPublicLinks']>\n  ): ReturnType<T['listPublicLinks']> {\n    return this._adapter.listPublicLinks(...args);\n  }\n  listSignedLinks(\n    ...args: Parameters<T['listSignedLinks']>\n  ): ReturnType<T['listSignedLinks']> {\n    return this._adapter.listSignedLinks(...args);\n  }\n  uploadStream(...args: Parameters<T['uploadStream']>): Writable {\n    return this._adapter.uploadStream(...args);\n  }\n}\n";

// libs/extensions/src/gcs/service-account-interface.txt
var service_account_interface_default = "export interface GoogleServiceAccount {\n  type: string;\n  project_id: string;\n  private_key_id: string;\n  private_key: string;\n  client_email: string;\n  client_id: string;\n  auth_uri: string;\n  token_uri: string;\n  auth_provider_x509_cert_url: string;\n  client_x509_cert_url: string;\n  universe_domain: string;\n}\n";

// libs/extensions/src/gcs/uploader.txt
var uploader_default = "import formidable from 'formidable';\nimport VolatileFile from 'formidable/VolatileFile';\nimport { PassThrough } from 'stream';\nimport { fileManager } from './storage';\nimport { IncomingMessage } from 'http';\nimport { ProblemDetailsException } from 'rfc-7807-problem-details';\n\nexport function uploadFile() {\n  const fileLocation = new PassThrough();\n\n  return {\n    fileLocation,\n    uploader: (volatileFile?: VolatileFile) => {\n      if (!volatileFile) {\n        // to make typescript happy\n        throw new Error('No file provided');\n      }\n\n      const { newFilename: fileName, mimetype } = volatileFile.toJSON();\n\n      return fileManager\n        .uploadStream({\n          fileName: fileName,\n          contentType: mimetype ?? undefined,\n        })\n        .on('finish', () => {\n          fileLocation.end(fileManager.filePublicUrl({ fileName }));\n        });\n    },\n  };\n}\n\nexport function createUploader() {\n  const { fileLocation, uploader } = uploadFile();\n  const parser = formidable({\n    keepExtensions: true,\n    maxFiles: 1,\n    maxFields: 1,\n    filename: (name, ext) => `${name}${ext}`,\n    fileWriteStreamHandler: uploader,\n  });\n  return {\n    fileLocation,\n    parser: {\n      ...parser,\n      parse: (req: IncomingMessage) => {\n        return parser.parse(req).catch((error) => {\n          fileLocation.end();\n          throw new ProblemDetailsException({\n            title: 'Failed to parse form data',\n            status: 400,\n            detail: error.message,\n          });\n        });\n      },\n    },\n  };\n}\n\nexport async function streamEnd(stream: NodeJS.ReadableStream) {\n  return new Promise<void>((resolve, reject) => {\n    stream.on('data', (buffer) => resolve(buffer.toString()));\n    stream.on('error', reject);\n  });\n}\n\nexport function upload(request: IncomingMessage) {\n  const { parser, fileLocation } = createUploader();\n  return Promise.all([parser.parse(request), streamEnd(fileLocation)])\n}\n";

// libs/extensions/src/gcs/index.ts
var gcs = {
  packages: {
    "@google-cloud/storage": {
      version: "7.11.2",
      dev: false
    },
    formidable: {
      version: "3.5.1",
      dev: false
    },
    "@types/formidable": {
      version: "3.4.5",
      dev: true
    },
    mime: {
      version: "4.0.3",
      dev: false
    }
  },
  files: {
    "src/extensions/gcs/uploader.ts": uploader_default,
    "src/core/service-account.ts": service_account_interface_default,
    // FIXME: file-manager shouldn't be added by a specific storage extension rather it
    // should be imported from a library (we should publish (file-manager or storage-abstraction) as npm package) and
    // only use the implementation of it here
    "src/core/file-manager.ts": file_manager_default,
    "src/extensions/gcs/index.ts": [
      `export * from './uploader';`,
      `export * from './storage';`,
      `import z from 'zod';
export const env = {
  GOOGLE_CLOUD_SERVICE_ACCOUNT_KEY: z.string()
}`
    ].join("\n"),
    "src/extensions/gcs/storage.ts": `import {
  FileManager,
  GoogleCloudStorageAdapter,
} from '../../core/file-manager';
import { GoogleServiceAccount } from '../../core/service-account';

const serviceAccount: GoogleServiceAccount = JSON.parse(Buffer.from(process.env.GOOGLE_CLOUD_SERVICE_ACCOUNT_KEY, 'base64').toString('ascii'));

export const fileManager = new FileManager({
  adapter: new GoogleCloudStorageAdapter({
    serviceAccount: serviceAccount,
  }),
});`
  }
};
export {
  gcs
};
//# sourceMappingURL=index.js.map
