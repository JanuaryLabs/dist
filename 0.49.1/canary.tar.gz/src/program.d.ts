export declare const cli: import("commander").Command;
export declare const spinner: import("ora").Ora;
