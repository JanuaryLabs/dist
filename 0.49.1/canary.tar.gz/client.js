import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// libs/canary/src/client.ts
import { join as join3 } from "path";

// libs/modern/src/index.ts
import { existsSync } from "fs";
import { mkdir, readFile, readdir, writeFile } from "fs/promises";
import { dirname, isAbsolute, join as join2 } from "path";
import { tap } from "rxjs/operators";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { join, normalize } from "path";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
function toLitObject(obj, accessor = (value) => value) {
  return `{${Object.keys(obj).map((key) => `${key}: ${accessor(obj[key])}`).join(", ")}}`;
}
function addLeadingSlash(path) {
  return normalize(join("/", path));
}
function removeTrialingSlashes(path, keepLastOne = false) {
  while (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path + (keepLastOne ? "/" : "");
}
function toCurlyBraces(path) {
  return path.replace(":", "$:").split("$").map((it) => {
    if (!it.startsWith(":")) {
      return it.split("/").filter(Boolean).join("/");
    }
    const [param, ...rest] = it.split("/");
    return [`{${param.slice(1)}}`, ...rest].join("/");
  }).join("/");
}
function normalizeWorkflowPath(config) {
  const path = removeTrialingSlashes(
    addLeadingSlash(
      join(
        spinalcase(config.featureName),
        snakecase(config.workflowTag),
        toCurlyBraces(config.workflowPath)
      )
    )
  );
  return config.workflowMethod ? `${config.workflowMethod} ${path}` : path;
}
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
async function writeFiles(dir, contents, format = true) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join2(dir, file);
    await mkdir(dirname(filePath), { recursive: true });
    const stringContent = typeof content === "string" ? content : JSON.stringify(content);
    await writeFile(
      filePath,
      format ? await formatCode(stringContent, getExt(file)) : stringContent,
      "utf-8"
    );
  }
}
function readFolder(path) {
  return existsSync(path) ? readdir(path) : [];
}
function getFile(filePath) {
  return existsSync(filePath) ? readFile(filePath, "utf-8") : Promise.resolve(null);
}
async function getFolderExports(folder, extensions = ["ts"]) {
  const files = await readdir(folder, { withFileTypes: true });
  const exports = [];
  for (const file of files) {
    if (file.isDirectory()) {
      exports.push(`export * from './${file.name}';`);
    } else if (file.name !== "index.ts" && extensions.includes(getExt(file.name))) {
      exports.push(`export * from './${file.name}';`);
    }
  }
  return exports.join("\n");
}

// libs/canary/src/client/client.txt
var client_default = "import { parse } from 'fast-content-type-parse';\nimport type { Endpoints } from './endpoints';\nimport schemas from './schemas';\nimport { validateOrThrow, ServerError } from './validator';\n\nexport interface RequestInterface<D extends object = object> {\n	/**\n	 * Sends a request based on endpoint options\n	 *\n	 * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'\n	 * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.\n	 */\n	<R extends keyof Endpoints>(\n		route: R,\n		options?: Endpoints[R]['input']\n	): Promise<Endpoints[R]['output']>;\n}\n\nexport async function handleError(response: Response) {\n	try {\n		if (response.status >= 400 && response.status < 500) {\n			const body = (await response.json()) as Record<string, any>;\n			return new ServerError(body.title || body.detail, response.status, body.errors ?? {});\n		}\n		return new Error(\n			`An error occurred while fetching the data. Status: ${response.status}`\n		);\n	} catch (error) {\n		// in case the response is not a json\n		// this is a workaround but we should change\n		// it from the server to always return json\n\n		return error as Error;\n	}\n}\n\nexport async function parseResponse(response: Response) {\n	const contentType = response.headers.get('Content-Type');\n	if (!contentType) {\n		throw new Error('Content-Type header is missing');\n	}\n\n	if (response.status === 204) {\n		return null;\n	}\n\n	const { type } = parse(contentType);\n	switch (type) {\n		case 'application/json':\n			return response.json();\n		case 'text/plain':\n			return response.text();\n		default:\n			throw new Error(`Unsupported content type: ${contentType}`);\n	}\n}";

// libs/canary/src/client/request.txt
var request_default = "type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';\ntype Endpoint = `${Method} ${string}`;\n\nexport function createUrl(base: string, path: string, query: URLSearchParams) {\n	const url = new URL(path, base);\n	url.search = query.toString();\n	return url;\n}\nfunction template(\n	templateString: string,\n	templateVariables: Record<string, any>\n): string {\n	const nargs = /{([0-9a-zA-Z_]+)}/g;\n	return templateString.replace(nargs, (match, key: string, index: number) => {\n		// Handle escaped double braces\n		if (\n			templateString[index - 1] === '{' &&\n			templateString[index + match.length] === '}'\n		) {\n			return key;\n		}\n\n		const result = key in templateVariables ? templateVariables[key] : null;\n		return result === null || result === undefined ? '' : String(result);\n	});\n}\nexport function toRequest<T extends Endpoint>(\n	endpoint: T,\n	input: Record<string, any>,\n	props: {\n		inputHeaders: string[];\n		inputQuery: string[];\n		inputBody: string[];\n		inputParams: string[];\n	},\n	defaults: {\n		baseUrl: string;\n		headers?: Record<string, string>;\n	}\n) {\n	const [method, path] = endpoint.split(' ');\n\n	const headers = new Headers({\n		...defaults?.headers,\n		'Content-Type': 'application/json',\n		Accept: 'application/json',\n	});\n\n	for (const header of props.inputHeaders) {\n		headers.set(header, input[header]);\n	}\n\n	const query = new URLSearchParams();\n	for (const key of props.inputQuery) {\n		const value = input[key];\n		if (value !== undefined) {\n			query.set(key, String(value));\n		}\n	}\n\n	const body = props.inputBody.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {\n		acc[key] = input[key];\n		return acc;\n	}, {});\n\n	const init = {\n		path: template(path, params),\n		method,\n		headers,\n		query,\n		body: JSON.stringify(body),\n	};\n\n	const url = createUrl(defaults.baseUrl, init.path, init.query);\n	return new Request(url, {\n		method: init.method,\n		headers: init.headers,\n		body: method === 'GET' ? undefined : JSON.stringify(body),\n	});\n}\n";

// libs/canary/src/client/validator.txt
var validator_default = "import { z } from 'zod';\n\nexport function validate<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n) {\n	const result = schema.safeParse(input);\n	if (!result.success) {\n		return result.error.flatten((issue) => ({\n			message: issue.message,\n			code: issue.code,\n			fatel: issue.fatal,\n			path: issue.path.join('.'),\n		})).fieldErrors;\n	}\n	return null;\n}\n\nexport class ValidationError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ValidationError';\n		Error.captureStackTrace(this, ValidationError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport class ServerError extends Error {\n	flattened: { path: string; message: string }[];\n	constructor(\n		public override message: string,\n		public status: number,\n		public errors: ReturnType<typeof validate>\n	) {\n		super(message);\n		this.name = 'ServerError';\n		Error.captureStackTrace(this, ServerError);\n		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({\n			path: key,\n			message: (it as any[])[0].message,\n		}));\n	}\n}\n\nexport function validateOrThrow<T extends z.ZodRawShape>(\n	schema: z.ZodObject<T>,\n	input: unknown\n): asserts input is z.infer<z.ZodObject<T>> {\n	const errors = validate(schema, input);\n	if (errors) {\n		throw new ValidationError('Validation failed', errors);\n	}\n}\n";

// libs/canary/src/client/sdk.ts
import { camelcase as camelcase2 } from "stringcase";
var SchemaEndpoint = class {
  #imports = [
    `import z from 'zod';`,
    'import type { Endpoints } from "./endpoints";',
    `import { toRequest, createUrl } from './request';`
  ];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation},`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export default {
${this.#endpoints.join("\n")}
}`;
  }
};
var Emitter = class {
  #imports = [`import z from 'zod';`];
  #endpoints = [];
  addEndpoint(endpoint, operation) {
    this.#endpoints.push(`  "${endpoint}": ${operation};`);
  }
  addImport(value) {
    this.#imports.push(value);
  }
  complete() {
    return `${this.#imports.join("\n")}
export interface Endpoints {
${this.#endpoints.join("\n")}
}`;
  }
};
function generateClientSdk(spec) {
  const emitter = new Emitter();
  const schemas = {};
  const schemasImports = [];
  const schemaEndpoint = new SchemaEndpoint();
  for (const feature of spec.features) {
    const featureSchemaFileName = camelcase2(feature.featureName);
    schemas[featureSchemaFileName] = [`import z from 'zod';`];
    emitter.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    schemaEndpoint.addImport(
      `import * as ${featureSchemaFileName} from './inputs/${featureSchemaFileName}';`
    );
    for (const workflow of feature.workflows) {
      const schema = `export const ${workflow.schemaName} = z.object(${toLitObject(
        workflow.inputs,
        (x) => x.schema
      )});`;
      schemas[featureSchemaFileName].push(schema);
      schemasImports.push(
        ...workflow.imports.filter((it) => it.moduleSpecifier === "@extensions/zod").map((it) => (it.namedImports ?? []).map((it2) => it2.name)).flat()
      );
      const workflowPath = normalizeWorkflowPath({
        // featureName: feature.featureName,
        featureName: "/",
        workflowTag: workflow.tag,
        workflowPath: workflow.trigger.path
      });
      const endpoint = `${workflow.trigger.method.toUpperCase()} ${workflowPath}`;
      const schemaRef = `${featureSchemaFileName}.${workflow.schemaName}`;
      const input = `z.infer<typeof ${schemaRef}>`;
      const output = pascalcase(workflow.name);
      emitter.addImport(
        `import {${output}} from './outputs/${workflow.name}';`
      );
      emitter.addEndpoint(endpoint, `{input: ${input}, output: ${output}}`);
      const inputHeaders = [];
      const inputQuery = [];
      const inputBody = [];
      const inputParams = [];
      for (const [name, prop] of Object.entries(workflow.inputs)) {
        if (prop.source === "headers") {
          inputHeaders.push(`"${name}"`);
        } else if (prop.source === "query") {
          inputQuery.push(`"${name}"`);
        } else if (prop.source === "body") {
          inputBody.push(`"${name}"`);
        } else if (prop.source === "path") {
          inputParams.push(`"${name}"`);
        } else if (prop.source === "internal") {
          continue;
        } else {
          throw new Error(
            `Unknown source ${prop.source} in ${name} ${JSON.stringify(
              prop
            )} in ${workflow.name}`
          );
        }
      }
      schemaEndpoint.addEndpoint(
        endpoint,
        `{
      schema: ${schemaRef},
      toRequest(input: Endpoints['${endpoint}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
        const endpoint = '${endpoint}';
          return toRequest(endpoint, input, {
          inputHeaders: [${inputHeaders}],
          inputQuery: [${inputQuery}],
          inputBody: [${inputBody}],
          inputParams: [${inputParams}],
        }, init);
        },
      }`
      );
    }
  }
  const specOptions = {
    ...spec.options ?? {},
    baseUrl: { schema: "z.string().url()" },
    token: { schema: "z.string().optional()" }
  };
  const clientName = `${spec.name ?? "Client"}`;
  const defaultHeaders = spec.securityScheme ? `{Authorization: \`${titlecase(spec.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}` : {};
  return {
    ...Object.fromEntries(
      Object.entries(schemas).map(([key, value]) => [
        `inputs/${key}.ts`,
        [
          schemasImports.length ? `import {${removeDuplicates(schemasImports, (it) => it)}} from '../zod';` : "",
          ...value
        ].join("\n")
      ])
    ),
    "sdk.ts": `
import z from 'zod';
import type { Endpoints } from './endpoints';
import schemas from './schemas';
import { validateOrThrow } from './validator';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${toLitObject(specOptions, (x) => x.schema)});
      type ${clientName}Options = z.infer<typeof optionsSchema>;
    export class ${clientName} {

      constructor(public options: ${clientName}Options) {}

async request<E extends keyof Endpoints>(
		endpoint: E,
		input: Endpoints[E]['input']
	): Promise<readonly [Endpoints[E]['output'], Error | null]> {
		try {
			const route = schemas[endpoint];
			validateOrThrow(route.schema, input);
			const response = await fetch(
				route.toRequest(input as never, {
					headers: this.defaultHeaders,
					baseUrl: this.options.baseUrl,
				})
			);

			if (response.ok) {
				const data = await parseResponse(response);
				return [data as Endpoints[E]['output'], null] as const;
			}
			const error = await handleError(response);
			return [null, error] as const;
		} catch (error) {
			return [null, error as Error] as const;
		}
	}

      get defaultHeaders() {
        return ${defaultHeaders}
      }

  setOptions(options: Partial<${clientName}Options>) {
		for (const key in this.options) {
			if (
				key in options &&
				options[key as keyof ${clientName}Options] !== undefined
			) {
				this.options[key as keyof ${clientName}Options] =
					options[key as keyof ${clientName}Options]!;
			}
		}
	}
    }`,
    "validator.ts": validator_default,
    "client.ts": client_default,
    "request.ts": request_default,
    "schemas.ts": schemaEndpoint.complete(),
    "endpoints.ts": emitter.complete()
  };
}

// libs/canary/src/client/serializer.ts
import { dirname as dirname2 } from "path";
import ts from "typescript";

// libs/canary/src/client/emitter.ts
var typeMappings = {
  DateConstructor: "Date"
};
function deserializeTypes(data) {
  const tokens = [];
  for (const type of data.types) {
    if (type === null || type === void 0) {
      tokens.push("any");
    } else if (typeof type === "string") {
      tokens.push(
        `${typeMappings[type] || type}${data.kind === "array" ? "[]" : ""}`
      );
    } else if ("types" in type) {
      tokens.push(deserializeTypes(type));
    }
  }
  return tokens.join(" | ");
}
function toInterface(contents, serializeSymbol2) {
  const contentMap = {};
  for (const [filePath, models] of Object.entries(contents)) {
    for (const [key, value] of Object.entries(models)) {
      const props = [];
      const isTypeAlias = value[serializeSymbol2];
      if (isTypeAlias) {
        contentMap[filePath] = {
          exports: [key],
          content: `export type ${key} = ${deserializeTypes(value)};`
        };
      } else {
        for (const [prop, data] of Object.entries(value)) {
          const tokens = [prop];
          if (data.optional) {
            tokens.push("?");
          }
          tokens.push(": ");
          tokens.push(deserializeTypes(data));
          props.push(tokens.join(""));
        }
        contentMap[filePath] = {
          exports: [key],
          content: `export interface ${key} {
${props.join("\n")}
}
`
        };
      }
    }
  }
  const imports = Object.values(contentMap).flatMap((it) => it.exports);
  const emits = {};
  for (const [filePath, { content, exports }] of Object.entries(contentMap)) {
    const allButCurrentExports = imports.filter((it) => !exports.includes(it)).map((it) => `import { ${it} } from './${it}';`);
    const fileContent = `${allButCurrentExports.join("\n")}
${content}`;
    emits[filePath] = fileContent;
  }
  return emits;
}

// libs/canary/src/client/serializer.ts
function parseTsConfig(tsconfigPath) {
  const configContent = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
  if (configContent.error) {
    console.error(
      `Failed to read tsconfig file:`,
      ts.formatDiagnosticsWithColorAndContext([configContent.error], {
        getCanonicalFileName: (path) => path,
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: () => ts.sys.newLine
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  const parsed = ts.parseJsonConfigFileContent(
    configContent.config,
    ts.sys,
    dirname2(tsconfigPath)
  );
  if (parsed.errors.length > 0) {
    console.error(
      `Errors found in tsconfig.json:`,
      ts.formatDiagnosticsWithColorAndContext(parsed.errors, {
        getCanonicalFileName: (path) => path,
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: () => ts.sys.newLine
      })
    );
    throw new Error("Failed to parse tsconfig.json");
  }
  return parsed;
}
var visitor = (on) => {
  return (node) => {
    if (ts.isReturnStatement(node) && node.expression) {
      if (ts.isCallExpression(node.expression) && node.expression.expression && ts.isPropertyAccessExpression(node.expression.expression)) {
        const propAccess = node.expression.expression;
        if (ts.isIdentifier(propAccess.expression) && propAccess.expression.text === "output") {
          const [ole] = node.expression.arguments;
          if (!ole) {
            return;
          }
          on(ole);
        }
      } else {
        on(node.expression);
      }
    }
    return ts.forEachChild(node, visitor(on));
  };
};
function isCallExpression(node, name) {
  return ts.isCallExpression(node) && node.expression && ts.isIdentifier(node.expression) && node.expression.text === name;
}
function getPropertyAssignment(node, name) {
  if (ts.isObjectLiteralExpression(node)) {
    return node.properties.filter((prop) => ts.isPropertyAssignment(prop)).find((prop) => prop.name.getText() === name);
  }
  return void 0;
}
function searchInFeature(sourceFile, serializer) {
  const results = [];
  sourceFile.forEachChild((node) => {
    if (ts.isExportAssignment(node) && isCallExpression(node.expression, "feature")) {
      const [configArg] = node.expression.arguments;
      if (ts.isObjectLiteralExpression(configArg)) {
        const workflows = getPropertyAssignment(configArg, "workflows");
        if (!workflows) {
          return;
        }
        if (ts.isArrayLiteralExpression(workflows.initializer)) {
          workflows.initializer.forEachChild((workflow) => {
            if (isCallExpression(workflow, "workflow")) {
              const [workflowNameArg, workflowConfigArg] = workflow.arguments;
              const name = ts.isStringLiteral(workflowNameArg) ? workflowNameArg.text : "";
              if (!name) {
                return;
              }
              if (ts.isObjectLiteralExpression(workflowConfigArg)) {
                const execute = getPropertyAssignment(
                  workflowConfigArg,
                  "execute"
                );
                if (execute?.initializer) {
                  if (ts.isArrowFunction(execute.initializer)) {
                    if (ts.isBlock(execute.initializer.body)) {
                      const contents = {
                        [name]: {
                          [serializeSymbol]: true,
                          optional: false,
                          types: ["void"]
                        }
                      };
                      visitor((node2) => {
                        contents[name] = serializer.serializeNode(node2);
                      })(execute.initializer.body);
                      results.push(contents);
                    }
                  }
                }
              }
            }
          });
        }
      }
    }
  });
  return results;
}
var serializeSymbol = Symbol.for("serialize");
function isInterfaceType(type) {
  if (type.isClassOrInterface()) {
    return !!(type.symbol.flags & ts.SymbolFlags.Interface);
  }
  return false;
}
var Serializer = class {
  constructor(program) {
    this.program = program;
    this.checker = program.getTypeChecker();
  }
  collector = {};
  checker;
  serializeType(type) {
    if (type.isUnion() || type.isIntersection()) {
      let optional;
      const types = [];
      for (const unionType of type.types) {
        if (optional === void 0) {
          optional = (unionType.flags & ts.TypeFlags.Undefined) !== 0;
          if (optional) {
            continue;
          }
        }
        types.push(this.serializeType(unionType));
      }
      return {
        [serializeSymbol]: true,
        optional,
        types
      };
    }
    if (this.checker.isArrayLikeType(type)) {
      const [argType] = this.checker.getTypeArguments(type);
      if (!argType) {
        console.warn(
          `No argument type found for ${type.symbol?.name} of ${this.checker.typeToString(type)}`
        );
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: ["any"]
        };
      }
      const typeSymbol = argType.getSymbol();
      if (!typeSymbol) {
        return {
          [serializeSymbol]: true,
          optional: false,
          kind: "array",
          types: [this.checker.typeToString(argType)]
        };
      }
      const declaration = typeSymbol.valueDeclaration;
      if (!declaration) {
        return null;
      }
      return {
        kind: "array",
        ...this.serializeNode(declaration)
      };
    }
    if (type.isClass()) {
      const declaration = type.symbol?.valueDeclaration;
      if (!declaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(declaration);
    }
    if (isInterfaceType(type)) {
      const valueDeclaration = type.symbol.valueDeclaration ?? type.symbol.declarations?.[0];
      if (!valueDeclaration) {
        return {
          [serializeSymbol]: true,
          optional: false,
          types: [type.symbol.getName()]
        };
      }
      return this.serializeNode(valueDeclaration);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: [this.checker.typeToString(type)]
    };
  }
  serializeNode(node) {
    if (ts.isObjectLiteralExpression(node)) {
      const symbolType = this.checker.getTypeAtLocation(node);
      const props = {};
      for (const symbol of symbolType.getProperties()) {
        const type = this.checker.getTypeOfSymbol(symbol);
        props[symbol.name] = this.serializeType(type);
      }
      return props;
    }
    if (ts.isPropertySignature(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isPropertyDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      const type = this.checker.getTypeOfSymbol(symbol);
      return this.serializeType(type);
    }
    if (ts.isInterfaceDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Interface has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertySignature)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isClassDeclaration(node)) {
      if (!node.name?.text) {
        throw new Error("Class has no name");
      }
      if (!this.collector[node.name.text]) {
        this.collector[node.name.text] = {};
        const members = {};
        for (const member of node.members.filter(ts.isPropertyDeclaration)) {
          members[member.name.getText()] = this.serializeNode(member);
        }
        this.collector[node.name.text] = members;
      }
      return {
        [serializeSymbol]: true,
        optional: false,
        types: [node.name.text]
      };
    }
    if (ts.isVariableDeclaration(node)) {
      const symbol = this.checker.getSymbolAtLocation(node.name);
      if (!symbol) {
        console.warn(`No symbol found for ${node.name.getText()}`);
        return null;
      }
      if (!node.type) {
        return "any";
      }
      const type = this.checker.getTypeFromTypeNode(node.type);
      return this.serializeType(type);
    }
    if (ts.isIdentifier(node)) {
      const symbol = this.checker.getSymbolAtLocation(node);
      if (!symbol) {
        console.warn(`No symbol found for ${node.getText()}`);
        return null;
      }
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    if (ts.isAwaitExpression(node)) {
      const type = this.checker.getTypeAtLocation(node);
      return this.serializeType(type);
    }
    return {
      [serializeSymbol]: true,
      optional: false,
      types: ["any"]
    };
  }
};
function serialize(tsconfigPath, features) {
  const tsConfigParseResult = parseTsConfig(tsconfigPath);
  const program = ts.createProgram({
    options: tsConfigParseResult.options,
    rootNames: tsConfigParseResult.fileNames,
    projectReferences: tsConfigParseResult.projectReferences,
    configFileParsingDiagnostics: tsConfigParseResult.errors
  });
  const serializer = new Serializer(program);
  const emits = {};
  for (const feature of features) {
    const sourceFile = program.getSourceFile(feature.path);
    if (!sourceFile) {
      throw new Error(`File not found: ${feature.path}`);
    }
    const result = searchInFeature(sourceFile, serializer);
    const collector = { ...serializer.collector };
    for (const workflow of result) {
      for (const [key, value] of Object.entries(workflow)) {
        collector[key] = value;
      }
    }
    const contents = Object.entries(collector).reduce(
      (acc, [key, value]) => {
        acc[key] = { [key]: value };
        return acc;
      },
      {}
    );
    emits[feature.name] = toInterface(contents, serializeSymbol);
  }
  return emits;
}
function flattenSerialized(serialized) {
  const outputs = {};
  for (const [featureName, content] of Object.entries(serialized)) {
    for (const [fileName, fileContent] of Object.entries(content)) {
      outputs[
        // join(
        //   basename(featureName).replace(extname(featureName), ''),
        //   `${fileName}.ts`,
        // )
        `${fileName}.ts`
      ] = fileContent;
    }
  }
  return outputs;
}

// libs/canary/src/settings.ts
function createWorkflowSchema(workflow) {
  return Object.entries(workflow.inputs).filter(([key, prop]) => !prop.data?.["standalone"]).reduce(
    (acc, [key, prop]) => ({
      ...acc,
      [key]: {
        schema: prop.data?.["zod"] || "z.any()",
        source: prop.data?.["source"]
      }
    }),
    {}
  );
}

// libs/canary/src/client.ts
var client_default2 = async ({
  client,
  features,
  settings
}) => {
  const spec = {
    name: client.name,
    options: client.options,
    securityScheme: client.securityScheme,
    features: features.map((feature) => ({
      featureName: feature.displayName,
      workflows: feature.workflows.filter((it) => ["http", "stream"].includes(it.trigger.sourceId)).map((workflow) => ({
        name: workflow.displayName,
        type: workflow.trigger.sourceId,
        imports: workflow.imports,
        schemaName: workflow.schemaName,
        tag: workflow.tag,
        trigger: workflow.trigger.details,
        inputs: createWorkflowSchema(workflow)
      }))
    }))
  };
  const output = join3(
    client.output ?? join3(settings.fs.output, "client"),
    "src"
  );
  await writeFiles(
    output,
    {
      ...generateClientSdk(spec),
      "zod.ts": await getFile(join3(settings.fs.extensions, "zod", "index.ts")) || ""
    },
    false
  );
  const featurePaths = await readFolder(settings.fs.features);
  const serialized = serialize(
    settings.fs.tsconfig,
    featurePaths.map((it) => ({
      name: it,
      path: join3(settings.fs.features, it)
    }))
  );
  await writeFiles(
    join3(output, "outputs"),
    flattenSerialized(serialized),
    false
  );
  const index = await getFolderExports(output);
  const outputIndex = await getFolderExports(join3(output, "outputs"));
  const inputsIndex = await getFolderExports(join3(output, "inputs"));
  await writeFiles(
    output,
    {
      "index.ts": index,
      "outputs/index.ts": outputIndex,
      "inputs/index.ts": inputsIndex,
      "../package.json": {
        // FIXME: instead of accepting inputs from user, pass it as function where user can customise further
        name: client.packageName,
        version: "0.0.0",
        type: "module",
        main: "./index.js",
        module: "./index.js",
        types: "./src/index.d.ts",
        dependencies: {
          validator: "^13.12.0",
          zod: "^3.23.8",
          "fast-content-type-parse": "^2.0.0"
        },
        exports: {
          "./package.json": "./package.json",
          ".": {
            node: "./index.js",
            default: "./index.js",
            import: "./index.js",
            types: "./src/index.d.ts"
          }
        }
      }
    },
    false
  );
};
export {
  client_default2 as default
};
//# sourceMappingURL=client.js.map
