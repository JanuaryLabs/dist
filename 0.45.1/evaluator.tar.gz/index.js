var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);

// libs/sdk/evaluator/src/lib/evaluate.ts
import { randomBytes } from "crypto";
import { get } from "lodash-es";

// libs/sdk/declarative/src/lib/feature.ts
function feature(nameOrConfig, config2) {
  if (typeof nameOrConfig === "string") {
    if (!config2) {
      throw new Error(`Missing config for feature ${nameOrConfig}`);
    }
    return {
      name: nameOrConfig,
      tables: config2.tables,
      workflows: config2.workflows,
      policies: Object.entries(config2.policies || {}).reduce(
        (acc, [key, value]) => {
          const result = value(key);
          if (result) {
            acc[key] = result;
          }
          return acc;
        },
        {}
      )
    };
  }
  return {
    name: "",
    tables: nameOrConfig.tables,
    workflows: nameOrConfig.workflows,
    policies: Object.entries(nameOrConfig.policies || {}).reduce(
      (acc, [key, value]) => {
        const result = value(key);
        if (result) {
          acc[key] = result;
        }
        return acc;
      },
      {}
    )
  };
}
feature.new = (name, config2) => {
  throw new Error("Not implemented");
};

// libs/sdk/declarative/src/lib/functional.ts
function input(value) {
  if (typeof value === "number" || typeof value === "boolean" || value === null) {
    return input.primitive(value);
  }
  if (value.startsWith("context") || value.startsWith("workflow")) {
    return input.workflow(value.replace("context.", ""));
  }
  if (value.startsWith("trigger")) {
    return input.trigger(value.replace("trigger.", ""));
  }
  if (!value.startsWith("@")) {
    return input.primitive(value);
  }
  return {
    input: value
  };
}
((input2) => {
  function primitive(value) {
    return {
      input: `@fixed:${typeof value === "boolean" || typeof value === "number" || value === null ? value : `'${value}'`}`
    };
  }
  input2.primitive = primitive;
  function workflow2(path) {
    return {
      input: `@workflow:${path}`
    };
  }
  input2.workflow = workflow2;
  function trigger2(path) {
    return {
      input: `@trigger:${path}`
    };
  }
  input2.trigger = trigger2;
  function field2(name) {
    return {
      input: `@tables:fields.${name}`
    };
  }
  input2.field = field2;
})(input || (input = {}));

// libs/sdk/declarative/src/lib/project.ts
function project(...features) {
  return features;
}

// libs/compiler/transpilers/src/lib/ast.ts
import { camelcase } from "stringcase";

// libs/compiler/transpilers/src/lib/expression.ts
var QueryBuilder;
((QueryBuilder2) => {
  class Expression {
  }
  QueryBuilder2.Expression = Expression;
  function createBooleanLiteral(value) {
    return {
      value,
      type: "boolean",
      accept(visitor, context) {
        return visitor.visitBooleanLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createBooleanLiteral = createBooleanLiteral;
  function createDateLiteral(value) {
    return {
      value,
      type: "date",
      accept(visitor, context) {
        return visitor.visitDateLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createDateLiteral = createDateLiteral;
  function createStringLiteral(value, defaultContext) {
    return {
      value,
      type: "string",
      accept(visitor, context = defaultContext) {
        return visitor.visitStringLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createStringLiteral = createStringLiteral;
  function createNumericLiteral(value) {
    return {
      value,
      type: "numeric",
      accept(visitor, context) {
        return visitor.visitNumericLiteralExpr(this, {
          ...context,
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNumericLiteral = createNumericLiteral;
  function createNullLiteral(defaultContext) {
    return {
      type: "null",
      accept(visitor, context = defaultContext) {
        return visitor.visitNullLiteralExpr(this, {
          ...context ?? {},
          required: true
        });
      }
    };
  }
  QueryBuilder2.createNullLiteral = createNullLiteral;
  function createIdentifier(value, defaultContext) {
    return {
      value,
      type: "identifier",
      accept(visitor, context) {
        return visitor.visitIdentifier(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createIdentifier = createIdentifier;
  function createCombinator(operator) {
    return {
      operator,
      type: "combinator",
      accept(visitor, context) {
        return visitor.visitCombinator(this, context);
      }
    };
  }
  QueryBuilder2.createCombinator = createCombinator;
  function createBinaryExpression(left, operator, right, defaultContext) {
    return {
      type: "binary",
      left,
      operator,
      right,
      accept(visitor, context = defaultContext) {
        return visitor.visitBinaryExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createBinaryExpression = createBinaryExpression;
  function createGroupExpression(list, combinator, defaultContext) {
    return {
      type: "group",
      combinator,
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitGroupExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createGroupExpression = createGroupExpression;
  function createQuerySelectExpression(groups, defaultContext) {
    return {
      type: "querySelect",
      value: groups,
      accept(visitor, context = defaultContext) {
        return visitor.visitQuerySelectExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createQuerySelectExpression = createQuerySelectExpression;
  function createListExpression(list, defaultContext) {
    return {
      type: "list",
      value: list,
      accept(visitor, context = defaultContext) {
        return visitor.visitListExpr(this, {
          ...defaultContext,
          ...context
        });
      }
    };
  }
  QueryBuilder2.createListExpression = createListExpression;
})(QueryBuilder || (QueryBuilder = {}));

// libs/compiler/transpilers/src/lib/factory.ts
var QueryFactory;
((QueryFactory2) => {
  function createEmptyGroupRule() {
    return {
      data: [],
      operator: "group",
      input: ["and"]
    };
  }
  QueryFactory2.createEmptyGroupRule = createEmptyGroupRule;
  function createGroupRule(combinator, data) {
    return {
      input: [combinator],
      operator: "group",
      data
    };
  }
  QueryFactory2.createGroupRule = createGroupRule;
  function createSelectRule(groups, columns) {
    return {
      operator: "querySelect",
      input: columns ?? [],
      data: groups
    };
  }
  QueryFactory2.createSelectRule = createSelectRule;
  function createIsEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsEmptyRule = createIsEmptyRule;
  function createIsNotEmptyRule(input2, data) {
    return {
      operator: "is_empty",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotEmptyRule = createIsNotEmptyRule;
  function createEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createEqualRule = createEqualRule;
  function createGreaterThanRule(input2, data) {
    return {
      operator: "more_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanRule = createGreaterThanRule;
  function createGreaterThanEqualRule(input2, data) {
    return {
      operator: "more_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createGreaterThanEqualRule = createGreaterThanEqualRule;
  function createLessThanRule(input2, data) {
    return {
      operator: "less_than",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanRule = createLessThanRule;
  function createLessThanEqualRule(input2, data) {
    return {
      operator: "less_than_or_equal",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createLessThanEqualRule = createLessThanEqualRule;
  function createIsRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createIsRule = createIsRule;
  function createIsNotRule(input2, data) {
    return {
      operator: "is",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createIsNotRule = createIsNotRule;
  function createNotEqualRule(input2, data) {
    return {
      operator: "equals",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotEqualRule = createNotEqualRule;
  function createOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createOneOfRule = createOneOfRule;
  function createNotOneOfRule(input2, data) {
    return {
      operator: "one_of",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotOneOfRule = createNotOneOfRule;
  function createBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: false
      }
    };
  }
  QueryFactory2.createBetweenRule = createBetweenRule;
  function createNotBetweenRule(input2, data) {
    return {
      operator: "between",
      input: input2,
      data: {
        ...data,
        inverse: true
      }
    };
  }
  QueryFactory2.createNotBetweenRule = createNotBetweenRule;
  function createContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createContainRule = createContainRule;
  function createMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createMatchRule = createMatchRule;
  function createNotMatchRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotMatchRule = createNotMatchRule;
  function createNotContainRule(input2, data) {
    return {
      operator: "contains",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotContainRule = createNotContainRule;
  function createStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createStartsWithRule = createStartsWithRule;
  function createNotStartsWithRule(input2, data) {
    return {
      operator: "starts_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "",
        postfix: "%"
      }
    };
  }
  QueryFactory2.createNotStartsWithRule = createNotStartsWithRule;
  function createEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: false,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createEndsWithRule = createEndsWithRule;
  function createNotEndsWithRule(input2, data) {
    return {
      operator: "ends_with",
      input: input2,
      data: {
        ...data,
        inverse: true,
        prefix: "%",
        postfix: ""
      }
    };
  }
  QueryFactory2.createNotEndsWithRule = createNotEndsWithRule;
  function createPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: false
      }
    };
  }
  QueryFactory2.createPeriodRule = createPeriodRule;
  function createNotPeriodRule(input2, operator, data) {
    return {
      operator,
      input: input2,
      data: {
        ...data,
        input: "",
        inverse: true
      }
    };
  }
  QueryFactory2.createNotPeriodRule = createNotPeriodRule;
})(QueryFactory || (QueryFactory = {}));

// libs/sdk/declarative/src/lib/utils.ts
import { Project, StructureKind, SyntaxKind } from "ts-morph";

// libs/compiler/sdk/devkit/src/lib/project-config.ts
import { Injectable, ServiceLifetime } from "tiny-injector";
var _config;
var ProjectConfig = class {
  constructor() {
    __privateAdd(this, _config, {
      basePath: "./src",
      features: "./src/features",
      tsConfigFilePath: "./tsconfig.json"
    });
  }
  getConfig() {
    return __privateGet(this, _config);
  }
  updateConfig(config2) {
    const current = this.getConfig();
    __privateSet(this, _config, {
      ...current,
      ...config2
    });
  }
};
_config = new WeakMap();
ProjectConfig = __decorateClass([
  Injectable({
    lifetime: ServiceLifetime.Singleton
  })
], ProjectConfig);

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
import { join } from "path";
import { Injectable as Injectable2, ServiceLifetime as ServiceLifetime2 } from "tiny-injector";

// libs/utils/src/index.ts
import {
  camelcase as camelcase2,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";

// libs/compiler/sdk/devkit/src/lib/project-fs.ts
var config = {
  basePath: "./src",
  extensions: "./src/extensions",
  features: "./src/features",
  tsConfigFilePath: "./tsconfig.json"
};
var ProjectFS = class {
  routersGlob() {
    return config.features + "/**/*.router.ts";
  }
  listenersGlob() {
    return config.features + "/**/*.github.ts";
  }
  cronsGlob() {
    return config.features + "/**/*.cron.ts";
  }
  entitiesGlob() {
    return config.features + "/**/*.entity.ts";
  }
  makeCoreImportSpecifier = (importPath) => {
    return join("#{relative}", config.basePath, importPath);
  };
  makeEntityImportSpecifier = (tableName) => {
    return join("#{entity}", pascalcase(tableName));
  };
  makeFeatureFile = (featureName, fileName) => join(config.features, spinalcase2(featureName), fileName);
  makeCorePath = (fileName) => join(config.basePath, "core", fileName);
  makeSrcPath = (fileName) => join(config.basePath, fileName);
  makeWorkspacePath = (fileName) => join(
    config.basePath,
    "../",
    /** We need this to work with new january cli */
    "../",
    fileName
  );
  makeRootPath = (fileName) => join(config.basePath, "../", fileName);
  makeCommandPath = (featureName, tagName, commandName) => this.makeFeatureFile(
    featureName,
    join(spinalcase2(tagName), `${spinalcase2(commandName)}.command.ts`)
  );
  makeIndexFilePath = (featureName, tagName) => this.makeFeatureFile(featureName, join(spinalcase2(tagName), `index.ts`));
  makeControllerPath = (featureName, suffix = "router") => this.makeFeatureFile(
    featureName,
    `${spinalcase2(featureName)}.${dotcase(`${suffix} ts`)}`
  );
  makeControllerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("routes", `${spinalcase2(routeName)}.${dotcase(`route ts`)}`)
  );
  makeListenerRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("listeners", `${spinalcase2(routeName)}.${dotcase(`listener ts`)}`)
  );
  makeJobRoutePath = (featureName, routeName) => this.makeFeatureFile(
    featureName,
    join("jobs", `${spinalcase2(routeName)}.${dotcase(`job ts`)}`)
  );
  makeEntityPath = (featureName, tableName, suffix) => join(
    config.features,
    spinalcase2(featureName),
    `${spinalcase2(tableName)}.${dotcase(`${suffix} ts`)}`
  );
  makeQueryPath = (tableName, queryName) => join(
    config.features,
    spinalcase2(tableName),
    "queries",
    `${spinalcase2(queryName)}.query.ts`
  );
  makeExportPath = (workflowName, suffix) => `./${spinalcase2(workflowName)}.${suffix}`;
};
ProjectFS = __decorateClass([
  Injectable2({
    lifetime: ServiceLifetime2.Singleton
  })
], ProjectFS);
var makeEntityImportSpecifier = (tableName) => {
  return join("#{entity}", pascalcase(tableName));
};

// libs/sdk/declarative/src/lib/utils.ts
function coerceString(value) {
  if (value === void 0 || value === null) {
    return value;
  }
  if (typeof value === "number") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.join(".");
  }
  return value.valueOf();
}
function refineExecute(transferable, options) {
  options.setOutput ??= (arg) => `return output.ok(${typeof arg === "undefined" ? "" : arg})`;
  const guard = transferable.toString();
  const project2 = new Project({
    useInMemoryFileSystem: true
  });
  const sourceFile = project2.createSourceFile(
    "index.ts",
    `const mapFn = ${guard}`
  );
  const triggerIdentifierText = "trigger";
  const guardFunction = sourceFile.getVariableDeclarationOrThrow("mapFn").getInitializerIfKindOrThrow(SyntaxKind.ArrowFunction);
  const inputs = {};
  const parameters = guardFunction.getParameters();
  if (parameters.length > 1) {
    inputs["request"] = {
      static: true,
      type: "IncomingMessage",
      value: `(context.env as { incoming: IncomingMessage }).incoming`,
      data: {
        parameterName: "request",
        standalone: true
      },
      structure: [
        {
          kind: StructureKind.ImportDeclaration,
          moduleSpecifier: "http",
          namedImports: ["IncomingMessage"]
        }
      ]
    };
  }
  const triggerUses = guardFunction.getDescendantsOfKind(SyntaxKind.Identifier).filter(
    (identifier) => identifier.getText() === triggerIdentifierText && !identifier.getFirstAncestorByKind(SyntaxKind.Parameter)
  );
  const tablesUsages = guardFunction.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression).filter((pae) => {
    return pae.getExpressionIfKind(SyntaxKind.Identifier)?.getText() === "tables";
  });
  const tables = [];
  for (const propertyAccess of tablesUsages) {
    const classTableName = pascalcase(propertyAccess.getName());
    tables.push({
      kind: StructureKind.ImportDeclaration,
      moduleSpecifier: makeEntityImportSpecifier(classTableName),
      defaultImport: classTableName
    });
    propertyAccess.replaceWithText(classTableName);
  }
  for (const triggerUse of triggerUses) {
    let parent = triggerUse.getParentWhileKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!parent) {
      inputs["trigger"] = {
        static: true,
        type: "IncomingMessage",
        value: `trigger`,
        data: {
          parameterName: "trigger",
          standalone: true
        }
      };
      continue;
    }
    const fullText = parent.getText();
    const callExpr = parent.getParentIfKind(SyntaxKind.CallExpression);
    if (callExpr && callExpr.getExpressionIfKind(SyntaxKind.PropertyAccessExpression)) {
      parent = parent.getFirstChildByKindOrThrow(
        SyntaxKind.PropertyAccessExpression
      );
    }
    const usageText = parent.getText();
    const [namespace, accesss, ...rest] = usageText.split(".");
    const v = rest.join(".");
    inputs[v] = {
      input: `@${namespace}:${rest.join(".")}`,
      value: fullText.replaceAll(`${triggerIdentifierText}.`, ""),
      data: {
        standalone: false,
        zod: "z.any()"
      }
    };
    parent.replaceWithText(options.replaceKey(v));
  }
  const isOutputReturn = (ret) => {
    const callExpr = ret.getExpressionIfKind(SyntaxKind.CallExpression);
    if (!callExpr) {
      return false;
    }
    const prop = callExpr.getExpressionIfKind(
      SyntaxKind.PropertyAccessExpression
    );
    if (!prop) {
      return false;
    }
    if (prop.getExpressionIfKind(SyntaxKind.Identifier)?.getText() !== "output") {
      return false;
    }
    return true;
  };
  const returns = guardFunction.getDescendantsOfKind(
    SyntaxKind.ReturnStatement
  );
  if (returns.length === 0) {
    guardFunction.addStatements(options.setOutput());
  }
  const atLeastOneOutputReturn = returns.some(isOutputReturn);
  if (!atLeastOneOutputReturn) {
    for (const ret of returns) {
      if (isOutputReturn(ret)) {
        continue;
      }
      const isReturningCall = ret.getExpressionIfKind(
        SyntaxKind.CallExpression
      );
      let returnValue = ret.getText().trim().replace("return ", "");
      if (returnValue.endsWith(";")) {
        returnValue = returnValue.slice(0, -1);
      }
      if (returnValue === "return") {
        ret.replaceWithText(options.setOutput());
      } else {
        ret.replaceWithText(
          options.setOutput(`${isReturningCall ? "await" : ""} ${returnValue}`)
        );
      }
    }
  }
  const body = guardFunction.getBodyText();
  return {
    structures: tables,
    code: body,
    inputs
  };
}

// libs/sdk/declarative/src/lib/query.ts
function where(column, operator, value) {
  const columnName = coerceColumnName(column);
  let condition;
  value = coerceString(value);
  switch (operator) {
    case "after":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "after",
        value
      );
      break;
    case "before":
      condition = QueryFactory.createPeriodRule(
        [columnName],
        "before",
        value
      );
      break;
  }
  if (condition) {
    return {
      kind: "condition",
      implementation: condition
    };
  }
  if (typeof value !== "string") {
    throw new Error(`Value ${value} is not supported`);
  }
  const data = {
    type: "string",
    input: value
  };
  switch (operator) {
    case "equals":
      condition = QueryFactory.createEqualRule([columnName], data);
      break;
    case "not_equals":
      condition = QueryFactory.createNotEqualRule([columnName], data);
      break;
    case "more_than":
      condition = QueryFactory.createGreaterThanRule([columnName], data);
      break;
    case "less_than":
      condition = QueryFactory.createLessThanRule([columnName], data);
      break;
    case "more_than_or_equal":
      condition = QueryFactory.createGreaterThanEqualRule([columnName], data);
      break;
    case "less_than_or_equal":
      condition = QueryFactory.createLessThanEqualRule([columnName], data);
      break;
    case "is":
      condition = QueryFactory.createIsRule([columnName], data);
      break;
    case "is_not_empty":
      condition = QueryFactory.createIsNotEmptyRule([columnName], data);
      break;
    case "is_empty":
      condition = QueryFactory.createIsEmptyRule([columnName], data);
      break;
    case "contains":
      condition = QueryFactory.createContainRule([columnName], data);
      break;
    case "starts_with":
      condition = QueryFactory.createStartsWithRule([columnName], data);
      break;
    case "ends_with":
      condition = QueryFactory.createEndsWithRule([columnName], data);
      break;
    default:
      throw new Error(`Operator ${operator} is not supported`);
  }
  return {
    kind: "condition",
    implementation: condition
  };
}
function sort(name, input2) {
  return {
    kind: "sort",
    implementation: {
      id: coerceColumnName(name),
      input: input2.startsWith("@fixed") ? input2 : `@fixed:${input2}`
    }
  };
}
function isKind(featureOrKind, kind) {
  if (!featureOrKind) {
    return false;
  }
  if (typeof featureOrKind === "string") {
    return (feature2) => feature2 && feature2.kind === featureOrKind;
  }
  return featureOrKind.kind === kind;
}
function query(...features) {
  const sorts = features.filter(isKind("sort"));
  const columns = features.filter((f) => f.kind === "select").map((f) => f.implementation);
  const conditions = features.filter(isKind("condition"));
  const groups = [
    ...features.filter((f) => f.kind === "group"),
    and(...conditions)
    // wrap this in an "and" group to simulate implicit "and" condition
  ].map((f) => f.implementation);
  const limit2 = features.find(isKind("limit"))?.implementation;
  return {
    whereBy: QueryFactory.createSelectRule(groups, columns),
    sortBy: sorts.map((it) => it.implementation),
    limit: limit2
  };
}
query.sql = (sql) => {
};
function select(name) {
  return {
    kind: "select",
    implementation: {
      name
    }
  };
}
function and(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("and", rules)
  };
}
function or(...features) {
  const rules = features.map((f) => f.implementation);
  return {
    kind: "group",
    implementation: QueryFactory.createGroupRule("or", rules)
  };
}
var coerceColumnName = (column) => {
  if (!column.startsWith("@tables")) {
    return `@tables:fields.${column}`;
  }
  return column;
};
var date;
((date2) => {
  let after;
  ((after2) => {
    function startOfThisWeek() {
      return weeksAgo(0);
    }
    after2.startOfThisWeek = startOfThisWeek;
    function weekAgo() {
      return weeksAgo(1);
    }
    after2.weekAgo = weekAgo;
    function weeksAgo(amount, relativeTo = "now") {
      return {
        period: "week",
        amount: -Math.abs(amount),
        relativeTo
      };
    }
    after2.weeksAgo = weeksAgo;
    function weekInYear(n, relativeTo = "now") {
    }
    function monthInYear(n) {
    }
    function startOfThisMonth() {
      return monthsAgo(0);
    }
    after2.startOfThisMonth = startOfThisMonth;
    function monthAgo() {
      return monthsAgo(1);
    }
    after2.monthAgo = monthAgo;
    function monthsAgo(amount) {
      return {
        period: "month",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.monthsAgo = monthsAgo;
    function startOfThisYear() {
      return yearsAgo(0);
    }
    after2.startOfThisYear = startOfThisYear;
    function yearAgo() {
      return yearsAgo(1);
    }
    after2.yearAgo = yearAgo;
    function yearsAgo(amount) {
      return {
        period: "year",
        amount: -Math.abs(amount),
        relativeTo: "now"
      };
    }
    after2.yearsAgo = yearsAgo;
  })(after = date2.after || (date2.after = {}));
})(date || (date = {}));
function limit(upTo) {
  return {
    kind: "limit",
    implementation: upTo
  };
}

// libs/sdk/declarative/src/lib/validation.ts
function mandatory(config2 = {}) {
  return {
    name: "mandatory",
    details: {
      value: "true",
      message: config2.message
    }
  };
}
var required = mandatory;
function unique(config2 = {}) {
  return [
    mandatory(),
    {
      name: "unique",
      details: {
        value: "true",
        message: config2.message
      }
    }
  ];
}
function defineValidation(config2) {
  return {
    name: config2.name,
    config: config2
  };
}
var validation;
((validation2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? validation2 : defineValidation;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown validation type: ${type}`);
  }
  validation2.fromConfig = fromConfig;
})(validation || (validation = {}));

// libs/sdk/declarative/src/lib/table.ts
var CREATED_AT = /^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var UPDATED_AT = /^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
var DELETED_AT = /^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;
function table(config2) {
  const additionalFields = {};
  const idField = Object.values(config2.fields).find(
    (def) => (
      // TODO: these types should come from the installed database extension
      ["primary-key-uuid", "primary-key-number", "primary-key-custom"].includes(
        def.type
      )
    )
  );
  if (!idField) {
    additionalFields["id"] = field.primary({
      type: "uuid",
      generated: true
    });
  }
  const createdAtField = Object.keys(config2.fields).find(
    (key) => CREATED_AT.test(key)
  );
  const updatedAtField = Object.keys(config2.fields).find(
    (key) => UPDATED_AT.test(key)
  );
  const deletedAtField = Object.keys(config2.fields).find(
    (key) => DELETED_AT.test(key)
  );
  if (!createdAtField) {
    additionalFields["createdAt"] = field({
      type: "datetime",
      metadata: {
        system_created_at: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true
      }
    });
  }
  if (!updatedAtField) {
    additionalFields["updatedAt"] = field({
      type: "datetime",
      metadata: {
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: true,
        system_updated_at: true
      }
    });
  }
  if (!deletedAtField) {
    additionalFields["deletedAt"] = field({
      type: "datetime",
      metadata: {
        system_deleted_at: true,
        system_auto_generated: true,
        can_be_deleted: false,
        can_be_updated: false
      }
    });
  }
  return {
    fields: {
      ...config2.fields,
      ...additionalFields
    },
    constraints: config2.constraints || []
  };
}
table.unique = (...fields) => {
  return {
    type: "unique",
    details: {
      columns: fields
    }
  };
};
table.index = (...fields) => {
  return {
    type: "index",
    details: {
      columns: fields
    }
  };
};
table.use = useTable;
function useTable(name) {
  return {
    command: "QueryTable",
    payload: {
      name
    }
  };
}
function field(config2) {
  const { type, validations = [], metadata = {}, ...rest } = config2;
  return {
    type: config2.type,
    details: {
      ...metadata,
      ...rest
    },
    validations
  };
}
((field2) => {
  function fromConfig(type, ...args) {
    if (typeof type === "string") {
      const parts = type.split(".");
      let impl = field2;
      while (parts.length) {
        impl = impl[parts.shift()];
      }
      if (impl) {
        return impl(...args);
      }
      if (type.endsWith(".rule")) {
        const reports = [];
        return reports;
      }
      throw new Error(`Unknown field type: ${type}`);
    }
    return field2(type);
  }
  field2.fromConfig = fromConfig;
  function primary(config2) {
    const typesMap = {
      uuid: "primary-key-uuid",
      number: "primary-key-number",
      string: "primary-key-custom"
    };
    return {
      type: typesMap[config2.type],
      details: {
        system_primary_key: true,
        can_be_deleted: false,
        can_be_updated: false,
        system_auto_generated: config2.generated ?? true
      },
      validations: [mandatory()]
    };
  }
  field2.primary = primary;
  function shortText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "short-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.shortText = shortText;
  function longText(config2 = {}) {
    const { validations, ...metadata } = config2;
    return field2({
      type: "long-text",
      validations: validations ?? [],
      metadata
    });
  }
  field2.longText = longText;
  function datetime(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "datetime",
      details: metadata,
      validations
    };
  }
  field2.datetime = datetime;
  function url(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "url",
      details: metadata,
      validations
    };
  }
  field2.url = url;
  function integer() {
    return {
      type: "integer",
      details: {},
      validations: []
    };
  }
  field2.integer = integer;
  function decimal(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "decimal",
      details: metadata,
      validations
    };
  }
  field2.decimal = decimal;
  function price(config2 = {}) {
    const { validations = [], scale = 3, precision = 8, ...metadata } = config2;
    return field2.decimal({
      scale,
      ...metadata,
      precision,
      validations
    });
  }
  field2.price = price;
  function boolean(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "boolean",
      details: metadata,
      validations
    };
  }
  field2.boolean = boolean;
  function bytes(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "bytes",
      details: metadata,
      validations
    };
  }
  field2.bytes = bytes;
  function email(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "email",
      details: metadata,
      validations
    };
  }
  field2.email = email;
  function json(config2 = {}) {
    const { validations = [], ...metadata } = config2;
    return {
      type: "json",
      details: metadata,
      validations
    };
  }
  field2.json = json;
  function relation(config2) {
    return field2({
      type: "relation",
      metadata: config2,
      validations: config2.validations
    });
  }
  field2.relation = relation;
})(field || (field = {}));
field.enum = (config2) => {
  return field({
    type: "single-select",
    metadata: {
      style: "enum",
      values: config2.values,
      defaultValue: config2.defaultValue
    }
  });
};
function useField(name, value) {
  value = coerceString(value);
  if (value === void 0) {
    return {
      input: {
        command: "QueryFieldName",
        payload: {
          name
        }
      }
    };
  }
  return {
    ...input(value),
    name: {
      command: "QueryField",
      payload: {
        name
      }
    }
  };
}
useField.increment = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      increment: true
    }
  };
};
useField.decrement = (name, value) => {
  return {
    ...useField(name, value),
    data: {
      decrement: true
    }
  };
};
function index(...fields) {
  return {
    type: "index",
    details: {
      columns: fields.map((field2) => ({
        command: "QueryFieldName",
        payload: {
          name: field2
        }
      }))
    }
  };
}

// libs/sdk/declarative/src/lib/workflow.ts
function workflow(name, config2) {
  const execute = config2.trigger.refineExecute(config2.execute);
  return {
    name,
    trigger: config2.trigger,
    raw: !Object.keys(config2.trigger.inputs ?? {}).length,
    execute,
    tag: config2.tag
  };
}
function defineTrigger(type, config2) {
  return {
    type,
    config: config2
  };
}
var trigger;
((trigger2) => {
  function fromConfig(type, ...args) {
    const parts = type.split(".");
    let impl = parts.length ? trigger2 : defineTrigger;
    while (parts.length) {
      impl = impl[parts.shift()];
    }
    if (impl) {
      return impl(...args);
    }
    if (type.endsWith(".rule")) {
      const reports = [];
      return reports;
    }
    throw new Error(`Unknown trigger type: ${type}`);
  }
  trigger2.fromConfig = fromConfig;
})(trigger || (trigger = {}));
((trigger2) => {
  function schedule(config2) {
    return {
      type: "node-cron-trigger",
      config: config2,
      policies: [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  }
  trigger2.schedule = schedule;
})(trigger || (trigger = {}));
((trigger2) => {
  function github(config2) {
    const inputs = {};
    return {
      type: "github-trigger",
      inputs,
      config: config2,
      policies: config2.policies ?? [],
      refineExecute: (execute) => {
        return refineExecute(execute, {
          replaceKey: (key) => key
        });
      }
    };
  }
  trigger2.github = github;
})(trigger || (trigger = {}));

// libs/sdk/parser/src/index.ts
import { readFileSync } from "fs";
var checker;
((checker2) => {
  function isCallExpression(node, name) {
    if (!node) {
      return false;
    }
    const isCallExpr = node.type === "CallExpression";
    if (!isCallExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    if (node.callee.type === "MemberExpression") {
      return node.callee.property.type === "Identifier" && node.callee.property.value === name;
    }
    return node.callee.type === "Identifier" && node.callee.value === name;
  }
  checker2.isCallExpression = isCallExpression;
  function isObjectExpression(node) {
    return node.type === "ObjectExpression";
  }
  checker2.isObjectExpression = isObjectExpression;
  function isKeyValueProperty(node, valueType, keyName) {
    if (node.type !== "KeyValueProperty") {
      return false;
    }
    if (!valueType) {
      return true;
    }
    const sameType = node.value.type === valueType;
    if (!sameType) {
      return false;
    }
    if (!keyName) {
      return true;
    }
    return isIdentifier(node.key, keyName);
  }
  checker2.isKeyValueProperty = isKeyValueProperty;
  function isNullLiteral(node) {
    return node.type === "NullLiteral";
  }
  checker2.isNullLiteral = isNullLiteral;
  function isPrimitive(node) {
    if (node.type === "StringLiteral" || node.type === "BooleanLiteral" || node.type === "NumericLiteral" || node.type === "BigIntLiteral") {
      return true;
    }
    return false;
  }
  checker2.isPrimitive = isPrimitive;
  function isIdentifier(node, name) {
    if (!node) {
      return false;
    }
    const isIdentifier2 = node.type === "Identifier";
    if (!isIdentifier2) {
      return false;
    }
    if (!name) {
      return true;
    }
    return node.value === name;
  }
  checker2.isIdentifier = isIdentifier;
  function isMemberExpression(node, name) {
    if (!node) {
      return false;
    }
    const isMemberExpr = node.type === "MemberExpression";
    if (!isMemberExpr) {
      return false;
    }
    if (!name) {
      return true;
    }
    return isIdentifier(node.property, name);
  }
  checker2.isMemberExpression = isMemberExpression;
  function isArrayExpression(node) {
    return node.type === "ArrayExpression";
  }
  checker2.isArrayExpression = isArrayExpression;
})(checker || (checker = {}));
var Checker;
((Checker2) => {
  function isPrimitive(value) {
    return value !== Object(value);
  }
  Checker2.isPrimitive = isPrimitive;
  function isCallExpression(value) {
    return !isPrimitive(value) && typeof value === "object" && "caller" in value && "arguments" in value;
  }
  Checker2.isCallExpression = isCallExpression;
  function isObjectExpression(value) {
    return !isCallExpression(value) && value !== null && typeof value === "object";
  }
  Checker2.isObjectExpression = isObjectExpression;
  function isArrayExpression(value) {
    return Array.isArray(value);
  }
  Checker2.isArrayExpression = isArrayExpression;
})(Checker || (Checker = {}));
function isRecord(obj) {
  return typeof obj === "object" && obj !== null;
}
function isSpan(obj) {
  return typeof obj === "object" && obj !== null && "start" in obj && "end" in obj;
}
function adjustOffsetOfAst(obj, startOffset) {
  if (Array.isArray(obj)) {
    obj.forEach((item) => adjustOffsetOfAst(item, startOffset));
  } else if (isRecord(obj)) {
    Object.entries(obj).forEach(([key, value]) => {
      if (key === "span" && value && isSpan(value)) {
        const span = value;
        span.start -= startOffset;
        span.end -= startOffset;
      } else {
        adjustOffsetOfAst(obj[key], startOffset);
      }
    });
  }
}
async function parseCode(code) {
  const { default: initSync, parseSync } = await import(
    /* webpackIgnore: true */
    "@swc/wasm-web"
  );
  const originalFetch = global.fetch;
  global.fetch = async function(...args) {
    const [url] = args;
    if (url instanceof URL && url.protocol === "file:") {
      return new Response(readFileSync(url.pathname), {
        headers: {
          "Content-Type": "application/wasm"
        }
      });
    }
    return originalFetch.apply(this, args);
  };
  await initSync();
  global.fetch = originalFetch;
  if (typeof code !== "string" || !code.trim()) {
    return null;
  }
  const val = parseSync(code, {
    syntax: "typescript",
    decorators: false,
    comments: false,
    dynamicImport: false,
    script: false,
    tsx: false,
    target: "es2022"
  });
  {
    adjustOffsetOfAst(val, val.span.start);
  }
  return val;
}
async function legacy_parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const projectExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!projectExpr) {
    return null;
  }
  if (!checker.isCallExpression(projectExpr.expression, "project")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(projectExpr.expression, code)
  };
}
async function parse(code) {
  const val = await parseCode(code);
  if (!val) {
    return null;
  }
  const defaultExpr = val.body.find(
    (it) => it.type === "ExportDefaultExpression"
  );
  if (!defaultExpr) {
    return null;
  }
  if (!checker.isCallExpression(defaultExpr.expression, "feature")) {
    return null;
  }
  return {
    imports: getImports(val.body, code),
    project: resolveCallExpression(defaultExpr.expression, code)
  };
}
function getImports(items, sourceCode) {
  return items.filter((it) => it.type === "ImportDeclaration").filter((it) => it.source.value !== "@january/declarative").filter((it) => !it.source.value.endsWith(".g.ts")).map(
    (it) => ({
      isTypeOnly: it.typeOnly,
      moduleSpecifier: it.source.value,
      defaultImport: it.specifiers.find(
        (sp) => sp.type === "ImportDefaultSpecifier"
      )?.local.value,
      namespaceImport: it.specifiers.find(
        (sp) => sp.type === "ImportNamespaceSpecifier"
      )?.local.value,
      namedImports: it.specifiers.filter((sp) => sp.type === "ImportSpecifier").map(
        (sp) => ({
          name: sp.imported ? sp.imported.value : sp.local.value,
          alias: sp.imported ? sp.local.value : void 0,
          isTypeOnly: sp.isTypeOnly
        })
      )
    })
  );
}
function resolveAsExpression(node, sourceCode) {
  const args = [];
  if (checker.isNullLiteral(node.expression)) {
    args.push(null);
  }
  if (node.expression.type === "TemplateLiteral") {
    args.push(
      sourceCode.slice(
        node.expression.span.start + 1,
        // remove start `
        node.expression.span.end - 1
        // remove end `
      )
    );
  }
  if (checker.isPrimitive(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isIdentifier(node.expression)) {
    args.push(node.expression.value);
  }
  if (checker.isObjectExpression(node.expression)) {
    args.push(resolveObjectExpression(node.expression, sourceCode));
  }
  if (checker.isCallExpression(node.expression)) {
    args.push(resolveCallExpression(node.expression, sourceCode));
  }
  if (checker.isMemberExpression(node.expression)) {
    args.push(resolveMemberExpression(node.expression, []).join("."));
  }
  if (node.expression.type === "TsAsExpression") {
    args.push(resolveAsExpression(node.expression, sourceCode));
  }
  return args;
}
function resolveCallExpression(node, sourceCode) {
  const args = [];
  for (const arg of node.arguments) {
    if (checker.isNullLiteral(arg.expression)) {
      args.push(null);
      continue;
    }
    if (arg.expression.type === "UnaryExpression") {
      args.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      args.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      args.push(arg.expression.value);
      continue;
    }
    if (checker.isIdentifier(arg.expression)) {
      args.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      args.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      args.push(resolveCallExpression(arg.expression, sourceCode));
    }
    if (checker.isMemberExpression(arg.expression)) {
      args.push(resolveMemberExpression(arg.expression, []));
    }
    if (arg.expression.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "FunctionExpression") {
      if (sourceCode) {
        args.push(
          sourceCode.slice(arg.expression.span.start, arg.expression.span.end)
        );
      }
    }
    if (arg.expression.type === "TsAsExpression") {
      args.push(resolveAsExpression(arg.expression, sourceCode));
    }
  }
  let calleeName = "";
  if (checker.isMemberExpression(node.callee)) {
    const [...actionPath] = resolveMemberExpression(node.callee, []);
    calleeName = actionPath.join(".");
  }
  if (checker.isIdentifier(node.callee)) {
    calleeName = node.callee.value;
  }
  return {
    caller: calleeName,
    arguments: args,
    span: node.span
  };
}
function resolveUnaryExpression(node) {
  if (node.argument.type === "NumericLiteral") {
    return Number(`${node.operator}${node.argument.value}`);
  }
  return `${node.operator}${node.argument.value}`;
}
function resolveArrayExpression(node, sourceCode) {
  const list = [];
  for (const arg of node.elements) {
    if (!arg) {
      continue;
    }
    if (checker.isNullLiteral(arg.expression)) {
      list.push(null);
    }
    if (arg.expression.type === "UnaryExpression") {
      list.push(resolveUnaryExpression(arg.expression));
      continue;
    }
    if (arg.expression.type === "TemplateLiteral") {
      list.push(
        sourceCode.slice(
          arg.expression.span.start + 1,
          // remove start `
          arg.expression.span.end - 1
          // remove end `
        )
      );
    }
    if (checker.isPrimitive(arg.expression)) {
      list.push(arg.expression.value);
    }
    if (checker.isObjectExpression(arg.expression)) {
      list.push(resolveObjectExpression(arg.expression, sourceCode));
    }
    if (checker.isCallExpression(arg.expression)) {
      list.push(resolveCallExpression(arg.expression, sourceCode));
    }
  }
  return list;
}
function resolveObjectExpression(node, sourceCode) {
  const obj = {};
  for (const prop of node.properties) {
    if (!checker.isKeyValueProperty(prop)) {
      continue;
    }
    if (!checker.isIdentifier(prop.key)) {
      continue;
    }
    if (checker.isNullLiteral(prop.value)) {
      obj[prop.key.value] = null;
      continue;
    }
    if (prop.value.type === "UnaryExpression") {
      obj[prop.key.value] = resolveUnaryExpression(prop.value);
      continue;
    }
    if (prop.value.type === "TemplateLiteral") {
      obj[prop.key.value] = sourceCode.slice(
        prop.value.span.start + 1,
        // remove start `
        prop.value.span.end - 1
        // remove end `
      );
      continue;
    }
    if (checker.isPrimitive(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isIdentifier(prop.value)) {
      obj[prop.key.value] = prop.value.value;
      continue;
    }
    if (checker.isKeyValueProperty(prop, "CallExpression")) {
      obj[prop.key.value] = resolveCallExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isArrayExpression(prop.value)) {
      obj[prop.key.value] = resolveArrayExpression(prop.value, sourceCode);
      continue;
    }
    if (checker.isObjectExpression(prop.value)) {
      obj[prop.key.value] = resolveObjectExpression(prop.value, sourceCode);
      continue;
    }
    if (prop.value.type === "NewExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (prop.value.type === "ArrowFunctionExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
    if (checker.isMemberExpression(prop.value) || prop.value.type === "TsAsExpression") {
      if (sourceCode) {
        obj[prop.key.value] = sourceCode.slice(
          prop.value.span.start,
          prop.value.span.end
        );
      }
    }
  }
  return obj;
}
function resolveMemberExpression(node, acc) {
  const collection = acc.slice(0);
  if (checker.isIdentifier(node.object)) {
    collection.push(node.object.value);
  }
  if (checker.isMemberExpression(node.object)) {
    collection.push(...resolveMemberExpression(node.object, acc));
  }
  if (checker.isIdentifier(node.property)) {
    collection.push(node.property.value);
  }
  return collection;
}

// libs/sdk/evaluator/src/lib/evaluate.ts
var defaultPrimitiveCallers = {
  project,
  table,
  feature,
  workflow,
  field: field.fromConfig,
  validation: validation.fromConfig,
  mandatory,
  required,
  unique,
  useTable,
  useField,
  query,
  select,
  sort,
  where,
  limit,
  and,
  or,
  input,
  index,
  withTrigger: (...args) => {
  }
};
var EVAL_ERRORS = {
  UNKNOWN_CALLER: randomBytes(5).toString("hex")
};
function staticEval(callers2, node, hooks = {}) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    let callerImpl = callers2[implFn];
    if (!callerImpl && !hooks.unknownCaller) {
      throw new Error(
        `${EVAL_ERRORS.UNKNOWN_CALLER}: Unknown caller ${node.caller}`
      );
    } else {
      callerImpl ??= hooks.unknownCaller?.(node, implFn);
      if (!callerImpl) {
        return null;
      }
    }
    const args = node.arguments.map((it) => staticEval(callers2, it, hooks));
    if (typeof callerImpl === "function") {
      if (type.length) {
        args.unshift(type.join("."));
      }
      return callerImpl(...args);
    }
    return get(callerImpl, type)(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => staticEval(callers2, it, hooks));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      obj[key] = staticEval(callers2, value, hooks);
    }
    return obj;
  }
  return node;
}
async function defensiveEvaluate(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  const features = staticEval(
    defaultPrimitiveCallers,
    ast.project
  );
  const service = {
    getFeature(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "feature") {
          return features.find(
            (feature2) => feature2.name === parent.node.arguments[0]
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    getWorkflow(descendantNode) {
      let parent = descendantNode.parent;
      while (parent) {
        if (Checker.isCallExpression(parent.node) && parent.node.caller === "workflow") {
          const feature2 = this.getFeature(parent);
          const [workflowName] = parent.node.arguments;
          return feature2?.workflows.find(
            (workflow2) => workflow2.name === workflowName
          );
        }
        parent = parent.parent;
      }
      return void 0;
    },
    duplicateWorkflowTriggerConfig: (relatedWorkflow, check) => {
      for (const feature2 of features) {
        for (const workflow2 of feature2.workflows) {
          if (workflow2 === relatedWorkflow) {
            continue;
          }
          if (check(workflow2, feature2)) {
            return true;
          }
        }
      }
      return false;
    },
    hasField: (name) => features.some(
      (feature2) => Object.keys(feature2.tables ?? {}).some(
        (table2) => Object.keys(feature2.tables[table2].fields).includes(name)
      )
    ),
    hasTable: (name) => features.some((feature2) => {
      return (feature2.tables ?? {})[name];
    }),
    inUniqueFeature: (name) => {
      let count = 0;
      for (const feature2 of features) {
        if (feature2.name === name) {
          count++;
        }
      }
      return count === 1;
    },
    isUniqueWorkflow: (name) => {
      for (const feature2 of features) {
        let count = 0;
        for (const workflow2 of feature2.workflows) {
          if (workflow2.name === name) {
            count++;
          }
        }
        if (count > 1) {
          return false;
        }
      }
      return true;
    },
    validateName(name, context) {
      const errors = [];
      if (typeof name !== "string") {
        errors.push(`${context} must be a string`);
      } else if (name.trim().length === 0) {
        errors.push(`${context} must not be empty`);
      }
      return errors;
    }
  };
  return {
    reports: [],
    definition: {
      features,
      imports: ast.imports
    }
  };
}
async function evaluate(code, callers2) {
  const ast = await parse(code);
  if (!ast) {
    throw new Error("Failed to parse the code");
  }
  return {
    feature: staticEval(callers2, ast.project),
    imports: ast.imports
  };
}
async function compare(a, b) {
  const removeSpans = (node) => {
    if (!node) return "";
    return JSON.stringify(node, (key, value) => {
      if (key === "span") {
        return void 0;
      }
      return value;
    });
  };
  return removeSpans((await legacy_parse(a))?.project ?? null) === removeSpans((await legacy_parse(a))?.project ?? null);
}

// libs/sdk/evaluator/src/lib/infertype.ts
var noop = () => {
};
var callers = {
  project: (...args) => {
    const [name, config2] = args;
    return args[0];
  },
  feature: (...args) => {
    const [name, config2] = args;
    return {
      workflows: config2.workflows,
      tables: config2.tables,
      featureName: name
    };
  },
  table,
  field,
  workflow,
  trigger: trigger.fromConfig,
  useTable: noop,
  mandatory: noop,
  required: noop,
  unique: noop,
  useField: noop,
  query: noop,
  select: noop,
  sort: noop,
  where: noop,
  limit: noop,
  and: noop,
  or: noop,
  input: noop,
  index: noop
};
function call(node, metadata, parent) {
  if (Checker.isCallExpression(node)) {
    const [implFn, ...type] = node.caller.split(".");
    const callerImpl = callers[implFn];
    if (!callerImpl) {
      throw new Error(`Unknown caller ${node.caller}`);
    }
    const args = node.arguments.map((it) => call(it));
    if (type.length) {
      args.unshift([...type, "dts"].join("."));
    } else {
      if ("dts" in callerImpl) {
        return callerImpl.dts(...args, metadata);
      }
    }
    return callerImpl(...args);
  }
  if (Checker.isArrayExpression(node)) {
    return node.map((it) => call(it));
  }
  if (Checker.isObjectExpression(node)) {
    const obj = {};
    for (const [key, value] of Object.entries(node)) {
      if (metadata === "actions") {
        obj[key] = call(
          {
            caller: "action.trigger",
            arguments: [value]
          },
          key
        );
      } else {
        obj[key] = call(value, key, node);
      }
    }
    return obj;
  }
  return node;
}
async function inferType(code) {
  const ast = await legacy_parse(code);
  if (!ast) {
    return [];
  }
  const result = call(ast.project);
  return result;
}
export {
  EVAL_ERRORS,
  compare,
  defaultPrimitiveCallers,
  defensiveEvaluate,
  evaluate,
  inferType,
  staticEval
};
