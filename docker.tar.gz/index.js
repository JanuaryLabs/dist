// libs/docker/src/index.ts
import { parse } from "dotenv";
import { readFile as readFile2 } from "fs/promises";
import { join as join3 } from "path";
import { PassThrough } from "stream";
import tarStream from "tar-stream";

// libs/utils/src/index.ts
import {
  camelcase,
  cramcase,
  dotcase,
  pascalcase,
  sentencecase,
  snakecase as snakecase2,
  spinalcase as spinalcase2,
  titlecase
} from "stringcase";

// libs/utils/src/lib/parser/index.ts
import { v4 } from "uuid";

// libs/utils/src/lib/utils.ts
import { get } from "lodash-es";
import retry from "retry";
import { snakecase, spinalcase } from "stringcase";
async function extractError(fn) {
  try {
    return [await fn(), void 0];
  } catch (error) {
    return [void 0, error];
  }
}
function removeDuplicates(data, accessor) {
  return [...new Map(data.map((x) => [accessor(x), x])).values()];
}

// libs/docker/src/lib/instance.ts
import Docker from "dockerode";
var docker = new Docker();

// libs/docker/src/lib/utils.ts
import crypto from "crypto";
import { createReadStream, existsSync } from "fs";
import { mkdir, readFile, rm, writeFile } from "fs/promises";
import { tmpdir } from "os";
import { basename, dirname, join } from "path";
function followProgress(stream, logger = console) {
  return new Promise((resolve, reject) => {
    docker.modem.followProgress(
      stream,
      (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      },
      (obj) => {
        try {
          if ("error" in obj) {
            reject(obj);
          }
        } finally {
          logger.log(obj);
        }
      }
    );
  });
}
async function upsertVolume(name) {
  try {
    return await docker.getVolume(name).inspect();
  } catch (error) {
    const { statusCode, message } = error;
    if (statusCode === 404) {
      return await docker.createVolume({ Name: name });
    }
    throw error;
  }
}
function upsertNetwork(name) {
  return docker.getNetwork(name).inspect().catch(() => docker.createNetwork({ Name: name }));
}
async function getContainer(containerId) {
  if (typeof containerId === "string") {
    return docker.getContainer(containerId);
  }
  const containers = await docker.listContainers({ all: true });
  const container = containers.find(
    (c) => c.Names.includes(`/${containerId.name}`)
  );
  if (!container) {
    return null;
  }
  return docker.getContainer(container.Id);
}
async function removeContainer(nameOrContainer, wait) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    throw new Error("Container not found");
  }
  const isRunning = await isContainerRunning(container);
  if (isRunning) {
    const options = wait === 0 ? { t: wait } : {};
    await container.stop(options).catch(console.error);
  }
  await container.remove({
    force: wait === 0
  }).catch(console.error);
}
async function isContainerRunning(nameOrContainer) {
  const container = typeof nameOrContainer === "string" ? await getContainer({ name: nameOrContainer }) : nameOrContainer;
  if (!container) {
    return false;
  }
  return container.inspect().then((info) => info.State.Running);
}
function computeChecksum(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("md5");
    const stream = typeof filePath === "string" ? createReadStream(filePath) : filePath;
    stream.on("data", (data) => hash.update(data));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", (err) => reject(err));
  });
}
async function fileChanged(filePath, discrminator) {
  const checksumDirPath = join(tmpdir(), discrminator);
  await mkdir(checksumDirPath, { recursive: true });
  const checksumFilePath = join(checksumDirPath, basename(filePath));
  const currentChecksum = await computeChecksum(filePath);
  const flush = async () => {
    await rm(checksumFilePath, { force: true });
  };
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
async function contentChanged(content, fileName, discrminator) {
  const checksumFilePath = join(tmpdir(), discrminator, fileName);
  await mkdir(dirname(checksumFilePath), { recursive: true });
  const filePath = join(tmpdir(), "check", discrminator, fileName);
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, "utf-8");
  const currentChecksum = await computeChecksum(filePath);
  const flush = async () => {
    await rm(checksumFilePath, { force: true });
  };
  if (!existsSync(checksumFilePath)) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
    return {
      changed: true,
      flush
    };
  }
  const storedChecksum = await readFile(checksumFilePath, "utf-8");
  const changed = currentChecksum !== storedChecksum;
  if (changed) {
    await writeFile(checksumFilePath, currentChecksum, "utf-8");
  }
  return {
    changed,
    flush
  };
}
async function followLogs(container) {
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    details: true
  });
  container.modem.demuxStream(stream, process.stdout, process.stderr);
}
async function startContainer(name, createContainer) {
  let container = null;
  if (typeof name === "string") {
    container = await getContainer({ name });
  } else {
    container = name;
  }
  if (!container) {
    if (!createContainer) {
      throw new Error(`Cannot initialize server for project: ${name}`);
    }
    container = await createContainer();
  }
  const running = await isContainerRunning(container);
  if (!running) {
    await container.start().catch((error) => {
      if (error.statusCode === 304) {
        return;
      }
      throw error;
    });
  }
  return container;
}
async function getContainerNet(containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings;
}
async function getContainerExternalPort(internalPort, containerId) {
  let container;
  if (typeof containerId === "string" || "name" in containerId) {
    container = await getContainer(containerId);
  } else {
    container = containerId;
  }
  if (!container) {
    throw new Error("Container not found");
  }
  const data = await container.inspect();
  return data.NetworkSettings.Ports[`${internalPort}/tcp`][0].HostPort;
}
async function pushImage(repo, tag = "latest") {
  const image = docker.getImage(repo);
  const stream = await image.push({
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    },
    tag
  });
  await followProgress(stream);
  return image;
}
async function pullImage(image, tag = "latest") {
  const stream = await docker.createImage({
    fromImage: image,
    tag,
    authconfig: {
      username: "docker user name",
      password: "docker access token not personal password",
      serveraddress: "https://index.docker.io/v1/"
    }
  });
  await followProgress(stream);
  return image;
}
async function imagesExists(...tags) {
  const images = await docker.listImages({
    all: true
  });
  const imageTags = images.flatMap((image) => image.RepoTags);
  return tags.every((tag) => {
    return imageTags.includes(tag.includes(":") ? tag : `${tag}:latest`);
  });
}

// libs/docker/src/compose.ts
import yaml from "js-yaml";

// libs/modern/src/index.ts
import { mkdir as mkdir2, writeFile as writeFile2 } from "fs/promises";
import { dirname as dirname2, isAbsolute, join as join2 } from "path";
import { tap } from "rxjs/operators";

// libs/utils/formatter/src/lib/format-code.ts
async function formatCode(code, extension, ignoreError = true) {
  if (!code || code.trim().length === 0) return "";
  function whatIsParserImport() {
    switch (extension) {
      case "ts":
        return {
          parserImport: [import("prettier/plugins/typescript")],
          parserName: "typescript"
        };
      case "js":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "babel"
        };
      case "html":
        return {
          parserImport: [import("prettier/plugins/html")],
          parserName: "html"
        };
      case "css":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "css"
        };
      case "scss":
        return {
          parserImport: [import("prettier/plugins/postcss")],
          parserName: "scss"
        };
      case "code-snippets":
      case "json":
      case "prettierrc":
        return {
          parserImport: [import("prettier/plugins/babel")],
          parserName: "json"
        };
      case "md":
        return {
          parserImport: [import("prettier/plugins/markdown")],
          parserName: "markdown"
        };
      case "yaml":
      case "yml":
        return {
          parserImport: [import("prettier/plugins/yaml")],
          parserName: "yaml"
        };
      case "":
      case "gitignore":
      case "dockerignore":
      case "prettierignore":
      case "Dockerfile":
      case "toml":
      case "env":
      case "txt":
        return {
          parserImport: [],
          parserName: ""
        };
      default:
        return {
          parserImport: [],
          parserName: ""
        };
    }
  }
  const { parserImport, parserName } = whatIsParserImport();
  if (!parserName) return code;
  const [prettier, ...plugins] = await Promise.all([
    import("prettier/standalone"),
    import("prettier/plugins/estree").then((e) => e),
    ...parserImport
  ]);
  try {
    return prettier.format(code, {
      parser: parserName,
      plugins,
      singleQuote: true
    }).then((formattedCode) => formattedCode.trim());
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === "SyntaxError") {
        return ignoreError === true ? code : formatCode(code, "ts", true);
      }
    }
    if (!ignoreError) {
      throw error;
    }
    return code;
  }
}

// libs/compiler/generator/utils/src/index.ts
var getExt = (fileName) => {
  if (!fileName) {
    return "";
  }
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }
  const ext = fileName.slice(lastDot + 1).split("/").filter(Boolean).join("");
  if (ext === fileName) {
    return "";
  }
  return ext || "txt";
};

// libs/modern/src/lib/browser.fs.ts
import localforage from "localforage";

// libs/modern/src/lib/octokit.ts
import { differenceInSeconds } from "date-fns";

// libs/modern/src/index.ts
var baseUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:4321" : "https://api.january.sh";
var serverizeUrl = process.env["NODE_ENV"] === "development" ? "http://localhost:3100" : "https://dev.january.sh";
var serverizeWs = process.env["NODE_ENV"] === "development" ? "ws://localhost:3100" : "wss://dev.january.sh";
async function writeFiles(dir, contents) {
  for (const [file, content] of Object.entries(contents)) {
    const filePath = isAbsolute(file) ? file : join2(dir, file);
    await mkdir2(dirname2(filePath), { recursive: true });
    await writeFile2(
      filePath,
      await formatCode(
        typeof content === "string" ? content : JSON.stringify(content),
        getExt(file)
      ),
      "utf-8"
    );
  }
}

// libs/docker/src/compose.ts
function compose(services) {
  const dockerCompose = {
    volumes: {},
    networks: {},
    services: {}
  };
  const appEnvironment = {};
  for (const [serviceName, it] of Object.entries(services)) {
    const depends_on = it.dependsOn(services);
    Object.assign(appEnvironment, it.composeService.appEnvironment ?? {});
    delete it.composeService.appEnvironment;
    dockerCompose.services[serviceName] = {
      ...it.composeService,
      environment: Object.keys(it.composeService.environment).length ? it.composeService.environment : void 0,
      depends_on: depends_on.length ? depends_on : void 0
    };
    dockerCompose.volumes = {
      ...dockerCompose.volumes,
      ...it.volumes.filter((it2) => it2.isNamedVolume).reduce(
        (acc, it2) => ({
          ...acc,
          [it2.src]: {}
        }),
        {}
      )
    };
    dockerCompose.networks = {
      ...dockerCompose.networks,
      ...it.networks.reduce(
        (acc, it2) => ({
          ...acc,
          [it2]: {}
        }),
        {}
      )
    };
  }
  return {
    dockerCompose,
    environment: appEnvironment
  };
}
function service(serviceLike) {
  const ports = (serviceLike.ports ?? []).map((it) => {
    const [host, internal] = it.split(":");
    return {
      host,
      internal
    };
  });
  const volumes = (serviceLike.volumes ?? []).map((it) => {
    const [src, dest] = it.split(":");
    return {
      src,
      dest,
      isNamedVolume: !(src.startsWith("/") || src.startsWith("./"))
    };
  });
  return {
    composeService: serviceLike,
    ports,
    volumes,
    networks: serviceLike.networks ?? [],
    dependsOn: (services) => {
      const depends_on = [];
      for (const dependencie of serviceLike.depends_on ?? []) {
        for (const [serviceName, serviceLike2] of Object.entries(services)) {
          if (serviceLike2.composeService === dependencie) {
            depends_on.push(serviceName);
          }
        }
      }
      return depends_on;
    }
  };
}
function toKevValEnv(obj) {
  return Object.entries(obj).map(([key, value]) => `${key}=${value}`).join("\n");
}
var postgres = {
  image: "postgres:16",
  ports: ["5432:5432"],
  volumes: ["postgres_data:/var/lib/postgresql/data"],
  networks: ["development"],
  environment: {
    POSTGRES_PASSWORD: "yourpassword",
    POSTGRES_USER: "youruser",
    POSTGRES_DB: "yourdatabase"
  },
  get appEnvironment() {
    const {
      POSTGRES_PASSWORD: password,
      POSTGRES_USER: user,
      POSTGRES_DB: db
    } = this.environment;
    const [host, internal] = (this.ports ?? [])[0].split(":");
    return {
      CONNECTION_STRING: `postgresql://${user}:${password}@database:${host}/${db}`
    };
  }
};
var pgadmin = {
  image: "dpage/pgadmin4",
  ports: ["8080:8080"],
  networks: ["development"],
  environment: {
    PGADMIN_DEFAULT_EMAIL: "admin@admin.com",
    PGADMIN_DEFAULT_PASSWORD: "password"
  }
};
var localServer = (options = {
  port: "3000"
}) => {
  options.port ??= "3000";
  return {
    image: "node:lts",
    build: {
      context: ".",
      dockerfile: "Dockerfile"
    },
    networks: ["development"],
    restart: "unless-stopped",
    command: "node --watch /app/build/server.js",
    develop: {
      watch: [
        {
          action: "sync",
          path: "./output/build/server.js",
          target: "/app/build/server.js",
          ignore: ["node_modules/"]
        },
        {
          action: "rebuild",
          path: "./output/package.json"
        },
        {
          action: "rebuild",
          path: "./package.json"
        }
      ]
    },
    ports: [`${options.port}:${options.port}`, "9229:9229"],
    environment: {
      NODE_ENV: "development",
      PORT: options.port
    },
    env_file: removeDuplicates(
      [".env", ...options.env_file ?? [], ".env.compose"],
      (key) => key
    )
  };
};
function writeCompose({
  dockerCompose,
  environment
}) {
  return writeFiles(process.cwd(), {
    "compose.dev.yml": yaml.dump(dockerCompose, {
      skipInvalid: false,
      noRefs: true,
      forceQuotes: true,
      noCompatMode: true,
      schema: yaml.JSON_SCHEMA
    }),
    ".env.compose": toKevValEnv(environment)
  });
}

// libs/docker/src/index.ts
function createPack(content) {
  const pack = tarStream.pack();
  const entry = pack.entry({ name: "package.json" }, content, () => {
    pack.finalize();
  });
  entry.end();
  return new Promise((resolve, reject) => {
    entry.on("finish", () => {
      resolve(pack);
    });
    entry.on("error", reject);
  });
}
function createExtract(onEntry) {
  const extract = tarStream.extract();
  extract.on("entry", (header, stream, next) => {
    onEntry(header.name, stream);
    stream.on("end", next);
    stream.resume();
  });
  extract.on("finish", () => {
    console.log("File extraction complete");
  });
  return extract;
}
var mainOutStream = new PassThrough();
var mainErrStream = new PassThrough();
if (process.env["NODE_ENV"] === "development") {
}
async function execCommand(container, cmd) {
  const exec = await container.exec({
    AttachStdout: true,
    AttachStderr: true,
    Cmd: cmd,
    Tty: false,
    Privileged: false
  });
  const stream = await exec.start({});
  const outStream = new PassThrough();
  const errStream = new PassThrough();
  container.modem.demuxStream(stream, outStream, errStream);
  let out = "";
  let err = "";
  outStream.on("data", (chunk) => {
    out += chunk.toString();
  });
  errStream.on("data", (chunk) => {
    err += chunk.toString();
  });
  return new Promise((resolve, reject) => {
    stream.on("end", async () => {
      try {
        console.log(`Command ${cmd.join(" ")}`);
        const a = await exec.inspect();
        if (a.ExitCode !== 0) {
          const error = new Error(err);
          error.cause = a;
          reject(error);
        } else if (err) {
          const error = new Error(err);
          error.cause = a;
          return reject(error);
        } else {
          resolve(out);
        }
      } catch (e) {
        reject(e);
      }
    });
  });
}
async function getDependencyInstaller() {
  const container = await startContainer(
    "dependency-installer",
    () => docker.createContainer({
      name: "dependency-installer",
      Image: "node:lts",
      WorkingDir: "/app",
      Cmd: ["tail", "-f", "/dev/null"],
      HostConfig: {
        Binds: [`node_modules:/app/node_modules`],
        CapDrop: ["ALL"],
        Privileged: false
      }
    })
  );
  await followLogs(container);
  return container;
}
async function installPackage(sourceData) {
  const container = await getDependencyInstaller();
  await execCommand(container, [
    "sh",
    "-c",
    `echo '${JSON.stringify({
      version: "0.0.0",
      main: "./build/server.js",
      type: "module",
      dependencies: {
        "ua-parser-js": "^1.0.37",
        "request-ip": "^3.3.0",
        "rfc-7807-problem-details": "^1.1.0",
        ajv: "8.12.0",
        "ajv-formats": "2.1.1",
        "ajv-errors": "3.0.0",
        "ajv-keywords": "5.1.0",
        validator: "13.9.0",
        "lodash-es": "^4.17.21",
        "http-status-codes": "2.2.0",
        hono: "^4.4.0",
        "@hono/node-server": "^1.11.1",
        "@scalar/hono-api-reference": "^0.5.145",
        typeorm: "0.3.20",
        pg: "8.11.5",
        "sql-template-tag": "5.2.1",
        resend: "1.0.0",
        "@octokit/webhooks": "^13.2.7",
        "node-cron": "^3.0.3",
        [sourceData.package]: sourceData.version
      },
      devDependencies: {
        "@types/ua-parser-js": "^0.7.39",
        "@types/request-ip": "^0.0.41",
        "@types/lodash-es": "^4.17.12",
        "@types/node": "^20.11.26",
        typescript: "^4.9.4",
        "@types/validator": "13.7.17",
        "@types/node-cron": "^3.0.11",
        prettier: "3.3.2"
      }
    })}' > package.json`
  ]);
  await execCommand(container, [
    "sh",
    "-c",
    "npm install",
    "--no-audit",
    "--no-fund"
  ]);
  return container;
}
async function installPackageJson(content, projectId) {
  const containerName = `${projectId}-install-deps`;
  const volumeName = "node_modules";
  const depsImage = "node:lts";
  const pack = await createPack(content);
  const [container, error] = await extractError(
    () => docker.createContainer({
      Image: depsImage,
      WorkingDir: "/app",
      name: containerName,
      Cmd: ["sh", "-c", "npm install", "--no-audit", "--no-fund"],
      HostConfig: {
        // Binds: [`${volumeName}:/app/node_modules`],
        AutoRemove: true,
        // ReadonlyRootfs: true,
        CapDrop: ["ALL"]
      }
    })
  );
  if (error) {
    const { statusCode, message } = error;
    switch (statusCode) {
      case 409:
        await removeContainer(containerName).catch(() => {
        });
        await installPackageJson(content, projectId);
        break;
      case 404:
        console.log(`Image not found: ${depsImage}`);
        console.error(error);
        break;
      default:
        console.error(error);
        break;
    }
    return;
  }
  try {
    await container.putArchive(pack, {
      path: "/app"
    });
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      logs: true
    });
    stream.pipe(process.stdout);
    await container.start();
    await container.wait({
      condition: "removed"
    });
    console.log("Dependencies installed");
  } finally {
    await removeContainer(containerName).catch(() => {
    });
  }
}
async function mergeEnvs(...files) {
  const env = {};
  for (const file of files) {
    const filePath = join3(process.cwd(), file);
    const envFile = await readFile2(filePath, "utf-8");
    const envFileContent = parse(envFile);
    Object.assign(env, envFileContent);
  }
  return env;
}
export {
  compose,
  computeChecksum,
  contentChanged,
  createExtract,
  createPack,
  docker,
  execCommand,
  fileChanged,
  followLogs,
  followProgress,
  getContainer,
  getContainerExternalPort,
  getContainerNet,
  getDependencyInstaller,
  imagesExists,
  installPackage,
  installPackageJson,
  isContainerRunning,
  localServer,
  mergeEnvs,
  pgadmin,
  postgres,
  pullImage,
  pushImage,
  removeContainer,
  service,
  startContainer,
  toKevValEnv,
  upsertNetwork,
  upsertVolume,
  writeCompose
};
