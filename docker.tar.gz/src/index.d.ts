export * from './lib/compose/compose';
export * from './lib/instance';
export * from './lib/utils';
export * from './lib/file';
export * from './lib/npm';
export declare function mergeEnvs(...files: string[]): Promise<Record<string, string>>;
