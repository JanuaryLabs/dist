import type { Container } from 'dockerode';
import type internal from 'stream';
export declare function upsertVolume(name: string): Promise<import("dockerode").VolumeInspectInfo | import("dockerode").VolumeCreateResponse>;
export declare function upsertNetwork(name: string): Promise<any>;
export declare function getContainer(containerId: string | {
    name: string;
}): Promise<Container | null>;
export declare function removeContainer(nameOrContainer: string | Container): Promise<void>;
export declare function isContainerRunning(nameOrContainer: string | Container): Promise<boolean>;
export declare function computeChecksum(filePath: string | internal.Readable): Promise<string>;
export declare function fileChanged(filePath: string, discrminator: string): Promise<{
    changed: boolean;
    flush: () => Promise<void>;
}>;
export declare function contentChanged(content: string, fileName: string, discrminator: string): Promise<{
    changed: boolean;
    flush: () => Promise<void>;
}>;
export declare function makeProjectPath(projectId: string): string;
export declare function makeRunningContainerName(projectId: string): string;
export declare function followLogs(container: Container): Promise<void>;
export declare function startContainer(name: string | Container, createContainer?: () => Promise<Container>): Promise<Container>;
export declare function getContainerPort(internalPort: string | number, containerId: string | {
    name: string;
} | Container): Promise<string>;
