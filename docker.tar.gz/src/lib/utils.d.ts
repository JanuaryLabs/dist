import type { Container } from 'dockerode';
import type internal from 'stream';
export declare function followProgress(stream: NodeJS.ReadableStream, logger?: Pick<Console, 'log'>): Promise<unknown>;
export declare function upsertVolume(name: string): Promise<import("dockerode").VolumeInspectInfo | import("dockerode").VolumeCreateResponse>;
export declare function upsertNetwork(name: string): Promise<any>;
export declare function getContainer(containerId: string | {
    name: string;
}): Promise<Container | null>;
export declare function removeContainer(nameOrContainer: string | Container, wait?: number): Promise<void>;
export declare function isContainerRunning(nameOrContainer: string | Container): Promise<boolean>;
export declare function computeChecksum(filePath: string | internal.Readable): Promise<string>;
export declare function fileChanged(filePath: string, discrminator: string): Promise<{
    changed: boolean;
    flush: () => Promise<void>;
}>;
export declare function contentChanged(content: string, fileName: string, discrminator: string): Promise<{
    changed: boolean;
    flush: () => Promise<void>;
}>;
export declare function followLogs(container: Container): Promise<void>;
export declare function startContainer(name: string | Container, createContainer?: () => Promise<Container>): Promise<Container>;
export declare function getContainerNet(containerId: string | {
    name: string;
} | Container): Promise<{
    Bridge: string;
    SandboxID: string;
    HairpinMode: boolean;
    LinkLocalIPv6Address: string;
    LinkLocalIPv6PrefixLen: number;
    Ports: {
        [portAndProtocol: string]: Array<{
            HostIp: string;
            HostPort: string;
        }>;
    };
    SandboxKey: string;
    SecondaryIPAddresses?: any;
    SecondaryIPv6Addresses?: any;
    EndpointID: string;
    Gateway: string;
    GlobalIPv6Address: string;
    GlobalIPv6PrefixLen: number;
    IPAddress: string;
    IPPrefixLen: number;
    IPv6Gateway: string;
    MacAddress: string;
    Networks: {
        [type: string]: {
            IPAMConfig?: any;
            Links?: any;
            Aliases?: any;
            NetworkID: string;
            EndpointID: string;
            Gateway: string;
            IPAddress: string;
            IPPrefixLen: number;
            IPv6Gateway: string;
            GlobalIPv6Address: string;
            GlobalIPv6PrefixLen: number;
            MacAddress: string;
        };
    };
    Node?: {
        ID: string;
        IP: string;
        Addr: string;
        Name: string;
        Cpus: number;
        Memory: number;
        Labels: any;
    } | undefined;
}>;
export declare function getContainerExternalPort(internalPort: string | number, containerId: string | {
    name: string;
} | Container): Promise<string>;
export declare function pushImage(repo: string, tag?: string): Promise<import("dockerode").Image>;
export declare function pullImage(image: string, tag?: string): Promise<string>;
export declare function imagesExists(...tags: string[]): Promise<boolean>;
