import Docker from 'dockerode';
export declare const docker: Docker;
