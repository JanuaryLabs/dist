import type { Stage, StartStage } from './declarative';
interface RuntimeConfig extends Omit<Stage, 'cmd' | 'port' | 'user'> {
    entrypoint?: string;
    script?: string;
    from?: Stage | string;
    allowWrite?: string[];
}
export declare function nodejs(entrypoint: string): StartStage;
export declare function nodejs(config: RuntimeConfig): StartStage;
export declare namespace nodejs {
    var alpine: string;
    var dockerignore: string[];
}
export declare function bunjs(entrypoint: string): StartStage;
export declare function bunjs(config: RuntimeConfig): StartStage;
export declare function nginx(config?: Omit<RuntimeConfig, 'entrypoint'>): StartStage;
export declare function httpd(): StartStage;
export {};
