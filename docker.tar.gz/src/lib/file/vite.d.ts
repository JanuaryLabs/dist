import { type PackageManager } from './utils';
export declare const vite: {
    (options: {
        packageManager?: PackageManager;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
