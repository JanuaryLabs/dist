export declare const streamlit: {
    (): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
