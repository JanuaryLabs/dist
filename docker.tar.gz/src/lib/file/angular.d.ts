import { type PackageManager } from './utils';
export type AngularOutputMode = 'ssr' | 'spa';
export declare const angular: {
    (config: {
        packageManager?: PackageManager;
        mode: AngularOutputMode;
        outputPath: string;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
