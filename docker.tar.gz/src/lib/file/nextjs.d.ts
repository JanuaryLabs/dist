import { type PackageManager } from './utils';
export type NextjsOutputMode = 'standalone' | 'export' | 'default';
export declare const nextjs: {
    (options: {
        packageManager?: PackageManager;
        mode?: NextjsOutputMode;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
