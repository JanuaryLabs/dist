export declare const deno: {
    (): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
