import { type PackageManager } from './utils';
export type AstroOutputMode = 'server' | 'hybrid' | 'static';
export declare const astrojs: {
    (options: {
        packageManager?: PackageManager;
        mode: AstroOutputMode;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
