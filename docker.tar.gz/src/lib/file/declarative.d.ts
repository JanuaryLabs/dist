type StageFn = (options?: any) => Stage;
export interface ShortCopy {
    from?: string | Stage | StageFn;
    link: string;
}
export interface PointToPointCopy {
    from?: string | Stage | StageFn;
    src: string | string[];
    dest?: string | {
        path: string;
        create?: boolean;
    };
}
type StageCopy = string | string[] | ShortCopy | ShortCopy[] | PointToPointCopy | PointToPointCopy[] | (PointToPointCopy | ShortCopy | string)[];
interface StageRunCmd {
    root?: boolean;
    cwd?: string;
    cmd: string | string[];
}
type StageRun = (string | string[]) | (string | string[] | string[][])[] | StageRunCmd | StageRunCmd[];
interface Image {
    image: string;
    pm: string;
}
export interface Stage {
    from: string | Image | Stage | StageFn;
    workdir?: string;
    run?: StageRun;
    output?: string | (string | {
        src: string;
        dest: string;
    })[];
    user?: string | undefined;
    copy?: StageCopy;
    environment?: Record<string, string | number>;
    packages?: string[];
}
export interface StartStage extends Stage {
    from: string | Image | Stage | StageFn;
    user?: string;
    port: string | number;
    cmd?: string | string[];
    entrypoint?: string | string[];
    run?: StageRun;
    environment?: Record<string, string | number>;
    healthCheck?: {
        test: string;
        interval?: string;
        timeout?: string;
        retries?: string;
        startPeriod?: string;
    };
}
type Stages = Record<string, Stage | readonly [Stage] | readonly [Stage | StageFn, any?]>;
export interface Dockerfile {
    stages?: Stages;
    start: StartStage;
}
export interface HasFrom {
    from: string | Stage | Image;
    workdir?: string;
}
export interface env {
    (name: string, value: string | number): StageFactory;
    (environment: Record<string, string | number>): StageFactory;
}
export interface StageFactory {
    config: Stage;
    from: (from: string | Stage) => StageFactory;
    env: env;
    user: (name: string) => StageFactory;
    addUser: () => StageFactory;
    addOutput: (value: string) => StageFactory;
    workdir: (workdir: string) => StageFactory;
    addCopy: (copy: StageCopy) => StageFactory;
    format: (name: string, stages: Record<string, Stage>) => string[];
    package: (...packages: string[]) => StageFactory;
}
export declare function coerceArray<T>(value: T): T[];
export interface DockerfileFactory {
    print: () => string;
    save: (filePath: string) => Promise<void>;
}
export declare function dockerfile(config: Dockerfile): DockerfileFactory;
export {};
