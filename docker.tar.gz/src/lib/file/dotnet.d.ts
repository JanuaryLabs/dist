export declare const dotnet: {
    (config: {
        projectName: string;
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
