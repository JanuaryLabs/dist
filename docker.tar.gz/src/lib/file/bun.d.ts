export declare const bun: import("./declarative").DockerfileFactory;
