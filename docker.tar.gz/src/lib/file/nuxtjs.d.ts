import { type PackageManager } from './utils';
export type NuxtOutputMode = 'ssr' | 'spa' | 'static';
export declare const nuxtjs: {
    (config: {
        packageManager?: PackageManager;
        mode: "ssr" | "spa" | "static";
    }): import("./declarative").DockerfileFactory;
    dockerignore: string[];
};
