import type { Stage } from './declarative';
export type PackageManager = 'yarn' | 'npm' | 'pnpm' | 'bun';
export declare function knownPackageManager(userSepcified?: PackageManager): userSepcified is PackageManager;
export declare const packageManagerCommands: {
    npm: {
        install: string;
        build: string;
    };
    yarn: {
        install: string;
        build: string;
    };
    pnpm: {
        install: string;
        build: string;
    };
    bun: {
        install: string;
        build: string;
    };
};
export declare const guessPackageManager: {
    build: string[];
    install: string[];
};
export declare function stage<P>(stageConfig: Stage | ((options: P) => Stage), options?: P): readonly [Stage | ((options: P) => Stage), NonNullable<P>] | readonly [Stage | ((options: P) => Stage)];
