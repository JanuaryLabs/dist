export interface ComposeService {
    image: string;
    ports?: string[];
    volumes?: string[];
    networks?: string[];
    environment: Record<string, string>;
    appEnvironment?: Record<string, string>;
    depends_on?: ComposeService[];
    build?: {
        context: string;
        dockerfile: string;
    };
    command?: string;
    restart?: 'unless-stopped' | 'no';
    env_file?: string[];
    develop?: {
        watch: ({
            action: 'sync';
            path: string;
            target: string;
            ignore: string[];
        } | {
            action: 'rebuild';
            path: string;
        })[];
    };
}
export interface Compose {
    volumes: Record<string, any>;
    networks: Record<string, any>;
    services: Record<string, any>;
}
export declare function compose(services: Record<string, ReturnType<typeof service>>): {
    dockerCompose: Compose;
    environment: Record<string, string>;
};
export interface ServiceHelper {
    composeService: ComposeService;
    ports: {
        host: string;
        internal: string;
    }[];
    volumes: {
        src: string;
        dest: string;
        isNamedVolume: boolean;
    }[];
    networks: string[];
    dependsOn: (services: Record<string, ReturnType<typeof service>>) => string[];
}
export declare function service(serviceLike: ComposeService): ServiceHelper;
export declare function toKevValEnv(obj: Record<string, string>): string;
export declare const postgres: ComposeService;
export declare const pgadmin: ComposeService;
export declare const localServer: (options?: {
    port?: string;
    env?: Record<string, string>;
    env_file?: string[];
}) => ComposeService;
export declare function writeCompose({ dockerCompose, environment, }: ReturnType<typeof compose>): Promise<void>;
