import ts from 'typescript';
export declare function parseTsConfig(tsconfigPath: string): ts.ParsedCommandLine;
export declare function getProgram(tsconfigPath: string): ts.Program;
