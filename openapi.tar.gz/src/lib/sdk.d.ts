import type { Checker } from '@january/parser';
export interface SecurityScheme {
    bearerAuth: {
        type: 'http';
        scheme: 'bearer';
        bearerFormat: 'JWT';
    };
}
export interface SdkConfig {
    /**
     * The name of the sdk client
     */
    name: string;
    packageName?: string;
    options?: Record<string, any>;
    emptyBodyAsNull?: boolean;
    stripBodyFromGetAndHead?: boolean;
    securityScheme?: SecurityScheme;
    output: string;
    formatGeneratedCode?: boolean;
}
export interface Spec {
    features: FeatureSpec[];
    name?: string;
    options?: Record<string, {
        in: 'header';
        schema: string;
    }>;
    securityScheme?: SecurityScheme;
}
export interface WorkflowInput {
    source: string;
    schema: string;
}
export interface FeatureSpec {
    featureName: string;
    workflows: {
        name: string;
        type: string;
        tag: string;
        schemaName: string;
        imports: Checker.Import[];
        trigger: Record<string, any>;
        inputs: Record<string, WorkflowInput>;
    }[];
}
export declare function generateClientSdk(spec: Spec): {
    'backend.ts': string;
    'validator.ts': string;
    'client.ts': string;
    'request.ts': string;
    'schemas.ts': string;
    'endpoints.ts': string;
    'stream-endpoints.ts': string;
};
