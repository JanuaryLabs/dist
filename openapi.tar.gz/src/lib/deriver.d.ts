import ts from 'typescript';
type Collector = Record<string, any>;
export declare const deriveSymbol: unique symbol;
export declare const $types: unique symbol;
export declare class TypeDeriver {
    readonly collector: Collector;
    private readonly checker;
    constructor(checker: ts.TypeChecker);
    serializeType(type: ts.Type): any;
    serializeNode(node: ts.Node): any;
}
export {};
