import { type SdkConfig } from '@january/opensdk';
export interface GenerateClient {
    fs: {
        features: string;
        extensions: string;
        tsconfig: string;
    };
    client: SdkConfig;
    primitives: any[];
}
export declare function generate({ client, fs, primitives }: GenerateClient): Promise<void>;
