var Ie=(e,t)=>()=>(e&&(t=e(e=0)),t);import{readFileSync as Ae}from"node:fs";function je(e){return typeof e=="object"&&e!==null}function Oe(e){return typeof e=="object"&&e!==null&&"start"in e&&"end"in e}function z(e,t){Array.isArray(e)?e.forEach(r=>z(r,t)):je(e)&&Object.entries(e).forEach(([r,n])=>{if(r==="span"&&n&&Oe(n)){let s=n;s.start-=t,s.end-=t}else z(e[r],t)})}async function Fe(e){let{default:t,parseSync:r}=await import("@swc/wasm-web"),n=globalThis.fetch;if(globalThis.fetch=async function(...i){let[a]=i;return a instanceof URL&&a.protocol==="file:"?new Response(Ae(a.pathname),{headers:{"Content-Type":"application/wasm"}}):n.apply(this,i)},await t(),globalThis.fetch=n,typeof e!="string"||!e.trim())return null;let s=r(e,{syntax:"typescript",decorators:!1,comments:!1,dynamicImport:!1,script:!1,tsx:!1,target:"es2022"});return z(s,s.span.start),s}async function ee(e){let t=await Fe(e);if(!t)return null;let r=t.body.find(n=>n.type==="ExportDefaultExpression");return!r||!f.isCallExpression(r.expression,"feature")?null:{imports:Ce(t.body,e),project:N(r.expression,e)}}function Ce(e,t){return e.filter(r=>r.type==="ImportDeclaration").filter(r=>r.source.value!=="@january/declarative").filter(r=>!r.source.value.endsWith(".g.ts")).map(r=>({isTypeOnly:r.typeOnly,moduleSpecifier:r.source.value,defaultImport:r.specifiers.find(n=>n.type==="ImportDefaultSpecifier")?.local.value,namespaceImport:r.specifiers.find(n=>n.type==="ImportNamespaceSpecifier")?.local.value,namedImports:r.specifiers.filter(n=>n.type==="ImportSpecifier").map(n=>({name:n.imported?n.imported.value:n.local.value,alias:n.imported?n.local.value:void 0,isTypeOnly:n.isTypeOnly}))}))}function te(e,t){let r=[];return f.isNullLiteral(e.expression)&&r.push(null),e.expression.type==="TemplateLiteral"&&r.push(t.slice(e.expression.span.start+1,e.expression.span.end-1)),f.isPrimitive(e.expression)&&r.push(e.expression.value),f.isIdentifier(e.expression)&&r.push(e.expression.value),f.isObjectExpression(e.expression)&&r.push(j(e.expression,t)),f.isCallExpression(e.expression)&&r.push(N(e.expression,t)),f.isMemberExpression(e.expression)&&r.push(D(e.expression,[]).join(".")),e.expression.type==="TsAsExpression"&&r.push(te(e.expression,t)),r}function N(e,t){let r=[];for(let s of e.arguments){if(f.isNullLiteral(s.expression)){r.push(null);continue}if(s.expression.type==="UnaryExpression"){r.push(U(s.expression));continue}if(s.expression.type==="TemplateLiteral"&&r.push(t.slice(s.expression.span.start+1,s.expression.span.end-1)),f.isPrimitive(s.expression)){r.push(s.expression.value);continue}f.isIdentifier(s.expression)&&r.push(s.expression.value),f.isObjectExpression(s.expression)&&r.push(j(s.expression,t)),f.isCallExpression(s.expression)&&r.push(N(s.expression,t)),f.isMemberExpression(s.expression)&&r.push(D(s.expression,[])),s.expression.type==="ArrowFunctionExpression"&&t&&r.push(t.slice(s.expression.span.start,s.expression.span.end)),s.expression.type==="FunctionExpression"&&t&&r.push(t.slice(s.expression.span.start,s.expression.span.end)),s.expression.type==="TsAsExpression"&&r.push(te(s.expression,t))}let n="";if(f.isMemberExpression(e.callee)){let[...s]=D(e.callee,[]);n=s.join(".")}return f.isIdentifier(e.callee)&&(n=e.callee.value),{caller:n,arguments:r,span:e.span}}function U(e){return e.argument.type==="NumericLiteral"?+`${e.operator}${e.argument.value}`:`${e.operator}${e.argument.value}`}function Le(e,t){let r=[];for(let n of e.elements)if(n){if(f.isNullLiteral(n.expression)&&r.push(null),n.expression.type==="UnaryExpression"){r.push(U(n.expression));continue}n.expression.type==="TemplateLiteral"&&r.push(t.slice(n.expression.span.start+1,n.expression.span.end-1)),f.isPrimitive(n.expression)&&r.push(n.expression.value),f.isObjectExpression(n.expression)&&r.push(j(n.expression,t)),f.isCallExpression(n.expression)&&r.push(N(n.expression,t)),f.isMemberExpression(n.expression)&&r.push(D(n.expression,[]).join("."))}return r}function j(e,t){let r={};for(let n of e.properties)if(f.isKeyValueProperty(n)&&f.isIdentifier(n.key)){if(f.isNullLiteral(n.value)){r[n.key.value]=null;continue}if(n.value.type==="UnaryExpression"){r[n.key.value]=U(n.value);continue}if(n.value.type==="TemplateLiteral"){r[n.key.value]=t.slice(n.value.span.start+1,n.value.span.end-1);continue}if(f.isPrimitive(n.value)){r[n.key.value]=n.value.value;continue}if(f.isIdentifier(n.value)){r[n.key.value]=n.value.value;continue}if(f.isKeyValueProperty(n,"CallExpression")){r[n.key.value]=N(n.value,t);continue}if(f.isArrayExpression(n.value)){r[n.key.value]=Le(n.value,t);continue}if(f.isObjectExpression(n.value)){r[n.key.value]=j(n.value,t);continue}n.value.type==="NewExpression"&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end)),n.value.type==="ArrowFunctionExpression"&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end)),(f.isMemberExpression(n.value)||n.value.type==="TsAsExpression")&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end))}return r}function D(e,t){let r=t.slice(0);return f.isIdentifier(e.object)&&r.push(e.object.value),f.isMemberExpression(e.object)&&r.push(...D(e.object,t)),f.isIdentifier(e.property)&&r.push(e.property.value),r}var f,P,re=Ie(()=>{"use strict";(c=>{function e(o,d){return!o||!(o.type==="CallExpression")?!1:d?o.callee.type==="MemberExpression"?o.callee.property.type==="Identifier"&&o.callee.property.value===d:o.callee.type==="Identifier"&&o.callee.value===d:!0}c.isCallExpression=e;function t(o){return o.type==="ObjectExpression"}c.isObjectExpression=t;function r(o,d,g){return o.type!=="KeyValueProperty"?!1:d?o.value.type===d?g?i(o.key,g):!0:!1:!0}c.isKeyValueProperty=r;function n(o){return o.type==="NullLiteral"}c.isNullLiteral=n;function s(o){return o.type==="StringLiteral"||o.type==="BooleanLiteral"||o.type==="NumericLiteral"||o.type==="BigIntLiteral"}c.isPrimitive=s;function i(o,d){return!o||!(o.type==="Identifier")?!1:d?o.value===d:!0}c.isIdentifier=i;function a(o,d){return!o||!(o.type==="MemberExpression")?!1:d?i(o.property,d):!0}c.isMemberExpression=a;function p(o){return o.type==="ArrayExpression"}c.isArrayExpression=p})(f||={});(s=>{function e(i){return i!==Object(i)}s.isPrimitive=e;function t(i){return!e(i)&&typeof i=="object"&&"caller"in i&&"arguments"in i}s.isCallExpression=t;function r(i){return!t(i)&&i!==null&&typeof i=="object"}s.isObjectExpression=r;function n(i){return Array.isArray(i)}s.isArrayExpression=n})(P||={})});import{merge as ft}from"lodash-es";import{readFile as dt,readdir as mt}from"node:fs/promises";import{basename as gt,extname as yt,join as I}from"node:path";import{randomBytes as _e}from"node:crypto";import{get as Ve}from"lodash-es";function H(e){return{name:"",tables:e.tables,workflows:e.workflows,imports:[],policies:Object.entries(e.policies||{}).reduce((t,[r,n])=>{let s=n(r);return s&&(t[r]=s),t},{})}}function R(e={}){return{name:"mandatory",details:{value:"true",message:e.message}}}var K=R;function Q(e={}){return[R(),{name:"unique",details:{value:"true",message:e.message}}]}function Se(e){return{name:e.name,config:e}}var V;(t=>{function e(r,...n){let s=r.split("."),i=s.length?t:Se;for(;s.length;)i=i[s.shift()];if(i)return i(...n);throw new Error(`Unknown validation type: ${r}`)}t.fromConfig=e})(V||={});var De=/^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i,Pe=/^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i,Ne=/^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;function Z(e){let t={};Object.values(e.fields).find(a=>["primary-key-uuid","primary-key-number","primary-key-custom"].includes(a.type))||(t.id=b.primary({type:"uuid",generated:!0}));let n=Object.keys(e.fields).find(a=>De.test(a)),s=Object.keys(e.fields).find(a=>Pe.test(a)),i=Object.keys(e.fields).find(a=>Ne.test(a));return n||(t.createdAt=b({type:"datetime",metadata:{system_created_at:!0,can_be_deleted:!1,can_be_updated:!1,system_auto_generated:!0}})),s||(t.updatedAt=b({type:"datetime",metadata:{can_be_deleted:!1,can_be_updated:!1,system_auto_generated:!0,system_updated_at:!0}})),i||(t.deletedAt=b({type:"datetime",metadata:{system_deleted_at:!0,system_auto_generated:!0,can_be_deleted:!1,can_be_updated:!1}})),{fields:{...e.fields,...t},constraints:e.constraints||[]}}function b(e){let{type:t,validations:r=[],metadata:n={},...s}=e;return{type:e.type,details:{...n,...s},validations:r}}(x=>{function e(u,...m){if(typeof u=="string"){let y=u.split("."),E=x;for(;y.length;)E=E[y.shift()];if(E)return E(...m);throw new Error(`Unknown field type: ${u}`)}return x(u)}x.fromConfig=e;function t(u){return{type:{uuid:"primary-key-uuid",number:"primary-key-number",string:"primary-key-custom"}[u.type],details:{system_primary_key:!0,can_be_deleted:!1,can_be_updated:!1,system_auto_generated:u.generated??!0},validations:[R()]}}x.primary=t;function r(u={}){let{validations:m,...y}=u;return x({type:"short-text",validations:m??[],metadata:y})}x.shortText=r;function n(u={}){let{validations:m,...y}=u;return x({type:"long-text",validations:m??[],metadata:y})}x.longText=n;function s(u={}){let{validations:m=[],...y}=u;return{type:"datetime",details:y,validations:m}}x.datetime=s;function i(u={}){let{validations:m=[],...y}=u;return{type:"url",details:y,validations:m}}x.url=i;function a(){return{type:"integer",details:{},validations:[]}}x.integer=a;function p(u={}){let{validations:m=[],...y}=u;return{type:"decimal",details:y,validations:m}}x.decimal=p;function c(u={}){let{validations:m=[],scale:y=3,precision:E=8,...S}=u;return x.decimal({scale:y,...S,precision:E,validations:m})}x.price=c;function o(u={}){let{validations:m=[],...y}=u;return{type:"boolean",details:y,validations:m}}x.boolean=o;function d(u={}){let{validations:m=[],...y}=u;return{type:"bytes",details:y,validations:m}}x.bytes=d;function g(u={}){let{validations:m=[],...y}=u;return{type:"email",details:y,validations:m}}x.email=g;function h(u={}){let{validations:m=[],...y}=u;return{type:"json",details:y,validations:m}}x.json=h;function v(u){let[,m,...y]=u.references.split(".");if(y.length)throw new Error(`Wrong relation reference: ${u.references}. Did you mean tables.${m}`);return x({type:"relation",metadata:{...u,references:m},validations:u.validations})}x.relation=v})(b||={});b.enum=e=>b({type:"single-select",validations:e.validations,metadata:{style:"enum",values:e.values,defaultValue:e.defaultValue}});function X(...e){return{type:"index",details:{columns:e.map(t=>({command:"QueryFieldName",payload:{name:t}}))}}}function Y(e,t){let r=t.trigger.refineExecute(t.execute);return{name:e,trigger:t.trigger,raw:!Object.keys(t.trigger.inputs??{}).length,execute:r,tag:t.tag}}re();var se={table:Z,feature:H,workflow:Y,field:b.fromConfig,validation:V.fromConfig,mandatory:R,required:K,unique:Q,index:X},ne={UNKNOWN_CALLER:_e(5).toString("hex")};function O(e,t,r={}){if(P.isCallExpression(t)){let[n,...s]=t.caller.split("."),i=e[n];if(!i&&!r.unknownCaller)throw new Error(`${ne.UNKNOWN_CALLER}: Unknown caller ${t.caller}`);if(i??=r.unknownCaller?.(t,n),!i)return null;let a=t.arguments.map(p=>O(e,p,r));if(typeof i=="function")return s.length&&a.unshift(s.join(".")),i(...a);if(i=Ve(i,s),!i)throw new Error(`${ne.UNKNOWN_CALLER}: Unknown caller ${t.caller}`);return i(...a)}if(P.isArrayExpression(t))return t.map(n=>O(e,n,r));if(P.isObjectExpression(t)){let n={};for(let[s,i]of Object.entries(t))n[s]=O(e,i,r);return n}return t}async function ie(e,t){let r=await ee(e);if(!r)throw new Error("Failed to parse the code");return{...O(t,r.project),imports:r.imports}}import{mkdir as Qe,readFile as Ze,readdir as le,stat as Xe,writeFile as Ye}from"node:fs/promises";import{dirname as et,isAbsolute as tt,join as rt}from"node:path";import{tap as sn}from"rxjs/operators";import{camelcase as Er,cramcase as br,dotcase as Tr,pascalcase as pe,sentencecase as Rr,snakecase as $r,spinalcase as Ir,titlecase as ce}from"stringcase";import{v4 as dr}from"uuid";import{join as oe,normalize as ze}from"node:path";import qt from"retry";import{snakecase as Ue,spinalcase as qe}from"stringcase";function A(e,t=r=>r){return`{${Object.keys(e).map(r=>`${r}: ${t(e[r])}`).join(", ")}}`}function We(e){return ze(oe("/",e))}function Me(e,t=!1){for(;e.endsWith("/");)e=e.slice(0,-1);return e+(t?"/":"")}function Be(e){return e.replace(":","$:").split("$").map(t=>{if(!t.startsWith(":"))return t.split("/").filter(Boolean).join("/");let[r,...n]=t.split("/");return[`{${r.slice(1)}}`,...n].join("/")}).join("/")}function ae(e){let t=Me(We(oe(qe(e.featureName),Ue(e.workflowTag),Be(e.workflowPath))));return e.workflowMethod?`${e.workflowMethod} ${t}`:t}function q(e,t){return[...new Map(e.map(r=>[t(r),r])).values()]}var F=e=>{if(!e)return"";let t=e.lastIndexOf(".");if(t===-1)return"";let r=e.slice(t+1).split("/").filter(Boolean).join("");return r===e?"":r||"txt"};async function W(e,t,r=!0){if(!e||e.trim().length===0)return"";function n(){switch(t){case"ts":return{parserImport:[import("prettier/plugins/typescript")],parserName:"typescript"};case"js":return{parserImport:[import("prettier/plugins/babel")],parserName:"babel"};case"html":return{parserImport:[import("prettier/plugins/html")],parserName:"html"};case"css":return{parserImport:[import("prettier/plugins/postcss")],parserName:"css"};case"scss":return{parserImport:[import("prettier/plugins/postcss")],parserName:"scss"};case"code-snippets":case"json":case"prettierrc":return{parserImport:[import("prettier/plugins/babel")],parserName:"json"};case"md":return{parserImport:[import("prettier/plugins/markdown")],parserName:"markdown"};case"yaml":case"yml":return{parserImport:[import("prettier/plugins/yaml")],parserName:"yaml"};case"":case"gitignore":case"dockerignore":case"prettierignore":case"Dockerfile":case"toml":case"env":case"txt":return{parserImport:[],parserName:""};default:return{parserImport:[],parserName:""}}}let{parserImport:s,parserName:i}=n();if(!i)return e;let[a,...p]=await Promise.all([import("prettier/standalone"),import("prettier/plugins/estree").then(c=>c),...s]);try{return a.format(e,{parser:i,plugins:p,singleQuote:!0}).then(c=>c.trim())}catch(c){if(c instanceof Error&&c.name==="SyntaxError")return r===!0?e:W(e,"ts",!0);if(!r)throw c;return e}}import Cr from"localforage";import{differenceInSeconds as Yr}from"date-fns";async function C(e,t,r=!0){return Promise.all(Object.entries(t).map(async([n,s])=>{let i=tt(n)?n:rt(e,n);await Qe(et(i),{recursive:!0});let a=typeof s=="string"?s:JSON.stringify(s);await Ye(i,r?await W(a,F(n)):a,"utf-8")}))}async function ue(e){return Xe(e).then(()=>!0).catch(()=>!1)}async function fe(e){return await ue(e)?le(e):[]}async function de(e){return await ue(e)?Ze(e,"utf-8"):null}async function L(e,t=["ts"]){let r=await le(e,{withFileTypes:!0}),n=[];for(let s of r)s.isDirectory()?n.push(`export * from './${s.name}';`):s.name!=="index.ts"&&t.includes(F(s.name))&&n.push(`export * from './${s.name.replace(`.${F(s.name)}`,"")}';`);return n.join(`
`)}var me=`import { parse } from 'fast-content-type-parse';
import type { Endpoints } from './endpoints';
import schemas from './schemas';
import { validateOrThrow, ServerError } from './validator';

export interface RequestInterface<D extends object = object> {
	/**
	 * Sends a request based on endpoint options
	 *
	 * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'
	 * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.
	 */
	<R extends keyof Endpoints>(
		route: R,
		options?: Endpoints[R]['input']
	): Promise<Endpoints[R]['output']>;
}

export async function handleError(response: Response) {
	try {
		if (response.status >= 400 && response.status < 500) {
			const body = (await response.json()) as Record<string, any>;
			return new ServerError(body.title || body.detail, response.status, body.errors ?? {});
		}
		return new Error(
			\`An error occurred while fetching the data. Status: \${response.status}\`
		);
	} catch (error) {
		// in case the response is not a json
		// this is a workaround but we should change
		// it from the server to always return json

		return error as Error;
	}
}

export async function parseResponse(response: Response) {
	const contentType = response.headers.get('Content-Type');
	if (!contentType) {
		throw new Error('Content-Type header is missing');
	}

	if (response.status === 204) {
		return null;
	}

	const { type } = parse(contentType);
	switch (type) {
		case 'application/json':
			return response.json();
		case 'text/plain':
			return response.text();
		default:
			throw new Error(\`Unsupported content type: \${contentType}\`);
	}
}`;var ge=`type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type Endpoint = \`\${Method} \${string}\`;

export function createUrl(base: string, path: string, query: URLSearchParams) {
	const url = new URL(path, base);
	url.search = query.toString();
	return url;
}
function template(
	templateString: string,
	templateVariables: Record<string, any>
): string {
	const nargs = /{([0-9a-zA-Z_]+)}/g;
	return templateString.replace(nargs, (match, key: string, index: number) => {
		// Handle escaped double braces
		if (
			templateString[index - 1] === '{' &&
			templateString[index + match.length] === '}'
		) {
			return key;
		}

		const result = key in templateVariables ? templateVariables[key] : null;
		return result === null || result === undefined ? '' : String(result);
	});
}
export function toRequest<T extends Endpoint>(
	endpoint: T,
	input: Record<string, any>,
	props: {
		inputHeaders: string[];
		inputQuery: string[];
		inputBody: string[];
		inputParams: string[];
	},
	defaults: {
		baseUrl: string;
		headers?: Record<string, string>;
	}
): Request {
	const [method, path] = endpoint.split(' ');

	const headers = new Headers({
		...defaults?.headers,
		'Content-Type': 'application/json',
		Accept: 'application/json',
	});

	for (const header of props.inputHeaders) {
		headers.set(header, input[header]);
	}

	const query = new URLSearchParams();
	for (const key of props.inputQuery) {
		const value = input[key];
		if (value !== undefined) {
			query.set(key, String(value));
		}
	}

	const body = props.inputBody.reduce<Record<string, any>>((acc, key) => {
		acc[key] = input[key];
		return acc;
	}, {});

	const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
		acc[key] = input[key];
		return acc;
	}, {});

	const init = {
		path: template(path, params),
		method,
		headers,
		query,
		body: JSON.stringify(body),
	};

	const url = createUrl(defaults.baseUrl, init.path, init.query);
	return new Request(url, {
		method: init.method,
		headers: init.headers,
		body: method === 'GET' ? undefined : JSON.stringify(body),
	});
}
`;var ye=`import { z } from 'zod';

export function validate<T extends z.ZodRawShape>(
	schema: z.ZodObject<T>,
	input: unknown
) {
	const result = schema.safeParse(input);
	if (!result.success) {
		return result.error.flatten((issue) => ({
			message: issue.message,
			code: issue.code,
			fatel: issue.fatal,
			path: issue.path.join('.'),
		})).fieldErrors;
	}
	return null;
}

export class ValidationError extends Error {
	flattened: { path: string; message: string }[];
	constructor(
		public override message: string,
		public errors: ReturnType<typeof validate>
	) {
		super(message);
		this.name = 'ValidationError';
		Error.captureStackTrace(this, ValidationError);
		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({
			path: key,
			message: (it as any[])[0].message,
		}));
	}
}

export class ServerError extends Error {
	flattened: { path: string; message: string }[];
	constructor(
		public override message: string,
		public status: number,
		public errors: ReturnType<typeof validate>
	) {
		super(message);
		this.name = 'ServerError';
		Error.captureStackTrace(this, ServerError);
		this.flattened = Object.entries(this.errors ?? {}).map(([key, it]) => ({
			path: key,
			message: (it as any[])[0].message,
		}));
	}
}

export function validateOrThrow<T extends z.ZodRawShape>(
	schema: z.ZodObject<T>,
	input: unknown
): asserts input is z.infer<z.ZodObject<T>> {
	const errors = validate(schema, input);
	if (errors) {
		throw new ValidationError('Validation failed', errors);
	}
}
`;import{camelcase as xe}from"stringcase";var he=e=>{let t={...e.options??{},baseUrl:{schema:"z.string().url()"}};e.securityScheme&&(t.token={schema:"z.string().optional()"});let r=e.securityScheme?`{Authorization: \`${ce(e.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}`:"{}";return`

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { validateOrThrow } from './validator';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${A(t,n=>n.schema)});
      type ${e.name}Options = z.infer<typeof optionsSchema>;
    export class ${e.name} {

      constructor(public options: ${e.name}Options) {}

async stream<E extends keyof StreamEndpoints>(
    endpoint: E,
    input: StreamEndpoints[E]['input'],
  ): Promise<readonly [ReadableStream, Error | null]> {
    try {
      const route = schemas[endpoint];
      validateOrThrow(route.schema, input);
      const response = await fetch(
        route.toRequest(input as never, {
          headers: this.defaultHeaders,
          baseUrl: this.options.baseUrl,
        }),
      );

      if (response.ok) {
        return [response.body!, null] as const;
      }
      const error = await handleError(response);
      return [null as never, error] as const;
    } catch (error) {
      return [null as never, error as Error] as const;
    }
  }

async request<E extends keyof Endpoints>(
		endpoint: E,
		input: Endpoints[E]['input']
	): Promise<readonly [Endpoints[E]['output'], Error | null]> {
		try {
			const route = schemas[endpoint];
			validateOrThrow(route.schema, input);
			const response = await fetch(
				route.toRequest(input as never, {
					headers: this.defaultHeaders,
					baseUrl: this.options.baseUrl,
				})
			);

			if (response.ok) {
				const data = await parseResponse(response);
				return [data as Endpoints[E]['output'], null] as const;
			}
			const error = await handleError(response);
			return [null, error] as const;
		} catch (error) {
			return [null, error as Error] as const;
		}
	}

      get defaultHeaders() {
        return ${r}
      }

  setOptions(options: Partial<${e.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${e.name}Options)[]) {
      if (validated[key] !== undefined) {
        this.options[key] = validated[key]!;
      }
    }
  }
}`};var M=class{#e=["import z from 'zod';",'import type { Endpoints } from "./endpoints";','import type { StreamEndpoints } from "./stream-endpoints";',"import { toRequest, createUrl } from './request';"];#t=[];addEndpoint(t,r){this.#t.push(`  "${t}": ${r},`)}addImport(t){this.#e.push(t)}complete(){return`${this.#e.join(`
`)}
export default {
${this.#t.join(`
`)}
}`}},_=class{imports=["import z from 'zod';"];endpoints=[];addEndpoint(t,r){this.endpoints.push(`  "${t}": ${r};`)}addImport(t){this.imports.push(t)}complete(){return`${this.imports.join(`
`)}
export interface Endpoints {
${this.endpoints.join(`
`)}
}`}},B=class extends _{complete(){return`${this.imports.join(`
`)}
export interface StreamEndpoints {
${this.endpoints.join(`
`)}
}`}};function ve(e){let t=new _,r=new B,n={},s=[],i=new M;for(let a of e.features){let p=xe(a.featureName);n[p]=["import z from 'zod';"],t.addImport(`import * as ${p} from './inputs/${p}';`),r.addImport(`import * as ${p} from './inputs/${p}';`),i.addImport(`import * as ${p} from './inputs/${p}';`);for(let c of a.workflows){let o=xe(`${c.name} schema`),d=`export const ${o} = z.object(${A(c.inputs,k=>k.schema)});`;n[p].push(d),s.push(...c.imports.filter(k=>k.moduleSpecifier==="@extensions/zod").map(k=>(k.namedImports??[]).map(T=>T.name)).flat());let g=ae({featureName:"/",workflowTag:c.tag,workflowPath:c.trigger.path}),h=`${c.trigger.method.toUpperCase()} ${g}`,v=`${p}.${o}`,x=`z.infer<typeof ${v}>`,u=pe(c.name),m=[],y=[],E=[],S=[];for(let[k,T]of Object.entries(c.inputs))if(T.source==="headers")m.push(`"${k}"`);else if(T.source==="query")y.push(`"${k}"`);else if(T.source==="body")E.push(`"${k}"`);else if(T.source==="path")S.push(`"${k}"`);else{if(T.source==="internal")continue;throw new Error(`Unknown source ${T.source} in ${k} ${JSON.stringify(T)} in ${c.name}`)}c.type==="stream"?(r.addImport(`import {${u}} from './outputs/${c.name}';`),r.addEndpoint(h,`{input: ${x}, output: ${u}}`),i.addEndpoint(h,`{
        schema: ${v},
        toRequest(input: StreamEndpoints['${h}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${h}';
            return toRequest(endpoint, input, {
            inputHeaders: [${m}],
            inputQuery: [${y}],
            inputBody: [${E}],
            inputParams: [${S}],
          }, init);
          },
        }`)):(t.addImport(`import {${u}} from './outputs/${c.name}';`),t.addEndpoint(h,`{input: ${x}, output: ${u}}`),i.addEndpoint(h,`{
        schema: ${v},
        toRequest(input: Endpoints['${h}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${h}';
            return toRequest(endpoint, input, {
            inputHeaders: [${m}],
            inputQuery: [${y}],
            inputBody: [${E}],
            inputParams: [${S}],
          }, init);
          },
        }`))}}return{...Object.fromEntries(Object.entries(n).map(([a,p])=>[`inputs/${a}.ts`,[s.length?`import {${q(s,c=>c)}} from '../zod';`:"",...p].join(`
`)])),"backend.ts":he(e),"validator.ts":ye,"client.ts":me,"request.ts":ge,"schemas.ts":i.complete(),"endpoints.ts":t.complete(),"stream-endpoints.ts":r.complete()}}import at from"debug";import{dirname as be,join as pt}from"node:path";import l from"typescript";var ot={DateConstructor:"Date"};function J(e,t){let r=[];for(let n of e.types)n==null?r.push("any"):typeof n=="string"?(r.push(`${ot[n]||n}${e.kind==="array"?"[]":""}`),t(n)):"types"in n&&r.push(J(n,t));return r.join(" | ")}function ke(e,t){let r={};for(let[i,a]of Object.entries(e))for(let[p,c]of Object.entries(a)){let o=[],d=c[t],g=new Set;if(d){let h=J(c,v=>{g.add(v)});r[i]={exports:[p],imports:Array.from(g),content:`export type ${p} = ${h};`}}else{for(let[h,v]of Object.entries(c)){let x=[h];v.optional&&x.push("?"),x.push(": "),x.push(J(v,u=>{g.add(u)})),o.push(x.join(""))}r[i]={exports:[p],imports:Array.from(g),content:`export interface ${p} {
${o.join(`
`)}
}
`}}}let n=Object.values(r).flatMap(i=>i.exports),s={};for(let[i,{content:a,exports:p,imports:c}]of Object.entries(r)){let o=[];for(let g of c)n.includes(g)&&g!==i&&o.push(`import { ${g} } from './${g}';`);let d=`${o.join(`
`)}
${a}`;s[i]=d}return s}var $=at("january:client");function ct(e){$(`Using TypeScript version: ${l.version}`);let t=l.readConfigFile(e,l.sys.readFile);if(t.error)throw console.error("Failed to read tsconfig file:",l.formatDiagnosticsWithColorAndContext([t.error],{getCanonicalFileName:n=>n,getCurrentDirectory:l.sys.getCurrentDirectory,getNewLine:()=>l.sys.newLine})),new Error("Failed to parse tsconfig.json");let r=l.parseJsonConfigFileContent(t.config,l.sys,be(e));if(r.errors.length>0)throw console.error("Errors found in tsconfig.json:",l.formatDiagnosticsWithColorAndContext(r.errors,{getCanonicalFileName:n=>n,getCurrentDirectory:l.sys.getCurrentDirectory,getNewLine:()=>l.sys.newLine})),new Error("Failed to parse tsconfig.json");return r}var Te=e=>t=>{if(l.isReturnStatement(t)&&t.expression)if(l.isCallExpression(t.expression)&&t.expression.expression&&l.isPropertyAccessExpression(t.expression.expression)){let r=t.expression.expression;if(l.isIdentifier(r.expression)&&r.expression.text==="output"){let[n]=t.expression.arguments;if(!n)return;e(n)}}else e(t.expression);return l.forEachChild(t,Te(e))};function we(e,t){return l.isCallExpression(e)&&e.expression&&l.isIdentifier(e.expression)&&e.expression.text===t}function Ee(e,t){if(l.isObjectLiteralExpression(e))return e.properties.filter(r=>l.isPropertyAssignment(r)).find(r=>r.name.getText()===t)}function lt(e,t){let r=[];return e.forEachChild(n=>{if(l.isExportAssignment(n)&&we(n.expression,"feature")){let[s]=n.expression.arguments;if(l.isObjectLiteralExpression(s)){let i=Ee(s,"workflows");if(!i)return;l.isArrayLiteralExpression(i.initializer)&&i.initializer.forEachChild(a=>{if(we(a,"workflow")){let[p,c]=a.arguments,o=l.isStringLiteral(p)?p.text:"";if(!o)return;if(l.isObjectLiteralExpression(c)){let d=Ee(c,"execute");if(d?.initializer&&l.isArrowFunction(d.initializer)&&l.isBlock(d.initializer.body)){let g={[o]:{[w]:!0,optional:!1,types:["void"]}};Te(h=>{g[o]=t.serializeNode(h)})(d.initializer.body),r.push(g)}}}})}}}),r}var w=Symbol.for("serialize");function ut(e){return e.isClassOrInterface()?!!(e.symbol.flags&l.SymbolFlags.Interface):!1}var G=class{constructor(t){this.checker=t}collector={};serializeType(t){if(t.isUnion()||t.isIntersection()){let r,n=[];for(let s of t.types)r===void 0&&(r=(s.flags&l.TypeFlags.Undefined)!==0,r)||n.push(this.serializeType(s));return{[w]:!0,optional:r,types:n}}if(this.checker.isArrayLikeType(t)){let[r]=this.checker.getTypeArguments(t);if(!r)return console.warn(`No argument type found for ${t.symbol?.name} of ${this.checker.typeToString(t)}`),{[w]:!0,optional:!1,kind:"array",types:["any"]};let n=r.getSymbol();if(!n)return{[w]:!0,optional:!1,kind:"array",types:[this.checker.typeToString(r)]};let s=n.valueDeclaration;return s?{kind:"array",...this.serializeNode(s)}:null}if(t.isClass()){let r=t.symbol?.valueDeclaration;return r?this.serializeNode(r):{[w]:!0,optional:!1,types:[t.symbol.getName()]}}if(ut(t)){let r=t.symbol.valueDeclaration??t.symbol.declarations?.[0];return r?this.serializeNode(r):{[w]:!0,optional:!1,types:[t.symbol.getName()]}}return{[w]:!0,optional:!1,types:[this.checker.typeToString(t)]}}serializeNode(t){if(l.isObjectLiteralExpression(t)){let r=this.checker.getTypeAtLocation(t),n={};for(let s of r.getProperties()){let i=this.checker.getTypeOfSymbol(s);n[s.name]=this.serializeType(i)}return n}if(l.isPropertySignature(t)){let r=this.checker.getSymbolAtLocation(t.name);if(!r)return console.warn(`No symbol found for ${t.name.getText()}`),null;let n=this.checker.getTypeOfSymbol(r);return this.serializeType(n)}if(l.isPropertyDeclaration(t)){let r=this.checker.getSymbolAtLocation(t.name);if(!r)return console.warn(`No symbol found for ${t.name.getText()}`),null;let n=this.checker.getTypeOfSymbol(r);return this.serializeType(n)}if(l.isInterfaceDeclaration(t)){if(!t.name?.text)throw new Error("Interface has no name");if(!this.collector[t.name.text]){this.collector[t.name.text]={};let r={};for(let n of t.members.filter(l.isPropertySignature))r[n.name.getText()]=this.serializeNode(n);this.collector[t.name.text]=r}return{[w]:!0,optional:!1,types:[t.name.text]}}if(l.isClassDeclaration(t)){if(!t.name?.text)throw new Error("Class has no name");if(!this.collector[t.name.text]){this.collector[t.name.text]={};let r={};for(let n of t.members.filter(l.isPropertyDeclaration))r[n.name.getText()]=this.serializeNode(n);this.collector[t.name.text]=r}return{[w]:!0,optional:!1,types:[t.name.text]}}if(l.isVariableDeclaration(t)){if(!this.checker.getSymbolAtLocation(t.name))return console.warn(`No symbol found for ${t.name.getText()}`),null;if(!t.type)return"any";let n=this.checker.getTypeFromTypeNode(t.type);return this.serializeType(n)}if(l.isIdentifier(t)){if(!this.checker.getSymbolAtLocation(t))return console.warn(`No symbol found for ${t.getText()}`),null;let n=this.checker.getTypeAtLocation(t);return this.serializeType(n)}if(l.isAwaitExpression(t)){let r=this.checker.getTypeAtLocation(t);return this.serializeType(r)}return{[w]:!0,optional:!1,types:["any"]}}};function Re(e,t){let r=ct(e);$("Parsing tsconfig");let n=l.createProgram({options:{...r.options,noEmit:!0,incremental:!0,tsBuildInfoFile:pt(be(e),"./.tsbuildinfo")},rootNames:r.fileNames,projectReferences:r.projectReferences,configFileParsingDiagnostics:r.errors});$("Program created");let s=n.getTypeChecker();$("Type checker created");let i=new G(s),a={};for(let p of t){$(`Transforming feature ${p.name}`);let c=n.getSourceFile(p.path);if(!c)throw new Error(`File not found: ${p.path}`);let o=lt(c,i),d={...i.collector};for(let h of o)for(let[v,x]of Object.entries(h))d[v]=x;let g=Object.entries(d).reduce((h,[v,x])=>(h[v]={[v]:x},h),{});$(`Converting feature ${p.name} to interface`),a[p.name]=ke(g,w)}return a}function $e(e){let t={};for(let[r,n]of Object.entries(e))for(let[s,i]of Object.entries(n))t[`${s}.ts`]=i;return t}async function ht(e,t){let r=await mt(e);return Promise.all(r.map(async n=>{let s=I(e,n),i=await dt(s,"utf-8"),a=await ie(i,ft(...t,se));return{featureName:gt(s).replace(yt(s),""),workflows:a.workflows.map(p=>({imports:a.imports,inputs:Object.fromEntries(Object.entries(p.trigger.inputs).map(([c,o])=>[c,{schema:o.data.zod,source:o.data.source}])),name:p.name,tag:p.tag,type:p.trigger.type,trigger:{method:p.trigger.config.method,path:p.trigger.config.path}}))}}))}async function zn({client:e,fs:t,primitives:r}){let n={name:e.name,options:e.options,securityScheme:e.securityScheme,features:await ht(t.features,r)},s=ve(n),[i,a]=await Promise.all([de(I(t.extensions,"zod","index.ts")).then(g=>g||""),fe(t.features)]);await C(e.output,{...s,"zod.ts":i},e.formatGeneratedCode);let p=Re(t.tsconfig,a.map(g=>({name:g,path:I(t.features,g)})));await C(I(e.output,"outputs"),$e(p),e.formatGeneratedCode);let[c,o,d]=await Promise.all([L(e.output),L(I(e.output,"outputs")),L(I(e.output,"inputs"))]);await C(e.output,{"index.ts":c,"outputs/index.ts":o,"inputs/index.ts":d,...e.packageName&&{"../package.json":{name:e.packageName,version:"0.0.0",type:"module",main:"./index.js",module:"./index.js",types:"./src/index.d.ts",dependencies:{validator:"^13.12.0",zod:"^3.23.8","fast-content-type-parse":"^2.0.0"},exports:{"./package.json":"./package.json",".":{node:"./index.js",default:"./index.js",import:"./index.js",types:"./src/index.d.ts"}}}}},e.formatGeneratedCode)}export{zn as generate};
