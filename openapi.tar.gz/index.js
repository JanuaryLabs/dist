var Ae=(e,t)=>()=>(e&&(t=e(e=0)),t);import{readFileSync as Ge}from"node:fs";function He(e){return typeof e=="object"&&e!==null}function Ke(e){return typeof e=="object"&&e!==null&&"start"in e&&"end"in e}function B(e,t){Array.isArray(e)?e.forEach(r=>B(r,t)):He(e)&&Object.entries(e).forEach(([r,n])=>{if(r==="span"&&n&&Ke(n)){let s=n;s.start-=t,s.end-=t}else B(e[r],t)})}async function Qe(e){let{default:t,parseSync:r}=await import("@swc/wasm-web"),n=globalThis.fetch;if(globalThis.fetch=async function(...i){let[l]=i;return l instanceof URL&&l.protocol==="file:"?new Response(Ge(l.pathname),{headers:{"Content-Type":"application/wasm"}}):n.apply(this,i)},await t(),globalThis.fetch=n,typeof e!="string"||!e.trim())return null;let s=r(e,{syntax:"typescript",decorators:!1,comments:!1,dynamicImport:!1,script:!1,tsx:!1,target:"es2022"});return B(s,s.span.start),s}async function pe(e){let t=await Qe(e);if(!t)return null;let r=t.body.find(n=>n.type==="ExportDefaultExpression");return r?{imports:Xe(t.body,e),project:Ze(r,e)}:null}function Ze(e,t){return d.isCallExpression(e.expression)?N(e.expression,t):d.isObjectExpression(e.expression)?C(e.expression,t):null}function Xe(e,t){return e.filter(r=>r.type==="ImportDeclaration").filter(r=>r.source.value!=="@january/declarative").filter(r=>!r.source.value.endsWith(".g.ts")).map(r=>({isTypeOnly:r.typeOnly,moduleSpecifier:r.source.value,defaultImport:r.specifiers.find(n=>n.type==="ImportDefaultSpecifier")?.local.value,namespaceImport:r.specifiers.find(n=>n.type==="ImportNamespaceSpecifier")?.local.value,namedImports:r.specifiers.filter(n=>n.type==="ImportSpecifier").map(n=>({name:n.imported?n.imported.value:n.local.value,alias:n.imported?n.local.value:void 0,isTypeOnly:n.isTypeOnly}))}))}function ce(e,t){let r=[];return d.isNullLiteral(e.expression)&&r.push(null),e.expression.type==="TemplateLiteral"&&r.push(t.slice(e.expression.span.start+1,e.expression.span.end-1)),d.isPrimitive(e.expression)&&r.push(e.expression.value),d.isIdentifier(e.expression)&&r.push(e.expression.value),d.isObjectExpression(e.expression)&&r.push(C(e.expression,t)),d.isCallExpression(e.expression)&&r.push(N(e.expression,t)),d.isMemberExpression(e.expression)&&r.push(A(e.expression,[]).join(".")),e.expression.type==="TsAsExpression"&&r.push(ce(e.expression,t)),r}function N(e,t){let r=[];for(let s of e.arguments){if(d.isNullLiteral(s.expression)){r.push(null);continue}if(s.expression.type==="UnaryExpression"){r.push(M(s.expression));continue}if(s.expression.type==="TemplateLiteral"&&r.push(t.slice(s.expression.span.start+1,s.expression.span.end-1)),d.isPrimitive(s.expression)){r.push(s.expression.value);continue}d.isIdentifier(s.expression)&&r.push(s.expression.value),d.isObjectExpression(s.expression)&&r.push(C(s.expression,t)),d.isCallExpression(s.expression)&&r.push(N(s.expression,t)),d.isMemberExpression(s.expression)&&r.push(A(s.expression,[])),s.expression.type==="ArrowFunctionExpression"&&t&&r.push(t.slice(s.expression.span.start,s.expression.span.end)),s.expression.type==="FunctionExpression"&&t&&r.push(t.slice(s.expression.span.start,s.expression.span.end)),s.expression.type==="TsAsExpression"&&r.push(ce(s.expression,t))}let n="";if(d.isMemberExpression(e.callee)){let[...s]=A(e.callee,[]);n=s.join(".")}return d.isIdentifier(e.callee)&&(n=e.callee.value),{caller:n,arguments:r,span:e.span}}function M(e){return e.argument.type==="NumericLiteral"?+`${e.operator}${e.argument.value}`:`${e.operator}${e.argument.value}`}function Ye(e,t){let r=[];for(let n of e.elements)if(n){if(d.isNullLiteral(n.expression)&&r.push(null),n.expression.type==="UnaryExpression"){r.push(M(n.expression));continue}n.expression.type==="TemplateLiteral"&&r.push(t.slice(n.expression.span.start+1,n.expression.span.end-1)),d.isPrimitive(n.expression)&&r.push(n.expression.value),d.isObjectExpression(n.expression)&&r.push(C(n.expression,t)),d.isCallExpression(n.expression)&&r.push(N(n.expression,t)),d.isMemberExpression(n.expression)&&r.push(A(n.expression,[]).join("."))}return r}function C(e,t){let r={};for(let n of e.properties)if(d.isKeyValueProperty(n)&&d.isIdentifier(n.key)){if(d.isNullLiteral(n.value)){r[n.key.value]=null;continue}if(n.value.type==="UnaryExpression"){r[n.key.value]=M(n.value);continue}if(n.value.type==="TemplateLiteral"){r[n.key.value]=t.slice(n.value.span.start+1,n.value.span.end-1);continue}if(d.isPrimitive(n.value)){r[n.key.value]=n.value.value;continue}if(d.isIdentifier(n.value)){r[n.key.value]=n.value.value;continue}if(d.isKeyValueProperty(n,"CallExpression")){r[n.key.value]=N(n.value,t);continue}if(d.isArrayExpression(n.value)){r[n.key.value]=Ye(n.value,t);continue}if(d.isObjectExpression(n.value)){r[n.key.value]=C(n.value,t);continue}n.value.type==="NewExpression"&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end)),n.value.type==="ArrowFunctionExpression"&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end)),(d.isMemberExpression(n.value)||n.value.type==="TsAsExpression")&&t&&(r[n.key.value]=t.slice(n.value.span.start,n.value.span.end))}return r}function A(e,t){let r=t.slice(0);return d.isIdentifier(e.object)&&r.push(e.object.value),d.isMemberExpression(e.object)&&r.push(...A(e.object,t)),d.isIdentifier(e.property)&&r.push(e.property.value),r}var d,D,le=Ae(()=>{"use strict";(u=>{function e(o,a){return!o||!(o.type==="CallExpression")?!1:a?o.callee.type==="MemberExpression"?o.callee.property.type==="Identifier"&&o.callee.property.value===a:o.callee.type==="Identifier"&&o.callee.value===a:!0}u.isCallExpression=e;function t(o){return o.type==="ObjectExpression"}u.isObjectExpression=t;function r(o,a,f){return o.type!=="KeyValueProperty"?!1:a?o.value.type===a?f?i(o.key,f):!0:!1:!0}u.isKeyValueProperty=r;function n(o){return o.type==="NullLiteral"}u.isNullLiteral=n;function s(o){return o.type==="StringLiteral"||o.type==="BooleanLiteral"||o.type==="NumericLiteral"||o.type==="BigIntLiteral"}u.isPrimitive=s;function i(o,a){return!o||!(o.type==="Identifier")?!1:a?o.value===a:!0}u.isIdentifier=i;function l(o,a){return!o||!(o.type==="MemberExpression")?!1:a?i(o.property,a):!0}u.isMemberExpression=l;function m(o){return o.type==="ArrayExpression"}u.isArrayExpression=m})(d||={});(s=>{function e(i){return i!==Object(i)}s.isPrimitive=e;function t(i){return!e(i)&&typeof i=="object"&&"caller"in i&&"arguments"in i}s.isCallExpression=t;function r(i){return!t(i)&&i!==null&&typeof i=="object"}s.isObjectExpression=r;function n(i){return Array.isArray(i)}s.isArrayExpression=n})(D||={})});import{merge as bt}from"lodash-es";import{readFile as vt,readdir as kt}from"node:fs/promises";import{basename as wt,extname as Et,join as O}from"node:path";import{camelcase as qe,cramcase as cr,dotcase as lr,pascalcase as $,sentencecase as ur,snakecase as dr,spinalcase as fr,titlecase as te}from"stringcase";import{v4 as er}from"uuid";import{join as X,normalize as De}from"node:path";import Ot from"retry";import{snakecase as Ne,spinalcase as Ce}from"stringcase";function R(e,t=r=>r){return`{${Object.keys(e).map(r=>`${r}: ${t(e[r])}`).join(", ")}}`}function Fe(e){return De(X("/",e))}function Le(e,t=!1){for(;e.endsWith("/");)e=e.slice(0,-1);return e+(t?"/":"")}function ze(e){return e.replace(":","$:").split("$").map(t=>{if(!t.startsWith(":"))return t.split("/").filter(Boolean).join("/");let[r,...n]=t.split("/");return[`{${r.slice(1)}}`,...n].join("/")}).join("/")}function Y(e){let t=Le(Fe(X(Ce(e.featureName),Ne(e.workflowTag),ze(e.workflowPath))));return e.workflowMethod?`${e.workflowMethod} ${t}`:t}function j(e,t){return[...new Map(e.map(r=>[t(r),r])).values()]}var P=e=>{if(!e)return"";let t=e.lastIndexOf(".");if(t===-1)return"";let r=e.slice(t+1).split("/").filter(Boolean).join("");return r===e?"":r||"txt"};function ee(e){return JSON.stringify(e,null,2)}import{get as et}from"lodash-es";import{randomBytes as tt}from"node:crypto";function re(e={}){return{name:"",tables:e.tables??{},workflows:e.workflows??[],imports:[],policies:Object.entries(e.policies??{}).reduce((t,[r,n])=>{let s=n(r);return s&&(t[r]=s),t},{})}}function I(e={}){return{name:"mandatory",details:{value:"true",message:e.message}}}var ne=I;function se(e={}){return[I(),{name:"unique",details:{value:"true",message:e.message}}]}function Be(e){return{name:e.name,config:e}}var q;(t=>{function e(r,...n){let s=r.split("."),i=s.length?t:Be;for(;s.length;)i=i[s.shift()];if(i)return i(...n);throw new Error(`Unknown validation type: ${r}`)}t.fromConfig=e})(q||={});var Me=/^created(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i,We=/^updated(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i,Je=/^deleted(_at|At|_At|on|On|_on|_On|[_-]?timestamp|[_-]?date)?$/i;function ie(e){let t={};Object.values(e.fields).find(l=>["primary-key-uuid","primary-key-number","primary-key-custom"].includes(l.type))||(t.id=T.primary({type:"uuid",generated:!0}));let n=Object.keys(e.fields).find(l=>Me.test(l)),s=Object.keys(e.fields).find(l=>We.test(l)),i=Object.keys(e.fields).find(l=>Je.test(l));return n||(t.createdAt=T({type:"datetime",metadata:{system_created_at:!0,can_be_deleted:!1,can_be_updated:!1,system_auto_generated:!0}})),s||(t.updatedAt=T({type:"datetime",metadata:{can_be_deleted:!1,can_be_updated:!1,system_auto_generated:!0,system_updated_at:!0}})),i||(t.deletedAt=T({type:"datetime",metadata:{system_deleted_at:!0,system_auto_generated:!0,can_be_deleted:!1,can_be_updated:!1}})),{fields:{...e.fields,...t},constraints:e.constraints||[]}}function T(e){let{type:t,validations:r=[],metadata:n={},...s}=e;return{type:e.type,details:{...n,...s},validations:r}}(h=>{function e(c,...g){if(typeof c=="string"){let y=c.split("."),E=h;for(;y.length;)E=E[y.shift()];if(E)return E(...g);throw new Error(`Unknown field type: ${c}`)}return h(c)}h.fromConfig=e;function t(c){return{type:{uuid:"primary-key-uuid",number:"primary-key-number",string:"primary-key-custom"}[c.type],details:{system_primary_key:!0,can_be_deleted:!1,can_be_updated:!1,system_auto_generated:c.generated??!0},validations:[I()]}}h.primary=t;function r(c={}){let{validations:g,...y}=c;return h({type:"short-text",validations:g??[],metadata:y})}h.shortText=r;function n(c={}){let{validations:g,...y}=c;return h({type:"long-text",validations:g??[],metadata:y})}h.longText=n;function s(c={}){let{validations:g=[],...y}=c;return{type:"datetime",details:y,validations:g}}h.datetime=s;function i(c={}){let{validations:g=[],...y}=c;return{type:"url",details:y,validations:g}}h.url=i;function l(){return{type:"integer",details:{},validations:[]}}h.integer=l;function m(c={}){let{validations:g=[],...y}=c;return{type:"decimal",details:y,validations:g}}h.decimal=m;function u(c={}){let{validations:g=[],scale:y=3,precision:E=8,...v}=c;return h.decimal({scale:y,...v,precision:E,validations:g})}h.price=u;function o(c={}){let{validations:g=[],...y}=c;return{type:"boolean",details:y,validations:g}}h.boolean=o;function a(c={}){let{validations:g=[],...y}=c;return{type:"bytes",details:y,validations:g}}h.bytes=a;function f(c={}){let{validations:g=[],...y}=c;return{type:"email",details:y,validations:g}}h.email=f;function k(c={}){let{validations:g=[],...y}=c;return{type:"json",details:y,validations:g}}h.json=k;function b(c){let[,g,...y]=c.references.split(".");if(y.length)throw new Error(`Wrong relation reference: ${c.references}. Did you mean tables.${g}`);return h({type:"relation",metadata:{...c,references:g},validations:c.validations})}h.relation=b})(T||={});T.enum=e=>T({type:"single-select",validations:e.validations,metadata:{style:"enum",values:e.values,defaultValue:e.defaultValue}});function oe(...e){return{type:"index",details:{columns:e.map(t=>({command:"QueryFieldName",payload:{name:t}}))}}}function ae(e,t){let r=t.trigger.refineExecute(t.execute);return{name:e,trigger:t.trigger,raw:!Object.keys(t.trigger.inputs??{}).length,execute:r,tag:t.tag}}le();var de={table:ie,feature:re,workflow:ae,field:T.fromConfig,validation:q.fromConfig,mandatory:I,required:ne,unique:se,index:oe},ue={UNKNOWN_CALLER:tt(5).toString("hex")};function L(e,t,r={}){if(D.isCallExpression(t)){let[n,...s]=t.caller.split("."),i=e[n];if(!i&&!r.unknownCaller)throw new Error(`${ue.UNKNOWN_CALLER}: Unknown caller ${t.caller}`);if(i??=r.unknownCaller?.(t,n),!i)return null;let l=t.arguments.map(m=>L(e,m,r));if(typeof i=="function")return s.length&&l.unshift(s.join(".")),i(...l);if(i=et(i,s),!i)throw new Error(`${ue.UNKNOWN_CALLER}: Unknown caller ${t.caller}`);return i(...l)}if(D.isArrayExpression(t))return t.map(n=>L(e,n,r));if(D.isObjectExpression(t)){let n={};for(let[s,i]of Object.entries(t))n[s]=L(e,i,r);return n}return t}async function fe(e,t){let r=await pe(e);if(!r)throw new Error("Failed to parse the code");return{block:L(t,r.project),imports:r.imports}}import{cp as cn,mkdir as nt,readFile as st,readdir as ge,stat as it,writeFile as me}from"node:fs/promises";import{basename as un,dirname as ot,isAbsolute as at,join as pt}from"node:path";import{tap as fn}from"rxjs/operators";async function z(e,t,r=!0){if(!e||e.trim().length===0)return"";function n(){switch(t){case"ts":return{parserImport:[import("prettier/plugins/typescript")],parserName:"typescript"};case"js":return{parserImport:[import("prettier/plugins/babel")],parserName:"babel"};case"html":return{parserImport:[import("prettier/plugins/html")],parserName:"html"};case"css":return{parserImport:[import("prettier/plugins/postcss")],parserName:"css"};case"scss":return{parserImport:[import("prettier/plugins/postcss")],parserName:"scss"};case"code-snippets":case"json":case"prettierrc":return{parserImport:[import("prettier/plugins/babel")],parserName:"json"};case"md":return{parserImport:[import("prettier/plugins/markdown")],parserName:"markdown"};case"yaml":case"yml":return{parserImport:[import("prettier/plugins/yaml")],parserName:"yaml"};case"":case"gitignore":case"dockerignore":case"prettierignore":case"Dockerfile":case"toml":case"env":case"txt":return{parserImport:[],parserName:""};default:return{parserImport:[],parserName:""}}}let{parserImport:s,parserName:i}=n();if(!i)return e;let[l,...m]=await Promise.all([import("prettier/standalone"),import("prettier/plugins/estree").then(u=>u),...s]);try{return l.format(e,{parser:i,plugins:m,singleQuote:!0}).then(u=>u.trim())}catch(u){if(u instanceof Error&&u.name==="SyntaxError")return r===!0?e:z(e,"ts",!0);if(!r)throw u;return e}}import qr from"localforage";import{differenceInSeconds as on}from"date-fns";async function _(e,t,r=!0){return Promise.all(Object.entries(t).map(async([n,s])=>{let i=at(n)?n:pt(e,n);await nt(ot(i),{recursive:!0}),typeof s=="string"?await me(i,r?await z(s,P(n)):s,"utf-8"):s.ignoreIfExists&&(await W(i)||await me(i,r?await z(s.content,P(n)):s.content,"utf-8"))}))}async function W(e){return it(e).then(()=>!0).catch(()=>!1)}async function ye(e){return await W(e)?ge(e):[]}async function xe(e){return await W(e)?st(e,"utf-8"):null}async function U(e,t=["ts"]){let r=await ge(e,{withFileTypes:!0}),n=[];for(let s of r)s.isDirectory()?n.push(`export * from './${s.name}';`):s.name!=="index.ts"&&t.includes(P(s.name))&&n.push(`export * from './${s.name.replace(`.${P(s.name)}`,"")}';`);return n.join(`
`)}import{get as Vn,merge as qn}from"lodash-es";import{get as wn}from"lodash-es";var he=`import { parse } from 'fast-content-type-parse';

import type { Endpoints } from './endpoints';

export interface RequestInterface<D extends object = object> {
  /**
   * Sends a request based on endpoint options
   *
   * @param {string} route Request method + URL. Example: 'GET /orgs/{org}'
   * @param {object} [parameters] URL, query or body parameters, as well as headers, mediaType.{format|previews}, request, or baseUrl.
   */
  <R extends keyof Endpoints>(
    route: R,
    options?: Endpoints[R]['input'],
  ): Promise<Endpoints[R]['output']>;
}

export async function handleError(response: Response) {
  try {
    if (response.status >= 400 && response.status < 500) {
      const body = (await response.json()) as Record<string, any>;
      return {
        status: response.status,
        body: body,
      };
    }
    return new Error(
      \`An error occurred while fetching the data. Status: \${response.status}\`,
    );
  } catch (error) {
    return error as any;
  }
}

async function handleChunkedResponse(response: Response, contentType: string) {
  const { type } = parse(contentType);

  switch (type) {
    case 'application/json': {
      let buffer = '';
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
      }
      return JSON.parse(buffer);
    }
    case 'text/html':
    case 'text/plain': {
      let buffer = '';
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
      }
      return buffer;
    }
    default:
      return response.body;
  }
}

export async function parseResponse(response: Response) {
  const contentType = response.headers.get('Content-Type');
  if (!contentType) {
    throw new Error('Content-Type header is missing');
  }

  if (response.status === 204) {
    return null;
  }
  const isChunked = response.headers.get('Transfer-Encoding') === 'chunked';
  if (isChunked) {
    return response.body;
    // return handleChunkedResponse(response, contentType);
  }

  const { type } = parse(contentType);
  switch (type) {
    case 'application/json':
      return response.json();
    case 'text/plain':
      return response.text();
    case 'text/html':
      return response.text();
    case 'text/xml':
    case 'application/xml':
      return response.text();
    case 'application/x-www-form-urlencoded':
      const text = await response.text();
      return Object.fromEntries(new URLSearchParams(text));
    case 'multipart/form-data':
      return response.formData();
    default:
      throw new Error(\`Unsupported content type: \${contentType}\`);
  }
}
`;var be=`import { z } from 'zod';

export type ParseError<T extends z.ZodType<any, any, any>> = {
  kind: 'parse';
} & z.inferFlattenedErrors<T>;

export function parse<T extends z.ZodType>(
  schema: T,
  input: unknown,
) {
  const result = schema.safeParse(input);
  if (!result.success) {
    const errors = result.error.flatten((issue) => issue);
    return [null, errors];
  }
  return [result.data as z.infer<T>, null];
}
`;var ve=`import { BodyInit } from 'undici-types'; // for node
type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type ContentType = 'xml' | 'json' | 'urlencoded' | 'multipart';
type Endpoint = \`\${ContentType} \${Method} \${string}\` | \`\${Method} \${string}\`;

export function createUrl(base: string, path: string, query: URLSearchParams) {
  const url = new URL(path, base);
  url.search = query.toString();
  return url;
}
function template(
  templateString: string,
  templateVariables: Record<string, any>,
): string {
  const nargs = /{([0-9a-zA-Z_]+)}/g;
  return templateString.replace(nargs, (match, key: string, index: number) => {
    // Handle escaped double braces
    if (
      templateString[index - 1] === '{' &&
      templateString[index + match.length] === '}'
    ) {
      return key;
    }

    const result = key in templateVariables ? templateVariables[key] : null;
    return result === null || result === undefined ? '' : String(result);
  });
}

interface ToRequest {
  <T extends Endpoint>(
    endpoint: T,
    input: Record<string, any>,
    props: {
      inputHeaders: string[];
      inputQuery: string[];
      inputBody: string[];
      inputParams: string[];
    },
    defaults: {
      baseUrl: string;
      headers?: Record<string, string>;
    },
  ): Request;
  urlencoded: <T extends Endpoint>(
    endpoint: T,
    input: Record<string, any>,
    props: {
      inputHeaders: string[];
      inputQuery: string[];
      inputBody: string[];
      inputParams: string[];
    },
    defaults: {
      baseUrl: string;
      headers?: Record<string, string>;
    },
  ) => Request;
}

function _json(
  input: Record<string, any>,
  props: {
    inputHeaders: string[];
    inputQuery: string[];
    inputBody: string[];
    inputParams: string[];
  },
) {
  const headers = new Headers({});
  for (const header of props.inputHeaders) {
    headers.set(header, input[header]);
  }

  const body: Record<string, any> = {};
  for (const prop of props.inputBody) {
    body[prop] = input[prop];
  }

  const query = new URLSearchParams();
  for (const key of props.inputQuery) {
    const value = input[key];
    if (value !== undefined) {
      query.set(key, String(value));
    }
  }

  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
    acc[key] = input[key];
    return acc;
  }, {});

  return {
    body: JSON.stringify(body),
    query,
    params,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
  };
}

type Input = Record<string, any>;
type Props = {
  inputHeaders: string[];
  inputQuery: string[];
  inputBody: string[];
  inputParams: string[];
};

abstract class Serializer {
  constructor(
    protected input: Input,
    protected props: Props,
  ) {}
  abstract getBody(): BodyInit | null;
  abstract getHeaders(): Record<string, string>;
  serialize(): Serialized {
    const headers = new Headers({});
    for (const header of this.props.inputHeaders) {
      headers.set(header, this.input[header]);
    }

    const query = new URLSearchParams();
    for (const key of this.props.inputQuery) {
      const value = this.input[key];
      if (value !== undefined) {
        query.set(key, String(value));
      }
    }

    const params = this.props.inputParams.reduce<Record<string, any>>(
      (acc, key) => {
        acc[key] = this.input[key];
        return acc;
      },
      {},
    );

    return {
      body: this.getBody(),
      query,
      params,
      headers: this.getHeaders(),
    };
  }
}

interface Serialized {
  body: BodyInit | null;
  query: URLSearchParams;
  params: Record<string, any>;
  headers: Record<string, string>;
}

class JsonSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body: Record<string, any> = {};
    for (const prop of this.props.inputBody) {
      body[prop] = this.input[prop];
    }
    return JSON.stringify(body);
  }
  getHeaders(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
  }
}

class UrlencodedSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body = new URLSearchParams();
    for (const prop of this.props.inputBody) {
      body.set(prop, this.input[prop]);
    }
    return body;
  }
  getHeaders(): Record<string, string> {
    return {};
  }
}

class FormDataSerializer extends Serializer {
  getBody(): BodyInit | null {
    const body = new FormData();
    for (const prop of this.props.inputBody) {
      body.append(prop, this.input[prop]);
    }
    return body;
  }
  getHeaders(): Record<string, string> {
    return {};
  }
}

export function json(input: Input, props: Props) {
  return new JsonSerializer(input, props).serialize();
}
export function urlencoded(input: Input, props: Props) {
  return new UrlencodedSerializer(input, props).serialize();
}
export function formdata(input: Input, props: Props) {
  return new FormDataSerializer(input, props).serialize();
}

export function _urlencoded(
  input: Record<string, any>,
  props: {
    inputHeaders: string[];
    inputQuery: string[];
    inputBody: string[];
    inputParams: string[];
  },
) {
  const headers = new Headers({});
  for (const header of props.inputHeaders) {
    headers.set(header, input[header]);
  }

  const body = new URLSearchParams();
  for (const prop of props.inputBody) {
    body.set(prop, input[prop]);
  }

  const query = new URLSearchParams();
  for (const key of props.inputQuery) {
    const value = input[key];
    if (value !== undefined) {
      query.set(key, String(value));
    }
  }

  const params = props.inputParams.reduce<Record<string, any>>((acc, key) => {
    acc[key] = input[key];
    return acc;
  }, {});

  return {
    body,
    query,
    params,
    headers: {},
  };
}

export function toRequest<T extends Endpoint>(
  endpoint: T,
  input: Serialized,
  defaults: {
    baseUrl: string;
    headers?: Record<string, string>;
  },
): Request {
  const [method, path] = endpoint.split(' ');

  const headers = new Headers({
    ...defaults?.headers,
    ...input.headers,
  });
  const pathVariable = template(path, input.params);

  const url = createUrl(defaults.baseUrl, pathVariable, input.query);
  return new Request(url, {
    method: method,
    headers: headers,
    body: method === 'GET' ? undefined : input.body,
  });
}
`;var ke=`export interface ApiResponse<Status extends number, Body extends unknown> {
  kind: 'response';
  status: Status;
  body: Body;
}

// 4xx Client Errors
export type BadRequest = ApiResponse<400, { message: string }>;
export type Unauthorized = ApiResponse<401, { message: string }>;
export type PaymentRequired = ApiResponse<402, { message: string }>;
export type Forbidden = ApiResponse<403, { message: string }>;
export type NotFound = ApiResponse<404, { message: string }>;
export type MethodNotAllowed = ApiResponse<405, { message: string }>;
export type NotAcceptable = ApiResponse<406, { message: string }>;
export type Conflict = ApiResponse<409, { message: string }>;
export type Gone = ApiResponse<410, { message: string }>;
export type UnprocessableEntity = ApiResponse<422, { message: string; errors?: Record<string, string[]> }>;
export type TooManyRequests = ApiResponse<429, { message: string; retryAfter?: string }>;
export type PayloadTooLarge = ApiResponse<413, { message: string; }>;
export type UnsupportedMediaType = ApiResponse<415, { message: string; }>;

// 5xx Server Errors
export type InternalServerError = ApiResponse<500, { message: string }>;
export type NotImplemented = ApiResponse<501, { message: string }>;
export type BadGateway = ApiResponse<502, { message: string }>;
export type ServiceUnavailable = ApiResponse<503, { message: string; retryAfter?: string }>;
export type GatewayTimeout = ApiResponse<504, { message: string }>;

export type ClientError =
  | BadRequest
  | Unauthorized
  | PaymentRequired
  | Forbidden
  | NotFound
  | MethodNotAllowed
  | NotAcceptable
  | Conflict
  | Gone
  | UnprocessableEntity
  | TooManyRequests;

export type ServerError =
  | InternalServerError
  | NotImplemented
  | BadGateway
  | ServiceUnavailable
  | GatewayTimeout;

export type ProblematicResponse = ClientError | ServerError;
`;import{camelcase as Ee}from"stringcase";var we=e=>{let t={...e.options??{},fetch:{schema:"z.function().args(z.instanceof(Request)).returns(z.promise(z.instanceof(Response))).optional()"},baseUrl:{schema:"z.string().url()"}};e.securityScheme&&(t.token={schema:"z.string().optional()"});let r=e.securityScheme?`{Authorization: \`${te(e.securityScheme.bearerAuth.scheme)} \${this.options.token}\`}`:"{}";return`

import z from 'zod';
import type { Endpoints } from './endpoints';
import type { StreamEndpoints } from './stream-endpoints';
import schemas from './schemas';
import { parse } from './parser';
import { handleError, parseResponse } from './client';

      const optionsSchema = z.object(${R(t,n=>n.schema)});
      type ${e.name}Options = z.infer<typeof optionsSchema>;
    export class ${e.name} {

      constructor(public options: ${e.name}Options) {}

  async request<E extends keyof Endpoints>(
    endpoint: E,
    input: Endpoints[E]['input'],
  ): Promise<readonly [Endpoints[E]['output'], Endpoints[E]['error'] | null]> {
      const route = schemas[endpoint];
      const [parsedInput, parseError] = parse(route.schema, input);
      if (parseError) {
        return [
          null as never,
          { ...parseError, kind: 'parse' } as never,
        ] as const;
      }
      const request = route.toRequest(parsedInput as never, {
        headers: this.defaultHeaders,
        baseUrl: this.options.baseUrl,
      });
      const response = await (this.options.fetch ?? fetch)(request);
      if (response.ok) {
        const data = await parseResponse(response);
        return [data as Endpoints[E]['output'], null] as const;
      }
      const error = await handleError(response);
      return [null as never, { ...error, kind: 'response' }] as const;
  }

      get defaultHeaders() {
        return ${r}
      }

  setOptions(options: Partial<${e.name}Options>) {
    const validated = optionsSchema.partial().parse(options);

    for (const key of Object.keys(validated) as (keyof ${e.name}Options)[]) {
      if (validated[key] !== undefined) {
        (this.options[key] as typeof validated[typeof key]) = validated[key]!;
      }
    }
  }
}`};var J=class{#e=["import z from 'zod';",'import type { Endpoints } from "./endpoints";','import type { StreamEndpoints } from "./stream-endpoints";',"import { toRequest, json, urlencoded, formdata, createUrl } from './request';","import type { ParseError } from './parser';"];#t=[];addEndpoint(t,r){this.#t.push(`  "${t}": ${r},`)}addImport(t){this.#e.push(t)}complete(){return`${this.#e.join(`
`)}
export default {
${this.#t.join(`
`)}
}`}},V=class{imports=["import z from 'zod';","import type { ParseError } from './parser';"];endpoints=[];addEndpoint(t,r){this.endpoints.push(`  "${t}": ${r};`)}addImport(t){this.imports.push(t)}complete(){return`${this.imports.join(`
`)}
export interface Endpoints {
${this.endpoints.join(`
`)}
}`}},G=class extends V{complete(){return`${this.imports.join(`
`)}
export interface StreamEndpoints {
${this.endpoints.join(`
`)}
}`}};function Te(e){let t=new V,r=new G,n={},s=[],i=new J,l=[];for(let[m,u]of Object.entries(e.groups)){let o=Ee(m);n[o]=["import z from 'zod';"],t.addImport(`import * as ${o} from './inputs/${o}';`),r.addImport(`import * as ${o} from './inputs/${o}';`),i.addImport(`import * as ${o} from './inputs/${o}';`);for(let a of u){let f=Ee(`${a.name} schema`),k=`export const ${f} = ${Object.keys(a.schemas).length===1?Object.values(a.schemas)[0]:R(a.schemas)};`;n[o].push(k),s.push(...a.imports.map(v=>(v.namedImports??[]).map(x=>x.name)).flat());let b=`${o}.${f}`,h=a.formatOutput(),c=[],g=[],y=[],E=[];for(let[v,x]of Object.entries(a.inputs))if(x.source==="headers"||x.source==="header")c.push(`"${v}"`);else if(x.source==="query")g.push(`"${v}"`);else if(x.source==="body")y.push(`"${v}"`);else if(x.source==="path")E.push(`"${v}"`);else{if(x.source==="internal")continue;throw new Error(`Unknown source ${x.source} in ${v} ${JSON.stringify(x)} in ${a.name}`)}if(a.type==="sse"){let v=`z.infer<typeof ${b}>`,x=`${a.trigger.method.toUpperCase()} ${a.trigger.path}`;r.addImport(`import {${$(a.name)}} from './outputs/${a.name}';`),r.addEndpoint(x,`{input: ${v}, output: ${h.use}}`),i.addEndpoint(x,`{
        schema: ${b},
        toRequest(input: StreamEndpoints['${x}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
          const endpoint = '${x}';
            return toRequest(endpoint, json(input, {
            inputHeaders: [${c}],
            inputQuery: [${g}],
            inputBody: [${y}],
            inputParams: [${E}],
          }), init);
          },
        }`)}else{t.addImport(`import {${h.import}} from './outputs/${a.name}';`),l.push(...a.errors??[]);let v=Object.keys(a.schemas).length>1;for(let x in a.schemas??{}){let Q="";v&&x!=="json"&&(Q=`${x} `);let Z=`typeof ${b}${v?`.${x}`:""}`,F=`${Q}${a.trigger.method.toUpperCase()} ${a.trigger.path}`;t.addEndpoint(F,`{input: z.infer<${Z}>; output: ${h.use}; error: ${(a.errors??["ServerError"]).concat(`ParseError<${Z}>`).join("|")}}`),i.addEndpoint(F,`{
          schema: ${b}${v?`.${x}`:""},
          toRequest(input: Endpoints['${F}']['input'], init: {baseUrl:string; headers?: Record<string, string>}) {
            const endpoint = '${F}';
              return toRequest(endpoint, ${a.contentType||"json"}(input, {
              inputHeaders: [${c}],
              inputQuery: [${g}],
              inputBody: [${y}],
              inputParams: [${E}],
            }), init);
            },
          }`)}}}}return t.addImport(`import type { ${j(l,m=>m).join(", ")} } from './response';`),{...Object.fromEntries(Object.entries(n).map(([m,u])=>[`inputs/${m}.ts`,[s.length?`import {${j(s,o=>o)}} from '../zod';`:"",...u].join(`
`)])),"backend.ts":we(e),"parser.ts":be,"client.ts":he,"request.ts":ve,"schemas.ts":i.complete(),"endpoints.ts":t.complete(),"stream-endpoints.ts":r.complete(),"response.ts":ke}}import mt from"debug";import{dirname as Se,join as gt}from"node:path";import p from"typescript";var ft={DateConstructor:"Date"};function H(e,t){let r=[];for(let n of e.types)n==null?r.push("any"):typeof n=="string"?(r.push(`${ft[n]||n}${e.kind==="array"?"[]":""}`),t(n)):"types"in n&&r.push(H(n,t));return r.join(" | ")}function Re(e,t){let r={};for(let[i,l]of Object.entries(e))for(let[m,u]of Object.entries(l)){let o=[],a=u[t],f=new Set;if(a){let k=H(u,b=>{f.add(b)});r[i]={exports:[m],imports:Array.from(f),content:`export type ${m} = ${k};`}}else{for(let[k,b]of Object.entries(u)){let h=[k];b.optional&&h.push("?"),h.push(": "),h.push(H(b,c=>{f.add(c)})),o.push(h.join(""))}r[i]={exports:[m],imports:Array.from(f),content:`export interface ${$(m)} {
${o.join(`
`)}
}
`}}}let n=Object.values(r).flatMap(i=>i.exports),s={};for(let[i,{content:l,exports:m,imports:u}]of Object.entries(r)){let o=[];for(let f of u)n.includes(f)&&f!==i&&o.push(`import { ${f} } from './${f}';`);let a=`${o.join(`
`)}
${l}`;s[i]=a}return s}var S=mt("january:client");function yt(e){S(`Using TypeScript version: ${p.version}`);let t=p.readConfigFile(e,p.sys.readFile);if(t.error)throw console.error("Failed to read tsconfig file:",p.formatDiagnosticsWithColorAndContext([t.error],{getCanonicalFileName:n=>n,getCurrentDirectory:p.sys.getCurrentDirectory,getNewLine:()=>p.sys.newLine})),new Error("Failed to parse tsconfig.json");let r=p.parseJsonConfigFileContent(t.config,p.sys,Se(e));if(r.errors.length>0)throw console.error("Errors found in tsconfig.json:",p.formatDiagnosticsWithColorAndContext(r.errors,{getCanonicalFileName:n=>n,getCurrentDirectory:p.sys.getCurrentDirectory,getNewLine:()=>p.sys.newLine})),new Error("Failed to parse tsconfig.json");return r}var Oe=e=>t=>{if(p.isReturnStatement(t)&&t.expression)if(p.isCallExpression(t.expression)&&t.expression.expression&&p.isPropertyAccessExpression(t.expression.expression)){let r=t.expression.expression;if(p.isIdentifier(r.expression)&&r.expression.text==="output"){let[n]=t.expression.arguments;if(!n)return;e(n)}}else e(t.expression);return p.forEachChild(t,Oe(e))};function $e(e,t){return p.isCallExpression(e)&&e.expression&&p.isIdentifier(e.expression)&&e.expression.text===t}function Ie(e,t){if(p.isObjectLiteralExpression(e))return e.properties.filter(r=>p.isPropertyAssignment(r)).find(r=>r.name.getText()===t)}function xt(e,t){let r=[];return e.forEachChild(n=>{if(p.isExportAssignment(n)&&$e(n.expression,"feature")){let[s]=n.expression.arguments;if(p.isObjectLiteralExpression(s)){let i=Ie(s,"workflows");if(!i)return;p.isArrayLiteralExpression(i.initializer)&&i.initializer.forEachChild(l=>{if($e(l,"workflow")){let[m,u]=l.arguments,o=p.isStringLiteral(m)?m.text:"";if(!o)return;if(p.isObjectLiteralExpression(u)){let a=Ie(u,"execute");if(a?.initializer&&p.isArrowFunction(a.initializer)&&p.isBlock(a.initializer.body)){let f={[o]:{[w]:!0,optional:!1,types:["void"]}};Oe(k=>{f[o]=t.serializeNode(k)})(a.initializer.body),r.push(f)}}}})}}}),r}var w=Symbol.for("serialize");function ht(e){return e.isClassOrInterface()?!!(e.symbol.flags&p.SymbolFlags.Interface):!1}var K=class{constructor(t){this.checker=t}collector={};serializeType(t){if(t.isUnion()||t.isIntersection()){let r,n=[];for(let s of t.types)r===void 0&&(r=(s.flags&p.TypeFlags.Undefined)!==0,r)||n.push(this.serializeType(s));return{[w]:!0,optional:r,types:n}}if(this.checker.isArrayLikeType(t)){let[r]=this.checker.getTypeArguments(t);if(!r)return console.warn(`No argument type found for ${t.symbol?.name} of ${this.checker.typeToString(t)}`),{[w]:!0,optional:!1,kind:"array",types:["any"]};let n=r.getSymbol();if(!n)return{[w]:!0,optional:!1,kind:"array",types:[this.checker.typeToString(r)]};let s=n.valueDeclaration;return s?{kind:"array",...this.serializeNode(s)}:null}if(t.isClass()){let r=t.symbol?.valueDeclaration;return r?this.serializeNode(r):{[w]:!0,optional:!1,types:[t.symbol.getName()]}}if(ht(t)){let r=t.symbol.valueDeclaration??t.symbol.declarations?.[0];return r?this.serializeNode(r):{[w]:!0,optional:!1,types:[t.symbol.getName()]}}return{[w]:!0,optional:!1,types:[this.checker.typeToString(t)]}}serializeNode(t){if(p.isObjectLiteralExpression(t)){let r=this.checker.getTypeAtLocation(t),n={};for(let s of r.getProperties()){let i=this.checker.getTypeOfSymbol(s);n[s.name]=this.serializeType(i)}return n}if(p.isPropertySignature(t)){let r=this.checker.getSymbolAtLocation(t.name);if(!r)return console.warn(`No symbol found for ${t.name.getText()}`),null;let n=this.checker.getTypeOfSymbol(r);return this.serializeType(n)}if(p.isPropertyDeclaration(t)){let r=this.checker.getSymbolAtLocation(t.name);if(!r)return console.warn(`No symbol found for ${t.name.getText()}`),null;let n=this.checker.getTypeOfSymbol(r);return this.serializeType(n)}if(p.isInterfaceDeclaration(t)){if(!t.name?.text)throw new Error("Interface has no name");if({ReadableStream:"ReadableStream",DateConstructor:"Date"}[t.name.text])return{[w]:!0,optional:!1,types:[t.name.text]};if(!this.collector[t.name.text]){this.collector[t.name.text]={};let n={};for(let s of t.members.filter(p.isPropertySignature))n[s.name.getText()]=this.serializeNode(s);this.collector[t.name.text]=n}return{[w]:!0,optional:!1,types:[t.name.text]}}if(p.isClassDeclaration(t)){if(!t.name?.text)throw new Error("Class has no name");if(!this.collector[t.name.text]){this.collector[t.name.text]={};let r={};for(let n of t.members.filter(p.isPropertyDeclaration))r[n.name.getText()]=this.serializeNode(n);this.collector[t.name.text]=r}return{[w]:!0,optional:!1,types:[t.name.text]}}if(p.isVariableDeclaration(t)){if(!this.checker.getSymbolAtLocation(t.name))return console.warn(`No symbol found for ${t.name.getText()}`),null;if(!t.type)return"any";let n=this.checker.getTypeFromTypeNode(t.type);return this.serializeType(n)}if(p.isIdentifier(t)){if(!this.checker.getSymbolAtLocation(t))return console.warn(`No symbol found for ${t.getText()}`),null;let n=this.checker.getTypeAtLocation(t);return this.serializeType(n)}if(p.isAwaitExpression(t)){let r=this.checker.getTypeAtLocation(t);return this.serializeType(r)}return{[w]:!0,optional:!1,types:["any"]}}};function je(e,t){let r=yt(e);S("Parsing tsconfig");let n=p.createProgram({options:{...r.options,noEmit:!0,incremental:!0,tsBuildInfoFile:gt(Se(e),"./.tsbuildinfo")},rootNames:r.fileNames,projectReferences:r.projectReferences,configFileParsingDiagnostics:r.errors});S("Program created");let s=n.getTypeChecker();S("Type checker created");let i=new K(s),l={};for(let m of t){S(`Transforming feature ${m.name}`);let u=n.getSourceFile(m.path);if(!u)throw new Error(`File not found: ${m.path}`);let o=xt(u,i),a={...i.collector};for(let k of o)for(let[b,h]of Object.entries(k))a[b]=h;let f=Object.entries(a).reduce((k,[b,h])=>(k[b]={[b]:h},k),{});S(`Converting feature ${m.name} to interface`),l[m.name]=Re(f,w)}return l}function Pe(e){let t={};for(let[r,n]of Object.entries(e))for(let[s,i]of Object.entries(n))t[`${s}.ts`]=i;return t}async function Tt(e,t){let r=await kt(e);return Object.fromEntries(await Promise.all(r.map(async n=>{let s=O(e,n),i=await vt(s,"utf-8"),l=await fe(i,bt(...t,de));return[wt(s).replace(Et(s),""),l.block.workflows.map(u=>{let o=Object.fromEntries(Object.entries(u.trigger.inputs).map(([a,f])=>[a,{schema:f.data.zod,source:f.data.source}]));return{imports:l.imports.filter(a=>a.moduleSpecifier==="@workspace/extensions/zod"),inputs:o,schema:`z.object(${R(o,a=>a.schema)})`,errors:["ServerError"],contentType:"json",schemas:{json:`z.object(${R(o,a=>a.schema)})`},name:u.name,type:u.trigger.type,formatOutput:()=>({import:$(u.name),use:$(u.name)}),trigger:{path:Y({featureName:"/",workflowTag:u.tag,workflowPath:u.trigger.config.path}),method:u.trigger.config.method}}})]})))}async function ps({client:e,fs:t,primitives:r}){let n={name:e.name,options:e.options,securityScheme:e.securityScheme,groups:await Tt(t.features,r)},s=Te(n),[i,l]=await Promise.all([xe(O(t.extensions,"zod","index.ts")).then(f=>f||""),ye(t.features)]);await _(e.output,{...s,"zod.ts":i},e.formatGeneratedCode);let m=je(t.tsconfig,l.map(f=>({name:f,path:O(t.features,f)})));await _(O(e.output,"outputs"),Pe(m),e.formatGeneratedCode);let[u,o,a]=await Promise.all([U(e.output),U(O(e.output,"outputs")),U(O(e.output,"inputs"))]);await _(e.output,{"index.ts":u,"outputs/index.ts":o,"inputs/index.ts":a,...e.packageName&&{"../package.json":ee({name:e.packageName,version:"0.0.0",type:"module",main:"./index.js",module:"./index.js",types:"./src/index.d.ts",dependencies:{validator:"^13.12.0",zod:"^3.23.8","fast-content-type-parse":"^2.0.0"},exports:{"./package.json":"./package.json",".":{node:"./index.js",default:"./index.js",import:"./index.js",types:"./src/index.d.ts"}}})}},e.formatGeneratedCode)}export{ps as generate};
